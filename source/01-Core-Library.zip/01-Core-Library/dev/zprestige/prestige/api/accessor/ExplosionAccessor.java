package dev.zprestige.prestige.api.accessor;
import dev.zprestige.prestige.api.reflect.BoundFieldAccessor;


import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.explosion.Explosion.DestructionType;

public class ExplosionAccessor {
   private final Explosion a;
   private static final long b = 97923152025046L;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[50];
   private static final String[] g = new String[50];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;

   public ExplosionAccessor(Explosion var1) {
      this.a = var1;
   }

   public DamageSource aReturningDamageSource(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 97923152025046L ^ var2;
      long var4 = var2 ^ 121694838542881L;
      long var6 = var2 ^ 61294149535694L;
      BoundFieldAccessor var8 = invokeBinding2(
         new Object[]{this.a, invokeBinding1(25311, 5005151933040175697L ^ var2), Explosion.class, DamageSource.class, var6}, 8833602644552302841L, var2
      );
      return (DamageSource)invokeBinding3(var8, new Object[]{var4}, 8833384213121816971L, var2);
   }

   public void aReturningVoid(Object[] var1) {
      World var2 = (World)var1[0];
      long var3 = (Long)var1[1];
      var3 = 97923152025046L ^ var3;
      long var5 = var3 ^ 80120984083168L;
      long var7 = var3 ^ 121084910531866L;
      BoundFieldAccessor var9 = invokeBinding5(
         new Object[]{this.a, invokeBinding4(29596, 7421039374382483906L ^ var3), Explosion.class, World.class, var7}, -8628022418144021971L, var3
      );
      invokeBinding6(var9, new Object[]{var2, var5}, -8628630700705687402L, var3);
   }

   public void bReturningVoid(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 97923152025046L ^ var2;
      long var5 = var2 ^ 75630531828031L;
      long var7 = var2 ^ 107991636653765L;
      BoundFieldAccessor var9 = invokeBinding8(
         new Object[]{this.a, invokeBinding7(12101, 7593144609069029057L ^ var2), Explosion.class, Entity.class, var7}, -3775116800772312590L, var2
      );
      invokeBinding9(var9, new Object[]{var4, var5}, -3774018619678647479L, var2);
   }

   public void cReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      long var4 = (Long)var1[1];
      var4 = 97923152025046L ^ var4;
      long var6 = var4 ^ 119914382117217L;
      long var8 = var4 ^ 83500203615899L;
      BoundFieldAccessor var10 = invokeBinding11(
         new Object[]{this.a, "x", Explosion.class, invokeBinding10(6613107778345531894L, var4), var8}, 6611915938726338988L, var4
      );
      invokeBinding13(var10, new Object[]{invokeBinding12(var2, 6611694520050383812L, var4), var6}, 6611802987226827543L, var4);
   }

   public void dReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      long var4 = (Long)var1[1];
      var4 = 97923152025046L ^ var4;
      long var6 = var4 ^ 128964697754184L;
      long var8 = var4 ^ 92033484088754L;
      BoundFieldAccessor var10 = invokeBinding15(
         new Object[]{this.a, "y", Explosion.class, invokeBinding14(-7426609260245435681L, var4), var8}, -7427800525948640635L, var4
      );
      invokeBinding17(var10, new Object[]{invokeBinding16(var2, -7428567292203091731L, var4), var6}, -7428459383360829378L, var4);
   }

   public void eReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      long var4 = (Long)var1[1];
      var4 = 97923152025046L ^ var4;
      long var6 = var4 ^ 118916334085704L;
      long var8 = var4 ^ 82298083346866L;
      BoundFieldAccessor var10 = invokeBinding19(
         new Object[]{this.a, "z", Explosion.class, invokeBinding18(-797283006328351009L, var4), var8}, -798474504459694459L, var4
      );
      invokeBinding21(var10, new Object[]{invokeBinding20(var2, -799261345999465235L, var4), var6}, -799152668353616834L, var4);
   }

   public void fReturningVoid(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 97923152025046L ^ var2;
      long var5 = var2 ^ 22238815303171L;
      long var7 = var2 ^ 55831243545081L;
      BoundFieldAccessor var9 = invokeBinding24(
         new Object[]{this.a, invokeBinding22(18807, 7600920051603136456L ^ var2), Explosion.class, invokeBinding23(-6584090045127190853L, var2), var7},
         -6584183810050548018L,
         var2
      );
      invokeBinding26(var9, new Object[]{invokeBinding25(var4, -6583427036836246479L, var2), var5}, -6583225818367101835L, var2);
   }

   public void gReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      long var3 = (Long)var1[1];
      var3 = 97923152025046L ^ var3;
      long var5 = var3 ^ 26726541635055L;
      long var7 = var3 ^ 68926102487573L;
      BoundFieldAccessor var9 = invokeBinding29(
         new Object[]{this.a, invokeBinding27(17278, 115907800268066350L ^ var3), Explosion.class, invokeBinding28(4561256608000608002L, var3), var7},
         4561103822178845986L,
         var3
      );
      invokeBinding31(var9, new Object[]{invokeBinding30(var2, 4558611443503023316L, var3), var5}, 4562043653734199193L, var3);
   }

   public void hReturningVoid(Object[] var1) {
      DestructionType var2 = (DestructionType)var1[0];
      long var3 = (Long)var1[1];
      var3 = 97923152025046L ^ var3;
      long var5 = var3 ^ 106824063736637L;
      long var7 = var3 ^ 78998197548231L;
      BoundFieldAccessor var9 = invokeBinding33(
         new Object[]{this.a, invokeBinding32(28185, 3509028667116492185L ^ var3), Explosion.class, DestructionType.class, var7}, 5304733123676730352L, var3
      );
      invokeBinding34(var9, new Object[]{var2, var5}, 5304637697388484939L, var3);
   }

   public void iReturningVoid(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      float var3 = (Float)var1[1];
      boolean var4 = (Boolean)var1[2];
      long var5 = (Long)var1[3];
      var5 = 97923152025046L ^ var5;
      long var7 = var5 ^ 101712161310006L;
      long var9 = var5 ^ 45766094514184L;
      long var11 = var5 ^ 441498380757L;
      long var13 = var5 ^ 89020035243738L;
      long var15 = var5 ^ 13680803244554L;
      long var17 = var5 ^ 40265457390973L;
      long var19 = var5 ^ 41471863913044L;
      long var21 = var5 ^ 68112735975805L;
      invokeBinding37(
         this, new Object[]{invokeBinding36(invokeBinding35(3765537482565501436L, var5), 3765492963740641097L, var5), var11}, 3765726083544765329L, var5
      );
      invokeBinding38(this, new Object[]{null, var15}, 3766075645977891332L, var5);
      double var10001 = invokeBinding39(var2, 3769424318212038447L, var5);
      Object[] var10004 = new Object[]{null, var19};
      var10004[0] = var10001;
      invokeBinding40(this, var10004, 3766251808597744410L, var5);
      var10001 = invokeBinding41(var2, 3769471569366569467L, var5);
      var10004 = new Object[]{null, var21};
      var10004[0] = var10001;
      invokeBinding42(this, var10004, 3765304225884012199L, var5);
      var10001 = invokeBinding43(var2, 3765590325435015159L, var5);
      var10004 = new Object[]{null, var17};
      var10004[0] = var10001;
      invokeBinding44(this, var10004, 3765940019495240012L, var5);
      var10004 = new Object[]{null, var7};
      var10004[0] = var3;
      invokeBinding45(this, var10004, 3769265032155640782L, var5);
      var10004 = new Object[]{null, var13};
      var10004[0] = var4;
      invokeBinding46(this, var10004, 3765701773244486478L, var5);
      invokeBinding48(this, new Object[]{invokeBinding47(3765058775730788517L, var5), var9}, 3769175020560363393L, var5);
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(67776565289176L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      String var6 = "óÊFàO(ÑGÿ\u0087ÜÎ}½* *\n\u0007\u0087Õ\"`\u0005%ï\u0094Ü\u0011ðä×\u0010\u0091ª\u0099ÛÎ÷\u009f\u008c©þ\u009bäF\u0007p4 |\u0010w\u0095]\u00adã\u0011\u0091\u0004Òé\u0012ØÌé\u0098hç\u001aç\u0015ð\u0089ÓÚ4ko\u00141º\u0010¤û¡<7`d.é~±ò\u008d¾S\u0016";
      int var8 = "óÊFàO(ÑGÿ\u0087ÜÎ}½* *\n\u0007\u0087Õ\"`\u0005%ï\u0094Ü\u0011ðä×\u0010\u0091ª\u0099ÛÎ÷\u009f\u008c©þ\u009bäF\u0007p4 |\u0010w\u0095]\u00adã\u0011\u0091\u0004Òé\u0012ØÌé\u0098hç\u001aç\u0015ð\u0089ÓÚ4ko\u00141º\u0010¤û¡<7`d.é~±ò\u008d¾S\u0016"
         .length();
      char var5 = ' ';
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = a(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     c = var9;
                     d = new String[6];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "ýÂÑÖKÄ3Þ^n!>¤Ì\u0019: \u009f^c Aq¹iÛx{Æõ/\u008eyw\u0002ØeÐÓX-yø\u008c\u001dwU\u0003'";
                  var8 = "ýÂÑÖKÄ3Þ^n!>¤Ì\u0019: \u009f^c Aq¹iÛx{Æõ/\u008eyw\u0002ØeÐÓX-yø\u008c\u001dwU\u0003'".length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12820;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])e.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/E", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/E_C0215",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/E" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 53;
            yield var15;
         }
         case 1 -> {
            byte var16 = 25;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 7;
            yield var18;
         }
         case 4 -> {
            byte var19 = 18;
            yield var19;
         }
         case 5 -> {
            byte var20 = 0;
            yield var20;
         }
         case 6 -> {
            byte var21 = 40;
            yield var21;
         }
         case 7 -> {
            byte var22 = 34;
            yield var22;
         }
         case 8 -> {
            byte var23 = 36;
            yield var23;
         }
         case 9 -> {
            byte var24 = 1;
            yield var24;
         }
         case 10 -> {
            byte var25 = 45;
            yield var25;
         }
         case 11 -> {
            byte var26 = 63;
            yield var26;
         }
         case 12 -> {
            byte var27 = 54;
            yield var27;
         }
         case 13 -> {
            byte var28 = 17;
            yield var28;
         }
         case 14 -> {
            byte var29 = 51;
            yield var29;
         }
         case 15 -> {
            byte var30 = 14;
            yield var30;
         }
         case 16 -> {
            byte var31 = 22;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 57;
            yield var33;
         }
         case 19 -> {
            byte var34 = 9;
            yield var34;
         }
         case 20 -> {
            byte var35 = 59;
            yield var35;
         }
         case 21 -> {
            byte var36 = 52;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 2;
            yield var38;
         }
         case 24 -> {
            byte var39 = 11;
            yield var39;
         }
         case 25 -> {
            byte var40 = 26;
            yield var40;
         }
         case 26 -> {
            byte var41 = 32;
            yield var41;
         }
         case 27 -> {
            byte var42 = 39;
            yield var42;
         }
         case 28 -> {
            byte var43 = 44;
            yield var43;
         }
         case 29 -> {
            byte var44 = 62;
            yield var44;
         }
         case 30 -> {
            byte var45 = 58;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 35;
            yield var47;
         }
         case 33 -> {
            byte var48 = 23;
            yield var48;
         }
         case 34 -> {
            byte var49 = 29;
            yield var49;
         }
         case 35 -> {
            byte var50 = 30;
            yield var50;
         }
         case 36 -> {
            byte var51 = 61;
            yield var51;
         }
         case 37 -> {
            byte var52 = 49;
            yield var52;
         }
         case 38 -> {
            byte var53 = 6;
            yield var53;
         }
         case 39 -> {
            byte var54 = 28;
            yield var54;
         }
         case 40 -> {
            byte var55 = 38;
            yield var55;
         }
         case 41 -> {
            byte var56 = 31;
            yield var56;
         }
         case 42 -> {
            byte var57 = 46;
            yield var57;
         }
         case 43 -> {
            byte var58 = 19;
            yield var58;
         }
         case 44 -> {
            byte var59 = 55;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 24;
            yield var61;
         }
         case 47 -> {
            byte var62 = 13;
            yield var62;
         }
         case 48 -> {
            byte var63 = 33;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 5;
            yield var65;
         }
         case 51 -> {
            byte var66 = 3;
            yield var66;
         }
         case 52 -> {
            byte var67 = 8;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 42;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 21;
            yield var71;
         }
         case 57 -> {
            byte var72 = 37;
            yield var72;
         }
         case 58 -> {
            byte var73 = 10;
            yield var73;
         }
         case 59 -> {
            byte var74 = 15;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 43;
            yield var76;
         }
         case 62 -> {
            byte var77 = 56;
            yield var77;
         }
         default -> 16;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "kVBR\u00074}VG\b\u0014#j\u001dD\u000e\u00187{ZS\u0019S']";
      f[1] = "5i\u0012F(\u0015@I\u0019I9Z!G\u0012B=\u0000U";
      f[2] = "4\u001bJYk\u0000\"\u001bO\u0003x\u00175PL\u0005t\u0003$\u0017[\u0012?\u0012\u001e";
      f[3] = "H>\u001fj.h=\u001e\u0014e?'\\\u0010\u001fn;}(";
      f[4] = "\u0001\u001dzn\u0007B\n\u0012k!fL\u0001\u0019o{";
      f[5] = "\u0011\\\fLP\u007f\u001aS\u001d\u00038\u007f\u0014\\\u000e";
      f[6] = "eeeMT\u0007njt\u00029\u0007nw`";
      f[7] = float.class;
      g[7] = "java/lang/Float";
      f[8] = "0\u000b\u0014\u001f/ E+\u001f\u0010>o$%\u0014\u001b:5P";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = "I\b!,yKB\u00070c\u0015HL\u00052,9";
      f[11] = boolean.class;
      g[11] = "java/lang/Boolean";
      f[12] = "\u0007_S\u0003}b\fPBL\u0017a\u0018\\I\u0007";
      f[13] = double.class;
      g[13] = "java/lang/Double";
      f[14] = "R\u0018n %\fD\u0018kz6\u001bSSh|:\u000fB\u0014\u007fkq9";
      f[15] = "j\u0005\u0018e\u0013]\u001f%\u0013j\u0002\u0012~+\u0018a\u0006H\n";
      f[16] = "F'\u0010\u001d#&3\u0007\u001b\u00122iR\t\u0010\u001963&";
      f[17] = "Y\u000e%<g&Y\u000e2`k)CE2~k<D4c&9";
      f[18] = "\u0004gx\u0007nt\u0004go[b{\u001e,oEbn\u0019]=\u00101*Na`Hpn56=\u001e:";
      f[19] = "bnii\u0016|\u0017Nbf\u00073v@im\u0003i\u0002";
      f[20] = "fY\u007flsEfYh0\u007fJ|\u0012h.\u007f_{c8s.";
      f[21] = "Yoql6=Yof0:2C$f.:'DU3qc";
      f[22] = "<\u0013p*\u000bbI3{%\u001a-(=p.\u001ew\\";
      f[23] = "\u000ef\u001fv\u0016\u000f{F\u0014y\u0007@\u001aH\u001fr\u0003\u001an";
      f[24] = "C3F\u000f\u0016\u00176\u0013M\u0000\u0007XW\u001dF\u000b\u0003\u0002#";
      f[25] = "ljK\u0001H7\u0019J@\u000eYxxDK\u0005]\"\f";
      f[26] = "\u0002. )n.w\u000e+&\u007fa\u0016\u0000 -{;b";
      f[27] = "Y\u000bPaC\\\\\u000e\u0018n*\\0\u0000M:NF\f\u0004\u001f9V<\u000e\u0018\u001b\u007fE_Z\u001dPt*";
      f[28] = "2\u0013Z.887\u0016\u0012!Q6[\u0018Gu5\"g\u001c\u0015v-Xe\u0000\u00110>;1\u0005Z;Q";
      f[29] = "q~rM'2>jp\u001aK*'~a\u0018\f:N%a\b6dtg#\u0015pTq~rM'2>jp\u001aK";
      f[30] = "q!fZQwu pL;\"{|eFlu!,;*\npu)<QE3\".";
      f[31] = "\bAy\u0002B;\f@o\u0014(n\u0002\u001cz\u001e\u007f9XL'r\u0019<\fI#\tV\u007f[N";
      f[32] = "%|o\u0000\u0013\u000e*x7\u001f,^/mm\t{\t~>9Z,[2flZ\u0012T6>s";
      f[33] = "\u001b\u000f}p<E\u0012Ng\u001b/7\u001c\u00199\u007f?\u000b\u0018K:gE\u000e\u0019\u000e;a\"Y\u0005Kz\u001b";
      f[34] = "uo)h@\u000b%ax4=0\u001fS\u000bW\u0001\u0002\u007fw|3V\u000f+s";
      f[35] = " 99'1Eo-;p]\u007fN\u0005\u001a\u001faM.!m{6@z%";
      f[36] = "Y6\u0007/\u0010#\\3O y/0=\u001at\u001d9\f9Hw\u0005C\u000e%L1\u0016 Z \u0007:y";
      f[37] = "7kH\u0010y6`w\rQ\u00038\u000en_\u0012g+2j\r\u0011\u007fQ4s\\P;7ctBW\u0003";
      f[38] = "E\u00045ZX\rV\u00159_(\u001dH\u0016,_\u007fJ\u0017Kw3FHP\u0014.QI\n\u0013\u001c";
      f[39] = "0WL'\u0010G#F@\"`\\1TQ)\fne\u0015\fw`U#UX>\u001eF2Y]N";
      f[40] = "$&M\u0010+\u0002 '[\u0006AW.{N\f\u0016\u0000t+\u0012`p\u0005 .\u0017\u001b?Fw)";
      f[41] = "/3\u001do[\u001a*6U`2\u0015F8\u00004V\u0000z<R7Nzx Vq]\u0019,%\u001dz2";
      f[42] = "faXTQRcd\u0010[8[\u000fjE\u000f\\H3n\u0017\fD21r\u0013JWQewXA8";
      f[43] = "V\u0019\u00170T\u0006\u0006\u0017Fl)\u001f\u0004\u0019\u0005bn\u000fm@E4\u0015\rU\u0007\toBaV\u0019\u00170T\u0006\u0006\u0017Fl)";
      f[44] = "_\\C;\ti^\u0004Q>7{\u0006]P8pko\b\u0011:\u000f8\u0014GRm\b\u0005_\\C;\ti^\u0004Q>7";
      f[45] = "h\u000b\r\u001d>\u0011m\u000eE\u0012W\u001c\u0001\u0000\u0010F3\u000b=\u0004BE+q?\u0018F\u00038\u0012k\u001d\r\bW";
      f[46] = "/\u001f\u001e\u0015x)x\u0003[T\u0002'\u0016\u001a\t\u0017f4*\u001e[\u0014~N(\u0002_Rm-|\u0007\u0014Y\u0002";
      f[47] = "Z\r\u0018cFO_\bPl/E3\u0006\u00058KU\u000f\u0002W;S/\r\u001eS}@LY\u001b\u0018v/";
      f[48] = "nN)5!ko\u0016;0\u001f[\u000fs\n[#ioW}?td;S";
      f[49] = "tm~H;&qh6GR-\u001dfc\u00136<!b1\u0010.F#~5V=%w{~]R";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(286016177578311L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(286016177578311L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(286016177578311L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 192;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 74;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 219;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 114;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 164;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 83;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 192;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 74;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 219;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/E_C0215",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/E" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static String invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = a(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = a(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = b(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding7(int var0, long var1) {
         MethodHandle var7 = bindingCache7;
         MethodHandle var6 = bindingCache7;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache7 = a(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = b(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Class invokeBinding10(long var0, long var2) {
         MethodHandle var8 = bindingCache10;
         MethodHandle var7 = bindingCache10;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache10 = b(MethodHandles.lookup(), "Û", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Double invokeBinding12(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = b(MethodHandles.lookup(), "S", SourceSupport.methodType("(DJJ)Ljava/lang/Double;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Class invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = b(MethodHandles.lookup(), "Û", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Double invokeBinding16(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = b(MethodHandles.lookup(), "S", SourceSupport.methodType("(DJJ)Ljava/lang/Double;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding17(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache17;
         MethodHandle var9 = bindingCache17;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache17 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Class invokeBinding18(long var0, long var2) {
         MethodHandle var8 = bindingCache18;
         MethodHandle var7 = bindingCache18;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache18 = b(MethodHandles.lookup(), "Û", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Double invokeBinding20(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = b(MethodHandles.lookup(), "S", SourceSupport.methodType("(DJJ)Ljava/lang/Double;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding21(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache21;
         MethodHandle var9 = bindingCache21;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache21 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding22(int var0, long var1) {
         MethodHandle var7 = bindingCache22;
         MethodHandle var6 = bindingCache22;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache22 = a(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding23(long var0, long var2) {
         MethodHandle var8 = bindingCache23;
         MethodHandle var7 = bindingCache23;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache23 = b(MethodHandles.lookup(), "Û", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding25(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = b(MethodHandles.lookup(), "S", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding26(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache26;
         MethodHandle var9 = bindingCache26;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache26 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding27(int var0, long var1) {
         MethodHandle var7 = bindingCache27;
         MethodHandle var6 = bindingCache27;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache27 = a(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding28(long var0, long var2) {
         MethodHandle var8 = bindingCache28;
         MethodHandle var7 = bindingCache28;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache28 = b(MethodHandles.lookup(), "Û", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Boolean invokeBinding30(boolean var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = b(MethodHandles.lookup(), "S", SourceSupport.methodType("(ZJJ)Ljava/lang/Boolean;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Boolean)var6.invokeExact((boolean)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding31(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding32(int var0, long var1) {
         MethodHandle var7 = bindingCache32;
         MethodHandle var6 = bindingCache32;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache32 = a(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding34(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache34;
         MethodHandle var9 = bindingCache34;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache34 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MinecraftClient invokeBinding35(long var0, long var2) {
         MethodHandle var8 = bindingCache35;
         MethodHandle var7 = bindingCache35;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache35 = b(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(JJ)Lnet/minecraft/client/MinecraftClient;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MinecraftClient)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientWorld invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = b(
                  MethodHandles.lookup(),
                  "À",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding37(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache37;
         MethodHandle var9 = bindingCache37;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache37 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding38(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache38;
         MethodHandle var9 = bindingCache38;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache38 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = b(MethodHandles.lookup(), "À", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding40(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache40;
         MethodHandle var9 = bindingCache40;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache40 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = b(MethodHandles.lookup(), "À", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding42(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache42;
         MethodHandle var9 = bindingCache42;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache42 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = b(MethodHandles.lookup(), "À", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding44(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache44;
         MethodHandle var9 = bindingCache44;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache44 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding45(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache45;
         MethodHandle var9 = bindingCache45;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache45 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding46(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static DestructionType invokeBinding47(long var0, long var2) {
         MethodHandle var8 = bindingCache47;
         MethodHandle var7 = bindingCache47;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache47 = b(
                  MethodHandles.lookup(),
                  "Û",
                  SourceSupport.methodType("(JJ)Lnet/minecraft/world/explosion/Explosion$DestructionType;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DestructionType)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static void invokeBinding48(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache48;
         MethodHandle var9 = bindingCache48;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache48 = b(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
         } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
