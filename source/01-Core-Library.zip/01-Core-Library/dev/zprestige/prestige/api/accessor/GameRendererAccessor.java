package dev.zprestige.prestige.api.accessor;
import dev.zprestige.prestige.api.reflect.BoundFieldAccessor;
import dev.zprestige.prestige.api.reflect.BoundMethodInvoker;
import dev.zprestige.prestige.api.reflect.ReflectedField;


import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.BufferBuilderStorage;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.Pool;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

public class GameRendererAccessor {
   private final GameRenderer a;
   private static final long b = 22416380579132L;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[26];
   private static final String[] g = new String[26];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;

   public GameRendererAccessor(GameRenderer var1) {
      this.a = var1;
   }

   public void aReturningVoid(Object[] var1) {
      Camera var2 = (Camera)var1[0];
      float var6 = (Float)var1[1];
      Matrix4f var3 = (Matrix4f)var1[2];
      long var4 = (Long)var1[3];
      var4 = 22416380579132L ^ var4;
      long var7 = var4 ^ 26218897384426L;
      long var9 = var4 ^ 50747010956780L;
      BoundMethodInvoker var11 = invokeBinding4(
         new Object[]{
            this.a,
            invokeBinding1(3543, 1416161808607721332L ^ var4),
            GameRenderer.class,
            invokeBinding2(-1647839704661222496L, var4),
            new Class[]{Camera.class, invokeBinding3(-1646068994363287820L, var4), Matrix4f.class},
            var9
         },
         -1646415081153043446L,
         var4
      );
      invokeBinding6(var11, new Object[]{new Object[]{var2, invokeBinding5(var6, -1646453816446615997L, var4), var3}, var7}, -1646228525933445323L, var4);
   }

   public InGameOverlayRenderer aReturningInGameOverlayRenderer(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 22416380579132L ^ var2;
      long var4 = var2 ^ 99948723781387L;
      long var6 = var2 ^ 4356198951652L;
      short var10001 = 16078;
      long var10002 = 4631474412135250683L ^ var2;
      Object[] var9 = new Object[]{this.a, "overlayRenderer", GameRenderer.class, InGameOverlayRenderer.class, var6};
      BoundFieldAccessor var8 = ReflectedField.bReturningbN_C0083(var9);
      Object[] var11 = new Object[]{var4};
      BoundFieldAccessor var10 = var8;
      return (InGameOverlayRenderer)var10.aReturningObject(var11);
   }

   public Pool aReturningPool(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 22416380579132L ^ var2;
      long var4 = var2 ^ 47797322363717L;
      long var6 = var2 ^ 125798786164394L;
      BoundFieldAccessor var8 = invokeBinding8(
         new Object[]{this.a, invokeBinding7(21580, 2813217286433545268L ^ var2), GameRenderer.class, Pool.class, var6}, -7206273554773557406L, var2
      );
      return (Pool)invokeBinding9(var8, new Object[]{var4}, -7206556521693558203L, var2);
   }

   public BufferBuilderStorage aReturningBufferBuilderStorage(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 22416380579132L ^ var2;
      long var4 = var2 ^ 32369929593669L;
      long var6 = var2 ^ 75187021837994L;
      BoundFieldAccessor var8 = invokeBinding11(
         new Object[]{this.a, invokeBinding10(27332, 2773043026685113010L ^ var2), GameRenderer.class, BufferBuilderStorage.class, var6},
         -8359214815832297630L,
         var2
      );
      return (BufferBuilderStorage)invokeBinding12(var8, new Object[]{var4}, -8359493384697390523L, var2);
   }

   public boolean aReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 22416380579132L ^ var2;
      long var4 = var2 ^ 114757778704288L;
      long var6 = var2 ^ 54212171878991L;
      BoundFieldAccessor var8 = invokeBinding15(
         new Object[]{this.a, invokeBinding13(15330, 5519680572599814014L ^ var2), GameRenderer.class, invokeBinding14(-5828798364714138158L, var2), var6},
         -5828942944456471673L,
         var2
      );
      return invokeBinding17((Boolean)invokeBinding16(var8, new Object[]{var4}, -5829795226546897248L, var2), -5829869029239642641L, var2);
   }

   public LightmapTextureManager aReturningLightmapTextureManager(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 22416380579132L ^ var2;
      long var4 = var2 ^ 112905597628142L;
      long var6 = var2 ^ 70087484111617L;
      BoundFieldAccessor var8 = invokeBinding19(
         new Object[]{this.a, invokeBinding18(9851, 8973033957804241828L ^ var2), GameRenderer.class, LightmapTextureManager.class, var6},
         456378374396289737L,
         var2
      );
      return (LightmapTextureManager)invokeBinding20(var8, new Object[]{var4}, 456665463461500910L, var2);
   }

   public Matrix4f aReturningMatrix4f(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      var3 = 22416380579132L ^ var3;
      long var5 = var3 ^ 17670398830664L;
      long var7 = var3 ^ 46101378332238L;
      BoundMethodInvoker var9 = invokeBinding23(
         new Object[]{
            this.a,
            invokeBinding21(23879, 8902414692194790473L ^ var3),
            GameRenderer.class,
            Matrix4f.class,
            new Class[]{invokeBinding22(2487670562147130710L, var3)},
            var7
         },
         2487330590182748072L,
         var3
      );
      return (Matrix4f)invokeBinding25(var9, new Object[]{new Object[]{invokeBinding24(var2, 2487281328040719841L, var3)}, var5}, 2487513297127470231L, var3);
   }

   public float aReturningFloat(Object[] var1) {
      Camera var6 = (Camera)var1[0];
      float var2 = (Float)var1[1];
      boolean var3 = (Boolean)var1[2];
      long var4 = (Long)var1[3];
      var4 = 22416380579132L ^ var4;
      long var7 = var4 ^ 15438086620987L;
      long var9 = var4 ^ 61527825865021L;
      BoundMethodInvoker var11 = invokeBinding30(
         new Object[]{
            this.a,
            invokeBinding26(7513, 225151240639497004L ^ var4),
            GameRenderer.class,
            invokeBinding27(1006243537169871397L, var4),
            new Class[]{Camera.class, invokeBinding28(1006243537169871397L, var4), invokeBinding29(1006199808147760959L, var4)},
            var9
         },
         1006514822809714907L,
         var4
      );
      return invokeBinding34(
         (Float)invokeBinding33(
            var11,
            new Object[]{new Object[]{var6, invokeBinding31(var2, 1006421651067706002L, var4), invokeBinding32(var3, 1006367189251311162L, var4)}, var7},
            1006117127199185892L,
            var4
         ),
         1006299556638514703L,
         var4
      );
   }

   public void bReturningVoid(Object[] var1) {
      MatrixStack var2 = (MatrixStack)var1[0];
      float var3 = (Float)var1[1];
      long var4 = (Long)var1[2];
      var4 = 22416380579132L ^ var4;
      long var6 = var4 ^ 133231378242597L;
      long var8 = var4 ^ 71278159856163L;
      BoundMethodInvoker var10 = invokeBinding38(
         new Object[]{
            this.a,
            invokeBinding35(23903, 8851856482421987381L ^ var4),
            GameRenderer.class,
            invokeBinding36(6264186505918129263L, var4),
            new Class[]{MatrixStack.class, invokeBinding37(6262415863234210107L, var4)},
            var8
         },
         6262726698139081669L,
         var4
      );
      invokeBinding40(var10, new Object[]{new Object[]{var2, invokeBinding39(var3, 6262800703571706252L, var4)}, var6}, 6262260867404300538L, var4);
   }

   public void cReturningVoid(Object[] var1) {
      MatrixStack var3 = (MatrixStack)var1[0];
      float var2 = (Float)var1[1];
      long var4 = (Long)var1[2];
      var4 = 22416380579132L ^ var4;
      long var6 = var4 ^ 48927299806299L;
      long var8 = var4 ^ 23640100584029L;
      BoundMethodInvoker var10 = invokeBinding44(
         new Object[]{
            this.a,
            invokeBinding41(22816, 7457718606111040567L ^ var4),
            GameRenderer.class,
            invokeBinding42(7967018527366421521L, var4),
            new Class[]{MatrixStack.class, invokeBinding43(7968775805229764933L, var4)},
            var8
         },
         7969112478519223227L,
         var4
      );
      invokeBinding46(var10, new Object[]{new Object[]{var3, invokeBinding45(var2, 7969019886617721330L, var4)}, var6}, 7968644860357687428L, var4);
   }

   public HeldItemRenderer aReturningHeldItemRenderer(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 22416380579132L ^ var2;
      long var4 = var2 ^ 50510314433706L;
      long var6 = var2 ^ 128510668880197L;
      BoundFieldAccessor var8 = invokeBinding48(
         new Object[]{this.a, invokeBinding47(26216, 1462552955210330617L ^ var2), GameRenderer.class, HeldItemRenderer.class, var6},
         4904748649707004045L,
         var2
      );
      return (HeldItemRenderer)invokeBinding49(var8, new Object[]{var4}, 4905033033974584746L, var2);
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(6957732331274L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[11];
      String var6 = "'O\u0017Ø\u0002¬B'2LqéoÒ:aDrÄuÖ×\u00165 ºïç\u0006a+Â\u0082Í)\u0091\u0012jy\u00ad\u0010½\\¥\u0089\u0003°g\u0083\u0006ÀåÔüàEê(.JSÔI¦vzx\u0016#\u0015¯×\u0082ÎÑ@\u0083i\u000e\u001c\u00855\u001f9\u001dÚôÚf÷ÊTòYÉæm\u001c\u0010C\u008b¡~ÃCÖtBÊ\u001f =»í_\u0010`\u009f\u009cüO\u0081é[Ùz¡S»÷²\u0017(5^ÔhA\u0082\u009c\\9Iû¦\u0085NÜ\u007f'rØ®0\u0019¥ú\u0017Í#ùêÐ\bQ-¢\u00146½H\u0002ë \u009eøn\u009f\u00990Ò\u0096¸Äd\u001aÎòè°f4\u001c2ý\u0004Feu\u001e7#Å½Võ À}\u001b\u0082sybW«\u0096\u009f\u009a9v\u0005¿Þ¾)Gy<{5pu\u000bº\u007fõJ\u008c(\u0017\u000e\u0090\u000b\u0099\u008ag^\u0006±\u000eu`µ\b÷O{\u0001osÏ\u00813×ÝÆ\u0018¸Oeïjw[Z\u0018\u000e\u0092k";
      int var8 = "'O\u0017Ø\u0002¬B'2LqéoÒ:aDrÄuÖ×\u00165 ºïç\u0006a+Â\u0082Í)\u0091\u0012jy\u00ad\u0010½\\¥\u0089\u0003°g\u0083\u0006ÀåÔüàEê(.JSÔI¦vzx\u0016#\u0015¯×\u0082ÎÑ@\u0083i\u000e\u001c\u00855\u001f9\u001dÚôÚf÷ÊTòYÉæm\u001c\u0010C\u008b¡~ÃCÖtBÊ\u001f =»í_\u0010`\u009f\u009cüO\u0081é[Ùz¡S»÷²\u0017(5^ÔhA\u0082\u009c\\9Iû¦\u0085NÜ\u007f'rØ®0\u0019¥ú\u0017Í#ùêÐ\bQ-¢\u00146½H\u0002ë \u009eøn\u009f\u00990Ò\u0096¸Äd\u001aÎòè°f4\u001c2ý\u0004Feu\u001e7#Å½Võ À}\u001b\u0082sybW«\u0096\u009f\u009a9v\u0005¿Þ¾)Gy<{5pu\u000bº\u007fõJ\u008c(\u0017\u000e\u0090\u000b\u0099\u008ag^\u0006±\u000eu`µ\b÷O{\u0001osÏ\u00813×ÝÆ\u0018¸Oeïjw[Z\u0018\u000e\u0092k"
         .length();
      char var5 = '(';
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = a(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     c = var9;
                     d = new String[11];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "LÅy\u0095^\u009d7IP\u00813ê¨ha\n=æ%û\u0018\u0002\u009e\u001esï-û\u0002\u0090µÚp¹\u0095Ã3ô×WoYøQäbDÉôQ|¸Î\u0093\u0003\u0012\u0010&]Û©\u0012»ÎïgÄÅEv(å ";
                  var8 = "LÅy\u0095^\u009d7IP\u00813ê¨ha\n=æ%û\u0018\u0002\u009e\u001esï-û\u0002\u0090µÚp¹\u0095Ã3ô×WoYøQäbDÉôQ|¸Î\u0093\u0003\u0012\u0010&]Û©\u0012»ÎïgÄÅEv(å "
                     .length();
                  var5 = '8';
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21383;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])e.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/F", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/F_C0269",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/F" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 55;
            yield var16;
         }
         case 2 -> {
            byte var17 = 14;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 16;
            yield var19;
         }
         case 5 -> {
            byte var20 = 35;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 3;
            yield var23;
         }
         case 9 -> {
            byte var24 = 46;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 15;
            yield var26;
         }
         case 12 -> {
            byte var27 = 44;
            yield var27;
         }
         case 13 -> {
            byte var28 = 10;
            yield var28;
         }
         case 14 -> {
            byte var29 = 8;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 30;
            yield var31;
         }
         case 17 -> {
            byte var32 = 33;
            yield var32;
         }
         case 18 -> {
            byte var33 = 50;
            yield var33;
         }
         case 19 -> {
            byte var34 = 24;
            yield var34;
         }
         case 20 -> {
            byte var35 = 59;
            yield var35;
         }
         case 21 -> {
            byte var36 = 41;
            yield var36;
         }
         case 22 -> {
            byte var37 = 60;
            yield var37;
         }
         case 23 -> {
            byte var38 = 4;
            yield var38;
         }
         case 24 -> {
            byte var39 = 31;
            yield var39;
         }
         case 25 -> {
            byte var40 = 21;
            yield var40;
         }
         case 26 -> {
            byte var41 = 25;
            yield var41;
         }
         case 27 -> {
            byte var42 = 57;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 43;
            yield var44;
         }
         case 30 -> {
            byte var45 = 34;
            yield var45;
         }
         case 31 -> {
            byte var46 = 53;
            yield var46;
         }
         case 32 -> {
            byte var47 = 18;
            yield var47;
         }
         case 33 -> {
            byte var48 = 62;
            yield var48;
         }
         case 34 -> {
            byte var49 = 0;
            yield var49;
         }
         case 35 -> {
            byte var50 = 32;
            yield var50;
         }
         case 36 -> {
            byte var51 = 45;
            yield var51;
         }
         case 37 -> {
            byte var52 = 27;
            yield var52;
         }
         case 38 -> {
            byte var53 = 37;
            yield var53;
         }
         case 39 -> {
            byte var54 = 17;
            yield var54;
         }
         case 40 -> {
            byte var55 = 54;
            yield var55;
         }
         case 41 -> {
            byte var56 = 7;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 52;
            yield var58;
         }
         case 44 -> {
            byte var59 = 61;
            yield var59;
         }
         case 45 -> {
            byte var60 = 12;
            yield var60;
         }
         case 46 -> {
            byte var61 = 1;
            yield var61;
         }
         case 47 -> {
            byte var62 = 47;
            yield var62;
         }
         case 48 -> {
            byte var63 = 40;
            yield var63;
         }
         case 49 -> {
            byte var64 = 42;
            yield var64;
         }
         case 50 -> {
            byte var65 = 36;
            yield var65;
         }
         case 51 -> {
            byte var66 = 48;
            yield var66;
         }
         case 52 -> {
            byte var67 = 20;
            yield var67;
         }
         case 53 -> {
            byte var68 = 23;
            yield var68;
         }
         case 54 -> {
            byte var69 = 58;
            yield var69;
         }
         case 55 -> {
            byte var70 = 63;
            yield var70;
         }
         case 56 -> {
            byte var71 = 9;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 6;
            yield var73;
         }
         case 59 -> {
            byte var74 = 26;
            yield var74;
         }
         case 60 -> {
            byte var75 = 11;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 13;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "\u001bvQ,qK\rvTvb\\\u001a=WpnH\u000bz@g%X+";
      f[1] = "\"\u0011i'f$W1b(wk6?i#s1B";
      f[2] = "*'\u0000 9\u001c<'\u0005z*\u000b+l\u0006|&\u001f:+\u0011km\u000f\u000b";
      f[3] = "\u001fs:$<\u000e\u0014|+kT\u000e\u001as8";
      f[4] = "d:~vvoo5o9\u001boo({";
      f[5] = float.class;
      g[5] = "java/lang/Float";
      f[6] = "_\u0019U\u001dUQ*9^\u0012D\u001eK7U\u0019@D?";
      f[7] = "~\bUJf4u\u0007D\u0005\u0007:~\f@_";
      f[8] = "\u0016c\u0014W-\u0005\u0000c\u0011\r>\u0012\u0017(\u0012\u000b2\u0006\u0006o\u0005\u001cy\u0016 ";
      f[9] = "In.`Wk<N%oF$]@.dB~)";
      f[10] = "\u0001\u0005o|m\f\u0017\u0005j&~\u001b\u0000Ni r\u000f\u0011\t~79\u001e+";
      f[11] = "\u007f\fu\u0007fK\n,~\bw\u0004k\"u\u0003s^\u001f";
      f[12] = "UP}\u0018iZ^_lW\u0005YP]n\u0018)";
      f[13] = boolean.class;
      g[13] = "java/lang/Boolean";
      f[14] = "v{\u0002-\u000e\t}t\u0013bv\nu~";
      f[15] = "l\u0013-L\u0003j?\u0007\"Z=\u0006\f4\u000b'\u0006bc\u0002~^\u00041a\t";
      f[16] = "\u0017?\u0017'\ni\u001a1F:ckN*R2${'\u007fF9XpB?H9]\u0015\u0017?\u0017'\ni\u001a1F:c";
      f[17] = "\u0005\u0006Q\fE5G\u0004UIz![\u0001VH$&[\u001bR4FwM]NZ\u001f4\u0004\u000f?";
      f[18] = "\u0003RW|\u001a\t]\u0015C\u0015\nq\\]Bp\n\u000e\u0017\u001fZocH\f\u001c_%\r\u001a\u001cS\u0006\u0015";
      f[19] = "3\u0007Z+\u0012*q\u0005^n-.`\u0003I~j>\t[\fa\u0016!g\u0002O(DP3\u0007Z+\u0012*q\u0005^n-";
      f[20] = "7Fce1\u0012eV,<\u0001\u0015\u000e\u0016\"xd\u0015q]``{|3G\u007fayD~\u001fj`\u0001";
      f[21] = "g\u0014c6\u001bMd\u0003pw \u001aZT!uE\u0019%\u001fcmZpeUju\u001d\u0013$\u0007c} ";
      f[22] = "\n(H1Z6H*Lte\u0010a\u0010k\t^t\u000e&\u001ep\\'\f-";
      f[23] = "1x\u000fXzf<v^E\u0013FPQz (\"?g\u000fY*q=l";
      f[24] = "'.cT\u0018!* 2Iq7p8?A\u0018;I6?Q\u001c]&6=\u0017\u00148f8=\u0012q";
      f[25] = "6duy0Kw6|q\rA\te>yhAv.|aw(44c`u\u0010ylva\r";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(559717555251941L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(559717555251941L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(559717555251941L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 226;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 105;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 81;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 165;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 246;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 253;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 226;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 105;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 81;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/F_C0269",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/F" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static String invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding3(long var0, long var2) {
         MethodHandle var8 = bindingCache3;
         MethodHandle var7 = bindingCache3;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache3 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundMethodInvoker invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding5(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(MethodHandles.lookup(), "ý", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding7(int var0, long var1) {
         MethodHandle var7 = bindingCache7;
         MethodHandle var6 = bindingCache7;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache7 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding13(int var0, long var1) {
         MethodHandle var7 = bindingCache13;
         MethodHandle var6 = bindingCache13;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache13 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = b(MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding18(int var0, long var1) {
         MethodHandle var7 = bindingCache18;
         MethodHandle var6 = bindingCache18;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache18 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding20(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding22(long var0, long var2) {
         MethodHandle var8 = bindingCache22;
         MethodHandle var7 = bindingCache22;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache22 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundMethodInvoker invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding24(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = b(MethodHandles.lookup(), "ý", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding25(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache25;
         MethodHandle var9 = bindingCache25;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache25 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding26(int var0, long var1) {
         MethodHandle var7 = bindingCache26;
         MethodHandle var6 = bindingCache26;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache26 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding27(long var0, long var2) {
         MethodHandle var8 = bindingCache27;
         MethodHandle var7 = bindingCache27;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache27 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding28(long var0, long var2) {
         MethodHandle var8 = bindingCache28;
         MethodHandle var7 = bindingCache28;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache28 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding29(long var0, long var2) {
         MethodHandle var8 = bindingCache29;
         MethodHandle var7 = bindingCache29;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache29 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundMethodInvoker invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding31(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = b(MethodHandles.lookup(), "ý", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Boolean invokeBinding32(boolean var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = b(MethodHandles.lookup(), "ý", SourceSupport.methodType("(ZJJ)Ljava/lang/Boolean;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Boolean)var6.invokeExact((boolean)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding33(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache33;
         MethodHandle var9 = bindingCache33;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache33 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = b(MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding35(int var0, long var1) {
         MethodHandle var7 = bindingCache35;
         MethodHandle var6 = bindingCache35;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache35 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding36(long var0, long var2) {
         MethodHandle var8 = bindingCache36;
         MethodHandle var7 = bindingCache36;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache36 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding37(long var0, long var2) {
         MethodHandle var8 = bindingCache37;
         MethodHandle var7 = bindingCache37;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache37 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundMethodInvoker invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding39(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = b(MethodHandles.lookup(), "ý", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding40(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache40;
         MethodHandle var9 = bindingCache40;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache40 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding41(int var0, long var1) {
         MethodHandle var7 = bindingCache41;
         MethodHandle var6 = bindingCache41;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache41 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding42(long var0, long var2) {
         MethodHandle var8 = bindingCache42;
         MethodHandle var7 = bindingCache42;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache42 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding43(long var0, long var2) {
         MethodHandle var8 = bindingCache43;
         MethodHandle var7 = bindingCache43;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache43 = b(MethodHandles.lookup(), "Q", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundMethodInvoker invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding45(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache45;
         MethodHandle var8 = bindingCache45;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache45 = b(MethodHandles.lookup(), "ý", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding46(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding47(int var0, long var1) {
         MethodHandle var7 = bindingCache47;
         MethodHandle var6 = bindingCache47;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache47 = a(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding48(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = b(
                  MethodHandles.lookup(), "ý", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding49(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache49;
         MethodHandle var9 = bindingCache49;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache49 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
