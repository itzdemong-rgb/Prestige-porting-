package dev.zprestige.prestige.api.accessor;
import dev.zprestige.prestige.api.reflect.BoundFieldAccessor;
import dev.zprestige.prestige.api.reflect.BoundMethodInvoker;
import dev.zprestige.prestige.api.reflect.ReflectedField;



import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.lenni0451.classtransform.mappings.AMapper;
import net.lenni0451.classtransform.utils.mappings.MapRemapper;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.HeldItemRenderer.HandRenderType;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;

public class HeldItemRendererAccessor {
   private final HeldItemRenderer a;
   private static final long b = 35875774684089L;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h;
   private static final Object[] i = new Object[99];
   private static final String[] j = new String[99];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;
   private static volatile MethodHandle bindingCache93;
   private static volatile MethodHandle bindingCache94;
   private static volatile MethodHandle bindingCache95;
   private static volatile MethodHandle bindingCache96;
   private static volatile MethodHandle bindingCache97;
   private static volatile MethodHandle bindingCache98;
   private static volatile MethodHandle bindingCache99;
   private static volatile MethodHandle bindingCache100;
   private static volatile MethodHandle bindingCache101;
   private static volatile MethodHandle bindingCache102;
   private static volatile MethodHandle bindingCache103;
   private static volatile MethodHandle bindingCache104;
   private static volatile MethodHandle bindingCache105;
   private static volatile MethodHandle bindingCache106;
   private static volatile MethodHandle bindingCache107;
   private static volatile MethodHandle bindingCache108;
   private static volatile MethodHandle bindingCache109;
   private static volatile MethodHandle bindingCache110;
   private static volatile MethodHandle bindingCache111;

   public HeldItemRendererAccessor(HeldItemRenderer var1) {
      this.a = var1;
   }

   public void aReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      var3 = 35875774684089L ^ var3;
      long var5 = var3 ^ 34173506952222L;
      long var7 = var3 ^ 63679238370276L;
      short var10001 = 1555;
      long var10002 = 5316545899087767171L ^ var3;
      Object[] var10 = new Object[]{this.a, "equipProgressMainHand", HeldItemRenderer.class, float.class, var7};
      BoundFieldAccessor var9 = ReflectedField.bReturningbN_C0083(var10);
      float var11 = var2;
      Object[] var13 = new Object[]{var11, var5};
      BoundFieldAccessor var12 = var9;
      var12.aReturningVoid(var13);
   }

   public void bReturningVoid(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 35875774684089L ^ var2;
      long var5 = var2 ^ 92831444238090L;
      long var7 = var2 ^ 125966435094768L;
      short var10001 = 9728;
      long var10002 = 4891518079134328207L ^ var2;
      Object[] var10 = new Object[]{this.a, "equipProgressOffHand", HeldItemRenderer.class, float.class, var7};
      BoundFieldAccessor var9 = ReflectedField.bReturningbN_C0083(var10);
      float var11 = var4;
      Object[] var13 = new Object[]{var11, var5};
      BoundFieldAccessor var12 = var9;
      var12.aReturningVoid(var13);
   }

   public float aReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 8908902347471L;
      long var6 = var2 ^ 89108263757600L;
      short var10001 = 24654;
      long var10002 = 7043282383942341662L ^ var2;
      Object[] var9 = new Object[]{this.a, "equipProgressMainHand", HeldItemRenderer.class, float.class, var6};
      BoundFieldAccessor var8 = ReflectedField.bReturningbN_C0083(var9);
      Object[] var11 = new Object[]{var4};
      BoundFieldAccessor var10 = var8;
      Float var12 = (Float)var10.aReturningObject(var11);
      return var12;
   }

   public float bReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 124195823049546L;
      long var6 = var2 ^ 46067659280037L;
      short var10001 = 24928;
      long var10002 = 5771632422513556664L ^ var2;
      Object[] var9 = new Object[]{this.a, "equipProgressOffHand", HeldItemRenderer.class, float.class, var6};
      BoundFieldAccessor var8 = ReflectedField.bReturningbN_C0083(var9);
      Object[] var11 = new Object[]{var4};
      BoundFieldAccessor var10 = var8;
      Float var12 = (Float)var10.aReturningObject(var11);
      return var12;
   }

   public float cReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 110264404355665L;
      long var6 = var2 ^ 67454864392126L;
      BoundFieldAccessor var8 = invokeBinding3(
         new Object[]{this.a, invokeBinding1(19380, 7300838357150066555L ^ var2), HeldItemRenderer.class, invokeBinding2(208246863084092887L, var2), var6},
         214546577680472832L,
         var2
      );
      return invokeBinding5((Float)invokeBinding4(var8, new Object[]{var4}, 214245152439818673L, var2), 214440013455018227L, var2);
   }

   public float dReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 65004245764377L;
      long var6 = var2 ^ 107819171290358L;
      BoundFieldAccessor var8 = invokeBinding8(
         new Object[]{this.a, invokeBinding6(4806, 6900262247480089922L ^ var2), HeldItemRenderer.class, invokeBinding7(7037868639343222431L, var2), var6},
         7039803172377262152L,
         var2
      );
      return invokeBinding10((Float)invokeBinding9(var8, new Object[]{var4}, 7039541294667610873L, var2), 7039556505921694651L, var2);
   }

   public void cReturningVoid(Object[] var1) {
      ItemStack var2 = (ItemStack)var1[0];
      long var3 = (Long)var1[1];
      var3 = 35875774684089L ^ var3;
      long var5 = var3 ^ 30260403393551L;
      long var7 = var3 ^ 67599921036277L;
      short var10001 = 27279;
      long var10002 = 7392510767275442689L ^ var3;
      Object[] var10 = new Object[]{this.a, "mainHand", HeldItemRenderer.class, ItemStack.class, var7};
      BoundFieldAccessor var9 = ReflectedField.bReturningbN_C0083(var10);
      Object[] var12 = new Object[]{var2, var5};
      BoundFieldAccessor var11 = var9;
      var11.aReturningVoid(var12);
   }

   public void dReturningVoid(Object[] var1) {
      ItemStack var4 = (ItemStack)var1[0];
      long var2 = (Long)var1[1];
      var2 = 35875774684089L ^ var2;
      long var5 = var2 ^ 27985003369239L;
      long var7 = var2 ^ 69875325254893L;
      short var10001 = 9557;
      long var10002 = 7696073023057709773L ^ var2;
      Object[] var10 = new Object[]{this.a, "offHand", HeldItemRenderer.class, ItemStack.class, var7};
      BoundFieldAccessor var9 = ReflectedField.bReturningbN_C0083(var10);
      Object[] var12 = new Object[]{var4, var5};
      BoundFieldAccessor var11 = var9;
      var11.aReturningVoid(var12);
   }

   public HandRenderType aReturningHeldItemRenderer_HandRenderType(Object[] var1) {
      ClientPlayerEntity var4 = (ClientPlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 35875774684089L ^ var2;
      String var5 = invokeBinding18(
         invokeBinding13(invokeBinding12(invokeBinding11(8131890854943145773L, var2), 8132138839818162310L, var2), 8130282298090441886L, var2),
         invokeBinding17(
            invokeBinding14(HeldItemRenderer.class, 8131724526740890611L, var2),
            (char)invokeBinding15(978, 3376298300317278634L ^ var2),
            (char)invokeBinding16(14982, 8310582645655771380L ^ var2),
            8132899800145579752L,
            var2
         ),
         8132968351844554021L,
         var2
      );
      String var6 = invokeBinding23(
         invokeBinding21(invokeBinding20(invokeBinding19(8131890854943145773L, var2), 8132138839818162310L, var2), 8130282298090441886L, var2),
         invokeBinding22(HandRenderType.class, new Class[]{ClientPlayerEntity.class}, 8124928539679609354L, var2),
         8133343716333530281L,
         var2
      );
      String var7 = invokeBinding27(
         invokeBinding25(invokeBinding24(8131890854943145773L, var2), 8132138839818162310L, var2),
         var5,
         invokeBinding26(24662, 917782635495898813L ^ var2),
         var6,
         8131293757682825420L,
         var2
      );

      try {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

         dev.prestige.recovery.SourceSupport.<IllegalAccessException>checkedBoundary();

         dev.prestige.recovery.SourceSupport.<InvocationTargetException>checkedBoundary();

         Method var8 = invokeBinding28(HeldItemRenderer.class, var7, new Class[]{ClientPlayerEntity.class}, 8131746095530832418L, var2);
         invokeBinding29(var8, true, 8125337961160495276L, var2);
         return (HandRenderType)invokeBinding30(var8, null, new Object[]{var4}, 8132804049717087530L, var2);
      } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException var12) {
         throw new RuntimeException(var12);
      }
   }

   public ItemStack aReturningItemStack(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 94871573350653L;
      long var6 = var2 ^ 16872308219154L;
      BoundFieldAccessor var8 = invokeBinding32(
         new Object[]{this.a, invokeBinding31(17352, 110124481431440804L ^ var2), HeldItemRenderer.class, ItemStack.class, var6}, -2281624100233184852L, var2
      );
      return (ItemStack)invokeBinding33(var8, new Object[]{var4}, -2281894729743549667L, var2);
   }

   public void eReturningVoid(Object[] var1) {
      AbstractClientPlayerEntity var4 = (AbstractClientPlayerEntity)var1[0];
      float var11 = (Float)var1[1];
      float var13 = (Float)var1[2];
      Hand var5 = (Hand)var1[3];
      float var10 = (Float)var1[4];
      ItemStack var9 = (ItemStack)var1[5];
      float var3 = (Float)var1[6];
      MatrixStack var6 = (MatrixStack)var1[7];
      VertexConsumerProvider var2 = (VertexConsumerProvider)var1[8];
      int var12 = (Integer)var1[9];
      long var7 = (Long)var1[10];
      var7 = 35875774684089L ^ var7;
      long var14 = var7 ^ 137554986714559L;
      long var16 = var7 ^ 75749826616249L;
      HeldItemRenderer var10000 = this.a;
      String var10001 = invokeBinding34(14597, 8364912937881835615L ^ var7);
      Class[] var10004 = new Class[invokeBinding35(1052, 2935856408782887387L ^ var7)];
      var10004[0] = ClientPlayerEntity.class;
      var10004[1] = invokeBinding36(-8107631838938795953L, var7);
      var10004[2] = invokeBinding37(-8107631838938795953L, var7);
      var10004[3] = Hand.class;
      var10004[4] = invokeBinding38(-8107631838938795953L, var7);
      var10004[5] = ItemStack.class;
      var10004[invokeBinding39(25185, 4788247945362948003L ^ var7)] = invokeBinding40(-8107631838938795953L, var7);
      var10004[invokeBinding41(3421, 7334835239818907804L ^ var7)] = MatrixStack.class;
      var10004[invokeBinding42(22203, 703179211302800241L ^ var7)] = VertexConsumerProvider.class;
      var10004[invokeBinding43(16664, 6051801244268764381L ^ var7)] = invokeBinding44(-8115337505162940942L, var7);
      BoundMethodInvoker var18 = invokeBinding45(new Object[]{var10000, var10001, HeldItemRenderer.class, Void.class, var10004, var16}, -8108647745822831973L, var7);
      Object[] var20 = new Object[invokeBinding46(15981, 5955496265154454437L ^ var7)];
      var20[0] = var4;
      var20[1] = invokeBinding47(var11, -8113678576871891289L, var7);
      var20[2] = invokeBinding48(var13, -8113678576871891289L, var7);
      var20[3] = var5;
      var20[4] = invokeBinding49(var10, -8113678576871891289L, var7);
      var20[5] = var9;
      var20[invokeBinding50(519, 5110640258482298823L ^ var7)] = invokeBinding51(var3, -8113678576871891289L, var7);
      var20[invokeBinding52(18073, 7416769477360261970L ^ var7)] = var6;
      var20[invokeBinding53(15438, 6911595465567854986L ^ var7)] = var2;
      var20[invokeBinding54(19686, 3260772150663876896L ^ var7)] = invokeBinding55(var12, -8114461325246898213L, var7);
      invokeBinding56(var18, new Object[]{var20, var14}, -8114533834212173817L, var7);
   }

   public ItemStack bReturningItemStack(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 62484061572912L;
      long var6 = var2 ^ 107500176579295L;
      BoundFieldAccessor var8 = invokeBinding58(
         new Object[]{this.a, invokeBinding57(3708, 1395123060766984148L ^ var2), HeldItemRenderer.class, ItemStack.class, var6}, 7465671192729878113L, var2
      );
      return (ItemStack)invokeBinding59(var8, new Object[]{var4}, 7464850833715903696L, var2);
   }

   public float eReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 93457444496128L;
      long var6 = var2 ^ 15318543644399L;
      BoundFieldAccessor var8 = invokeBinding62(
         new Object[]{this.a, invokeBinding60(28764, 7780017334575437257L ^ var2), HeldItemRenderer.class, invokeBinding61(-3768695005995617146L, var2), var6},
         -3770911127982353839L,
         var2
      );
      return invokeBinding64((Float)invokeBinding63(var8, new Object[]{var4}, -3771740071025798944L, var2), -3771508804693458526L, var2);
   }

   public float fReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 35875774684089L ^ var2;
      long var4 = var2 ^ 91384072066544L;
      long var6 = var2 ^ 11048312274975L;
      BoundFieldAccessor var8 = invokeBinding67(
         new Object[]{this.a, invokeBinding65(12587, 3247562637099590215L ^ var2), HeldItemRenderer.class, invokeBinding66(9026023163421983350L, var2), var6},
         9032830709767333025L,
         var2
      );
      return invokeBinding69((Float)invokeBinding68(var8, new Object[]{var4}, 9031988299841283600L, var2), 9032232229867992914L, var2);
   }

    public void fReturningVoid(Object[] objectArray) {
        block14: {
            float f;
            float f10;
            float f11;
            float f12;
            long l;
            long l2;
            long l3;
            long l4;
            long l5;
            int n;
            ClientPlayerEntity clientPlayerEntity;
            VertexConsumerProvider vertexConsumerProvider;
            MatrixStack matrixStack;
            float f13;
            block16: {
                block15: {
                    boolean bl;
                    Hand hand;
                    float f14;
                    block10: {
                        HeldItemRenderer.HandRenderType handRenderType;
                        block11: {
                            float f15;
                            long l6;
                            long l7;
                            long l8;
                            block13: {
                                block12: {
                                    f13 = ((Float)objectArray[0]).floatValue();
                                    matrixStack = (MatrixStack)objectArray[1];
                                    vertexConsumerProvider = (VertexConsumerProvider)objectArray[2];
                                    clientPlayerEntity = (ClientPlayerEntity)objectArray[3];
                                    n = (Integer)objectArray[4];
                                    l5 = (Long)objectArray[5];
                                    long l9 = l5 = 0x20A0FACE5BB9L ^ l5;
                                    l4 = l9 ^ 0x77D8A775D75BL;
                                    long l10 = l9 ^ 0x611F86D6D463L;
                                    l8 = l9 ^ 0x53D3F1586F11L;
                                    l7 = l9 ^ 0x516532F244ECL;
                                    l3 = l9 ^ 0x3FF804D4C321L;
                                    l6 = l9 ^ 0xF36736A3EDEL;
                                    l2 = l9 ^ 0x53C39BE82BD8L;
                                    l = l9 ^ 0x543133B8D9E1L;
                                    f14 = HeldItemRendererAccessor.invokeBinding70(clientPlayerEntity, f13, -64617547952741218L, l5);
                                    hand = (Hand)HeldItemRendererAccessor.invokeBinding74(HeldItemRendererAccessor.invokeBinding72(clientPlayerEntity, -70127284834608261L, l5), HeldItemRendererAccessor.invokeBinding73(-69982098648233827L, l5), -64690027700675847L, l5);
                                    int n2 = HeldItemRendererAccessor.invokeBinding71(-70716655813508278L, l5);
                                    f12 = HeldItemRendererAccessor.invokeBinding75(clientPlayerEntity, f13, -71765399931910589L, l5);
                                    Object[] objectArray2 = new Object[2];
                                    objectArray2[1] = l10;
                                    objectArray2[0] = clientPlayerEntity;
                                    handRenderType = HeldItemRendererAccessor.invokeBinding76(this, objectArray2, -64940660633675342L, l5);
                                    float f16 = HeldItemRendererAccessor.invokeBinding79(f13, HeldItemRendererAccessor.invokeBinding77(clientPlayerEntity, -65183076841563705L, l5), HeldItemRendererAccessor.invokeBinding78(clientPlayerEntity, -64802680061836713L, l5), -64275618098344961L, l5);
                                    float f17 = HeldItemRendererAccessor.invokeBinding82(f13, HeldItemRendererAccessor.invokeBinding80(clientPlayerEntity, -64378970238291519L, l5), HeldItemRendererAccessor.invokeBinding81(clientPlayerEntity, -70532118274121541L, l5), -64275618098344961L, l5);
                                    try {
                                        try {
                                            try {
                                                HeldItemRendererAccessor.invokeBinding86(matrixStack, HeldItemRendererAccessor.invokeBinding85(HeldItemRendererAccessor.invokeBinding83(-65301696934571609L, l5), (HeldItemRendererAccessor.invokeBinding84(clientPlayerEntity, f13, -71295843269837705L, l5) - f16) * 0.1f, -64822581989438179L, l5), -64407564430012840L, l5);
                                                HeldItemRendererAccessor.invokeBinding90(matrixStack, HeldItemRendererAccessor.invokeBinding89(HeldItemRendererAccessor.invokeBinding87(-64491390918186220L, l5), (HeldItemRendererAccessor.invokeBinding88(clientPlayerEntity, f13, -70282684594864725L, l5) - f17) * 0.1f, -64822581989438179L, l5), -64407564430012840L, l5);
                                                bl = HeldItemRendererAccessor.invokeBinding91(handRenderType, -71206020266586534L, l5);
                                                if (n2 != 0) break block10;
                                                if (!bl) break block11;
                                            }
                                            catch (RuntimeException runtimeException) {
                                                throw HeldItemRendererAccessor.invokeBinding92(runtimeException, -70214824975603148L, l5);
                                            }
                                            if (hand != HeldItemRendererAccessor.invokeBinding93(-69982098648233827L, l5)) break block12;
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw HeldItemRendererAccessor.invokeBinding94(runtimeException, -70214824975603148L, l5);
                                        }
                                        f15 = f14;
                                        break block13;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw HeldItemRendererAccessor.invokeBinding95(runtimeException, -70214824975603148L, l5);
                                    }
                                }
                                f15 = 0.0f;
                            }
                            f11 = f15;
                            Object[] objectArray3 = new Object[1];
                            objectArray3[0] = l8;
                            Object[] objectArray4 = new Object[1];
                            objectArray4[0] = l6;
                            f10 = 1.0f - HeldItemRendererAccessor.invokeBinding98(f13, HeldItemRendererAccessor.invokeBinding96(this, objectArray3, -70772020871012861L, l5), HeldItemRendererAccessor.invokeBinding97(this, objectArray4, -71782763199213758L, l5), -64275618098344961L, l5);
                            Object[] objectArray5 = new Object[1];
                            objectArray5[0] = l7;
                            Object[] objectArray6 = new Object[11];
                            objectArray6[10] = l2;
                            objectArray6[9] = n;
                            objectArray6[8] = vertexConsumerProvider;
                            objectArray6[7] = matrixStack;
                            objectArray6[6] = Float.valueOf(f10);
                            objectArray6[5] = HeldItemRendererAccessor.invokeBinding100(this, objectArray5, -70862323765810854L, l5);
                            objectArray6[4] = Float.valueOf(f11);
                            objectArray6[3] = HeldItemRendererAccessor.invokeBinding99(-69982098648233827L, l5);
                            objectArray6[2] = Float.valueOf(f12);
                            objectArray6[1] = Float.valueOf(f13);
                            objectArray6[0] = clientPlayerEntity;
                            HeldItemRendererAccessor.invokeBinding101(this, objectArray6, -68041009625382344L, l5);
                        }
                        bl = HeldItemRendererAccessor.invokeBinding102(handRenderType, -70375793005036050L, l5);
                    }
                    try {
                        try {
                            if (!bl) break block14;
                            if (hand != HeldItemRendererAccessor.invokeBinding103(-70358276558902046L, l5)) break block15;
                        }
                        catch (RuntimeException runtimeException) {
                            throw HeldItemRendererAccessor.invokeBinding104(runtimeException, -70214824975603148L, l5);
                        }
                        f = f14;
                        break block16;
                    }
                    catch (RuntimeException runtimeException) {
                        throw HeldItemRendererAccessor.invokeBinding105(runtimeException, -70214824975603148L, l5);
                    }
                }
                f = 0.0f;
            }
            f11 = f;
            Object[] objectArray7 = new Object[1];
            objectArray7[0] = l;
            Object[] objectArray8 = new Object[1];
            objectArray8[0] = l4;
            f10 = 1.0f - HeldItemRendererAccessor.invokeBinding108(f13, HeldItemRendererAccessor.invokeBinding106(this, objectArray7, -71587997519499136L, l5), HeldItemRendererAccessor.invokeBinding107(this, objectArray8, -70446773614564423L, l5), -64275618098344961L, l5);
            Object[] objectArray9 = new Object[1];
            objectArray9[0] = l3;
            Object[] objectArray10 = new Object[11];
            objectArray10[10] = l2;
            objectArray10[9] = n;
            objectArray10[8] = vertexConsumerProvider;
            objectArray10[7] = matrixStack;
            objectArray10[6] = Float.valueOf(f10);
            objectArray10[5] = HeldItemRendererAccessor.invokeBinding110(this, objectArray9, -65022663470042765L, l5);
            objectArray10[4] = Float.valueOf(f11);
            objectArray10[3] = HeldItemRendererAccessor.invokeBinding109(-70358276558902046L, l5);
            objectArray10[2] = Float.valueOf(f12);
            objectArray10[1] = Float.valueOf(f13);
            objectArray10[0] = clientPlayerEntity;
            HeldItemRendererAccessor.invokeBinding111(this, objectArray10, -68041009625382344L, l5);
        }
    }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(85417108990032L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[14];
      String var17 = "l¯´ÒZ¾q\u009d\u009b\u0093\nN\\\u0098vÓz\u00861§w\u007fÅéÎ0;KÒòQQÓ¿\u009bKÜÚ\u000b\r\u0010\u008a¿ç\u0093{+©1óõ\u0090T®õ\u0096×(\u0014\bi®öi\u0081\u00040ß\u0095CÕým\bòâ\u0087\u001c7ðe(ãç\u0096fózÄÑµ¸\u001a\u001f ±\u000f\"\u0010\u0010Aå\u007f\u0098<ª\u008eã«Q£cµ¦c8ä\u0001B¦Ç\u009eÁËLÎl;@áVÍbüï+\u0005B\be2Ñ\u001bEä\u001bBE\u001f~u\u000fQ\u009eñ..Ú%\u0080®ï¸\u0018I\u0088,l9ù\u0086Ì8ï\u008d\u0002\u0013å ÖÌi¼m\u0096¬uï\u001a^áãÌe×+ÐX\u008eb\u001d<#(üú\u0000\u0080ãq\u0080ê¯iW\u0016b\u009e\u0012ÆÌ\f©\u0092bPh÷¿(V¸% A&ß\u0015\u0014Ë\u000f\u0013cï\u0019O\u0016<laÉ#ùû\u0007w\u0016A\u001b\u0085H¨s¸j\u007f\u0089\u0012±$8uþ£\u0013\u0084uË+éw:¬ã©\u0015\u0085e_Ø\u0084ÜÚh×x\u0098¶ÀK¾\u000b\u0015\u000e\u009bZÊr\u001fû){\t\u009c\u0018¿*\u0097\u008b\u0014UùÃO}\u0007õ x\u0095\u0019\u0094\u0014\u0094\u009aQ'eD\u0095x4\u0014çisª·Þt\bOj\u009bà!L\u009f¥å ªBÌ\"¦$µ\u001fåÙ\u009fÔ¸yK\u009f¡ù\u0017\u000b[J\u0090¡Ðô]ög\u0093y©(\u0015\u0082*ÒÃ)VdL<úb\u0098/Û\u0018~\rúÈý®\u0001òLËÁël4¶\u0090\u0093\u0087}.Êq:Ë(3\u007fìûl\u0098ÃÜÌå\bÊÑûÈÀ±c\u0082yç\u0093Z6(ãsç\u009b\u0013Wã:\u001bÈ \"\u0005O\u0091";
      int var19 = "l¯´ÒZ¾q\u009d\u009b\u0093\nN\\\u0098vÓz\u00861§w\u007fÅéÎ0;KÒòQQÓ¿\u009bKÜÚ\u000b\r\u0010\u008a¿ç\u0093{+©1óõ\u0090T®õ\u0096×(\u0014\bi®öi\u0081\u00040ß\u0095CÕým\bòâ\u0087\u001c7ðe(ãç\u0096fózÄÑµ¸\u001a\u001f ±\u000f\"\u0010\u0010Aå\u007f\u0098<ª\u008eã«Q£cµ¦c8ä\u0001B¦Ç\u009eÁËLÎl;@áVÍbüï+\u0005B\be2Ñ\u001bEä\u001bBE\u001f~u\u000fQ\u009eñ..Ú%\u0080®ï¸\u0018I\u0088,l9ù\u0086Ì8ï\u008d\u0002\u0013å ÖÌi¼m\u0096¬uï\u001a^áãÌe×+ÐX\u008eb\u001d<#(üú\u0000\u0080ãq\u0080ê¯iW\u0016b\u009e\u0012ÆÌ\f©\u0092bPh÷¿(V¸% A&ß\u0015\u0014Ë\u000f\u0013cï\u0019O\u0016<laÉ#ùû\u0007w\u0016A\u001b\u0085H¨s¸j\u007f\u0089\u0012±$8uþ£\u0013\u0084uË+éw:¬ã©\u0015\u0085e_Ø\u0084ÜÚh×x\u0098¶ÀK¾\u000b\u0015\u000e\u009bZÊr\u001fû){\t\u009c\u0018¿*\u0097\u008b\u0014UùÃO}\u0007õ x\u0095\u0019\u0094\u0014\u0094\u009aQ'eD\u0095x4\u0014çisª·Þt\bOj\u009bà!L\u009f¥å ªBÌ\"¦$µ\u001fåÙ\u009fÔ¸yK\u009f¡ù\u0017\u000b[J\u0090¡Ðô]ög\u0093y©(\u0015\u0082*ÒÃ)VdL<úb\u0098/Û\u0018~\rúÈý®\u0001òLËÁël4¶\u0090\u0093\u0087}.Êq:Ë(3\u007fìûl\u0098ÃÜÌå\bÊÑûÈÀ±c\u0082yç\u0093Z6(ãsç\u009b\u0013Wã:\u001bÈ \"\u0005O\u0091"
         .length();
      char var16 = '(';
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = a(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     c = var20;
                     d = new String[14];
                     h = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(85417108990032L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[12];
                     String var4 = "£\u0094\u0083¿Ú¯\u0087\u0003}\u00adÅ½\u009döÅ\u0007\u0016BU^béA\u0007\fÌ!\fïÀ§ùÄPÚ¬%µáÌèE_\u009fÅ\u001d\u0084\u008c\r\u009dÊ.ÏªçÜÒ(\u008e^òµß¶ü¶¶¿¾Eø\u0095\u009e±7\u009d&¢OØ";
                     int var5 = "£\u0094\u0083¿Ú¯\u0087\u0003}\u00adÅ½\u009döÅ\u0007\u0016BU^béA\u0007\fÌ!\fïÀ§ùÄPÚ¬%µáÌèE_\u009fÅ\u001d\u0084\u008c\r\u009dÊ.ÏªçÜÒ(\u008e^òµß¶ü¶¶¿¾Eø\u0095\u009e±7\u009d&¢OØ"
                        .length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    f = var6;
                                    g = new Integer[12];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0093a¬[CJ\u0006k'.aCä½ÂI";
                                 var5 = "\u0093a¬[CJ\u0006k'.aCä½ÂI".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "ôè·\u0000ºÒw\u0098ü£1YÈK\u0019 Ï×L\u008cídS\u00153uq\u0092pív\u0003\u0011×Æ¥\u0010öÞ*¯NQêªÑ1I 2\u0096è\u0019¤°är_ùÒ\u00ad 37\u0018±\u0004,|Ú~Ë\f\u008f¬#ÿ¦þÇ÷";
                  var19 = "ôè·\u0000ºÒw\u0098ü£1YÈK\u0019 Ï×L\u008cídS\u00153uq\u0092pív\u0003\u0011×Æ¥\u0010öÞ*¯NQêªÑ1I 2\u0096è\u0019¤°är_ùÒ\u00ad 37\u0018±\u0004,|Ú~Ë\f\u008f¬#ÿ¦þÇ÷"
                     .length();
                  var16 = '0';
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11815;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])e.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/K", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/K_C0421",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/K" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21174;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/K", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/K_C0421",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/K" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 52;
            yield var15;
         }
         case 1 -> {
            byte var16 = 5;
            yield var16;
         }
         case 2 -> {
            byte var17 = 31;
            yield var17;
         }
         case 3 -> {
            byte var18 = 40;
            yield var18;
         }
         case 4 -> {
            byte var19 = 12;
            yield var19;
         }
         case 5 -> {
            byte var20 = 9;
            yield var20;
         }
         case 6 -> {
            byte var21 = 46;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 17;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 44;
            yield var27;
         }
         case 13 -> {
            byte var28 = 20;
            yield var28;
         }
         case 14 -> {
            byte var29 = 7;
            yield var29;
         }
         case 15 -> {
            byte var30 = 8;
            yield var30;
         }
         case 16 -> {
            byte var31 = 11;
            yield var31;
         }
         case 17 -> {
            byte var32 = 58;
            yield var32;
         }
         case 18 -> {
            byte var33 = 23;
            yield var33;
         }
         case 19 -> {
            byte var34 = 34;
            yield var34;
         }
         case 20 -> {
            byte var35 = 26;
            yield var35;
         }
         case 21 -> {
            byte var36 = 47;
            yield var36;
         }
         case 22 -> {
            byte var37 = 61;
            yield var37;
         }
         case 23 -> {
            byte var38 = 24;
            yield var38;
         }
         case 24 -> {
            byte var39 = 63;
            yield var39;
         }
         case 25 -> {
            byte var40 = 10;
            yield var40;
         }
         case 26 -> {
            byte var41 = 59;
            yield var41;
         }
         case 27 -> {
            byte var42 = 57;
            yield var42;
         }
         case 28 -> {
            byte var43 = 33;
            yield var43;
         }
         case 29 -> {
            byte var44 = 4;
            yield var44;
         }
         case 30 -> {
            byte var45 = 21;
            yield var45;
         }
         case 31 -> {
            byte var46 = 15;
            yield var46;
         }
         case 32 -> {
            byte var47 = 50;
            yield var47;
         }
         case 33 -> {
            byte var48 = 37;
            yield var48;
         }
         case 34 -> {
            byte var49 = 22;
            yield var49;
         }
         case 35 -> {
            byte var50 = 45;
            yield var50;
         }
         case 36 -> {
            byte var51 = 55;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 1;
            yield var53;
         }
         case 39 -> {
            byte var54 = 2;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 41;
            yield var56;
         }
         case 42 -> {
            byte var57 = 6;
            yield var57;
         }
         case 43 -> {
            byte var58 = 29;
            yield var58;
         }
         case 44 -> {
            byte var59 = 25;
            yield var59;
         }
         case 45 -> {
            byte var60 = 36;
            yield var60;
         }
         case 46 -> {
            byte var61 = 51;
            yield var61;
         }
         case 47 -> {
            byte var62 = 54;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 30;
            yield var64;
         }
         case 50 -> {
            byte var65 = 13;
            yield var65;
         }
         case 51 -> {
            byte var66 = 62;
            yield var66;
         }
         case 52 -> {
            byte var67 = 60;
            yield var67;
         }
         case 53 -> {
            byte var68 = 42;
            yield var68;
         }
         case 54 -> {
            byte var69 = 16;
            yield var69;
         }
         case 55 -> {
            byte var70 = 18;
            yield var70;
         }
         case 56 -> {
            byte var71 = 53;
            yield var71;
         }
         case 57 -> {
            byte var72 = 43;
            yield var72;
         }
         case 58 -> {
            byte var73 = 27;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 35;
            yield var75;
         }
         case 61 -> {
            byte var76 = 49;
            yield var76;
         }
         case 62 -> {
            byte var77 = 38;
            yield var77;
         }
         default -> 3;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "\u001c~65MF\n~3o^Q\u001d50iRE\fr'~\u0019U*";
      i[1] = "%{*i\u0017\u001dP[!f\u0006R1U*m\u0002\bE";
      i[2] = "\u0007\u0002\u001fT\r\u001d\u0011\u0002\u001a\u000e\u001e\n\u0006I\u0019\b\u0012\u001e\u0017\u000e\u000e\u001fY\u000f-";
      i[3] = "v\u0014Zp U}\u001bK?HUs\u0014X";
      i[4] = "O$?#\u0015!D+.lx!D6:";
      i[5] = " N\u001dT\u00052Un\u0016[\u0014}4`\u001dP\u0010'@";
      i[6] = "\\y\u0019=\tpWv\brh~\\}\f(";
      i[7] = float.class;
      j[7] = "java/lang/Float";
      i[8] = "k *l\u0015\f\u001e\u0000!c\u0004C\u007f\u000e*h\u0000\u0019\u000b";
      i[9] = void.class;
      j[9] = "java/lang/Void";
      i[10] = ")\u0019Jk]X)\u0019]7QW3R])QB4#\tq\u0006";
      i[11] = "f\r-w=Cj\u0005,<tOj\u000f-64\u0002g\u00033<taj\u0010%\u00168F`\u00014*";
      i[12] = "\u0002=3c\u0007:\u0014=69\u0014-\u0003v5?\u00189\u00121\"(S\u0001";
      i[13] = "C5~u\u0019\\6\u0015uz\b\u0013W\u001b~q\fI#";
      i[14] = "\u0016D\u0003CFb\u0016D\u0014\u001fJm\f\u000f\u0014\u0001Jx\u000b~FZ\u00122";
      i[15] = "q\u000f\\K\u007f2g\u000fY\u0011l%pDZ\u0017`1a\u0003M\u0000+#P";
      i[16] = int.class;
      j[16] = "java/lang/Integer";
      i[17] = "\u0010-2Z{\u001ce\r9UjS\u0004\u00032^n\tp";
      i[18] = "\u00044[PNp\u00044L\fB\u007f\u001e\u007fL\u0012Bj\u0019\u000e\u0018F\u0010*";
      i[19] = "wn\u0005d%Xwn\u00128)Wm%\u0012&)BjTF\u007fq\u0015zg\u00109;n,<Fy";
      i[20] = boolean.class;
      j[20] = "java/lang/Boolean";
      i[21] = "\u001d^\u0000sI\u001fh~\u000b|XP\tp\u0000w\\\n}";
      i[22] = "yPz@`.yPm\u001cl!c\u001bm\u0002l4dj:[5p";
      i[23] = "+(~\u001b;2)67d$<0?k[82*<z";
      i[24] = "B4\u0014\u0003\u0003?B4\u0003_\u000f0X\u007f\u0003A\u000f%_\u000eS\u0018]d";
      i[25] = "s/E\u001c&X\u0006\u000fN\u00137\u0017g\u0001E\u00183M\u0013";
      i[26] = "rl.AeJ\u0007L%Nt\u0005fB.Ep_\u0012";
      i[27] = "cqu,\u0019qao<S\u0006\u007fxf`l\u001aqbe";
      i[28] = "4:W#B]4:@\u007fNR.q@aNG)\u0000\u0012?\u0019\f";
      i[29] = "<S\tJ8iIs\u0002E)&(}\tN-|\\";
      i[30] = "s#W\u001b\u0005\u0000x,FTy\u0019w6H\u0017N)a!D\n_\u0005v,";
      i[31] = "G<*\"?U2\u001c!-.\u001aS\u0012*&*@'";
      i[32] = "\nqS\u0004\u001bL\u007fQX\u000b\n\u0003\u001e_S\u0000\u000eYj";
      i[33] = "vv\tV\u0004]}y\u0018\u0019c_hr\u0018RX";
      i[34] = "Wyo*\u0005ZAyjp\u0016MV2iv\u001aYGu~aQIg";
      i[35] = "!M&\u0010_ETm-\u001fN\n5c&\u0014JPA";
      i[36] = "LxW\u001fAiZxRER~M3QC^j\\tFT\u0015zm";
      i[37] = "+R|k\u0013k^rwd\u0002$?||o\u0006~K";
      i[38] = "*\f,-?q!\u0003=bBi2\u00044+";
      i[39] = char.class;
      j[39] = "java/lang/Character";
      i[40] = "\u0018\u00181\u0003}\u0002\u0018\u0013,\u001d%RGS&Ap\u0014\u0005\t7L\u007f\u0014\u0010\u00127@?\u0012\u0002\u0014)^?\n\u0017\r5D\u007f\u0000\u0005S\bLa5\u0013\u0010$]a\u0002\u0004";
      i[41] = ";\t\u000f/*v0\u0006\u001e`v\u007f7\u0004\u001c-p4\u001c\r\r&k~";
      i[42] = "/EK\u001a\u0002?Ze@\u0015\u0013p7e@\b\u0007e";
      i[43] = "Zw\u001c\u0002F]Z|\u0001\u001c\u001e\r\u0005<\u000b@KKGf\u001aMDKR}\u001aA\u0004lFs\u0006_LWF\u007f\r^gYZs\u000fIX";
      i[44] = "SU\";d\u001cS^?%<L\f\u001e5yi\nND$tf\n[_$x&\u0014\\@&|f\u001eN\u001e\u0017Xi\tMU$";
      i[45] = "F];\u00165+FV&\bm{\u0019\u0016,T8=[L=Y7=NW=Uw;\\Q#Kw\u000f{u\u001aL0\"[";
      i[46] = "8#JL?\u0016M\u0003AC.Y \u0003A^:L";
      i[47] = "hW\b3\u001ez\u001dw\u0003<\u000f5|y\b7\u000bo\b";
      i[48] = "\"t#w!\u0002x|!3\u0010\u0004pk9+|6#/dq\u0010\\}k'.(\n!n<L-\u0001ai;t{]drY";
      i[49] = "Z\u007f\u0016&G`T{[\"<>\u000b=\u001f$z7\f\u0001\u0019<XPV)\u0003\"[5\u0000:\r<<l\u0004 \u001e?Y:\u0017.\u0000X\u0000>\r=\u0003=V-\u0003#d";
      i[50] = "D<-307Rt!?\u000b;N y6\\i\u0017r$d\u000b>^}tai(\u0016qx";
      i[51] = "csK<1c9eO!SA\bRbFh%ezTv.e`{";
      i[52] = "C0='D\\\u00198?cuQ\u001d>#p\"\u0004Mh~\u001cH_\u0000-%$\u001e\u0003\u00056";
      i[53] = "[GHY8\u0005I\u001e\u0016OCZX]KC/h\u000f\u001b\u001a\u001c|?ZEZA$G^^U\u0018C\u0001^AL_ \u0005SDU$";
      i[54] = "m,I{BD#?\u0018u ]t\u0019\u001e`K[r-\u000f|Z!(mOk[\u0011n-Jj ^qn\u0017cJO|9\u000b\u001bYB}$L*EAh)s";
      i[55] = "C33MR_G.5M1TA64V]f\u0015th\n\u00001\u0011*(OS\tGv-T1\fL6*S\tZ\u0010311\fQP46\tZ\rU/T\fQMR(lZ\rHIJ";
      i[56] = "{y~R\u0017Y!q|\u0016&T%w`\u0005q\u0001u#8i\u001bZ8dfQM\u0006=\u007f";
      i[57] = "\u0006'\u0005\u001c`M\u0010o\t\u0010[A\f;Q\u0019\f\u0013Ui\fI[D\u001cf\\N9RTjP";
      i[58] = "\u001d\u0000\u0015W|\u0000F\u000f\u0019\r\u0013\u0006-\u0015\u0017\u000fz\u0010N\u0013\u0018\u001emlDS\t\u0000x\u0015R\rL\u0010\u0013";
      i[59] = "oq1\\\t'ep \u000f8#yp\u0016YS5ow>X\\5\u0014ao\u0003Z6w78M\u0004X*g?UC;.j:L8";
      i[60] = "{}}1r\b rqk\u001d\rKh\u007fit\u0018(npxcd'lz{d_&+'5\u001d";
      i[61] = "0QH\u0015\u0018af\\OL{5W\u001eVH\u0012 4\u0018YY\u0005\\/\nO\u0011\u0002l'\u001f\tS{";
      i[62] = "-H'yUXw@%=dUsF9.3\u0000#\u0012cBY[nU?z\u000f\u0007kN";
      i[63] = "H\u0018T8\u001b%^PX4 =D\u0015\r-A E%\t>Z*N\u0012dl@;]\u000b\\:\u001c>Fi\u0005+B9JX\u001c6M{#";
      i[64] = "/\u001bGGMGu\u0013E\u0003|A}\u0004]\u001b\u0010s-G\u0005A|\u0019p\u0004C\u001eDO,\u0001X|ADl\u0006_D\u0017\u0018i\u001d=";
      i[65] = "r8\u007fm\u0005Zj~4gf]q+``1\u000e \u007f<\f\u0004Mk'ge\u001c\u000b -";
      i[66] = "kZ\u001ee+\\1R\u001c!\u001aQ5T\u00002M\u0001n\u0007Z^xA/X\u00077`\u0007dR";
      i[67] = "O?-nd\u001f\u00140!4\u000b\u001a\u007f1\"ik\u0010\u001c9zess\u001b<w5h\u0010\u0013d{-\u000b";
      i[68] = "dB'+\u0003e|\u0004l!`bgQ8&716\u0004lJ\u0002r}]?#\u001a46W";
      i[69] = "@G>\u001ddM\u001aQ:\u0000\u0006M\u0013Z'\nA]z\u0003:\u001bxQBUf\u001ec3@G>\u001ddM\u001aQ:\u0000\u0006";
      i[70] = "qX\u001d\u0006T/{Y\fUe1l[\u0014\u000b\bP6K\u0014\u0012\u00025`X\u001a\fe/nF\u001a\u0014\u0006)aW\rhY>m_\u0014\r\u000f-cAs";
      i[71] = ")@p%aG5Ce(^\f=[z=5\u001bPY\"3 Fj\u001fr%!v*\u001fy*nLlOo+^\u000f3Moko\u00130XbT";
      i[72] = "i*Y'/\u0012n.H:K\f{h9=(\u0007c/\b!+\u0012n\u0010@'%\u0018-!\\$0\u0015\u0012";
      i[73] = "~\u0012\\l\bk%\u001dP6gnN\u0007^4\u000e{-\u0001Q%\u0019\u0007'A@;\f~1\u001f\u0005+g";
      i[74] = "\u000b1\u0019[\u007fY^0\u0019\u001cGQb&\u0010[8D\u001a<\u0013@z;";
      i[75] = "-E\u0010>v\u0000vJ\u001cd\u0019\u0001\u001dP\u0012fp\u0010~V\u001dwgl O\n{{Tv\u0013\u000f`\u0019";
      i[76] = "SNbc.n\tF`'\u001fc\r@|4H6]\u0016\"X\"m\u0010Sz`t1\u0015H";
      i[77] = "4\t\nqeE3\r\u001bl\u0001[&K/\u007f}^(_&\u007fzUOJ\t|p\u0001~V\ni}>6P\u0004c>\u000f*S\u0011n\u0001";
      i[78] = "5E^'rE4\u0002\u0003i\u000b\u00108S[:\\Di\u0005\u000ff\u000b\u0013i\u000f]8hE>A\u0003";
      i[79] = "\u0016\\9lpyMS56\u001f\u007f&I;4viEO4%a\u0015\u001bV#)}-M\n&2\u001f";
      i[80] = "o\u001d(b\u0004+h\u00199\u007f`5}_\rl\u001c0sK\u000eh\u0005=\u0014^+o\u0011o%B(z\u001cPmD&p_aqG3}`)wI9>Q5t\\4\u0001\u00193zVw0\u00050o[H";
      i[81] = "N\u0002'D[TF\u0017a\u0006\"\r6\u0016>\u001dK\u0018U\u00101\f\\d\n\u0007=\u0004E\u0001\\\u00143\u001a\"";
      i[82] = "\t\u001cM9?t\u0013MKz\u0000e\u0006CM/GuoMS<\u007fd\u0017WP'=\u001b\t\u001cM9?t\u0013MKz\u0000";
      i[83] = "\u000b\u0014AIsNQ\u001cC\rBHY\u000b[\u0015.z\tI\nOB\u0010T\u000bE\u0010zF\b\u000e^r\u007fMH\tYJ)\u0011M\u0012;";
      i[84] = "\u0010\na\u0000Eh\u0007\u001dtgBT\u0004\u0014z\u000eT7\u0002\u001bk\u0019(m\u0002IvV\u0015n\u000bJ\u007fg";
      i[85] = "\u0016`[QR>\u0017'\u0006\u001f+k\u001bv^L|?J \n\u001f+hJ*XNH>\u001dd\u0006";
      i[86] = "nky\u000eU\u0007(+|\u000f.X8/\u0003\u0017KZU*&\u0010_\bd6%\u0005R7";
      i[87] = "Mz\u0017s){\u000b:\u0012rR$\u001b>nn.+\u0011.+z1%\u0007}\u001af20\nBTai/\u000e(El>3v9Vm<z\t3W|oK";
      i[88] = ">Y\u0002f;\u001f=P\u0001o\nK\u0007__jc^dYP{t\";N\\smGm]Rm\n";
      i[89] = "\u0016\fs-\u0005K\u0010\u0004hhhE\u0006IH;\rC\u0013M\u007f,hTW\u000b}<\u000fQ\r\r}V";
      i[90] = "ea\fE96>n\u0000\u001fV3Ut\u000e\u001d?&6r\u0001\f(Zhk\u0016\u00004b>7\u0013\u001bV";
      i[91] = "'\u001e$*{o}\b 7\u0019\u007fy\u0000),Gxy\u001a-P$qa\u0019\"hr-d\u0002@";
      i[92] = ">KR9zM;\u0011T9\u0010E-\u000b6;uC8\u000f\u0001,\u0010Qz\u0017\u000f2kV~\u0006\u0012V";
      i[93] = "*\u001eT\u0019\u0000wp\u0016V]1qx\u0001NE]C+D\u0012\u001b\r\u0014(\u001dR\\S,~AWG1)u\u0001P@\t\u007f)\u0004K\"";
      i[94] = "+\n\u0011:9)1[\u0017y\u0006\u001a\u001ci!A=~qA\u0017q{>t@";
      i[95] = "|v1.\u0006<'y=ti>Lc3v\u0000,/e<g\u0017Pq|+k\u000bh' .pi";
      i[96] = "\u0018iF_=jCfJ\u0005Rk(|D\u0007;zKzK\u0016,\u0006\u0016h@\u0003)e\u0012eE\u001aR";
      i[97] = "#xN$|G qM-M\u0013\u001a~\u0013($\u0006yx\u001c93z$j\u0017,6\u0019 g\u00125M";
      i[98] = "lt~]8]kpo@\\\\z0sD'K\u00175$^?Bl2 O\"&";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(450497477039133L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(450497477039133L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(450497477039133L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 164;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 82;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 220;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 98;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 242;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 164;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 82;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 220;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/K_C0421",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/K" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static String invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding7(long var0, long var2) {
         MethodHandle var8 = bindingCache7;
         MethodHandle var7 = bindingCache7;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache7 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static AMapper invokeBinding11(long var0, long var2) {
         MethodHandle var8 = bindingCache11;
         MethodHandle var7 = bindingCache11;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache11 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding15(int var0, long var1) {
         MethodHandle var7 = bindingCache15;
         MethodHandle var6 = bindingCache15;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache15 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding16(int var0, long var1) {
         MethodHandle var7 = bindingCache16;
         MethodHandle var6 = bindingCache16;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache16 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding17(Object var0, char var1, char var2, long var3, long var5) {
         MethodHandle var11 = bindingCache17;
         MethodHandle var10 = bindingCache17;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache17 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;CCJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (char)var1, (char)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding19(long var0, long var2) {
         MethodHandle var8 = bindingCache19;
         MethodHandle var7 = bindingCache19;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache19 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding22(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding23(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding24(long var0, long var2) {
         MethodHandle var8 = bindingCache24;
         MethodHandle var7 = bindingCache24;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache24 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding26(int var0, long var1) {
         MethodHandle var7 = bindingCache26;
         MethodHandle var6 = bindingCache26;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache26 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding27(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache27;
         MethodHandle var11 = bindingCache27;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache27 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (String)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static Method invokeBinding28(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache28;
         MethodHandle var10 = bindingCache28;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache28 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/reflect/Method;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Method)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static void invokeBinding29(Object var0, boolean var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;ZJJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (boolean)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding30(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache30;
         MethodHandle var10 = bindingCache30;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache30 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding31(int var0, long var1) {
         MethodHandle var7 = bindingCache31;
         MethodHandle var6 = bindingCache31;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache31 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding33(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache33;
         MethodHandle var9 = bindingCache33;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache33 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding34(int var0, long var1) {
         MethodHandle var7 = bindingCache34;
         MethodHandle var6 = bindingCache34;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache34 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding35(int var0, long var1) {
         MethodHandle var7 = bindingCache35;
         MethodHandle var6 = bindingCache35;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache35 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding36(long var0, long var2) {
         MethodHandle var8 = bindingCache36;
         MethodHandle var7 = bindingCache36;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache36 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding37(long var0, long var2) {
         MethodHandle var8 = bindingCache37;
         MethodHandle var7 = bindingCache37;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache37 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Class invokeBinding38(long var0, long var2) {
         MethodHandle var8 = bindingCache38;
         MethodHandle var7 = bindingCache38;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache38 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding39(int var0, long var1) {
         MethodHandle var7 = bindingCache39;
         MethodHandle var6 = bindingCache39;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache39 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding40(long var0, long var2) {
         MethodHandle var8 = bindingCache40;
         MethodHandle var7 = bindingCache40;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache40 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding41(int var0, long var1) {
         MethodHandle var7 = bindingCache41;
         MethodHandle var6 = bindingCache41;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache41 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding42(int var0, long var1) {
         MethodHandle var7 = bindingCache42;
         MethodHandle var6 = bindingCache42;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache42 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding43(int var0, long var1) {
         MethodHandle var7 = bindingCache43;
         MethodHandle var6 = bindingCache43;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache43 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding44(long var0, long var2) {
         MethodHandle var8 = bindingCache44;
         MethodHandle var7 = bindingCache44;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache44 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundMethodInvoker invokeBinding45(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache45;
         MethodHandle var8 = bindingCache45;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache45 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding46(int var0, long var1) {
         MethodHandle var7 = bindingCache46;
         MethodHandle var6 = bindingCache46;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache46 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Float invokeBinding47(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding48(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Float invokeBinding49(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding50(int var0, long var1) {
         MethodHandle var7 = bindingCache50;
         MethodHandle var6 = bindingCache50;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache50 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Float invokeBinding51(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache51;
         MethodHandle var8 = bindingCache51;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache51 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FJJ)Ljava/lang/Float;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding52(int var0, long var1) {
         MethodHandle var7 = bindingCache52;
         MethodHandle var6 = bindingCache52;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache52 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding53(int var0, long var1) {
         MethodHandle var7 = bindingCache53;
         MethodHandle var6 = bindingCache53;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache53 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding54(int var0, long var1) {
         MethodHandle var7 = bindingCache54;
         MethodHandle var6 = bindingCache54;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache54 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Integer invokeBinding55(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache55;
         MethodHandle var8 = bindingCache55;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache55 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding56(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache56;
         MethodHandle var9 = bindingCache56;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache56 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding57(int var0, long var1) {
         MethodHandle var7 = bindingCache57;
         MethodHandle var6 = bindingCache57;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache57 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static BoundFieldAccessor invokeBinding58(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache58;
         MethodHandle var8 = bindingCache58;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache58 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding59(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache59;
         MethodHandle var9 = bindingCache59;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache59 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding60(int var0, long var1) {
         MethodHandle var7 = bindingCache60;
         MethodHandle var6 = bindingCache60;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache60 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding61(long var0, long var2) {
         MethodHandle var8 = bindingCache61;
         MethodHandle var7 = bindingCache61;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache61 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding62(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache62;
         MethodHandle var8 = bindingCache62;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache62 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding63(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache63;
         MethodHandle var9 = bindingCache63;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache63 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding64(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache64;
         MethodHandle var8 = bindingCache64;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache64 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding65(int var0, long var1) {
         MethodHandle var7 = bindingCache65;
         MethodHandle var6 = bindingCache65;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache65 = a(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Class invokeBinding66(long var0, long var2) {
         MethodHandle var8 = bindingCache66;
         MethodHandle var7 = bindingCache66;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache66 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Ljava/lang/Class;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Class)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static BoundFieldAccessor invokeBinding67(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache67;
         MethodHandle var8 = bindingCache67;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache67 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding68(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache68;
         MethodHandle var9 = bindingCache68;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache68 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding69(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache69;
         MethodHandle var8 = bindingCache69;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache69 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding70(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache70;
         MethodHandle var9 = bindingCache70;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache70 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;FJJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding71(long var0, long var2) {
         MethodHandle var8 = bindingCache71;
         MethodHandle var7 = bindingCache71;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache71 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Hand invokeBinding72(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache72;
         MethodHandle var8 = bindingCache72;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache72 = c(
                  MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/Hand;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Hand)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Hand invokeBinding73(long var0, long var2) {
         MethodHandle var8 = bindingCache73;
         MethodHandle var7 = bindingCache73;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache73 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/Hand;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Hand)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Object invokeBinding74(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache74;
         MethodHandle var9 = bindingCache74;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache74 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding75(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache75;
         MethodHandle var9 = bindingCache75;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache75 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;FJJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static HandRenderType invokeBinding76(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache76;
         MethodHandle var9 = bindingCache76;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache76 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (HandRenderType)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = c(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding78(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache78;
         MethodHandle var8 = bindingCache78;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache78 = c(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding79(float var0, float var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache79;
         MethodHandle var10 = bindingCache79;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache79 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FFFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var8.invokeExact((float)var0, (float)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static float invokeBinding80(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache80;
         MethodHandle var8 = bindingCache80;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache80 = c(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding81(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache81;
         MethodHandle var8 = bindingCache81;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache81 = c(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding82(float var0, float var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache82;
         MethodHandle var10 = bindingCache82;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache82 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FFFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var8.invokeExact((float)var0, (float)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static RotationAxis invokeBinding83(long var0, long var2) {
         MethodHandle var8 = bindingCache83;
         MethodHandle var7 = bindingCache83;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache83 = c(
                  MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/math/RotationAxis;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RotationAxis)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static float invokeBinding84(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache84;
         MethodHandle var9 = bindingCache84;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache84 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;FJJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Quaternionf invokeBinding85(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache85;
         MethodHandle var9 = bindingCache85;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache85 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;FJJ)Lorg/joml/Quaternionf;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Quaternionf)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding86(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache86;
         MethodHandle var9 = bindingCache86;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache86 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RotationAxis invokeBinding87(long var0, long var2) {
         MethodHandle var8 = bindingCache87;
         MethodHandle var7 = bindingCache87;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache87 = c(
                  MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/math/RotationAxis;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RotationAxis)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static float invokeBinding88(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache88;
         MethodHandle var9 = bindingCache88;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache88 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;FJJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Quaternionf invokeBinding89(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache89;
         MethodHandle var9 = bindingCache89;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache89 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;FJJ)Lorg/joml/Quaternionf;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Quaternionf)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding90(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache90;
         MethodHandle var9 = bindingCache90;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache90 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding91(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache91;
         MethodHandle var8 = bindingCache91;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache91 = c(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding92(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache92;
         MethodHandle var8 = bindingCache92;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache92 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Hand invokeBinding93(long var0, long var2) {
         MethodHandle var8 = bindingCache93;
         MethodHandle var7 = bindingCache93;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache93 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/Hand;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Hand)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding94(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache94;
         MethodHandle var8 = bindingCache94;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache94 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding95(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache95;
         MethodHandle var8 = bindingCache95;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache95 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding96(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache96;
         MethodHandle var9 = bindingCache96;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache96 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding97(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache97;
         MethodHandle var9 = bindingCache97;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache97 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding98(float var0, float var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache98;
         MethodHandle var10 = bindingCache98;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache98 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FFFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var8.invokeExact((float)var0, (float)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Hand invokeBinding99(long var0, long var2) {
         MethodHandle var8 = bindingCache99;
         MethodHandle var7 = bindingCache99;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache99 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/Hand;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Hand)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ItemStack invokeBinding100(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache100;
         MethodHandle var9 = bindingCache100;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache100 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/item/ItemStack;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ItemStack)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding101(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache101;
         MethodHandle var9 = bindingCache101;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache101 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding102(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache102;
         MethodHandle var8 = bindingCache102;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache102 = c(MethodHandles.lookup(), "¤", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Hand invokeBinding103(long var0, long var2) {
         MethodHandle var8 = bindingCache103;
         MethodHandle var7 = bindingCache103;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache103 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/Hand;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Hand)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding104(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache104;
         MethodHandle var8 = bindingCache104;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache104 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding105(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache105;
         MethodHandle var8 = bindingCache105;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache105 = c(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding106(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache106;
         MethodHandle var9 = bindingCache106;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache106 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding107(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache107;
         MethodHandle var9 = bindingCache107;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache107 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding108(float var0, float var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache108;
         MethodHandle var10 = bindingCache108;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache108 = c(MethodHandles.lookup(), "ò", SourceSupport.methodType("(FFFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var8.invokeExact((float)var0, (float)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Hand invokeBinding109(long var0, long var2) {
         MethodHandle var8 = bindingCache109;
         MethodHandle var7 = bindingCache109;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache109 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(JJ)Lnet/minecraft/util/Hand;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Hand)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ItemStack invokeBinding110(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache110;
         MethodHandle var9 = bindingCache110;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache110 = c(
                  MethodHandles.lookup(),
                  "b",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/item/ItemStack;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ItemStack)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding111(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache111;
         MethodHandle var9 = bindingCache111;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache111 = c(
                  MethodHandles.lookup(), "b", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
