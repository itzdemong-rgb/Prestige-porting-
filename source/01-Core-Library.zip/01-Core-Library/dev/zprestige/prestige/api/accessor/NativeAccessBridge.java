package dev.zprestige.prestige.api.accessor;
import dev.zprestige.prestige.api.events.AmbientColorEvent;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.AttackCooldownEvent;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.AttackTargetUpdateEvent;
import dev.zprestige.prestige.api.events.BlockBounceEvent;
import dev.zprestige.prestige.api.events.BlockStateUpdateEvent;
import dev.zprestige.prestige.api.events.BlockVisibilityEvent;
import dev.zprestige.prestige.api.events.CameraPositionEvent;
import dev.zprestige.prestige.api.events.CameraRotationEvent;
import dev.zprestige.prestige.api.events.CrosshairRenderEvent;
import dev.zprestige.prestige.api.events.EntityBoundingBoxEvent;
import dev.zprestige.prestige.api.events.EntityLabelEvent;
import dev.zprestige.prestige.api.events.EntityLifecycleEvent;
import dev.zprestige.prestige.api.events.EntityNameEvent;
import dev.zprestige.prestige.api.events.EntityReachEvent;
import dev.zprestige.prestige.api.events.EntityRotationEvent;
import dev.zprestige.prestige.api.events.FireOverlayEvent;
import dev.zprestige.prestige.api.events.FrustumEvent;
import dev.zprestige.prestige.api.events.HeldItemTransformEvent;
import dev.zprestige.prestige.api.events.HotbarItemNameEvent;
import dev.zprestige.prestige.api.events.HurtCameraEvent;
import dev.zprestige.prestige.api.events.InterpolatedPositionEvent;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.events.KeyInputEvent;
import dev.zprestige.prestige.api.events.LightmapEvent;
import dev.zprestige.prestige.api.events.MouseButtonEvent;
import dev.zprestige.prestige.api.events.MouseLookEvent;
import dev.zprestige.prestige.api.events.MovementPhaseEvent;
import dev.zprestige.prestige.api.events.MovementResetEvent;
import dev.zprestige.prestige.api.events.MovementRotationEvent;
import dev.zprestige.prestige.api.events.MovementVectorEvent;
import dev.zprestige.prestige.api.events.NativePhaseEvent;
import dev.zprestige.prestige.api.events.NativeRenderPhaseEvent;
import dev.zprestige.prestige.api.events.OverlayStyleEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.ParticleRenderEvent;
import dev.zprestige.prestige.api.events.PlayerHealthIndicatorEvent;
import dev.zprestige.prestige.api.events.PlayerNameEvent;
import dev.zprestige.prestige.api.events.PlayerSkinEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.ScoreboardRenderEvent;
import dev.zprestige.prestige.api.events.ScreenBackgroundTintEvent;
import dev.zprestige.prestige.api.events.ShieldEntityEvent;
import dev.zprestige.prestige.api.events.SwingDurationEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.TotemAnimationEvent;
import dev.zprestige.prestige.api.events.VelocityEvent;
import dev.zprestige.prestige.api.events.WeatherRenderEvent;
import dev.zprestige.prestige.api.events.WindowEvent;
import dev.zprestige.prestige.api.events.WorldChunkEvent;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.WorldTimeEvent;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.client.management.EntityModelManager;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.client.management.VisualRotationManager;
import dev.zprestige.prestige.client.resources.PrestigeResourcePack;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.GlStateSnapshot;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.RenderLayerUtil;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;


import com.mojang.authlib.GameProfile;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.ProjectionMatrix2;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.network.packet.Packet;
import net.minecraft.resource.Resource;
import net.minecraft.text.Text;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector4f;

public class NativeAccessBridge {
   private static final long a = 88534709430571L;
   private static final Object[] b = new Object[194];
   private static final String[] c = new String[194];

   public static boolean cr(EventBus var0, Class var1) {
      long var10001 = 62523444268790L ^ 96204953122931L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static GuiRendererAccessor by(GuiRenderer var0) {
      return new GuiRendererAccessor(var0);
   }

   public static PlayerHealthIndicatorEvent bk(PlayerEntity var0, String var1) {
      return new PlayerHealthIndicatorEvent(var0, var1);
   }

   public static boolean f(PlayerSkinEvent var0) {
      long var10001 = 67343354421460L ^ 18468690833296L;
      Object[] var6 = new Object[]{50524040089412L};
      PlayerSkinEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean ez(BlockStateUpdateEvent var0) {
      long var10001 = 111350070434850L ^ 79947562652518L;
      Object[] var6 = new Object[]{50524040089412L};
      BlockStateUpdateEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static PacketReceiveEvent V(Packet var0) {
      return new PacketReceiveEvent(var0);
   }

   public static CameraRotationEvent L(float var0, float var1) {
      return new CameraRotationEvent(var0, var1);
   }

   public static boolean bq() {
      long var10001 = 104567726880265L ^ 50318056538456L;
      Object[] var4 = new Object[]{126276464932689L};
      return Prestige.bReturningBoolean(var4);
   }

   public static boolean dj(ItemUseEvent var0) {
      long var10001 = 126359845705692L ^ 104590955632792L;
      Object[] var6 = new Object[]{50524040089412L};
      ItemUseEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static TickEvent dc() {
      return new TickEvent();
   }

   public static AttackTargetUpdateEvent dm() {
      return new AttackTargetUpdateEvent();
   }

   public static boolean ev(WorldTimeEvent var0) {
      long var10001 = 21855011619240L ^ 68251581288172L;
      Object[] var6 = new Object[]{50524040089412L};
      WorldTimeEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Color ef(AmbientColorEvent var0) {
      Object[] var4 = new Object[0];
      AmbientColorEvent var3 = var0;
      return var3.bReturningColor(var4);
   }

   public static boolean et(EventBus var0, Class var1) {
      long var10001 = 119307386723291L ^ 3437110914398L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static WorldChunkEvent ad(WorldChunk var0) {
      return new WorldChunkEvent(var0);
   }

   public static boolean av(AttackEntityEvent var0) {
      long var10001 = 114754887818407L ^ 76613612295139L;
      Object[] var6 = new Object[]{50524040089412L};
      AttackEntityEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean bl(PlayerHealthIndicatorEvent var0) {
      long var10001 = 83660100723465L ^ 107636878191693L;
      Object[] var6 = new Object[]{50524040089412L};
      PlayerHealthIndicatorEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Resource dK(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static String dE(GameProfile var0) {
      long var10001 = 82993479142825L ^ 74636001465205L;
      Object[] var5 = new Object[]{var0, 9461285330652L};
      return RaycastUtil.aReturningString(var5);
   }

   public static boolean C(BlockVisibilityEvent var0) {
      Object[] var4 = new Object[0];
      BlockVisibilityEvent var3 = var0;
      return var3.cReturningBoolean(var4);
   }

   public static boolean X(EventBus var0, Class var1) {
      long var10001 = 126780521324284L ^ 31801184741497L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean ax(EntityLifecycleEvent var0) {
      long var10001 = 114787359682319L ^ 76508546342987L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityLifecycleEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static WorldTimeEvent eu(long var0) {
      return new WorldTimeEvent(var0);
   }

   public static double J(CameraPositionEvent var0) {
      Object[] var4 = new Object[0];
      CameraPositionEvent var3 = var0;
      return var3.cReturningDouble(var4);
   }

   public static Resource dM(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static boolean aM(VelocityEvent var0) {
      long var10001 = 20830695700619L ^ 69275897427919L;
      Object[] var6 = new Object[]{50524040089412L};
      VelocityEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Resource dJ(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static SkinTextures dH(PlayerSkinEvent var0) {
      Object[] var4 = new Object[0];
      PlayerSkinEvent var3 = var0;
      return var3.aReturningSkinTextures(var4);
   }

   public static float t(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.bReturningFloat(var4);
   }

   public static Vec3d aG(double var0, double var2, double var4) {
      return new Vec3d(var0, var2, var4);
   }

   public static float aD(MovementVectorEvent var0) {
      Object[] var4 = new Object[0];
      MovementVectorEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static boolean dy(EventBus var0, Class var1) {
      long var10001 = 96972214467908L ^ 61092483337153L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean cu(EventBus var0, Class var1) {
      long var10001 = 2329950905863L ^ 120655601504386L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static PlayerSkinEvent e(SkinTextures var0, String var1) {
      return new PlayerSkinEvent(var0, var1);
   }

   public static Rotation an(RotationManager var0) {
      long var10001 = 83857255494623L ^ 117618403810287L;
      Object[] var6 = new Object[]{42595921258544L};
      RotationManager var5 = var0;
      return var5.dReturningdx_C0210(var6);
   }

   public static boolean D(EventBus var0, Class var1) {
      long var10001 = 3714337613424L ^ 119584345018613L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static PacketSendEvent Y(Packet var0) {
      return new PacketSendEvent(var0);
   }

   public static GlStateSnapshot eE() {
      return GlStateSnapshot.aReturninggo_C0354();
   }

   public static double aP(VelocityEvent var0) {
      Object[] var4 = new Object[0];
      VelocityEvent var3 = var0;
      return var3.cReturningDouble(var4);
   }

   public static MatrixStack bI() {
      return new MatrixStack();
   }

   public static boolean bf(EventBus var0, Class var1) {
      long var10001 = 20280859476815L ^ 138332991206858L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean ej(EntityNameEvent var0) {
      long var10001 = 5496202338891L ^ 45132124941583L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityNameEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static MouseButtonEvent dv(int var0, int var1) {
      return new MouseButtonEvent(var0, var1);
   }

   public static boolean cg(EventBus var0, Class var1) {
      long var10001 = 8346112733787L ^ 114577156359390L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean eR(NativeRenderPhaseEvent var0) {
      long var10001 = 50848597667417L ^ 4177257275677L;
      Object[] var6 = new Object[]{50524040089412L};
      NativeRenderPhaseEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean dn(AttackTargetUpdateEvent var0) {
      long var10001 = 94182243846837L ^ 132332376163825L;
      Object[] var6 = new Object[]{50524040089412L};
      AttackTargetUpdateEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean en(PlayerNameEvent var0) {
      long var10001 = 54883685190871L ^ 30894001292179L;
      Object[] var6 = new Object[]{50524040089412L};
      PlayerNameEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static ProjectionMatrix2 bz(GuiRendererAccessor var0) {
      long var10001 = 6383713209661L ^ 52829200530652L;
      Object[] var6 = new Object[]{59107663835617L};
      GuiRendererAccessor var5 = var0;
      return var5.aReturningVoid(var6);
   }

   public static void eD() {
      long var10001 = 100574852028926L ^ 114314217522967L;
      Object[] var4 = new Object[]{66585716858601L};
      GameRenderUtil.aReturningVoid(var4);
   }

   public static OverlayStyleEvent v(float var0, float var1, Color var2) {
      return new OverlayStyleEvent(var0, var1, var2);
   }

   public static void bE(RenderContext var0) {
      long var10001 = 26575702287194L ^ 22157308694656L;
      Object[] var5 = new Object[]{var0, 13251144905690L};
      RenderThreadUtil.eReturningVoid(var5);
   }

   public static double I(CameraPositionEvent var0) {
      Object[] var4 = new Object[0];
      CameraPositionEvent var3 = var0;
      return var3.bReturningDouble(var4);
   }

   public static boolean el(EventBus var0, Class var1) {
      long var10001 = 3815450509054L ^ 119685491427451L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean dY(EventBus var0, Class var1) {
      long var10001 = 51200693658919L ^ 71688348341154L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static List eA() {
      long var10001 = 40899894187682L ^ 44175945307990L;
      Object[] var4 = new Object[]{14427804729844L};
      return RenderThreadUtil.aReturningList(var4);
   }

   public static Color x(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static void bu(List var0) {
      long var10001 = 42445721126557L ^ 119160220507053L;
      Object[] var5 = new Object[]{var0, 82439963417904L};
      RenderThreadUtil.cReturningVoid(var5);
   }

   public static void eG(GlStateSnapshot var0) {
      GlStateSnapshot var3 = var0;
      var3.aReturningVoid();
   }

   public static boolean am(PlayerUpdateEvent var0) {
      long var10001 = 26805150501417L ^ 58903397074285L;
      Object[] var6 = new Object[]{50524040089412L};
      PlayerUpdateEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static MovementVectorEvent cW(float var0) {
      return new MovementVectorEvent(var0);
   }

   public static boolean M(CameraRotationEvent var0) {
      long var10001 = 6781418009967L ^ 48212743600683L;
      Object[] var6 = new Object[]{50524040089412L};
      CameraRotationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Text ek(EntityNameEvent var0) {
      Object[] var4 = new Object[0];
      EntityNameEvent var3 = var0;
      return var3.aReturningText(var4);
   }

   public static boolean cL(MovementRotationEvent var0) {
      long var10001 = 92658907370712L ^ 133824171482012L;
      Object[] var6 = new Object[]{50524040089412L};
      MovementRotationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean U(EventBus var0, Class var1) {
      long var10001 = 33365392004036L ^ 125319998039361L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static ShieldEntityEvent cT(LivingEntity var0) {
      return new ShieldEntityEvent(var0);
   }

   public static CameraAccessor G(Camera var0) {
      return new CameraAccessor(var0);
   }

   public static boolean z(EventBus var0, Class var1) {
      long var10001 = 91001663880815L ^ 67490318682346L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean c(BlockVisibilityEvent var0) {
      long var10001 = 73498612514534L ^ 122231309398434L;
      Object[] var6 = new Object[]{50524040089412L};
      BlockVisibilityEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean ak(AttackAttemptEvent var0) {
      long var10001 = 6605407616752L ^ 48320455061940L;
      Object[] var6 = new Object[]{50524040089412L};
      AttackAttemptEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static EntityLifecycleEvent ay(Entity var0, EventPhase var1) {
      return new EntityLifecycleEvent(var0, var1);
   }

   public static Vector4f y(float var0, float var1, float var2, float var3) {
      return new Vector4f(var0, var1, var2, var3);
   }

   public static boolean es(WeatherRenderEvent var0) {
      long var10001 = 75926085837587L ^ 115441743064151L;
      Object[] var6 = new Object[]{50524040089412L};
      WeatherRenderEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static BlockVisibilityEvent S(Block var0) {
      return new BlockVisibilityEvent(var0);
   }

   public static boolean dC(AttackCooldownEvent var0) {
      long var10001 = 87619923982819L ^ 108040188065447L;
      Object[] var6 = new Object[]{50524040089412L};
      AttackCooldownEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Resource dN(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static InGameOverlayRenderer bR(GameRendererAccessor var0) {
      long var10001 = 110747071736063L ^ 117359106404982L;
      Object[] var6 = new Object[]{15416852732553L};
      GameRendererAccessor var5 = var0;
      return var5.aReturningInGameOverlayRenderer(var6);
   }

   public static Resource dO(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static MovementPhaseEvent ce() {
      return new MovementPhaseEvent();
   }

   public static boolean dA(ParticleRenderEvent var0) {
      long var10001 = 80363731288734L ^ 110933248462298L;
      Object[] var6 = new Object[]{50524040089412L};
      ParticleRenderEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static String ep(PlayerNameEvent var0) {
      Object[] var4 = new Object[0];
      PlayerNameEvent var3 = var0;
      return var3.bReturningString(var4);
   }

   public static RenderContext eI(Matrix4f var0, Matrix4f var1, Camera var2) {
      return new RenderContext(var0, var1, var2);
   }

   public static PlayerInput cE(boolean var0, boolean var1, boolean var2, boolean var3, boolean var4, boolean var5, boolean var6) {
      return new PlayerInput(var0, var1, var2, var3, var4, var5, var6);
   }

   public static List bp() {
      long var10001 = 113397287909399L ^ 116811856968163L;
      Object[] var4 = new Object[]{14427804729844L};
      return RenderThreadUtil.aReturningList(var4);
   }

   public static boolean dw(MouseButtonEvent var0) {
      long var10001 = 120491335947085L ^ 70805089246217L;
      Object[] var6 = new Object[]{50524040089412L};
      MouseButtonEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Color ed(AmbientColorEvent var0) {
      Object[] var4 = new Object[0];
      AmbientColorEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static void eL(GlStateSnapshot var0) {
      GlStateSnapshot var3 = var0;
      var3.aReturningVoid();
   }

   public static boolean bH() {
      long var10001 = 14561972633023L ^ 140632242866926L;
      Object[] var4 = new Object[]{126276464932689L};
      return Prestige.bReturningBoolean(var4);
   }

   public static EntityNameEvent bh(Entity var0, Text var1) {
      return new EntityNameEvent(var0, var1);
   }

   public static boolean dl(AttackInputEvent var0) {
      long var10001 = 21617831466831L ^ 68559495239691L;
      Object[] var6 = new Object[]{50524040089412L};
      AttackInputEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean dG(PlayerSkinEvent var0) {
      long var10001 = 39850956814489L ^ 10776297977821L;
      Object[] var6 = new Object[]{50524040089412L};
      PlayerSkinEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Vec3d aE(MovementVectorEvent var0) {
      Object[] var4 = new Object[0];
      MovementVectorEvent var3 = var0;
      return var3.aReturningVec3d(var4);
   }

   public static boolean W(PacketReceiveEvent var0) {
      long var10001 = 37772148184452L ^ 17218659146432L;
      Object[] var6 = new Object[]{50524040089412L};
      PacketReceiveEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean bL(HurtCameraEvent var0) {
      long var10001 = 70698330553399L ^ 120668038804339L;
      Object[] var6 = new Object[]{50524040089412L};
      HurtCameraEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cS(EventBus var0, Class var1) {
      long var10001 = 75484471100135L ^ 47301292192866L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean ba(EntityRotationEvent var0) {
      long var10001 = 135563811107316L ^ 95352094490288L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityRotationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean eC() {
      long var10001 = 50518087338024L ^ 104639084330873L;
      Object[] var4 = new Object[]{126276464932689L};
      return Prestige.bReturningBoolean(var4);
   }

   public static FireOverlayEvent cp() {
      return new FireOverlayEvent();
   }

   public static float aq(PlayerUpdateEvent var0) {
      Object[] var4 = new Object[0];
      PlayerUpdateEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static boolean F(CameraPositionEvent var0) {
      long var10001 = 22955947531752L ^ 62755150189228L;
      Object[] var6 = new Object[]{50524040089412L};
      CameraPositionEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Box aK(EntityBoundingBoxEvent var0) {
      Object[] var4 = new Object[0];
      EntityBoundingBoxEvent var3 = var0;
      return var3.aReturningBox(var4);
   }

   public static double aO(VelocityEvent var0) {
      Object[] var4 = new Object[0];
      VelocityEvent var3 = var0;
      return var3.bReturningDouble(var4);
   }

   public static float cY(MovementVectorEvent var0) {
      Object[] var4 = new Object[0];
      MovementVectorEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static boolean cm(EventBus var0, Class var1) {
      long var10001 = 105427633645255L ^ 53055211360322L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static void eK(GlStateSnapshot var0) {
      GlStateSnapshot var3 = var0;
      var3.aReturningVoid();
   }

   public static HotbarItemNameEvent cn() {
      return new HotbarItemNameEvent();
   }

   public static Rotation aT(RotationManager var0) {
      Object[] var4 = new Object[0];
      RotationManager var3 = var0;
      return var3.bReturningdx_C0210(var4);
   }

   public static float O(CameraRotationEvent var0) {
      Object[] var4 = new Object[0];
      CameraRotationEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static boolean bi(EntityNameEvent var0) {
      long var10001 = 64590787203788L ^ 25620513496456L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityNameEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean ai(AttackAttemptEvent var0) {
      Object[] var4 = new Object[0];
      AttackAttemptEvent var3 = var0;
      return var3.cReturningBoolean(var4);
   }

   public static boolean d(EventBus var0, Class var1) {
      long var10001 = 84451639749424L ^ 38950057876917L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean cR(SwingDurationEvent var0) {
      long var10001 = 55528414424921L ^ 34579790225437L;
      Object[] var6 = new Object[]{50524040089412L};
      SwingDurationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static FramebufferEffect methodDo() {
      Object[] var2 = new Object[0];
      return EntityModelManager.aReturningc_(var2);
   }

   public static ScoreboardRenderEvent ck() {
      return new ScoreboardRenderEvent();
   }

   public static void eJ(RenderContext var0) {
      long var10001 = 4444713667463L ^ 84169957240288L;
      Object[] var5 = new Object[]{var0, 79746905056871L};
      RenderThreadUtil.dReturningVoid(var5);
   }

   public static ScreenBackgroundTintEvent dU() {
      return new ScreenBackgroundTintEvent();
   }

   public static Matrix4f bC() {
      return new Matrix4f();
   }

   public static boolean cb(EventBus var0, Class var1) {
      long var10001 = 52384659045974L ^ 70398429333715L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean h(EventBus var0, Class var1) {
      long var10001 = 15962814973836L ^ 106818123297033L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static Vector4f o(float var0, float var1, float var2, float var3) {
      return new Vector4f(var0, var1, var2, var3);
   }

   public static Color l(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static boolean T(BlockVisibilityEvent var0) {
      long var10001 = 55640592504106L ^ 34537421019758L;
      Object[] var6 = new Object[]{50524040089412L};
      BlockVisibilityEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean eO(FrustumEvent var0) {
      long var10001 = 17874136881231L ^ 67835500041995L;
      Object[] var6 = new Object[]{50524040089412L};
      FrustumEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static NativePhaseEvent cB(EventPhase var0) {
      return new NativePhaseEvent(var0);
   }

   public static boolean af(EventBus var0, Class var1) {
      long var10001 = 71361087446353L ^ 51974035041236L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static void br() {
      long var10001 = 12884807400110L ^ 137922028446349L;
      Object[] var4 = new Object[]{130599282874403L};
      RenderThreadUtil.hReturningVoid(var4);
   }

   public static boolean ae(WorldChunkEvent var0) {
      long var10001 = 76851660509982L ^ 114447466798170L;
      Object[] var6 = new Object[]{50524040089412L};
      WorldChunkEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static SkinTextures g(PlayerSkinEvent var0) {
      Object[] var4 = new Object[0];
      PlayerSkinEvent var3 = var0;
      return var3.aReturningSkinTextures(var4);
   }

   public static float bT() {
      long var10001 = 40620842207357L ^ 87067928052801L;
      Object[] var4 = new Object[]{118480199388220L};
      return ItemUseUtil.bReturningFloat(var4);
   }

   public static long ew(WorldTimeEvent var0) {
      Object[] var4 = new Object[0];
      WorldTimeEvent var3 = var0;
      return var3.aReturningLong(var4);
   }

   public static boolean cD(PacketQueueManager var0) {
      long var10001 = 11535146145727L ^ 18432525152141L;
      Object[] var6 = new Object[]{29403687221298L};
      PacketQueueManager var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean aU(EventBus var0, Class var1) {
      long var10001 = 3598417412825L ^ 119743617283164L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean aC(MovementVectorEvent var0) {
      long var10001 = 39067357800784L ^ 15924003186196L;
      Object[] var6 = new Object[]{50524040089412L};
      MovementVectorEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean dV(ScreenBackgroundTintEvent var0) {
      long var10001 = 8877954783967L ^ 41646219662747L;
      Object[] var6 = new Object[]{50524040089412L};
      ScreenBackgroundTintEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Matrix4f bB(ProjectionMatrixAccessor var0, float var1, float var2) {
      long var10001 = 37584687768549L ^ 63719669085458L;
      Object[] var10005 = new Object[]{null, null, 30636971333367L};
      var10005[1] = var2;
      var10005[0] = var1;
      Object[] var8 = var10005;
      ProjectionMatrixAccessor var7 = var0;
      return var7.aReturningMatrix4f(var8);
   }

   public static MovementVectorEvent aB(float var0, Vec3d var1) {
      return new MovementVectorEvent(var0, var1);
   }

   public static boolean dT(ScreenBackgroundTintEvent var0) {
      long var10001 = 60978826608022L ^ 29163737723602L;
      Object[] var6 = new Object[]{50524040089412L};
      ScreenBackgroundTintEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cF(PacketQueueManager var0) {
      long var10001 = 72462319880440L ^ 29210570588550L;
      Object[] var6 = new Object[]{100564234471806L};
      PacketQueueManager var5 = var0;
      return var5.cReturningBoolean(var6);
   }

   public static Resource dL(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static void aa(PacketQueueManager var0, Packet var1) {
      long var10001 = 4311302954602L ^ 135860116037858L;
      Object[] var7 = new Object[]{var1, 132472500846216L};
      PacketQueueManager var6 = var0;
      var6.aReturningVoid(var7);
   }

   public static CrosshairRenderEvent ch() {
      return new CrosshairRenderEvent();
   }

   public static boolean cj(EventBus var0, Class var1) {
      long var10001 = 74409699538213L ^ 48442702594976L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean co(HotbarItemNameEvent var0) {
      long var10001 = 34866920212051L ^ 55274569369879L;
      Object[] var6 = new Object[]{50524040089412L};
      HotbarItemNameEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cU(ShieldEntityEvent var0) {
      long var10001 = 102279867925207L ^ 124203613572499L;
      Object[] var6 = new Object[]{50524040089412L};
      ShieldEntityEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean eq(EventBus var0, Class var1) {
      long var10001 = 31355847557960L ^ 126610057868749L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static float q(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static float r(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.bReturningFloat(var4);
   }

   public static float ap(Rotation var0) {
      Object[] var4 = new Object[0];
      Rotation var3 = var0;
      return var3.bReturningFloat(var4);
   }

   public static double aN(VelocityEvent var0) {
      Object[] var4 = new Object[0];
      VelocityEvent var3 = var0;
      return var3.aReturningDouble(var4);
   }

   public static GlStateSnapshot bt() {
      return GlStateSnapshot.aReturninggo_C0354();
   }

   public static void bZ(HeightBoundsAccessor var0, int var1) {
      long var10001 = 113989402999251L ^ 137323740347236L;
      Object[] var10004 = new Object[]{null, 30000700752567L};
      var10004[0] = var1;
      Object[] var7 = var10004;
      HeightBoundsAccessor var6 = var0;
      var6.aReturningVoid(var7);
   }

   public static boolean dX(InterpolatedPositionEvent var0) {
      long var10001 = 2699488305545L ^ 52257093381837L;
      Object[] var6 = new Object[]{50524040089412L};
      InterpolatedPositionEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Predicate bX() {
      Object[] var2 = new Object[0];
      return EntityReachEvent.aReturningPredicate(var2);
   }

   public static OverlayStyleEvent i(float var0, float var1, Color var2) {
      return new OverlayStyleEvent(var0, var1, var2);
   }

   public static boolean j(OverlayStyleEvent var0) {
      long var10001 = 45198617774445L ^ 5394830771753L;
      Object[] var6 = new Object[]{50524040089412L};
      OverlayStyleEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static InterpolatedPositionEvent dW(float var0, double var1, double var3, double var5) {
      return new InterpolatedPositionEvent(var0, var1, var3, var5);
   }

   public static float aS(Rotation var0) {
      Object[] var4 = new Object[0];
      Rotation var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static void ca(HeightBoundsAccessor var0, int var1) {
      long var10001 = 77530138204696L ^ 67136960388084L;
      Object[] var10004 = new Object[]{null, 135845234606572L};
      var10004[0] = var1;
      Object[] var7 = var10004;
      HeightBoundsAccessor var6 = var0;
      var6.bReturningVoid(var7);
   }

   public static boolean Z(PacketSendEvent var0) {
      long var10001 = 27564866865134L ^ 58147304589482L;
      Object[] var6 = new Object[]{50524040089412L};
      PacketSendEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean ah(AttackAttemptEvent var0) {
      long var10001 = 12470028568171L ^ 42489791236399L;
      Object[] var6 = new Object[]{50524040089412L};
      AttackAttemptEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static String eo(PlayerNameEvent var0) {
      Object[] var4 = new Object[0];
      PlayerNameEvent var3 = var0;
      return var3.aReturningString(var4);
   }

   public static BlockBounceEvent cv() {
      return new BlockBounceEvent();
   }

   public static String bm(PlayerHealthIndicatorEvent var0) {
      Object[] var4 = new Object[0];
      PlayerHealthIndicatorEvent var3 = var0;
      return var3.aReturningString(var4);
   }

   public static boolean cw(BlockBounceEvent var0) {
      long var10001 = 67194016534254L ^ 18620160328106L;
      Object[] var6 = new Object[]{50524040089412L};
      BlockBounceEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Rotation cM(RotationManager var0) {
      Object[] var4 = new Object[0];
      RotationManager var3 = var0;
      return var3.cReturningdx_C0210(var4);
   }

   public static ItemUseEvent di() {
      return new ItemUseEvent();
   }

   public static RenderContext bD(Matrix4f var0, Matrix4f var1, Camera var2) {
      return new RenderContext(var0, var1, var2);
   }

   public static void bs() {
      long var10001 = 32426287161523L ^ 42152490687843L;
      Object[] var4 = new Object[]{65058846031312L};
      Prestige.aReturningVoid(var4);
   }

   public static LightmapEvent bc() {
      return new LightmapEvent();
   }

   public static boolean eP(EventBus var0, Class var1) {
      long var10001 = 119711728107910L ^ 3584798652163L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static HeightBoundsAccessor bY(Object var0) {
      return new HeightBoundsAccessor(var0);
   }

   public static Rotation cJ(RotationManager var0) {
      Object[] var4 = new Object[0];
      RotationManager var3 = var0;
      return var3.cReturningdx_C0210(var4);
   }

   public static Resource dP(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static Resource dx(Identifier var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.aReturningResource(var3);
   }

   public static WorldResetEvent ab() {
      return new WorldResetEvent();
   }

   public static boolean cf(MovementPhaseEvent var0) {
      long var10001 = 24068586809549L ^ 61643197736841L;
      Object[] var6 = new Object[]{50524040089412L};
      MovementPhaseEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static EntityNameEvent ei(Entity var0, Text var1) {
      return new EntityNameEvent(var0, var1);
   }

   public static Resource dR(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static Color eg(AmbientColorEvent var0) {
      Object[] var4 = new Object[0];
      AmbientColorEvent var3 = var0;
      return var3.bReturningColor(var4);
   }

   public static boolean bo(EntityLabelEvent var0) {
      long var10001 = 119843636898096L ^ 71523252676212L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityLabelEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean bJ(EventBus var0, Class var1) {
      long var10001 = 30493919532195L ^ 127653988016678L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static MovementResetEvent de() {
      return new MovementResetEvent();
   }

   public static AttackInputEvent dk() {
      return new AttackInputEvent();
   }

   public static boolean at(PlayerUpdateEvent var0) {
      long var10001 = 58928504108897L ^ 26851464165413L;
      Object[] var6 = new Object[]{50524040089412L};
      PlayerUpdateEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cX(MovementVectorEvent var0) {
      long var10001 = 18529666689754L ^ 67249746814366L;
      Object[] var6 = new Object[]{50524040089412L};
      MovementVectorEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static EntityBoundingBoxEvent aI(Entity var0, Box var1) {
      return new EntityBoundingBoxEvent(var0, var1);
   }

   public static boolean dh(WindowEvent var0) {
      long var10001 = 132959957013731L ^ 93590230899623L;
      Object[] var6 = new Object[]{50524040089412L};
      WindowEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static void bF(GlStateSnapshot var0) {
      GlStateSnapshot var3 = var0;
      var3.aReturningVoid();
   }

   public static LightmapEvent cH() {
      return new LightmapEvent();
   }

   public static boolean df(MovementResetEvent var0) {
      long var10001 = 100931984734702L ^ 130015176881834L;
      Object[] var6 = new Object[]{50524040089412L};
      MovementResetEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static VertexConsumer dr(VertexConsumer var0, int var1) {
      long var10001 = 45840482374323L ^ 61427585287039L;
      Object[] var10004 = new Object[]{null, null, 33462774763980L};
      var10004[1] = var1;
      var10004[0] = var0;
      Object[] var6 = var10004;
      return RenderLayerUtil.aReturningVertexConsumer(var6);
   }

   public static boolean du(MouseLookEvent var0) {
      long var10001 = 73304806263779L ^ 122424041817255L;
      Object[] var6 = new Object[]{50524040089412L};
      MouseLookEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean dp(EntityModel var0) {
      long var10001 = 6489317557621L ^ 2944810618232L;
      Object[] var5 = new Object[]{var0, 8019997083661L};
      return EntityModelManager.cReturningBoolean(var5);
   }

   public static boolean cq(FireOverlayEvent var0) {
      long var10001 = 17393333275188L ^ 37530364134768L;
      Object[] var6 = new Object[]{50524040089412L};
      FireOverlayEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static ParticleRenderEvent dz() {
      return new ParticleRenderEvent();
   }

   public static boolean ex(EventBus var0, Class var1) {
      long var10001 = 65079373955267L ^ 92987406579270L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean cZ(EntityModel var0) {
      long var10001 = 127605804472431L ^ 43784591601703L;
      Object[] var5 = new Object[]{var0, 92208378341448L};
      return EntityModelManager.bReturningBoolean(var5);
   }

   public static boolean eM(EventBus var0, Class var1) {
      long var10001 = 112942724959308L ^ 10010203634377L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean ac(WorldResetEvent var0) {
      long var10001 = 76076580297499L ^ 115188858426463L;
      Object[] var6 = new Object[]{50524040089412L};
      WorldResetEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static PlayerUpdateEvent as(EventPhase var0, float var1, float var2) {
      return new PlayerUpdateEvent(var0, var1, var2);
   }

   public static Rotation cV(RotationManager var0) {
      Object[] var4 = new Object[0];
      RotationManager var3 = var0;
      return var3.cReturningdx_C0210(var4);
   }

   public static double H(CameraPositionEvent var0) {
      Object[] var4 = new Object[0];
      CameraPositionEvent var3 = var0;
      return var3.aReturningDouble(var4);
   }

   public static MovementRotationEvent cN(EventPhase var0, float var1, float var2) {
      return new MovementRotationEvent(var0, var1, var2);
   }

   public static void K(CameraAccessor var0, double var1, double var3, double var5) {
      long var10001 = 44662717766259L ^ 96408610321417L;
      Object[] var10006 = new Object[]{null, null, null, 139845101284986L};
      var10006[2] = var5;
      var10006[1] = var3;
      var10006[0] = var1;
      Object[] var12 = var10006;
      CameraAccessor var11 = var0;
      var11.aReturningVoid(var12);
   }

   public static boolean aJ(EntityBoundingBoxEvent var0) {
      long var10001 = 125798267620556L ^ 105116010562440L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityBoundingBoxEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Rotation aA(RotationManager var0) {
      Object[] var4 = new Object[0];
      RotationManager var3 = var0;
      return var3.cReturningdx_C0210(var4);
   }

   public static BlockVisibilityEvent A(Block var0) {
      return new BlockVisibilityEvent(var0);
   }

   public static Float p(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningBoxedFloat(var4);
   }

   public static boolean aW(EntityRotationEvent var0) {
      long var10001 = 54688005761902L ^ 31123486696490L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityRotationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Matrix4f eH(Matrix4fc var0) {
      return new Matrix4f(var0);
   }

   public static AttackCooldownEvent dB() {
      return new AttackCooldownEvent();
   }

   public static boolean bd(LightmapEvent var0) {
      long var10001 = 4230275967207L ^ 50764289337251L;
      Object[] var6 = new Object[]{50524040089412L};
      LightmapEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Color ea(int var0, int var1, int var2) {
      return new Color(var0, var1, var2);
   }

   public static KeyInputEvent cx(int var0, int var1) {
      return new KeyInputEvent(var0, var1);
   }

   public static boolean bV(EntityReachEvent var0) {
      long var10001 = 117363669430991L ^ 78401686027659L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityReachEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static WindowEvent dg(Window var0) {
      return new WindowEvent(var0);
   }

   public static GameRendererAccessor bQ(GameRenderer var0) {
      return new GameRendererAccessor(var0);
   }

   public static float ar(PlayerUpdateEvent var0) {
      Object[] var4 = new Object[0];
      PlayerUpdateEvent var3 = var0;
      return var3.bReturningFloat(var4);
   }

   public static Resource dQ(String var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.bReturningVoid(var3);
   }

   public static boolean w(OverlayStyleEvent var0) {
      long var10001 = 138032161960374L ^ 88483147120370L;
      Object[] var6 = new Object[]{50524040089412L};
      OverlayStyleEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static FrustumEvent eN(Frustum var0) {
      return new FrustumEvent(var0);
   }

   public static TotemAnimationEvent bN(int var0) {
      return new TotemAnimationEvent(var0);
   }

   public static CameraAccessor N(Camera var0) {
      return new CameraAccessor(var0);
   }

   public static boolean u(EventBus var0, Class var1) {
      long var10001 = 4098407717912L ^ 118850695932573L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean a(EventBus var0, Class var1) {
      long var10001 = 63477664416325L ^ 94668092241088L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static ScreenBackgroundTintEvent dS() {
      return new ScreenBackgroundTintEvent();
   }

   public static BlockStateUpdateEvent ey(BlockPos var0, BlockState var1) {
      return new BlockStateUpdateEvent(var0, var1);
   }

   public static Resource dI(Identifier var0) {
      Object[] var3 = new Object[]{var0};
      return PrestigeResourcePack.aReturningResource(var3);
   }

   public static float aR(Rotation var0) {
      Object[] var4 = new Object[0];
      Rotation var3 = var0;
      return var3.bReturningFloat(var4);
   }

   public static boolean ct(BlockBounceEvent var0) {
      long var10001 = 30635134688645L ^ 59576684925633L;
      Object[] var6 = new Object[]{50524040089412L};
      BlockBounceEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cA(NativePhaseEvent var0) {
      long var10001 = 52395394412836L ^ 2563217391200L;
      Object[] var6 = new Object[]{50524040089412L};
      NativePhaseEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean dD(EventBus var0, Class var1) {
      long var10001 = 14633609830464L ^ 108770293995205L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static int bP(TotemAnimationEvent var0) {
      Object[] var4 = new Object[0];
      TotemAnimationEvent var3 = var0;
      return var3.aReturningInt(var4);
   }

   public static boolean dd(TickEvent var0) {
      long var10001 = 1052461665622L ^ 49505956053522L;
      Object[] var6 = new Object[]{50524040089412L};
      TickEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static NativeRenderPhaseEvent eQ() {
      return new NativeRenderPhaseEvent();
   }

   public static Vec3d aF(MovementVectorEvent var0) {
      Object[] var4 = new Object[0];
      MovementVectorEvent var3 = var0;
      return var3.aReturningVec3d(var4);
   }

   public static PlayerSkinEvent dF(SkinTextures var0, String var1) {
      return new PlayerSkinEvent(var0, var1);
   }

   public static boolean aH(EventBus var0, Class var1) {
      long var10001 = 52148913460568L ^ 71261910180829L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean be(EventBus var0, Class var1) {
      long var10001 = 17411353340747L ^ 106067642424782L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static Optional dq(RenderLayer var0) {
      long var10001 = 46688570557338L ^ 122384759319365L;
      Object[] var5 = new Object[]{var0, 76108627388639L};
      return RenderLayerUtil.aReturningOptional(var5);
   }

   public static EntityReachEvent bU(float var0) {
      return new EntityReachEvent(var0);
   }

   public static boolean bb(EventBus var0, Class var1) {
      long var10001 = 130924759847797L ^ 27150139549168L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static Color dZ(int var0, int var1, int var2) {
      return new Color(var0, var1, var2);
   }

   public static boolean ds(EventBus var0, Class var1) {
      long var10001 = 127043731724453L ^ 30964652830240L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean bM(EventBus var0, Class var1) {
      long var10001 = 108071216735250L ^ 15291758809751L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static boolean ec(AmbientColorEvent var0) {
      long var10001 = 100200748053838L ^ 130645498542602L;
      Object[] var6 = new Object[]{50524040089412L};
      AmbientColorEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean eh(EventBus var0, Class var1) {
      long var10001 = 99498662657777L ^ 59221153450100L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static void eF(List var0) {
      long var10001 = 53184625159164L ^ 134851471390412L;
      Object[] var5 = new Object[]{var0, 82439963417904L};
      RenderThreadUtil.cReturningVoid(var5);
   }

   public static HurtCameraEvent bK() {
      return new HurtCameraEvent();
   }

   public static BlockBounceEvent cs() {
      return new BlockBounceEvent();
   }

   public static Color m(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static boolean ci(CrosshairRenderEvent var0) {
      long var10001 = 363032002011L ^ 50195502133919L;
      Object[] var6 = new Object[]{50524040089412L};
      CrosshairRenderEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static float bW(EntityReachEvent var0) {
      Object[] var4 = new Object[0];
      EntityReachEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static EntityRotationEvent aZ(Entity var0, EventPhase var1) {
      return new EntityRotationEvent(var0, var1);
   }

   public static void bG(GlStateSnapshot var0) {
      GlStateSnapshot var3 = var0;
      var3.aReturningVoid();
   }

   public static boolean cd(HeldItemTransformEvent var0) {
      long var10001 = 30388240738886L ^ 59720903501058L;
      Object[] var6 = new Object[]{50524040089412L};
      HeldItemTransformEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean bg(EventBus var0, Class var1) {
      long var10001 = 81320966289578L ^ 42142939418159L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static void Q(CameraAccessor var0, float var1, float var2) {
      long var10001 = 82825710011575L ^ 32986312814212L;
      Object[] var10005 = new Object[]{null, null, 93820950882867L};
      var10005[1] = var2;
      var10005[0] = var1;
      Object[] var8 = var10005;
      CameraAccessor var7 = var0;
      var7.bReturningVoid(var8);
   }

   public static void bw() {
      long var10001 = 138348372231645L ^ 78031183755277L;
      Object[] var4 = new Object[]{65058846031312L};
      Prestige.aReturningVoid(var4);
   }

   public static ProjectionMatrixAccessor bA(ProjectionMatrix2 var0) {
      return new ProjectionMatrixAccessor(var0);
   }

   public static boolean cy(KeyInputEvent var0) {
      long var10001 = 45884831730390L ^ 4711284393362L;
      Object[] var6 = new Object[]{50524040089412L};
      KeyInputEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cl(ScoreboardRenderEvent var0) {
      long var10001 = 106930815308722L ^ 84332994977014L;
      Object[] var6 = new Object[]{50524040089412L};
      ScoreboardRenderEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static SwingDurationEvent cQ(int var0) {
      return new SwingDurationEvent(var0);
   }

   public static float ao(Rotation var0) {
      Object[] var4 = new Object[0];
      Rotation var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static boolean eB() {
      long var10001 = 69468569344924L ^ 98207132846242L;
      Object[] var4 = new Object[]{112699004588862L};
      return Prestige.aReturningBoolean(var4);
   }

   public static boolean cI(LightmapEvent var0) {
      long var10001 = 35748142650619L ^ 14778045979583L;
      Object[] var6 = new Object[]{50524040089412L};
      LightmapEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static Color k(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static CameraPositionEvent E(double var0, double var2, double var4) {
      return new CameraPositionEvent(var0, var2, var4);
   }

   public static WeatherRenderEvent er() {
      return new WeatherRenderEvent();
   }

   public static EntityLabelEvent bn(Text var0, Text var1, Entity var2) {
      return new EntityLabelEvent(var0, var1, var2);
   }

   public static boolean aY(EventBus var0, Class var1) {
      long var10001 = 103437633022760L ^ 54637805608365L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static Text bj(EntityNameEvent var0) {
      Object[] var4 = new Object[0];
      EntityNameEvent var3 = var0;
      return var3.aReturningText(var4);
   }

   public static Color ee(AmbientColorEvent var0) {
      Object[] var4 = new Object[0];
      AmbientColorEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static void bx(GlStateSnapshot var0) {
      GlStateSnapshot var3 = var0;
      var3.aReturningVoid();
   }

   public static Color n(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningColor(var4);
   }

   public static boolean aX(VisualRotationManager var0) {
      Object[] var4 = new Object[0];
      VisualRotationManager var3 = var0;
      return var3.aReturningBoolean(var4);
   }

   public static boolean bS(EventBus var0, Class var1) {
      long var10001 = 76471122917311L ^ 46381280264506L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static PlayerUpdateEvent al(EventPhase var0, float var1, float var2) {
      return new PlayerUpdateEvent(var0, var1, var2);
   }

   public static HeldItemTransformEvent cc(MatrixStack var0, Arm var1, float var2, float var3) {
      return new HeldItemTransformEvent(var0, var1, var2, var3);
   }

   public static BlockVisibilityEvent b(Block var0) {
      return new BlockVisibilityEvent(var0);
   }

   public static AttackAttemptEvent aj(EventPhase var0) {
      return new AttackAttemptEvent(var0);
   }

   public static boolean R(EventBus var0, Class var1) {
      long var10001 = 11074019703671L ^ 111808579063282L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static float P(CameraRotationEvent var0) {
      Object[] var4 = new Object[0];
      CameraRotationEvent var3 = var0;
      return var3.bReturningFloat(var4);
   }

   public static boolean cC(NativePhaseEvent var0) {
      long var10001 = 13246187715410L ^ 37381602702358L;
      Object[] var6 = new Object[]{50524040089412L};
      NativePhaseEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static MovementRotationEvent cK(EventPhase var0, float var1, float var2) {
      return new MovementRotationEvent(var0, var1, var2);
   }

   public static boolean db(TickEvent var0) {
      long var10001 = 56565235947706L ^ 33541911861246L;
      Object[] var6 = new Object[]{50524040089412L};
      TickEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static PlayerNameEvent em(String var0, String var1) {
      return new PlayerNameEvent(var0, var1);
   }

   public static float s(OverlayStyleEvent var0) {
      Object[] var4 = new Object[0];
      OverlayStyleEvent var3 = var0;
      return var3.aReturningFloat(var4);
   }

   public static EntityRotationEvent aV(Entity var0, EventPhase var1) {
      return new EntityRotationEvent(var0, var1);
   }

   public static boolean bO(TotemAnimationEvent var0) {
      long var10001 = 30189672799594L ^ 59951834681902L;
      Object[] var6 = new Object[]{50524040089412L};
      TotemAnimationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static TickEvent da() {
      return new TickEvent();
   }

   public static void bv() {
      long var10001 = 71395723279828L ^ 59548100748791L;
      Object[] var4 = new Object[]{130599282874403L};
      RenderThreadUtil.hReturningVoid(var4);
   }

   public static boolean B(BlockVisibilityEvent var0) {
      long var10001 = 21388673033393L ^ 68721543769077L;
      Object[] var6 = new Object[]{50524040089412L};
      BlockVisibilityEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean az(EntityLifecycleEvent var0) {
      long var10001 = 30067742664486L ^ 60109047244898L;
      Object[] var6 = new Object[]{50524040089412L};
      EntityLifecycleEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static boolean cO(MovementRotationEvent var0) {
      long var10001 = 125515483907031L ^ 105365524139155L;
      Object[] var6 = new Object[]{50524040089412L};
      MovementRotationEvent var5 = var0;
      return var5.bReturningBoolean(var6);
   }

   public static VelocityEvent aL(double var0, double var2, double var4) {
      return new VelocityEvent(var0, var2, var4);
   }

   public static EntityLifecycleEvent aw(Entity var0, EventPhase var1) {
      return new EntityLifecycleEvent(var0, var1);
   }

   public static MouseLookEvent dt(double var0, double var2) {
      return new MouseLookEvent(var0, var2);
   }

   public static boolean cP(EventBus var0, Class var1) {
      long var10001 = 40058666276861L ^ 83342954537336L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static NativePhaseEvent cz(EventPhase var0) {
      return new NativePhaseEvent(var0);
   }

   public static Rotation aQ(RotationManager var0) {
      Object[] var4 = new Object[0];
      RotationManager var3 = var0;
      return var3.cReturningdx_C0210(var4);
   }

   public static AttackEntityEvent au(Entity var0) {
      return new AttackEntityEvent(var0);
   }

   public static AttackAttemptEvent ag(EventPhase var0) {
      return new AttackAttemptEvent(var0);
   }

   public static boolean cG(EventBus var0, Class var1) {
      long var10001 = 100892270700201L ^ 57590785855532L;
      Object[] var7 = new Object[]{var1, 122742273865349L};
      EventBus var6 = var0;
      return var6.bReturningBoolean(var7);
   }

   public static AmbientColorEvent eb(Color var0, Color var1) {
      return new AmbientColorEvent(var0, var1);
   }

   static {
      aReturningVoid();
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = c[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = b[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 44;
            yield var15;
         }
         case 1 -> {
            byte var16 = 12;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 33;
            yield var19;
         }
         case 5 -> {
            byte var20 = 62;
            yield var20;
         }
         case 6 -> {
            byte var21 = 50;
            yield var21;
         }
         case 7 -> {
            byte var22 = 11;
            yield var22;
         }
         case 8 -> {
            byte var23 = 63;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 3;
            yield var25;
         }
         case 11 -> {
            byte var26 = 48;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 23;
            yield var30;
         }
         case 16 -> {
            byte var31 = 0;
            yield var31;
         }
         case 17 -> {
            byte var32 = 35;
            yield var32;
         }
         case 18 -> {
            byte var33 = 32;
            yield var33;
         }
         case 19 -> {
            byte var34 = 25;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 26;
            yield var36;
         }
         case 22 -> {
            byte var37 = 58;
            yield var37;
         }
         case 23 -> {
            byte var38 = 28;
            yield var38;
         }
         case 24 -> {
            byte var39 = 47;
            yield var39;
         }
         case 25 -> {
            byte var40 = 18;
            yield var40;
         }
         case 26 -> {
            byte var41 = 7;
            yield var41;
         }
         case 27 -> {
            byte var42 = 46;
            yield var42;
         }
         case 28 -> {
            byte var43 = 60;
            yield var43;
         }
         case 29 -> {
            byte var44 = 54;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 43;
            yield var46;
         }
         case 32 -> {
            byte var47 = 20;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 49;
            yield var49;
         }
         case 35 -> {
            byte var50 = 38;
            yield var50;
         }
         case 36 -> {
            byte var51 = 9;
            yield var51;
         }
         case 37 -> {
            byte var52 = 52;
            yield var52;
         }
         case 38 -> {
            byte var53 = 13;
            yield var53;
         }
         case 39 -> {
            byte var54 = 34;
            yield var54;
         }
         case 40 -> {
            byte var55 = 40;
            yield var55;
         }
         case 41 -> {
            byte var56 = 4;
            yield var56;
         }
         case 42 -> {
            byte var57 = 21;
            yield var57;
         }
         case 43 -> {
            byte var58 = 6;
            yield var58;
         }
         case 44 -> {
            byte var59 = 45;
            yield var59;
         }
         case 45 -> {
            byte var60 = 17;
            yield var60;
         }
         case 46 -> {
            byte var61 = 10;
            yield var61;
         }
         case 47 -> {
            byte var62 = 42;
            yield var62;
         }
         case 48 -> {
            byte var63 = 41;
            yield var63;
         }
         case 49 -> {
            byte var64 = 53;
            yield var64;
         }
         case 50 -> {
            byte var65 = 1;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 16;
            yield var67;
         }
         case 53 -> {
            byte var68 = 36;
            yield var68;
         }
         case 54 -> {
            byte var69 = 22;
            yield var69;
         }
         case 55 -> {
            byte var70 = 27;
            yield var70;
         }
         case 56 -> {
            byte var71 = 61;
            yield var71;
         }
         case 57 -> {
            byte var72 = 59;
            yield var72;
         }
         case 58 -> {
            byte var73 = 31;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 14;
            yield var75;
         }
         case 61 -> {
            byte var76 = 29;
            yield var76;
         }
         case 62 -> {
            byte var77 = 8;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            c[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      b[0] = "% 9\u000b\u007f\u001c3 <Ql\u000b$k?W`\u001f5,(@+\u000b.";
      b[1] = void.class;
      c[1] = "java/lang/Void";
      b[2] = "f!\u000fS\u0003&p!\n\t\u00101gj\t\u000f\u001c%v-\u001e\u0018W5n-\u001c\u0013\rxR6\u001c\u000e\r?e!";
      b[3] = "\\RC-/{)rH\">4H|C):n<";
      b[4] = boolean.class;
      c[4] = "java/lang/Boolean";
      b[5] = "a\u0018x`\u0004Cw\u0018}:\u0017T`S~<\u001b@q\u0014i+PQ|";
      b[6] = "sc7\nh\t\u0006C<\u0005yFgM7\u000e}\u001c\u0013";
      b[7] = "FQ;B\u007f\u001a[Dc`>\u0017CB";
      b[8] = "\u0012S=RGx\u0004S8\bTo\u0013\u0018;\u000eX{\u0002_,\u0019\u0013N";
      b[9] = "pzD\u000f]9\u0005ZO\u0000LvdTD\u000bH,\u0010";
      b[10] = "GY\u0012G@yGY\u0005\u001bLv]\u0012\u0005\u0005LcZcR_\u001d#";
      b[11] = "\u0003rFb#%\u0015rC802\u00029@><&\u0013~W)w4\"";
      b[12] = "UE\u0017CJ\" e\u001cL[mAk\u0017G_75";
      b[13] = "R\u001b7U.4D\u001b2\u000f=#SP1\t17B\u0017&\u001ez&`";
      b[14] = "Cp\u0005]G\u00136P\u000eRV\\W^\u0005YR\u0006#";
      b[15] = "@\u0017?hj>V\u0017:2y)A\\94u=P\u001b.#>,h";
      b[16] = "Y_c@j#,\u007fhO{lMqcD\u007f69";
      b[17] = "\u007f)\u0018\r=ri)\u001dW.e~b\u001eQ\"qo%\tFiE";
      b[18] = "5[`\u0017\bC@{k\u0018\u0019\f!u`\u0013\u001dVU";
      b[19] = "\u0017G'\u0017\b\u001b\u0017G0K\u0004\u0014\r\f0U\u0004\u0001\n}b\bWEA";
      b[20] = "ws9 x_as<zkHv8?|g\\g\u007f(k,Ky";
      b[21] = "\u00124]\fnrg\u0014V\u0003\u007f=\u0006\u001a]\b{gr";
      b[22] = ":8\u000fuHj,8\n/[};s\t)Wi*4\u001e>\u001cx\u0015";
      b[23] = "3|u~olF\\~q~#'RuzzyS";
      b[24] = "u3\\Nq%\u0000\u0013WA`ja\u001d\\Jd0\u0015";
      b[25] = "D\u0005~h\u0013yR\u0005{2\u0000nENx4\fzT\to#Gj\u0016";
      b[26] = "~'1\u0011\u0016\b\u000b\u0007:\u001e\u0007Gj\t1\u0015\u0003\u001d\u001e";
      b[27] = "?zyHN\\?zn\u0014BS%1n\nBF\"@>T\u001a\r";
      b[28] = "_=S?_^*\u001dX0N\u0011K\u0013S;JK?";
      b[29] = "\u001e0tl<\\\u00008n#^@\u0007%";
      b[30] = "S=\u0018n\u000b?&\u001d\u0013a\u001apG\u0013\u0018j\u001e*3";
      b[31] = "HR\u007f\u0011\u001fD^RzK\fSI\u0019yM\u0000GX^nZKu";
      b[32] = ";\u000b+b@\u0006N+ mQI/%+fU\u0013[";
      b[33] = "U2%R^*C2 \bM=Ty#\u000eA)E>4\u0019\n8P";
      b[34] = "zn\u001b)Hv\u000fN\u0010&Y9n@\u001b-]c\u001a";
      b[35] = float.class;
      c[35] = "java/lang/Float";
      b[36] = "G\u0002F\b8\rQ\u0002CR+\u001aFI@T'\u000eW\u000eWCl\u001cy";
      b[37] = "\u0003r\u0001U(~vR\nZ91\u0017\\\u0001Q=kc";
      b[38] = "\u0010P &DG\u0006P%|WP\u0011\u001b&z[D\u0000\\1m\u0010U\f";
      b[39] = "U[sT\f\u000b {x[\u001dDAusP\u0019\u001e5";
      b[40] = "$y\u0007$~n$y\u0010xra>2\u0010frt9CK<+2";
      b[41] = "8&/:@3.&*`S$9m)f_0(*>q\u0014\u0016";
      b[42] = "q`\u0015[9#\u0004@\u001eT(leN\u0015_,6\u0011";
      b[43] = "\u001d\u0007\u0013\u0005Eq\u001f\u0019ZfNj\u0000\u001c\f\u001fI";
      b[44] = "~L LC+hL%\u0016P<\u007f\u0007&\u0010\\(n@1\u0007\u00179y";
      b[45] = "{d?HL\u000f\u000eD4G]@oJ?LY\u001a\u001b";
      b[46] = "2!\t|h 2!\u001e d/(j\u001e>d:/\u001bOf6";
      b[47] = "k\u0016J\\am\u001e6ASp\"\u007f8JXtx\u000b";
      b[48] = "ql47\u0015\u001e\u0004L?8\u0004QeB43\u0000\u000b\u0011";
      b[49] = "xeUf/{\rE^i>4lKUb:n\u0018";
      b[50] = "WTxrD\u001bAT}(W\fV\u001f~.[\u0018GXi9\u0010\tX";
      b[51] = "J_hM@\u0019?\u007fcBQV^qhIU\f*";
      b[52] = ")8nJ^y\"7\u007f\u0005#a10vL";
      b[53] = "\u0002uz\tKC\u0014u\u007fSXT\u0003>|UT@\u0012ykB\u001fQ/";
      b[54] = "_z<]iR*Z7Rx\u001dKT<Y|G?";
      b[55] = double.class;
      c[55] = "java/lang/Double";
      b[56] = "3=]v\u0010q%=X,\u0003f2v[*\u000fr#1L=D`\u0013";
      b[57] = "\u0000\f|\\\u001c\u0001u,wS\rN\u0014\"|X\t\u0014`";
      b[58] = "\u001c\u00146\u001aBs\n\u00143@Qd\u001d_0F]p\f\u0018'Q\u0016`'";
      b[59] = "3?4K8 %?1\u0011+72t2\u0017'##3%\u0000l1\u0018";
      b[60] = "0\u0012]<\u0013?E2V3\u0002p$<]8\u0006*P";
      b[61] = "\u0003,\u001a4I\u0019\u0003,\rhE\u0016\u0019g\rvE\u0003\u001e\u0016\\)\u001c";
      b[62] = "#kq^_O5kt\u0004LX\" w\u0002@L3g`\u0015\u000b[>";
      b[63] = "%*q7S)P\nz8Bf1\u0004q3F<E";
      b[64] = "\u0013Ydv\u0014f\u0005Ya,\u0007q\u0012\u0012b*\u000be\u0003Uu=@r\u000f";
      b[65] = "\u0006~U:fM\u0010~P`uZ\u00075SfyN\u0016rDq2\\=";
      b[66] = "\u0010*qW@Pe\nzXQ\u001f\u0004\u0004qSUEp";
      b[67] = "wz;8a\"\u0002Z07pmcT;<t7\u0017";
      b[68] = "\"v\u0000+\rW)y\u0011deW'v\u0002";
      b[69] = "`qon%,vqj46;a:i2:/p}~%q=U";
      b[70] = "Kx\u0010Q[8>X\u001b^Jw_V\u0010UN-+";
      b[71] = "Y\u0019!G~\u0006,9*HoIM7!Ck\u00139";
      b[72] = "_L5R~>IL0\bm)^\u00073\u000ea=O@$\u0019*,S";
      b[73] = "7j\n\u001bY\u001bBJ\u0001\u0014HT#D\n\u001fL\u000eW";
      b[74] = "X\fn=n -,e2\u007foL\"n9{58";
      b[75] = "0\"~Y8R&\"{\u0003+E1ix\u0005'Q .o\u0012lCm";
      b[76] = "Pvfgy\u000b%VmhhDDXfcl\u001e0";
      b[77] = "M\u0015,\u0001\u0019\u000eM\u0015;]\u0015\u0001W^;C\u0015\u0014P/j\u001aBV";
      b[78] = "~_\u001fe\u007f`\u000b\u007f\u0014jn/jq\u001faju\u001e";
      b[79] = "Wj&\u000bw\u0001\"J-\u0004fNCD&\u000fb\u00147";
      b[80] = "\u001e\u000f\fQi\u0012\b\u000f\t\u000bz\u0005\u001fD\n\rv\u0011\u000e\u0003\u001d\u001a=+";
      b[81] = "?\u0005AOATJ%J@P\u001b++AKTA_";
      b[82] = "\bd8k\u0014\u000b}D3d\u0005D\u001cJ8o\u0001\u001eh";
      b[83] = "K\u0019\u0014{\u00050>9\u001ft\u0014\u007f_7\u0014\u007f\u0010%+";
      b[84] = "WR.hA~\"r%gP1C|.lTk7";
      b[85] = "QAN\n\u00016$aE\u0005\u0010yEoN\u000e\u0014#1";
      b[86] = "j,\u000e\u0001:t\u001f\f\u0005\u000e+;~\u0002\u000e\u0005/a\n";
      b[87] = "*e:,/j_E1#>%>K:(:\u007fJ";
      b[88] = "YSa\u001a\"|,sj\u001533M}a\u001e7i9";
      b[89] = " 9g\u000fd\u0010U\u0019l\u0000u_4\u0017g\u000bq\u0005@";
      b[90] = "v5g\u001ck}`5bFxjw~a@t~f9vW?oS";
      b[91] = "BV-jgw7v&ev8Vx-nrb\"";
      b[92] = "\u0016^\u001d}gLc~\u0016rv\u0003\u0002p\u001dyrYv";
      b[93] = "\u0001r`g\u001aZtRkh\u000b\u0015\u0015\\`c\u000fOa";
      b[94] = "\u001bs=UP\nnS6ZAE\u000f]=QE\u001f{";
      b[95] = "DOz4.\u00151oq;?ZPaz0;\u0000$";
      b[96] = "l\u0013$F\u001cSz\u0013!\u001c\u000fDmX\"\u001a\u0003P|\u001f5\rHB8";
      b[97] = "s:\t\u0001)J\u0006\u001a\u0002\u000e8\u0005g\u0014\t\u0005<_\u0013";
      b[98] = "kpm?\u0001?\u001ePf0\u0010p\u007f^m;\u0014*\u000b";
      b[99] = "}`\u007f\f\u0012U\b@t\u0003\u0003\u001aiN\u007f\b\u0007@\u001d";
      b[100] = "M}@Lae8]KCp*YS@Htp-";
      b[101] = "\u001bE\u0016qRi\rE\u0013+A~\u001a\u000e\u0010-Mj\u000bI\u0007:\u0006z&";
      b[102] = "\t\u00002K\u0000&| 9D\u0011i\u001d.2O\u00153i";
      b[103] = "\u0001['Aj-\u001fS=\u000e\u000b(\u001fS>N%4";
      b[104] = "CEHYNw6eCV_8WkH][b#";
      b[105] = "]xQ\u001e\u001e\nKxTD\r\u001d\\3WB\u0001\tMt@UJ\u001ez";
      b[106] = "\u001bkO?2\u0018nKD0#W\u000fEO;'\r{";
      b[107] = "6Mg@\n}CmlO\u001b2\"cgD\u001fhV";
      b[108] = "\u0013\u001f\u0019RF\u0012\u0005\u001f\u001c\bU\u0005\u0012T\u001f\u000eY\u0011\u0003\u0013\b\u0019\u0012\u0003.";
      b[109] = "e\u007fYE/R\u0010_RJ>\u001dqQYA:G\u0005";
      b[110] = int.class;
      c[110] = "java/lang/Integer";
      b[111] = "9\u0010I\u000191/\u0010L[*&8[O]&2)\u001cXJm\"1";
      b[112] = "\u0011}\u001eP;\"d]\u0015_*m\u0005S\u001eT.7q";
      b[113] = "TFM\u001du?BFHGf(U\rKAj<DJ\\V!-z";
      b[114] = "L@\nz\u0006!9`\u0001u\u0017nXn\n~\u00134,";
      b[115] = long.class;
      c[115] = "java/lang/Long";
      b[116] = "\"\u001apTA2W:{[P}64pPT'B";
      b[117] = "\r\tp5U\\\r\tgiYS\u0017BgwYF\u001030.\u0000\r";
      b[118] = "\\\u0001;gOdJ\u0001>=\\s]J=;PgL\r*,\u001bw\u000b";
      b[119] = "K.LE^\u0010>\u000eGJO__\u0000LAK\u0005+";
      b[120] = "r6a\u001eIG\u0007\u0016j\u0011X\bf\u0018a\u001a\\R\u0012";
      b[121] = "\n1tU\u000ep\u007f\u0011\u007fZ\u001f?\u001e\u001ftQ\u001bej";
      b[122] = "V@K*[ZHHQe\u0013ZRBI\"\u001aA\u0012qO.\u0011F_@I.";
      b[123] = "!X;a$y7X>;7n \u0013==;z1T**pm2";
      b[124] = "MP?EKb8p4JZ-Y~?A^w-";
      b[125] = "XJ\u0003#F[SE\u0012l'UXN\u00166";
      b[126] = "4w\u0014\u0017\u001a_6oV\f\u0019'g\u0015U\u001c\bF|iS\u001f\u001c\u001bl\u0015V\u0018_\u001c2-\f\u001e\u001e^\r";
      b[127] = "\u001e\u001b\\s+\u0015Y\u0004\u0002\"+{Nv\u0006r<\u001aV\n\u0000q(GFv[g+\u001dH\u0012\u0001e8F'";
      b[128] = "4dI@0~9rMX_\u007fP!FS>d,'EGctP\"B\u0004d*hxDE&\u0015";
      b[129] = "+oA+P\u0019)wC*0JG$M%QV;\"N1\fFG'Ir\u000b\u0018\u007f}O3I'";
      b[130] = "X\u0005V|E\u007fO\u0005_n8+%MXiY3YK[}\u0004#%\u0010M~^-AJOm\u0005B";
      b[131] = "MG\u001c\"'*D\t\u001f3&\u0010\u001d6\u001b70q\u0005J\u001d4$,\u00156\u001bk4nJX\u001f9isM6";
      b[132] = "8k1\u001c\rT}\u007f&FT;h\u0016nJ\u0006ZpjhI\u0012\u0007`\u00163_\u0011]nri]\u0002\u0006\u0001";
      b[133] = "[<Gly_\u0018}Usf>\b\u0002\u0006qs_\u0010~\u0000rg\u0002\u0000\u0002\u0006,*N\u00068Frf\u000e\u0013\u0002";
      b[134] = "\u000b\b\u0007\u000eD[\t\u0010\u0005\u000f$\tgC\u000b\u0000E\u0014\u001bE\b\u0014\u0018\u0004g@\u000fW\u001fZ_\u001a\t\u0016]e";
      b[135] = "<D\u000f\n\n{\u007fDV\r:bNE\u0004\u0007[z2C\u0007\u0013\u0006jNFQ\u000e[r'\u001d\u000e^\u0002lN";
      b[136] = "rzw1r)p=%!8R\"Cr1`3:?t2tn*Cqf4=%,5;085C";
      b[137] = "t{(\u0000\u0012.v<z\u0010XU&B-\u0000\u00004<>+\u0003\u0014i,B.WT:#-j\nP?3B";
      b[138] = " ]\tc3\t,Q\u0003cR\u0004\u001d\u0005\u001623\u001ca\u0003\u0015&n\f\u001d\u0001\ne+\u0000-\u000f\u0000e9m";
      b[139] = "\u0004\u000e-g\n$\u0006\u0016/fjshE!i\u000bk\u0014C\"}V{h\u001cq?\u0010{\u0005\u0001 0\u0011\u001a";
      b[140] = "zF$hosvB1q\u0016y\u0014\u001e.gwch\u0018-s*s\u0014\u001f~e&m,\u0018s7(\u0012";
      b[141] = "@/=&j\u0005M99>\u0005\u0007$j25d\u001fXl1!9\u000f$i6b>Q\u001c30#|n";
      b[142] = "]w\u001a\u0004 l\n=\u0004F[g;u\u000e]:|Gs\rIgl;(\u001bJ=b_r\u0019Yf\r";
      b[143] = "BWx\u000eo\u000fEY/Gql\u0011h\u007f\u001b{\r\n\u0014y\u0018oP\u001ah|Fs\u000e\u0000P\"\u001dn\u0003Kh";
      b[144] = "m\u007f.$\u001e!(k9~GN>\u0002qr\u0015/%~wq\u0001r5\u0002,g\u0002(;fve\u0011sT";
      b[145] = "!}P`'\u0013s|RlNG\u0018!Sk/_d'P\u007frO\u0018 \u0003i~Q '\u000e;p.";
      b[146] = "8x-\u001c31`)6JxCh\u0017}\u001ek\"pk{\u001d\u007f\u007f`\u0017~\u0013lyg|.\u001er'?\u0017";
      b[147] = "W\u0017\u001c\r7\u0000U\u000f\u001e\fW^;\\\u0010\u00036OGZ\u0013\u0017k_;_\u0014Tl\u0001\u0003\u0005\u0012\u0015.>";
      b[148] = "\u0012i\u001eXPK\u0000dV\u0016jLj?JO\u000bW\u00169I[VGjb_X\fI\u000e8]KW&";
      b[149] = "}'i^4W<&mZs+.\u001ciX\"J6`o[6\u0017&\u001ci\t6@7g<Y{Z)\u001c";
      b[150] = "\u0017-\u0017*h,Ks\u0001+\u0013|')\u0002|rg[/\u0001h/w'(R~#i\u001f/_,-\u0016";
      b[151] = "\u0012D1Q\u0006f\u0015Jf\u0018\u0018\u0005G{6D\u0012dZ\u00070G\u00069J{5\u0019\u001agPCkB\u0007j\u001b{";
      b[152] = "ZJ``H{ET6n7k#\u0014=`Vs_\u0012>t\u000bc#Ujb\f:\u0019\u0010\"5\t\u0002";
      b[153] = "(\u001cEvv\u0016\u007fV[4\r\u001eN\u001eQ/l\u00062\u0018R;1\u0016NCD8k\u0018*\u0019F+0w";
      b[154] = ")\u007fe&4mz+n!5Sz\u0016d -2bjb#9or\u0016gu$2j\u007f<*tkt\u0016";
      b[155] = "gK\u00173\u00042/@F8\u000fK4'A/\f*,[G,\u0018w<'B+[pb\u001f\u0018-\u001a2]";
      b[156] = "i?De&!(>\u001df&\u001a:T\u0017v.{!(\u0011u:&1T\u0014!zu>;P|~p.T";
      b[157] = "lIc\u0007j2%K\u007f\u0011\u0006$]K~\u0017g>!M}\u0003:.]J.\u001560eM#G8O";
      b[158] = "\u0011T\u0019(P\u0005\u0016ZNaNfCk\u001e=D\u0007Y\u0017\u0018>PZIk\u001d`L\u0004SSC;Q\t\u0018k";
      b[159] = ")S>\u0001(0+K<\u0000HeE\u00182\u000f)\u007f9\u001e1\u001btoE\u001b6Xs1}A0\u00191\u000e";
      b[160] = "\u0015\u0012n|\u0013\u0015T\u00137\u007f\u0013.Ey=o\u001bO]\u0005;l\u000f\u0012My>8OAB\u0016zeKDRy";
      b[161] = "/f\u0012`\u0007om!Lg\b\n}\u001c\u00114\u001fkg`\u00177\u000b6w\u001c\u0010d\u001d:i$\u0017iO4\u0016";
      b[162] = "JJ\u0018RF9\rUF\u0003FW\u001a'BSQ6\u0002[DPEk\u0012'BU@oJE\u0012\u0006\u00070N'";
      b[163] = "\u0012T{?|zI\u0007#\"sFAe(4|'Z\u0019.7hzJe+au'R\fp>%~Le";
      b[164] = "\u007f\u001aXN@\u001ctM@\u001fy\u0004\u0015\u0018W\u001f\u0018\u001fi\u001eT\u000bE\u000f\u0015\u0019\u0007\u001dI\u0011-\u001e\nOGn";
      b[165] = "JPc G&\u0010HuRQ[\u0012[4i\u0007cH]u+8";
      b[166] = "(\u0007\u007f\u0007Vl*@-\u0017\u001c\u0017{>z\u0007Dv`B|\u0004P+p>yP\u0010x\u007fQ=\r\u0014}o>";
      b[167] = "\u0007<h$\u0016yU=j(\u007f->`k/\u001e5Bfh;C%>coxD{\u00069i9\u0006D";
      b[168] = "*\f\f]u\u0017-T\u001fR+}z6FZ{\u001cbJ@YoAr6E\u000b#\u0001uW\u0012U#\u0018l6";
      b[169] = "\u0006PJ\t\u001aW\u0014]\u0002G S~\u0006\u001e\u001eAK\u0002\u0000\u001d\n\u001c[~\u0005\u0019\u0010NU\u0011W\u0003\u0015DW~";
      b[170] = ")XV\u0000\u001f\u000f{YT\fvX\u0010\u0004U\u000b\u0017Cl\u0002V\u001fJS\u0010\u0005\u0005\tFM(\u0002\b[H2";
      b[171] = "\u0017\u0004},V\u001d^_k82I,_j SRPYi4\u000eB,X?wLYQ\u001fx*\u0003#";
      b[172] = "V\r\u007f*(6D\u0007,xD==X{,%%A^x8x5=\u000eo*;$_\r/z\u007fT";
      b[173] = "e\u000f;K\u0018\u001cw\u0002s\u0005\"\u0018\u001dYo\\C\u0000a_lH\u001e\u0010\u001d\u0004zKD\u001ey^xX\u001fq";
      b[174] = "\u001ck\u0010W\r!Co[E]NLV\u001aWX/T*\u001cTLrDV\u0019\u0004J4]?JA\f?FV";
      b[175] = "BMl\u0003(L\u000bOp\u0015DXsOq\u0013%@\u000fIr\u0007xPsLuD\u007f\u000eK\u0016s\u0005=1";
      b[176] = "V]S\fC\u0002\u001f_O\u001a/\u0015g_N\u001cN\u000e\u001bYM\b\u0013\u001eg^\u001e\u001e\u001f\u0000_Y\u0013L\u0011\u007f";
      b[177] = "20\u0011\u0000c\u0006 =YNY\u0002JfE\u00178\u001a6`F\u0003e\nJa\u0010@'\u00117&W\u001dhk";
      b[178] = "dK6\u0011`j:\u0010+\u001c+R4{m\u001er3,\u0007k\u001dfn<{0\u000be42\u001fj\tvo]";
      b[179] = "O?(SOdO}+\u000eW_\u001c\u0006)\u0007O>\u0004z/\u0004[c\u0014\u0006(WMo\n>/Z\u001fau";
      b[180] = " \u0005TYE\u001e']GV\u001bts?\u001e^K\u0015hC\u0018]_Hx?\u001f\u000eIDf\u0007\u0018\u0003\u001bJ\u0019";
      b[181] = "c\u0017\u0003Ku]*L\u0015_\u0011\nXL\u0014Gp\u0012$J\u0017S-\u0002XKA\u0010o\u0019%\f\u0006M c";
      b[182] = "f->/\"Nq-7=_\u001a\u001be0:>\u0002gc3.c\u0012\u001b 1)o\n&10/%s";
      b[183] = "w6!1\u0004?,ey,\u000b\u0003'\u0007r:\u0004b?{t9\u0010?/\u0007qo\rb7n*0];)\u0007";
      b[184] = "U (g\u0006\u0004\u000f8>\u0015\u0010yU (g\u0006\u0004\u000f8>\u0015";
      b[185] = "\u0006Z\rP5\u001e\u000bZ[J\u0005\u0017f\u0018XHd\f\u001a\u001e[\\9\u001cf@\u0004JdA\\GRX\u007f}";
      b[186] = "\bnf$\u001cEV5{)W}[^=+\u000e\u001c@\";(\u001aAP^`>\u0019\u001b^::<\n@1";
      b[187] = "\\V{q\u001f\u0000U\u0018x`\u001e:\f'|d\b[\u0014[zg\u001c\u0006\u0004'\u007f{\u0011V\u001eG\u007f0\u0005@\f'";
      b[188] = "\u0005i_\u0002/\u0004\u0015o\u001eSO\u000e~5B\u000b.\u0016\u00023A\u001fs\u0006~s_Y3\u001b\u0019a\u001e_5g";
      b[189] = "\u0006\u0014GA\u0018\u0018\u000b\u0014\u0011[(\u0012fV\u0012YI\n\u001aP\u0011M\u0014\u001af\u000eN[IG\\\t\u0018IR{";
      b[190] = "+A\tg,=j@Pd,\u0006y*Zt$gcV\\w0:s*Y#pi|E\u001d~tll*";
      b[191] = ",);u\u001e]vsau\u000el|\u0014>x\u0005\rgh8{\u0011Pw\u0014cm\u0012\nyp9o\u0001Q\u0016";
      b[192] = "\u0018}BKUt\u001f%QD\u000b\u001eJG\bL[\u007fP;\u000eOO\"@G\t\u001cY.^\u007f\u000e\u0011\u000b !";
      b[193] = "* Pk\u001aS(8\u0012p\u0019+zB\u0011`\bJb>\u0017c\u001c\u0017rB\u0012d_\u0010,zHb\u001eR\u0013";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = b[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = c[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            b[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  b[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(8856867170029421L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = c[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  b[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(8856867170029421L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        b[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(8856867170029421L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 65;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 66;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 73;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 112;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 239;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 200;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 65;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 66;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 73;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cS_C0147",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
