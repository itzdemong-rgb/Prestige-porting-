package dev.zprestige.prestige.api.accessor;

public class PlayerMovePacketAccessor {
}
