package dev.zprestige.prestige.api.accessor;
import dev.zprestige.prestige.api.reflect.FieldAccessor;
import dev.zprestige.prestige.api.reflect.ReflectedField;


import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class RaycastContextAccessor {
   private static final FieldAccessor a;
   private static final FieldAccessor b;
   private static final FieldAccessor c;
   private static final FieldAccessor d;
   private static final FieldAccessor e;
   private final RaycastContext f;
   private static final long g = 4408678203275L;
   private static final Object[] h = new Object[22];
   private static final String[] i = new String[22];

   public RaycastContextAccessor(RaycastContext var1) {
      this.f = var1;
   }

   public void aReturningVoid(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      var3 = 4408678203275L ^ var3;
      long var5 = var3 ^ 15014296833098L;
      FieldAccessor var10000 = a;
      Object[] var8 = new Object[]{this.f, var2, var5};
      FieldAccessor var7 = var10000;
      var7.fReturningVoid(var8);
   }

   public void bReturningVoid(Object[] var1) {
      Vec3d var4 = (Vec3d)var1[0];
      long var2 = (Long)var1[1];
      var2 = 4408678203275L ^ var2;
      long var5 = var2 ^ 44427415991661L;
      FieldAccessor var10000 = b;
      Object[] var8 = new Object[]{this.f, var4, var5};
      FieldAccessor var7 = var10000;
      var7.fReturningVoid(var8);
   }

   public void cReturningVoid(Object[] var1) {
      ShapeType var2 = (ShapeType)var1[0];
      long var3 = (Long)var1[1];
      var3 = 4408678203275L ^ var3;
      long var5 = var3 ^ 128530184976323L;
      FieldAccessor var10000 = c;
      Object[] var8 = new Object[]{this.f, var2, var5};
      FieldAccessor var7 = var10000;
      var7.fReturningVoid(var8);
   }

   public void dReturningVoid(Object[] var1) {
      FluidHandling var2 = (FluidHandling)var1[0];
      long var3 = (Long)var1[1];
      var3 = 4408678203275L ^ var3;
      long var5 = var3 ^ 135549916998937L;
      FieldAccessor var10000 = d;
      Object[] var8 = new Object[]{this.f, var2, var5};
      FieldAccessor var7 = var10000;
      var7.fReturningVoid(var8);
   }

   public void eReturningVoid(Object[] var1) {
      ShapeContext var2 = (ShapeContext)var1[0];
      long var3 = (Long)var1[1];
      var3 = 4408678203275L ^ var3;
      long var5 = var3 ^ 110733915106696L;
      FieldAccessor var10000 = e;
      Object[] var8 = new Object[]{this.f, var2, var5};
      FieldAccessor var7 = var10000;
      var7.fReturningVoid(var8);
   }

   public void fReturningVoid(Object[] var1) {
      Vec3d var5 = (Vec3d)var1[0];
      Vec3d var6 = (Vec3d)var1[1];
      ShapeType var7 = (ShapeType)var1[2];
      FluidHandling var4 = (FluidHandling)var1[3];
      Entity var8 = (Entity)var1[4];
      long var2 = (Long)var1[5];
      var2 = 4408678203275L ^ var2;
      long var9 = var2 ^ 12410403685065L;
      long var11 = var2 ^ 5379129235475L;
      long var13 = var2 ^ 29800598870146L;
      long var15 = var2 ^ 125393858525504L;
      long var17 = var2 ^ 96500699463783L;
      Object[] var20 = new Object[]{var5, var15};
      RaycastContextAccessor var19 = this;
      var19.aReturningVoid(var20);
      Object[] var22 = new Object[]{var6, var17};
      RaycastContextAccessor var21 = this;
      var21.bReturningVoid(var22);
      Object[] var24 = new Object[]{var7, var9};
      RaycastContextAccessor var23 = this;
      var23.cReturningVoid(var24);
      Object[] var26 = new Object[]{var4, var11};
      RaycastContextAccessor var25 = this;
      var25.dReturningVoid(var26);
      Entity var27 = var8;
      Object[] var29 = new Object[]{ShapeContext.of(var27), var13};
      RaycastContextAccessor var28 = this;
      var28.eReturningVoid(var29);
   }

   static {

      {

      long var10001 = 128299746416391L ^ 20586299019041L;
      aReturningVoid();
      Cipher var1;
      Cipher var10000 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(128299746416391L << var2 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[5];
      String var5 = "!¢S\u000b]§\u007f\u0090µye\b\u001eÓ°S\b¤UûößL¦h\u0010rµì\u001cy\u0096\u0089Ñm%û\u0019«ýqq";
      int var7 = "!¢S\u000b]§\u007f\u0090µye\b\u001eÓ°S\b¤UûößL¦h\u0010rµì\u001cy\u0096\u0089Ñm%û\u0019«ýqq".length();
      char var4 = 16;
      int var19 = -1;

      label28:
      while (true) {
         String var20 = var5.substring(++var19, var19 + var4);
         // while (true) {
            byte[] var8 = var1.doFinal(var20.getBytes("ISO-8859-1"));
            String var27 = a(var8).intern();
            switch (var22) {
               case 0:
                  var0[var6++] = var27;
                  if ((var19 += var4) >= var7) {
                     Object[] var13 = new Object[]{RaycastContext.class, var0[1], Vec3d.class, 112188903987238L};
                     a = ReflectedField.aReturningbO_C0085(var13);
                     Object[] var14 = new Object[]{RaycastContext.class, var0[3], Vec3d.class, 112188903987238L};
                     b = ReflectedField.aReturningbO_C0085(var14);
                     Object[] var15 = new Object[]{RaycastContext.class, var0[2], ShapeType.class, 112188903987238L};
                     c = ReflectedField.aReturningbO_C0085(var15);
                     Object[] var16 = new Object[]{RaycastContext.class, var0[4], FluidHandling.class, 112188903987238L};
                     d = ReflectedField.aReturningbO_C0085(var16);
                     Object[] var17 = new Object[]{RaycastContext.class, var0[0], ShapeContext.class, 112188903987238L};
                     e = ReflectedField.aReturningbO_C0085(var17);
                     break;
                  }

                  var4 = var5.charAt(var19);
                  break;
               default:
                  var0[var6++] = var27;
                  if ((var19 += var4) < var7) {
                     var4 = var5.charAt(var19);
                     continue label28;
                  }

                  var5 = "\u0098zrÜ`ÏÐ®\bVÝ\u0003ÛÍÌ?}";
                  var7 = "\u0098zrÜ`ÏÐ®\bVÝ\u0003ÛÍÌ?}".length();
                  var4 = '\b';
                  var19 = -1;
            }

            var20 = var5.substring(++var19, var19 + var4);
            var22 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 3;
            yield var15;
         }
         case 1 -> {
            byte var16 = 5;
            yield var16;
         }
         case 2 -> {
            byte var17 = 48;
            yield var17;
         }
         case 3 -> {
            byte var18 = 54;
            yield var18;
         }
         case 4 -> {
            byte var19 = 6;
            yield var19;
         }
         case 5 -> {
            byte var20 = 16;
            yield var20;
         }
         case 6 -> {
            byte var21 = 31;
            yield var21;
         }
         case 7 -> {
            byte var22 = 42;
            yield var22;
         }
         case 8 -> {
            byte var23 = 36;
            yield var23;
         }
         case 9 -> {
            byte var24 = 27;
            yield var24;
         }
         case 10 -> {
            byte var25 = 49;
            yield var25;
         }
         case 11 -> {
            byte var26 = 50;
            yield var26;
         }
         case 12 -> {
            byte var27 = 21;
            yield var27;
         }
         case 13 -> {
            byte var28 = 0;
            yield var28;
         }
         case 14 -> {
            byte var29 = 57;
            yield var29;
         }
         case 15 -> {
            byte var30 = 43;
            yield var30;
         }
         case 16 -> {
            byte var31 = 61;
            yield var31;
         }
         case 17 -> {
            byte var32 = 35;
            yield var32;
         }
         case 18 -> {
            byte var33 = 40;
            yield var33;
         }
         case 19 -> {
            byte var34 = 29;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 25;
            yield var36;
         }
         case 22 -> {
            byte var37 = 9;
            yield var37;
         }
         case 23 -> {
            byte var38 = 34;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 24;
            yield var40;
         }
         case 26 -> {
            byte var41 = 39;
            yield var41;
         }
         case 27 -> {
            byte var42 = 12;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 14;
            yield var44;
         }
         case 30 -> {
            byte var45 = 26;
            yield var45;
         }
         case 31 -> {
            byte var46 = 7;
            yield var46;
         }
         case 32 -> {
            byte var47 = 63;
            yield var47;
         }
         case 33 -> {
            byte var48 = 13;
            yield var48;
         }
         case 34 -> {
            byte var49 = 58;
            yield var49;
         }
         case 35 -> {
            byte var50 = 37;
            yield var50;
         }
         case 36 -> {
            byte var51 = 46;
            yield var51;
         }
         case 37 -> {
            byte var52 = 44;
            yield var52;
         }
         case 38 -> {
            byte var53 = 51;
            yield var53;
         }
         case 39 -> {
            byte var54 = 23;
            yield var54;
         }
         case 40 -> {
            byte var55 = 28;
            yield var55;
         }
         case 41 -> {
            byte var56 = 56;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 60;
            yield var58;
         }
         case 44 -> {
            byte var59 = 8;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 1;
            yield var61;
         }
         case 47 -> {
            byte var62 = 17;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 38;
            yield var64;
         }
         case 50 -> {
            byte var65 = 22;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 4;
            yield var67;
         }
         case 53 -> {
            byte var68 = 19;
            yield var68;
         }
         case 54 -> {
            byte var69 = 32;
            yield var69;
         }
         case 55 -> {
            byte var70 = 20;
            yield var70;
         }
         case 56 -> {
            byte var71 = 55;
            yield var71;
         }
         case 57 -> {
            byte var72 = 41;
            yield var72;
         }
         case 58 -> {
            byte var73 = 10;
            yield var73;
         }
         case 59 -> {
            byte var74 = 53;
            yield var74;
         }
         case 60 -> {
            byte var75 = 59;
            yield var75;
         }
         case 61 -> {
            byte var76 = 15;
            yield var76;
         }
         case 62 -> {
            byte var77 = 33;
            yield var77;
         }
         default -> 11;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "\fK\u0004/RR\fK\u0013s^]\u0016\u0000\u0013m^H\u0011qC6\r\r";
      h[1] = "9X7Z\u0011u9X \u0006\u001dz#\u0013 \u0018\u001do$brFE+";
      h[2] = "{=h0\u00001m=mj\u0013&zvnl\u001f2k1y{T\u0016";
      h[3] = " \u00075/D\u001eU'> UQ4)5+Q\u000b@";
      h[4] = void.class;
      i[4] = "java/lang/Void";
      h[5] = "c2M\u000f\u0013~\u0016\u0012F\u0000\u00021w\u001cM\u000b\u0006k\u0003";
      h[6] = "?Un\u000e&5Jue\u00017z+{n\n3 _";
      h[7] = "?u,8*gJU'7;(+[,<?r_";
      h[8] = "\\`A\u0018W;)@J\u0017FtHNA\u001cB.<";
      h[9] = "RB-=K`DB(gXwS\t+aTcBN<v\u001fry";
      h[10] = "(&g=\u0016@]\u0006l2\u0007\u000f<\bg9\u0003UH";
      h[11] = "#,!}Q75,$'B \"g'!N43 06\u0005$\u0015";
      h[12] = "%W#l8\u000bPw(c)D1y#h-\u001eE";
      h[13] = "\f'&\\\u0003V\u0007(7\u0013bX\f#3I";
      h[14] = "4z\u0004k(1/y\u001a\u0000vb\" \rlD6`y[=\u0013s;qS>-`5#jj)a5{Tq*\u007f^";
      h[15] = "\f\u000e\u00002\u0017pTU\u000edwd5[\u0001$\u001eo\u0005PT`\b\u000e\u000e[\n>M?T\f\u001d$w";
      h[16] = "c\u0007[\u001dH;;\\UK()ZRZ\u000bA$jY\u000fOWEaRQ\u0011\u0012t;\u0005F\u000b(";
      h[17] = "x~YV.\u0011\")\u0005_O\u0001F#\u0002V&\u000ev(W\u00120o}#\tLu^'t\u001eVO";
      h[18] = "`L6\u001cF88\u00178J&-Y\u00197\nO'i\u0012bNYFb\u0019<\u0010\u001cw8N+\n&";
      h[19] = "k|\u0019\u001b\u0003P3'\u0017McGR)\u0018\r\nOb\"MI\u001c.i)\u0013\u0017Y\u001f3~\u0004\rc";
      h[20] = "*\u001a0\\{w*\u0006\"C\u0011#\u0015O;Zx+%Dn\u001enJ+\u0012`Zp4qE<S\u0011";
      h[21] = "H\u001a\\k%\u0015\u0010AR=E\u0006qO]},\nAD\b9:kJOVg\u007fZ\u0010\u0018A}E";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(945017278536515L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(945017278536515L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(945017278536515L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 106;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 241;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 65;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 165;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 170;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 111;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 106;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 241;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 65;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/W_C0445",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/W" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
