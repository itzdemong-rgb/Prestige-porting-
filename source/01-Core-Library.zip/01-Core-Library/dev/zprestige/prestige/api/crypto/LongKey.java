package dev.zprestige.prestige.api.crypto;

public interface LongKey {
   void a(LongKey var1);

   int[] b();

   long a(long var1);

   void b(long var1);

   boolean b(LongKey var1);
}
