package dev.zprestige.prestige.api.crypto;

import java.util.ArrayList;
import java.util.Vector;

public class LongKeyState implements LongKey {
   private long a;
   private int[] b;
   private LongKey c;
   private long d;
   private long[] j;
   private static long[] k = new long[64];
   public static int[] e;
   private static ArrayList f;
   private static Vector m;
   private static int i;
   private static Object o;
   private static int h = 52;
   private static int l = 128;
   private static int n = 17;

   public static Object g() {
      return o;
   }

   public static LongKey a(long var0, long var2, Object var4) {
      long var12;
      int var9 = (var12 = var0 - 0L) == 0L ? 0 : (var12 < 0L ? -1 : 1);
      byte var8;
      if (var9 > 0) {
         byte var10 = 1;
         var8 = var10;
      } else {
         var8 = 0;
      }

      LongKeyRegistry.aReturningVoid(dev.prestige.recovery.SourceSupport.asBoolean(var8));
      LongKey var5 = d(var0);
      LongKey var6 = d(var2);
      LongKey var7 = LongKeyRegistry.aReturningVoid(var5, var6);
      Object var11 = var4;
      if (var11 != null) {
         m.add(var4);
      }

      return var7;
   }

   public static LongKey c(long var0) {
      int var2 = (int)a(var0, h, 63, e, k);
      int var5 = i;
      int var4 = var2;
      if (var4 < var5) {
         return (LongKey)f.get(var2);
      }

      int var6 = f.size() % l;
      if (var6 == 0) {
         e = (int[])e.clone();
      }

      LongKeyState var3 = new LongKeyState(var0);
      f.add(var3);
      return var3;
   }

   private static LongKey d(long var0) {
      return new LongKeyState(var0);
   }

   public static void a(LongKeyRegistry var0) {
      i = f.size();
      c();
      var0.dReturningVoid();
   }

   public static void b(LongKeyRegistry var0) {
      c();
      int[] var10000 = e = new int[64];
      var10000[0] = -45;
      var10000[1] = -24;
      var10000[2] = -18;
      var10000[3] = -32;
      var10000[4] = -24;
      var10000[5] = -17;
      var10000[6] = -48;
      var10000[7] = -10;
      var10000[8] = -21;
      var10000[9] = -7;
      var10000[10] = -33;
      var10000[11] = -29;
      var10000[12] = -48;
      var10000[13] = -20;
      var10000[14] = -48;
      var10000[15] = -27;
      var10000[16] = 7;
      var10000[17] = 10;
      var10000[18] = -40;
      var10000[19] = -13;
      var10000[20] = 18;
      var10000[21] = -6;
      var10000[22] = 17;
      var10000[23] = -1;
      var10000[24] = 1;
      var10000[25] = 24;
      var10000[26] = -31;
      var10000[27] = 6;
      var10000[28] = 24;
      var10000[29] = 21;
      var10000[30] = -14;
      var10000[31] = -19;
      var10000[32] = 13;
      var10000[33] = 20;
      var10000[34] = -18;
      var10000[35] = 32;
      var10000[36] = -12;
      var10000[37] = -14;
      var10000[38] = -8;
      var10000[39] = -17;
      var10000[40] = 29;
      var10000[41] = -8;
      var10000[42] = 27;
      var10000[43] = 33;
      var10000[44] = 14;
      var10000[45] = 45;
      var10000[46] = 8;
      var10000[47] = -16;
      var10000[48] = 12;
      var10000[49] = 8;
      var10000[50] = 19;
      var10000[51] = 14;
      var10000[52] = 18;
      var10000[53] = -6;
      var10000[54] = 48;
      var10000[55] = -6;
      var10000[56] = 17;
      var10000[57] = 31;
      var10000[58] = 40;
      var10000[59] = 6;
      var10000[60] = 48;
      var10000[61] = 6;
      var10000[62] = 48;
      var10000[63] = 16;
      var0.cReturningVoid();
   }

   private LongKeyState(long var1) {
      this.a = var1;
      this.b = e;
      this.j = k;
   }

   @Override
   public long a(long var1) {
      long var3 = this.aReturningVoid(8, 55);
      long var5 = this.a ^ var1 ^ this.d;
      this.a = var5;
      LongKey var7 = this.c;
      if (var7 != null) {
         this.c.aReturningVoid(var1);
      }

      return var3;
   }

   @Override
   public void b(long var1) {
      this.d = var1;
   }

   @Override
   public void a(LongKey var1) {
      LongKey var3 = var1;
      LongKeyState var2 = this;
      if (var2 != var3) {
         LongKey var4 = this.c;
         if (var4 == null) {
            this.c = var1;
         } else {
            this.c.aReturningVoid(var1);
         }
      }
   }

   @Override
   public int hashCode() {
      return (int)this.aReturningVoid(8);
   }

   @Override
   public boolean equals(Object var1) {
      Object var4 = var1;
      LongKeyState var3 = this;
      if (var3 == var4) {
         return true;
      }

      boolean var5 = var1 instanceof LongKeyState;
      if (var5) {
         long var8;
         int var6 = (var8 = this.aReturningVoid(56) - ((LongKeyState)var1).aReturningVoid(56)) == 0L ? 0 : (var8 < 0L ? -1 : 1);
         byte var2;
         if (!((var6) != 0)) {
            byte var7 = 1;
            var2 = var7;
         } else {
            var2 = 0;
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(var2);
      } else {
         return false;
      }
   }

   @Override
   public boolean b(LongKey var1) {
      LongKey var4 = var1;
      LongKeyState var3 = this;
      if (var3 == var4) {
         return true;
      }

      boolean var5 = var1 instanceof LongKeyState;
      if (var5) {
         long var8;
         int var6 = (var8 = this.aReturningVoid(56, 63) - ((LongKeyState)var1).aReturningVoid(56, 63) - 0L) == 0L ? 0 : (var8 < 0L ? -1 : 1);
         byte var2;
         if (var6 <= 0) {
            byte var7 = 1;
            var2 = var7;
         } else {
            var2 = 0;
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(var2);
      } else {
         return true;
      }
   }

   @Override
   public int[] b() {
      return this.b;
   }

   private long a(int var1) {
      return this.aReturningVoid(0, var1 - 1);
   }

   private long a(int var1, int var2) {
      return a(this.a, var1, var2, this.b, this.j);
   }

   private static long a(long var0, int var2, int var3, int[] var4, long[] var5) {
      int var8 = var4.length;
      while (true) {
         int var14 = var8;
         int var13 = var9;
         if (var13 >= var14) {
            long var20 = var6;
            long var11 = (long)(63 - var3);
            long var18 = var11;
            if (var18 > 0) {
               var20 <<= var11;
            }

            long var21 = (long)(var2 + 64 - 1 - var3);
            long var19 = var21;
            if (var19 > 0) {
               var20 >>>= var21;
            }

            return var20;
         }

         long var10 = var0 & k[var9];
         long var12 = (long)var4[var9];
         long var22;
         int var15 = (var22 = var10 - 0L) == 0L ? 0 : (var22 < 0L ? -1 : 1);
         if (((var15) != 0)) {
            long var16 = var12;
            if (var16 > 0) {
               var10 >>>= var12;
            } else {
               long var17 = var12;
               if (var17 < 0) {
                  var10 <<= ~var12 + 1;
               }
            }

            var6 |= var10;
         }

         var9++;
      }
   }

   private static void c() {
      a(0, f.size() - 1, f, new ArrayList(f), 0);
   }

   private static void a(int var0, int var1, ArrayList var2, ArrayList var3, int var4) {
      int var7 = var1;
      int var6 = var0;
      if (var6 < var7) {
         int var5 = var0 + (var1 - var0) / 2;
         var4++;
         int var9 = n;
         int var8 = var4;
         if (var8 < var9) {
            a(var0, var5, var2, var3, var4);
            a(var5 + 1, var1, var2, var3, var4);
         }

         a(var0, var5, var1, var2, var3);
      }
   }

   private static void a(int var0, int var1, int var2, ArrayList var3, ArrayList var4) {
      int var5 = var0;
      int var6 = var1 + 1;
      int var7 = var0;

      while (true) {
         int var9 = var2;
         int var8 = var7;
         if (var8 > var9) {
            while (true) {
               int var11 = var1;
               int var10 = var5;
               if (var10 > var11) {
                  break;
               }

               int var13 = var2;
               int var12 = var6;
               if (var12 > var13) {
                  break;
               }

               boolean var14 = ((LongKey)var4.get(var5)).bReturningVoid((LongKey)var4.get(var6));
               LongKey var17;
               if (var14) {
                  var17 = (LongKey)var4.get(var5++);
               } else {
                  var17 = (LongKey)var4.get(var6++);
               }

               var3.set(var0, var17);
               var0++;
            }

            while (true) {
               int var16 = var1;
               int var15 = var5;
               if (var15 > var16) {
                  return;
               }

               var3.set(var0, var4.get(var5));
               var0++;
               var5++;
            }
         }

         var4.set(var7, var3.get(var7));
         var7++;
      }
   }

   static {
      {

      long var0 = 1L;
      while (true) {
         byte var4 = 64;
         int var3 = var2;
         if (var3 >= var4) {
            o = new Object();
            m = new Vector();
            f = new ArrayList();
            a0();
            i = f.size();
            c();
            break;
         }

         k[var2] = var0;
         var0 <<= 1;
         var2++;
      }
   
      }
}

   private static void a0() {
      e = new int[]{
         -21,
         -18,
         -53,
         -7,
         -56,
         -21,
         -14,
         -44,
         -42,
         -54,
         7,
         -30,
         -25,
         -36,
         -24,
         -12,
         -6,
         -42,
         -27,
         18,
         14,
         21,
         6,
         -10,
         -23,
         -11,
         21,
         12,
         -14,
         -17,
         -13,
         -26,
         -16,
         10,
         -27,
         -23,
         11,
         25,
         24,
         -13,
         -4,
         30,
         14,
         13,
         4,
         27,
         17,
         23,
         16,
         36,
         42,
         44,
         13,
         -3,
         -8,
         53,
         3,
         26,
         23,
         42,
         56,
         27,
         8,
         54
      };
      f.add(new LongKeyState(-5815150067372710800L));
      f.add(new LongKeyState(-8531530570271033214L));
      f.add(new LongKeyState(-3107579684980133701L));
      f.add(new LongKeyState(-141617246379761525L));
      f.add(new LongKeyState(-5452827649041059861L));
      f.add(new LongKeyState(-7877672406555896800L));
      f.add(new LongKeyState(2586024620548855842L));
      f.add(new LongKeyState(761402728745156090L));
      f.add(new LongKeyState(-4030831176629897982L));
      f.add(new LongKeyState(-8292671514207004294L));
      f.add(new LongKeyState(2821659662072990506L));
      f.add(new LongKeyState(-8000604450647685814L));
      f.add(new LongKeyState(-8806956412202871070L));
      f.add(new LongKeyState(6521294504186122226L));
      f.add(new LongKeyState(-2961628107931399895L));
      f.add(new LongKeyState(-5732341135403628606L));
      f.add(new LongKeyState(6746428748749206185L));
      f.add(new LongKeyState(6979030215887911321L));
      f.add(new LongKeyState(-4953861574996169991L));
      f.add(new LongKeyState(4363142947363356507L));
      f.add(new LongKeyState(-7810072738973951565L));
      f.add(new LongKeyState(4984315947028967203L));
      f.add(new LongKeyState(6795313653699923096L));
      f.add(new LongKeyState(-5069655910612040520L));
      f.add(new LongKeyState(7200937653332880691L));
      f.add(new LongKeyState(-4889244984641610190L));
      f.add(new LongKeyState(-6348530327548465021L));
      f.add(new LongKeyState(-2614785344548696127L));
      f.add(new LongKeyState(383886009557199251L));
      f.add(new LongKeyState(-523766929999107726L));
      f.add(new LongKeyState(4902721056622113803L));
      f.add(new LongKeyState(9131969644715793650L));
      f.add(new LongKeyState(1226217631517559083L));
      f.add(new LongKeyState(-7869686036124409200L));
      f.add(new LongKeyState(-958729190965890342L));
      f.add(new LongKeyState(503911243827391873L));
      f.add(new LongKeyState(8210666835634210800L));
      f.add(new LongKeyState(-346339189724425949L));
      f.add(new LongKeyState(-3663952229289450424L));
      f.add(new LongKeyState(598001709958669392L));
      f.add(new LongKeyState(-5382599465050288607L));
      f.add(new LongKeyState(6682562594495427322L));
      f.add(new LongKeyState(8680378056801070731L));
      f.add(new LongKeyState(-2918830989805198718L));
      f.add(new LongKeyState(8704619220764411947L));
      f.add(new LongKeyState(-5116914819833921389L));
      f.add(new LongKeyState(5022446002895558499L));
      f.add(new LongKeyState(-2606637789080219912L));
      f.add(new LongKeyState(2968257109556035200L));
      f.add(new LongKeyState(-723687973924544224L));
      f.add(new LongKeyState(2471974225960384754L));
      f.add(new LongKeyState(-1750432521909409816L));
      f.add(new LongKeyState(-3678348705457350093L));
      f.add(new LongKeyState(8275331946907544802L));
      f.add(new LongKeyState(5959546952554976331L));
      f.add(new LongKeyState(-7021789052358034645L));
      f.add(new LongKeyState(-5142675859271545144L));
      f.add(new LongKeyState(3008702500131534865L));
      f.add(new LongKeyState(7319108409698703970L));
      f.add(new LongKeyState(9143710273239982475L));
      f.add(new LongKeyState(8529441447808265392L));
      f.add(new LongKeyState(3235216218379250929L));
      f.add(new LongKeyState(-2049297308917426720L));
      f.add(new LongKeyState(-3593455414354363128L));
      f.add(new LongKeyState(8297251313383750705L));
      f.add(new LongKeyState(-5957270218558789942L));
      f.add(new LongKeyState(-8639590583320153965L));
      f.add(new LongKeyState(-2307811645342272213L));
      f.add(new LongKeyState(-2003829269579360119L));
      f.add(new LongKeyState(-8368130041608345438L));
      f.add(new LongKeyState(3706742023852102288L));
      f.add(new LongKeyState(-4122202021021073528L));
      f.add(new LongKeyState(7983661313057977105L));
      f.add(new LongKeyState(3803520026193168731L));
      f.add(new LongKeyState(-5750166558858661791L));
      f.add(new LongKeyState(-3442454600124889574L));
      f.add(new LongKeyState(-7649987394653260134L));
      f.add(new LongKeyState(7634608176795025545L));
      f.add(new LongKeyState(3392558974726884954L));
      f.add(new LongKeyState(-6205512464371302719L));
      f.add(new LongKeyState(-1781292717705893782L));
      f.add(new LongKeyState(9173827553262769457L));
      f.add(new LongKeyState(9050766414485901528L));
      f.add(new LongKeyState(9183228538080393435L));
      f.add(new LongKeyState(-6835822123237608749L));
      f.add(new LongKeyState(1082237099890043361L));
      f.add(new LongKeyState(3992611112916459010L));
      f.add(new LongKeyState(3357248621046599545L));
      f.add(new LongKeyState(1162424161038065184L));
      f.add(new LongKeyState(-3637617702580096077L));
      f.add(new LongKeyState(-7134823484283329421L));
      f.add(new LongKeyState(3530716396533312721L));
      f.add(new LongKeyState(8392379887562310665L));
      f.add(new LongKeyState(697649708560218777L));
      f.add(new LongKeyState(7707983471303071266L));
      f.add(new LongKeyState(2035317371510377946L));
      f.add(new LongKeyState(713746239878914624L));
      f.add(new LongKeyState(1282228515849916904L));
      f.add(new LongKeyState(-2497735386868910264L));
      f.add(new LongKeyState(-8273424858933573997L));
      f.add(new LongKeyState(5862250323037647288L));
      f.add(new LongKeyState(7698976272048199202L));
      f.add(new LongKeyState(-1244154961633777640L));
      f.add(new LongKeyState(-4611192131347876493L));
      f.add(new LongKeyState(-1393822606813633511L));
      f.add(new LongKeyState(2106180289929807001L));
      f.add(new LongKeyState(-4219219491010772301L));
      f.add(new LongKeyState(2674859862123718361L));
      f.add(new LongKeyState(3947417395791151800L));
      f.add(new LongKeyState(-3057953270709536526L));
      f.add(new LongKeyState(8133715741145433569L));
      f.add(new LongKeyState(-6233478012053246464L));
      f.add(new LongKeyState(-8025034945387657752L));
      f.add(new LongKeyState(-209595575761319957L));
      f.add(new LongKeyState(-7641464089741551968L));
      f.add(new LongKeyState(3327561716095188760L));
      f.add(new LongKeyState(2404863123302678721L));
      f.add(new LongKeyState(-6189439559580768271L));
      f.add(new LongKeyState(2356094019614196432L));
      f.add(new LongKeyState(5179624650237540258L));
      f.add(new LongKeyState(-505752531489625246L));
      f.add(new LongKeyState(5058820640090688435L));
      f.add(new LongKeyState(-3372332013121267520L));
      f.add(new LongKeyState(2711322404405582256L));
      f.add(new LongKeyState(1859465745629357625L));
      f.add(new LongKeyState(-6638974723622729454L));
      f.add(new LongKeyState(611668114698314434L));
      f.add(new LongKeyState(-711558772612344392L));
      f.add(new LongKeyState(-6837080080565360445L));
      f.add(new LongKeyState(8798117494818189769L));
      f.add(new LongKeyState(-3836391344606109688L));
      f.add(new LongKeyState(-7561782662796289190L));
      f.add(new LongKeyState(2136031249756491819L));
      f.add(new LongKeyState(5152603052473185714L));
      f.add(new LongKeyState(6275687408355379497L));
      f.add(new LongKeyState(-3303908933617804133L));
      f.add(new LongKeyState(347287453041641632L));
      f.add(new LongKeyState(-7471475513152634278L));
      f.add(new LongKeyState(7447784137588973658L));
      f.add(new LongKeyState(-4458465609166127312L));
      f.add(new LongKeyState(9111602367551709529L));
      f.add(new LongKeyState(-4537346529071138429L));
      f.add(new LongKeyState(-2763019859446278767L));
      f.add(new LongKeyState(-8784885039600562623L));
      f.add(new LongKeyState(-3981556119381407742L));
      f.add(new LongKeyState(257125796651051482L));
      f.add(new LongKeyState(6534892657643649408L));
      f.add(new LongKeyState(8655962593490938179L));
      f.add(new LongKeyState(-6553548419700174319L));
      f.add(new LongKeyState(-1249069298318155312L));
      f.add(new LongKeyState(-1517806059919485638L));
      f.add(new LongKeyState(6306874611224847578L));
      f.add(new LongKeyState(806295766266262433L));
      f.add(new LongKeyState(-8974775250488994319L));
      f.add(new LongKeyState(6578211694221437146L));
      f.add(new LongKeyState(1761437113416725075L));
      f.add(new LongKeyState(1522720673875839090L));
      f.add(new LongKeyState(-7775690187028083095L));
      e = (int[])e.clone();
      f.add(new LongKeyState(-3091924301407677719L));
      f.add(new LongKeyState(-6629941585406794750L));
      f.add(new LongKeyState(1059927256708703008L));
      f.add(new LongKeyState(-147370371885359742L));
      f.add(new LongKeyState(-2462887437938334495L));
      f.add(new LongKeyState(7723745566799571450L));
      f.add(new LongKeyState(6342226500618312728L));
      f.add(new LongKeyState(7233024245860060571L));
      f.add(new LongKeyState(2783605245521427432L));
      f.add(new LongKeyState(-7471939531205262413L));
      f.add(new LongKeyState(5085962443611550016L));
      f.add(new LongKeyState(3767685290687487723L));
      f.add(new LongKeyState(-19965482734308277L));
      f.add(new LongKeyState(8692324015404981128L));
      f.add(new LongKeyState(6969893139111503281L));
      f.add(new LongKeyState(7692386095554353409L));
      f.add(new LongKeyState(-6697993267496441336L));
      f.add(new LongKeyState(-1219066043187826263L));
      f.add(new LongKeyState(4925907625342080051L));
      f.add(new LongKeyState(-1049752884295000989L));
      f.add(new LongKeyState(8895003236094672210L));
      f.add(new LongKeyState(-741702370286542032L));
      f.add(new LongKeyState(8890434558656438354L));
      f.add(new LongKeyState(8032311248388650139L));
      f.add(new LongKeyState(-3605015693086368344L));
      f.add(new LongKeyState(588700080252590920L));
      f.add(new LongKeyState(4278285782649015705L));
      f.add(new LongKeyState(4833208498077047067L));
      f.add(new LongKeyState(5091926313658465155L));
      f.add(new LongKeyState(8479080291135819395L));
      f.add(new LongKeyState(9077025342225615160L));
      f.add(new LongKeyState(2404347819643974314L));
      f.add(new LongKeyState(4868595385777159482L));
      f.add(new LongKeyState(3252076808190060384L));
      f.add(new LongKeyState(6025752694753386843L));
      f.add(new LongKeyState(-7480618220054197349L));
      f.add(new LongKeyState(2102462223207548411L));
      f.add(new LongKeyState(-5594049121205141941L));
      f.add(new LongKeyState(1036301848948427784L));
      f.add(new LongKeyState(-2151954783998101839L));
      f.add(new LongKeyState(-4333118689596044583L));
      f.add(new LongKeyState(-3080626484911218518L));
      f.add(new LongKeyState(2751242919363277467L));
      f.add(new LongKeyState(-6620231744183881805L));
      f.add(new LongKeyState(-6818863511757887063L));
      f.add(new LongKeyState(3401484356392208139L));
      f.add(new LongKeyState(-5358875045449288600L));
      f.add(new LongKeyState(9200714608364923761L));
      f.add(new LongKeyState(-6755577180502754496L));
      f.add(new LongKeyState(-5833825583068227069L));
      f.add(new LongKeyState(4226185079737334225L));
      f.add(new LongKeyState(5187794166555372731L));
      f.add(new LongKeyState(-1233531184178166717L));
      f.add(new LongKeyState(1367628346752532266L));
      f.add(new LongKeyState(-3351850674415216349L));
      f.add(new LongKeyState(8731189759729706123L));
      f.add(new LongKeyState(746987078690859704L));
      f.add(new LongKeyState(-5795759395368970399L));
      f.add(new LongKeyState(-3095140366607962256L));
      f.add(new LongKeyState(6115592816287274827L));
      f.add(new LongKeyState(3545440152065392643L));
      f.add(new LongKeyState(3500852437052037378L));
      f.add(new LongKeyState(-4042128292485781349L));
      f.add(new LongKeyState(5521160384965091361L));
      f.add(new LongKeyState(2665615838359371474L));
      f.add(new LongKeyState(-9173914894045111413L));
      f.add(new LongKeyState(-5261998034521034238L));
      f.add(new LongKeyState(8722896689355069832L));
      f.add(new LongKeyState(-7617411266194000096L));
      f.add(new LongKeyState(-1355669610161899038L));
      f.add(new LongKeyState(-7459441549941139087L));
      f.add(new LongKeyState(-3458163826949395623L));
      f.add(new LongKeyState(-8136108858046085095L));
      f.add(new LongKeyState(8596483262161222282L));
      f.add(new LongKeyState(5102521241119447792L));
      f.add(new LongKeyState(-7123252388583668477L));
      f.add(new LongKeyState(7255627791645501513L));
      f.add(new LongKeyState(2708646242742689971L));
      f.add(new LongKeyState(-4229988511342849509L));
      f.add(new LongKeyState(2235819736818853985L));
      f.add(new LongKeyState(146177542720326817L));
      f.add(new LongKeyState(-8618766088647933528L));
      f.add(new LongKeyState(7937844321031175218L));
      f.add(new LongKeyState(-6736420391271317077L));
      f.add(new LongKeyState(-5621353973885991591L));
      f.add(new LongKeyState(6976672500512138011L));
      f.add(new LongKeyState(-4085141725216846693L));
      f.add(new LongKeyState(8956997946999607288L));
      f.add(new LongKeyState(-7322802350482154469L));
      f.add(new LongKeyState(-4691634270642681495L));
      f.add(new LongKeyState(3183999260348095827L));
      f.add(new LongKeyState(-4516085013570162183L));
      f.add(new LongKeyState(-9074096867621636383L));
      f.add(new LongKeyState(-3678138048122001591L));
      f.add(new LongKeyState(841648477896407145L));
      f.add(new LongKeyState(-6614453818638869599L));
      f.add(new LongKeyState(106763306328100595L));
      f.add(new LongKeyState(3194334267866590738L));
      f.add(new LongKeyState(5420249442517194009L));
      f.add(new LongKeyState(8904245849779778746L));
      f.add(new LongKeyState(8501681854097646353L));
      f.add(new LongKeyState(7868278531013931289L));
      f.add(new LongKeyState(-8398177648898212957L));
      f.add(new LongKeyState(6303854169792479288L));
      f.add(new LongKeyState(2542232894153724129L));
      f.add(new LongKeyState(-8566829401796684215L));
      f.add(new LongKeyState(-8964510874743495768L));
      f.add(new LongKeyState(-3459822199646600759L));
      f.add(new LongKeyState(-6644723261551803239L));
      f.add(new LongKeyState(-2340014838904307446L));
      f.add(new LongKeyState(-1739174334761017998L));
      f.add(new LongKeyState(5808644197820907890L));
      f.add(new LongKeyState(-4478332136696585312L));
      f.add(new LongKeyState(-5185754918655923792L));
      f.add(new LongKeyState(-5933249841374896517L));
      f.add(new LongKeyState(7693587413602919890L));
      f.add(new LongKeyState(4187507868640382249L));
      f.add(new LongKeyState(-1745922525605928792L));
      f.add(new LongKeyState(1311852224985851672L));
      e = (int[])e.clone();
      f.add(new LongKeyState(-6604273069749529519L));
      f.add(new LongKeyState(3105761963034346466L));
      f.add(new LongKeyState(3159790025338270472L));
      f.add(new LongKeyState(3432600507570910849L));
      f.add(new LongKeyState(-6748016141946564837L));
      f.add(new LongKeyState(1526230816579341201L));
      f.add(new LongKeyState(5419726767509405304L));
      f.add(new LongKeyState(4801060196603179528L));
      f.add(new LongKeyState(-1535819748223456000L));
      f.add(new LongKeyState(6062344543901259360L));
      f.add(new LongKeyState(4441102188136888978L));
      f.add(new LongKeyState(5736991158442620025L));
      f.add(new LongKeyState(-3912548114218562399L));
      f.add(new LongKeyState(4699725588813950713L));
      f.add(new LongKeyState(4155431740157493033L));
      f.add(new LongKeyState(-1440110313841294382L));
      f.add(new LongKeyState(-8561280290116275805L));
      f.add(new LongKeyState(-963731034414913600L));
      f.add(new LongKeyState(-1854707200694038008L));
      f.add(new LongKeyState(-2924819287338957432L));
      f.add(new LongKeyState(3711043722764475522L));
      f.add(new LongKeyState(7784308833408484818L));
      f.add(new LongKeyState(-9194417729828320957L));
      f.add(new LongKeyState(-6300625045805236319L));
      f.add(new LongKeyState(-6701262194299228758L));
      f.add(new LongKeyState(-6484060936708998694L));
      f.add(new LongKeyState(-759870174455232839L));
      f.add(new LongKeyState(2155163362130048979L));
      f.add(new LongKeyState(143898813762858634L));
      f.add(new LongKeyState(3998032794923125569L));
      f.add(new LongKeyState(675200739153419331L));
      f.add(new LongKeyState(-71043921528729848L));
      f.add(new LongKeyState(-1077336220538097615L));
      f.add(new LongKeyState(-5705488383544404768L));
      f.add(new LongKeyState(7782190254279142744L));
      f.add(new LongKeyState(-6564902526390352470L));
      f.add(new LongKeyState(4563531973844382432L));
      f.add(new LongKeyState(-2200414868359941520L));
      f.add(new LongKeyState(-4583285736761855608L));
      f.add(new LongKeyState(-3689811349836813318L));
      f.add(new LongKeyState(-6249520915631897359L));
      f.add(new LongKeyState(2695386704519785402L));
      f.add(new LongKeyState(-8661082478563788087L));
      f.add(new LongKeyState(-781492471224023375L));
      f.add(new LongKeyState(-1530722452708776031L));
      f.add(new LongKeyState(5927801528836436905L));
      f.add(new LongKeyState(-2358036871641630053L));
      f.add(new LongKeyState(-4898344136362711983L));
      f.add(new LongKeyState(-1790887101467825029L));
      f.add(new LongKeyState(542556983733798354L));
      f.add(new LongKeyState(-5015782956381868216L));
      f.add(new LongKeyState(9068160912020085226L));
      f.add(new LongKeyState(3666150559619280720L));
      f.add(new LongKeyState(8642965086084046339L));
      f.add(new LongKeyState(6863165535834269195L));
      f.add(new LongKeyState(-4119498483865937965L));
      f.add(new LongKeyState(-276921598301821038L));
      f.add(new LongKeyState(-1298624118346465775L));
      f.add(new LongKeyState(6056997826089307296L));
      f.add(new LongKeyState(-5916883146754822112L));
      f.add(new LongKeyState(-8945730289768913749L));
      f.add(new LongKeyState(-125640499195293334L));
      f.add(new LongKeyState(-5402940959447253525L));
      f.add(new LongKeyState(-5717183084360725573L));
      f.add(new LongKeyState(122822869111912657L));
      f.add(new LongKeyState(-7748668589263991703L));
      f.add(new LongKeyState(-1881059280013382216L));
      f.add(new LongKeyState(-5987940626658582566L));
      f.add(new LongKeyState(-8936293097562746822L));
      f.add(new LongKeyState(-4988914740784097894L));
      f.add(new LongKeyState(-6518093581019922960L));
      f.add(new LongKeyState(-2031141730091561440L));
      f.add(new LongKeyState(-458667703132915592L));
      f.add(new LongKeyState(-8499424789948106615L));
      f.add(new LongKeyState(-1307631319748559871L));
      f.add(new LongKeyState(3226661367398305211L));
      f.add(new LongKeyState(-5425939983027186294L));
      f.add(new LongKeyState(-8156686571354294790L));
      f.add(new LongKeyState(-6064437470143412278L));
      f.add(new LongKeyState(-605922954028629416L));
      f.add(new LongKeyState(-709402974037221590L));
      f.add(new LongKeyState(1030597779653947024L));
      f.add(new LongKeyState(-3842254763171201407L));
      f.add(new LongKeyState(-5202467200476055543L));
      f.add(new LongKeyState(7904214764327584819L));
      f.add(new LongKeyState(6856311101528937899L));
      f.add(new LongKeyState(-6155849409303722101L));
      f.add(new LongKeyState(-2128467306958080374L));
      f.add(new LongKeyState(-7210212056066723032L));
      f.add(new LongKeyState(-777777558285220165L));
      f.add(new LongKeyState(-4852616067030512821L));
      f.add(new LongKeyState(-4865640894873483200L));
      f.add(new LongKeyState(-4572486785438564973L));
      f.add(new LongKeyState(31403615462690040L));
      f.add(new LongKeyState(3374530643639358219L));
      f.add(new LongKeyState(4948216534241464673L));
      f.add(new LongKeyState(8229756216453434593L));
      f.add(new LongKeyState(430873381627930785L));
      f.add(new LongKeyState(-7314752366594457525L));
      f.add(new LongKeyState(4926477370014716001L));
      f.add(new LongKeyState(3984232687479203914L));
      f.add(new LongKeyState(-4149757118976914870L));
      f.add(new LongKeyState(7768135426660743049L));
      f.add(new LongKeyState(4617285710754458363L));
      f.add(new LongKeyState(8881174383513781968L));
      f.add(new LongKeyState(2455412867334834785L));
      f.add(new LongKeyState(-2100897311252710926L));
      f.add(new LongKeyState(83751570343999832L));
      f.add(new LongKeyState(-2301064414723665024L));
      f.add(new LongKeyState(1244996517098461154L));
      f.add(new LongKeyState(1477034396239002514L));
      f.add(new LongKeyState(3076305962107970387L));
      f.add(new LongKeyState(-4635995413895541815L));
      f.add(new LongKeyState(5767934196514201787L));
      f.add(new LongKeyState(6965496945324735794L));
      f.add(new LongKeyState(-1893361783677807910L));
      f.add(new LongKeyState(-3746334284629927062L));
      f.add(new LongKeyState(6587275758445661226L));
      f.add(new LongKeyState(-1951984751491148526L));
      f.add(new LongKeyState(8475933542969075944L));
      f.add(new LongKeyState(8230966162861552737L));
      f.add(new LongKeyState(1663069760773949433L));
      f.add(new LongKeyState(8876700181987576819L));
      f.add(new LongKeyState(355365882970267482L));
      f.add(new LongKeyState(344898754919577123L));
      f.add(new LongKeyState(-3703634612407519063L));
      f.add(new LongKeyState(8520193838863547601L));
      f.add(new LongKeyState(-8722830028331611095L));
      f.add(new LongKeyState(4197975485884541193L));
      f.add(new LongKeyState(5507929646317139224L));
      f.add(new LongKeyState(2438712309006818626L));
      f.add(new LongKeyState(1406432400722380843L));
      f.add(new LongKeyState(7462818174460724984L));
      f.add(new LongKeyState(85611641020363401L));
      f.add(new LongKeyState(-4245092743963046720L));
      f.add(new LongKeyState(-1364676841628763678L));
      f.add(new LongKeyState(1116172518193937921L));
      f.add(new LongKeyState(7333927759291644984L));
      f.add(new LongKeyState(5162798065977507731L));
      f.add(new LongKeyState(7375057798810056833L));
      f.add(new LongKeyState(-4561143608260181998L));
      f.add(new LongKeyState(3149131252713991504L));
      f.add(new LongKeyState(-307476763773244069L));
      f.add(new LongKeyState(1228895618414742019L));
      f.add(new LongKeyState(2114392076155395192L));
      f.add(new LongKeyState(-5183482806532812902L));
      f.add(new LongKeyState(-9090256451884410582L));
      f.add(new LongKeyState(-4459423467453556517L));
      f.add(new LongKeyState(-1548905825154442301L));
      f.add(new LongKeyState(5009874233217143643L));
      f.add(new LongKeyState(8636260802918164787L));
      f.add(new LongKeyState(-7670851476797258813L));
      f.add(new LongKeyState(7542617137597103297L));
      f.add(new LongKeyState(2407742251824157473L));
      f.add(new LongKeyState(5124982403638279347L));
      f.add(new LongKeyState(-2080494633363831399L));
      e = (int[])e.clone();
      f.add(new LongKeyState(5149272513484316818L));
      f.add(new LongKeyState(6730995935903633209L));
      f.add(new LongKeyState(559829644915733696L));
      f.add(new LongKeyState(6119378155719348699L));
      f.add(new LongKeyState(-2865425605052080285L));
      f.add(new LongKeyState(-279514549536771047L));
      f.add(new LongKeyState(4230821233129773544L));
      f.add(new LongKeyState(9093287201402443529L));
      f.add(new LongKeyState(-616149849985544885L));
      f.add(new LongKeyState(2922612076434945011L));
      f.add(new LongKeyState(4918576826141409736L));
      f.add(new LongKeyState(7605364893443703651L));
      f.add(new LongKeyState(-7371228737233749229L));
      f.add(new LongKeyState(-5035942999025840741L));
      f.add(new LongKeyState(8404002132176790560L));
      f.add(new LongKeyState(-143615094106349950L));
      f.add(new LongKeyState(4224347214736860035L));
      f.add(new LongKeyState(2580082066374889331L));
      f.add(new LongKeyState(-161072480263190640L));
      f.add(new LongKeyState(6897504586550119779L));
      f.add(new LongKeyState(7436972174039702752L));
      f.add(new LongKeyState(-71297489329339054L));
      f.add(new LongKeyState(-5940122333582376110L));
      f.add(new LongKeyState(-8913305867952924352L));
      f.add(new LongKeyState(4380499331345846907L));
      f.add(new LongKeyState(1192696841447300488L));
      f.add(new LongKeyState(-1506438108096590175L));
      f.add(new LongKeyState(-8247309719769327437L));
      f.add(new LongKeyState(7782347557175793634L));
      f.add(new LongKeyState(6333896174629332698L));
      f.add(new LongKeyState(-5308625057476146575L));
      f.add(new LongKeyState(7064340864713006424L));
      f.add(new LongKeyState(-4388798648361517557L));
      f.add(new LongKeyState(-923388009138420544L));
      f.add(new LongKeyState(714890162246423432L));
      f.add(new LongKeyState(-8188940153890852072L));
      f.add(new LongKeyState(-6680058450801565472L));
      f.add(new LongKeyState(1414799363073429115L));
      f.add(new LongKeyState(-555025331008263814L));
      f.add(new LongKeyState(8933243452856706392L));
      f.add(new LongKeyState(1367182033870666560L));
      f.add(new LongKeyState(-9183951020773089415L));
      f.add(new LongKeyState(-2607766160278377789L));
      f.add(new LongKeyState(-8318635471619184208L));
      f.add(new LongKeyState(-9206821591013207317L));
      f.add(new LongKeyState(3561718059647341282L));
      f.add(new LongKeyState(-4336296781813052544L));
      f.add(new LongKeyState(-7810933136425231397L));
      f.add(new LongKeyState(-415844919740195775L));
      f.add(new LongKeyState(6458034974237691808L));
      f.add(new LongKeyState(2508898824309294009L));
      f.add(new LongKeyState(-4811685604560241144L));
      f.add(new LongKeyState(5095637450609413457L));
      f.add(new LongKeyState(-7268712005710322640L));
      f.add(new LongKeyState(-5979831786184884031L));
      f.add(new LongKeyState(-7348059496211653741L));
      f.add(new LongKeyState(4217898092860556690L));
      f.add(new LongKeyState(2076962115131802425L));
      f.add(new LongKeyState(-8359010862413685007L));
      f.add(new LongKeyState(-6098978805072658375L));
      f.add(new LongKeyState(6668257359601813899L));
      f.add(new LongKeyState(-587626215346538584L));
      f.add(new LongKeyState(-4971169510455580855L));
      f.add(new LongKeyState(-6596140721920930838L));
      f.add(new LongKeyState(7152257237975200995L));
      f.add(new LongKeyState(-18619619808904869L));
      f.add(new LongKeyState(-1548050510278215413L));
      f.add(new LongKeyState(2059075620908813184L));
      f.add(new LongKeyState(-3631677910749943541L));
      f.add(new LongKeyState(7719773160725691096L));
      f.add(new LongKeyState(8888424416912883624L));
      f.add(new LongKeyState(1525442496521054257L));
      f.add(new LongKeyState(-5466575673741404023L));
      f.add(new LongKeyState(-3612579057411884870L));
      f.add(new LongKeyState(-1128995819351378927L));
      f.add(new LongKeyState(7073348061820263768L));
      f.add(new LongKeyState(-4145493086338569318L));
      f.add(new LongKeyState(-5018888661092274799L));
      f.add(new LongKeyState(-5278145113214290342L));
      f.add(new LongKeyState(-8983431221846133232L));
      f.add(new LongKeyState(1609781931768327168L));
      f.add(new LongKeyState(-849395838853126103L));
      f.add(new LongKeyState(-7070737501248498176L));
      f.add(new LongKeyState(-2243288130470366278L));
      f.add(new LongKeyState(-3949404360567955526L));
      f.add(new LongKeyState(-4644198889826157126L));
      f.add(new LongKeyState(-643016189981919614L));
      f.add(new LongKeyState(-7168937156248225896L));
      f.add(new LongKeyState(743511828390469434L));
      f.add(new LongKeyState(4640489759209875520L));
      f.add(new LongKeyState(7515557378668634426L));
      f.add(new LongKeyState(5614442598708484328L));
      f.add(new LongKeyState(-4499023812225229325L));
      f.add(new LongKeyState(-8977769744645726983L));
      f.add(new LongKeyState(-8465445962726327296L));
      f.add(new LongKeyState(7700846706832548595L));
      f.add(new LongKeyState(-954228617562409549L));
      f.add(new LongKeyState(1990449294288004840L));
      f.add(new LongKeyState(-6933460292549091592L));
      f.add(new LongKeyState(-2930446561979858664L));
      f.add(new LongKeyState(-7674840268657785703L));
      f.add(new LongKeyState(-2560844566134461551L));
      f.add(new LongKeyState(-7077158220523404214L));
      f.add(new LongKeyState(2419549955245486890L));
      f.add(new LongKeyState(-347046975657582094L));
      f.add(new LongKeyState(-8801941908447491136L));
      f.add(new LongKeyState(6310413143667358785L));
      f.add(new LongKeyState(2844049681190519291L));
      f.add(new LongKeyState(-2854393071297061910L));
      f.add(new LongKeyState(-9014408756705837400L));
      f.add(new LongKeyState(3676889728336370248L));
      f.add(new LongKeyState(6331733060273873299L));
      f.add(new LongKeyState(8029843614420060666L));
      f.add(new LongKeyState(-4013380123953426879L));
      f.add(new LongKeyState(-3312396963348190221L));
      f.add(new LongKeyState(2319245549285240594L));
      f.add(new LongKeyState(-2552753146825615422L));
      f.add(new LongKeyState(-7763753876888160504L));
      f.add(new LongKeyState(7516925744383812801L));
      f.add(new LongKeyState(8152960867158875410L));
      f.add(new LongKeyState(7289528758068404960L));
      f.add(new LongKeyState(-934724987918855990L));
      f.add(new LongKeyState(1780264735949328683L));
      f.add(new LongKeyState(3113677524475384584L));
      f.add(new LongKeyState(-5519477949471504775L));
      f.add(new LongKeyState(3250094513053113635L));
      f.add(new LongKeyState(844163972941476984L));
      f.add(new LongKeyState(-1077336254897835471L));
      f.add(new LongKeyState(5768071311653753139L));
      f.add(new LongKeyState(-4591637573292967152L));
      f.add(new LongKeyState(-8203889033677869534L));
      f.add(new LongKeyState(53190776601038944L));
      f.add(new LongKeyState(-7970656102735601784L));
      f.add(new LongKeyState(-7536071083555963102L));
      f.add(new LongKeyState(6706660241972220784L));
      f.add(new LongKeyState(2843842766475919896L));
      f.add(new LongKeyState(3397286393380902600L));
      f.add(new LongKeyState(8138314768347446865L));
      f.add(new LongKeyState(-8140890935219117104L));
      f.add(new LongKeyState(7538783675240353219L));
      f.add(new LongKeyState(-6806599453659564432L));
      f.add(new LongKeyState(582907482869037162L));
      f.add(new LongKeyState(-5411181769452452525L));
      f.add(new LongKeyState(-7892733985426807757L));
      f.add(new LongKeyState(2476815956762864970L));
      f.add(new LongKeyState(-6524188660926191110L));
      f.add(new LongKeyState(-4113831700412312782L));
      f.add(new LongKeyState(2660180241589955555L));
      f.add(new LongKeyState(9121600434012144682L));
      f.add(new LongKeyState(-4272110970851324510L));
      f.add(new LongKeyState(4799219774230115819L));
      f.add(new LongKeyState(-8600907558587964047L));
      f.add(new LongKeyState(8851755350744259569L));
      f.add(new LongKeyState(-5289833008733086288L));
      f.add(new LongKeyState(-3423409494613440181L));
      f.add(new LongKeyState(7330152999033917721L));
      f.add(new LongKeyState(7931794714438779936L));
      f.add(new LongKeyState(595856701384774074L));
      f.add(new LongKeyState(7172097553557223706L));
      e = (int[])e.clone();
      f.add(new LongKeyState(7610223813440986050L));
      f.add(new LongKeyState(8196472503000910490L));
      f.add(new LongKeyState(3009881416876065106L));
      f.add(new LongKeyState(-5771711080750834629L));
      f.add(new LongKeyState(-1156407376632895992L));
      f.add(new LongKeyState(4627269552458180248L));
      f.add(new LongKeyState(-3435509226936567791L));
      f.add(new LongKeyState(3109861269610330642L));
      f.add(new LongKeyState(2150118904932995922L));
      f.add(new LongKeyState(4925833949058952275L));
      f.add(new LongKeyState(-7805867265901182288L));
      f.add(new LongKeyState(-7244446649029804926L));
      f.add(new LongKeyState(-7950406888117777189L));
      f.add(new LongKeyState(4259272806220507313L));
      f.add(new LongKeyState(-9173655273321169917L));
      f.add(new LongKeyState(2253673122875704827L));
      f.add(new LongKeyState(-6522115872011044104L));
      f.add(new LongKeyState(-8374733818669342312L));
      f.add(new LongKeyState(4376907356872011593L));
      f.add(new LongKeyState(2177974576211692731L));
      f.add(new LongKeyState(3418847781773676827L));
      f.add(new LongKeyState(6112926373169201659L));
      f.add(new LongKeyState(7580884104296431835L));
      f.add(new LongKeyState(-5838744011070988942L));
      f.add(new LongKeyState(-4789606686236687319L));
      f.add(new LongKeyState(8064059113347630657L));
      f.add(new LongKeyState(3766220416501369992L));
      f.add(new LongKeyState(7964348822106007203L));
      f.add(new LongKeyState(8770407935768866378L));
      f.add(new LongKeyState(-8255197244720942326L));
      f.add(new LongKeyState(7332550132831311699L));
      f.add(new LongKeyState(-3611205551194736142L));
      f.add(new LongKeyState(7442596752766866232L));
      f.add(new LongKeyState(5038828866161490978L));
      f.add(new LongKeyState(2439180304025873683L));
      f.add(new LongKeyState(3072860109609389123L));
      f.add(new LongKeyState(-489022254665827992L));
      f.add(new LongKeyState(3953410835008939809L));
      f.add(new LongKeyState(-982565893535200157L));
      f.add(new LongKeyState(-3887478185433499853L));
      f.add(new LongKeyState(-3923163813950433126L));
      f.add(new LongKeyState(2546852225838065576L));
      f.add(new LongKeyState(-6838947678321802376L));
      f.add(new LongKeyState(1647525805731128322L));
      f.add(new LongKeyState(697779215493098873L));
      f.add(new LongKeyState(2300924222831993666L));
      f.add(new LongKeyState(1461325186673638234L));
      f.add(new LongKeyState(-7772254118274089015L));
      f.add(new LongKeyState(-179742143398247040L));
      f.add(new LongKeyState(-6600128089889868416L));
      f.add(new LongKeyState(6828292388929129515L));
      f.add(new LongKeyState(3536934876193736593L));
      f.add(new LongKeyState(3160057884494169035L));
      f.add(new LongKeyState(-935429083061956784L));
      f.add(new LongKeyState(2834270950017041746L));
      f.add(new LongKeyState(1853459506238381424L));
      f.add(new LongKeyState(2996720658022365897L));
      f.add(new LongKeyState(2099478464877219600L));
      f.add(new LongKeyState(5944183864817304154L));
      f.add(new LongKeyState(-6771748666497814085L));
      f.add(new LongKeyState(8332601865981885696L));
      f.add(new LongKeyState(8889303678159661258L));
      f.add(new LongKeyState(-1630416404176771039L));
      f.add(new LongKeyState(214397964649880691L));
      f.add(new LongKeyState(-3667752501753726357L));
      f.add(new LongKeyState(7730189578927781433L));
      f.add(new LongKeyState(4695820622819280289L));
      f.add(new LongKeyState(-9196469006357340958L));
      f.add(new LongKeyState(9186218291684920784L));
      f.add(new LongKeyState(3067823436340045793L));
      f.add(new LongKeyState(721522165081337856L));
      f.add(new LongKeyState(2874712733296482339L));
      f.add(new LongKeyState(7908086771917836553L));
      f.add(new LongKeyState(-2900760670378127838L));
      f.add(new LongKeyState(3331842037645080896L));
      f.add(new LongKeyState(-5700967849000300792L));
      f.add(new LongKeyState(-2513965981001410301L));
      f.add(new LongKeyState(-4865590996481703624L));
      f.add(new LongKeyState(-4179641311177021934L));
      f.add(new LongKeyState(4536489011393791521L));
      f.add(new LongKeyState(-7225116323014280382L));
      f.add(new LongKeyState(-758175311430946455L));
      f.add(new LongKeyState(-3820895342532045311L));
      f.add(new LongKeyState(8276504448498577833L));
      f.add(new LongKeyState(6992847939222405587L));
      f.add(new LongKeyState(-748486611194405080L));
      f.add(new LongKeyState(-7490532991830299286L));
      f.add(new LongKeyState(-6528213294573308047L));
      f.add(new LongKeyState(-6418384158406579223L));
      f.add(new LongKeyState(-7885409950078416805L));
      f.add(new LongKeyState(-5845009722487692597L));
      f.add(new LongKeyState(2554143280048532778L));
      f.add(new LongKeyState(-7759879742673314919L));
      f.add(new LongKeyState(-4231879601006727431L));
      f.add(new LongKeyState(-4831401873261377912L));
      f.add(new LongKeyState(2788136836073382979L));
      f.add(new LongKeyState(2073653299062655880L));
      f.add(new LongKeyState(7800980771771380930L));
      f.add(new LongKeyState(8240361663034345217L));
      f.add(new LongKeyState(6964951901186260498L));
      f.add(new LongKeyState(6658437442386518136L));
      f.add(new LongKeyState(2072342194483063016L));
      f.add(new LongKeyState(7707915554762035584L));
      f.add(new LongKeyState(-2417302338263453767L));
      f.add(new LongKeyState(-4948215308697109447L));
      f.add(new LongKeyState(-3663572744219945023L));
      f.add(new LongKeyState(-5507595975468665182L));
      f.add(new LongKeyState(8115094279748737193L));
      f.add(new LongKeyState(694165924149829248L));
      f.add(new LongKeyState(4691179486193256112L));
      f.add(new LongKeyState(6362117850280957393L));
      f.add(new LongKeyState(2546825605743619561L));
      f.add(new LongKeyState(8251886212801360744L));
      f.add(new LongKeyState(1349596605607524457L));
      f.add(new LongKeyState(-8259891984476838981L));
      f.add(new LongKeyState(1773510279315842250L));
      f.add(new LongKeyState(-327612873888675965L));
      f.add(new LongKeyState(-4017854983477123158L));
      f.add(new LongKeyState(-8174181931444679480L));
      f.add(new LongKeyState(769389499784398419L));
      f.add(new LongKeyState(6059817777694531384L));
      f.add(new LongKeyState(5893177010390958880L));
      f.add(new LongKeyState(-3297698656834563622L));
      f.add(new LongKeyState(-2156249441814722597L));
      f.add(new LongKeyState(-2513965983148893949L));
      f.add(new LongKeyState(-8257049383793108829L));
      f.add(new LongKeyState(-5603235938391054406L));
      f.add(new LongKeyState(-4219112442710527286L));
      f.add(new LongKeyState(-3097895523236093206L));
      f.add(new LongKeyState(7207294674703988041L));
      f.add(new LongKeyState(5158403031539442019L));
      f.add(new LongKeyState(3660338324446927368L));
      f.add(new LongKeyState(-9039751405363761318L));
      f.add(new LongKeyState(42478669834726633L));
      f.add(new LongKeyState(908468205874852448L));
      f.add(new LongKeyState(-5408472556242590775L));
      f.add(new LongKeyState(-6593516494541641677L));
      e = (int[])e.clone();
      f.add(new LongKeyState(-5823937459732231493L));
      f.add(new LongKeyState(-7729658747245890640L));
      f.add(new LongKeyState(7299368605308920921L));
      f.add(new LongKeyState(-4123399114543942029L));
      f.add(new LongKeyState(7271679577429264360L));
      f.add(new LongKeyState(7296414780695063401L));
      f.add(new LongKeyState(-3249610023306037837L));
      f.add(new LongKeyState(2166828188051526200L));
      f.add(new LongKeyState(5781882065565778794L));
      f.add(new LongKeyState(8317256133426458304L));
      f.add(new LongKeyState(-7979465752884659887L));
      f.add(new LongKeyState(7723502307136537473L));
      f.add(new LongKeyState(-8014204185127960295L));
      f.add(new LongKeyState(7277805050244880136L));
      f.add(new LongKeyState(-3889730333052280319L));
      f.add(new LongKeyState(971776619180223657L));
      f.add(new LongKeyState(-3398114496543131615L));
      f.add(new LongKeyState(-7916556977682268846L));
      f.add(new LongKeyState(8384196838267832418L));
      f.add(new LongKeyState(3487138655908786019L));
      f.add(new LongKeyState(-9071923062679733039L));
      f.add(new LongKeyState(-6599774079985348101L));
      f.add(new LongKeyState(-3557871302171956855L));
      f.add(new LongKeyState(4309163350084395562L));
      f.add(new LongKeyState(5292988364615035291L));
      f.add(new LongKeyState(1273980813431450681L));
      f.add(new LongKeyState(5955721698670702955L));
      f.add(new LongKeyState(-8020752899672788879L));
      f.add(new LongKeyState(-6572462324539655623L));
      f.add(new LongKeyState(8492864435342303211L));
      f.add(new LongKeyState(-4172727205373172424L));
      f.add(new LongKeyState(-1479195051450731239L));
      f.add(new LongKeyState(-4751143477652249270L));
      f.add(new LongKeyState(-7469703011986118503L));
      f.add(new LongKeyState(-5659958228244646310L));
      f.add(new LongKeyState(3758210586521074721L));
      f.add(new LongKeyState(3464894413021560474L));
      f.add(new LongKeyState(-2560844563986978431L));
      f.add(new LongKeyState(4862948794153243114L));
      f.add(new LongKeyState(-4447123511649305310L));
      f.add(new LongKeyState(-2958288873943410808L));
      f.add(new LongKeyState(5368045204580134217L));
      f.add(new LongKeyState(2400767601771751200L));
      f.add(new LongKeyState(-4069546643016207382L));
      f.add(new LongKeyState(-3928581863347918774L));
      f.add(new LongKeyState(-4329309398649335478L));
      f.add(new LongKeyState(-2668098346375408983L));
      f.add(new LongKeyState(4182240422279783993L));
      f.add(new LongKeyState(1284953244895371128L));
      f.add(new LongKeyState(-1935735205129620550L));
      f.add(new LongKeyState(-6807441427440312303L));
      f.add(new LongKeyState(-6251690816038996959L));
      f.add(new LongKeyState(8064809190686639859L));
      f.add(new LongKeyState(-6100972271132041935L));
      f.add(new LongKeyState(-4635200547121491982L));
      f.add(new LongKeyState(790611329958566681L));
      f.add(new LongKeyState(-4387820136166498703L));
      f.add(new LongKeyState(-1772773976779416574L));
      f.add(new LongKeyState(-3981247506426915349L));
      f.add(new LongKeyState(-6928585017631636311L));
      f.add(new LongKeyState(6075012209566403744L));
      f.add(new LongKeyState(3974365123476343288L));
      f.add(new LongKeyState(6273708288404131344L));
      f.add(new LongKeyState(2843147267552986907L));
      f.add(new LongKeyState(-3078650391000009184L));
      f.add(new LongKeyState(1835216352556561920L));
      f.add(new LongKeyState(-8526550973731827637L));
      f.add(new LongKeyState(8583464569521849944L));
      f.add(new LongKeyState(2011496240408245249L));
      f.add(new LongKeyState(243794446761887928L));
      f.add(new LongKeyState(-7463457055058166719L));
      f.add(new LongKeyState(-8847712939588037928L));
      f.add(new LongKeyState(-6563611316811550792L));
      f.add(new LongKeyState(-1367189389520735125L));
      f.add(new LongKeyState(-4415632416165896799L));
      f.add(new LongKeyState(-1179587812789859469L));
      f.add(new LongKeyState(3797946746425140618L));
      f.add(new LongKeyState(-7176777317136065207L));
      f.add(new LongKeyState(7886522295556416248L));
      f.add(new LongKeyState(5658098820933012714L));
      e = (int[])e.clone();
      f.add(new LongKeyState(1244670685945078626L));
      f.add(new LongKeyState(-7658901062935869456L));
      f.add(new LongKeyState(-113908173399517605L));
      f.add(new LongKeyState(-167783983685708965L));
      f.add(new LongKeyState(1921270388127866648L));
      f.add(new LongKeyState(3454870222330883824L));
      f.add(new LongKeyState(8635263021259707178L));
      f.add(new LongKeyState(5708553497249540640L));
      f.add(new LongKeyState(-2137092311440284551L));
      f.add(new LongKeyState(-4745672028900976112L));
      f.add(new LongKeyState(-43704701449919638L));
      f.add(new LongKeyState(8619201992126390441L));
      f.add(new LongKeyState(-4010871901722417389L));
      f.add(new LongKeyState(-6291306034739577598L));
      f.add(new LongKeyState(-6183034747413857317L));
      f.add(new LongKeyState(-748135703220318743L));
      f.add(new LongKeyState(4211532494141308770L));
      f.add(new LongKeyState(8810427958340673099L));
      f.add(new LongKeyState(-3581728809803309278L));
      f.add(new LongKeyState(-1067930581990328440L));
      f.add(new LongKeyState(7207722435816112730L));
      f.add(new LongKeyState(-686404734061631557L));
      f.add(new LongKeyState(2840499112254501489L));
      f.add(new LongKeyState(-4940275870592059592L));
      f.add(new LongKeyState(-819782455276214733L));
      f.add(new LongKeyState(-2790926898508068125L));
      f.add(new LongKeyState(2111418181615401394L));
      f.add(new LongKeyState(-4271438991249394382L));
      f.add(new LongKeyState(6823315972611662360L));
      f.add(new LongKeyState(-1521185416982370056L));
      f.add(new LongKeyState(8443981391389461152L));
      f.add(new LongKeyState(-7490591760487124247L));
      f.add(new LongKeyState(5972704517140154849L));
      f.add(new LongKeyState(3507563831860667672L));
      f.add(new LongKeyState(-6848707170533808255L));
      f.add(new LongKeyState(-3267478593600894430L));
      f.add(new LongKeyState(3029090822467862539L));
      f.add(new LongKeyState(-6898513848258635373L));
      f.add(new LongKeyState(6308715278399642033L));
      f.add(new LongKeyState(6966279458061366881L));
      f.add(new LongKeyState(-4569612617637865966L));
      f.add(new LongKeyState(-6609594709041848784L));
      f.add(new LongKeyState(1749814125861372978L));
      f.add(new LongKeyState(1852999882585741064L));
      f.add(new LongKeyState(879818300496852994L));
      f.add(new LongKeyState(-1196979099588449974L));
      f.add(new LongKeyState(5986556661586002450L));
      f.add(new LongKeyState(5554963952627584913L));
      f.add(new LongKeyState(-7260087775032159072L));
      f.add(new LongKeyState(8936716191068866528L));
      f.add(new LongKeyState(6327170226172429176L));
      f.add(new LongKeyState(-5182731768113865909L));
      f.add(new LongKeyState(-6785324402859839264L));
      f.add(new LongKeyState(-5834275320109017743L));
      f.add(new LongKeyState(-4131546827323655230L));
      f.add(new LongKeyState(1262394774443150443L));
      f.add(new LongKeyState(-2864107283367081336L));
      f.add(new LongKeyState(435929343095316849L));
      f.add(new LongKeyState(7962900932146017675L));
      f.add(new LongKeyState(2875798056464971345L));
      f.add(new LongKeyState(915856838078725418L));
      f.add(new LongKeyState(6055381461215797867L));
      f.add(new LongKeyState(-5808673462184951640L));
      f.add(new LongKeyState(4622475358552910416L));
      f.add(new LongKeyState(5980410598293069179L));
      f.add(new LongKeyState(-2704710768694647029L));
      f.add(new LongKeyState(-3537451889681289286L));
      f.add(new LongKeyState(-7305189193884982560L));
      f.add(new LongKeyState(3309065333820566488L));
      f.add(new LongKeyState(6337502830505554432L));
      f.add(new LongKeyState(1953372705452019411L));
      f.add(new LongKeyState(-5087915018394327704L));
      f.add(new LongKeyState(-8494904438434681759L));
      f.add(new LongKeyState(6817730758828263016L));
      f.add(new LongKeyState(926231741140863272L));
      f.add(new LongKeyState(-8363941917291432919L));
      f.add(new LongKeyState(9119283053109295314L));
      f.add(new LongKeyState(-7095477164134949054L));
      f.add(new LongKeyState(-4884381699556514966L));
      f.add(new LongKeyState(-2507355196071741688L));
      f.add(new LongKeyState(-2982980243324005951L));
      f.add(new LongKeyState(-3613858439335738784L));
      f.add(new LongKeyState(3541741343469664338L));
      f.add(new LongKeyState(-8568977521335557623L));
      f.add(new LongKeyState(7681334764949986939L));
      f.add(new LongKeyState(6419003647482531314L));
      f.add(new LongKeyState(4574990556088390056L));
      f.add(new LongKeyState(-1299171084633525168L));
      f.add(new LongKeyState(-6271237380873123223L));
      f.add(new LongKeyState(-6765646830069085056L));
      f.add(new LongKeyState(-6738075850458427702L));
      f.add(new LongKeyState(-925880563804405229L));
      f.add(new LongKeyState(-7027296906346705285L));
      f.add(new LongKeyState(-1789383318487360527L));
      f.add(new LongKeyState(7111117537596510546L));
      f.add(new LongKeyState(4751819902083282331L));
      f.add(new LongKeyState(22250667864330353L));
      f.add(new LongKeyState(8055051896912889425L));
      f.add(new LongKeyState(-58111695944827447L));
      f.add(new LongKeyState(8096878038858629474L));
      f.add(new LongKeyState(-3850261533500212926L));
      f.add(new LongKeyState(-5084467985724283414L));
      f.add(new LongKeyState(-2157635898566874848L));
      f.add(new LongKeyState(-3176094322367675280L));
      f.add(new LongKeyState(-2549167430459731142L));
      f.add(new LongKeyState(3777599047250443634L));
      f.add(new LongKeyState(-4792965222086138326L));
      f.add(new LongKeyState(5230046515617977728L));
      f.add(new LongKeyState(-7628720704538922335L));
      f.add(new LongKeyState(367259743487112586L));
      f.add(new LongKeyState(420683467207790595L));
      f.add(new LongKeyState(-5179619791008004576L));
      f.add(new LongKeyState(-6461291725246013743L));
      f.add(new LongKeyState(689179418632851937L));
      f.add(new LongKeyState(1210531593710052003L));
      f.add(new LongKeyState(2293615119279377658L));
      f.add(new LongKeyState(1857289710161687154L));
      f.add(new LongKeyState(949071318633190339L));
      f.add(new LongKeyState(-726476156615364752L));
      f.add(new LongKeyState(-8918761767739400254L));
      f.add(new LongKeyState(-3294382513299101197L));
      f.add(new LongKeyState(-8879287654033812791L));
      f.add(new LongKeyState(8281837166367057409L));
      f.add(new LongKeyState(-7027061111684968013L));
      f.add(new LongKeyState(-7442066482897711496L));
      f.add(new LongKeyState(-7248369514268235991L));
      f.add(new LongKeyState(5321529634169704219L));
      f.add(new LongKeyState(2005942937443373600L));
      f.add(new LongKeyState(-2707351196538627527L));
      f.add(new LongKeyState(-7971835636404783253L));
      f.add(new LongKeyState(-7563740733833576941L));
      f.add(new LongKeyState(3275468720371245858L));
      f.add(new LongKeyState(4975295306998604731L));
      f.add(new LongKeyState(2916641778815545994L));
      f.add(new LongKeyState(-7521596643623349366L));
      f.add(new LongKeyState(-4710084825517934757L));
      f.add(new LongKeyState(3670935789745436225L));
      e = (int[])e.clone();
      f.add(new LongKeyState(2258322869842517481L));
      f.add(new LongKeyState(-3341396376449182221L));
      f.add(new LongKeyState(-4463661924143534253L));
      f.add(new LongKeyState(-2763335921254663230L));
      f.add(new LongKeyState(-8660204187258795461L));
      f.add(new LongKeyState(7706883656372939152L));
      f.add(new LongKeyState(-6424743447376946573L));
      f.add(new LongKeyState(-2074858794860309173L));
      f.add(new LongKeyState(-1986973305154134455L));
      f.add(new LongKeyState(51106872245176929L));
      f.add(new LongKeyState(7878996218058206442L));
      f.add(new LongKeyState(-5826698855715861861L));
      f.add(new LongKeyState(1151367773950713L));
      f.add(new LongKeyState(-797666357227361958L));
      f.add(new LongKeyState(-2713887448149741045L));
      f.add(new LongKeyState(1170378196480658651L));
      f.add(new LongKeyState(-2901201018228226293L));
      f.add(new LongKeyState(-1317896670351457168L));
      f.add(new LongKeyState(1850467841343164969L));
      f.add(new LongKeyState(-5215377821461856527L));
      f.add(new LongKeyState(3878350343197047033L));
      f.add(new LongKeyState(-7951615385342604501L));
      f.add(new LongKeyState(-1875048439198677128L));
      f.add(new LongKeyState(-836994912083795430L));
      f.add(new LongKeyState(1566486425132640161L));
      f.add(new LongKeyState(-3702751930312344655L));
      f.add(new LongKeyState(2838435884346557131L));
      f.add(new LongKeyState(9091683978050180050L));
      f.add(new LongKeyState(-4340761146491233973L));
      f.add(new LongKeyState(-714395158830804848L));
      f.add(new LongKeyState(-1817022316258600815L));
      f.add(new LongKeyState(2683159848290211185L));
      f.add(new LongKeyState(-5064548514947960256L));
      f.add(new LongKeyState(-1253487654478006438L));
      f.add(new LongKeyState(4975308764954095411L));
      f.add(new LongKeyState(3053521260308739288L));
      f.add(new LongKeyState(3783629573180456722L));
      f.add(new LongKeyState(-6975542036074692374L));
      f.add(new LongKeyState(-5302376789163289445L));
      f.add(new LongKeyState(-5384024179985103183L));
      f.add(new LongKeyState(-282831047148938774L));
      f.add(new LongKeyState(826014406311407891L));
      f.add(new LongKeyState(7060072282949101497L));
      f.add(new LongKeyState(293906103853042234L));
      f.add(new LongKeyState(6621832460432631392L));
      f.add(new LongKeyState(-865069764301592336L));
      f.add(new LongKeyState(1105383980912876704L));
      f.add(new LongKeyState(4807491224083880531L));
      f.add(new LongKeyState(2151408318818344265L));
      f.add(new LongKeyState(-5254521750781230934L));
      f.add(new LongKeyState(-3221913808454927429L));
      f.add(new LongKeyState(6187561696141641536L));
      f.add(new LongKeyState(1514590699075386459L));
      f.add(new LongKeyState(4075193680680062010L));
      f.add(new LongKeyState(345959725849912577L));
      f.add(new LongKeyState(-6844412916548220704L));
      f.add(new LongKeyState(2233808171530906458L));
      f.add(new LongKeyState(8811558920539881408L));
      f.add(new LongKeyState(6761597447178454144L));
      f.add(new LongKeyState(-1018907287790237184L));
      f.add(new LongKeyState(-4872122823930681280L));
      f.add(new LongKeyState(-46274688638798975L));
      f.add(new LongKeyState(-2004032884865202808L));
      f.add(new LongKeyState(-4198413753992646799L));
      f.add(new LongKeyState(1722344973902605522L));
      f.add(new LongKeyState(-130322237842469230L));
      f.add(new LongKeyState(-2721374142952950422L));
      f.add(new LongKeyState(-840584543506596296L));
      f.add(new LongKeyState(6497401893399247410L));
      f.add(new LongKeyState(8538037168416284491L));
      f.add(new LongKeyState(-928123876430823143L));
      f.add(new LongKeyState(-3403899794127886717L));
      f.add(new LongKeyState(2766951842538856193L));
      f.add(new LongKeyState(8909686666549821906L));
      f.add(new LongKeyState(2385798329963489953L));
      f.add(new LongKeyState(8900188406123888520L));
      f.add(new LongKeyState(-4551886161273196278L));
      f.add(new LongKeyState(-4810858407930031016L));
      f.add(new LongKeyState(-98284763375431800L));
      f.add(new LongKeyState(-5297624684661198957L));
      f.add(new LongKeyState(-679394250391281935L));
      f.add(new LongKeyState(5293783545205205707L));
      f.add(new LongKeyState(-8671816395194638464L));
      f.add(new LongKeyState(-4171042687330664765L));
      f.add(new LongKeyState(1810336564762909426L));
      f.add(new LongKeyState(-6757528423829677016L));
      f.add(new LongKeyState(-3536593735562631869L));
      f.add(new LongKeyState(-8156564069055386669L));
      f.add(new LongKeyState(4412597829397659355L));
      f.add(new LongKeyState(3728787594891597467L));
      f.add(new LongKeyState(3639038861636238344L));
      f.add(new LongKeyState(3725486346064532234L));
      f.add(new LongKeyState(-5570983771288806326L));
      f.add(new LongKeyState(-1011222100469192744L));
      f.add(new LongKeyState(-1915249466567091286L));
      f.add(new LongKeyState(4213279516565343906L));
      f.add(new LongKeyState(8462316776500902338L));
      f.add(new LongKeyState(-2656098852772591240L));
      f.add(new LongKeyState(-9112859486984380735L));
      f.add(new LongKeyState(-3890388952172848671L));
      f.add(new LongKeyState(-6399820148820235454L));
      f.add(new LongKeyState(-5111429640414392277L));
      f.add(new LongKeyState(3744210398703788881L));
      f.add(new LongKeyState(1248860432946078674L));
      f.add(new LongKeyState(8636424899114204906L));
      f.add(new LongKeyState(-4202221955356009919L));
      f.add(new LongKeyState(-129567441465419269L));
      f.add(new LongKeyState(-5717602699816170062L));
      f.add(new LongKeyState(-3126465723655681958L));
      f.add(new LongKeyState(842817916768606760L));
      e = new int[]{
         -46,
         -6,
         -34,
         -6,
         -8,
         -14,
         -7,
         6,
         -36,
         6,
         -6,
         -48,
         8,
         7,
         -42,
         -5,
         6,
         -30,
         -15,
         14,
         5,
         -8,
         -23,
         -37,
         -33,
         -5,
         -16,
         -16,
         -21,
         8,
         5,
         -30,
         -30,
         15,
         -19,
         -13,
         34,
         -26,
         -13,
         -15,
         -15,
         -9,
         16,
         16,
         36,
         23,
         46,
         30,
         13,
         21,
         9,
         13,
         -6,
         19,
         15,
         15,
         42,
         33,
         6,
         48,
         37,
         30,
         30,
         26
      };
   }
}
