package dev.zprestige.prestige.api.eventbus;

import java.util.ArrayList;
import java.util.Map.Entry;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.SubscriberMethod;
import java.io.PrintStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class EventBus {
   private volatile Map a = new HashMap();
   private final Object b = new Object();
   private static final MethodType c;
   private static final Set d;
   public final CopyOnWriteArrayList e = new CopyOnWriteArrayList();
   private static final long f = 93852033798039L;
   private static final String g;
   private static final Object[] h = new Object[81];
   private static final String[] i = new String[81];

   public void aReturningVoid(final Object[] array) {
      final Object o = array[0];
      final long n = 0x555BA122CF97L ^ (long)array[1];
      final long l = n ^ 0x4A3C1AEC9EDBL;
      if (o == null) {
         return;
      }
      if (!this.e.isEmpty()) {
         return;
      }
      final Class<?> class1 = o.getClass();
      final ArrayList list2 = new ArrayList();
      final Method[] declaredMethods = class1.getDeclaredMethods();
      final int length = declaredMethods.length;
      for (int i = 0; i < length; i++) {
         final Method method = declaredMethods[i];
         if (!method.isAnnotationPresent(EventListener.class)) {
            continue;
         }
         final Class<?>[] parameterTypes = method.getParameterTypes();
         if (parameterTypes.length != 1) {
            continue;
         }
         try {
            method.setAccessible(true);
            final Object[] b3 = b();
            final Method d = d(807269654669435160L, n);
            final Object obj = null;
            Object invoke;
            try {
               invoke = d.invoke(obj, b3);
            } catch (final InvocationTargetException ex) {
               throw ex.getTargetException();
            }
            final Object[] a3 = a(method);
            final Method d2 = d(803987156285004681L, n);
            Object invoke2;
            try {
               invoke2 = d2.invoke(invoke, a3);
            } catch (final InvocationTargetException ex2) {
               throw ex2.getTargetException();
            }
            final Object[] a4 = a(o);
            final Method d3 = d(804547946810503639L, n);
            Object invoke3;
            try {
               invoke3 = d3.invoke(invoke2, a4);
            } catch (final InvocationTargetException ex3) {
               throw ex3.getTargetException();
            }
            final Object[] a5 = a(EventBus.c);
            final Method d4 = d(804355199932686594L, n);
            MethodHandle methodHandle;
            try {
               methodHandle = (MethodHandle)d4.invoke(invoke3, a5);
            } catch (final InvocationTargetException ex4) {
               throw ex4.getTargetException();
            }
            list2.add(new SubscriberMethod(method, o, parameterTypes[0], methodHandle));
         } catch (final Throwable t) {
         }
      }
      synchronized (this.b) {
         final Map a = this.a;
         if (!dReturningBoolean(new Object[] { a, o, l })) {
            final HashMap<Class, SubscriberMethod[]> a2 = new HashMap<Class, SubscriberMethod[]>(this.a);
            for (final Object entry : list2) {
               final SubscriberMethod subscriberMethod = (SubscriberMethod)entry;
               final SubscriberMethod[] existing = a2.get(subscriberMethod.aReturningClass(new Object[0]));
               SubscriberMethod[] merged;
               if (existing == null) {
                  merged = new SubscriberMethod[] { subscriberMethod };
               } else {
                  merged = new SubscriberMethod[existing.length + 1];
                  System.arraycopy(existing, 0, merged, 0, existing.length);
                  merged[existing.length] = subscriberMethod;
               }
               a2.put(subscriberMethod.aReturningClass(new Object[0]), merged);
            }
            this.a = a2;
         }
      }
   }
   public void bReturningVoid(Object[] var1) {
      boolean var52;
      java.lang.Object var53;

      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 93852033798039L ^ var3;
      int var5 = Event.bReturningInt();
      Object var51 = var2;
      if (var5 == 0) {
         if (var2 == null) {
            return;
         }

         var51 = this.b;
      }

      Object var6 = var51;
      synchronized (var51) {
         HashMap var7 = new HashMap(this.a);
         boolean var8 = false;
         ArrayList var22 = new ArrayList(var7.entrySet());
         Iterator var9 = var22.iterator();

         label116: {
            while (true) {
               if (var9.hasNext()) {
                  Entry var10 = (Entry)var9.next();
                  SubscriberMethod[] var11 = (SubscriberMethod[])var10.getValue();
                  SubscriberMethod[] var13 = var11;
                  int var14 = var11.length;
                  var52 = false;
                  if (var5 != 0) {
                     break;
                  }

                  while (var15 < var14) {
                     SubscriberMethod var16 = var13[var15];
                     if (var5 == 0) {
                        Object[] var27 = new Object[0];
                        var53 = var16.aReturningObject(var27);
                        if (var5 != 0) {
                           break label116;
                        }

                        if (var53 != var2) {
                           var12++;
                        }

                        var15++;
                     }

                     if (var5 != 0) {
                        break;
                     }
                  }

                  int var54 = var12;
                  if (var5 == 0) {
                     if (var12 == var11.length) {
                        continue;
                     }

                     var8 = true;
                     var54 = var12;
                  }

                  if (var5 == 0) {
                     if (var54 == 0) {
                        Object var36 = var10.getKey();
                        var7.remove(var36);
                        if (var5 == 0) {
                           continue;
                        }
                     }

                     var13 = new SubscriberMethod[var12];
                     var54 = 0;
                  }

                  var14 = var54;
                  SubscriberMethod[] var49 = var11;
                  int var50 = var11.length;
                  label93: {
                     while (var17 < var50) {
                        SubscriberMethod var18 = var49[var17];
                        if (var5 == 0) {
                           Object[] var39 = new Object[0];
                           Object var55 = var18.aReturningObject(var39);
                           if (var5 != 0) {
                              break label93;
                           }

                           if (var55 != var2) {
                              var13[var14++] = var18;
                           }

                           var17++;
                        }

                        if (var5 != 0) {
                           break;
                        }
                     }

                     Class var45 = (Class)var10.getKey();
                     var7.put(var45, var13);
                  }

                  if (var5 == 0) {
                     continue;
                  }
               }

               var52 = var8;
               break;
            }

            if (var52) {
               this.a = var7;
            }

            var53 = var6;
         }

         
      }
   }

   public boolean aReturningBoolean(Object[] var1) {
      Event var4 = (Event)var1[0];
      long var2 = (Long)var1[1];
      var2 = 93852033798039L ^ var2;
      long var5 = var2 ^ 42171463985498L;
      int var10000 = Event.bReturningInt();
      Map var10001 = this.a;
      Class var15 = var4.getClass();
      Map var14 = var10001;
      SubscriberMethod[] var8 = (SubscriberMethod[])var14.get(var15);
      int var7 = var10000;
      int var29 = var7;
      SubscriberMethod[] var28 = var8;
      SubscriberMethod[] var26 = var28;
      SubscriberMethod[] var25 = var28;
      if (var29 == 0) {
         SubscriberMethod[] var30 = var25;
         if (var30 == null) {
            Object[] var18 = new Object[0];
            Event var17 = var4;
            return var17.aReturningBoolean(var18);
         }

         var26 = var8;
      }

      SubscriberMethod[] var9 = var26;
      int var10 = var9.length;
      int var33;
      do {
         int var32 = var10;
         int var31 = var11;
         if (var31 >= var32) {
            break;
         }

         SubscriberMethod var12 = var9[var11];

         try {
            Object[] var21 = new Object[0];
            SubscriberMethod var20 = var12;
            var20.aReturningMethodHandle(var21).invokeExact((Event)var4);
         } catch (Throwable var34) {
            Object[] var22 = new Object[]{var12, var34, var5};
            cReturningVoid(var22);
         }

         var11++;
         var33 = var7;
      } while (var33 == 0);

      Object[] var24 = new Object[0];
      Event var23 = var4;
      return var23.aReturningBoolean(var24);
   }

   public boolean bReturningBoolean(Object[] var1) {
      Class var4 = (Class)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 93852033798039L ^ var2;
      int var21 = Event.bReturningInt();
      Class var8 = var4;
      Map var7 = this.a;
      SubscriberMethod[] var6 = (SubscriberMethod[])var7.get(var8);
      int var5 = var21;
      int var15 = var5;
      SubscriberMethod[] var14 = var6;
      SubscriberMethod[] var10 = var14;
      SubscriberMethod[] var9 = var14;
      if (var15 == 0) {
         SubscriberMethod[] var16 = var9;
         if (var16 == null) {
            return false;
         }

         var10 = var6;
      }

      int var22 = var10.length;
      int var18 = var5;
      int var17 = var22;
      int var12 = var17;
      int var11 = var17;
      if (var18 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var12);
      } else {
         int var19 = var11;
         if (var19 > 0) {
            byte var23 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var23);
         } else {
            return false;
         }
      }
   }

   public boolean cReturningBoolean(Object[] var1) {
      Class var2 = (Class)var1[0];
      Class var5 = (Class)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 93852033798039L ^ var3;
      int var36 = Event.cReturningInt();
      Class var13 = var2;
      Map var12 = this.a;
      SubscriberMethod[] var7 = (SubscriberMethod[])var12.get(var13);
      int var6 = var36;
      int var26 = var6;
      SubscriberMethod[] var25 = var7;
      SubscriberMethod[] var21 = var25;
      SubscriberMethod[] var20 = var25;
      if (var26 != 0) {
         SubscriberMethod[] var27 = var20;
         if (var27 == null) {
            return false;
         }

         var21 = var7;
      }

      SubscriberMethod[] var8 = var21;
      int var9 = var8.length;
      boolean var24;
      while (true) {
         int var29 = var9;
         int var28 = var10;
         if (var28 < var29) {
            SubscriberMethod var11 = var8[var10];
            int var30 = var6;
            if (var30 != 0) {
               Object[] var17 = new Object[0];
               SubscriberMethod var16 = var11;
               Object var19 = var16.aReturningObject(var17);
               Class var18 = var5;
               boolean var37 = var18.isInstance(var19);
               int var32 = var6;
               boolean var31 = var37;
               var24 = var31;
               boolean var22 = var31;
               if (var32 == 0) {
                  break;
               }

               boolean var33 = var22;
               boolean var23 = var33;
               boolean var34 = var23;
               if (var34) {
                  return true;
               }

               var10++;
            }

            int var35 = var6;
            if (var35 != 0) {
               continue;
            }
         }

         var24 = false;
         break;
      }

      return var24;
   }

   private static boolean dReturningBoolean(Object[] var0) {
      Map var1 = (Map)var0[0];
      Object var2 = var0[1];
      for (Object var18 : var1.values()) {
         SubscriberMethod[] var8 = (SubscriberMethod[])var18;
         for (SubscriberMethod var11 : var8) {
            if (var11.aReturningObject(new Object[0]) == var2) {
               return true;
            }
         }
      }
      return false;
   }
   private static void cReturningVoid(Object[] var0) {
      SubscriberMethod var4 = (SubscriberMethod)var0[0];
      Throwable var3 = (Throwable)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 93852033798039L ^ var1;
      int var23 = Event.bReturningInt();
      Object[] var8 = new Object[0];
      SubscriberMethod var7 = var4;
      Class var9 = var7.aReturningObject(var8).getClass();
      String var10001 = var9.getName();
      Object[] var11 = new Object[0];
      SubscriberMethod var10 = var4;
      Method var12 = var10.aReturningMethod(var11);
      String var6 = var10001 + "#" + var12.getName();
      int var5 = var23;
      int var21 = var5;
      if (var21 == 0) {
         Set var24 = d;
         Class var13 = var3.getClass();
         String var15 = var6 + ":" + var13.getName();
         Set var14 = var24;
         boolean var22 = var14.add(var15);
         if (!var22) {
            return;
         }

         String var18 = g + var6;
         PrintStream var17 = System.err;
         var17.println(var18);
      }

      Throwable var20 = var3;
      var20.printStackTrace();
   }

   static {

      java.lang.invoke.MethodType var6;
      aReturningVoid();
      Cipher var0;
      Cipher var10000 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(139851580918917L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var2 = var0.doFinal(
         "2±¨-!ó\u0087pI>\u0099ÈvF\u0012Ø½\u0090\u000e\u009e`g\u0094ÉÀS¥½b#\u009bëúQ\u0081\u008cæoÄÞ.P#D\fç\u0094\u0088e9ª»æÂK\u0085~\u009cO\u00adD\u009f\u0012+"
            .getBytes("ISO-8859-1")
      );
      String var9 = a(var2).intern();
      // g = var9;
      Object[] var4 = a(void.class, Event.class);
      Method var5 = d(5515225744173552963L, 139851580918917L);
      Object[] var11 = var4;
      Object var8 = null;

      try {
         var6 = (MethodType)var5.invoke(var8, var11);
      } catch (InvocationTargetException var3) {
         throw var3.getTargetException();
      }

      c = var6;
      d = ConcurrentHashMap.newKeySet();
   
      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 24;
            yield var15;
         }
         case 1 -> {
            byte var16 = 28;
            yield var16;
         }
         case 2 -> {
            byte var17 = 47;
            yield var17;
         }
         case 3 -> {
            byte var18 = 23;
            yield var18;
         }
         case 4 -> {
            byte var19 = 11;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 9;
            yield var21;
         }
         case 7 -> {
            byte var22 = 12;
            yield var22;
         }
         case 8 -> {
            byte var23 = 37;
            yield var23;
         }
         case 9 -> {
            byte var24 = 55;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 4;
            yield var26;
         }
         case 12 -> {
            byte var27 = 21;
            yield var27;
         }
         case 13 -> {
            byte var28 = 18;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 31;
            yield var30;
         }
         case 16 -> {
            byte var31 = 33;
            yield var31;
         }
         case 17 -> {
            byte var32 = 62;
            yield var32;
         }
         case 18 -> {
            byte var33 = 46;
            yield var33;
         }
         case 19 -> {
            byte var34 = 56;
            yield var34;
         }
         case 20 -> {
            byte var35 = 5;
            yield var35;
         }
         case 21 -> {
            byte var36 = 17;
            yield var36;
         }
         case 22 -> {
            byte var37 = 32;
            yield var37;
         }
         case 23 -> {
            byte var38 = 30;
            yield var38;
         }
         case 24 -> {
            byte var39 = 41;
            yield var39;
         }
         case 25 -> {
            byte var40 = 61;
            yield var40;
         }
         case 26 -> {
            byte var41 = 57;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 27;
            yield var43;
         }
         case 29 -> {
            byte var44 = 7;
            yield var44;
         }
         case 30 -> {
            byte var45 = 6;
            yield var45;
         }
         case 31 -> {
            byte var46 = 48;
            yield var46;
         }
         case 32 -> {
            byte var47 = 36;
            yield var47;
         }
         case 33 -> {
            byte var48 = 25;
            yield var48;
         }
         case 34 -> {
            byte var49 = 26;
            yield var49;
         }
         case 35 -> {
            byte var50 = 0;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 59;
            yield var52;
         }
         case 38 -> {
            byte var53 = 22;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 35;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 52;
            yield var57;
         }
         case 43 -> {
            byte var58 = 43;
            yield var58;
         }
         case 44 -> {
            byte var59 = 15;
            yield var59;
         }
         case 45 -> {
            byte var60 = 8;
            yield var60;
         }
         case 46 -> {
            byte var61 = 14;
            yield var61;
         }
         case 47 -> {
            byte var62 = 51;
            yield var62;
         }
         case 48 -> {
            byte var63 = 2;
            yield var63;
         }
         case 49 -> {
            byte var64 = 38;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 45;
            yield var66;
         }
         case 52 -> {
            byte var67 = 13;
            yield var67;
         }
         case 53 -> {
            byte var68 = 19;
            yield var68;
         }
         case 54 -> {
            byte var69 = 60;
            yield var69;
         }
         case 55 -> {
            byte var70 = 53;
            yield var70;
         }
         case 56 -> {
            byte var71 = 42;
            yield var71;
         }
         case 57 -> {
            byte var72 = 20;
            yield var72;
         }
         case 58 -> {
            byte var73 = 44;
            yield var73;
         }
         case 59 -> {
            byte var74 = 3;
            yield var74;
         }
         case 60 -> {
            byte var75 = 63;
            yield var75;
         }
         case 61 -> {
            byte var76 = 50;
            yield var76;
         }
         case 62 -> {
            byte var77 = 29;
            yield var77;
         }
         default -> 49;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "\\?\u0017\u0005I\u0013J?\u0012_Z\u0004]t\u0011YV\u0010L3\u0006N\u001d\u0000N";
      h[1] = "c)|lPz\u0016\twcA5w\u0007|hEo\u0003";
      h[2] = "^z\u0001KS7Uu\u0010\u000429^~\u0014^";
      h[3] = "x8\nq31n8\u000f+ &ys\f-,2h4\u001b:g Y";
      h[4] = int.class;
      i[4] = "java/lang/Integer";
      h[5] = "`Z5ZPvkU$\u0015=vkH0";
      h[6] = boolean.class;
      i[6] = "java/lang/Boolean";
      h[7] = "{AH2%beIR}Fva";
      h[8] = "bp\u0001VB tp\u0004\fQ7c;\u0007\n]#r|\u0010\u001d\u00162J";
      h[9] = "\u0014\u00184\t1}\u001f\u0017%FKy\f\u00165\t}}\u001b";
      h[10] = ">7\u000eN}% ?\u0014\u0001\u00005 ";
      h[11] = "\nv.k\u0017w\u0014~4$xp\u0012v!FPq\u0014";
      h[12] = "iG%\u000bd`wO?D\u0003afT2\u001e%g";
      h[13] = "'\u0014o\u000b\u000e89\u001cuDm,=Q\\\u0004T?4";
      h[14] = "\bBd*|X\u0003Mue Q\u0004Ow(&\u001a/Ff#=P";
      h[15] = void.class;
      i[15] = "java/lang/Void";
      h[16] = "}~\u000b/\t7vq\u001a`N5ap\u0016+\t\u0016rk\u0015!C\u0013vq\u0019\"B(";
      h[17] = "f\u0010I|$im\u001fX3ckz\u001eTx$Hi\u0005WrnMm\u001f[qov(=Prap|";
      h[18] = "\u0004\u0000\u0017A\u0019\\\u000f\u000f\u0006\u000e^^\u0018\u000e\nE\u0019}\u000b\u0015\tOSx\u000f\u000f\u0005LR";
      h[19] = "T|d\u0001`e!\\o\u000eq*L\\o\u0013e?";
      h[20] = "6\b\u0015cC0(\u0000\u000f,!,/\u001d";
      h[21] = "rmx)k2\u0007Ms&z}[Dt$x0]\u000f_-i;FE)";
      h[22] = "B?\u000b\u0014997\u001f\u0000\u001b(vV\u0011\u000b\u0010,,\"";
      h[23] = "i\u0019\u0004i7&b\u0016\u0015&J3p\f\u0017e";
      h[24] = "%\u0016;:\u001c<P605\rs18;>\t)E";
      h[25] = "6`U\u0000?:=oDOx8*nH\u0004?\u001b9uK\u000eu\u0002%qF";
      h[26] = "&\u0010*[\u000bo8\u00180\u0014Fu\"\u0012)HW\u007f\"\u0005ryJj5>2mWs8\u0014\u001dHW{5=5IQ";
      h[27] = "#\u00194\u007f^,V9?pOc774{K9C";
      h[28] = "1A7U\n\u001fDa<Z\u001bP%o7Q\u001f\nQ";
      h[29] = "\u000bi5H\u001bb~I>G\n-\u001fG5L\u000ewk";
      h[30] = "L/N\u001c\u001a R'TSw:J\"]\u001e@<I ";
      h[31] = "\u007f;(zS*a325\u001e0{9+i\u000f:{.pX\u00121v/,i\u00181a\u0012?h\u0015\u0012t*";
      h[32] = "8\u0004lH\u0010\u0015&\fv\u0007]\u000f<\u0006o[L\u0005<\u00114jQ\u000e1\u0010h[[\u000e&-{ZV-3\u0015>b[\u0019\u0001\u0000n\u007fW\u0005%";
      h[33] = "\u007fC:qUrtL+>-q|F";
      h[34] = "nn \nx\u001bea1E\u0005\u0003vf8\f";
      h[35] = "\b\u001dw\u0011Uy\rRQ\u0002\u0012~\u0016/u\u0002\u001eq\u000f";
      h[36] = "\rjs\u0001nRxJx\u000e\u007f\u001d\u0019Ds\u0005{Gm";
      h[37] = "=N)\u0016L\u00051Om\u0011w\baN\u0012\u0011\u0012\n\fT0\n\u0005\u0000|\u000b1F\u0010g";
      h[38] = "\u0011Y^&\u0019&A\u0006\u0013|'t+\r\\'HlEN\u001d;L\u001e";
      h[39] = "\u0003<G#x=\u00104VvIc\u000e4Nd1\u0007\u0003-Sp+jXn\u0011{I";
      h[40] = "eX\u000e\bn:{\u0019\f[\r:l[w\n|\u0007lX4\u0002a?x\u0018\f\u00157dk$";
      h[41] = "3*>?C]`)~|?Vo0AoN9;+?kZIawr~?";
      h[42] = "\u0012UNg\u001cKRJ](nYVNI+5]EDL\u000b\u0014HGB/>\u001e^H\u0013\u00164\u000eA\u001d/";
      h[43] = "+m-_>\u0005'liX\u0005\bwm\bX\u007f\u000e\u007f|,\\\u007f;ki=J\u0005\u000b*,kMk\u0007!z91";
      h[44] = "-\u000ff\t~\f8\n'\f\u001f\u000f<Xd\u001dc\t:5.\u0014f\u0001*^{\u0004r\t@";
      h[45] = "OpqsaA\u001f/<)_\u0012u$sr0\u000b\u001bg2n4y";
      h[46] = "3/5%5UkjdtEE\rk`'4Obl2y?.dcvyy\u0017nsi,E";
      h[47] = "N6B,\u0019i\u001ei\u000fv'8t!\u0016sV0\u001b&D-]QH=@&\u0016<\u001bb\u0004w'";
      h[48] = "`a\u0002\f.\u0007o&\u0005\u0002G\u0006\u007fq\u001eU;\u0000y\u001cT\\>\biw\u0001L*\u0000\u0003";
      h[49] = "\u0010\u000b\u001ck\tm\u0012\u0018B;ohP3\u001ez\u0013`M\u0019\u0015\u0001Vn\u0016\u001b\u001dq\f2[\u000ex=\u000b6DC\u0015nTr\u0015r";
      h[50] = "m:\u001fyz\u001c#`\bs\u0006\u000f>jg:a[;c\u0017`=\u0016.\u0006[g9\tck\b8}XR";
      h[51] = "\u001e\\V=\u000e7\u0012]\u0012:54TiM5R)F\\J4S\rUMP>S)/\u001bR7_3K\u0019Ai\u000fU\u0013D\u0014<\u00048@\u001bPm5";
      h[52] = "DO\u0007[_K\u0003\u0018_\\;\u001c\u0014\n8\u0006\\N\u0010\u0013H\\\u0000\u0003\u0005v\u0001X\u0006\u001a\u001c\u0006[\u0004K\u000fy";
      h[53] = "zw|!\u0001B/gh)kO'gyNRNw~`>\b\u0012:k\u0005";
      h[54] = "o`p{\u0016e7%!*frQ$%y\u0017\u007f>#w'\u001c\u001em8s,Ws>g7}f";
      h[55] = "=Tl_/\u001f`\u001b~bxd!\u00038\u0013p\u000b&Qf\u0018\u0011_ \u000eh\u0004u]3P8b";
      h[56] = "W<\u0018Ur\u0002\ns\nh%yKkL\u0019-\u0016L9\u0012\u0012L\u0012Lb\u0015\n=\u0015\\9\u001bh";
      h[57] = "FNgD\fr\u0013^sLfy\u001fUXF\u0016ev\u0012z\u0014\t(\u001bA%PX\u0019";
      h[58] = "*!%_:[?$dZ[X<V8Z'HG'9\u001d4\b*tfYe9";
      h[59] = "\u0004O5RGIC\u0018mU#\u001c_\npGx\u001cEv5\n[\u000bE\f{PL\u00019";
      h[60] = "(F\u001c$E7o\u0011D#!ux\u001aD>L\u000f,\u0018\u001e)D\u007fvDS<!6rBJ%Ql.\u000f_@";
      h[61] = "\u0006%8\u0016U&W>e\t%-\u000b+d\u0013I\u0014\u0017/it\u001e1\u0002=b\u0010\u001c\"\\m\u0004O\\,\f1`MOr\\Wd\u0006\u0019*\u001695\u001dD5f";
      h[62] = "\u001f\u0016U\"n\n\u0013\u0017\u0011%U\u0013C\u0016a'>\u0005U\u0011I&1\u0005.VLs:YC\u0005\u00137khG\u001aW(iQM\nH}U";
      h[63] = "D\fVO5\b\u0016^GIHX\bXP]4^\u000e5\u001aT1V\u001e^OD%^t";
      h[64] = "l(u)C`+\u007f-.'&8u7 \\X2l,}N8=++s'";
      h[65] = "\u000b9\u0017\u0004/D\f)L\nM_\u0001 \u001b;*5Y!J\u000e(E\u0003}\u0007\u001bM^\u001f&\u0014\u0005<Y\u000f}\u001ag";
      h[66] = "o~\u0005\u0013\u007f\u0004{-\u0012\u0007\u0019\u000bzh{\u001d}\u0000l+\u0016Dt\u001bq";
      h[67] = "\u0015\u0010\t9\u001e}H_\u001b\u0004I\u0006\tG]uAi\u000e\u0015\u0003~ ?\u0016\u0013\u000eaPeJ^\u001b\u0004";
      h[68] = "Ek0.k6Gxn~\r=\u0013n\u0012-h?~t06\u007f5\u000e+1zjR";
      h[69] = "\u001aX1\u0014\u0019\u001f\u000f]p\u0011x\u0014\u001b\u000eIP\u001f@\u001e\u00079\nC\r\u000bbu\rG\u0012F\u000f&R\u0003Cw";
      h[70] = "-y\u0002\u0004Bktp\u0019\u0019{~0|\u0002\u0014\u001f`J{\u0000\u001a\ta:$\u0001V\u001c\u0006#m\u001b\fG?)}\u0004Y{";
      h[71] = "5g|1`Fh(n\f7=)0(}?R.bvv^\f-$|7<\u0000,`{\f";
      h[72] = "P\u0003*\u00125\bR\u0010tBS\u0003\u0006\u0006\u0002\u00158\b\u0002\u0000#\u0014\u0016\u0001\u0017\u001a)\u0014(l\u0006\u0007t\u0014kWZ\u0003v\u001aS";
      h[73] = "H-HM\u001bf\u0013n\nFyvD)[J\u001dfI/6\u0015\u0005vLhT\u0019\u00042KS][\u0019h@\"ZKBf\"";
      h[74] = "ls\u001fF/@d~CO]a[\u001b>)fDn)\u0015MdW0y";
      h[75] = "Q?\u001dp\u0015\u0016\u0002<]3i\u001d\r%\u007f$\r\u000f\rY\u0018*T\u001b\u0005)Bv\u0019\u000e`";
      h[76] = "`\u001aO@\u00028tIXTd3u\fXX\u000f=w\u00071\u0010\u0003gf\u0013AJ_*sv\n\u0016\u00005}\u0018IW\u001c1\u000fOV\u0014\r?\u007f\u0015\nY\u0018Z4IUF\u00164w\bIBda0\u0012^[\n\"q\u000eZ)\r*p\u0012\r\u0010\u0007:oG1";
      h[77] = "'\u0003Q[<a\u007fF\u0000\nLs\u0019\u0001\u0017\u0002|hsA\b\u00113\u001a'E\fS>pgZ\u001f\u001cL";
      h[78] = "a#]0>Af3\u0006>\\Yq\u0000L+10j.\u00011,^;5\\.\\[u<^1-\\egPS";
      h[79] = "M /N@q\nwwI$1\re\u0010\u0013Ct\u0019|`I\u001f9\f\u0019)M\u0019 \u0015is\u0011T5p w\u0017M,\u0000z+ZXI";
      h[80] = "\u0016\u0007}O\u0010OI\u0012x\u0017pC\f$}W\fSwU|\u0010\u001f\u0013\u001a\u0006#TN\"";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(169681569712625L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(169681569712625L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(169681569712625L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 164;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 80;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 245;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 208;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 196;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 219;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 164;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 80;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 245;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bL_C0079",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bL" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Object[] b() {
      return new Object[0];
   }

   private static Object[] a(Object var0, Object var1) {
      return new Object[]{var0, var1};
   }

   private static Object[] a(Object var0) {
      return new Object[]{var0};
   }
}
