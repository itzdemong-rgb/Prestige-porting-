package dev.zprestige.prestige.api.eventbus;

import java.lang.invoke.MethodHandle;
import java.lang.reflect.Method;

public class SubscriberMethod {
   private final Method a;
   private final Object b;
   private final Class c;
   private final MethodHandle d;

   public SubscriberMethod(Method var1, Object var2, Class var3) {
      this(var1, var2, var3, null);
   }

   public SubscriberMethod(Method var1, Object var2, Class var3, MethodHandle var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public Method aReturningMethod(Object[] var1) {
      return this.a;
   }

   public Object aReturningObject(Object[] var1) {
      return this.b;
   }

   public Class aReturningClass(Object[] var1) {
      return this.c;
   }

   public MethodHandle aReturningMethodHandle(Object[] var1) {
      return this.d;
   }
}
