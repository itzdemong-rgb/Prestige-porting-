package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import java.awt.Color;

public class AmbientColorEvent extends Event {
   private Color a;
   private Color b;

   public AmbientColorEvent(Color var1) {
      this.a = var1;
      this.b = null;
   }

   public AmbientColorEvent(Color var1, Color var2) {
      this.a = var1;
      this.b = var2;
   }

   public Color aReturningColor(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      Color var2 = (Color)var1[0];
      this.a = var2;
   }

   public Color bReturningColor(Object[] var1) {
      return this.b;
   }

   public void cReturningVoid(Object[] var1) {
      Color var2 = (Color)var1[0];
      this.b = var2;
   }
}
