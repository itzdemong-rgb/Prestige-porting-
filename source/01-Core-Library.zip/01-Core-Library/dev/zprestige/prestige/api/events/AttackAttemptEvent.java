package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventPhase;

public class AttackAttemptEvent extends Event {
   private boolean b;

   public AttackAttemptEvent(EventPhase var1) {
      super(var1);
   }

   public boolean cReturningBoolean(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      this.b = var2;
   }
}
