package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.Entity;

public class AttackEntityEvent extends Event {
   private final Entity a;

   public AttackEntityEvent(Entity var1) {
      this.a = var1;
   }

   public Entity aReturningEntity(Object[] var1) {
      return this.a;
   }
}
