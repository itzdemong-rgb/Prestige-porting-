package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

public class BlockStateUpdateEvent extends Event {
   private final BlockPos a;
   private final BlockState b;

   public BlockStateUpdateEvent(BlockPos var1, BlockState var2) {
      this.a = var1;
      this.b = var2;
   }

   public BlockPos aReturningBlockPos(Object[] var1) {
      return this.a;
   }

   public BlockState aReturningBlockState(Object[] var1) {
      return this.b;
   }
}
