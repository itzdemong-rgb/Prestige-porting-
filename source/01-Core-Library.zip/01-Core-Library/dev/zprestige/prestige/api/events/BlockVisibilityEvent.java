package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.block.Block;

public class BlockVisibilityEvent extends Event {
   private final Block a;
   private boolean b = dev.prestige.recovery.SourceSupport.asBoolean(0);

   public BlockVisibilityEvent(Block var1) {
      this.a = var1;
   }

   public Block aReturningBlock(Object[] var1) {
      return this.a;
   }

   public boolean cReturningBoolean(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      this.b = var2;
   }
}
