package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class CameraPositionEvent extends Event {
   public static boolean a = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private double b;
   private double c;
   private double d;

   public CameraPositionEvent(double var1, double var3, double var5) {
      this.b = var1;
      this.c = var3;
      this.d = var5;
   }

   public final double aReturningDouble(Object[] var1) {
      return this.b;
   }

   public final void bReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      this.b = var2;
   }

   public final double bReturningDouble(Object[] var1) {
      return this.c;
   }

   public final void cReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      this.c = var2;
   }

   public final double cReturningDouble(Object[] var1) {
      return this.d;
   }

   public final void dReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      this.d = var2;
   }
}
