package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.client.render.Camera;
import org.joml.Matrix4f;

public class CameraRenderEvent extends Event {
   private final Camera a;
   private final float b;
   private final Matrix4f c;

   public CameraRenderEvent(Camera var1, float var2, Matrix4f var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public Camera aReturningCamera(Object[] var1) {
      return this.a;
   }

   public float aReturningFloat(Object[] var1) {
      return this.b;
   }

   public Matrix4f aReturningMatrix4f(Object[] var1) {
      return this.c;
   }
}
