package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class CameraRotationEvent extends Event {
   public static boolean a = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private float b;
   private float c;

   public CameraRotationEvent(float var1, float var2) {
      this.b = var1;
      this.c = var2;
   }

   public float aReturningFloat(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.b = var2;
   }

   public float bReturningFloat(Object[] var1) {
      return this.c;
   }

   public void cReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.c = var2;
   }
}
