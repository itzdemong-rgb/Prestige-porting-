package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;

public class EntityBoundingBoxEvent extends Event {
   private final Entity a;
   private Box b;

   public EntityBoundingBoxEvent(Entity var1, Box var2) {
      this.a = var1;
      this.b = var2;
   }

   public Entity aReturningEntity(Object[] var1) {
      return this.a;
   }

   public Box aReturningBox(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      Box var2 = (Box)var1[0];
      this.b = var2;
   }
}
