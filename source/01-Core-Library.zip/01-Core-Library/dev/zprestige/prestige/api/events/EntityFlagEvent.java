package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.Entity;

public class EntityFlagEvent extends Event {
   public final Entity a;
   public boolean b;

   public EntityFlagEvent(Entity var1) {
      this.a = var1;
   }
}
