package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;

public class EntityLabelEvent extends Event {
   private Text a;
   private Text b;
   private Entity c;

   public EntityLabelEvent(Text var1, Text var2) {
      this(var1, var2, null);
   }

   public EntityLabelEvent(Text var1, Text var2, Entity var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public Entity aReturningEntity(Object[] var1) {
      return this.c;
   }

   public void bReturningVoid(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      this.c = var2;
   }

   public Text aReturningText(Object[] var1) {
      return this.a;
   }

   public void cReturningVoid(Object[] var1) {
      Text var2 = (Text)var1[0];
      this.a = var2;
   }

   public Text bReturningText(Object[] var1) {
      return this.b;
   }

   public void dReturningVoid(Object[] var1) {
      Text var2 = (Text)var1[0];
      this.b = var2;
   }
}
