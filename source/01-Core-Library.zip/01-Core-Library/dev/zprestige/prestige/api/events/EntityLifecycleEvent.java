package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import net.minecraft.entity.Entity;

public class EntityLifecycleEvent extends Event {
   private final Entity a;

   public EntityLifecycleEvent(Entity var1, EventPhase var2) {
      super(var2);
      this.a = var1;
   }

   public Entity aReturningEntity(Object[] var1) {
      return this.a;
   }
}
