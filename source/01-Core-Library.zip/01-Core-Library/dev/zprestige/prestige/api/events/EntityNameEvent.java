package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;

public class EntityNameEvent extends Event {
   private final Entity a;
   private Text b;

   public EntityNameEvent(Entity var1, Text var2) {
      this.a = var1;
      this.b = var2;
   }

   public Entity aReturningEntity(Object[] var1) {
      return this.a;
   }

   public Text aReturningText(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      Text var2 = (Text)var1[0];
      this.b = var2;
   }
}
