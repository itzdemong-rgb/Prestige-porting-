package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import net.minecraft.entity.Entity;

public class EntityRotationEvent extends Event {
   public final Entity a;

   public EntityRotationEvent(Entity var1, EventPhase var2) {
      super(var2);
      this.a = var1;
   }
}
