package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.Entity;

public class EntityScalarEvent extends Event {
   private final Entity a;
   private float b;

   public EntityScalarEvent(Entity var1, float var2) {
      this.a = var1;
      this.b = var2;
   }

   public Entity aReturningEntity(Object[] var1) {
      return this.a;
   }

   public float aReturningFloat(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.b = var2;
   }
}
