package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.client.render.Frustum;

public class FrustumEvent extends Event {
   private final Frustum a;

   public FrustumEvent(Frustum var1) {
      this.a = var1;
   }

   public Frustum a(Object[] var1) {
      return this.a;
   }
}
