package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

public class HeldItemTransformEvent extends Event {
   private final MatrixStack a;
   private final Arm b;
   private final float c;
   private final float d;

   public HeldItemTransformEvent(MatrixStack var1, Arm var2, float var3, float var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public MatrixStack aReturningMatrixStack(Object[] var1) {
      return this.a;
   }

   public Arm aReturningArm(Object[] var1) {
      return this.b;
   }

   public float aReturningFloat(Object[] var1) {
      return this.c;
   }

   public float bReturningFloat(Object[] var1) {
      return this.d;
   }
}
