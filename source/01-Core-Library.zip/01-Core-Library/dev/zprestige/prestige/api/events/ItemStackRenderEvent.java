package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.item.ItemStack;

public class ItemStackRenderEvent extends Event {
   private ItemStack a;

   public ItemStackRenderEvent(ItemStack var1) {
      this.a = var1;
   }

   public ItemStack aReturningItemStack(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      ItemStack var2 = (ItemStack)var1[0];
      this.a = var2;
   }
}
