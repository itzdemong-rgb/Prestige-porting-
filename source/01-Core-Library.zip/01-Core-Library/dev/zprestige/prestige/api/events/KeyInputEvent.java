package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class KeyInputEvent extends Event {
   private final int a;
   private final int b;

   public KeyInputEvent(int var1, int var2) {
      this.a = var1;
      this.b = var2;
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   public int dReturningInt(Object[] var1) {
      return this.b;
   }
}
