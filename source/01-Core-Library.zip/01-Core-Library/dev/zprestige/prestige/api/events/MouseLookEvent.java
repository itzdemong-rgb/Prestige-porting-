package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public final class MouseLookEvent extends Event {
   private final double a;
   private final double b;

   public MouseLookEvent(double var1, double var3) {
      this.a = var1;
      this.b = var3;
   }

   public double aReturningDouble(Object[] var1) {
      return this.a;
   }

   public double bReturningDouble(Object[] var1) {
      return this.b;
   }
}
