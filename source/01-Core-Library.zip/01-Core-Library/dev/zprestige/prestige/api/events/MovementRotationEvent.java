package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventPhase;

public class MovementRotationEvent extends Event {
   public float a;
   public float b;
   public static float c;
   public static float d;

   public MovementRotationEvent(EventPhase var1, float var2, float var3) {
      super(var1);
      this.a = var2;
      this.b = var3;
   }
}
