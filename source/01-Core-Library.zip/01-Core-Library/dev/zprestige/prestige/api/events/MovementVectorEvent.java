package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.util.math.Vec3d;

public class MovementVectorEvent extends Event {
   private float a;
   private Vec3d b;

   public MovementVectorEvent(float var1) {
      this.a = var1;
   }

   public MovementVectorEvent(float var1, Vec3d var2) {
      this.a = var1;
      this.b = var2;
   }

   public float aReturningFloat(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.a = var2;
   }

   public Vec3d aReturningVec3d(Object[] var1) {
      return this.b;
   }

   public void cReturningVoid(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      this.b = var2;
   }
}
