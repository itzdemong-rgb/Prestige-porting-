package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventPhase;

public class NativePhaseEvent extends Event {
   public NativePhaseEvent(EventPhase var1) {
      super(var1);
   }
}
