package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import java.awt.Color;

public class OverlayStyleEvent extends Event {
   private float a;
   private float b;
   private Color c;
   private Float d;

   public OverlayStyleEvent(float var1, float var2, Color var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public Color aReturningColor(Object[] var1) {
      return this.c;
   }

   public void bReturningVoid(Object[] var1) {
      Color var2 = (Color)var1[0];
      this.c = var2;
   }

   public float aReturningFloat(Object[] var1) {
      return this.a;
   }

   public void cReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.a = var2;
   }

   public float bReturningFloat(Object[] var1) {
      return this.b;
   }

   public void dReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.b = var2;
   }

   public Float aReturningBoxedFloat(Object[] var1) {
      return this.d;
   }

   public void eReturningVoid(Object[] var1) {
      Float var2 = (Float)var1[0];
      this.d = var2;
   }
}
