package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.network.packet.Packet;

public class PacketSendEvent extends Event {
   private final Packet a;

   public PacketSendEvent(Packet var1) {
      this.a = var1;
   }

   public Packet a(Object[] var1) {
      return this.a;
   }
}
