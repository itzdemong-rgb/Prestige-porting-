package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.player.PlayerEntity;

public class PlayerHealthIndicatorEvent extends Event {
   private final PlayerEntity a;
   private String b;

   public PlayerHealthIndicatorEvent(PlayerEntity var1, String var2) {
      this.a = var1;
      this.b = var2;
   }

   public PlayerEntity aReturningPlayerEntity(Object[] var1) {
      return this.a;
   }

   public String aReturningString(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      this.b = var2;
   }
}
