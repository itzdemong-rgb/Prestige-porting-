package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class PlayerNameEvent extends Event {
   private String a;
   private String b;

   public PlayerNameEvent(String var1, String var2) {
      this.a = var1;
      this.b = var2;
   }

   public String aReturningString(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      this.a = var2;
   }

   public String bReturningString(Object[] var1) {
      return this.b;
   }

   public void cReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      this.b = var2;
   }
}
