package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.player.SkinTextures;

public class PlayerSkinEvent extends Event {
   private SkinTextures a;
   private final String b;

   public PlayerSkinEvent(SkinTextures var1, String var2) {
      this.a = var1;
      this.b = var2;
   }

   public SkinTextures aReturningSkinTextures(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      SkinTextures var2 = (SkinTextures)var1[0];
      this.a = var2;
   }

   public String aReturningString(Object[] var1) {
      return this.b;
   }
}
