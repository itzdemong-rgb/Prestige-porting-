package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventPhase;

public class PlayerUpdateEvent extends Event {
   private float a;
   private float b;
   public static float c;
   public static float d;

   public PlayerUpdateEvent(EventPhase var1, float var2, float var3) {
      super(var1);
      this.a = var2;
      this.b = var3;
   }

   public float aReturningFloat(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.a = var2;
   }

   public float bReturningFloat(Object[] var1) {
      return this.b;
   }

   public void cReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.b = var2;
   }
}
