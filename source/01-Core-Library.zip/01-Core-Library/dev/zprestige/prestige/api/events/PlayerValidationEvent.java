package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.player.PlayerEntity;

public class PlayerValidationEvent extends Event {
   private final PlayerEntity a;

   public PlayerValidationEvent(PlayerEntity var1) {
      this.a = var1;
   }

   public PlayerEntity aReturningPlayerEntity(Object[] var1) {
      return this.a;
   }
}
