package dev.zprestige.prestige.api.events;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;


import dev.zprestige.prestige.api.eventbus.Event;

public class Render2DEvent extends Event {
   public final MeshBufferManager a;
   public final RenderContext b;

   public Render2DEvent(MeshBufferManager var1, RenderContext var2) {
      this.a = var1;
      this.b = var2;
   }
}
