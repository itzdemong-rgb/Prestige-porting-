package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class ScoreboardRenderEvent extends Event {
}
