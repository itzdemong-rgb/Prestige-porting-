package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.entity.LivingEntity;

public class ShieldEntityEvent extends Event {
   public final LivingEntity a;

   public ShieldEntityEvent(LivingEntity var1) {
      this.a = var1;
   }
}
