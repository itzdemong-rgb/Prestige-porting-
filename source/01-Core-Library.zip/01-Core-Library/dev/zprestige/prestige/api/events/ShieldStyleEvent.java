package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import java.awt.Color;
import net.minecraft.util.math.Vec3d;

public class ShieldStyleEvent extends Event {
   public boolean b;
   public boolean a;
   public boolean c;
   public Vec3d d;
   public Vec3d e;
   public String f;
   public Color g;
   public Color h;
}
