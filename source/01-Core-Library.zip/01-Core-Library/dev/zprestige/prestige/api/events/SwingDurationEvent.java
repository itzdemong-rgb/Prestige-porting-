package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class SwingDurationEvent extends Event {
   public int a;

   public SwingDurationEvent(int var1) {
      this.a = var1;
   }
}
