package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class TotemAnimationEvent extends Event {
   private int a;

   public TotemAnimationEvent(int var1) {
      this.a = var1;
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   public void cReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      this.a = var2;
   }
}
