package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public final class VelocityEvent extends Event {
   private double a;
   private double b;
   private double c;

   public VelocityEvent(double var1, double var3, double var5) {
      this.a = var1;
      this.b = var3;
      this.c = var5;
   }

   public double aReturningDouble(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      this.a = var2;
   }

   public double bReturningDouble(Object[] var1) {
      return this.b;
   }

   public void cReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      this.b = var2;
   }

   public double cReturningDouble(Object[] var1) {
      return this.c;
   }

   public void dReturningVoid(Object[] var1) {
      double var2 = (Double)var1[0];
      this.c = var2;
   }
}
