package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.client.util.Window;

public class WindowEvent extends Event {
   private final Window a;

   public WindowEvent(Window var1) {
      this.a = var1;
   }

   public Window a(Object[] var1) {
      return this.a;
   }
}
