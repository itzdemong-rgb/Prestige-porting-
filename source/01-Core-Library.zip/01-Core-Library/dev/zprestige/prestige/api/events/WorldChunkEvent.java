package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;
import net.minecraft.world.chunk.WorldChunk;

public class WorldChunkEvent extends Event {
   private final WorldChunk a;

   public WorldChunkEvent(WorldChunk var1) {
      this.a = var1;
   }

   public WorldChunk a(Object[] var1) {
      return this.a;
   }
}
