package dev.zprestige.prestige.api.events;

import dev.zprestige.prestige.api.eventbus.Event;

public class WorldTimeEvent extends Event {
   private long a;

   public WorldTimeEvent(long var1) {
      this.a = var1;
   }

   public long aReturningLong(Object[] var1) {
      return this.a;
   }

   public void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      this.a = var2;
   }
}
