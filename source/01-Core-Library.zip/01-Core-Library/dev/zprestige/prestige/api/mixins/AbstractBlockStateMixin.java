package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.BlockVisibilityEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.block.AbstractBlock.AbstractBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

@CTransformer(AbstractBlockState.class)
public class AbstractBlockStateMixin {
   @CInject(
      method = "getAmbientOcclusionLightLevel(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;)F",
      target = @CTarget("RETURN"),
      cancellable = true
   )
   private void a(BlockView blockView, BlockPos blockPos, InjectionCallback cir) {
      boolean var5 = Prestige.w;
      if (!var5) {
         boolean var6 = NativeAccessBridge.aReturningVoid(Prestige.b, BlockVisibilityEvent.class);
         if (var6) {
            BlockVisibilityEvent var4 = NativeAccessBridge.bReturningVoid(null);
            boolean var7 = NativeAccessBridge.cReturningVoid(var4);
            if (var7) {
               cir.setReturnValue(1.0F);
            }
         }
      }
   }
}
