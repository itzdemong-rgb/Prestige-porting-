package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.PlayerSkinEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;

@CTransformer(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerEntityMixin {
   @CInject(method = "getSkin", target = @CTarget("RETURN"), cancellable = true)
   private void a(InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = NativeAccessBridge.dReturningVoid(Prestige.b, PlayerSkinEvent.class);
         if (var4) {
            PlayerSkinEvent var2 = NativeAccessBridge.eReturningVoid((SkinTextures)ci.getReturnValue(), ((AbstractClientPlayerEntity)((net.minecraft.client.network.AbstractClientPlayerEntity)(Object)(this))).getName().getString());
            boolean var5 = NativeAccessBridge.fReturningVoid(var2);
            if (var5) {
               ci.setReturnValue(NativeAccessBridge.gReturningVoid(var2));
            }

            return;
         }
      }
   }
}
