package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.BlockVisibilityEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;

@CTransformer(Block.class)
public class BlockMixin {
   @CInject(method = "shouldDrawSide", target = @CTarget("HEAD"), cancellable = true)
   public static void a(BlockState state, BlockState otherState, Direction side, InjectionCallback cir) {
      boolean var5 = Prestige.w;
      if (!var5) {
         boolean var6 = NativeAccessBridge.z(Prestige.b, BlockVisibilityEvent.class);
         if (var6) {
            BlockVisibilityEvent var4 = NativeAccessBridge.A(state.getBlock());
            boolean var7 = NativeAccessBridge.B(var4);
            if (var7) {
               cir.setReturnValue(NativeAccessBridge.C(var4));
            }
         }
      }
   }
}
