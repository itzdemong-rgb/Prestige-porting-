package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.CameraPositionEvent;
import dev.zprestige.prestige.api.events.CameraRotationEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.Camera;

@CTransformer(Camera.class)
public class CameraMixin {
   @CInject(method = "setPos", target = @CTarget("HEAD"), cancellable = true)
   private void a(double x, double y, double z, InjectionCallback ci) {
      boolean var9 = CameraPositionEvent.a;
      if (!var9) {
         boolean var10 = Prestige.w;
         if (!var10) {
            boolean var11 = NativeAccessBridge.D(Prestige.b, CameraPositionEvent.class);
            if (var11) {
               CameraPositionEvent var8 = NativeAccessBridge.E(x, y, z);
               boolean var12 = NativeAccessBridge.F(var8);
               if (var12) {
                  CameraPositionEvent.a = true;
                  NativeAccessBridge.K(NativeAccessBridge.G((Camera)((net.minecraft.client.render.Camera)(Object)(this))), NativeAccessBridge.H(var8), NativeAccessBridge.I(var8), NativeAccessBridge.J(var8));
                  CameraPositionEvent.a = false;
                  ci.cancel();
               }

               return;
            }
         }
      }
   }

   @CInject(method = "setRotation", target = @CTarget("HEAD"), cancellable = true)
   private void b(float yaw, float pitch, InjectionCallback ci) {
      boolean var5 = CameraRotationEvent.a;
      if (!var5) {
         boolean var6 = Prestige.w;
         if (!var6) {
            CameraRotationEvent var4 = NativeAccessBridge.L(yaw, pitch);
            boolean var7 = NativeAccessBridge.M(var4);
            if (var7) {
               CameraRotationEvent.a = true;
               NativeAccessBridge.Q(NativeAccessBridge.N((Camera)((net.minecraft.client.render.Camera)(Object)(this))), NativeAccessBridge.O(var4), NativeAccessBridge.P(var4));
               CameraRotationEvent.a = false;
               ci.cancel();
            }

            return;
         }
      }
   }
}
