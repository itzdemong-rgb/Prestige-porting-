package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.BlockVisibilityEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.chunk.ChunkOcclusionDataBuilder;
import net.minecraft.util.math.BlockPos;

@CTransformer(ChunkOcclusionDataBuilder.class)
public class ChunkOcclusionDataBuilderMixin {
   @CInject(method = "markClosed", target = @CTarget("HEAD"), cancellable = true)
   private void a(BlockPos pos, InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = NativeAccessBridge.R(Prestige.b, BlockVisibilityEvent.class);
         if (var4) {
            boolean var5 = NativeAccessBridge.T(NativeAccessBridge.S(null));
            if (var5) {
               ci.cancel();
            }
         }
      }
   }
}
