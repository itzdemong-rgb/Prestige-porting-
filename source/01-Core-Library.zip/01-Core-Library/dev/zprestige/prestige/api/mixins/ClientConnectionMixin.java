package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;


import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;

@CTransformer(ClientConnection.class)
public class ClientConnectionMixin {
   @CInject(method = "handlePacket", target = @CTarget("HEAD"), cancellable = true)
   private static <T extends PacketListener> void a(Packet<T> packet, PacketListener listener, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         boolean var5 = NativeAccessBridge.U(Prestige.b, PacketReceiveEvent.class);
         if (var5) {
            PacketReceiveEvent var3 = NativeAccessBridge.V(packet);
            boolean var6 = NativeAccessBridge.W(var3);
            if (var6) {
               ci.cancel();
            }
         }
      }
   }

   @CInject(method = "send(Lnet/minecraft/network/packet/Packet;)V", target = @CTarget("HEAD"), cancellable = true)
   private void b(Packet<?> packet, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         EventBus var5 = Prestige.b;
         if (var5 != null) {
            boolean var6 = NativeAccessBridge.X(Prestige.b, PacketSendEvent.class);
            if (var6) {
               PacketSendEvent var3 = NativeAccessBridge.Y(packet);
               boolean var7 = NativeAccessBridge.Z(var3);
               if (var7) {
                  ci.cancel();
                  return;
               }
            }
         }

         PacketQueueManager var8 = Prestige.u;
         if (var8 != null) {
            NativeAccessBridge.aa(Prestige.u, packet);
         }
      }
   }
}
