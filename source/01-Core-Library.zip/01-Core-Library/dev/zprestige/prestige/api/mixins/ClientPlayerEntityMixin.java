package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;


import com.mojang.authlib.GameProfile;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Hand;

@CTransformer(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin extends AbstractClientPlayerEntity {
   public ClientPlayerEntityMixin(ClientWorld world, GameProfile profile) {
      super(world, profile);
   }

   @CInject(method = "swingHand", target = @CTarget("HEAD"), cancellable = true)
   private void a(Hand hand, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         EventBus var5 = Prestige.b;
         if (var5 != null) {
            boolean var6 = NativeAccessBridge.af(Prestige.b, AttackAttemptEvent.class);
            if (var6) {
               AttackAttemptEvent var3 = NativeAccessBridge.ag(EventPhase.PRE);
               boolean var7 = NativeAccessBridge.ah(var3);
               if (var7) {
                  ci.cancel();
               } else {
                  boolean var8 = NativeAccessBridge.ai(var3);
                  if (!var8) {
                     boolean var9 = NativeAccessBridge.ak(NativeAccessBridge.aj(EventPhase.POST));
                     if (var9) {
                        ci.cancel();
                     }
                  }
               }

               return;
            }
         }
      }
   }

   @CInject(method = "sendMovementPackets", target = @CTarget("HEAD"))
   private void b() {
      boolean var5 = Prestige.w;
      if (!var5) {
         PlayerUpdateEvent.c = this.getYaw();
         PlayerUpdateEvent.d = this.getPitch();
         PlayerUpdateEvent var1 = NativeAccessBridge.al(EventPhase.PRE, PlayerUpdateEvent.c, PlayerUpdateEvent.d);
         boolean var2 = NativeAccessBridge.am(var1);
         RotationManager var6 = Prestige.o;
         Rotation var4;
         if (var6 == null) {
            Object var7 = null;
            var4 = (Rotation)var7;
         } else {
            var4 = NativeAccessBridge.an(Prestige.o);
         }

         Rotation var3 = var4;
         Rotation var8 = var3;
         if (var8 != null) {
            this.setYaw(NativeAccessBridge.ao(var3));
            this.setPitch(NativeAccessBridge.ap(var3));
         } else {
            boolean var9 = var2;
            if (var9) {
               this.setYaw(NativeAccessBridge.aq(var1));
               this.setPitch(NativeAccessBridge.ar(var1));
            }
         }
      }
   }

   @CInject(method = "sendMovementPackets", target = @CTarget("RETURN"))
   private void c() {
      boolean var2 = Prestige.w;
      if (!var2) {
         PlayerUpdateEvent var1 = NativeAccessBridge.as(EventPhase.POST, PlayerUpdateEvent.c, PlayerUpdateEvent.d);
         NativeAccessBridge.at(var1);
         this.setYaw(PlayerUpdateEvent.c);
         this.setPitch(PlayerUpdateEvent.d);
      }
   }
}
