package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.AttackEntityEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

@CTransformer(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
   @CInject(method = "attackEntity", target = @CTarget("HEAD"), cancellable = true)
   private void a(PlayerEntity player, Entity target, InjectionCallback ci) {
      boolean var5 = Prestige.w;
      if (!var5) {
         ClientPlayerEntity var6 = MinecraftClient.getInstance().player;
         if (var6 != null) {
            boolean var7 = player.equals(MinecraftClient.getInstance().player);
            if (var7) {
               AttackEntityEvent var4 = NativeAccessBridge.au(target);
               boolean var8 = NativeAccessBridge.av(var4);
               if (var8) {
                  ci.cancel();
               }
            }
         }
      }
   }
}
