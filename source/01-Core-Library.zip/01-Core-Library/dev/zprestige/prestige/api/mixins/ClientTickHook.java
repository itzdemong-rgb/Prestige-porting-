package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.TickEvent;


import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

@CTransformer(MinecraftClient.class)
public class ClientTickHook {
   @CInject(
      method = "tick",
      target = @CTarget(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;tick(Z)V", shift = CTarget.Shift.AFTER),
      cancellable = true
   )
   public void a(InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         ClientWorld var4 = MinecraftClient.getInstance().world;
         if (var4 != null) {
            ClientPlayerEntity var5 = MinecraftClient.getInstance().player;
            if (var5 != null) {
               ModuleManager.f = false;
               TickEvent var2 = NativeAccessBridge.da();
               boolean var6 = NativeAccessBridge.db(var2);
               if (var6) {
                  ci.cancel();
               }

               return;
            }
         }
      }
   }

   @CInject(method = "tick", target = @CTarget("HEAD"), cancellable = true)
   public void b(InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = ModuleManager.f;
         if (var4) {
            ClientWorld var5 = MinecraftClient.getInstance().world;
            if (var5 != null) {
               ClientPlayerEntity var6 = MinecraftClient.getInstance().player;
               if (var6 != null) {
                  TickEvent var2 = NativeAccessBridge.dc();
                  boolean var7 = NativeAccessBridge.dd(var2);
                  if (var7) {
                     ci.cancel();
                  }

                  return;
               }
            }

            return;
         }
      }
   }

   @CInject(method = "tick", target = @CTarget("HEAD"))
   public void c(InjectionCallback ci) {
      boolean var2 = Prestige.w;
      if (!var2) {
         NativeAccessBridge.df(NativeAccessBridge.de());
      }
   }

   @CInject(method = "onResolutionChanged", target = @CTarget("TAIL"))
   public void d(InjectionCallback ci) {
      boolean var2 = Prestige.w;
      if (!var2) {
         NativeAccessBridge.dh(NativeAccessBridge.dg(MinecraftClient.getInstance().getWindow()));
      }
   }

   @CInject(method = "doItemUse", target = @CTarget("HEAD"), cancellable = true)
   public void e(InjectionCallback ci) {
      boolean var2 = Prestige.w;
      if (!var2) {
         boolean var3 = NativeAccessBridge.dj(NativeAccessBridge.di());
         if (var3) {
            ci.cancel();
         }
      }
   }

   @CInject(method = "doAttack", target = @CTarget("HEAD"), cancellable = true)
   public void f(InjectionCallback cir) {
      boolean var2 = Prestige.w;
      if (!var2) {
         boolean var3 = NativeAccessBridge.dl(NativeAccessBridge.dk());
         if (var3) {
            cir.setReturnValue(false);
         }
      }
   }

   @CInject(method = "handleBlockBreaking", target = @CTarget("HEAD"), cancellable = true)
   public void g(boolean bl, InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = NativeAccessBridge.dn(NativeAccessBridge.dm());
         if (var4) {
            ci.cancel();
         }
      }
   }
}
