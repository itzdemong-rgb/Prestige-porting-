package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.EntityLifecycleEvent;


import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Entity.RemovalReason;

@CTransformer(ClientWorld.class)
public class ClientWorldMixin {
   @CInject(method = "addEntity", target = @CTarget("TAIL"))
   private void a(Entity entity, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         Entity var5 = entity;
         if (var5 != null) {
            EntityLifecycleEvent var3 = NativeAccessBridge.aw(entity, EventPhase.PRE);
            NativeAccessBridge.ax(var3);
         }
      }
   }

   @CInject(method = "removeEntity", target = @CTarget("HEAD"))
   private void b(int entityId, RemovalReason removalReason, InjectionCallback ci) {
      boolean var7 = Prestige.w;
      if (!var7) {
         ClientWorld var4 = (ClientWorld)((net.minecraft.client.world.ClientWorld)(Object)(this));
         ClientWorld var8 = var4;
         if (var8 != null) {
            Entity var5 = var4.getEntityById(entityId);
            Entity var9 = var5;
            if (var9 != null) {
               EntityLifecycleEvent var6 = NativeAccessBridge.ay(var5, EventPhase.POST);
               NativeAccessBridge.az(var6);
            }
         }
      }
   }
}
