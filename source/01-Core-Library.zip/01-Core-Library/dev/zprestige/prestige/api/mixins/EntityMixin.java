package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.EntityBoundingBoxEvent;
import dev.zprestige.prestige.api.events.MovementVectorEvent;
import dev.zprestige.prestige.api.events.VelocityEvent;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@CTransformer(Entity.class)
public abstract class EntityMixin {
   @CInject(method = "updateVelocity", target = @CTarget("HEAD"), cancellable = true)
   private void a(float speed, Vec3d movementInput, InjectionCallback ci) {
      boolean var17 = Prestige.w;
      if (!var17) {
         Entity var4 = (Entity)((net.minecraft.entity.Entity)(Object)(this));
         MinecraftClient var5 = MinecraftClient.getInstance();
         ClientPlayerEntity var19 = var5.player;
         Entity var18 = var4;
         if (var18 == var19) {
            RotationManager var20 = Prestige.o;
            if (var20 != null) {
               Rotation var21 = NativeAccessBridge.aA(Prestige.o);
               if (var21 != null) {
                  MovementVectorEvent var6 = NativeAccessBridge.aB(var4.getYaw(), movementInput);
                  boolean var22 = NativeAccessBridge.aC(var6);
                  if (var22) {
                     float var7 = NativeAccessBridge.aD(var6);
                     Vec3d var23 = NativeAccessBridge.aE(var6);
                     Vec3d var15;
                     if (var23 != null) {
                        Vec3d var24 = NativeAccessBridge.aF(var6);
                        var15 = var24;
                     } else {
                        var15 = movementInput;
                     }

                     Vec3d var8 = var15;
                     double var9 = var8.lengthSquared();
                     double var28;
                     int var25 = (var28 = var9 - 1.0E-7) == 0.0 ? 0 : (var28 < 0.0 ? -1 : 1);
                     Vec3d var11;
                     if (var25 < 0) {
                        var11 = Vec3d.ZERO;
                     } else {
                        double var29;
                        int var26 = (var29 = var9 - 1.0) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
                        Vec3d var16;
                        if (var26 > 0) {
                           Vec3d var27 = var8.normalize();
                           var16 = var27;
                        } else {
                           var16 = var8;
                        }

                        Vec3d var12 = var16.multiply(speed);
                        float var13 = MathHelper.sin(var7 * (float) (Math.PI / 180.0));
                        float var14 = MathHelper.cos(var7 * (float) (Math.PI / 180.0));
                        var11 = NativeAccessBridge.aG(var12.x * var14 - var12.z * var13, var12.y, var12.z * var14 + var12.x * var13);
                     }

                     var4.setVelocity(var4.getVelocity().add(var11));
                     ci.cancel();
                  }

                  return;
               }
            }
         }
      }
   }

   @CInject(method = "getBoundingBox", target = @CTarget("RETURN"), cancellable = true)
   private void b(InjectionCallback cir) {
      boolean var5 = Prestige.w;
      if (!var5) {
         Entity var2 = (Entity)((net.minecraft.entity.Entity)(Object)(this));
         Entity var6 = var2;
         if (var6 != null) {
            boolean var7 = NativeAccessBridge.aH(Prestige.b, EntityBoundingBoxEvent.class);
            if (var7) {
               Box var3 = (Box)cir.getReturnValue();
               EntityBoundingBoxEvent var4 = NativeAccessBridge.aI(var2, var3);
               boolean var8 = NativeAccessBridge.aJ(var4);
               if (var8) {
                  cir.setReturnValue(NativeAccessBridge.aK(var4));
               }
            }
         }
      }
   }

   @CInject(method = "setVelocityClient", target = @CTarget("HEAD"), cancellable = true)
   public void c(Vec3d velocity, InjectionCallback ci) {
      boolean var5 = Prestige.w;
      if (!var5) {
         Entity var3 = (Entity)((net.minecraft.entity.Entity)(Object)(this));
         ClientPlayerEntity var7 = MinecraftClient.getInstance().player;
         Entity var6 = var3;
         if (var6 == var7) {
            VelocityEvent var4 = NativeAccessBridge.aL(velocity.x, velocity.y, velocity.z);
            boolean var8 = NativeAccessBridge.aM(var4);
            if (var8) {
               var3.setVelocity(NativeAccessBridge.aN(var4), NativeAccessBridge.aO(var4), NativeAccessBridge.aP(var4));
               ci.cancel();
            }
         }
      }
   }

   @CInject(method = "getRotationVec", target = @CTarget("HEAD"), cancellable = true)
   public void d(float tickDelta, InjectionCallback cir) {
      MinecraftClient var3 = MinecraftClient.getInstance();
      MinecraftClient var5 = var3;
      if (var5 != null) {
         ClientPlayerEntity var6 = var3.player;
         if (var6 != null) {
            ClientPlayerEntity var8 = var3.player;
            EntityMixin var7 = this;
            if ((Object)var7 == var8) {
               boolean var9 = Prestige.w;
               if (!var9) {
                  RotationManager var10 = Prestige.o;
                  if (var10 != null) {
                     Rotation var4 = NativeAccessBridge.aQ(Prestige.o);
                     Rotation var11 = var4;
                     if (var11 != null) {
                        cir.setReturnValue(var3.player.getRotationVector(NativeAccessBridge.aR(var4), NativeAccessBridge.aS(var4)));
                     }

                     return;
                  }
               }
            }
         }
      }
   }
}
