package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.EntityLabelEvent;
import dev.zprestige.prestige.api.events.EntityNameEvent;
import dev.zprestige.prestige.api.events.EntityRotationEvent;
import dev.zprestige.prestige.api.events.LightmapEvent;
import dev.zprestige.prestige.api.events.PlayerHealthIndicatorEvent;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.client.management.VisualRotationManager;


import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

@CTransformer(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
   @CInject(method = "getAndUpdateRenderState", target = @CTarget("HEAD"))
   public void a(T entity, float tickDelta) {
      boolean var3 = Prestige.w;
      if (!var3) {
         ClientPlayerEntity var5 = MinecraftClient.getInstance().player;
         Entity var4 = entity;
         if (var4 == var5) {
            EventBus var6 = Prestige.b;
            if (var6 != null) {
               RotationManager var7 = Prestige.o;
               if (var7 != null) {
                  Rotation var8 = NativeAccessBridge.aT(Prestige.o);
                  if (var8 != null) {
                     boolean var9 = NativeAccessBridge.aU(Prestige.b, EntityRotationEvent.class);
                     if (var9) {
                        NativeAccessBridge.aW(NativeAccessBridge.aV(entity, EventPhase.PRE));
                        return;
                     }
                  }
               }
            }

            return;
         }
      }
   }

   @CInject(method = "getAndUpdateRenderState", target = @CTarget("RETURN"))
   public void b(T entity, float tickDelta) {
      boolean var3 = Prestige.w;
      if (!var3) {
         ClientPlayerEntity var5 = MinecraftClient.getInstance().player;
         Entity var4 = entity;
         if (var4 == var5) {
            EventBus var6 = Prestige.b;
            if (var6 != null) {
               VisualRotationManager var7 = Prestige.p;
               if (var7 != null) {
                  boolean var8 = NativeAccessBridge.aX(Prestige.p);
                  if (var8) {
                     boolean var9 = NativeAccessBridge.aY(Prestige.b, EntityRotationEvent.class);
                     if (var9) {
                        NativeAccessBridge.ba(NativeAccessBridge.aZ(entity, EventPhase.POST));
                        return;
                     }
                  }
               }
            }

            return;
         }
      }
   }

   @CInject(method = "getSkyLight", target = @CTarget("RETURN"), cancellable = true)
   private void c(T entity, BlockPos pos, InjectionCallback cir) {
      boolean var5 = Prestige.w;
      if (!var5) {
         boolean var6 = NativeAccessBridge.bb(Prestige.b, LightmapEvent.class);
         if (var6) {
            LightmapEvent var4 = NativeAccessBridge.bc();
            boolean var7 = NativeAccessBridge.bd(var4);
            if (var7) {
               cir.setReturnValue(15);
            }
         }
      }
   }

   @CInject(method = "updateRenderState", target = @CTarget("RETURN"))
   public void d(T entity, S state, float tickDelta) {
      boolean var18 = Prestige.w;
      if (!var18) {
         EventBus var19 = Prestige.b;
         if (var19 != null) {
            Text var20 = state.displayName;
            if (var20 != null) {
               boolean var4 = NativeAccessBridge.be(Prestige.b, EntityNameEvent.class);
               boolean var5 = NativeAccessBridge.bf(Prestige.b, PlayerHealthIndicatorEvent.class);
               boolean var6 = NativeAccessBridge.bg(Prestige.b, EntityLabelEvent.class);
               boolean var21 = var4;
               if (!var21) {
                  boolean var22 = var5;
                  if (!var22) {
                     boolean var23 = var6;
                     if (!var23) {
                        return;
                     }
                  }
               }

               Text var7 = state.displayName;
               Text var8 = var7;
               boolean var24 = entity instanceof PlayerEntity;
               if (var24) {
                  PlayerEntity var9 = (PlayerEntity)entity;
                  boolean var25 = entity.isAlive();
                  label44:
                  if (var25) {
                     boolean var26 = var4;
                     if (!var26) {
                        boolean var27 = var5;
                        if (!var27) {
                           break label44;
                        }
                     }

                     EntityNameEvent var10 = NativeAccessBridge.bh(entity, var8);
                     boolean var11 = NativeAccessBridge.bi(var10);
                     var8 = NativeAccessBridge.bj(var10);
                     boolean var28 = var11;
                     if (!var28) {
                        PlayerHealthIndicatorEvent var12 = NativeAccessBridge.bk(var9, "");
                        boolean var29 = NativeAccessBridge.bl(var12);
                        if (var29) {
                           var8 = Text.of(var8.getString() + NativeAccessBridge.bm(var12));
                        }
                     }
                  }
               }

               boolean var30 = var6;
               if (var30) {
                  EntityLabelEvent var38 = NativeAccessBridge.bn(var7, var8, entity);
                  boolean var31 = NativeAccessBridge.bo(var38);
                  if (var31) {
                     state.displayName = null;
                     return;
                  }
               }

               EntityRenderState var16;
               Text var17;
               label37: {
                  Text var33 = var8;
                  EntityRenderState var32 = state;
                  EntityRenderState var14 = var32;
                  EntityRenderState var13 = var32;
                  if (var33 != null) {
                     boolean var35 = var8.getString().isEmpty();
                     EntityRenderState var34 = var13;
                     EntityRenderState var15 = var34;
                     var14 = var34;
                     if (!var35) {
                        var17 = var8;
                        var16 = var15;
                        break label37;
                     }
                  }

                  Object var37 = null;
                  EntityRenderState var36 = var14;
                  var16 = var36;
                  var17 = (Text)var37;
               }

               var16.displayName = var17;
               return;
            }
         }
      }
   }
}
