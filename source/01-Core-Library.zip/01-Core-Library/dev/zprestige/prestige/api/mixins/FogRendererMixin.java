package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.OverlayStyleEvent;


import com.mojang.blaze3d.buffers.Std140Builder;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.nio.ByteBuffer;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector4f;

@CTransformer(FogRenderer.class)
public class FogRendererMixin {
   @CInject(method = "applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V", target = @CTarget("HEAD"), cancellable = true)
   private void a(
      ByteBuffer buffer,
      int bufPos,
      Vector4f fogColor,
      float environmentalStart,
      float environmentalEnd,
      float renderDistanceStart,
      float renderDistanceEnd,
      float skyEnd,
      float cloudEnd,
      InjectionCallback ci
   ) {
      if (!Prestige.w) {
         if (NativeAccessBridge.hReturningVoid(Prestige.b, OverlayStyleEvent.class)) {
            OverlayStyleEvent event = NativeAccessBridge.iReturningVoid(0.0F, 0.0F, Color.WHITE);
            if (NativeAccessBridge.jReturningVoid(event)) {
               Vector4f color = NativeAccessBridge.o(
                  NativeAccessBridge.kReturningVoid(event).getRed() / 255.0F,
                  NativeAccessBridge.lReturningVoid(event).getGreen() / 255.0F,
                  NativeAccessBridge.mReturningVoid(event).getBlue() / 255.0F,
                  NativeAccessBridge.nReturningVoid(event).getAlpha() / 255.0F
               );
               Float skyOv = NativeAccessBridge.p(event);
               float effectiveSkyEnd = skyOv == null ? skyEnd : skyOv;
               buffer.position(bufPos);
               Std140Builder.intoBuffer(buffer)
                  .putVec4(color)
                  .putFloat(NativeAccessBridge.q(event))
                  .putFloat(NativeAccessBridge.r(event))
                  .putFloat(NativeAccessBridge.s(event))
                  .putFloat(NativeAccessBridge.t(event))
                  .putFloat(effectiveSkyEnd)
                  .putFloat(cloudEnd);
               ci.cancel();
            }
         }
      }
   }

   @CInject(
      method = "applyFog(Lnet/minecraft/client/render/Camera;ILnet/minecraft/client/render/RenderTickCounter;FLnet/minecraft/client/world/ClientWorld;)Lorg/joml/Vector4f;",
      target = @CTarget("TAIL"),
      cancellable = true
   )
   private void b(Camera camera, int viewDistance, RenderTickCounter tickCounter, float tickProgress, ClientWorld world, InjectionCallback ci) {
      boolean var9 = Prestige.w;
      if (!var9) {
         boolean var10 = NativeAccessBridge.u(Prestige.b, OverlayStyleEvent.class);
         if (var10) {
            OverlayStyleEvent var7 = NativeAccessBridge.v(0.0F, 0.0F, Color.WHITE);
            boolean var11 = NativeAccessBridge.w(var7);
            if (var11) {
               Color var8 = NativeAccessBridge.x(var7);
               ci.setReturnValue(NativeAccessBridge.y(var8.getRed() / 255.0F, var8.getGreen() / 255.0F, var8.getBlue() / 255.0F, var8.getAlpha() / 255.0F));
            }
         }
      }
   }
}
