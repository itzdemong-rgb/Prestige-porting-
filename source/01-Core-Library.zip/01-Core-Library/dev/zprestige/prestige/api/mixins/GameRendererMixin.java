package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.EntityReachEvent;
import dev.zprestige.prestige.api.events.HurtCameraEvent;
import dev.zprestige.prestige.api.events.TotemAnimationEvent;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.GlStateSnapshot;
import dev.zprestige.prestige.renderlib.RenderContext;

import java.util.List;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;


import com.mojang.blaze3d.systems.RenderSystem;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.profiler.Profilers;

@CTransformer(GameRenderer.class)
public class GameRendererMixin {
   @CShadow("client")
   public MinecraftClient client;
   @CShadow("guiRenderer")
   private GuiRenderer guiRenderer;

   @CInject(method = "render", target = @CTarget("TAIL"))
   public void a(RenderTickCounter tickCounter, boolean tick) {
      List<Runnable> delayedActions = NativeAccessBridge.bp();
      boolean renderWork = !Prestige.w && Prestige.b != null && NativeAccessBridge.bq();
      if (!renderWork && delayedActions.isEmpty()) {
         NativeAccessBridge.br();
         NativeAccessBridge.bs();
      } else {
         GlStateSnapshot cap = NativeAccessBridge.bt();
         boolean var11 = false ;

         label55: {
            try {
               var11 = true;
               NativeAccessBridge.bu(delayedActions);
               if (!renderWork) {
                  NativeAccessBridge.bv();
                  NativeAccessBridge.bw();
                  var11 = false;
                  break label55;
               }

               Window window = this.client.getWindow();
               Matrix4f proj = NativeAccessBridge.bB(
                  NativeAccessBridge.bA(NativeAccessBridge.bz(NativeAccessBridge.by(this.guiRenderer))),
                  (float)window.getFramebufferWidth() / window.getScaleFactor(),
                  (float)window.getFramebufferHeight() / window.getScaleFactor()
               );
               RenderContext context = NativeAccessBridge.bD(proj, NativeAccessBridge.bC().setTranslation(0.0F, 0.0F, -10000.0F), null);
               NativeAccessBridge.bE(context);
               var11 = false;
            } finally {
               if (var11) {
                  NativeAccessBridge.bG(cap);
               }
            }

            NativeAccessBridge.bF(cap);
            return;
         }

         NativeAccessBridge.bx(cap);
      }
   }

   @CInject(target = @CTarget("HEAD"), method = "renderWorld")
   private void b(RenderTickCounter tickCounter) {
      if (!Prestige.w && NativeAccessBridge.bH()) {
         Camera camera = this.client.gameRenderer.getCamera();
         MatrixStack matrixStack = NativeAccessBridge.bI();
         RenderSystem.getModelViewStack().pushMatrix().mul(matrixStack.peek().getPositionMatrix());
         matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
         matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
         GameRenderUtil.e.set(RenderSystem.getModelViewMatrix());
         GameRenderUtil.f.set(matrixStack.peek().getPositionMatrix());
         RenderSystem.getModelViewStack().popMatrix();
      }
   }

   @CInject(target = @CTarget("HEAD"), method = "tiltViewWhenHurt", cancellable = true)
   private void c(MatrixStack matrices, float tickDelta, InjectionCallback ci) {
      boolean var5 = Prestige.w;
      if (!var5) {
         EventBus var6 = Prestige.b;
         if (var6 != null) {
            boolean var7 = NativeAccessBridge.bJ(Prestige.b, HurtCameraEvent.class);
            if (var7) {
               HurtCameraEvent var4 = NativeAccessBridge.bK();
               boolean var8 = NativeAccessBridge.bL(var4);
               if (var8) {
                  ci.cancel();
               }

               return;
            }
         }
      }
   }

   @CInject(target = @CTarget("HEAD"), method = "tick")
   private void d() {
      boolean var3 = Prestige.w;
      if (!var3) {
         EventBus var4 = Prestige.b;
         if (var4 != null) {
            boolean var5 = NativeAccessBridge.bM(Prestige.b, TotemAnimationEvent.class);
            if (var5) {
               TotemAnimationEvent var1 = NativeAccessBridge.bN(0);
               NativeAccessBridge.bO(var1);
               while (true) {
                  int var7 = NativeAccessBridge.bP(var1);
                  int var6 = var2;
                  if (var6 >= var7) {
                     return;
                  }

                  NativeAccessBridge.bR(NativeAccessBridge.bQ((GameRenderer)((net.minecraft.client.render.GameRenderer)(Object)(this)))).tickFloatingItemTimer();
                  var2++;
               }
            }
         }
      }
   }

   @CInject(method = "updateCrosshairTarget", target = @CTarget("HEAD"), cancellable = true)
   public void e(float tickDelta, InjectionCallback ci) {
      boolean var22 = Prestige.w;
      if (!var22) {
         EventBus var23 = Prestige.b;
         if (var23 != null) {
            boolean var24 = NativeAccessBridge.bS(Prestige.b, EntityReachEvent.class);
            if (var24) {
               Entity var3 = this.client.getCameraEntity();
               Entity var25 = var3;
               if (var25 == null) {
                  return;
               }

               ClientWorld var26 = this.client.world;
               if (var26 == null) {
                  return;
               }

               Profilers.get().push("pick");
               this.client.targetedEntity = null;
               double var4 = NativeAccessBridge.bT();
               EntityReachEvent var6 = NativeAccessBridge.bU(0.0F);
               boolean var7 = NativeAccessBridge.bV(var6);
               boolean var27 = var7;
               if (var27) {
                  var4 += NativeAccessBridge.bW(var6);
               }

               this.client.crosshairTarget = var3.raycast(var4, tickDelta, false);
               Vec3d var8 = var3.getCameraPosVec(tickDelta);
               boolean var9 = false;
               double var11 = var4;
               boolean var28 = this.client.player.isCreative();
               if (var28) {
                  var11 = 6.0;
                  var4 = 6.0;
               } else {
                  double var41;
                  int var29 = (var41 = var11 - 3.0) == 0.0 ? 0 : (var41 < 0.0 ? -1 : 1);
                  if (var29 > 0) {
                     boolean var30 = var7;
                     if (!var30) {
                        var9 = true;
                     }
                  }

                  var4 = var11;
               }

               var11 *= var11;
               HitResult var31 = this.client.crosshairTarget;
               if (var31 != null) {
                  var11 = this.client.crosshairTarget.getPos().squaredDistanceTo(var8);
               }

               Vec3d var13 = var3.getRotationVec(1.0F);
               Vec3d var14 = var8.add(var13.x * var4, var13.y * var4, var13.z * var4);
               Box var16 = var3.getBoundingBox().stretch(var13.multiply(var4)).expand(1.0, 1.0, 1.0);
               EntityHitResult var17 = ProjectileUtil.raycast(var3, var8, var14, var16, NativeAccessBridge.bX(), var11);
               EntityHitResult var32 = var17;
               label51:
               if (var32 != null) {
                  Entity var18 = var17.getEntity();
                  Vec3d var19 = var17.getPos();
                  double var20 = var8.squaredDistanceTo(var19);
                  boolean var33 = var9;
                  if (var33) {
                     double var42;
                     int var34 = (var42 = var20 - 9.0) == 0.0 ? 0 : (var42 < 0.0 ? -1 : 1);
                     if (var34 > 0) {
                        this.client.crosshairTarget = BlockHitResult.createMissed(
                           var19, Direction.getFacing(var13.x, var13.y, var13.z), BlockPos.ofFloored(var19)
                        );
                        break label51;
                     }
                  }

                  double var43;
                  int var35 = (var43 = var20 - var11) == 0.0 ? 0 : (var43 < 0.0 ? -1 : 1);
                  if (var35 >= 0) {
                     HitResult var36 = this.client.crosshairTarget;
                     if (var36 != null) {
                        break label51;
                     }
                  }

                  this.client.crosshairTarget = var17;
                  boolean var37 = var18 instanceof LivingEntity;
                  if (!var37) {
                     boolean var38 = var18 instanceof ItemFrameEntity;
                     if (!var38) {
                        break label51;
                     }
                  }

                  this.client.targetedEntity = var18;
               }

               Profilers.get().pop();
               ci.cancel();
               return;
            }
         }
      }
   }
}
