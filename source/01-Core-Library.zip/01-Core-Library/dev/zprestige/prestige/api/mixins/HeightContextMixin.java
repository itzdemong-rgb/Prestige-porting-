package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.HeightBoundsAccessor;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;


import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.gen.HeightContext;
import net.minecraft.world.gen.chunk.ChunkGenerator;

@CTransformer(HeightContext.class)
public class HeightContextMixin {
   @CInject(method = "<init>", target = @CTarget("HEAD"), cancellable = true)
   private void a(ChunkGenerator generator, HeightLimitView world, InjectionCallback ci) {
      ChunkGenerator var5 = generator;
      if (var5 == null) {
         HeightBoundsAccessor var4 = NativeAccessBridge.bY(this);
         NativeAccessBridge.bZ(var4, -9999999);
         NativeAccessBridge.ca(var4, 100000000);
         ci.cancel();
      }
   }
}
