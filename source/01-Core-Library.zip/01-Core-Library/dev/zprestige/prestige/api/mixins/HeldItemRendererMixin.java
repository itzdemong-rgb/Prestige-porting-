package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.HeldItemTransformEvent;

import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

@CTransformer(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
   @CInject(method = "swingArm", target = @CTarget("HEAD"), cancellable = true)
   private void a(float swingProgress, MatrixStack matrixStack, int i, Arm arm, InjectionCallback ci) {
      boolean var7 = Prestige.w;
      if (!var7) {
         boolean var8 = NativeAccessBridge.cb(Prestige.b, HeldItemTransformEvent.class);
         if (var8) {
            HeldItemTransformEvent var6 = NativeAccessBridge.cc(matrixStack, arm, swingProgress, 1.0F);
            boolean var9 = NativeAccessBridge.cd(var6);
            if (var9) {
               matrixStack.scale(2.0F, 2.0F, 2.0F);
               ci.cancel();
            }

            return;
         }
      }
   }
}
