package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.CrosshairRenderEvent;
import dev.zprestige.prestige.api.events.HotbarItemNameEvent;
import dev.zprestige.prestige.api.events.MovementPhaseEvent;
import dev.zprestige.prestige.api.events.ScoreboardRenderEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;

@CTransformer(InGameHud.class)
public class InGameHudMixin {
   @CInject(method = "renderStatusEffectOverlay", target = @CTarget("HEAD"), cancellable = true)
   private void a(DrawContext context, RenderTickCounter tickCounter, InjectionCallback ci) {
      boolean var5 = Prestige.w;
      if (!var5) {
         MovementPhaseEvent var4 = NativeAccessBridge.ce();
         boolean var6 = NativeAccessBridge.cf(var4);
         if (var6) {
            ci.cancel();
         }
      }
   }

   @CInject(method = "renderCrosshair", target = @CTarget("HEAD"), cancellable = true)
   private void b(DrawContext context, RenderTickCounter tickCounter, InjectionCallback ci) {
      boolean var5 = Prestige.w;
      if (!var5) {
         boolean var6 = NativeAccessBridge.cg(Prestige.b, CrosshairRenderEvent.class);
         if (var6) {
            CrosshairRenderEvent var4 = NativeAccessBridge.ch();
            boolean var7 = NativeAccessBridge.ci(var4);
            if (var7) {
               ci.cancel();
            }

            return;
         }
      }
   }

   @CInject(method = "renderScoreboardSidebar", target = @CTarget("HEAD"), cancellable = true)
   private void c(DrawContext context, RenderTickCounter counter, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         boolean var5 = NativeAccessBridge.cj(Prestige.b, ScoreboardRenderEvent.class);
         if (var5) {
            boolean var6 = NativeAccessBridge.cl(NativeAccessBridge.ck());
            if (var6) {
               ci.cancel();
            }

            return;
         }
      }
   }

   @CInject(method = "renderOverlayMessage", target = @CTarget("HEAD"), cancellable = true)
   private void d(DrawContext context, RenderTickCounter tickCounter, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         boolean var5 = NativeAccessBridge.cm(Prestige.b, HotbarItemNameEvent.class);
         if (var5) {
            boolean var6 = NativeAccessBridge.co(NativeAccessBridge.cn());
            if (var6) {
               ci.cancel();
            }

            return;
         }
      }
   }
}
