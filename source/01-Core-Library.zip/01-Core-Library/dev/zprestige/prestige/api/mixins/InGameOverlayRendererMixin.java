package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.FireOverlayEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

@CTransformer(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
   @CInject(
      method = "renderFireOverlay",
      target = @CTarget(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"),
      cancellable = true
   )
   private static void a(MatrixStack matrices, VertexConsumerProvider vertexConsumers, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         FireOverlayEvent var3 = NativeAccessBridge.cp();
         boolean var5 = NativeAccessBridge.cq(var3);
         if (var5) {
            ci.cancel();
         }
      }
   }
}
