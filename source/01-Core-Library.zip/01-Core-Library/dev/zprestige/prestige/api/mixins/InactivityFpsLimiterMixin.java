package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.client.ui.ClickGuiScreen;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.InactivityFpsLimiter;

@CTransformer(InactivityFpsLimiter.class)
public class InactivityFpsLimiterMixin {
   @CInject(method = "update", target = @CTarget("HEAD"), cancellable = true)
   public void a(InjectionCallback cir) {
      boolean var4 = Prestige.w;
      if (!var4) {
         MinecraftClient var2 = MinecraftClient.getInstance();
         ClickGuiScreen var5 = Prestige.k;
         if (var5 != null) {
            ClickGuiScreen var7 = Prestige.k;
            Screen var6 = var2.currentScreen;
            if (var6 == var7) {
               int var3 = (Integer)var2.options.getMaxFps().getValue();
               cir.setReturnValue(var3);
            }
         }
      }
   }
}
