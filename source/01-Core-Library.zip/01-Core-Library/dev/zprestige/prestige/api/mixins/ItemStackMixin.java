package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.BlockBounceEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.item.ItemStack;

@CTransformer(ItemStack.class)
public class ItemStackMixin {
   @CInject(method = "getBobbingAnimationTime", target = @CTarget("HEAD"), cancellable = true)
   private void a(InjectionCallback info) {
      boolean var2 = Prestige.w;
      if (!var2) {
         boolean var3 = NativeAccessBridge.cr(Prestige.b, BlockBounceEvent.class);
         if (var3) {
            boolean var4 = NativeAccessBridge.ct(NativeAccessBridge.cs());
            if (var4) {
               info.setReturnValue(0);
            }

            return;
         }
      }
   }

   @CInject(method = "setBobbingAnimationTime", target = @CTarget("HEAD"), cancellable = true)
   public void b(int bobbingAnimationTime, InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = NativeAccessBridge.cu(Prestige.b, BlockBounceEvent.class);
         if (var4) {
            boolean var5 = NativeAccessBridge.cw(NativeAccessBridge.cv());
            if (var5) {
               ci.cancel();
            }

            return;
         }
      }
   }
}
