package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.NativePhaseEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;


import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec2f;

@CTransformer(KeyboardInput.class)
public class KeyboardInputMixin extends Input {
   @CInject(method = "tick", target = @CTarget("HEAD"))
   private void a(InjectionCallback ci) {
      NativePhaseEvent var2 = NativeAccessBridge.cz(EventPhase.PRE);
      NativeAccessBridge.cA(var2);
   }

   @CInject(method = "tick", target = @CTarget("RETURN"))
   private void b(InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         NativePhaseEvent var2 = NativeAccessBridge.cB(EventPhase.POST);
         NativeAccessBridge.cC(var2);
      }
   }

   @CInject(method = "tick", target = @CTarget("RETURN"))
   private void c(InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         PacketQueueManager var4 = Prestige.u;
         if (var4 != null) {
            boolean var5 = NativeAccessBridge.cD(Prestige.u);
            if (var5) {
               this.playerInput = NativeAccessBridge.cE(false, false, false, false, false, false, false);
               this.movementVector = Vec2f.ZERO;
            } else {
               boolean var6 = NativeAccessBridge.cF(Prestige.u);
               if (var6) {
                  boolean var7 = this.hasForwardMovement();
                  if (var7) {
                     MinecraftClient var2 = MinecraftClient.getInstance();
                     ClientPlayerEntity var8 = var2.player;
                     if (var8 != null) {
                        boolean var9 = var2.player.isSprinting();
                        if (!var9) {
                           var2.player.setSprinting(true);
                        }
                     }
                  }
               }
            }

            return;
         }
      }
   }
}
