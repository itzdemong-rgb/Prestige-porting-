package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.KeyInputEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyInput;

@CTransformer(Keyboard.class)
public class KeyboardMixin {
   @CShadow("client")
   public MinecraftClient client;

   @CInject(method = "onKey", target = @CTarget("HEAD"), cancellable = true)
   private void a(long window, int action, KeyInput input, InjectionCallback ci) {
      int var6 = input.getKeycode();
      boolean var8 = Prestige.w;
      if (!var8) {
         // int var9 = var6;
         if (var9 != var10) {
            KeyInputEvent var7 = NativeAccessBridge.cx(var6, action);
            boolean var11 = NativeAccessBridge.cy(var7);
            if (var11) {
               ci.cancel();
            }
         }
      }
   }
}
