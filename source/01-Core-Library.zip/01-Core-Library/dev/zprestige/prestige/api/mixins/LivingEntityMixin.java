package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.MovementRotationEvent;
import dev.zprestige.prestige.api.events.MovementVectorEvent;
import dev.zprestige.prestige.api.events.ShieldEntityEvent;
import dev.zprestige.prestige.api.events.SwingDurationEvent;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;


import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@CTransformer(LivingEntity.class)
public abstract class LivingEntityMixin {
   @CInject(method = "travel", target = @CTarget("HEAD"))
   private void a(Vec3d movementInput, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         ClientPlayerEntity var5 = MinecraftClient.getInstance().player;
         if (var5 != null) {
            boolean var6 = ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).equals(MinecraftClient.getInstance().player);
            if (var6) {
               RotationManager var7 = Prestige.o;
               if (var7 != null) {
                  Rotation var8 = NativeAccessBridge.cJ(Prestige.o);
                  if (var8 != null) {
                     MovementRotationEvent var3 = NativeAccessBridge.cK(EventPhase.PRE, ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).getYaw(), ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).getPitch());
                     boolean var9 = NativeAccessBridge.cL(var3);
                     if (var9) {
                        MovementRotationEvent.c = ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).getYaw();
                        MovementRotationEvent.d = ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).getPitch();
                        ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).setYaw(var3.a);
                        ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).setPitch(var3.b);
                     }

                     return;
                  }
               }
            }
         }
      }
   }

   @CInject(method = "travel", target = @CTarget("RETURN"))
   private void b(Vec3d movementInput) {
      boolean var3 = Prestige.w;
      if (!var3) {
         ClientPlayerEntity var4 = MinecraftClient.getInstance().player;
         if (var4 != null) {
            boolean var5 = ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).equals(MinecraftClient.getInstance().player);
            if (var5) {
               RotationManager var6 = Prestige.o;
               if (var6 != null) {
                  Rotation var7 = NativeAccessBridge.cM(Prestige.o);
                  if (var7 != null) {
                     MovementRotationEvent var2 = NativeAccessBridge.cN(EventPhase.POST, ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).getYaw(), ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).getPitch());
                     boolean var8 = NativeAccessBridge.cO(var2);
                     if (var8) {
                        ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).setYaw(MovementRotationEvent.c);
                        ((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))).setPitch(MovementRotationEvent.d);
                     }

                     return;
                  }
               }
            }
         }
      }
   }

   @CInject(method = "getHandSwingDuration", target = @CTarget("HEAD"), cancellable = true)
   private void c(InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         EventBus var4 = Prestige.b;
         if (var4 != null) {
            boolean var5 = NativeAccessBridge.cP(Prestige.b, SwingDurationEvent.class);
            if (var5) {
               SwingDurationEvent var2 = NativeAccessBridge.cQ(0);
               boolean var6 = NativeAccessBridge.cR(var2);
               if (var6) {
                  ci.setReturnValue(var2.a);
               }

               return;
            }
         }
      }
   }

   @CInject(method = "handleStatus", target = @CTarget("HEAD"))
   private void d(byte status) {
      boolean var2 = Prestige.w;
      if (!var2) {
         EventBus var3 = Prestige.b;
         if (var3 != null) {
            boolean var4 = NativeAccessBridge.cS(Prestige.b, ShieldEntityEvent.class);
            if (var4) {
               byte var6 = 30;
               byte var5 = status;
               if (var5 == var6) {
                  NativeAccessBridge.cU(NativeAccessBridge.cT((LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this))));
               }

               return;
            }
         }
      }
   }

   @CInject(
      method = "jump",
      target = @CTarget(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;addVelocityInternal(Lnet/minecraft/util/math/Vec3d;)V"),
      cancellable = true
   )
   private void e(InjectionCallback ci) {
      boolean var6 = Prestige.w;
      if (!var6) {
         LivingEntity var2 = (LivingEntity)((net.minecraft.entity.LivingEntity)(Object)(this));
         ClientPlayerEntity var8 = MinecraftClient.getInstance().player;
         LivingEntity var7 = var2;
         if (var7 == var8) {
            RotationManager var9 = Prestige.o;
            if (var9 != null) {
               Rotation var10 = NativeAccessBridge.cV(Prestige.o);
               if (var10 != null) {
                  float var3 = var2.getYaw();
                  MovementVectorEvent var4 = NativeAccessBridge.cW(var3);
                  boolean var11 = NativeAccessBridge.cX(var4);
                  if (var11) {
                     var3 = NativeAccessBridge.cY(var4);
                     float var5 = var3 * (float) (Math.PI / 180.0);
                     var2.setVelocity(var2.getVelocity().add(-MathHelper.sin(var5) * 0.2F, 0.0, MathHelper.cos(var5) * 0.2F));
                     var2.velocityDirty = true;
                     ci.cancel();
                  }

                  return;
               }
            }
         }
      }
   }
}
