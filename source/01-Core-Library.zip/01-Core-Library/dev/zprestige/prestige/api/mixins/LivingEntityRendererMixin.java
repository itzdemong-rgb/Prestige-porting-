package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.client.management.EntityModelManager;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;

@CTransformer(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
   @CShadow("model")
   private EntityModel<?> model;

   @CInject(method = "isVisible", target = @CTarget("HEAD"), cancellable = true)
   private void a(LivingEntityRenderState state, InjectionCallback ci) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = EntityModelManager.e;
         if (var4) {
            boolean var5 = EntityModelManager.f;
            if (var5) {
               EntityModel var6 = this.model;
               if (var6 == null) {
                  return;
               }

               boolean var7 = NativeAccessBridge.cZ(this.model);
               if (!var7) {
                  return;
               }

               ci.setReturnValue(true);
               return;
            }
         }
      }
   }
}
