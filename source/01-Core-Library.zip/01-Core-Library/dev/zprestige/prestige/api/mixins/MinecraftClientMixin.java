package dev.zprestige.prestige.api.mixins;

import net.lenni0451.classtransform.annotations.CTransformer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

@CTransformer(MinecraftClient.class)
public class MinecraftClientMixin extends Screen {
   protected MinecraftClientMixin(Text title) {
      super(title);
   }
}
