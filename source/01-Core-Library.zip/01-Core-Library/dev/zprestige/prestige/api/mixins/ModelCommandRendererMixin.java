package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.client.management.EntityModelManager;
import dev.zprestige.prestige.renderlib.FramebufferEffect;


import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.client.modules.ESP;
import java.util.Optional;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.lenni0451.classtransform.annotations.injection.CRedirect;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.command.ModelCommandRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl.ModelCommand;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;

@CTransformer(ModelCommandRenderer.class)
public class ModelCommandRendererMixin {
   @CInject(
      method = "render(Lnet/minecraft/client/render/command/OrderedRenderCommandQueueImpl$ModelCommand;Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/client/render/OutlineVertexConsumerProvider;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;)V",
      target = @CTarget("HEAD")
   )
   private void a(
      ModelCommand<?> model,
      RenderLayer renderLayer,
      VertexConsumer vertexConsumer,
      OutlineVertexConsumerProvider outlineVertexConsumers,
      Immediate crumblingOverlayVertexConsumers
   ) {
      boolean var6 = EntityModelManager.e;
      if (var6) {
         ESP.u.set(renderLayer);
      }
   }

   @CInject(
      method = "render(Lnet/minecraft/client/render/command/OrderedRenderCommandQueueImpl$ModelCommand;Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/client/render/OutlineVertexConsumerProvider;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;)V",
      target = @CTarget("RETURN")
   )
   private void b() {
      boolean var1 = EntityModelManager.e;
      if (var1) {
         ESP.u.remove();
      }
   }

   @CRedirect(
      method = "render(Lnet/minecraft/client/render/command/OrderedRenderCommandQueueImpl$ModelCommand;Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/client/render/OutlineVertexConsumerProvider;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;)V",
      target = @CTarget(
         value = "INVOKE",
         target = "Lnet/minecraft/client/model/Model;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V",
         ordinal = 0
      )
   )
   private void c(Model model, MatrixStack matrices, VertexConsumer originalConsumer, int light, int overlay, int color) {
      VertexConsumer var7 = originalConsumer;
      RenderLayer var8 = (RenderLayer)ESP.u.get();
      boolean var12 = EntityModelManager.e;
      if (var12) {
         RenderLayer var13 = var8;
         if (var13 != null) {
            boolean var14 = model instanceof EntityModel;
            if (var14) {
               EntityModel var9 = (EntityModel)model;
               FramebufferEffect var15 = NativeAccessBridge.methodDo();
               if (var15 != null) {
                  boolean var16 = NativeAccessBridge.dp(var9);
                  label19:
                  if (var16) {
                     Screen var17 = MinecraftAccess.b.currentScreen;
                     if (var17 != null) {
                        boolean var18 = MinecraftAccess.b.currentScreen instanceof ChatScreen;
                        if (!var18) {
                           break label19;
                        }
                     }

                     Optional var10 = NativeAccessBridge.dq(var8);
                     Integer var11 = (Integer)var10.orElse(null);
                     Integer var19 = var11;
                     if (var19 != null) {
                        var7 = NativeAccessBridge.dr(originalConsumer, var11);
                     }
                  }
               }
            }
         }
      }

      model.render(matrices, var7, light, overlay, color);
   }
}
