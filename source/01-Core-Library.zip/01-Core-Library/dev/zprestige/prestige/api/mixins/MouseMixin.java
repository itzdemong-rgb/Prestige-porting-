package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.MouseLookEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;

@CTransformer(Mouse.class)
public class MouseMixin {
   @CShadow("cursorDeltaX")
   public double cursorDeltaX;
   @CShadow("cursorDeltaY")
   public double cursorDeltaY;

   @CInject(method = "updateMouse", target = @CTarget("HEAD"), cancellable = true)
   private void a(double timeDelta, InjectionCallback ci) {
      boolean var5 = Prestige.w;
      if (!var5) {
         boolean var6 = NativeAccessBridge.ds(Prestige.b, MouseLookEvent.class);
         if (var6) {
            MouseLookEvent var4 = NativeAccessBridge.dt(this.cursorDeltaX, this.cursorDeltaY);
            boolean var7 = NativeAccessBridge.du(var4);
            if (var7) {
               ci.cancel();
            }

            return;
         }
      }
   }

   @CInject(method = "onMouseButton", target = @CTarget("HEAD"))
   private void b(long window, MouseInput input, int action, InjectionCallback ci) {
      int var6 = input.button();
      boolean var7 = Prestige.w;
      if (!var7) {
         
         if (var8 != var9) {
            NativeAccessBridge.dw(NativeAccessBridge.dv(var6, action));
         }
      }
   }
}
