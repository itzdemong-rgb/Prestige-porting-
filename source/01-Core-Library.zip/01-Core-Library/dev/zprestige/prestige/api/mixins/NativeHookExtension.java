package dev.zprestige.prestige.api.mixins;

import net.lenni0451.classtransform.annotations.CTransformer;
import net.minecraft.client.MinecraftClient;

@CTransformer(MinecraftClient.class)
public class NativeHookExtension {
}
