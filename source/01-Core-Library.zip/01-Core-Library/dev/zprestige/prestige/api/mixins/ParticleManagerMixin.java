package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.ParticleRenderEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;

@CTransformer(ParticleManager.class)
public class ParticleManagerMixin {
   @CInject(method = "addParticle", target = @CTarget("HEAD"), cancellable = true)
   private void a(Particle particle, InjectionCallback ci) {
      boolean var4 = Prestige.w;
      if (!var4) {
         boolean var5 = NativeAccessBridge.dy(Prestige.b, ParticleRenderEvent.class);
         if (var5) {
            ParticleRenderEvent var3 = NativeAccessBridge.dz();
            boolean var6 = NativeAccessBridge.dA(var3);
            if (var6) {
               ci.cancel();
            }
         }
      }
   }
}
