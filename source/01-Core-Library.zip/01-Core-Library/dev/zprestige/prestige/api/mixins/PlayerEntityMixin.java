package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.entity.player.PlayerEntity;

@CTransformer(PlayerEntity.class)
public class PlayerEntityMixin {
   @CInject(method = "resetTicksSince", target = @CTarget("HEAD"), cancellable = true)
   private void a(InjectionCallback ci) {
      boolean var2 = Prestige.w;
      if (!var2) {
         boolean var3 = NativeAccessBridge.dC(NativeAccessBridge.dB());
         if (var3) {
            ci.cancel();
         }
      }
   }
}
