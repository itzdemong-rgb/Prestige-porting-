package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.PlayerSkinEvent;


import com.mojang.authlib.GameProfile;
import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.SkinTextures;

@CTransformer(PlayerListEntry.class)
public class PlayerListEntryMixin {
   @CShadow("profile")
   public GameProfile profile;

   @CInject(method = "getSkinTextures", target = @CTarget("RETURN"), cancellable = true)
   private void a(InjectionCallback ci) {
      GameProfile var3 = this.profile;
      if (var3 != null) {
         boolean var4 = Prestige.w;
         if (!var4) {
            boolean var5 = NativeAccessBridge.dD(Prestige.b, PlayerSkinEvent.class);
            if (var5) {
               PlayerSkinEvent var2 = NativeAccessBridge.dF((SkinTextures)ci.getReturnValue(), NativeAccessBridge.dE(this.profile));
               boolean var6 = NativeAccessBridge.dG(var2);
               if (var6) {
                  ci.setReturnValue(NativeAccessBridge.dH(var2));
               }

               return;
            }
         }
      }
   }
}
