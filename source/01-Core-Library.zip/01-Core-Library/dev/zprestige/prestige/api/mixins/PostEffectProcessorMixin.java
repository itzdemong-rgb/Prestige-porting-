package dev.zprestige.prestige.api.mixins;

import net.lenni0451.classtransform.annotations.CTransformer;
import net.minecraft.client.gl.PostEffectProcessor;

@CTransformer(PostEffectProcessor.class)
public class PostEffectProcessorMixin {
}
