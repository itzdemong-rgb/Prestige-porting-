package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;


import java.util.Optional;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.resource.ReloadableResourceManagerImpl;
import net.minecraft.util.Identifier;

@CTransformer(ReloadableResourceManagerImpl.class)
public class ReloadableResourceManagerImplMixin {
   @CInject(method = "getResource", target = @CTarget("HEAD"), cancellable = true)
   public void a(Identifier identifier, InjectionCallback callbackInfoReturnable) {
      boolean var3 = identifier.getNamespace().equals("prestige");
      if (var3) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dI(identifier)));
      }

      boolean var4 = identifier.getPath().equals("shaders/post/glow.json");
      if (var4) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dJ("assets/prestige/shaders/post/glow.json")));
      }

      boolean var5 = identifier.getPath().equals("shaders/program/glow.json");
      if (var5) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dK("assets/prestige/shaders/program/glow.json")));
      }

      boolean var6 = identifier.getPath().equals("shaders/program/glow.fsh");
      if (var6) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dL("assets/prestige/shaders/program/glow.fsh")));
      }

      boolean var7 = identifier.getPath().equals("shaders/core/blur.json");
      if (var7) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dM("assets/minecraft/shaders/core/blur.json")));
      }

      boolean var8 = identifier.getPath().equals("shaders/core/blur.fsh");
      if (var8) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dN("assets/minecraft/shaders/core/blur.fsh")));
      }

      boolean var9 = identifier.getPath().equals("shaders/core/rounded_rect.json");
      if (var9) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dO("assets/minecraft/shaders/core/rounded_rect.json")));
      }

      boolean var10 = identifier.getPath().equals("shaders/core/rounded_rect.fsh");
      if (var10) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dP("assets/minecraft/shaders/core/rounded_rect.fsh")));
      }

      boolean var11 = identifier.getPath().equals("shaders/core/rounded_rect_glow.json");
      if (var11) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dQ("assets/minecraft/shaders/core/rounded_rect_glow.json")));
      }

      boolean var12 = identifier.getPath().equals("shaders/core/rounded_rect_glow.fsh");
      if (var12) {
         callbackInfoReturnable.setReturnValue(Optional.of(NativeAccessBridge.dR("assets/minecraft/shaders/core/rounded_rect_glow.fsh")));
      }
   }
}
