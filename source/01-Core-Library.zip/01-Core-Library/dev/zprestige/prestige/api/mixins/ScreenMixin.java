package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.ScreenBackgroundTintEvent;

import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.Identifier;

@CTransformer(Screen.class)
public class ScreenMixin {
   @CInject(method = "renderBackground", target = @CTarget("HEAD"), cancellable = true)
   private void a(DrawContext drawContext, int i, int j, float f, InjectionCallback ci) {
      boolean var7 = Prestige.w;
      if (!var7) {
         ScreenBackgroundTintEvent var6 = NativeAccessBridge.dS();
         boolean var8 = NativeAccessBridge.dT(var6);
         if (var8) {
            ci.cancel();
         }
      }
   }

   @CInject(method = "renderBackgroundTexture", target = @CTarget("HEAD"), cancellable = true)
   private static void b(DrawContext drawContext, Identifier identifier, int i, int j, float f, float g, int k, int l, InjectionCallback ci) {
      boolean var10 = Prestige.w;
      if (!var10) {
         ScreenBackgroundTintEvent var9 = NativeAccessBridge.dU();
         boolean var11 = NativeAccessBridge.dV(var9);
         if (var11) {
            ci.cancel();
         }
      }
   }
}
