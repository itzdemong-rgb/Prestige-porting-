package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.AmbientColorEvent;


import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.SkyRendering;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.world.ClientWorld;

@CTransformer(SkyRendering.class)
public class SkyRenderingMixin {
   @CInject(method = "updateRenderState", target = @CTarget("TAIL"))
   private void a(ClientWorld world, float tickDelta, Camera camera, SkyRenderState state, InjectionCallback ci) {
      boolean var13 = Prestige.w;
      if (!var13) {
         boolean var14 = NativeAccessBridge.dY(Prestige.b, AmbientColorEvent.class);
         if (var14) {
            int var6 = state.skyColor;
            Color var7 = NativeAccessBridge.dZ(var6 >> 16 & 0xFF, var6 >> 8 & 0xFF, var6 & 0xFF);
            int var8 = state.sunriseAndSunsetColor;
            Color var9 = NativeAccessBridge.ea(var8 >> 16 & 0xFF, var8 >> 8 & 0xFF, var8 & 0xFF);
            AmbientColorEvent var10 = NativeAccessBridge.eb(var7, var9);
            boolean var15 = NativeAccessBridge.ec(var10);
            if (var15) {
               Color var16 = NativeAccessBridge.ed(var10);
               if (var16 != null) {
                  Color var11 = NativeAccessBridge.ee(var10);
                  state.skyColor = 0xFF000000 | (var11.getRed() & 0xFF) << 16 | (var11.getGreen() & 0xFF) << 8 | var11.getBlue() & 0xFF;
               }

               Color var17 = NativeAccessBridge.ef(var10);
               if (var17 != null) {
                  Color var18 = NativeAccessBridge.eg(var10);
                  int var12 = var8 >> 24 & 0xFF;
                  state.sunriseAndSunsetColor = var12 << 24 | (var18.getRed() & 0xFF) << 16 | (var18.getGreen() & 0xFF) << 8 | var18.getBlue() & 0xFF;
               }
            }
         }
      }
   }
}
