package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.EntityNameEvent;


import dev.zprestige.prestige.client.Prestige;
import java.util.Iterator;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CModifyArgs;
import net.lenni0451.classtransform.utils.CArgs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.DisplayEntityRenderer.TextDisplayEntityRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

@CTransformer(TextDisplayEntityRenderer.class)
public class TextDisplayEntityRendererMixin {
   @CModifyArgs(
      method = "getLines",
      target = @CTarget(
         value = "INVOKE",
         target = "Lnet/minecraft/client/font/TextRenderer;wrapLines(Lnet/minecraft/text/StringVisitable;I)Ljava/util/List;",
         ordinal = 0
      )
   )
   public void a(CArgs cArgs) {
      boolean var11 = Prestige.w;
      if (!var11) {
         boolean var12 = NativeAccessBridge.eh(Prestige.b, EntityNameEvent.class);
         if (var12) {
            Text var2 = (Text)cArgs.get(0);
            String var3 = var2.getString();
            ClientWorld var4 = MinecraftClient.getInstance().world;
            boolean var13 = var3.isBlank();
            if (!var13) {
               ClientWorld var14 = var4;
               if (var14 != null) {
                  Iterator var5 = var4.getPlayers().iterator();

                  while (true) {
                     boolean var15 = var5.hasNext();
                     if (!var15) {
                        break;
                     }

                     PlayerEntity var6;
                     boolean var10;
                     label52: {
                        var6 = (PlayerEntity)var5.next();
                        int var7 = var3.indexOf(var6.getNameForScoreboard());
                        // int var16 = var7;
                        label34:
                        if (var16 != var17) {
                           int var18 = var7;
                           if (var18 > 0) {
                              boolean var19 = Character.isLetterOrDigit(var3.charAt(var7 - 1));
                              if (var19) {
                                 break label34;
                              }
                           }

                           int var10000 = var7 + var6.getNameForScoreboard().length();
                           int var21 = var3.length();
                           int var20 = var10000;
                           if (var20 < var21) {
                              boolean var22 = Character.isLetterOrDigit(var3.charAt(var7 + var6.getNameForScoreboard().length()));
                              if (var22) {
                                 break label34;
                              }
                           }

                           var10 = false;
                           break label52;
                        }

                        boolean var23 = true;
                        var10 = var23;
                     }

                     boolean var8 = var10;
                     boolean var24 = var8;
                     if (!var24) {
                        EntityNameEvent var9 = NativeAccessBridge.ei(var6, var2);
                        boolean var25 = NativeAccessBridge.ej(var9);
                        if (var25) {
                           cArgs.set(0, NativeAccessBridge.ek(var9));
                        }
                     }
                  }
               }
            }

            return;
         }
      }
   }
}
