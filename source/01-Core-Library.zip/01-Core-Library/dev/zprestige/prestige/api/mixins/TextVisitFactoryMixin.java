package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.PlayerNameEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CModifyArgs;
import net.lenni0451.classtransform.utils.CArgs;
import net.minecraft.text.TextVisitFactory;

@CTransformer(TextVisitFactory.class)
public class TextVisitFactoryMixin {
   @CModifyArgs(
      method = "visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
      target = @CTarget(
         value = "INVOKE",
         target = "Lnet/minecraft/text/TextVisitFactory;visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
         ordinal = 0
      )
   )
   private static void a(CArgs cArgs) {
      String var1 = (String)cArgs.get(0);
      String var3 = var1;
      if (var3 != null) {
         boolean var4 = Prestige.w;
         if (!var4) {
            boolean var5 = NativeAccessBridge.el(Prestige.b, PlayerNameEvent.class);
            if (!var5) {
               return;
            }

            PlayerNameEvent var2 = NativeAccessBridge.em("", var1);
            boolean var6 = NativeAccessBridge.en(var2);
            if (var6) {
               cArgs.set(0, var1.replace(NativeAccessBridge.eo(var2), NativeAccessBridge.ep(var2)));
            }
         } else {
            cArgs.set(0, var1);
         }
      }
   }
}
