package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.BlockStateUpdateEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

@CTransformer(WorldChunk.class)
public class WorldChunkMixin {
   @CShadow("world")
   public World world;

   @CInject(method = "setBlockState", target = @CTarget("TAIL"))
   private void a(BlockPos pos, BlockState state, int flags, InjectionCallback cir) {
      boolean var6 = Prestige.w;
      if (!var6) {
         boolean var7 = NativeAccessBridge.ex(Prestige.b, BlockStateUpdateEvent.class);
         if (var7) {
            boolean var8 = this.world.isClient();
            if (var8) {
               BlockStateUpdateEvent var5 = NativeAccessBridge.ey(pos, state);
               NativeAccessBridge.ez(var5);
            }
         }
      }
   }
}
