package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.WeatherRenderEvent;
import dev.zprestige.prestige.api.events.WorldTimeEvent;


import dev.zprestige.prestige.client.Prestige;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.world.World;

@CTransformer(World.class)
public class WorldMixin {
   @CInject(method = "getRainGradient(F)F", target = @CTarget("RETURN"), cancellable = true)
   private void a(float delta, InjectionCallback cir) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = NativeAccessBridge.eq(Prestige.b, WeatherRenderEvent.class);
         if (var4) {
            boolean var5 = NativeAccessBridge.es(NativeAccessBridge.er());
            if (var5) {
               cir.setReturnValue(0.0F);
            }

            return;
         }
      }
   }

   @CInject(method = "getTimeOfDay", target = @CTarget("RETURN"), cancellable = true)
   private void b(InjectionCallback cir) {
      boolean var3 = Prestige.w;
      if (!var3) {
         boolean var4 = NativeAccessBridge.et(Prestige.b, WorldTimeEvent.class);
         if (var4) {
            WorldTimeEvent var2 = NativeAccessBridge.eu((Long)cir.getReturnValue());
            boolean var5 = NativeAccessBridge.ev(var2);
            if (var5) {
               cir.setReturnValue(NativeAccessBridge.ew(var2));
            }

            return;
         }
      }
   }
}
