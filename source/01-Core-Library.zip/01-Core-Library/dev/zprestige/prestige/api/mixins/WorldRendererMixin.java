package dev.zprestige.prestige.api.mixins;
import dev.zprestige.prestige.api.accessor.NativeAccessBridge;
import dev.zprestige.prestige.api.events.FrustumEvent;
import dev.zprestige.prestige.api.events.NativeRenderPhaseEvent;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.GlStateSnapshot;
import dev.zprestige.prestige.renderlib.RenderContext;


import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.client.Prestige;
import java.util.List;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CShadow;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Vector4f;

@CTransformer(WorldRenderer.class)
public class WorldRendererMixin {
   @CShadow("capturedFrustum")
   private Frustum frustum;

   
   
   @CInject(
      method = "render",
      target = @CTarget(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/FrameGraphBuilder;run(Lnet/minecraft/client/util/ObjectAllocator;Lnet/minecraft/client/render/FrameGraphBuilder$Profiler;)V",
         shift = CTarget.Shift.AFTER
      )
   )
   public void a(
      ObjectAllocator allocator,
      RenderTickCounter tickCounter,
      boolean renderBlockOutline,
      Camera camera,
      Matrix4f theCameraRotation,
      Matrix4f actualRealProjMatrix,
      Matrix4f projectionMatrix,
      GpuBufferSlice fogBuffer,
      Vector4f fogColor,
      boolean renderSky
   ) {
      if (!Prestige.w && Prestige.b != null) {
         List<Runnable> delayedActions = NativeAccessBridge.eA();
         boolean renderWork = NativeAccessBridge.eB();
         boolean hudWork = NativeAccessBridge.eC();
         if (hudWork) {
            GameRenderUtil.d.set(actualRealProjMatrix);
            if (!renderWork) {
               NativeAccessBridge.eD();
            }
         }

         if (renderWork || !delayedActions.isEmpty()) {
            GlStateSnapshot cap = NativeAccessBridge.eE();
            boolean var19 = false ;

            label55: {
               try {
                  var19 = true;
                  NativeAccessBridge.eF(delayedActions);
                  if (!renderWork) {
                     var19 = false;
                     break label55;
                  }

                  Matrix4fStack actualRealModView = RenderSystem.getModelViewStack();
                  RenderContext context = NativeAccessBridge.eI(actualRealProjMatrix, NativeAccessBridge.eH(actualRealModView), camera);
                  NativeAccessBridge.eJ(context);
                  var19 = false;
               } finally {
                  if (var19) {
                     NativeAccessBridge.eL(cap);
                  }
               }

               NativeAccessBridge.eK(cap);
               return;
            }

            NativeAccessBridge.eG(cap);
         }
      }
   }

   @CInject(method = "setupFrustum", target = @CTarget("RETURN"))
   private void b(Matrix4f matrix4f, Matrix4f matrix4f2, Vec3d vec3d, InjectionCallback ci) {
      boolean var6 = Prestige.w;
      if (!var6) {
         EventBus var7 = Prestige.b;
         if (var7 != null) {
            boolean var8 = NativeAccessBridge.eM(Prestige.b, FrustumEvent.class);
            if (var8) {
               FrustumEvent var5 = NativeAccessBridge.eN((Frustum)ci.getReturnValue());
               NativeAccessBridge.eO(var5);
               return;
            }
         }
      }
   }

   @CInject(method = "reload", target = @CTarget("HEAD"))
   private void c(InjectionCallback ci) {
      boolean var2 = Prestige.w;
      if (!var2) {
         EventBus var3 = Prestige.b;
         if (var3 != null) {
            boolean var4 = NativeAccessBridge.eP(Prestige.b, NativeRenderPhaseEvent.class);
            if (var4) {
               NativeAccessBridge.eR(NativeAccessBridge.eQ());
               return;
            }
         }
      }
   }
}
