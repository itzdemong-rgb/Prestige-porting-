package dev.zprestige.prestige.api.module;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.annotation.NativeMarker;
import dev.zprestige.prestige.api.annotation.NativeIdentifier;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.api.setting.SettingDefinition;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.SettingContainer;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

public class Module extends SettingContainer implements MinecraftAccess {
   private final List c = new ArrayList();
   private final BooleanSetting d = new BooleanSetting("Enabled", false);
   private String e;
   private final BindSetting f;
   private Category g;
   private String h;
   private boolean i;
   private volatile List j;
   private static final long cb = 112173374300133L;
   private static final String[] eb;
   private static final String[] fb;
   private static final Map gb = new HashMap(13);
   private static final Object[] ub = new Object[97];
   private static final String[] vb = new String[97];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;

   public Module() {
      BindSetting var10001 = new BindSetting("Bind", -1);
      String var4 = "Keybind for " + this.e;
      BindSetting var3 = var10001;
      this.f = var3.setDescriptionReturningBindSetting(var4);
      BooleanSetting var6 = this.d;
      List var5 = this.c;
      var5.add(var6);
      BindSetting var8 = this.f;
      List var7 = this.c;
      var7.add(var8);
   }

   public Module(String var1, String var2, int var3) {
      this();
      this.e = var1;
      int var10000 = Event.bReturningInt();
      this.h = var2;
      int var6 = var10000;
      Category[] var7 = Category.values();
      int var8 = var7.length;
      int var18;
      do {
         int var13 = var8;
         int var12 = var9;
         if (var12 >= var13) {
            break;
         }

         Category var10 = var7[var9];
         int var14 = var6;
         if (var14 == 0) {
            Category var11 = var10;
            var10000 = var11.ordinal();
            int var16 = var3;
            int var15 = var10000;
            if (var15 == var16) {
               this.g = var10;
               int var17 = var6;
               if (var17 == 0) {
                  break;
               }
            }

            var9++;
         }

         var18 = var6;
      } while (var18 == 0);
   }

   @NativeIdentifier
   public void a(Object var1, String var2, String var3, int var4) {
      int var7 = Event.cReturningInt();
      int var19 = var7;
      if (var19 != 0) {
         Object var20 = var1;
         if (var20 != null) {
            SettingDefinition var10 = (SettingDefinition)var1;
            ArrayList var9 = this.a;
            var9.add(var10);
            this.j = null;
            int var21 = var7;
            if (var21 != 0) {
               return;
            }
         }

         this.e = var2;
         this.h = var3;
      }

      Category[] var13 = Category.values();
      Stream var10001 = Arrays.stream(var13);
      Predicate var15 = invokeBinding1(var4);
      Stream var14 = var10001;
      Stream var16 = var14.filter(var15);
      Optional var22 = var16.findFirst();
      Category var18 = this.g;
      Optional var17 = var22;
      this.g = ((dev.zprestige.prestige.api.module.Category)(Object)(var17.orElse(var18)));
   }

   @NativeMarker
   public boolean aReturningBoolean() {
      BooleanSetting var3 = this.d;
      Boolean var4 = (Boolean)var3.aReturningObject();
      return var4;
   }

   public int bReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 112173374300133L ^ var2;
      BindSetting var4 = this.f;
      Integer var5 = (Integer)var4.aReturningObject();
      return var5;
   }

   public BindSetting bReturningBindSetting(Object[] var1) {
      return this.f;
   }

   public void aReturningVoid(Object[] var1) {
      long var4;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      int var18;
      BooleanSetting var63;
      byte var64;
      label59: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 23276974332793L;
         var6 = var2 ^ 16872047181045L;
         var8 = var2 ^ 97434553232679L;
         var10 = var2 ^ 116087004029242L;
         var12 = var2 ^ 75595538011097L;
         var14 = var2 ^ 33056819824678L;
         var16 = var2 ^ 56651557002554L;
         var18 = Event.cReturningInt();
         BooleanSetting var10000 = this.d;
         Module var19 = this;
         byte var10001 = ((byte)((var19.aReturningBoolean()) ? 1 : 0));
         int var69 = var18;
         byte var68 = var10001;
         BooleanSetting var67 = var10000;
         BooleanSetting var60 = var67;
         byte var61 = var68;
         BooleanSetting var56 = var67;
         byte var57 = var68;
         if (var69 != 0) {
            byte var71 = var57;
            BooleanSetting var70 = var56;
            BooleanSetting var62 = var70;
            BooleanSetting var58 = var70;
            if (var71 != 0) {
               var64 = 0;
               var63 = var62;
               break label59;
            }

            BooleanSetting var72 = var58;
            BooleanSetting var59 = var72;
            var61 = 1;
            var60 = var59;
         }

         byte var74 = var61;
         BooleanSetting var73 = var60;
         var63 = var73;
         var64 = var74;
      }

      label62: {
         byte var21 = var64;
         Boolean var23 = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var21));
         BooleanSetting var22 = var63;
         var22.aReturningVoid(var23);
         Module var24 = this;
         Object[] var26 = new Object[]{var24.aReturningBoolean()};
         Module var25 = this;
         var25.iReturningVoid(var26);
         int var75 = var18;
         if (var75 != 0) {
            Module var27 = this;
            boolean var76 = var27.aReturningBoolean();
            if (var76) {
               EventBus var88 = Prestige.b;
               Object[] var30 = new Object[]{this, var6};
               EventBus var29 = var88;
               var29.aReturningVoid(var30);
               int var77 = var18;
               if (var77 != 0) {
                  MinecraftClient var32 = b;
                  ClientWorld var78 = var32.world;
                  if (var78 != null) {
                     MinecraftClient var34 = b;
                     ClientPlayerEntity var79 = var34.player;
                     if (var79 != null) {
                        Object[] var37 = new Object[]{var8};
                        Module var36 = this;
                        var36.dReturningVoid(var37);
                        int var80 = var18;
                        if (var80 != 0) {
                           break label62;
                        }
                     }
                  }

                  ModuleManager var89 = Prestige.d;
                  Object[] var40 = new Object[]{this, var14};
                  ModuleManager var39 = var89;
                  var39.aReturningVoid(var40);
               }

               int var81 = var18;
               if (var81 != 0) {
                  break label62;
               }
            }

            EventBus var90 = Prestige.b;
            Object[] var43 = new Object[]{this, var16};
            EventBus var42 = var90;
            var42.bReturningVoid(var43);
         }

         label40: {
            int var83 = var18;
            MinecraftClient var82 = b;
            MinecraftClient var66 = var82;
            MinecraftClient var65 = var82;
            if (var83 != 0) {
               MinecraftClient var45 = var65;
               ClientWorld var84 = var45.world;
               if (var84 == null) {
                  break label40;
               }

               MinecraftClient var85 = b;
               var66 = var85;
            }

            MinecraftClient var48 = var66;
            ClientPlayerEntity var86 = var48.player;
            if (var86 != null) {
               Object[] var50 = new Object[]{var10};
               Module var49 = this;
               var49.eReturningVoid(var50);
               int var87 = var18;
               if (var87 != 0) {
                  break label62;
               }
            }
         }

         ModuleManager var91 = Prestige.d;
         Object[] var53 = new Object[]{this, var12};
         ModuleManager var52 = var91;
         var52.bReturningVoid(var53);
      }

      Object[] var55 = new Object[]{this, var4};
      ModuleNotificationsWidget.r(var55);
   }

   public void bReturningVoid(Object[] var1) {
      long var4;
      label49: {
         long var2 = (Long)var1[0];
         var2 = 112173374300133L ^ var2;
         var4 = var2 ^ 119691242571087L;
         long var6 = var2 ^ 130464100033219L;
         long var8 = var2 ^ 36755824276241L;
         long var10 = var2 ^ 18024947334924L;
         long var12 = var2 ^ 67279237074415L;
         long var14 = var2 ^ 114215968216592L;
         long var16 = var2 ^ 81872442360588L;
         int var18 = Event.bReturningInt();
         int var50 = var18;
         if (var50 == 0) {
            Module var19 = this;
            boolean var51 = var19.aReturningBoolean();
            if (var51) {
               EventBus var10000 = Prestige.b;
               Object[] var22 = new Object[]{this, var6};
               EventBus var21 = var10000;
               var21.aReturningVoid(var22);
               int var52 = var18;
               if (var52 == 0) {
                  MinecraftClient var24 = b;
                  ClientWorld var53 = var24.world;
                  if (var53 != null) {
                     MinecraftClient var26 = b;
                     ClientPlayerEntity var54 = var26.player;
                     if (var54 != null) {
                        Object[] var29 = new Object[]{var8};
                        Module var28 = this;
                        var28.dReturningVoid(var29);
                        int var55 = var18;
                        if (var55 == 0) {
                           break label49;
                        }
                     }
                  }

                  ModuleManager var64 = Prestige.d;
                  Object[] var32 = new Object[]{this, var14};
                  ModuleManager var31 = var64;
                  var31.aReturningVoid(var32);
               }

               int var56 = var18;
               if (var56 == 0) {
                  break label49;
               }
            }

            EventBus var65 = Prestige.b;
            Object[] var35 = new Object[]{this, var16};
            EventBus var34 = var65;
            var34.bReturningVoid(var35);
         }

         label34: {
            int var58 = var18;
            MinecraftClient var57 = b;
            MinecraftClient var49 = var57;
            MinecraftClient var48 = var57;
            if (var58 == 0) {
               MinecraftClient var37 = var48;
               ClientWorld var59 = var37.world;
               if (var59 == null) {
                  break label34;
               }

               MinecraftClient var60 = b;
               var49 = var60;
            }

            MinecraftClient var40 = var49;
            ClientPlayerEntity var61 = var40.player;
            if (var61 != null) {
               Object[] var42 = new Object[]{var10};
               Module var41 = this;
               var41.eReturningVoid(var42);
               int var62 = var18;
               if (var62 == 0) {
                  break label49;
               }
            }
         }

         ModuleManager var66 = Prestige.d;
         Object[] var45 = new Object[]{this, var12};
         ModuleManager var44 = var66;
         var44.bReturningVoid(var45);
      }

      Object[] var47 = new Object[]{this, var4};
      ModuleNotificationsWidget.r(var47);
   }

   public void cReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 112173374300133L ^ var2;
      this.e = null;
      this.h = null;
      int var23 = Event.cReturningInt();
      ArrayList var5 = new ArrayList();
      int var4 = var23;
      ArrayList var9 = this.a;
      ArrayList var8 = var5;
      var8.addAll(var9);
      List var11 = this.c;
      ArrayList var10 = var5;
      var10.addAll(var11);
      ArrayList var12 = var5;
      Iterator var6 = var12.iterator();

      int var22;
      do {
         Iterator var13 = var6;
         boolean var21 = var13.hasNext();
         if (!var21) {
            break;
         }

         Iterator var14 = var6;
         SettingDefinition var7 = (SettingDefinition)var14.next();
         Object[] var16 = new Object[]{null};
         SettingDefinition var15 = var7;
         var15.aReturningVoid(var16);
         Object var18 = null;
         SettingDefinition var17 = var7;
         var17.setDescriptionReturningdF_C0175((String)var18);
         Object var20 = null;
         SettingDefinition var19 = var7;
         var19.aReturningVoid(var20);
         var22 = var4;
      } while (var22 != 0);
   }

   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
   }

   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
   }

   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return true;
   }

   public String aReturningString(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return "";
   }

   public List aReturningList(Object[] var1) {
      return this.c;
   }

   @NativeMarker
   public String bReturningString() {
      return this.e;
   }

   public void fReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      this.e = var2;
   }

   @NativeMarker
   public String cReturningString() {
      return this.h;
   }

   public void gReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      this.h = var2;
   }

   @NativeMarker
   public Category aReturningCategory() {
      return this.g;
   }

   public void hReturningVoid(Object[] var1) {
      Category var2 = (Category)var1[0];
      this.g = var2;
   }

   public boolean cReturningBoolean(Object[] var1) {
      return this.i;
   }

   public void iReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      this.i = var2;
   }

   public float aReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 112173374300133L ^ var2;
      long var4 = var2 ^ 69462817631540L;
      long var6 = var2 ^ 135216943007350L;
      long var8 = var2 ^ 43550570619943L;
      String var10 = this.e + " " + invokeBinding2(this, new Object[]{var8}, 2235250632598102549L, var2);

      float var13;
      try {
         float var10000 = invokeBinding5(
            invokeBinding4(invokeBinding3(2235350576696611426L, var2), new Object[]{var6}, 2242190508130924728L, var2),
            new Object[]{var10, var4},
            2235757315061019482L,
            var2
         );
         boolean var17 = invokeBinding7(invokeBinding6(this, new Object[]{var8}, 2235250632598102549L, var2), 2235571736956306508L, var2);
         float var16 = var10000;
         var13 = var16;
         float var11 = var16;
         if (!var17) {
            float var19 = invokeBinding10(
               invokeBinding9(invokeBinding8(2235350576696611426L, var2), new Object[]{var6}, 2242190508130924728L, var2),
               new Object[]{" ", var4},
               2235757315061019482L,
               var2
            );
            float var18 = var11;
            float var22 = var18;
            float var23 = var19;
            return var22 + var23;
         }
      } catch (MatchException var20) {
         throw invokeBinding11(var20, 2241473988677524355L, var2);
      }

      float var15 = 0.0F;
      float var14 = var13;
      return var14 + var15;
   }

   @NativeMarker
   public List bReturningList() {
      int var10000 = Event.cReturningInt();
      List var4 = this.j;
      int var3 = var10000;
      int var17 = var3;
      List var16 = var4;
      List var15 = var16;
      List var14 = var16;
      if (var17 != 0) {
         List var18 = var14;
         if (var18 == null) {
            List var7 = this.c;
            int var10002 = var7.size();
            ArrayList var8 = this.a;
            ArrayList var5 = new ArrayList(var10002 + var8.size());
            List var10 = this.c;
            ArrayList var9 = var5;
            var9.addAll(var10);
            ArrayList var12 = this.a;
            ArrayList var11 = var5;
            var11.addAll(var12);
            ArrayList var13 = var5;
            var4 = List.copyOf(var13);
            this.j = var4;
         }

         var15 = var4;
      }

      return var15;
   }

   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Any;
      return Set.of(var4);
   }

   @NativeMarker
   public int cReturningInt() {
      long var10001 = 132563418104445L ^ 85654782420922L;
      Object[] var11 = new Object[]{58788934804935L};
      Module var10 = this;
      Set var6 = var10.aReturningSet(var11);
      int var10000 = Event.bReturningInt();
      Set var12 = var6;
      Iterator var8 = var12.iterator();
      int var5 = var10000;

      while (true) {
         Iterator var13 = var8;
         boolean var18 = var13.hasNext();
         if (!var18) {
            break;
         }

         Iterator var14 = var8;
         CombatProfile var9 = (CombatProfile)var14.next();
         int var19 = var5;
         if (var19 == 0) {
            CombatProfile var21 = CombatProfile.Any;
            CombatProfile var20 = var9;
            if (var20 == var21) {
               continue;
            }

            CombatProfile var17 = var9;
            var7 |= 1 << var17.ordinal();
         }

         int var22 = var5;
         if (var22 != 0) {
            break;
         }
      }

      return var7;
   }

   private static boolean lambda$set$0(int var0, Category var1) {
      int var4 = Event.bReturningInt();
      Category var5 = var1;
      int var10000 = var5.ordinal();
      int var10 = var4;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      int var8;
      if (var10 == 0) {
         int var12 = var0;
         int var11 = var6;
         if (var11 == var12) {
            byte var13 = 1;
            var8 = var13;
         } else {
            var8 = 0;
         }
      } else {
         int var14 = var7;
         var8 = var14;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {

      {

      g();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(75142679879188L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      String var6 = "²\u00adøqÌq¿\u0002T8J[\u009c}\u00adO\u0018vf&¯{\u0001\u0086\u0003oÃ*&.\u009dj\u0010\u001d±\u0097oÉ\u001de\u00853=\tì\u0099\u0087\\â\u0010ã6±µÞõrØO\u0098LJ\r\u001bô7";
      int var8 = "²\u00adøqÌq¿\u0002T8J[\u009c}\u00adO\u0018vf&¯{\u0001\u0086\u0003oÃ*&.\u009dj\u0010\u001d±\u0097oÉ\u001de\u00853=\tì\u0099\u0087\\â\u0010ã6±µÞõrØO\u0098LJ\r\u001bô7"
         .length();
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = a(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            eb = var9;
            fb = new String[3];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException b(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1568;
      if (fb[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])gb.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               gb.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dQ", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = eb[var5].getBytes("ISO-8859-1");
         fb[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return fb[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dQ_C0195",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = vb[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = ub[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 41;
            yield var15;
         }
         case 1 -> {
            byte var16 = 8;
            yield var16;
         }
         case 2 -> {
            byte var17 = 54;
            yield var17;
         }
         case 3 -> {
            byte var18 = 15;
            yield var18;
         }
         case 4 -> {
            byte var19 = 9;
            yield var19;
         }
         case 5 -> {
            byte var20 = 38;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 51;
            yield var22;
         }
         case 8 -> {
            byte var23 = 59;
            yield var23;
         }
         case 9 -> {
            byte var24 = 30;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 6;
            yield var26;
         }
         case 12 -> {
            byte var27 = 13;
            yield var27;
         }
         case 13 -> {
            byte var28 = 58;
            yield var28;
         }
         case 14 -> {
            byte var29 = 39;
            yield var29;
         }
         case 15 -> {
            byte var30 = 36;
            yield var30;
         }
         case 16 -> {
            byte var31 = 53;
            yield var31;
         }
         case 17 -> {
            byte var32 = 56;
            yield var32;
         }
         case 18 -> {
            byte var33 = 31;
            yield var33;
         }
         case 19 -> {
            byte var34 = 52;
            yield var34;
         }
         case 20 -> {
            byte var35 = 48;
            yield var35;
         }
         case 21 -> {
            byte var36 = 62;
            yield var36;
         }
         case 22 -> {
            byte var37 = 4;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 2;
            yield var39;
         }
         case 25 -> {
            byte var40 = 23;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 17;
            yield var42;
         }
         case 28 -> {
            byte var43 = 32;
            yield var43;
         }
         case 29 -> {
            byte var44 = 25;
            yield var44;
         }
         case 30 -> {
            byte var45 = 55;
            yield var45;
         }
         case 31 -> {
            byte var46 = 28;
            yield var46;
         }
         case 32 -> {
            byte var47 = 44;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 1;
            yield var49;
         }
         case 35 -> {
            byte var50 = 16;
            yield var50;
         }
         case 36 -> {
            byte var51 = 35;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 12;
            yield var53;
         }
         case 39 -> {
            byte var54 = 26;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 22;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 3;
            yield var58;
         }
         case 44 -> {
            byte var59 = 50;
            yield var59;
         }
         case 45 -> {
            byte var60 = 40;
            yield var60;
         }
         case 46 -> {
            byte var61 = 46;
            yield var61;
         }
         case 47 -> {
            byte var62 = 34;
            yield var62;
         }
         case 48 -> {
            byte var63 = 60;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 24;
            yield var65;
         }
         case 51 -> {
            byte var66 = 7;
            yield var66;
         }
         case 52 -> {
            byte var67 = 61;
            yield var67;
         }
         case 53 -> {
            byte var68 = 43;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 11;
            yield var70;
         }
         case 56 -> {
            byte var71 = 29;
            yield var71;
         }
         case 57 -> {
            byte var72 = 27;
            yield var72;
         }
         case 58 -> {
            byte var73 = 20;
            yield var73;
         }
         case 59 -> {
            byte var74 = 57;
            yield var74;
         }
         case 60 -> {
            byte var75 = 19;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 42;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            vb[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void g() {
      ub[0] = " \r?k#\u00036\r:10\u0014!F97<\u00000\u0001. w\u0012\u0001";
      ub[1] = int.class;
      vb[1] = "java/lang/Integer";
      ub[2] = "^57\u001b%NH52A6Y_~1G:MN9&PqZk";
      ub[3] = "]\u001dwQw&(=|^fiI3wUb3=";
      ub[4] = void.class;
      vb[4] = "java/lang/Void";
      ub[5] = "\u0005'f51P\u0013'co\"G\u0004l`i.S\u0015+w~eC&";
      ub[6] = "eSZn0|\u0010sQa!3q}Zj%i\u0005";
      ub[7] = "Kj|~ ]@em1CPUhbZvRD{~va_";
      ub[8] = boolean.class;
      vb[8] = "java/lang/Boolean";
      ub[9] = "g\u0012.\u0017&Mg\u00129K*B}Y9U*Wz(i\b{";
      ub[10] = "NcKx*ENc\\$&JT(\\:&_SY\te\u007f";
      ub[11] = "D[\u0004uEVD[\u0013)IY^\u0010\u00137ILYaGo\u001e";
      ub[12] = "2|\u001cZ&TG\\\u0017U7\u001b&R\u001c^3AR";
      ub[13] = ":zZpK~OZQ\u007fZ1.TZt^kZ";
      ub[14] = "?]\f~BJ)]\t$Q]>\u0016\n\"]I/Q\u001d5\u0016Y7Q\u001f>L\u0014\u000bJ\u001f#LS<]";
      ub[15] = "\u000fh\u0012EIm\u0019h\u0017\u001fZz\u000e#\u0014\u0019Vn\u001fd\u0003\u000e\u001d\u007f'";
      ub[16] = "B\u0002h0147\"c? {V,h4$!\"";
      ub[17] = "\u0013D\u0018/\u000eg\u0005D\u001du\u001dp\u0012\u000f\u001es\u0011d\u0003H\tdZuN";
      ub[18] = "Y{w`Y&,[|oHiMUwdL39";
      ub[19] = "\u000eq\u0019N^\u001e{Q\u0012AOQ\u001a_\u0019JK\u000bn";
      ub[20] = "\u0004[7b\fj\u001aS--mo\u001aS.mCs";
      ub[21] = "SV\u0002sMGXY\u0013<,ISR\u0017f";
      ub[22] = "\u0012'!XCC\f/;\u0017\u001eB\n#6TCe\f42X\u0000";
      ub[23] = "Lr:\u0016l\tRz Y\u0003\u000eTr5;+\u000fR";
      ub[24] = "t\u001bn-]Ij\u0013tb\u0015Ip\u0019l%\u001cR0*j)\u0017U}\u001bl)";
      ub[25] = "\u0007\u0017]\u001a\u0003\u000e\u0019\u001fGUl\t\u001f\u0017R\b";
      ub[26] = "Dh[*\u000fg1HP%\u001e(PF[.\u001ar$";
      ub[27] = "m5\run\u0002{5\b/}\u0015l~\u000b)q\u0001}9\u001c>:\u0015";
      ub[28] = "2l]\rK\u001a\u0013PK\rN@\u0000G\\FMF\fSM\u0001ZQGG\u0002";
      ub[29] = "[z\u0018XPwPu\t\u0017<t^w\u000bX\u0010";
      ub[30] = "\"}\u000e|.$W]\u0005s?k6S\u000ex;1B";
      ub[31] = "\bad\u0003!Z\u001eaaY2M\t*b_>Y\u0018muHuN*";
      ub[32] = "\u000bK\nF\u0004{~k\u0001I\u00154\u001fe\nB\u0011nk";
      ub[33] = "O`\u001fk)\u0001Qh\u0005$T\u0011Q";
      ub[34] = "2\u0010H\u0003T/,\u0018RL3.=\u0003_\u0016\u0015(";
      ub[35] = "%.D_\u0007\u00113.A\u0005\u0014\u0006$eB\u0003\u0018\u00125\"U\u0014S\u000e";
      ub[36] = "3v\u007fN!A-~e\u0001C]*c";
      ub[37] = "@Dj@S\u0003^Lp\u000f>\u0019FIyB\t\u001fEK";
      ub[38] = "`\u0014g\u0001\u0017\u0017k\u001bvNj\u000fx\u001c\u007f\u0007";
      ub[39] = "l\u001e\u001d\u0003`7\u0019>\u0016\fqxx0\u001d\u0007u\"\f";
      ub[40] = "O.I'\\*Y.L}O=NeO{C)_\"Xl\b>l";
      ub[41] = "\u0018a%{F\u0018mA.tWW\fO%\u007fS\rx";
      ub[42] = "?W\u0002LG\u000e)W\u0007\u0016T\u0019>\u001c\u0004\u0010X\r/[\u0013\u0007\u0013\u001d!";
      ub[43] = "g\u0019g\u0007\t\u0011\u00129l\b\u0018^s7g\u0003\u001c\u0004\u0007";
      ub[44] = "kq$\u0007\u001b{}q!]\blj:\"[\u0004x{}5LOhw";
      ub[45] = "\u000e?xO\u001eC{\u001fs@\u000f\f\u001a\u0011xK\u000bVn";
      ub[46] = float.class;
      vb[46] = "java/lang/Float";
      ub[47] = "\u00112$fRM\u001a=5)5O\u000f65b\u000e";
      ub[48] = "\u000b\u0007\\g/ \u001cQ\u0013}W6\u001c%I{:Q\bU\u0016?'lWUTkW?[S\u0012pj`[\u0011F\u0000";
      ub[49] = "\u001637\u0019\u000e(\u0013?a\u001fp{/*g\u0004\u0011*F0h\u000e\r\u0012V*e\u0002\u001f\"V)j\u001ep";
      ub[50] = "0tLa\u0016q5x\u001agh&\tm\u001c|\ts`w\u0013v\u0015K3n\u0019x\u00197`jO?h";
      ub[51] = " 8^(\u0000Wv7\u001dqaY\u0011:\u000ff^Y(w\r/\u001a";
      ub[52] = "\u0003\u00152\bh~\u000bJbT\u000bp\u0007A!Xwv\u0001,<\u0001z\u007fF\u001c=\ti~{";
      ub[53] = ",+\u001a*0or*\u00049S7H,\u0000)2f!6\u000f#.^r/\u0005-\"\"!+SjS";
      ub[54] = "Ef\u000e\u0013dLDm\u0000P\u0006L\\`a\u0003bPW\u001cC\u0013oLP!\u0006S{-";
      ub[55] = "\u007f.#1Y[~&00d\run._\nV#!\"bUVauR";
      ub[56] = "Z\u0001|mq\u0010_\r*k\u000fFc\u0018,pn\u0012\n\u0002#zr*Y\u001b)t~V\n\u001f\u007f3\u000f";
      ub[57] = ",;\"ev{1(ir\u0012tQ9yes%8#voo\u001d.{*o{z?v/{\u0012";
      ub[58] = "OG\u0000];\u0005\u0019HC\u0004Z\n~P\\^(\u0006O\u0002\u0000\r%";
      ub[59] = "\f61(T\u0001W4y,e\u0010gskn\u0004R\u000eidd\u0018j]pnj\u0014\u0016\u000et8-e";
      ub[60] = "n\u0004\u0010i@\u000en\u0007\u001fu/_l7\u001cmSO\u0017DAtPRe\u001aCd\u001e>";
      ub[61] = "+*\u0014dTap$Cdlc1(S}\u0010e7EN$\u001dlpuO,\u000emM";
      ub[62] = "\u00138:?\u007fR\u001c938\u0019GL4f7N\u0010\u0013i=[&EO4}e}GUc";
      ub[63] = "NfM_w\u0001\u001c:\u001eR\u0011Y'{\u0019Wp\bNa\u0016]l0\u001dx\u001cS`LN|J\u0014\u0011";
      ub[64] = "yK\u000f\r}\u0007q\u0014_Q\u001e\u0003f\n\u0017sphy\n\u0001_!\b9\u0016\u0000E\u001e\u00108\u001b_Wq\u0018gK\u00034";
      ub[65] = "%\u0005Ha+1\u007f\u0015\r~\u0017;9\u001e\u001bmr@;\u000f\fe/)!\u0000\u0006y\u0017.\"\b\u000fzo' U\r\u0004";
      ub[66] = "G-Y!\bu@*R/uwO3]&\u000e\tD*A\"\u001cp\u001b-_pu";
      ub[67] = "\u0011Al\u0018qSC\u001d?\u0015\u0017\bx\\8\u0010vZ\u0011F7\u001ajbB_=\u0014f\u001e\u0011[kS\u0017";
      ub[68] = "Q\u000fy\u0000\u00077\b\u0000wx\fMJ\u0010p\u0019\fp\u000fPdx";
      ub[69] = "\u0010\u001bJ\u0000\f\u0010\u0003N\\\u0000r^\u001a\u0010X\t5NsJ\u001d\u0005\rL\u0001\u0014\u001f\u0015C \u0010\u001bJ\u0000\f\u0010\u0003N\\\u0000r";
      ub[70] = "9$:TJV1{j\b)P-q\u001a\tM99e4\u0006\u0016Yyy5\u001c)\u0007y|,\u0001[Y{lbm";
      ub[71] = "+cxh8v{l#{S (?\rc7I<+#ll)|7\"vSw|2;k!)~\"u\u0007";
      ub[72] = "\u0015y\u0001lw0\u0010uWj\t`,#\u0005v2q\u0016|K5l\n\u0011!G0r0No\u0004n\t";
      ub[73] = "+1L\u001810p?\u001b\u0018\t4#^\u001fU2l=c@Up8M8\u001eUyk.c\u0010\u0002yS";
      ub[74] = "m#`)0\u001b=,;:[_ca1F']kr6{b\u001d\u007f\u0013";
      ub[75] = "!`\u0006[bMxo\b#h7:\u007f\u000fBi\n\u007f?\u001b#";
      ub[76] = ".tAR{\u0003=!WR\u0005Y*|J[lU\u0013rJKh3s#OIiA-!_\u0007\u0005";
      ub[77] = "f\u0003Mc\u0000k8\u0002Spc3\u0002\u0014\u0001!\\*?K\u0001c\bZ";
      ub[78] = "<\u0018r-\u0006t3\u0019{*`ac\u0014.%76=CvI_vhD05\njg\u0007";
      ub[79] = ">O\f22/h@OkS&\u000f\nTqi!o@Hd2";
      ub[80] = "\u007fwO00\u0003~\u007f\\1\rSq<x3}O\u0018y\u0006?r_j'\u0004/<3";
      ub[81] = "\u0001{\u000fdk>\u0006|\u0004j\u0016%\u001am\u0017h\u007f&`}\u000fgw(]8Os\u0016";
      ub[82] = "A2\u007f3-\u0001\f06wFQ=\"fv'\u0000T8i|;8@ =v\"^]3vaF";
      ub[83] = "H\u001fL\u0014/K\u0002\u0003YODAs\u0006XT%\u0013\u001a\u001cW^9+I\u0005]P5W\u001a\u0001\u000b\u0017D";
      ub[84] = "R( 7UxW$v1++k1p*Jz\u0002+\u007f VB\r & \u0013!V.q +";
      ub[85] = "\u001a7\u000f;35D6\u0011(P\u007f\u001322/+o\u0004/\u0006>1c\u0018N\u0007<9x\u0011~\u0007?6d~*\u00073)gOt\u0006-:\u0004";
      ub[86] = "p\u0016bG\u0018ay\u0014?Efw\u007f\u0017bp\u0007ce\r\u000eS\thy\t\u007fD_'cq";
      ub[87] = "\u0004Y$\nX\u001c\u0001Ur\f&O=\u0000'\fYJO^%\u001c\u0017&";
      ub[88] = "i\t\u0016=gp9\u0006M.\f&jU*<1t9I\u0017c16m9\u0014jm0jKJh}~\u0006";
      ub[89] = "Y%+9s&Qz{e\u0010 MpBn-r\u001el\u007f1-0J\u001c|8q6Mn\":ax!";
      ub[90] = "0NMU458\u0011\u001d\tW!)\u0005Il+#!\u0016NQnc5w";
      ub[91] = "\u0002^q}sJ\u0007R'{\r\u0011;G!`lHR].jpp\u0001D$d|\fR@r#\r";
      ub[92] = "\f$'OaQF82\u0014\nX7=3\u000fk\t^'<\u0005w1\r>6\u000b{M^:`L\n";
      ub[93] = ":E\u001d\nH dD\u0003\u0019+x^RQH\u0014ac\rQ\n@\u0011dA\u0002\rZm7ETJ+";
      ub[94] = "\u0016#T~k#\u001f!\t|\u00155\u0019 Djo[\u0018}U|eaHu^j\u00155\u001f(Aym<\u001duC\u0007";
      ub[95] = "/d\u0003#2E..\u0002>C\u00058b?*8\u0015/\u007f\u000b;\"\u00193\u001e\n9*\u0002:.\n:%\u001eUd\t7'\u000fneC6:~";
      ub[96] = "\u0014Pg_\u0001~C]|\u0006\u007fu\tVw\\\u0016vsFoS\u001exN\u0003/G\u007f";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = ub[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(vb[var4]);
            ub[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = ub[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = vb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            ub[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  ub[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(1537757233741380L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = ub[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = vb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  ub[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(1537757233741380L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        ub[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(1537757233741380L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 211;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 207;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 90;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 236;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 118;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 242;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 211;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 207;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 90;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dQ_C0195",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(I)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dQ_C0195", "lambda$set$0", "(ILdev/zprestige/prestige/g_C0324;)Z"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/g_C0324;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static String invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = g(
                  MethodHandles.lookup(), "v", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MsdfFontManager invokeBinding3(long var0, long var2) {
         MethodHandle var8 = bindingCache3;
         MethodHandle var7 = bindingCache3;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache3 = g(MethodHandles.lookup(), "Z", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = g(
                  MethodHandles.lookup(),
                  "v",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding5(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = g(MethodHandles.lookup(), "v", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = g(
                  MethodHandles.lookup(), "v", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = g(MethodHandles.lookup(), "v", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MsdfFontManager invokeBinding8(long var0, long var2) {
         MethodHandle var8 = bindingCache8;
         MethodHandle var7 = bindingCache8;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache8 = g(MethodHandles.lookup(), "Z", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = g(
                  MethodHandles.lookup(),
                  "v",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding10(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache10;
         MethodHandle var9 = bindingCache10;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache10 = g(
                  MethodHandles.lookup(), "v", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
