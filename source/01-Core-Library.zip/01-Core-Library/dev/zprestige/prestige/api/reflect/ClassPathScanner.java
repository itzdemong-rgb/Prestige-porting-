package dev.zprestige.prestige.api.reflect;
import java.util.Set;
import net.lenni0451.classtransform.annotations.CTransformer;



import dev.prestige.recovery.SourceSupport;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class ClassPathScanner {
   private static final String a;
   private static final long b = 21003447101325L;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h;
   private static final Object[] i = new Object[59];
   private static final String[] j = new String[59];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;

   private ClassPathScanner() {
   }

   
   
   public static String[] aReturningArrayOfString(Object[] var0) {

      long var1 = (Long)var0[0];
      var1 = 21003447101325L ^ var1;
      long var3 = var1 ^ 44097098598106L;
      TreeSet var6 = new TreeSet();
      int var10000 = invokeBinding1(2901090699203603476L, var1);
      ClassLoader var7 = invokeBinding2(ClassPathScanner.class, 2904133422009259802L, var1);
      int var5 = var10000;

      ClassLoader var12;
      label49: {
         label48: {
            try {
               int var16 = var5;
               ClassLoader var15 = var7;
               var12 = var15;
               ClassLoader var10 = var15;
               if (var16 == 0) {
                  break label49;
               }

               ClassLoader var17 = var10;
               if (var17 != null) {
                  break label48;
            } catch (Throwable var24) {
               throw invokeBinding3(var24, 2902033146784529078L, var1);
            }

            var7 = invokeBinding4(2900928633379277644L, var1);
         }

         try {
            var12 = var7;
         } catch (Throwable var23) {
            return (String[])invokeBinding11(var6, new String[0], 2902475612296192756L, var1);
         }
      }

      try {
         Enumeration var8 = invokeBinding6(var12, invokeBinding5(672, 8459276691123791708L ^ var1), 2900979296844103737L, var1);

         while (true) {
            boolean var18 = invokeBinding7(var8, 2903958933514196451L, var1);
            if (!var18) {
               break;
            }

            URL var9 = (URL)invokeBinding8(var8, 2901476613868703885L, var1);

            try {
               invokeBinding9(new Object[]{var9, var7, var6, var3}, 2901683547363166507L, var1);
               int var19 = var5;
               if (var19 == 0) {
                  break;
               }

               int var20 = var5;
               if (var20 == 0) {
                  break;
            } catch (Throwable var21) {
               throw invokeBinding10(var21, 2902033146784529078L, var1);
            }
      } catch (Throwable var22) {
      }

      return (String[])invokeBinding11(var6, new String[0], 2902475612296192756L, var1);
   
      
}

   private static void aReturningVoid(Object[] param0) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[19];
      recoveryLocals[0]=param0;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.net.URL)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[1]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.ClassLoader)recoveryStack[1]); }
                  recoveryAt=10; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=11; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=12; { recoveryStack[2]=2; }
                  recoveryAt=13; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=14; { recoveryStack[1]=((java.util.Set)recoveryStack[1]); }
                  recoveryAt=15; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=16; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=17; { recoveryStack[2]=3; }
                  recoveryAt=18; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=19; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=20; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=21; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=23; { recoveryStack[0]=21003447101325L; }
                  recoveryAt=24; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=25; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=26; { recoveryLocals[4]=recoveryStack[0];  }
                  recoveryAt=27; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=28; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=29; { recoveryStack[2]=96586815415416L; }
                  recoveryAt=30; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=31; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=33; { recoveryStack[0]=654576242353065283L; }
                  recoveryAt=34; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=35; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding12(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=38; { recoveryStack[1]=recoveryLocals[1];  }
                  recoveryAt=39; { recoveryStack[2]=653082800604283477L; }
                  recoveryAt=40; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=41; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding13(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=42; { recoveryLocals[9]=recoveryStack[1];  }
                  recoveryAt=43; { recoveryLocals[8]=recoveryStack[0];  }
                  recoveryAt=46; { recoveryStack[0]=4350; }
                  recoveryAt=47; { recoveryStack[1]=5016079618316522586L; }
                  recoveryAt=48; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=49; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=50; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding14(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=51; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=52; { recoveryStack[2]=654978962128481937L; }
                  recoveryAt=53; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=54; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding15(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=55; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=56; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=339; continue recoveryFlow;} recoveryPc=57; continue recoveryFlow; }
               }
               case 57 -> {
                  recoveryAt=57; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=308; continue recoveryFlow;} recoveryPc=59; continue recoveryFlow; }
               }
               case 59 -> {
                  recoveryAt=59; { recoveryPc=69; continue recoveryFlow; }
               }
               case 62 -> {
                  recoveryAt=62; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=63; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=64; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding16(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=65; { throw (Throwable)recoveryStack[0]; }
               }
               case 69 -> {
                  recoveryAt=69; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(java.io.File.class); recoveryStack[0]=new Object(); }
                  recoveryAt=70; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=71; { recoveryStack[2]=recoveryLocals[1];  }
                  recoveryAt=72; { recoveryStack[3]=654159999143180564L; }
                  recoveryAt=73; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=74; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding17(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=75; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new java.io.File(((java.net.URI)recoveryStack[2])); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=76; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=79; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=80; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=81; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=103; continue recoveryFlow;} recoveryPc=82; continue recoveryFlow; }
               }
               case 82 -> {
                  recoveryAt=82; { recoveryStack[1]=655178148434385720L; }
                  recoveryAt=83; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=84; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding18(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=85; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=100; continue recoveryFlow;} recoveryPc=87; continue recoveryFlow; }
               }
               case 87 -> {
                  recoveryAt=87; { recoveryPc=96; continue recoveryFlow; }
               }
               case 90 -> {
                  recoveryAt=90; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=91; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=92; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding19(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=93; { throw (Throwable)recoveryStack[0]; }
               }
               case 96 -> {
                  recoveryAt=96; { return; }
               }
               case 100 -> {
                  recoveryAt=100; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryPc=103; continue recoveryFlow;
               }
               case 103 -> {
                  recoveryAt=103; { recoveryStack[1]=654843812486769401L; }
                  recoveryAt=104; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=105; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding20(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=106; { recoveryLocals[11]=recoveryStack[0];  }
                  recoveryAt=109; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=110; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=111; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=130; continue recoveryFlow;} recoveryPc=112; continue recoveryFlow; }
               }
               case 112 -> {
                  recoveryAt=112; { if(recoveryStack[0]!=null){recoveryPc=127; continue recoveryFlow;} recoveryPc=114; continue recoveryFlow; }
               }
               case 114 -> {
                  recoveryAt=114; { recoveryPc=123; continue recoveryFlow; }
               }
               case 117 -> {
                  recoveryAt=117; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=118; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=119; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding21(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=120; { throw (Throwable)recoveryStack[0]; }
               }
               case 123 -> {
                  recoveryAt=123; { return; }
               }
               case 127 -> {
                  recoveryAt=127; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryPc=130; continue recoveryFlow;
               }
               case 130 -> {
                  recoveryAt=130; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=131; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=132; { recoveryStack[0]=java.lang.reflect.Array.getLength(recoveryStack[0]); }
                  recoveryAt=133; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=134; { recoveryStack[0]=0; }
                  recoveryAt=135; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryPc=138; continue recoveryFlow;
               }
               case 138 -> {
                  recoveryAt=138; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=139; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=140; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=304; continue recoveryFlow;} recoveryPc=141; continue recoveryFlow; }
               }
               case 141 -> {
                  recoveryAt=141; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=142; { recoveryStack[1]=recoveryLocals[14];  }
                  recoveryAt=143; { recoveryStack[0]=((Object[])recoveryStack[0])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])]; }
                  recoveryAt=144; { recoveryLocals[15]=recoveryStack[0];  }
                  recoveryAt=147; { recoveryStack[0]=recoveryLocals[15];  }
                  recoveryAt=148; { recoveryStack[1]=653260287714204789L; }
                  recoveryAt=149; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=150; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding22(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=151; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=154; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=155; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=714; continue recoveryFlow;} recoveryPc=157; continue recoveryFlow; }
               }
               case 157 -> {
                  recoveryAt=157; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=158; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=159; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=221; continue recoveryFlow;} recoveryPc=161; continue recoveryFlow; }
               }
               case 161 -> {
                  recoveryAt=161; { recoveryPc=170; continue recoveryFlow; }
               }
               case 164 -> {
                  recoveryAt=164; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=165; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=166; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding23(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=167; { throw (Throwable)recoveryStack[0]; }
               }
               case 170 -> {
                  recoveryAt=170; { recoveryStack[1]=15456; }
                  recoveryAt=171; { recoveryStack[2]=2373347918619670722L; }
                  recoveryAt=172; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=173; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=174; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding24(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=175; { recoveryStack[2]=654648112694898942L; }
                  recoveryAt=176; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=177; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding25(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=178; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=201; continue recoveryFlow;} recoveryPc=180; continue recoveryFlow; }
               }
               case 180 -> {
                  recoveryAt=180; { recoveryPc=298; continue recoveryFlow; }
               }
               case 183 -> {
                  recoveryAt=183; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=184; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=185; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding26(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=186; { throw (Throwable)recoveryStack[0]; }
               }
               case 194 -> {
                  recoveryAt=194; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=195; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=196; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding27(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=197; { throw (Throwable)recoveryStack[0]; }
               }
               case 201 -> {
                  recoveryAt=201; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=202; { recoveryStack[1]=0; }
                  recoveryAt=203; { recoveryStack[2]=recoveryLocals[16];  }
                  recoveryAt=204; { recoveryStack[3]=654302872931657553L; }
                  recoveryAt=205; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=206; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding28(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=207; { recoveryStack[3]=4051; }
                  recoveryAt=208; { recoveryStack[4]=882082684974713718L; }
                  recoveryAt=209; { recoveryStack[5]=recoveryLocals[4];  }
                  recoveryAt=210; { recoveryStack[4]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5]); }
                  recoveryAt=211; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding29(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=212; { recoveryStack[4]=654302872931657553L; }
                  recoveryAt=213; { recoveryStack[5]=recoveryLocals[4];  }
                  recoveryAt=214; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding30(((java.lang.Object)recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=215; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])-dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]); }
                  recoveryAt=216; { recoveryStack[3]=653975637041537259L; }
                  recoveryAt=217; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=218; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding31(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryPc=221; continue recoveryFlow;
               }
               case 221 -> {
                  recoveryAt=221; { recoveryLocals[17]=recoveryStack[0];  }
                  recoveryAt=224; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=225; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=226; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=265; continue recoveryFlow;} recoveryPc=228; continue recoveryFlow; }
               }
               case 228 -> {
                  recoveryAt=228; { recoveryStack[1]="$"; }
                  recoveryAt=229; { recoveryStack[2]=655851325958194686L; }
                  recoveryAt=230; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=231; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding32(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=232; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=255; continue recoveryFlow;} recoveryPc=234; continue recoveryFlow; }
               }
               case 234 -> {
                  recoveryAt=234; { recoveryPc=298; continue recoveryFlow; }
               }
               case 237 -> {
                  recoveryAt=237; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=238; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=239; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding33(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=240; { throw (Throwable)recoveryStack[0]; }
               }
               case 248 -> {
                  recoveryAt=248; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=249; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=250; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding34(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=251; { throw (Throwable)recoveryStack[0]; }
               }
               case 255 -> {
                  recoveryAt=255; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=256; { recoveryStack[1]=15581; }
                  recoveryAt=257; { recoveryStack[2]=3526263913975937141L; }
                  recoveryAt=258; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=259; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=260; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding35(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=261; { Object recoveryTemp=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=262; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.concatenate("\u0001\u0001",new Object[]{((java.lang.String)recoveryStack[0]),((java.lang.String)recoveryStack[1])},new Object[]{}); }
                  recoveryPc=265; continue recoveryFlow;
               }
               case 265 -> {
                  recoveryAt=265; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=266; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=267; { recoveryStack[3]=recoveryLocals[6];  }
                  recoveryAt=268; { recoveryStack[4]=4; }
                  recoveryAt=269; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=270; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=271; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=273; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=274; { recoveryStack[6]=3; }
                  recoveryAt=275; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=276; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=277; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=278; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=279; { recoveryStack[5]=2; }
                  recoveryAt=280; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=281; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=282; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=283; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=284; { recoveryStack[4]=1; }
                  recoveryAt=285; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=286; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=287; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=288; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=289; { recoveryStack[3]=0; }
                  recoveryAt=290; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=291; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=292; { recoveryStack[1]=653486002776563897L; }
                  recoveryAt=293; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=294; { dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding36(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryPc=298; continue recoveryFlow;
               }
               case 298 -> {
                  recoveryAt=298; { recoveryLocals[14]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[14])+(1); }
                  recoveryAt=299; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=300; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=138; continue recoveryFlow;} recoveryPc=304; continue recoveryFlow; }
               }
               case 304 -> {
                  recoveryAt=304; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=305; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=714; continue recoveryFlow;} recoveryPc=308; continue recoveryFlow; }
               }
               case 308 -> {
                  recoveryAt=308; { recoveryStack[0]=5901; }
                  recoveryAt=309; { recoveryStack[1]=7294469905884894119L; }
                  recoveryAt=310; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=311; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=312; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding37(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=313; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=314; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=356; continue recoveryFlow;} recoveryPc=316; continue recoveryFlow; }
               }
               case 316 -> {
                  recoveryAt=316; { recoveryPc=325; continue recoveryFlow; }
               }
               case 319 -> {
                  recoveryAt=319; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=320; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=321; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding38(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=322; { throw (Throwable)recoveryStack[0]; }
               }
               case 325 -> {
                  recoveryAt=325; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=326; { recoveryStack[2]=654978962128481937L; }
                  recoveryAt=327; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=328; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding39(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=330; { recoveryPc=339; continue recoveryFlow; }
               }
               case 333 -> {
                  recoveryAt=333; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=334; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=335; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding40(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=336; { throw (Throwable)recoveryStack[0]; }
               }
               case 339 -> {
                  recoveryAt=339; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=714; continue recoveryFlow;} recoveryPc=342; continue recoveryFlow; }
               }
               case 342 -> {
                  recoveryAt=342; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=343; { recoveryStack[1]=656083081842174613L; }
                  recoveryAt=344; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=345; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding41(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=347; { recoveryPc=356; continue recoveryFlow; }
               }
               case 350 -> {
                  recoveryAt=350; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=351; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=352; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding42(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=353; { throw (Throwable)recoveryStack[0]; }
               }
               case 356 -> {
                  recoveryAt=356; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=359; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=360; { recoveryStack[1]=8528; }
                  recoveryAt=361; { recoveryStack[2]=3446881551881310339L; }
                  recoveryAt=362; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=363; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=364; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding43(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=365; { recoveryStack[2]=656263614414285798L; }
                  recoveryAt=366; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=367; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding44(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=368; { recoveryLocals[11]=recoveryStack[0];  }
                  recoveryAt=371; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=372; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=0){recoveryPc=378; continue recoveryFlow;} recoveryPc=374; continue recoveryFlow; }
               }
               case 374 -> {
                  recoveryAt=374; { return; }
               }
               case 378 -> {
                  recoveryAt=378; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=379; { recoveryStack[1]=30977; }
                  recoveryAt=380; { recoveryStack[2]=6095525645197426095L; }
                  recoveryAt=381; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=382; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=383; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding45(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=384; { recoveryStack[2]=654302872931657553L; }
                  recoveryAt=385; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=386; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding46(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=387; { recoveryStack[2]=recoveryLocals[11];  }
                  recoveryAt=388; { recoveryStack[3]=653975637041537259L; }
                  recoveryAt=389; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=390; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding47(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=391; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=394; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=395; { recoveryStack[1]=13820; }
                  recoveryAt=396; { recoveryStack[2]=469034929315541333L; }
                  recoveryAt=397; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=398; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=399; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding48(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=400; { recoveryStack[2]=recoveryLocals[8];  }
                  recoveryAt=401; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])==0){recoveryPc=440; continue recoveryFlow;} recoveryPc=402; continue recoveryFlow; }
               }
               case 402 -> {
                  recoveryAt=402; { recoveryStack[2]=655251242219737188L; }
                  recoveryAt=403; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=404; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding49(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=405; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=432; continue recoveryFlow;} recoveryPc=407; continue recoveryFlow; }
               }
               case 407 -> {
                  recoveryAt=407; { recoveryPc=416; continue recoveryFlow; }
               }
               case 410 -> {
                  recoveryAt=410; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=411; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=412; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding50(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=413; { throw (Throwable)recoveryStack[0]; }
               }
               case 416 -> {
                  recoveryAt=416; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=417; { recoveryStack[1]=22751; }
                  recoveryAt=418; { recoveryStack[2]=1225450490149706878L; }
                  recoveryAt=419; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=420; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=421; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding51(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=422; { recoveryStack[2]=654302872931657553L; }
                  recoveryAt=423; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=424; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding52(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=425; { recoveryStack[2]=655103661021408792L; }
                  recoveryAt=426; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=427; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding53(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=428; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryPc=432; continue recoveryFlow;
               }
               case 432 -> {
                  recoveryAt=432; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=433; { recoveryStack[1]=26230; }
                  recoveryAt=434; { recoveryStack[2]=7244794262174638806L; }
                  recoveryAt=435; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=436; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=437; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding54(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryPc=440; continue recoveryFlow;
               }
               case 440 -> {
                  recoveryAt=440; { recoveryStack[2]=653401628445210776L; }
                  recoveryAt=441; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=442; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding55(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=443; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=446; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(java.util.jar.JarFile.class); recoveryStack[0]=new Object(); }
                  recoveryAt=447; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=448; { recoveryStack[2]=recoveryLocals[12];  }
                  recoveryAt=449; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new java.util.jar.JarFile(((java.lang.String)recoveryStack[2])); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=450; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=453; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=454; { recoveryStack[1]=653145327678023035L; }
                  recoveryAt=455; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=456; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding56(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=457; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryPc=461; continue recoveryFlow;
               }
               case 461 -> {
                  recoveryAt=461; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=462; { recoveryStack[1]=656351553775121588L; }
                  recoveryAt=463; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=464; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding57(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=465; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=681; continue recoveryFlow;} recoveryPc=468; continue recoveryFlow; }
               }
               case 468 -> {
                  recoveryAt=468; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=469; { recoveryStack[1]=653908816271405530L; }
                  recoveryAt=470; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=471; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding58(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=472; { recoveryStack[0]=((java.util.jar.JarEntry)recoveryStack[0]); }
                  recoveryAt=473; { recoveryLocals[15]=recoveryStack[0];  }
                  recoveryAt=476; { recoveryStack[0]=recoveryLocals[15];  }
                  recoveryAt=477; { recoveryStack[1]=654871687362246819L; }
                  recoveryAt=478; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=479; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding59(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=480; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=483; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=484; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=687; continue recoveryFlow;} recoveryPc=486; continue recoveryFlow; }
               }
               case 486 -> {
                  recoveryAt=486; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=487; { recoveryStack[1]=12245; }
                  recoveryAt=488; { recoveryStack[2]=106033478572862326L; }
                  recoveryAt=489; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=490; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=491; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding60(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=492; { recoveryStack[2]=recoveryLocals[8];  }
                  recoveryAt=493; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])==0){recoveryPc=538; continue recoveryFlow;} recoveryPc=495; continue recoveryFlow; }
               }
               case 495 -> {
                  recoveryAt=495; { recoveryPc=504; continue recoveryFlow; }
               }
               case 498 -> {
                  recoveryAt=498; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=499; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=500; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding61(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=501; { throw (Throwable)recoveryStack[0]; }
               }
               case 504 -> {
                  recoveryAt=504; { recoveryStack[2]=655251242219737188L; }
                  recoveryAt=505; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=506; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding62(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=507; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=530; continue recoveryFlow;} recoveryPc=509; continue recoveryFlow; }
               }
               case 509 -> {
                  recoveryAt=509; { recoveryPc=461; continue recoveryFlow; }
               }
               case 512 -> {
                  recoveryAt=512; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=513; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=514; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding63(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=515; { throw (Throwable)recoveryStack[0]; }
               }
               case 523 -> {
                  recoveryAt=523; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=524; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=525; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding64(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=526; { throw (Throwable)recoveryStack[0]; }
               }
               case 530 -> {
                  recoveryAt=530; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=531; { recoveryStack[1]=27555; }
                  recoveryAt=532; { recoveryStack[2]=8786883213284159237L; }
                  recoveryAt=533; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=534; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=535; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding65(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryPc=538; continue recoveryFlow;
               }
               case 538 -> {
                  recoveryAt=538; { recoveryStack[2]=654302872931657553L; }
                  recoveryAt=539; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=540; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding66(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=541; { recoveryStack[2]=1; }
                  recoveryAt=542; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])+dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]); }
                  recoveryAt=543; { recoveryStack[2]=655103661021408792L; }
                  recoveryAt=544; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=545; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding67(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=546; { recoveryLocals[17]=recoveryStack[0];  }
                  recoveryAt=549; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=550; { recoveryStack[1]="/"; }
                  recoveryAt=551; { recoveryStack[2]=655851325958194686L; }
                  recoveryAt=552; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=553; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding68(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=554; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=555; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=574; continue recoveryFlow;} recoveryPc=556; continue recoveryFlow; }
               }
               case 556 -> {
                  recoveryAt=556; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=461; continue recoveryFlow;} recoveryPc=558; continue recoveryFlow; }
               }
               case 558 -> {
                  recoveryAt=558; { recoveryPc=567; continue recoveryFlow; }
               }
               case 561 -> {
                  recoveryAt=561; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=562; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=563; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding69(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=564; { throw (Throwable)recoveryStack[0]; }
               }
               case 567 -> {
                  recoveryAt=567; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=568; { recoveryStack[1]="$"; }
                  recoveryAt=569; { recoveryStack[2]=655851325958194686L; }
                  recoveryAt=570; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=571; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding70(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=574; continue recoveryFlow;
               }
               case 574 -> {
                  recoveryAt=574; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=575; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=608; continue recoveryFlow;} recoveryPc=576; continue recoveryFlow; }
               }
               case 576 -> {
                  recoveryAt=576; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=461; continue recoveryFlow;} recoveryPc=578; continue recoveryFlow; }
               }
               case 578 -> {
                  recoveryAt=578; { recoveryPc=587; continue recoveryFlow; }
               }
               case 581 -> {
                  recoveryAt=581; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=582; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=583; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding71(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=584; { throw (Throwable)recoveryStack[0]; }
               }
               case 587 -> {
                  recoveryAt=587; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=588; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=589; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=633; continue recoveryFlow;} recoveryPc=590; continue recoveryFlow; }
               }
               case 590 -> {
                  recoveryAt=590; { recoveryStack[1]=4051; }
                  recoveryAt=591; { recoveryStack[2]=882082684974713718L; }
                  recoveryAt=592; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=593; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=594; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding72(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=595; { recoveryStack[2]=654648112694898942L; }
                  recoveryAt=596; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=597; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding73(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=599; { recoveryPc=608; continue recoveryFlow; }
               }
               case 602 -> {
                  recoveryAt=602; { recoveryStack[1]=653352642887883745L; }
                  recoveryAt=603; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=604; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding74(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=605; { throw (Throwable)recoveryStack[0]; }
               }
               case 608 -> {
                  recoveryAt=608; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=613; continue recoveryFlow;} recoveryPc=609; continue recoveryFlow; }
               }
               case 609 -> {
                  recoveryAt=609; { recoveryPc=461; continue recoveryFlow; }
               }
               case 613 -> {
                  recoveryAt=613; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=614; { recoveryStack[1]=0; }
                  recoveryAt=615; { recoveryStack[2]=recoveryLocals[17];  }
                  recoveryAt=616; { recoveryStack[3]=654302872931657553L; }
                  recoveryAt=617; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=618; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding75(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=619; { recoveryStack[3]=4051; }
                  recoveryAt=620; { recoveryStack[4]=882082684974713718L; }
                  recoveryAt=621; { recoveryStack[5]=recoveryLocals[4];  }
                  recoveryAt=622; { recoveryStack[4]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5]); }
                  recoveryAt=623; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding76(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=624; { recoveryStack[4]=654302872931657553L; }
                  recoveryAt=625; { recoveryStack[5]=recoveryLocals[4];  }
                  recoveryAt=626; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding77(((java.lang.Object)recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=627; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])-dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]); }
                  recoveryAt=628; { recoveryStack[3]=653975637041537259L; }
                  recoveryAt=629; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=630; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding78(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryPc=633; continue recoveryFlow;
               }
               case 633 -> {
                  recoveryAt=633; { recoveryLocals[18]=recoveryStack[0];  }
                  recoveryAt=636; { recoveryStack[0]=recoveryLocals[18];  }
                  recoveryAt=637; { recoveryStack[1]=12245; }
                  recoveryAt=638; { recoveryStack[2]=106033478572862326L; }
                  recoveryAt=639; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=640; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=641; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding79(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=642; { Object recoveryTemp=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=643; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.concatenate("\u0001\u0001",new Object[]{((java.lang.String)recoveryStack[0]),((java.lang.String)recoveryStack[1])},new Object[]{}); }
                  recoveryAt=644; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=645; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=646; { recoveryStack[3]=recoveryLocals[6];  }
                  recoveryAt=647; { recoveryStack[4]=4; }
                  recoveryAt=648; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=649; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=650; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=652; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=653; { recoveryStack[6]=3; }
                  recoveryAt=654; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=655; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=656; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=657; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=658; { recoveryStack[5]=2; }
                  recoveryAt=659; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=660; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=661; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=662; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=663; { recoveryStack[4]=1; }
                  recoveryAt=664; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=665; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=666; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=667; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=668; { recoveryStack[3]=0; }
                  recoveryAt=669; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=670; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=671; { recoveryStack[1]=653486002776563897L; }
                  recoveryAt=672; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=673; { dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding80(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=676; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=677; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=461; continue recoveryFlow;} recoveryPc=681; continue recoveryFlow; }
               }
               case 681 -> {
                  recoveryAt=681; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=682; { recoveryStack[1]=655031085703543173L; }
                  recoveryAt=683; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=684; { dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding81(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryPc=687; continue recoveryFlow;
               }
               case 687 -> {
                  recoveryAt=687; { recoveryPc=722; continue recoveryFlow; }
               }
               case 691 -> {
                  recoveryAt=691; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=693; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=694; { recoveryStack[1]=655031085703543173L; }
                  recoveryAt=695; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=696; { dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding82(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=698; { recoveryPc=709; continue recoveryFlow; }
               }
               case 701 -> {
                  recoveryAt=701; { recoveryLocals[15]=recoveryStack[0];  }
                  recoveryAt=702; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=703; { recoveryStack[1]=recoveryLocals[15];  }
                  recoveryAt=704; { recoveryStack[2]=654261948352703151L; }
                  recoveryAt=705; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=706; { dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding83(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=709; continue recoveryFlow;
               }
               case 709 -> {
                  recoveryAt=709; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=710; { throw (Throwable)recoveryStack[0]; }
               }
               case 714 -> {
                  recoveryAt=714; { recoveryPc=722; continue recoveryFlow; }
               }
               case 718 -> {
                  recoveryPc=722; continue recoveryFlow;
               }
               case 722 -> {
                  recoveryAt=722; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=585 && recoveryAt<598 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=602; continue recoveryFlow;}
            if(recoveryAt>=572 && recoveryAt<577 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=581; continue recoveryFlow;}
            if(recoveryAt>=547 && recoveryAt<557 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=561; continue recoveryFlow;}
            if(recoveryAt>=502 && recoveryAt<516 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=523; continue recoveryFlow;}
            if(recoveryAt>=485 && recoveryAt<508 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=512; continue recoveryFlow;}
            if(recoveryAt>=481 && recoveryAt<494 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=498; continue recoveryFlow;}
            if(recoveryAt>=77 && recoveryAt<86 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=90; continue recoveryFlow;}
            if(recoveryAt>=44 && recoveryAt<58 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=62; continue recoveryFlow;}
            if(recoveryAt>=451 && recoveryAt<516 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=691; continue recoveryFlow;}
            if(recoveryAt>=521 && recoveryAt<678 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=691; continue recoveryFlow;}
            if(recoveryAt>=692 && recoveryAt<697 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=701; continue recoveryFlow;}
            if(recoveryAt>=44 && recoveryAt<94 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            if(recoveryAt>=107 && recoveryAt<113 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=117; continue recoveryFlow;}
            if(recoveryAt>=97 && recoveryAt<121 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            if(recoveryAt>=337 && recoveryAt<346 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=350; continue recoveryFlow;}
            if(recoveryAt>=306 && recoveryAt<329 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=333; continue recoveryFlow;}
            if(recoveryAt>=301 && recoveryAt<315 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=319; continue recoveryFlow;}
            if(recoveryAt>=227 && recoveryAt<241 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=248; continue recoveryFlow;}
            if(recoveryAt>=222 && recoveryAt<233 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=237; continue recoveryFlow;}
            if(recoveryAt>=168 && recoveryAt<187 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=194; continue recoveryFlow;}
            if(recoveryAt>=156 && recoveryAt<179 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=183; continue recoveryFlow;}
            if(recoveryAt>=152 && recoveryAt<160 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=164; continue recoveryFlow;}
            if(recoveryAt>=124 && recoveryAt<187 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            if(recoveryAt>=192 && recoveryAt<241 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            if(recoveryAt>=246 && recoveryAt<373 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            if(recoveryAt>=392 && recoveryAt<406 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=410; continue recoveryFlow;}
            if(recoveryAt>=375 && recoveryAt<516 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            if(recoveryAt>=521 && recoveryAt<711 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=718; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

    private static void bReturningVoid(final Object[] array) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[8];
      recoveryLocals[0]=array;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.String)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.ClassLoader)recoveryStack[1]); }
                  recoveryAt=10; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=11; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=12; { recoveryStack[2]=2; }
                  recoveryAt=13; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=14; { recoveryStack[1]=((java.util.Set)recoveryStack[1]); }
                  recoveryAt=15; { recoveryLocals[1]=recoveryStack[1];  }
                  recoveryAt=16; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=17; { recoveryStack[2]=3; }
                  recoveryAt=18; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=19; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=20; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=21; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=23; { recoveryStack[0]=21003447101325L; }
                  recoveryAt=24; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=25; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=26; { recoveryLocals[4]=recoveryStack[0];  }
                  recoveryAt=27; { recoveryStack[0]=5399595395293345999L; }
                  recoveryAt=28; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=29; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding84(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=30; { recoveryLocals[6]=recoveryStack[0];  }
                  recoveryAt=33; { recoveryStack[0]=recoveryLocals[3];  }
                  recoveryAt=34; { recoveryStack[1]=30727; }
                  recoveryAt=35; { recoveryStack[2]=8155323581565078048L; }
                  recoveryAt=36; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=37; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=38; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding85(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=39; { recoveryStack[2]=16760; }
                  recoveryAt=40; { recoveryStack[3]=3568996680604005212L; }
                  recoveryAt=41; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=42; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=43; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding86(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=44; { recoveryStack[3]=5399354932097038962L; }
                  recoveryAt=45; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=46; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding87(((java.lang.Object)recoveryStack[0]),(char)dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),(char)dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=47; { recoveryStack[1]=0; }
                  recoveryAt=48; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=49; { recoveryStack[3]=5396625172393537525L; }
                  recoveryAt=50; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=51; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding88(((java.lang.Object)recoveryStack[0]),((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]) & 1) != 0),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=52; { recoveryLocals[7]=recoveryStack[0];  }
                  recoveryAt=55; { recoveryStack[0]=recoveryLocals[7];  }
                  recoveryAt=56; { recoveryStack[1]=net.lenni0451.classtransform.annotations.CTransformer.class; }
                  recoveryAt=57; { recoveryStack[2]=5396239438870161869L; }
                  recoveryAt=58; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=59; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding89(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=60; { recoveryStack[1]=recoveryLocals[6];  }
                  recoveryAt=61; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=90; continue recoveryFlow;} recoveryPc=63; continue recoveryFlow; }
               }
               case 63 -> {
                  recoveryAt=63; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=94; continue recoveryFlow;} recoveryPc=65; continue recoveryFlow; }
               }
               case 65 -> {
                  recoveryAt=65; { recoveryPc=75; continue recoveryFlow; }
               }
               case 68 -> {
                  recoveryAt=68; { recoveryStack[1]=5396552628504582164L; }
                  recoveryAt=69; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=70; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding90(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=71; { throw (Throwable)recoveryStack[0]; }
               }
               case 75 -> {
                  recoveryAt=75; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=76; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=77; { recoveryStack[2]=5395750130926486241L; }
                  recoveryAt=78; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=79; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding91(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=81; { recoveryPc=90; continue recoveryFlow; }
               }
               case 84 -> {
                  recoveryAt=84; { recoveryStack[1]=5396552628504582164L; }
                  recoveryAt=85; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=86; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ClassPathScanner.invokeBinding92(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=87; { throw (Throwable)recoveryStack[0]; }
               }
               case 90 -> {
                  recoveryPc=94; continue recoveryFlow;
               }
               case 94 -> {
                  recoveryAt=94; { recoveryPc=102; continue recoveryFlow; }
               }
               case 98 -> {
                  recoveryPc=102; continue recoveryFlow;
               }
               case 102 -> {
                  recoveryAt=102; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=62 && recoveryAt<80 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=84; continue recoveryFlow;}
            if(recoveryAt>=53 && recoveryAt<64 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=68; continue recoveryFlow;}
            if(recoveryAt>=31 && recoveryAt<91 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=98; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(107064688426360L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[13];
      String var17 = "eRCÀ:ÐõÞy4ùþ\u0084Ù\u0093ê@~i\u0096t!äßwàWoÞ2ËàÉr©7ø;|\u0092M\u0095\u0081\u009b¬ä\u00944ìÅp®ÔÂq\u001f\u009aR\u0017\u0016ú44Ø|\u0091\u007f\u0095Æ\u0014_1q¾P\"08\u0088ÛE\u0010&\u0092\u0099`\u001fÄ%¯ê´XUKS$¤\u0010\u0087µ\u001e÷·O4(\rïlv\u0084ò[²@¾úÌ Ô(3¹éü%²\u0018ß¹sÐ UÏ\u0092ÊïS[Î\f>\u000b+\u0014¾WÊ@ØBÚÍ\u00adnÃ;Äû\u008aþ\u000eY³ÐmÙ×½ajBR÷\u0000i$à@\r\u0006\u0000qI\u0013ç\u009a\u0092Z¯Õ\u008dj·¾É\r\u0083©ëó«@,pnõâ1l!uû\u000f\u0083\u0017\b\u0091S\u001f \tk\u0085\u0013ò»ÿ±×\u0092h<\u000f·e¡âÝE\u0092\u0017â\u0010ñ\u0004\u001ar\u0098\fb\u000f\u0004\u0093ô#é4¯\u0001\u0010Î¼\u0084ûzw\u0001Ô\u00ad.\u0003laü\u0089Z\u0010Ú\u0005#[£\u009d\u0010\u000bê¿Þö>\u0015\u0002¨@Ü¤\u0013l°®lt`þ°\tbQ\u0018\u0007ªÈ«K]¶<\u0001|OIH\u0086ß^ÕX\u0084,\u007flô\u008bä\u0098¯;n)^¢\"\u0013\u008bÿÜ\u009f5\u009dÅi\u0002°ÑöDª|83ê*\u0012f5ù\u008aë\u000b$r5\u0091á´Ú\u0083í}{\\2æaM\u0004¿\"¢IÊ\u0003kpm#\u0093Tï>\u0010ø\u001f\u001c<l2ù\u001bë\u001cXÜ\u008e\\";
      int var19 = "eRCÀ:ÐõÞy4ùþ\u0084Ù\u0093ê@~i\u0096t!äßwàWoÞ2ËàÉr©7ø;|\u0092M\u0095\u0081\u009b¬ä\u00944ìÅp®ÔÂq\u001f\u009aR\u0017\u0016ú44Ø|\u0091\u007f\u0095Æ\u0014_1q¾P\"08\u0088ÛE\u0010&\u0092\u0099`\u001fÄ%¯ê´XUKS$¤\u0010\u0087µ\u001e÷·O4(\rïlv\u0084ò[²@¾úÌ Ô(3¹éü%²\u0018ß¹sÐ UÏ\u0092ÊïS[Î\f>\u000b+\u0014¾WÊ@ØBÚÍ\u00adnÃ;Äû\u008aþ\u000eY³ÐmÙ×½ajBR÷\u0000i$à@\r\u0006\u0000qI\u0013ç\u009a\u0092Z¯Õ\u008dj·¾É\r\u0083©ëó«@,pnõâ1l!uû\u000f\u0083\u0017\b\u0091S\u001f \tk\u0085\u0013ò»ÿ±×\u0092h<\u000f·e¡âÝE\u0092\u0017â\u0010ñ\u0004\u001ar\u0098\fb\u000f\u0004\u0093ô#é4¯\u0001\u0010Î¼\u0084ûzw\u0001Ô\u00ad.\u0003laü\u0089Z\u0010Ú\u0005#[£\u009d\u0010\u000bê¿Þö>\u0015\u0002¨@Ü¤\u0013l°®lt`þ°\tbQ\u0018\u0007ªÈ«K]¶<\u0001|OIH\u0086ß^ÕX\u0084,\u007flô\u008bä\u0098¯;n)^¢\"\u0013\u008bÿÜ\u009f5\u009dÅi\u0002°ÑöDª|83ê*\u0012f5ù\u008aë\u000b$r5\u0091á´Ú\u0083í}{\\2æaM\u0004¿\"¢IÊ\u0003kpm#\u0093Tï>\u0010ø\u001f\u001c<l2ù\u001bë\u001cXÜ\u008e\\"
         .length();
      char var16 = 16;
      int var23 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var24.getBytes("ISO-8859-1"));
            String var33 = a(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var23 += var16) >= var19) {
                     c = var20;
                     d = new String[13];
                     a = "dev/zprestige/prestige/api/newmixins";
                     h = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(107064688426360L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     String var4 = "O{ëröñ\\O¿pn\u0083 ³\u0088hß\u0091Ùvp\u009dÌ0";
                     int var5 = "O{ëröñ\\O¿pn\u0083 ³\u0088hß\u0091Ùvp\u009dÌ0".length();
                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var10001] = var10004;
                     } while (var2 < var5);

                     f = var6;
                     g = new Integer[3];
                     break;
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label45;
                  }

                  var17 = "p\u0003\u000f(\u008aZ?§\r½9\u0006îüêÿ\u0010rø\u0095b\u0018ÚAã·\u0007V\u0099Å«Na";
                  var19 = "p\u0003\u000f(\u008aZ?§\r½9\u0006îüêÿ\u0010rø\u0095b\u0018ÚAã·\u0007V\u0099Å«Na".length();
                  var16 = 16;
                  var23 = -1;
            }

            var24 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19903;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])e.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cF", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cF_C0121",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14542;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cF", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cF_C0121",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 43;
            yield var15;
         }
         case 1 -> {
            byte var16 = 30;
            yield var16;
         }
         case 2 -> {
            byte var17 = 16;
            yield var17;
         }
         case 3 -> {
            byte var18 = 39;
            yield var18;
         }
         case 4 -> {
            byte var19 = 35;
            yield var19;
         }
         case 5 -> {
            byte var20 = 33;
            yield var20;
         }
         case 6 -> {
            byte var21 = 28;
            yield var21;
         }
         case 7 -> {
            byte var22 = 49;
            yield var22;
         }
         case 8 -> {
            byte var23 = 1;
            yield var23;
         }
         case 9 -> {
            byte var24 = 11;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 60;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 55;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 21;
            yield var30;
         }
         case 16 -> {
            byte var31 = 27;
            yield var31;
         }
         case 17 -> {
            byte var32 = 17;
            yield var32;
         }
         case 18 -> {
            byte var33 = 14;
            yield var33;
         }
         case 19 -> {
            byte var34 = 0;
            yield var34;
         }
         case 20 -> {
            byte var35 = 57;
            yield var35;
         }
         case 21 -> {
            byte var36 = 15;
            yield var36;
         }
         case 22 -> {
            byte var37 = 3;
            yield var37;
         }
         case 23 -> {
            byte var38 = 62;
            yield var38;
         }
         case 24 -> {
            byte var39 = 50;
            yield var39;
         }
         case 25 -> {
            byte var40 = 32;
            yield var40;
         }
         case 26 -> {
            byte var41 = 42;
            yield var41;
         }
         case 27 -> {
            byte var42 = 18;
            yield var42;
         }
         case 28 -> {
            byte var43 = 9;
            yield var43;
         }
         case 29 -> {
            byte var44 = 22;
            yield var44;
         }
         case 30 -> {
            byte var45 = 37;
            yield var45;
         }
         case 31 -> {
            byte var46 = 5;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 52;
            yield var48;
         }
         case 34 -> {
            byte var49 = 53;
            yield var49;
         }
         case 35 -> {
            byte var50 = 7;
            yield var50;
         }
         case 36 -> {
            byte var51 = 13;
            yield var51;
         }
         case 37 -> {
            byte var52 = 10;
            yield var52;
         }
         case 38 -> {
            byte var53 = 25;
            yield var53;
         }
         case 39 -> {
            byte var54 = 54;
            yield var54;
         }
         case 40 -> {
            byte var55 = 47;
            yield var55;
         }
         case 41 -> {
            byte var56 = 58;
            yield var56;
         }
         case 42 -> {
            byte var57 = 20;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 31;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 23;
            yield var61;
         }
         case 47 -> {
            byte var62 = 29;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 44;
            yield var64;
         }
         case 50 -> {
            byte var65 = 61;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 12;
            yield var68;
         }
         case 54 -> {
            byte var69 = 56;
            yield var69;
         }
         case 55 -> {
            byte var70 = 59;
            yield var70;
         }
         case 56 -> {
            byte var71 = 19;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 63;
            yield var73;
         }
         case 59 -> {
            byte var74 = 40;
            yield var74;
         }
         case 60 -> {
            byte var75 = 34;
            yield var75;
         }
         case 61 -> {
            byte var76 = 46;
            yield var76;
         }
         case 62 -> {
            byte var77 = 8;
            yield var77;
         }
         default -> 4;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "\bd.2pz\u0016l4}\u001ba\u0017h=!?{\u000bj6";
      i[1] = boolean.class;
      j[1] = "java/lang/Boolean";
      i[2] = "qg\u000fc=xzh\u001e,@`io\u0017e";
      i[3] = int.class;
      j[3] = "java/lang/Integer";
      i[4] = "C0\"{b\u0018H?34\u0003\u0016C47n";
      i[5] = "\tg5%t>\u0002h$j\u0019:\u0002t\u0010!+'\u0006h !";
      i[6] = "HU\bu&hG@PAZJ";
      i[7] = "\u0005Dg<T=\u001bL}s\u0010)\u001d\u000b[<\b\r\u0001Qc$";
      i[8] = "\u0014,['6T\u001b9\u0003\u0013Jv:(N)|_\f";
      i[9] = "o\u001a`{|Jy\u001ae!o]nQf'cI\u007f\u0016q0(YM";
      i[10] = "x\u001c\u000bGhWs\u0013\u001a\b\u0012S`\u0012\nG$Ww";
      i[11] = "cG\u0015-b#uG\u0010wq4b\f\u0013q} sK\u0004f62B";
      i[12] = void.class;
      j[12] = "java/lang/Void";
      i[13] = "e\b{EQV\u0010(pJ@\u0019q&{ADC\u0005";
      i[14] = "Qu(+Cu^`p\u001f?R";
      i[15] = "~XH\u0006\u001d\u0015`PRIY\u0001f\u0017t\u0006A&}U[";
      i[16] = "DoAgsIA qo1E";
      i[17] = "F4\u001001\u00183\u0011\u0015\u007f\u0001\u0010q\u001dA";
      i[18] = ",4H\u007f_\u001a';Y02\u001a'&M";
      i[19] = "\u0006\u0011T-\u0007t\r\u001eEbjt\r\u0003Q\u0000Fy\b\u0015P";
      i[20] = "Gx\t\u0017:gYp\u0013XGwY";
      i[21] = "Ut&Yr] T-Vc\u0012AZ&]gH5";
      i[22] = "\u0003\f\u0015;B.v,\u001e4Sa\u0017\"\u0015?W;c";
      i[23] = "8\u0010N\npmM0E\u0005a\",>N\u000eexX";
      i[24] = char.class;
      j[24] = "java/lang/Character";
      i[25] = ".2Y\u00138ek.\r\u0002Tgz8\u0004\u0013?p\u0017 ZC6\u007fp)\n\u00108\u001dwzY\u00186z~*\n\u0016T$ey\t\u0016,ay-\u0018z";
      i[26] = "aV\r\u000e=:w\b\u001ek4kp.\u0006\u00119Oo\u0006\u0004\u00062~pk\u001f\u00112f{\u0001\u001e\u00069\u0002";
      i[27] = ">8{kV\u0018{$/z:\u0001a&/r}\u000e\u0007p'rZ\u000ey*:|\u0003`=/2bT\u001eg2<;:";
      i[28] = "\n(\u0004\u0019+4D \u0014\u001bKd5k\nS+`K1\u0017]r\u000e";
      i[29] = "hX:3\u000bI-Dn\"gZ6L\u007f3\u0006W**?g\u000bZ;Lbg\u0003SQTy<\u0003A;Un7g";
      i[30] = "@|>y#>B sr\u001b \u001bE~dz:\u0013\u001e;l\"5\u0010f~pv$|";
      i[31] = "/\b\u0015}?\u0011.T\u0011/]@.I:%4T8q\u0016(1B95\u001d!7L}Y\f:&]C";
      i[32] = "!0Vn\u000410+G\u007f:2 ,f`A:0*W`A]t\"\u0005dV%1>Qu:7p<Yd\u0002!./<";
      i[33] = "sHi2\u0006\u0014bSx#8\u0017rTX C\u0004rMH5Q\u0003dld8T\u0015e(o1R\u001b!D~*C\n\u001f";
      i[34] = "w5,\u0004 D2)x\u0015LQ(+n2-@.G,\u001fuU\"?i\u0003!DN9o\u000b(L$8x\u0000L";
      i[35] = "10Lx\u001dy\u007f8\\z}(\u000esB2\u001d-p)_<DC";
      i[36] = "\u0011nt\u001dn4AslU\u0014fCrVPlwUsvVyc/ }T$u\u0014p`Ll\u000f\u001fn|Q(`\u0011|jC\u0014";
      i[37] = "\r\u000bg>~\u001d\u000fW*5F\u0003V4\u0001\u0018FNJU>\"\"\u0000]\u0004dY";
      i[38] = "#%1#\t4-2?,h8\"$_rQ#\u007fto*\u0013`%H!3\u000e5>\" $\u0005Q";
      i[39] = "G`Hiy}\u0002|\u001cx\u0015a\u0013t\u001e|u\u0005Dw\u0001`{{\u001ej\u000f9\u0015";
      i[40] = "iT3PG*,HgA+)-LqEQ36I\n\u0003N\"0HtYS,i&3K\u0012;<^vWF*P";
      i[41] = "S\u0001O6fiG\rF&Xd^\u0003_4X?J\u0015Xe71X\u0003JY";
      i[42] = "e]OPO\u0002 A\u001bA#\u0001 F\fEX%=S\u00169\u001a\beF\u001aA_\u00141WvGY\u001c8_\u001cFN\u0017\\";
      i[43] = "k \u007f\u0002HA9%y\u0001*Jz\u0003#FG@}(8M*U{)&L@Tl\"B";
      i[44] = "f<mD|Q49kG\u001e_m(,4\u007f_a(P\u0011s\\=+3\n%\u0007qS";
      i[45] = "I\u001df\u0007vMHAbU\u0014\u0012^id]s\u000fL\\c\\r+_MyVr\u000f%L?_(\u0011\u001bMc[zs[Zd_d\u0019ZMo;";
      i[46] = "}\b[U!r8\u0014\u000fDMg=\u0007\u000bX6\n\u007fC\u0010\rq:'\u0001SWMt>\u001c\u0006L'u)\u0017b";
      i[47] = "\u0007vj\fYsJ/1\u0007=wW4\u0015\bXu:q!XTtB4=\fE\u0018";
      i[48] = "^ka\u007fx\u0003\u001ez&vF\u0014\u000e~?t+xZgaq*\u0000\u001f{5`FA\u0011,1t>\u0004\rx \u0018\u007f\nZ|4`:\u0016\u000emX";
      i[49] = "\u0012\u0007:\u0016xZ\u0015\u00104\\\u001f\u000f,W)_/\u001c\u0017\u00074Ggf\u0012\u0019 \u0016e]B\u00048^\u001f";
      i[50] = "Yf`B\u007f^X:d\u0010\u001d\u000eR!B\u0017x\r5bvGt\fM'j\u0013e`K!b\u001am\nJ6i~q\u0000_8:\u0012`\u001bN)\u0004\u0012 \u0004\t9:\u0013|\u0000[[";
      i[51] = "gO0EV>`X>\u000f1hYN?\rRo#X\"E[\u0002iQ\"\t\rmgC4\u001b1";
      i[52] = "jU\t?\u0001+~Y\u0000/? eL\u00181R6\u0003Z_<Z$;L\u0001/?";
      i[53] = "<\u0001&2me>]k9Uhm\u001fB/2{g\b}1U>rZs9-{n\u000ebU";
      i[54] = "w\u0007\u0012qg)%\u0002\u0014r\u0005,p\u0014i&`.\u001dQ]vl/e\u0014A\"}C";
      i[55] = ";\u001f\n\u0014\u000e}5\b\u0004\u001bod1;\u001e\u0004\u0006iV\u001d\b\u0006\fu,\u000b\u0015N\u0005\u00189\u001e\u001c\u001d\u0002b/\u0003T\u0014o";
      i[56] = "\u0019y\u0003TQ(\\eWE=+]aAAG1Fd:\u0007X @eD]E.\u0019\u000b\u0000XM0NuZECi 2H\u0004T<XwTPEP";
      i[57] = "<P?K7\u001c*\u000e,.8I&\u0011\u001eJ3A;\u000b/.e\u001d$\\o\u001e=_g\u0006S";
      i[58] = "\nb%ma\u0019\ru+'\u0006L4c*%eHNu7ml%\u0004|7!:J\nn!3\u0006";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(310263572968464L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(310263572968464L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(310263572968464L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 248;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 88;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 224;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 109;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 208;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 248;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 88;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 224;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cF_C0121",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClassLoader invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/ClassLoader;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ClassLoader)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClassLoader invokeBinding4(long var0, long var2) {
         MethodHandle var8 = bindingCache4;
         MethodHandle var7 = bindingCache4;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache4 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(JJ)Ljava/lang/ClassLoader;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (ClassLoader)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static String invokeBinding5(int var0, long var1) {
         MethodHandle var7 = bindingCache5;
         MethodHandle var6 = bindingCache5;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache5 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Enumeration invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(
                  MethodHandles.lookup(),
                  "Ð",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/util/Enumeration;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Enumeration)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object[] invokeBinding11(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)[Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object[])var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding12(long var0, long var2) {
         MethodHandle var8 = bindingCache12;
         MethodHandle var7 = bindingCache12;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache12 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static String invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding14(int var0, long var1) {
         MethodHandle var7 = bindingCache14;
         MethodHandle var6 = bindingCache14;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache14 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static URI invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/net/URI;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (URI)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static File[] invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)[Ljava/io/File;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (File[])var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding22(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding24(int var0, long var1) {
         MethodHandle var7 = bindingCache24;
         MethodHandle var6 = bindingCache24;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache24 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding25(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache25;
         MethodHandle var9 = bindingCache25;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache25 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding29(int var0, long var1) {
         MethodHandle var7 = bindingCache29;
         MethodHandle var6 = bindingCache29;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache29 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding31(Object var0, int var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache31;
         MethodHandle var10 = bindingCache31;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache31 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;IIJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (int)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static boolean invokeBinding32(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache32;
         MethodHandle var9 = bindingCache32;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache32 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding35(int var0, long var1) {
         MethodHandle var7 = bindingCache35;
         MethodHandle var6 = bindingCache35;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache35 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding37(int var0, long var1) {
         MethodHandle var7 = bindingCache37;
         MethodHandle var6 = bindingCache37;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache37 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding43(int var0, long var1) {
         MethodHandle var7 = bindingCache43;
         MethodHandle var6 = bindingCache43;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache43 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding44(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache44;
         MethodHandle var9 = bindingCache44;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache44 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;IJJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding45(int var0, long var1) {
         MethodHandle var7 = bindingCache45;
         MethodHandle var6 = bindingCache45;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache45 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding46(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache46;
         MethodHandle var8 = bindingCache46;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache46 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding47(Object var0, int var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache47;
         MethodHandle var10 = bindingCache47;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache47 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;IIJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (int)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding48(int var0, long var1) {
         MethodHandle var7 = bindingCache48;
         MethodHandle var6 = bindingCache48;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache48 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding49(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache49;
         MethodHandle var9 = bindingCache49;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache49 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding50(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache50;
         MethodHandle var8 = bindingCache50;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache50 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding51(int var0, long var1) {
         MethodHandle var7 = bindingCache51;
         MethodHandle var6 = bindingCache51;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache51 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding52(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache52;
         MethodHandle var8 = bindingCache52;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache52 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding53(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache53;
         MethodHandle var9 = bindingCache53;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache53 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;IJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding54(int var0, long var1) {
         MethodHandle var7 = bindingCache54;
         MethodHandle var6 = bindingCache54;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache54 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding55(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache55;
         MethodHandle var9 = bindingCache55;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache55 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Enumeration invokeBinding56(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache56;
         MethodHandle var8 = bindingCache56;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache56 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/Enumeration;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Enumeration)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding57(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache57;
         MethodHandle var8 = bindingCache57;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache57 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding58(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache58;
         MethodHandle var8 = bindingCache58;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache58 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding59(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache59;
         MethodHandle var8 = bindingCache59;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache59 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding60(int var0, long var1) {
         MethodHandle var7 = bindingCache60;
         MethodHandle var6 = bindingCache60;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache60 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding61(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache61;
         MethodHandle var8 = bindingCache61;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache61 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding62(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache62;
         MethodHandle var9 = bindingCache62;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache62 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding63(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache63;
         MethodHandle var8 = bindingCache63;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache63 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding64(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache64;
         MethodHandle var8 = bindingCache64;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache64 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding65(int var0, long var1) {
         MethodHandle var7 = bindingCache65;
         MethodHandle var6 = bindingCache65;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache65 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding66(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache66;
         MethodHandle var8 = bindingCache66;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache66 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding67(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache67;
         MethodHandle var9 = bindingCache67;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache67 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;IJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding68(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache68;
         MethodHandle var9 = bindingCache68;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache68 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding69(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache69;
         MethodHandle var8 = bindingCache69;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache69 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding70(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache70;
         MethodHandle var9 = bindingCache70;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache70 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding71(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache71;
         MethodHandle var8 = bindingCache71;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache71 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding72(int var0, long var1) {
         MethodHandle var7 = bindingCache72;
         MethodHandle var6 = bindingCache72;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache72 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding73(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache73;
         MethodHandle var9 = bindingCache73;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache73 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding74(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache74;
         MethodHandle var8 = bindingCache74;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache74 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding75(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache75;
         MethodHandle var8 = bindingCache75;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache75 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding76(int var0, long var1) {
         MethodHandle var7 = bindingCache76;
         MethodHandle var6 = bindingCache76;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache76 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding78(Object var0, int var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache78;
         MethodHandle var10 = bindingCache78;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache78 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;IIJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (int)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding79(int var0, long var1) {
         MethodHandle var7 = bindingCache79;
         MethodHandle var6 = bindingCache79;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache79 = a(MethodHandles.lookup(), "z", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding80(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache80;
         MethodHandle var8 = bindingCache80;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache80 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding81(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache81;
         MethodHandle var8 = bindingCache81;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache81 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding82(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache82;
         MethodHandle var8 = bindingCache82;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache82 = c(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding83(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache83;
         MethodHandle var9 = bindingCache83;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache83 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding84(long var0, long var2) {
         MethodHandle var8 = bindingCache84;
         MethodHandle var7 = bindingCache84;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache84 = c(MethodHandles.lookup(), "µ", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding85(int var0, long var1) {
         MethodHandle var7 = bindingCache85;
         MethodHandle var6 = bindingCache85;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache85 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding86(int var0, long var1) {
         MethodHandle var7 = bindingCache86;
         MethodHandle var6 = bindingCache86;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache86 = b(MethodHandles.lookup(), "a", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding87(Object var0, char var1, char var2, long var3, long var5) {
         MethodHandle var11 = bindingCache87;
         MethodHandle var10 = bindingCache87;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache87 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;CCJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (char)var1, (char)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Class invokeBinding88(Object var0, boolean var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache88;
         MethodHandle var10 = bindingCache88;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache88 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;ZLjava/lang/Object;JJ)Ljava/lang/Class;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Class)var8.invokeExact((Object)var0, (boolean)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static boolean invokeBinding89(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache89;
         MethodHandle var9 = bindingCache89;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache89 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding90(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache90;
         MethodHandle var8 = bindingCache90;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache90 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding91(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache91;
         MethodHandle var9 = bindingCache91;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache91 = c(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding92(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache92;
         MethodHandle var8 = bindingCache92;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache92 = c(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
