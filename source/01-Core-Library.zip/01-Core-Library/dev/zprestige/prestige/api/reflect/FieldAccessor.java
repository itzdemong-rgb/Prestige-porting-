package dev.zprestige.prestige.api.reflect;
import dev.zprestige.prestige.api.reflect.ReflectionUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.VarHandle;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import sun.misc.Unsafe;

public final class FieldAccessor {
   private final boolean a;
   private final long b;
   private final Object c;
   private final boolean d;
   private final boolean e;
   private final VarHandle f;
   private final Field g;
   private final Class h;
   private final String i;
   private final Class j;
   private static final long k = 87264189422038L;
   private static final long[] l;
   private static final Long[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[67];
   private static final String[] p = new String[67];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;
   private static volatile MethodHandle bindingCache93;
   private static volatile MethodHandle bindingCache94;
   private static volatile MethodHandle bindingCache95;
   private static volatile MethodHandle bindingCache96;
   private static volatile MethodHandle bindingCache97;
   private static volatile MethodHandle bindingCache98;
   private static volatile MethodHandle bindingCache99;
   private static volatile MethodHandle bindingCache100;
   private static volatile MethodHandle bindingCache101;
   private static volatile MethodHandle bindingCache102;
   private static volatile MethodHandle bindingCache103;
   private static volatile MethodHandle bindingCache104;
   private static volatile MethodHandle bindingCache105;
   private static volatile MethodHandle bindingCache106;
   private static volatile MethodHandle bindingCache107;
   private static volatile MethodHandle bindingCache108;
   private static volatile MethodHandle bindingCache109;
   private static volatile MethodHandle bindingCache110;
   private static volatile MethodHandle bindingCache111;
   private static volatile MethodHandle bindingCache112;
   private static volatile MethodHandle bindingCache113;
   private static volatile MethodHandle bindingCache114;
   private static volatile MethodHandle bindingCache115;
   private static volatile MethodHandle bindingCache116;
   private static volatile MethodHandle bindingCache117;
   private static volatile MethodHandle bindingCache118;
   private static volatile MethodHandle bindingCache119;
   private static volatile MethodHandle bindingCache120;
   private static volatile MethodHandle bindingCache121;
   private static volatile MethodHandle bindingCache122;
   private static volatile MethodHandle bindingCache123;
   private static volatile MethodHandle bindingCache124;
   private static volatile MethodHandle bindingCache125;
   private static volatile MethodHandle bindingCache126;
   private static volatile MethodHandle bindingCache127;
   private static volatile MethodHandle bindingCache128;
   private static volatile MethodHandle bindingCache129;
   private static volatile MethodHandle bindingCache130;
   private static volatile MethodHandle bindingCache131;
   private static volatile MethodHandle bindingCache132;
   private static volatile MethodHandle bindingCache133;
   private static volatile MethodHandle bindingCache134;

   public FieldAccessor(FieldAccessMetadata var1, long var2) {
      super();
      FieldAccessor var7;
      byte var8;
      label12: {
         var2 = 87264189422038L ^ var2;
         
         this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
         this.b = var1.d;
         this.c = var1.c;
         this.d = var1.b;
         this.f = var1.e;
         this.g = var1.a;
         Unsafe var10 = ReflectionUtil.a;
         FieldAccessor var9 = this;
         FieldAccessor var6 = var9;
         FieldAccessor var4 = var9;
         if (var10 != null) {
            short var10002 = 7885;
            long var10003 = 3814550727055396764L ^ var2;
            long var16;
            int var12 = (var16 = var1.d - -1L) == 0L ? 0 : (var16 < 0L ? -1 : 1);
            FieldAccessor var11 = var4;
            var6 = var11;
            FieldAccessor var5 = var11;
            if (((var12) != 0)) {
               byte var14 = 1;
               FieldAccessor var13 = var5;
               var7 = var13;
               var8 = var14;
               break label12;
            }
         }

         var8 = 0;
         var7 = var6;
      }

      this.e = dev.prestige.recovery.SourceSupport.asBoolean(var8);
      this.h = null;
      this.i = null;
      this.j = null;
   }

   public FieldAccessor(Class var1, String var2, Class var3, long var4) {
      super();
      
      var4 = 87264189422038L ^ var4;

      this.a = dev.prestige.recovery.SourceSupport.asBoolean(0);
      short var10001 = 727;
      long var10002 = 6773701608313495768L ^ var4;
      this.b = -1L;
      this.c = null;
      this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.e = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.f = null;
      this.g = null;
      this.h = var1;
      this.i = var2;
      this.j = var3;
   }

   private Object aReturningObject(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 87264189422038L ^ var3;
      int var5 = Event.bReturningInt();
      int var10 = var5;
      FieldAccessor var9 = this;
      FieldAccessor var7 = var9;
      FieldAccessor var6 = var9;
      Object var8;
      if (var10 == 0) {
         boolean var11 = var6.d;
         if (var11) {
            Object var12 = this.c;
            var8 = var12;
         } else {
            var8 = var2;
         }
      } else {
         FieldAccessor var13 = var7;
         var8 = var13;
      }

      return var8;
   }

   public void aReturningVoid(Object[] var1) {
      Object var2;
      double var3;
      long var11;
      int var13;
      FieldAccessor var44;
      label53: {
         var2 = var1[0];
         var3 = (Double)var1[1];
         long var5 = (Long)var1[2];
         var5 = 87264189422038L ^ var5;
         long var7 = var5 ^ 120316420869268L;
         long var9 = var5 ^ 107418254003518L;
         var11 = var5 ^ 44026041010890L;
         var13 = Event.bReturningInt();
         int var51 = var13;
         boolean var50 = this.a;
         boolean var43 = var50;
         boolean var41 = var50;
         if (var51 == 0) {
            boolean var52 = var41;
            if (!var52) {
               double var15 = var3;
               Object[] var18 = new Object[]{var2, var15, var7};
               FieldAccessor var17 = this;
               var17.gReturningVoid(var18);
               return;
            }

            int var54 = var13;
            FieldAccessor var53 = this;
            var44 = var53;
            FieldAccessor var42 = var53;
            if (var54 != 0) {
               break label53;
            }

            boolean var55 = var42.e;
            var43 = var55;
         }

         boolean var56 = var43;
         if (var56) {
            Unsafe var10000 = ReflectionUtil.a;
            Object[] var22 = new Object[]{var2, var9};
            FieldAccessor var21 = this;
            Object var10001 = var21.aReturningObject(var22);
            double var27 = var3;
            long var25 = this.b;
            Object var24 = var10001;
            Unsafe var23 = var10000;
            var23.putDouble(var24, var25, var27);
            int var57 = var13;
            if (var57 == 0) {
               return;
            }
         }

         FieldAccessor var58 = this;
         var44 = var58;
      }

      int var60 = var13;
      FieldAccessor var59 = var44;
      FieldAccessor var49 = var59;
      FieldAccessor var45 = var59;
      if (var60 == 0) {
         VarHandle var61 = var45.f;
         if (var61 != null) {
            int var63 = var13;
            FieldAccessor var62 = this;
            FieldAccessor var48 = var62;
            FieldAccessor var46 = var62;
            if (var63 == 0) {
               FieldAccessor var64 = var46;
               FieldAccessor var47 = var64;
               boolean var65 = var47.d;
               if (var65) {
                  this.f.set((double)var3);
                  int var66 = var13;
                  if (var66 == 0) {
                     return;
                  }
               }

               FieldAccessor var67 = this;
               var48 = var67;
            }

            var48.f.set((Object)var2, (double)var3);
            int var68 = var13;
            if (var68 == 0) {
               return;
            }
         }

         FieldAccessor var69 = this;
         var49 = var69;
      }

      double var37 = var3;
      Object[] var40 = new Object[]{var2, var37, var11};
      FieldAccessor var39 = var49;
      var39.hReturningVoid(var40);
   }

    public double aReturningDouble(Object[] objectArray) {
        Object object;
        long l;
        block20: {
            long l2;
            Object object2;
            block21: {
                Object object3;
                block24: {
                    FieldAccessor bO_C00852;
                    block22: {
                        block23: {
                            FieldAccessor bO_C00853;
                            int n;
                            block19: {
                                boolean bl;
                                long l3;
                                block17: {
                                    block18: {
                                        object2 = objectArray[0];
                                        l = (Long)objectArray[1];
                                        long l4 = l = 0x4F5DC70319D6L ^ l;
                                        l3 = l4 ^ 0x2E93945FE807L;
                                        long l5 = l4 ^ 0x2CE11C25AE0L;
                                        l2 = l4 ^ 0x2D723413AACEL;
                                        n = FieldAccessor.invokeBinding1(7699432184474145992L, l);
                                        try {
                                            try {
                                                bl = this.a;
                                                if (n == 0) break block17;
                                                if (bl) break block18;
                                            }
                                            catch (RuntimeException runtimeException) {
                                                throw FieldAccessor.invokeBinding2(runtimeException, 7699533215584087020L, l);
                                            }
                                            Object[] objectArray2 = new Object[2];
                                            objectArray2[1] = l5;
                                            objectArray2[0] = object2;
                                            return FieldAccessor.invokeBinding4((Number)FieldAccessor.invokeBinding3(this, objectArray2, 7699884723202878049L, l), 7699211984332599445L, l);
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding5(runtimeException, 7699533215584087020L, l);
                                        }
                                    }
                                    try {
                                        bO_C00853 = this;
                                        if (n == 0) break block19;
                                        bl = bO_C00853.e;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding6(runtimeException, 7699533215584087020L, l);
                                    }
                                }
                                try {
                                    if (bl) {
                                        Object[] objectArray3 = new Object[2];
                                        objectArray3[1] = l3;
                                        objectArray3[0] = object2;
                                        return FieldAccessor.invokeBinding8(ReflectionUtil.a, FieldAccessor.invokeBinding7(this, objectArray3, 7699674371189292579L, l), this.b, 7699066622014675965L, l);
                                    }
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding9(runtimeException, 7699533215584087020L, l);
                                }
                                bO_C00853 = this;
                            }
                            try {
                                try {
                                    try {
                                        try {
                                            object = bO_C00853.f;
                                            if (n == 0) break block20;
                                            if (object == null) break block21;
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding10(runtimeException, 7699533215584087020L, l);
                                        }
                                        bO_C00852 = this;
                                        if (n == 0) break block22;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding11(runtimeException, 7699533215584087020L, l);
                                    }
                                    if (!bO_C00852.d) break block23;
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding12(runtimeException, 7699533215584087020L, l);
                                }
                                object3 = this.f.get();
                                break block24;
                            }
                            catch (RuntimeException runtimeException) {
                                throw FieldAccessor.invokeBinding13(runtimeException, 7699533215584087020L, l);
                            }
                        }
                        bO_C00852 = this;
                    }
                    object3 = bO_C00852.f.get(object2);
                }
                return FieldAccessor.invokeBinding14((Double)object3, 7700368292443366177L, l);
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l2;
            objectArray4[0] = object2;
            object = FieldAccessor.invokeBinding15(this, objectArray4, 7700720741513800565L, l);
        }
        return FieldAccessor.invokeBinding16((Number)object, 7699211984332599445L, l);
    }

   public void bReturningVoid(Object[] var1) {
      Object var4;
      float var5;
      long var10;
      int var12;
      FieldAccessor var40;
      label53: {
         var4 = var1[0];
         var5 = (Float)var1[1];
         long var2 = (Long)var1[2];
         var2 = 87264189422038L ^ var2;
         long var6 = var2 ^ 51823790544651L;
         long var8 = var2 ^ 39570372155041L;
         var10 = var2 ^ 116848606548309L;
         var12 = Event.cReturningInt();
         int var47 = var12;
         boolean var46 = this.a;
         boolean var39 = var46;
         boolean var37 = var46;
         if (var47 != 0) {
            boolean var48 = var37;
            if (!var48) {
               float var14 = var5;
               Object[] var16 = new Object[]{var4, var14, var6};
               FieldAccessor var15 = this;
               var15.gReturningVoid(var16);
               return;
            }

            int var50 = var12;
            FieldAccessor var49 = this;
            var40 = var49;
            FieldAccessor var38 = var49;
            if (var50 == 0) {
               break label53;
            }

            boolean var51 = var38.e;
            var39 = var51;
         }

         boolean var52 = var39;
         if (var52) {
            Unsafe var10000 = ReflectionUtil.a;
            Object[] var20 = new Object[]{var4, var8};
            FieldAccessor var19 = this;
            Object var10001 = var19.aReturningObject(var20);
            float var25 = var5;
            long var23 = this.b;
            Object var22 = var10001;
            Unsafe var21 = var10000;
            var21.putFloat(var22, var23, var25);
            int var53 = var12;
            if (var53 != 0) {
               return;
            }
         }

         FieldAccessor var54 = this;
         var40 = var54;
      }

      int var56 = var12;
      FieldAccessor var55 = var40;
      FieldAccessor var45 = var55;
      FieldAccessor var41 = var55;
      if (var56 != 0) {
         VarHandle var57 = var41.f;
         if (var57 != null) {
            int var59 = var12;
            FieldAccessor var58 = this;
            FieldAccessor var44 = var58;
            FieldAccessor var42 = var58;
            if (var59 != 0) {
               FieldAccessor var60 = var42;
               FieldAccessor var43 = var60;
               boolean var61 = var43.d;
               if (var61) {
                  this.f.set((float)var5);
                  int var62 = var12;
                  if (var62 != 0) {
                     return;
                  }
               }

               FieldAccessor var63 = this;
               var44 = var63;
            }

            var44.f.set((Object)var4, (float)var5);
            int var64 = var12;
            if (var64 != 0) {
               return;
            }
         }

         FieldAccessor var65 = this;
         var45 = var65;
      }

      float var34 = var5;
      Object[] var36 = new Object[]{var4, var34, var10};
      FieldAccessor var35 = var45;
      var35.hReturningVoid(var36);
   }

    public float aReturningFloat(Object[] objectArray) {
        Object object;
        long l;
        block20: {
            long l2;
            Object object2;
            block21: {
                Object object3;
                block24: {
                    FieldAccessor bO_C00852;
                    block22: {
                        block23: {
                            FieldAccessor bO_C00853;
                            int n;
                            block19: {
                                boolean bl;
                                long l3;
                                block17: {
                                    block18: {
                                        object2 = objectArray[0];
                                        l = (Long)objectArray[1];
                                        long l4 = l = 0x4F5DC70319D6L ^ l;
                                        l3 = l4 ^ 0x3C268E9E2BAL;
                                        long l5 = l4 ^ 0x2F9FED74505DL;
                                        l2 = l4 ^ 0x23C8A5A073L;
                                        n = FieldAccessor.invokeBinding17(6947741799274265778L, l);
                                        try {
                                            try {
                                                bl = this.a;
                                                if (n != 0) break block17;
                                                if (bl) break block18;
                                            }
                                            catch (RuntimeException runtimeException) {
                                                throw FieldAccessor.invokeBinding18(runtimeException, 6946540722518745425L, l);
                                            }
                                            Object[] objectArray2 = new Object[2];
                                            objectArray2[1] = l5;
                                            objectArray2[0] = object2;
                                            return FieldAccessor.invokeBinding20((Number)FieldAccessor.invokeBinding19(this, objectArray2, 6946328595119792348L, l), 6945013429864621712L, l);
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding21(runtimeException, 6946540722518745425L, l);
                                        }
                                    }
                                    try {
                                        bO_C00853 = this;
                                        if (n != 0) break block19;
                                        bl = bO_C00853.e;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding22(runtimeException, 6946540722518745425L, l);
                                    }
                                }
                                try {
                                    if (bl) {
                                        Object[] objectArray3 = new Object[2];
                                        objectArray3[1] = l3;
                                        objectArray3[0] = object2;
                                        return FieldAccessor.invokeBinding24(ReflectionUtil.a, FieldAccessor.invokeBinding23(this, objectArray3, 6946679667409335454L, l), this.b, 6945390021430387270L, l);
                                    }
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding25(runtimeException, 6946540722518745425L, l);
                                }
                                bO_C00853 = this;
                            }
                            try {
                                try {
                                    try {
                                        try {
                                            object = bO_C00853.f;
                                            if (n != 0) break block20;
                                            if (object == null) break block21;
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding26(runtimeException, 6946540722518745425L, l);
                                        }
                                        bO_C00852 = this;
                                        if (n != 0) break block22;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding27(runtimeException, 6946540722518745425L, l);
                                    }
                                    if (!bO_C00852.d) break block23;
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding28(runtimeException, 6946540722518745425L, l);
                                }
                                object3 = this.f.get();
                                break block24;
                            }
                            catch (RuntimeException runtimeException) {
                                throw FieldAccessor.invokeBinding29(runtimeException, 6946540722518745425L, l);
                            }
                        }
                        bO_C00852 = this;
                    }
                    object3 = bO_C00852.f.get(object2);
                }
                return FieldAccessor.invokeBinding30((Float)object3, 6945318539449149334L, l);
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l2;
            objectArray4[0] = object2;
            object = FieldAccessor.invokeBinding31(this, objectArray4, 6945493899626389960L, l);
        }
        return FieldAccessor.invokeBinding32((Number)object, 6945013429864621712L, l);
    }

   public void cReturningVoid(Object[] param1) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[13];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Object)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.Integer)recoveryStack[1]); }
                  recoveryAt=10; { recoveryStack[1]=((java.lang.Integer)recoveryStack[1]).intValue(); }
                  recoveryAt=11; { recoveryLocals[5]=recoveryStack[1];  }
                  recoveryAt=12; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=13; { recoveryStack[2]=2; }
                  recoveryAt=14; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=16; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=17; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=19; { recoveryStack[0]=87264189422038L; }
                  recoveryAt=20; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=21; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=22; { recoveryLocals[3]=recoveryStack[0];  }
                  recoveryAt=23; { recoveryStack[0]=recoveryLocals[3];  }
                  recoveryAt=24; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=25; { recoveryStack[2]=48240243889690L; }
                  recoveryAt=26; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=27; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=28; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=29; { recoveryStack[2]=42884539635632L; }
                  recoveryAt=30; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=31; { recoveryLocals[8]=recoveryStack[1];  }
                  recoveryAt=32; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=33; { recoveryStack[2]=121736747421764L; }
                  recoveryAt=34; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=35; { recoveryLocals[10]=recoveryStack[1];  }
                  recoveryAt=37; { recoveryStack[0]=-3067257749099959425L; }
                  recoveryAt=38; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=39; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding33(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=40; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=43; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=44; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).a; }
                  recoveryAt=45; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=46; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=112; continue recoveryFlow;} recoveryPc=48; continue recoveryFlow; }
               }
               case 48 -> {
                  recoveryAt=48; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=98; continue recoveryFlow;} recoveryPc=50; continue recoveryFlow; }
               }
               case 50 -> {
                  recoveryAt=50; { recoveryPc=59; continue recoveryFlow; }
               }
               case 53 -> {
                  recoveryAt=53; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=54; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=55; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding34(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=56; { throw (Throwable)recoveryStack[0]; }
               }
               case 59 -> {
                  recoveryAt=59; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=60; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=61; { recoveryStack[2]=recoveryLocals[5];  }
                  recoveryAt=62; { recoveryStack[3]=-3068527824137583054L; }
                  recoveryAt=63; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=64; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding35(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=65; { recoveryStack[3]=recoveryLocals[6];  }
                  recoveryAt=66; { recoveryStack[4]=3; }
                  recoveryAt=67; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=68; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=69; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=71; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=72; { recoveryStack[6]=2; }
                  recoveryAt=73; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=74; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=75; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=76; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=77; { recoveryStack[5]=1; }
                  recoveryAt=78; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=79; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=80; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=81; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=82; { recoveryStack[4]=0; }
                  recoveryAt=83; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=84; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=85; { recoveryStack[2]=-3068301926678813173L; }
                  recoveryAt=86; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=87; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding36(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=88; { return; }
               }
               case 91 -> {
                  recoveryAt=91; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=92; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=93; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding37(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=94; { throw (Throwable)recoveryStack[0]; }
               }
               case 98 -> {
                  recoveryAt=98; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=99; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=100; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=165; continue recoveryFlow;} recoveryPc=101; continue recoveryFlow; }
               }
               case 101 -> {
                  recoveryAt=101; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).e; }
                  recoveryAt=103; { recoveryPc=112; continue recoveryFlow; }
               }
               case 106 -> {
                  recoveryAt=106; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=107; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=108; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding38(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=109; { throw (Throwable)recoveryStack[0]; }
               }
               case 112 -> {
                  recoveryAt=112; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=154; continue recoveryFlow;} recoveryPc=114; continue recoveryFlow; }
               }
               case 114 -> {
                  recoveryAt=114; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.a; }
                  recoveryAt=115; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=116; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=117; { recoveryStack[3]=recoveryLocals[8];  }
                  recoveryAt=118; { recoveryStack[4]=2; }
                  recoveryAt=119; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=120; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=121; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=123; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=124; { recoveryStack[6]=1; }
                  recoveryAt=125; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=126; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=127; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=128; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=129; { recoveryStack[5]=0; }
                  recoveryAt=130; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=131; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=132; { recoveryStack[3]=-3067597204002373228L; }
                  recoveryAt=133; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=134; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding39(((java.lang.Object)recoveryStack[1]),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=135; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=136; { recoveryStack[2]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[2]).b; }
                  recoveryAt=137; { recoveryStack[3]=recoveryLocals[5];  }
                  recoveryAt=138; { recoveryStack[4]=-3070896762186583045L; }
                  recoveryAt=139; { recoveryStack[5]=recoveryLocals[3];  }
                  recoveryAt=140; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding40(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=141; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=142; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=283; continue recoveryFlow;} recoveryPc=144; continue recoveryFlow; }
               }
               case 144 -> {
                  recoveryAt=144; { recoveryPc=154; continue recoveryFlow; }
               }
               case 147 -> {
                  recoveryAt=147; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=148; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=149; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding41(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=150; { throw (Throwable)recoveryStack[0]; }
               }
               case 154 -> {
                  recoveryAt=154; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=156; { recoveryPc=165; continue recoveryFlow; }
               }
               case 159 -> {
                  recoveryAt=159; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=160; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=161; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding42(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=162; { throw (Throwable)recoveryStack[0]; }
               }
               case 165 -> {
                  recoveryAt=165; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=166; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=252; continue recoveryFlow;} recoveryPc=168; continue recoveryFlow; }
               }
               case 168 -> {
                  recoveryAt=168; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=169; { if(recoveryStack[0]==null){recoveryPc=241; continue recoveryFlow;} recoveryPc=171; continue recoveryFlow; }
               }
               case 171 -> {
                  recoveryAt=171; { recoveryPc=180; continue recoveryFlow; }
               }
               case 174 -> {
                  recoveryAt=174; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=175; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=176; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding43(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=177; { throw (Throwable)recoveryStack[0]; }
               }
               case 180 -> {
                  recoveryAt=180; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=181; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=182; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=232; continue recoveryFlow;} recoveryPc=184; continue recoveryFlow; }
               }
               case 184 -> {
                  recoveryAt=184; { recoveryPc=193; continue recoveryFlow; }
               }
               case 187 -> {
                  recoveryAt=187; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=188; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=189; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding44(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=190; { throw (Throwable)recoveryStack[0]; }
               }
               case 193 -> {
                  recoveryAt=193; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).d; }
                  recoveryAt=194; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=221; continue recoveryFlow;} recoveryPc=196; continue recoveryFlow; }
               }
               case 196 -> {
                  recoveryAt=196; { recoveryPc=205; continue recoveryFlow; }
               }
               case 199 -> {
                  recoveryAt=199; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=200; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=201; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding45(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=202; { throw (Throwable)recoveryStack[0]; }
               }
               case 205 -> {
                  recoveryAt=205; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=206; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=207; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=208; { ((java.lang.invoke.VarHandle)recoveryStack[0]).set(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])); }
                  recoveryAt=209; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=210; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=283; continue recoveryFlow;} recoveryPc=212; continue recoveryFlow; }
               }
               case 212 -> {
                  recoveryAt=212; { recoveryPc=221; continue recoveryFlow; }
               }
               case 215 -> {
                  recoveryAt=215; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=216; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=217; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding46(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=218; { throw (Throwable)recoveryStack[0]; }
               }
               case 221 -> {
                  recoveryAt=221; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=223; { recoveryPc=232; continue recoveryFlow; }
               }
               case 226 -> {
                  recoveryAt=226; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=227; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=228; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding47(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=229; { throw (Throwable)recoveryStack[0]; }
               }
               case 232 -> {
                  recoveryAt=232; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=233; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=234; { recoveryStack[2]=recoveryLocals[5];  }
                  recoveryAt=235; { ((java.lang.invoke.VarHandle)recoveryStack[0]).set(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])); }
                  recoveryAt=236; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=237; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=283; continue recoveryFlow;} recoveryPc=241; continue recoveryFlow; }
               }
               case 241 -> {
                  recoveryAt=241; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=243; { recoveryPc=252; continue recoveryFlow; }
               }
               case 246 -> {
                  recoveryAt=246; { recoveryStack[1]=-3067737251524225957L; }
                  recoveryAt=247; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=248; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding48(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=249; { throw (Throwable)recoveryStack[0]; }
               }
               case 252 -> {
                  recoveryAt=252; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=253; { recoveryStack[2]=recoveryLocals[5];  }
                  recoveryAt=254; { recoveryStack[3]=-3068527824137583054L; }
                  recoveryAt=255; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=256; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding49(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=257; { recoveryStack[3]=recoveryLocals[10];  }
                  recoveryAt=258; { recoveryStack[4]=3; }
                  recoveryAt=259; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=260; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=261; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=263; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=264; { recoveryStack[6]=2; }
                  recoveryAt=265; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=266; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=267; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=268; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=269; { recoveryStack[5]=1; }
                  recoveryAt=270; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=271; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=272; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=273; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=274; { recoveryStack[4]=0; }
                  recoveryAt=275; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=276; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=277; { recoveryStack[2]=-3068065524993641435L; }
                  recoveryAt=278; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=279; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding50(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=283; continue recoveryFlow;
               }
               case 283 -> {
                  recoveryAt=283; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=41 && recoveryAt<49 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=53; continue recoveryFlow;}
            if(recoveryAt>=47 && recoveryAt<89 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=91; continue recoveryFlow;}
            if(recoveryAt>=95 && recoveryAt<102 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=106; continue recoveryFlow;}
            if(recoveryAt>=110 && recoveryAt<143 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=147; continue recoveryFlow;}
            if(recoveryAt>=113 && recoveryAt<155 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=159; continue recoveryFlow;}
            if(recoveryAt>=163 && recoveryAt<170 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=174; continue recoveryFlow;}
            if(recoveryAt>=167 && recoveryAt<183 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=187; continue recoveryFlow;}
            if(recoveryAt>=178 && recoveryAt<195 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=199; continue recoveryFlow;}
            if(recoveryAt>=191 && recoveryAt<211 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=215; continue recoveryFlow;}
            if(recoveryAt>=203 && recoveryAt<222 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=226; continue recoveryFlow;}
            if(recoveryAt>=230 && recoveryAt<242 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=246; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

    public int aReturningInt(Object[] objectArray) {
        Object object;
        long l;
        block20: {
            long l2;
            Object object2;
            block21: {
                Object object3;
                block24: {
                    FieldAccessor bO_C00852;
                    block22: {
                        block23: {
                            FieldAccessor bO_C00853;
                            int n;
                            block19: {
                                boolean bl;
                                long l3;
                                block17: {
                                    block18: {
                                        object2 = objectArray[0];
                                        l = (Long)objectArray[1];
                                        long l4 = l = 0x4F5DC70319D6L ^ l;
                                        l3 = l4 ^ 0x5732C636EA75L;
                                        long l5 = l4 ^ 0x7B6F43AB5892L;
                                        l2 = l4 ^ 0x54D3667AA8BCL;
                                        n = FieldAccessor.invokeBinding51(7542290664690783930L, l);
                                        try {
                                            try {
                                                bl = this.a;
                                                if (n == 0) break block17;
                                                if (bl) break block18;
                                            }
                                            catch (RuntimeException runtimeException) {
                                                throw FieldAccessor.invokeBinding52(runtimeException, 7541353490541242782L, l);
                                            }
                                            Object[] objectArray2 = new Object[2];
                                            objectArray2[1] = l5;
                                            objectArray2[0] = object2;
                                            return FieldAccessor.invokeBinding54((Number)FieldAccessor.invokeBinding53(this, objectArray2, 7541565637267548179L, l), 7541920457186823262L, l);
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding55(runtimeException, 7541353490541242782L, l);
                                        }
                                    }
                                    try {
                                        bO_C00853 = this;
                                        if (n == 0) break block19;
                                        bl = bO_C00853.e;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding56(runtimeException, 7541353490541242782L, l);
                                    }
                                }
                                try {
                                    if (bl) {
                                        Object[] objectArray3 = new Object[2];
                                        objectArray3[1] = l3;
                                        objectArray3[0] = object2;
                                        return FieldAccessor.invokeBinding58(ReflectionUtil.a, FieldAccessor.invokeBinding57(this, objectArray3, 7541493812980595793L, l), this.b, 7540428381872413876L, l);
                                    }
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding59(runtimeException, 7541353490541242782L, l);
                                }
                                bO_C00853 = this;
                            }
                            try {
                                try {
                                    try {
                                        try {
                                            object = bO_C00853.f;
                                            if (n == 0) break block20;
                                            if (object == null) break block21;
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding60(runtimeException, 7541353490541242782L, l);
                                        }
                                        bO_C00852 = this;
                                        if (n == 0) break block22;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding61(runtimeException, 7541353490541242782L, l);
                                    }
                                    if (!bO_C00852.d) break block23;
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding62(runtimeException, 7541353490541242782L, l);
                                }
                                object3 = this.f.get();
                                break block24;
                            }
                            catch (RuntimeException runtimeException) {
                                throw FieldAccessor.invokeBinding63(runtimeException, 7541353490541242782L, l);
                            }
                        }
                        bO_C00852 = this;
                    }
                    object3 = bO_C00852.f.get(object2);
                }
                return FieldAccessor.invokeBinding64((Integer)object3, 7542041427050944557L, l);
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l2;
            objectArray4[0] = object2;
            object = FieldAccessor.invokeBinding65(this, objectArray4, 7542417870689446151L, l);
        }
        return FieldAccessor.invokeBinding66((Number)object, 7541920457186823262L, l);
    }

   public void dReturningVoid(Object[] param1) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[14];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Object)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=10; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=11; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=12; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=13; { recoveryStack[2]=2; }
                  recoveryAt=14; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=16; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=17; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=19; { recoveryStack[0]=87264189422038L; }
                  recoveryAt=20; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=21; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=22; { recoveryLocals[4]=recoveryStack[0];  }
                  recoveryAt=23; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=24; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=25; { recoveryStack[2]=53259622780304L; }
                  recoveryAt=26; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=27; { recoveryLocals[7]=recoveryStack[1];  }
                  recoveryAt=28; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=29; { recoveryStack[2]=66723990211642L; }
                  recoveryAt=30; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=31; { recoveryLocals[9]=recoveryStack[1];  }
                  recoveryAt=32; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=33; { recoveryStack[2]=128744830946254L; }
                  recoveryAt=34; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=35; { recoveryLocals[11]=recoveryStack[1];  }
                  recoveryAt=37; { recoveryStack[0]=-8148303419682729422L; }
                  recoveryAt=38; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=39; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding67(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=40; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=43; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=44; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).a; }
                  recoveryAt=45; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=46; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=112; continue recoveryFlow;} recoveryPc=48; continue recoveryFlow; }
               }
               case 48 -> {
                  recoveryAt=48; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=98; continue recoveryFlow;} recoveryPc=50; continue recoveryFlow; }
               }
               case 50 -> {
                  recoveryAt=50; { recoveryPc=59; continue recoveryFlow; }
               }
               case 53 -> {
                  recoveryAt=53; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=54; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=55; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding68(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=56; { throw (Throwable)recoveryStack[0]; }
               }
               case 59 -> {
                  recoveryAt=59; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=60; { recoveryStack[1]=recoveryLocals[6];  }
                  recoveryAt=61; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=62; { recoveryStack[3]=-8150303705067785528L; }
                  recoveryAt=63; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=64; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding69(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=65; { recoveryStack[3]=recoveryLocals[7];  }
                  recoveryAt=66; { recoveryStack[4]=3; }
                  recoveryAt=67; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=68; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=69; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=71; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=72; { recoveryStack[6]=2; }
                  recoveryAt=73; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=74; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=75; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=76; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=77; { recoveryStack[5]=1; }
                  recoveryAt=78; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=79; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=80; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=81; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=82; { recoveryStack[4]=0; }
                  recoveryAt=83; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=84; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=85; { recoveryStack[2]=-8151189832336015999L; }
                  recoveryAt=86; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=87; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding70(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=88; { return; }
               }
               case 91 -> {
                  recoveryAt=91; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=92; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=93; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding71(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=94; { throw (Throwable)recoveryStack[0]; }
               }
               case 98 -> {
                  recoveryAt=98; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=99; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=100; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=165; continue recoveryFlow;} recoveryPc=101; continue recoveryFlow; }
               }
               case 101 -> {
                  recoveryAt=101; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).e; }
                  recoveryAt=103; { recoveryPc=112; continue recoveryFlow; }
               }
               case 106 -> {
                  recoveryAt=106; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=107; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=108; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding72(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=109; { throw (Throwable)recoveryStack[0]; }
               }
               case 112 -> {
                  recoveryAt=112; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=154; continue recoveryFlow;} recoveryPc=114; continue recoveryFlow; }
               }
               case 114 -> {
                  recoveryAt=114; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.a; }
                  recoveryAt=115; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=116; { recoveryStack[2]=recoveryLocals[6];  }
                  recoveryAt=117; { recoveryStack[3]=recoveryLocals[9];  }
                  recoveryAt=118; { recoveryStack[4]=2; }
                  recoveryAt=119; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=120; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=121; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=123; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=124; { recoveryStack[6]=1; }
                  recoveryAt=125; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=126; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=127; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=128; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=129; { recoveryStack[5]=0; }
                  recoveryAt=130; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=131; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=132; { recoveryStack[3]=-8149352349089310178L; }
                  recoveryAt=133; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=134; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding73(((java.lang.Object)recoveryStack[1]),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=135; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=136; { recoveryStack[2]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[2]).b; }
                  recoveryAt=137; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=138; { recoveryStack[4]=-8149320959316567046L; }
                  recoveryAt=139; { recoveryStack[5]=recoveryLocals[4];  }
                  recoveryAt=140; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding74(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=141; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=142; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=283; continue recoveryFlow;} recoveryPc=144; continue recoveryFlow; }
               }
               case 144 -> {
                  recoveryAt=144; { recoveryPc=154; continue recoveryFlow; }
               }
               case 147 -> {
                  recoveryAt=147; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=148; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=149; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding75(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=150; { throw (Throwable)recoveryStack[0]; }
               }
               case 154 -> {
                  recoveryAt=154; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=156; { recoveryPc=165; continue recoveryFlow; }
               }
               case 159 -> {
                  recoveryAt=159; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=160; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=161; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding76(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=162; { throw (Throwable)recoveryStack[0]; }
               }
               case 165 -> {
                  recoveryAt=165; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=166; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=252; continue recoveryFlow;} recoveryPc=168; continue recoveryFlow; }
               }
               case 168 -> {
                  recoveryAt=168; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=169; { if(recoveryStack[0]==null){recoveryPc=241; continue recoveryFlow;} recoveryPc=171; continue recoveryFlow; }
               }
               case 171 -> {
                  recoveryAt=171; { recoveryPc=180; continue recoveryFlow; }
               }
               case 174 -> {
                  recoveryAt=174; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=175; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=176; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding77(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=177; { throw (Throwable)recoveryStack[0]; }
               }
               case 180 -> {
                  recoveryAt=180; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=181; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=182; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=232; continue recoveryFlow;} recoveryPc=184; continue recoveryFlow; }
               }
               case 184 -> {
                  recoveryAt=184; { recoveryPc=193; continue recoveryFlow; }
               }
               case 187 -> {
                  recoveryAt=187; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=188; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=189; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding78(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=190; { throw (Throwable)recoveryStack[0]; }
               }
               case 193 -> {
                  recoveryAt=193; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).d; }
                  recoveryAt=194; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=221; continue recoveryFlow;} recoveryPc=196; continue recoveryFlow; }
               }
               case 196 -> {
                  recoveryAt=196; { recoveryPc=205; continue recoveryFlow; }
               }
               case 199 -> {
                  recoveryAt=199; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=200; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=201; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding79(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=202; { throw (Throwable)recoveryStack[0]; }
               }
               case 205 -> {
                  recoveryAt=205; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=206; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=207; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=208; { ((java.lang.invoke.VarHandle)recoveryStack[0]).set(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=209; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=210; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=283; continue recoveryFlow;} recoveryPc=212; continue recoveryFlow; }
               }
               case 212 -> {
                  recoveryAt=212; { recoveryPc=221; continue recoveryFlow; }
               }
               case 215 -> {
                  recoveryAt=215; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=216; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=217; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding80(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=218; { throw (Throwable)recoveryStack[0]; }
               }
               case 221 -> {
                  recoveryAt=221; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=223; { recoveryPc=232; continue recoveryFlow; }
               }
               case 226 -> {
                  recoveryAt=226; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=227; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=228; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding81(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=229; { throw (Throwable)recoveryStack[0]; }
               }
               case 232 -> {
                  recoveryAt=232; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=233; { recoveryStack[1]=recoveryLocals[6];  }
                  recoveryAt=234; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=235; { ((java.lang.invoke.VarHandle)recoveryStack[0]).set(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=236; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=237; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=283; continue recoveryFlow;} recoveryPc=241; continue recoveryFlow; }
               }
               case 241 -> {
                  recoveryAt=241; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=243; { recoveryPc=252; continue recoveryFlow; }
               }
               case 246 -> {
                  recoveryAt=246; { recoveryStack[1]=-8149493776292376623L; }
                  recoveryAt=247; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=248; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding82(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=249; { throw (Throwable)recoveryStack[0]; }
               }
               case 252 -> {
                  recoveryAt=252; { recoveryStack[1]=recoveryLocals[6];  }
                  recoveryAt=253; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=254; { recoveryStack[3]=-8150303705067785528L; }
                  recoveryAt=255; { recoveryStack[4]=recoveryLocals[4];  }
                  recoveryAt=256; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding83(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=257; { recoveryStack[3]=recoveryLocals[11];  }
                  recoveryAt=258; { recoveryStack[4]=3; }
                  recoveryAt=259; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=260; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=261; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=263; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=264; { recoveryStack[6]=2; }
                  recoveryAt=265; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=266; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=267; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=268; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=269; { recoveryStack[5]=1; }
                  recoveryAt=270; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=271; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=272; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=273; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=274; { recoveryStack[4]=0; }
                  recoveryAt=275; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=276; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=277; { recoveryStack[2]=-8149807755035807825L; }
                  recoveryAt=278; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=279; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding84(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=283; continue recoveryFlow;
               }
               case 283 -> {
                  recoveryAt=283; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=41 && recoveryAt<49 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=53; continue recoveryFlow;}
            if(recoveryAt>=47 && recoveryAt<89 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=91; continue recoveryFlow;}
            if(recoveryAt>=95 && recoveryAt<102 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=106; continue recoveryFlow;}
            if(recoveryAt>=110 && recoveryAt<143 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=147; continue recoveryFlow;}
            if(recoveryAt>=113 && recoveryAt<155 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=159; continue recoveryFlow;}
            if(recoveryAt>=163 && recoveryAt<170 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=174; continue recoveryFlow;}
            if(recoveryAt>=167 && recoveryAt<183 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=187; continue recoveryFlow;}
            if(recoveryAt>=178 && recoveryAt<195 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=199; continue recoveryFlow;}
            if(recoveryAt>=191 && recoveryAt<211 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=215; continue recoveryFlow;}
            if(recoveryAt>=203 && recoveryAt<222 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=226; continue recoveryFlow;}
            if(recoveryAt>=230 && recoveryAt<242 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=246; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

    public long aReturningLong(Object[] objectArray) {
        Object object;
        long l;
        block20: {
            long l2;
            Object object2;
            block21: {
                Object object3;
                block24: {
                    FieldAccessor bO_C00852;
                    block22: {
                        block23: {
                            FieldAccessor bO_C00853;
                            int n;
                            block19: {
                                boolean bl;
                                long l3;
                                block17: {
                                    block18: {
                                        object2 = objectArray[0];
                                        l = (Long)objectArray[1];
                                        long l4 = l = 0x4F5DC70319D6L ^ l;
                                        l3 = l4 ^ 0x74255D81753AL;
                                        long l5 = l4 ^ 0x5878D81CC7DDL;
                                        l2 = l4 ^ 0x77C4FDCD37F3L;
                                        n = FieldAccessor.invokeBinding85(-584137054773573131L, l);
                                        try {
                                            try {
                                                bl = this.a;
                                                if (n == 0) break block17;
                                                if (bl) break block18;
                                            }
                                            catch (RuntimeException runtimeException) {
                                                throw FieldAccessor.invokeBinding86(runtimeException, -583385353542732079L, l);
                                            }
                                            Object[] objectArray2 = new Object[2];
                                            objectArray2[1] = l5;
                                            objectArray2[0] = object2;
                                            return FieldAccessor.invokeBinding88((Number)FieldAccessor.invokeBinding87(this, objectArray2, -583736311472949412L, l), -584348226344855428L, l);
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding89(runtimeException, -583385353542732079L, l);
                                        }
                                    }
                                    try {
                                        bO_C00853 = this;
                                        if (n == 0) break block19;
                                        bl = bO_C00853.e;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding90(runtimeException, -583385353542732079L, l);
                                    }
                                }
                                try {
                                    if (bl) {
                                        Object[] objectArray3 = new Object[2];
                                        objectArray3[1] = l3;
                                        objectArray3[0] = object2;
                                        return FieldAccessor.invokeBinding92(ReflectionUtil.a, FieldAccessor.invokeBinding91(this, objectArray3, -583242827564834018L, l), this.b, -583545515487673931L, l);
                                    }
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding93(runtimeException, -583385353542732079L, l);
                                }
                                bO_C00853 = this;
                            }
                            try {
                                try {
                                    try {
                                        try {
                                            object = bO_C00853.f;
                                            if (n == 0) break block20;
                                            if (object == null) break block21;
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding94(runtimeException, -583385353542732079L, l);
                                        }
                                        bO_C00852 = this;
                                        if (n == 0) break block22;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding95(runtimeException, -583385353542732079L, l);
                                    }
                                    if (!bO_C00852.d) break block23;
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding96(runtimeException, -583385353542732079L, l);
                                }
                                object3 = this.f.get();
                                break block24;
                            }
                            catch (RuntimeException runtimeException) {
                                throw FieldAccessor.invokeBinding97(runtimeException, -583385353542732079L, l);
                            }
                        }
                        bO_C00852 = this;
                    }
                    object3 = bO_C00852.f.get(object2);
                }
                return FieldAccessor.invokeBinding98((Long)object3, -583997027566222770L, l);
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l2;
            objectArray4[0] = object2;
            object = FieldAccessor.invokeBinding99(this, objectArray4, -584572948795935160L, l);
        }
        return FieldAccessor.invokeBinding100((Number)object, -584348226344855428L, l);
    }

   public void eReturningVoid(Object[] param1) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[13];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Object)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[5]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.Boolean)recoveryStack[1]); }
                  recoveryAt=10; { recoveryStack[1]=((java.lang.Boolean)recoveryStack[1]).booleanValue(); }
                  recoveryAt=11; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=12; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=13; { recoveryStack[2]=2; }
                  recoveryAt=14; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=16; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=17; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=19; { recoveryStack[0]=87264189422038L; }
                  recoveryAt=20; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=21; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=22; { recoveryLocals[3]=recoveryStack[0];  }
                  recoveryAt=23; { recoveryStack[0]=recoveryLocals[3];  }
                  recoveryAt=24; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=25; { recoveryStack[2]=90610826633117L; }
                  recoveryAt=26; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=27; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=28; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=29; { recoveryStack[2]=104143855017527L; }
                  recoveryAt=30; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=31; { recoveryLocals[8]=recoveryStack[1];  }
                  recoveryAt=32; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=33; { recoveryStack[2]=25354251901379L; }
                  recoveryAt=34; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=35; { recoveryLocals[10]=recoveryStack[1];  }
                  recoveryAt=37; { recoveryStack[0]=6694050190903607359L; }
                  recoveryAt=38; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=39; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding101(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=40; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=43; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=44; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).a; }
                  recoveryAt=45; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=46; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=112; continue recoveryFlow;} recoveryPc=48; continue recoveryFlow; }
               }
               case 48 -> {
                  recoveryAt=48; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=98; continue recoveryFlow;} recoveryPc=50; continue recoveryFlow; }
               }
               case 50 -> {
                  recoveryAt=50; { recoveryPc=59; continue recoveryFlow; }
               }
               case 53 -> {
                  recoveryAt=53; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=54; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=55; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding102(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=56; { throw (Throwable)recoveryStack[0]; }
               }
               case 59 -> {
                  recoveryAt=59; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=60; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=61; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=62; { recoveryStack[3]=6694108558994610464L; }
                  recoveryAt=63; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=64; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding103(((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]) & 1) != 0),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=65; { recoveryStack[3]=recoveryLocals[6];  }
                  recoveryAt=66; { recoveryStack[4]=3; }
                  recoveryAt=67; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=68; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=69; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=71; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=72; { recoveryStack[6]=2; }
                  recoveryAt=73; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=74; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=75; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=76; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=77; { recoveryStack[5]=1; }
                  recoveryAt=78; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=79; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=80; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=81; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=82; { recoveryStack[4]=0; }
                  recoveryAt=83; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=84; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=85; { recoveryStack[2]=6695808179782168460L; }
                  recoveryAt=86; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=87; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding104(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=88; { return; }
               }
               case 91 -> {
                  recoveryAt=91; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=92; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=93; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding105(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=94; { throw (Throwable)recoveryStack[0]; }
               }
               case 98 -> {
                  recoveryAt=98; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=99; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=100; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=165; continue recoveryFlow;} recoveryPc=101; continue recoveryFlow; }
               }
               case 101 -> {
                  recoveryAt=101; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).e; }
                  recoveryAt=103; { recoveryPc=112; continue recoveryFlow; }
               }
               case 106 -> {
                  recoveryAt=106; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=107; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=108; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding106(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=109; { throw (Throwable)recoveryStack[0]; }
               }
               case 112 -> {
                  recoveryAt=112; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=154; continue recoveryFlow;} recoveryPc=114; continue recoveryFlow; }
               }
               case 114 -> {
                  recoveryAt=114; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.a; }
                  recoveryAt=115; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=116; { recoveryStack[2]=recoveryLocals[5];  }
                  recoveryAt=117; { recoveryStack[3]=recoveryLocals[8];  }
                  recoveryAt=118; { recoveryStack[4]=2; }
                  recoveryAt=119; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=120; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=121; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=123; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=124; { recoveryStack[6]=1; }
                  recoveryAt=125; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=126; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=127; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=128; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=129; { recoveryStack[5]=0; }
                  recoveryAt=130; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=131; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=132; { recoveryStack[3]=6695389400769923091L; }
                  recoveryAt=133; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=134; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding107(((java.lang.Object)recoveryStack[1]),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=135; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=136; { recoveryStack[2]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[2]).b; }
                  recoveryAt=137; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=138; { recoveryStack[4]=6696699103468612150L; }
                  recoveryAt=139; { recoveryStack[5]=recoveryLocals[3];  }
                  recoveryAt=140; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding108(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]) & 1) != 0),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=141; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=142; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=283; continue recoveryFlow;} recoveryPc=144; continue recoveryFlow; }
               }
               case 144 -> {
                  recoveryAt=144; { recoveryPc=154; continue recoveryFlow; }
               }
               case 147 -> {
                  recoveryAt=147; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=148; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=149; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding109(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=150; { throw (Throwable)recoveryStack[0]; }
               }
               case 154 -> {
                  recoveryAt=154; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=156; { recoveryPc=165; continue recoveryFlow; }
               }
               case 159 -> {
                  recoveryAt=159; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=160; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=161; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding110(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=162; { throw (Throwable)recoveryStack[0]; }
               }
               case 165 -> {
                  recoveryAt=165; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=166; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=252; continue recoveryFlow;} recoveryPc=168; continue recoveryFlow; }
               }
               case 168 -> {
                  recoveryAt=168; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=169; { if(recoveryStack[0]==null){recoveryPc=241; continue recoveryFlow;} recoveryPc=171; continue recoveryFlow; }
               }
               case 171 -> {
                  recoveryAt=171; { recoveryPc=180; continue recoveryFlow; }
               }
               case 174 -> {
                  recoveryAt=174; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=175; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=176; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding111(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=177; { throw (Throwable)recoveryStack[0]; }
               }
               case 180 -> {
                  recoveryAt=180; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=181; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=182; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=232; continue recoveryFlow;} recoveryPc=184; continue recoveryFlow; }
               }
               case 184 -> {
                  recoveryAt=184; { recoveryPc=193; continue recoveryFlow; }
               }
               case 187 -> {
                  recoveryAt=187; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=188; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=189; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding112(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=190; { throw (Throwable)recoveryStack[0]; }
               }
               case 193 -> {
                  recoveryAt=193; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).d; }
                  recoveryAt=194; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=221; continue recoveryFlow;} recoveryPc=196; continue recoveryFlow; }
               }
               case 196 -> {
                  recoveryAt=196; { recoveryPc=205; continue recoveryFlow; }
               }
               case 199 -> {
                  recoveryAt=199; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=200; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=201; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding113(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=202; { throw (Throwable)recoveryStack[0]; }
               }
               case 205 -> {
                  recoveryAt=205; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=206; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=207; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=208; { ((java.lang.invoke.VarHandle)recoveryStack[0]).set(((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]) & 1) != 0)); }
                  recoveryAt=209; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=210; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=283; continue recoveryFlow;} recoveryPc=212; continue recoveryFlow; }
               }
               case 212 -> {
                  recoveryAt=212; { recoveryPc=221; continue recoveryFlow; }
               }
               case 215 -> {
                  recoveryAt=215; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=216; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=217; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding114(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=218; { throw (Throwable)recoveryStack[0]; }
               }
               case 221 -> {
                  recoveryAt=221; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=223; { recoveryPc=232; continue recoveryFlow; }
               }
               case 226 -> {
                  recoveryAt=226; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=227; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=228; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding115(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=229; { throw (Throwable)recoveryStack[0]; }
               }
               case 232 -> {
                  recoveryAt=232; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.FieldAccessor)recoveryStack[0]).f; }
                  recoveryAt=233; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=234; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=235; { ((java.lang.invoke.VarHandle)recoveryStack[0]).set(((java.lang.Object)recoveryStack[1]),((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]) & 1) != 0)); }
                  recoveryAt=236; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=237; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=283; continue recoveryFlow;} recoveryPc=241; continue recoveryFlow; }
               }
               case 241 -> {
                  recoveryAt=241; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=243; { recoveryPc=252; continue recoveryFlow; }
               }
               case 246 -> {
                  recoveryAt=246; { recoveryStack[1]=6695247969313218012L; }
                  recoveryAt=247; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=248; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding116(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=249; { throw (Throwable)recoveryStack[0]; }
               }
               case 252 -> {
                  recoveryAt=252; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=253; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=254; { recoveryStack[3]=6694108558994610464L; }
                  recoveryAt=255; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=256; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding117(((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]) & 1) != 0),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=257; { recoveryStack[3]=recoveryLocals[10];  }
                  recoveryAt=258; { recoveryStack[4]=3; }
                  recoveryAt=259; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=260; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=261; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=263; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=264; { recoveryStack[6]=2; }
                  recoveryAt=265; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=266; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=267; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=268; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=269; { recoveryStack[5]=1; }
                  recoveryAt=270; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=271; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=272; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=273; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=274; { recoveryStack[4]=0; }
                  recoveryAt=275; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=276; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=277; { recoveryStack[2]=6695571844769660322L; }
                  recoveryAt=278; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=279; { dev.zprestige.prestige.api.reflect.FieldAccessor.invokeBinding118(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=283; continue recoveryFlow;
               }
               case 283 -> {
                  recoveryAt=283; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=41 && recoveryAt<49 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=53; continue recoveryFlow;}
            if(recoveryAt>=47 && recoveryAt<89 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=91; continue recoveryFlow;}
            if(recoveryAt>=95 && recoveryAt<102 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=106; continue recoveryFlow;}
            if(recoveryAt>=110 && recoveryAt<143 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=147; continue recoveryFlow;}
            if(recoveryAt>=113 && recoveryAt<155 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=159; continue recoveryFlow;}
            if(recoveryAt>=163 && recoveryAt<170 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=174; continue recoveryFlow;}
            if(recoveryAt>=167 && recoveryAt<183 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=187; continue recoveryFlow;}
            if(recoveryAt>=178 && recoveryAt<195 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=199; continue recoveryFlow;}
            if(recoveryAt>=191 && recoveryAt<211 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=215; continue recoveryFlow;}
            if(recoveryAt>=203 && recoveryAt<222 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=226; continue recoveryFlow;}
            if(recoveryAt>=230 && recoveryAt<242 && recoveryFailure instanceof java.lang.RuntimeException){recoveryStack[0]=recoveryFailure; recoveryPc=246; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

    public boolean aReturningBoolean(Object[] objectArray) {
        Object object;
        long l;
        block20: {
            long l2;
            Object object2;
            block21: {
                Object object3;
                block24: {
                    FieldAccessor bO_C00852;
                    block22: {
                        block23: {
                            FieldAccessor bO_C00853;
                            int n;
                            block19: {
                                boolean bl;
                                long l3;
                                block17: {
                                    block18: {
                                        object2 = objectArray[0];
                                        l = (Long)objectArray[1];
                                        long l4 = l = 0x4F5DC70319D6L ^ l;
                                        l3 = l4 ^ 0x7A5ABAEA77FAL;
                                        long l5 = l4 ^ 0x56073F77C51DL;
                                        l2 = l4 ^ 0x79BB1AA63533L;
                                        n = FieldAccessor.invokeBinding119(-782302461263148235L, l);
                                        try {
                                            try {
                                                bl = this.a;
                                                if (n == 0) break block17;
                                                if (bl) break block18;
                                            }
                                            catch (RuntimeException runtimeException) {
                                                throw FieldAccessor.invokeBinding120(runtimeException, -781541234748394479L, l);
                                            }
                                            Object[] objectArray2 = new Object[2];
                                            objectArray2[1] = l5;
                                            objectArray2[0] = object2;
                                            return FieldAccessor.invokeBinding122((Boolean)FieldAccessor.invokeBinding121(this, objectArray2, -781892864765102692L, l), -782229116671759548L, l);
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding123(runtimeException, -781541234748394479L, l);
                                        }
                                    }
                                    try {
                                        bO_C00853 = this;
                                        if (n == 0) break block19;
                                        bl = bO_C00853.e;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding124(runtimeException, -781541234748394479L, l);
                                    }
                                }
                                try {
                                    if (bl) {
                                        Object[] objectArray3 = new Object[2];
                                        objectArray3[1] = l3;
                                        objectArray3[0] = object2;
                                        return FieldAccessor.invokeBinding126(ReflectionUtil.a, FieldAccessor.invokeBinding125(this, objectArray3, -781398986960461346L, l), this.b, -775662657303065850L, l);
                                    }
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding127(runtimeException, -781541234748394479L, l);
                                }
                                bO_C00853 = this;
                            }
                            try {
                                try {
                                    try {
                                        try {
                                            object = bO_C00853.f;
                                            if (n == 0) break block20;
                                            if (object == null) break block21;
                                        }
                                        catch (RuntimeException runtimeException) {
                                            throw FieldAccessor.invokeBinding128(runtimeException, -781541234748394479L, l);
                                        }
                                        bO_C00852 = this;
                                        if (n == 0) break block22;
                                    }
                                    catch (RuntimeException runtimeException) {
                                        throw FieldAccessor.invokeBinding129(runtimeException, -781541234748394479L, l);
                                    }
                                    if (!bO_C00852.d) break block23;
                                }
                                catch (RuntimeException runtimeException) {
                                    throw FieldAccessor.invokeBinding130(runtimeException, -781541234748394479L, l);
                                }
                                object3 = this.f.get();
                                break block24;
                            }
                            catch (RuntimeException runtimeException) {
                                throw FieldAccessor.invokeBinding131(runtimeException, -781541234748394479L, l);
                            }
                        }
                        bO_C00852 = this;
                    }
                    object3 = bO_C00852.f.get(object2);
                }
                return FieldAccessor.invokeBinding132((Boolean)object3, -782229116671759548L, l);
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l2;
            objectArray4[0] = object2;
            object = FieldAccessor.invokeBinding133(this, objectArray4, -782746176257772408L, l);
        }
        return FieldAccessor.invokeBinding134((Boolean)object, -782229116671759548L, l);
    }

   public void fReturningVoid(Object[] var1) {
      Object var2;
      Object var3;
      long var10;
      int var12;
      FieldAccessor var38;
      label53: {
         var2 = var1[0];
         var3 = var1[1];
         long var4 = (Long)var1[2];
         var4 = 87264189422038L ^ var4;
         long var6 = var4 ^ 47600527105899L;
         long var8 = var4 ^ 43524256685761L;
         var10 = var4 ^ 121139981293877L;
         var12 = Event.bReturningInt();
         int var45 = var12;
         boolean var44 = this.a;
         boolean var37 = var44;
         boolean var35 = var44;
         if (var45 == 0) {
            boolean var46 = var35;
            if (!var46) {
               Object[] var15 = new Object[]{var2, var3, var6};
               FieldAccessor var14 = this;
               var14.gReturningVoid(var15);
               return;
            }

            int var48 = var12;
            FieldAccessor var47 = this;
            var38 = var47;
            FieldAccessor var36 = var47;
            if (var48 != 0) {
               break label53;
            }

            boolean var49 = var36.e;
            var37 = var49;
         }

         boolean var50 = var37;
         if (var50) {
            Unsafe var10000 = ReflectionUtil.a;
            Object[] var19 = new Object[]{var2, var8};
            FieldAccessor var18 = this;
            Object var10001 = var18.aReturningObject(var19);
            Object var24 = var3;
            long var22 = this.b;
            Object var21 = var10001;
            Unsafe var20 = var10000;
            var20.putObject(var21, var22, var24);
            int var51 = var12;
            if (var51 == 0) {
               return;
            }
         }

         FieldAccessor var52 = this;
         var38 = var52;
      }

      int var54 = var12;
      FieldAccessor var53 = var38;
      FieldAccessor var43 = var53;
      FieldAccessor var39 = var53;
      if (var54 == 0) {
         VarHandle var55 = var39.f;
         if (var55 != null) {
            int var57 = var12;
            FieldAccessor var56 = this;
            FieldAccessor var42 = var56;
            FieldAccessor var40 = var56;
            if (var57 == 0) {
               FieldAccessor var58 = var40;
               FieldAccessor var41 = var58;
               boolean var59 = var41.d;
               if (var59) {
                  this.f.set((Object)var3);
                  int var60 = var12;
                  if (var60 == 0) {
                     return;
                  }
               }

               FieldAccessor var61 = this;
               var42 = var61;
            }

            var42.f.set((Object)var2, (Object)var3);
            int var62 = var12;
            if (var62 == 0) {
               return;
            }
         }

         FieldAccessor var63 = this;
         var43 = var63;
      }

      Object[] var34 = new Object[]{var2, var3, var10};
      FieldAccessor var33 = var43;
      var33.hReturningVoid(var34);
   }

   public Object bReturningObject(Object[] var1) {
      Object var4;
      long var9;
      int var11;
      FieldAccessor var33;
      label47: {
         var4 = var1[0];
         long var2 = (Long)var1[1];
         var2 = 87264189422038L ^ var2;
         long var5 = var2 ^ 88208404194031L;
         long var7 = var2 ^ 136769391857672L;
         var9 = var2 ^ 92188232212518L;
         var11 = Event.cReturningInt();
         int var41 = var11;
         boolean var40 = this.a;
         boolean var32 = var40;
         boolean var30 = var40;
         if (var41 != 0) {
            boolean var42 = var30;
            if (!var42) {
               Object[] var14 = new Object[]{var4, var7};
               FieldAccessor var13 = this;
               return var13.cReturningObject(var14);
            }

            int var44 = var11;
            FieldAccessor var43 = this;
            var33 = var43;
            FieldAccessor var31 = var43;
            if (var44 == 0) {
               break label47;
            }

            boolean var45 = var31.e;
            var32 = var45;
         }

         boolean var46 = var32;
         if (var46) {
            Unsafe var10000 = ReflectionUtil.a;
            Object[] var18 = new Object[]{var4, var5};
            FieldAccessor var17 = this;
            Object var10001 = var17.aReturningObject(var18);
            long var21 = this.b;
            Object var20 = var10001;
            Unsafe var19 = var10000;
            return var19.getObject(var20, var21);
         }

         var33 = this;
      }

      int var48 = var11;
      VarHandle var47 = var33.f;
      Object var39 = var47;
      VarHandle var34 = var47;
      if (var48 != 0) {
         VarHandle var49 = var34;
         if (var49 != null) {
            int var51 = var11;
            FieldAccessor var50 = this;
            FieldAccessor var37 = var50;
            FieldAccessor var35 = var50;
            if (var51 != 0) {
               FieldAccessor var52 = var35;
               FieldAccessor var36 = var52;
               boolean var53 = var36.d;
               if (var53) {
                  return (Object)this.f.get();
               }

               var37 = this;
            }

            return (Object)var37.f.get((Object)var4);
         }

         Object[] var29 = new Object[]{var4, var9};
         FieldAccessor var28 = this;
         var39 = var28.dReturningObject(var29);
      }

      return var39;
   }

   private void gReturningVoid(Object[] var1) {
      Object var2 = var1[0];
      Object var3 = var1[1];
      long var4 = (Long)var1[2];
      var4 = 87264189422038L ^ var4;
      long var6 = var4 ^ 21575186122753L;
      long var8 = var4 ^ 58692952254459L;
      Object[] var10 = new Object[]{var2, this.i, this.h, this.j, var8};
      BoundFieldAccessor var10000 = ReflectedField.bReturningbN_C0083(var10);
      Object[] var12 = new Object[]{var3, var6};
      BoundFieldAccessor var11 = var10000;
      var11.aReturningVoid(var12);
   }

   private Object cReturningObject(Object[] var1) {
      Object var4 = var1[0];
      long var2 = (Long)var1[1];
      var2 = 87264189422038L ^ var2;
      long var5 = var2 ^ 84604342501721L;
      long var7 = var2 ^ 24065143592118L;
      Object[] var9 = new Object[]{var4, this.i, this.h, this.j, var7};
      BoundFieldAccessor var10000 = ReflectedField.bReturningbN_C0083(var9);
      Object[] var11 = new Object[]{var5};
      BoundFieldAccessor var10 = var10000;
      return var10.aReturningObject(var11);
   }

   private void hReturningVoid(Object[] var1) {
      Object var2 = var1[0];
      Object var3 = var1[1];
      long var4 = (Long)var1[2];
      var4 = 87264189422038L ^ var4;
      long var6 = var4 ^ 7581042302498L;

      try {
         Field var10000 = this.g;
         Object[] var10 = new Object[]{var2, var6};
         FieldAccessor var9 = this;
         Object var10001 = var9.aReturningObject(var10);
         Object var13 = var3;
         Object var12 = var10001;
         Field var11 = var10000;
         var11.set(var12, var13);
      } catch (IllegalAccessException var15) {
         throw new RuntimeException(var15);
      }
   }

   private Object dReturningObject(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      var3 = 87264189422038L ^ var3;
      long var5 = var3 ^ 84372070816543L;

      try {
         Field var10000 = this.g;
         Object[] var9 = new Object[]{var2, var5};
         FieldAccessor var8 = this;
         Object var11 = var8.aReturningObject(var9);
         Field var10 = var10000;
         return var10.get(var11);
      } catch (IllegalAccessException var14) {
         throw new RuntimeException(var14);
      }
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(63872731484409L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "YI¼\u0017É¥¶I9\u0093\u009aâ\n2Ú´";
      int var7 = "YI¼\u0017É¥¶I9\u0093\u009aâ\n2Ú´".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Long[2];
   
      
}

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11443;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bO", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bO_C0085",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bO" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 31;
            yield var15;
         }
         case 1 -> {
            byte var16 = 55;
            yield var16;
         }
         case 2 -> {
            byte var17 = 47;
            yield var17;
         }
         case 3 -> {
            byte var18 = 8;
            yield var18;
         }
         case 4 -> {
            byte var19 = 63;
            yield var19;
         }
         case 5 -> {
            byte var20 = 61;
            yield var20;
         }
         case 6 -> {
            byte var21 = 40;
            yield var21;
         }
         case 7 -> {
            byte var22 = 51;
            yield var22;
         }
         case 8 -> {
            byte var23 = 49;
            yield var23;
         }
         case 9 -> {
            byte var24 = 4;
            yield var24;
         }
         case 10 -> {
            byte var25 = 54;
            yield var25;
         }
         case 11 -> {
            byte var26 = 26;
            yield var26;
         }
         case 12 -> {
            byte var27 = 46;
            yield var27;
         }
         case 13 -> {
            byte var28 = 6;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 11;
            yield var30;
         }
         case 16 -> {
            byte var31 = 60;
            yield var31;
         }
         case 17 -> {
            byte var32 = 19;
            yield var32;
         }
         case 18 -> {
            byte var33 = 27;
            yield var33;
         }
         case 19 -> {
            byte var34 = 7;
            yield var34;
         }
         case 20 -> {
            byte var35 = 48;
            yield var35;
         }
         case 21 -> {
            byte var36 = 3;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 17;
            yield var38;
         }
         case 24 -> {
            byte var39 = 36;
            yield var39;
         }
         case 25 -> {
            byte var40 = 1;
            yield var40;
         }
         case 26 -> {
            byte var41 = 59;
            yield var41;
         }
         case 27 -> {
            byte var42 = 24;
            yield var42;
         }
         case 28 -> {
            byte var43 = 23;
            yield var43;
         }
         case 29 -> {
            byte var44 = 9;
            yield var44;
         }
         case 30 -> {
            byte var45 = 33;
            yield var45;
         }
         case 31 -> {
            byte var46 = 44;
            yield var46;
         }
         case 32 -> {
            byte var47 = 53;
            yield var47;
         }
         case 33 -> {
            byte var48 = 62;
            yield var48;
         }
         case 34 -> {
            byte var49 = 32;
            yield var49;
         }
         case 35 -> {
            byte var50 = 12;
            yield var50;
         }
         case 36 -> {
            byte var51 = 10;
            yield var51;
         }
         case 37 -> {
            byte var52 = 18;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 50;
            yield var55;
         }
         case 41 -> {
            byte var56 = 34;
            yield var56;
         }
         case 42 -> {
            byte var57 = 45;
            yield var57;
         }
         case 43 -> {
            byte var58 = 57;
            yield var58;
         }
         case 44 -> {
            byte var59 = 5;
            yield var59;
         }
         case 45 -> {
            byte var60 = 35;
            yield var60;
         }
         case 46 -> {
            byte var61 = 14;
            yield var61;
         }
         case 47 -> {
            byte var62 = 2;
            yield var62;
         }
         case 48 -> {
            byte var63 = 30;
            yield var63;
         }
         case 49 -> {
            byte var64 = 58;
            yield var64;
         }
         case 50 -> {
            byte var65 = 22;
            yield var65;
         }
         case 51 -> {
            byte var66 = 13;
            yield var66;
         }
         case 52 -> {
            byte var67 = 28;
            yield var67;
         }
         case 53 -> {
            byte var68 = 29;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 41;
            yield var71;
         }
         case 57 -> {
            byte var72 = 16;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 38;
            yield var74;
         }
         case 60 -> {
            byte var75 = 52;
            yield var75;
         }
         case 61 -> {
            byte var76 = 0;
            yield var76;
         }
         case 62 -> {
            byte var77 = 25;
            yield var77;
         }
         default -> 37;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      o[0] = ";Nl@eQ-Ni\u001avF:\u0005j\u001czR+B}\u000b1C\u0010";
      o[1] = "lY-p\u0006\u0015gV<?z\fhL2|M<~[>a\\\u0010iV";
      o[2] = "\u0001\u001dn\u0000\u0000N\u0017\u001dkZ\u0013Y\u0000Vh\\\u001fM\u0011\u0011\u007fKT_ ";
      o[3] = int.class;
      p[3] = "java/lang/Integer";
      o[4] = "6Z\u0010\b\u000f0=U\u0001Gm32\\";
      o[5] = long.class;
      p[5] = "java/lang/Long";
      o[6] = "\u0004bIYK6qBBVZy\u0010LI]^#d";
      o[7] = "I\u000bDX:QB\u0004U\u0017[_I\u000fQM";
      o[8] = "o>Ty<F\u001a\u001e_v-\t{\u0010T})S\u000f";
      o[9] = "6(P%\u001e]6>\u0010^\u001dG$;[";
      o[10] = "\u001e\u0013[\u0017,>\u0015\u001cJXL'\u0019\u0010H\u0004";
      o[11] = "!kc65DTKh9$\u000b5Ec2 QA";
      o[12] = "0\u0012\u0007\u0019LiE2\f\u0016]&$<\u0007\u001dY|P";
      o[13] = void.class;
      p[13] = "java/lang/Void";
      o[14] = "\u0006[\u0014{Pws{\u001ftA8\u0012u\u0014\u007fEbf";
      o[15] = "n z\u0006b\u0002e/kI\u0005\u0000p$k\u0002>";
      o[16] = float.class;
      p[16] = "java/lang/Float";
      o[17] = "\u000em\t\rW\u0013\u0005b\u0018B?\u0013\u000bm\u000b";
      o[18] = "\u0007 \t1/Z\f/\u0018~sS\u000b-\u001a3u\u0018+(\u001a<e";
      o[19] = "\u001cuA>mw\nuDd~`\u001d>Gbrt\fyPu9d*";
      o[20] = "a\u0012.\u001bHr\u00142%\u0014Y=u<.\u001f]g\u0001";
      o[21] = "y\trjR(o\tw0A?xBt6M+i\u0005c!\u0006:S";
      o[22] = "L.t\u0018\u000f[9\u000e\u007f\u0017\u001e\u0014X\u0000t\u001c\u001aN,";
      o[23] = "\u007fNP\u0003\u0015&tAAL\u007f%`MJ\u0007";
      o[24] = double.class;
      p[24] = "java/lang/Double";
      o[25] = "B\u0018G*\"0I\u0017VeN3G\u0015T*b";
      o[26] = boolean.class;
      p[26] = "java/lang/Boolean";
      o[27] = "&\u001a]UrIS:VZc\u000624]Qg\\F";
      o[28] = "\u0014\u0010\u0007}yH\u001cEHs\tD-G_x2\u0012O\u0002T|u.";
      o[29] = "q\u001aln\u001f\u0012.\n9;|\\x\u0000+m;L\u0011\u0005<9\u0019Zp\u0014-kG\"q\u001aln\u001f\u0012.\n9;|";
      o[30] = "@f\"=}m\u0017a,j@h\u0003z]j<\u0010C=\"mxq\u001e|fq@+\u0007hyc&(\u0007t{\fzw\u001b= n?|\u001fz\u001c=#`\u0017zzt'}\u0002\u0006";
      o[31] = "i\u0019_7\u007f\f>\u001eQ`B\u001e:\u0005 `>qjB_gz\u00107\u0003\u001b{BJ.\u0017\u0004i$I.\u000b\u0006\u0006x\u00162B]d=\u001d6\u0005a";
      o[32] = "!Da\u0010r\b%F%WM\u0007s\u001ab\u0005\n\u0017\u001aEf\u0006(\u0016|Ff\u001a*y!Da\u0010r\b%F%WM";
      o[33] = ".r\u0016=\u0018[(=\u0010.(Tw}\u0018)Efyd\u000f (Ww`\u001b JXu:\u0002M";
      o[34] = "C 5e2\tKuzkB\u0004zwm`yS\u00182fd>o";
      o[35] = "<\n*5x\u0007c\u001a\u007f`\u001b];\u0013t6rQ\u0002\u001dt&v7=\u001e)>cV,\u000f{`\u001b";
      o[36] = "\u0011Nun\r\b\u0015L1)2\u001dM\u0012dH[\u001dW\u0019\u000b-K\u0017O\u001bm.K\u000bMt";
      o[37] = "1c4M\n\r7,2^:\u000fim\u000eT^\u0013b\u0011jZ_U3s/Q[\u0012\u000f";
      o[38] = "34\u001cw6p0/\u0000.]k<(&\u007f9w7TBq81f6\u0007z<vZ";
      o[39] = ".\\ENpzy[K\u0019Mh}@7\u00180mtQ{Bv9q\u0004\u001a\u001f7}m<@\u0006#b\u007fZC\u0006?`\u0010S\u001c\u001f$jr\\\u001eE=\u0007";
      o[40] = "\u0014\u0003\u0003r\u0001\u0012EYOK\u0015-ENV.\u001b\u0012M\u0005Nr~\u0010\u001f\u0000Ss\u001fM^DOK";
      o[41] = "'^\u001a\u0000q0v\u0004V9n\u000fv\u0013O\\k0~XW\u0000\u000e>t\u0013BEhwp\u000eW9";
      o[42] = "\u000e*\t>x\u007f\u0013v\u001f,\u001ah\u000fjcn!-\u0003.\u00023`i\u001f\u0016^h$rZw\u0003)`nb'\u0000#so\u0004n\u0004>f\u0013";
      o[43] = "a*Y\u0012j96-WEW+26#D1+_w\\\u001d6|>*\u001dY*Dd3\tF8\"g3\u0015DW\u007f&$\u0002L1|&8\u0000#";
      o[44] = "}\n{HaU*\ru\u001f\\P>\u0016\t\u001e!B'\u0007EDg\u0016\"R$\u0019&R>j~\u00002M,\f}\u0000.OC\u0005\"\u00195E!\n C,(r\t5\u0010 N;\r(\u0005\\";
      o[45] = "EL\u001e'!&\u0014\u0016R\u001e7\u0019\u000b\fOa0 \u001c\fO\u001e d\u0015\u000eA'7d\u0015q";
      o[46] = "n$21J\u001e9#<fw\u001b-8Hg\u0011\fPy7>\u0016[1$vz\nck=be\u0018\u0005h=~gwX)*io\u0011[)6k\u0000F\u0000 -pf\u000f\u0004=8\f";
      o[47] = "@/1+sz\u0011u}\u0012eE\u0011bdwiz\u0019)|+\fxK,a*m%\nh}\u0012";
      o[48] = "O\u001b\u001b&oHL\u0000\u0007\u007f\u0004LO\u001f\u0002*C\\&A\u0018\"?\u000eD\u0004\u0013&x2O\u001b\u001b&oHL\u0000\u0007\u007f\u0004";
      o[49] = "W|QKxV\u0005,]L\u0002\u0003_aQ\u0012o1QxF\u001b\u0002\u0000_|R\u001b`\u000f]&Kv";
      o[50] = "`m\u001e0\u001627j\u0010g+7#qneL&\"\r\u001d:\u0015.fl@{Q2^6YoN 85YsLO4h_dN43bYn+~=}I}M79`\\\u0001";
      o[51] = ":k09e{'.km\\~Vv'b9qi~lze\u0014;lohe,1'1x\\";
      o[52] = "\u001cA%1\u000biKF+f6{O]\\jTyI]\u001b=\r*C\u0019z`Ln_! yXqMG#yDs\"\u001c >W,CAazK\u0014";
      o[53] = "a*{\u001d2{0p7$\"D0g.A({8,6\u001dMu2g#X+<6z6$";
      o[54] = "9=\u001e\u0003i<n:\u0010TT9z!gX6,l! \u000fo\u007ffeAR.;z]\u001bK:$h;\u0018K&&\u0007`\u001b\f5yf=ZH)A6>P[('\u007f:MNT";
      o[55] = "Cl\u0012<O\rE#\u0014/\u007f\u0000\u0019y\u001f0!\u0007\u0019c\u001bL\u0015\u000b\u0002{\u00137\u0012\u0001\u0004qv";
      o[56] = "<\u0011\u0007\u0012\u0003W6ZY\u0002:\u0006Q\u000bO\u0018_\nn\u0003\u0004\u0000\u0003olQ\u0001\u001d\u0002\u000e1\u0010E\u0001:";
      o[57] = "\u00162\u000f\u0018o1A5\u0001OR4U.{N5(E;W)ow\u00163\tH26R/1\u0012+\"M=W\u0011+>ORPCk)P3AR9w(cRY;0N*VD.L";
      o[58] = "_SX|Gm\bTV+z\u007f\fO()\u001dy\u001d3[vDqYR\u00067\u0000ma\b\u001f#\u001f\u007f\u0007\u000b\u001f?\u001d\u0010\u000bV\u0019(\u001fk\f\\\u001f\"z";
      o[59] = "\\\u0012d7\u001eoQ\nc-z;R\nu($<R\u0010qT\u00100I\by/\u0017:O\u0002\u001c";
      o[60] = "\u001c]z\u001c\n)M\u00076%\u0019\u0016M\u0010/@\u0010)E[7\u001cu+\u0017^*\u001d\u0014vV\u001a6%";
      o[61] = "W?Q\u000fh\rZ'V\u0015\fIT$T\u0001KY=*L\u0013iRF-F\u0015c7W?Q\u000fh\rZ'V\u0015\f";
      o[62] = "T\u0018IYHI\u0006HE^2\u000eR\u001c^\tu\u001e;\u0017D\u0004[\u001dY\u0018F^BpT\u0018IYHI\u0006HE^2";
      o[63] = "K[#w\u000e\fM\u0014%d>\u000b\u0012O(YW\u000b\bDG<G\u0001\u0010F!?G\u001d\u0012)";
      o[64] = "b7;%N@h|e5w\u0011\u000f-s/\u0012\u001d0%87Nx>/s\"\u000b\u001ew+n7w";
      o[65] = "Q)I`^l\u0006.G7c~\u00025=6\u0004u\u0002 \u0011Q^*Q(O0\u0003k\u00154wj\u001a\u007f\n&\u0011i\u001ac\bI\u0016;Zt\u0017(\u0007*\b*o";
      o[66] = "SW~|PBN\u000bhn2AR\u0017\u0014,\t\u0010^SuqHTBk)*\fO\u0007\ntkHS?";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(516772511193306L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(516772511193306L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(516772511193306L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 211;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 83;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 217;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 222;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 71;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 226;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 211;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 83;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 217;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bO_C0085",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bO" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding7(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding8(Object var0, Object var1, long var2, long var4, long var6) {
         MethodHandle var12 = bindingCache8;
         MethodHandle var11 = bindingCache8;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache8 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJJ)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (double)var9.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static RuntimeException invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding17(long var0, long var2) {
         MethodHandle var8 = bindingCache17;
         MethodHandle var7 = bindingCache17;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache17 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding22(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding23(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding24(Object var0, Object var1, long var2, long var4, long var6) {
         MethodHandle var12 = bindingCache24;
         MethodHandle var11 = bindingCache24;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache24 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var9.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static RuntimeException invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding31(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding33(long var0, long var2) {
         MethodHandle var8 = bindingCache33;
         MethodHandle var7 = bindingCache33;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache33 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Integer invokeBinding35(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding36(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache36;
         MethodHandle var9 = bindingCache36;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache36 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RuntimeException invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding40(Object var0, Object var1, long var2, int var4, long var5, long var7) {
         MethodHandle var13 = bindingCache40;
         MethodHandle var12 = bindingCache40;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache40 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JIJJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var10.invokeExact((Object)var0, (Object)var1, (long)var2, (int)var4, (long)var5, (long)var7);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static RuntimeException invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding45(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache45;
         MethodHandle var8 = bindingCache45;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache45 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding46(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache46;
         MethodHandle var8 = bindingCache46;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache46 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding48(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Integer invokeBinding49(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding50(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache50;
         MethodHandle var9 = bindingCache50;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache50 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding51(long var0, long var2) {
         MethodHandle var8 = bindingCache51;
         MethodHandle var7 = bindingCache51;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache51 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding52(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache52;
         MethodHandle var8 = bindingCache52;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache52 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding53(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache53;
         MethodHandle var9 = bindingCache53;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache53 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding54(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache54;
         MethodHandle var8 = bindingCache54;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache54 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding55(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache55;
         MethodHandle var8 = bindingCache55;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache55 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding56(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache56;
         MethodHandle var8 = bindingCache56;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache56 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding57(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache57;
         MethodHandle var9 = bindingCache57;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache57 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding58(Object var0, Object var1, long var2, long var4, long var6) {
         MethodHandle var12 = bindingCache58;
         MethodHandle var11 = bindingCache58;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache58 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJJ)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (int)var9.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static RuntimeException invokeBinding59(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache59;
         MethodHandle var8 = bindingCache59;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache59 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding60(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache60;
         MethodHandle var8 = bindingCache60;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache60 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding61(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache61;
         MethodHandle var8 = bindingCache61;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache61 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding62(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache62;
         MethodHandle var8 = bindingCache62;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache62 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding63(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache63;
         MethodHandle var8 = bindingCache63;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache63 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding64(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache64;
         MethodHandle var8 = bindingCache64;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache64 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding65(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache65;
         MethodHandle var9 = bindingCache65;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache65 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding66(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache66;
         MethodHandle var8 = bindingCache66;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache66 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding67(long var0, long var2) {
         MethodHandle var8 = bindingCache67;
         MethodHandle var7 = bindingCache67;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache67 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding68(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache68;
         MethodHandle var8 = bindingCache68;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache68 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Long invokeBinding69(long var0, long var2, long var4) {
         MethodHandle var10 = bindingCache69;
         MethodHandle var9 = bindingCache69;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache69 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJJ)Ljava/lang/Long;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Long)var7.invokeExact((long)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding70(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache70;
         MethodHandle var9 = bindingCache70;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache70 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RuntimeException invokeBinding71(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache71;
         MethodHandle var8 = bindingCache71;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache71 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding72(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache72;
         MethodHandle var8 = bindingCache72;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache72 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding73(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache73;
         MethodHandle var9 = bindingCache73;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache73 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding74(Object var0, Object var1, long var2, long var4, long var6, long var8) {
         MethodHandle var14 = bindingCache74;
         MethodHandle var13 = bindingCache74;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache74 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJJJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var11.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static RuntimeException invokeBinding75(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache75;
         MethodHandle var8 = bindingCache75;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache75 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding76(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache76;
         MethodHandle var8 = bindingCache76;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache76 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding78(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache78;
         MethodHandle var8 = bindingCache78;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache78 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding79(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache79;
         MethodHandle var8 = bindingCache79;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache79 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding80(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache80;
         MethodHandle var8 = bindingCache80;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache80 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding81(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache81;
         MethodHandle var8 = bindingCache81;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache81 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding82(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache82;
         MethodHandle var8 = bindingCache82;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache82 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Long invokeBinding83(long var0, long var2, long var4) {
         MethodHandle var10 = bindingCache83;
         MethodHandle var9 = bindingCache83;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache83 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJJ)Ljava/lang/Long;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Long)var7.invokeExact((long)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding84(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache84;
         MethodHandle var9 = bindingCache84;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache84 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding85(long var0, long var2) {
         MethodHandle var8 = bindingCache85;
         MethodHandle var7 = bindingCache85;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache85 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding86(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache86;
         MethodHandle var8 = bindingCache86;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache86 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding87(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache87;
         MethodHandle var9 = bindingCache87;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache87 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static long invokeBinding88(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache88;
         MethodHandle var8 = bindingCache88;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache88 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)J", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (long)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding89(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache89;
         MethodHandle var8 = bindingCache89;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache89 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding90(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache90;
         MethodHandle var8 = bindingCache90;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache90 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding91(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache91;
         MethodHandle var9 = bindingCache91;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache91 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static long invokeBinding92(Object var0, Object var1, long var2, long var4, long var6) {
         MethodHandle var12 = bindingCache92;
         MethodHandle var11 = bindingCache92;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache92 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJJ)J", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (long)var9.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static RuntimeException invokeBinding93(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache93;
         MethodHandle var8 = bindingCache93;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache93 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding94(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache94;
         MethodHandle var8 = bindingCache94;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache94 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding95(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache95;
         MethodHandle var8 = bindingCache95;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache95 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding96(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache96;
         MethodHandle var8 = bindingCache96;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache96 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding97(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache97;
         MethodHandle var8 = bindingCache97;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache97 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static long invokeBinding98(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache98;
         MethodHandle var8 = bindingCache98;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache98 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)J", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (long)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding99(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache99;
         MethodHandle var9 = bindingCache99;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache99 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static long invokeBinding100(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache100;
         MethodHandle var8 = bindingCache100;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache100 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)J", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (long)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding101(long var0, long var2) {
         MethodHandle var8 = bindingCache101;
         MethodHandle var7 = bindingCache101;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache101 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding102(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache102;
         MethodHandle var8 = bindingCache102;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache102 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Boolean invokeBinding103(boolean var0, long var1, long var3) {
         MethodHandle var9 = bindingCache103;
         MethodHandle var8 = bindingCache103;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache103 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(ZJJ)Ljava/lang/Boolean;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Boolean)var6.invokeExact((boolean)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding104(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache104;
         MethodHandle var9 = bindingCache104;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache104 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RuntimeException invokeBinding105(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache105;
         MethodHandle var8 = bindingCache105;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache105 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding106(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache106;
         MethodHandle var8 = bindingCache106;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache106 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding107(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache107;
         MethodHandle var9 = bindingCache107;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache107 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding108(Object var0, Object var1, long var2, boolean var4, long var5, long var7) {
         MethodHandle var13 = bindingCache108;
         MethodHandle var12 = bindingCache108;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache108 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JZJJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var10.invokeExact((Object)var0, (Object)var1, (long)var2, (boolean)var4, (long)var5, (long)var7);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static RuntimeException invokeBinding109(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache109;
         MethodHandle var8 = bindingCache109;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache109 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding110(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache110;
         MethodHandle var8 = bindingCache110;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache110 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding111(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache111;
         MethodHandle var8 = bindingCache111;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache111 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding112(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache112;
         MethodHandle var8 = bindingCache112;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache112 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding113(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache113;
         MethodHandle var8 = bindingCache113;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache113 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding114(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache114;
         MethodHandle var8 = bindingCache114;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache114 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding115(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache115;
         MethodHandle var8 = bindingCache115;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache115 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding116(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache116;
         MethodHandle var8 = bindingCache116;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache116 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Boolean invokeBinding117(boolean var0, long var1, long var3) {
         MethodHandle var9 = bindingCache117;
         MethodHandle var8 = bindingCache117;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache117 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(ZJJ)Ljava/lang/Boolean;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Boolean)var6.invokeExact((boolean)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding118(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache118;
         MethodHandle var9 = bindingCache118;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache118 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding119(long var0, long var2) {
         MethodHandle var8 = bindingCache119;
         MethodHandle var7 = bindingCache119;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache119 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static RuntimeException invokeBinding120(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache120;
         MethodHandle var8 = bindingCache120;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache120 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding121(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache121;
         MethodHandle var9 = bindingCache121;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache121 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding122(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache122;
         MethodHandle var8 = bindingCache122;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache122 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding123(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache123;
         MethodHandle var8 = bindingCache123;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache123 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding124(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache124;
         MethodHandle var8 = bindingCache124;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache124 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding125(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache125;
         MethodHandle var9 = bindingCache125;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache125 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding126(Object var0, Object var1, long var2, long var4, long var6) {
         MethodHandle var12 = bindingCache126;
         MethodHandle var11 = bindingCache126;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache126 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var9.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static RuntimeException invokeBinding127(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache127;
         MethodHandle var8 = bindingCache127;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache127 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding128(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache128;
         MethodHandle var8 = bindingCache128;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache128 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding129(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache129;
         MethodHandle var8 = bindingCache129;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache129 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding130(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache130;
         MethodHandle var8 = bindingCache130;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache130 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RuntimeException invokeBinding131(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache131;
         MethodHandle var8 = bindingCache131;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache131 = b(
                  MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding132(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache132;
         MethodHandle var8 = bindingCache132;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache132 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding133(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache133;
         MethodHandle var9 = bindingCache133;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache133 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding134(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache134;
         MethodHandle var8 = bindingCache134;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache134 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
