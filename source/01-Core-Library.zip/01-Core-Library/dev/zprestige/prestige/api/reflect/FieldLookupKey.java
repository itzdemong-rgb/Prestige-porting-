package dev.zprestige.prestige.api.reflect;

public record FieldLookupKey(Class<?> az, String aA, Object aB, Class<?> aC) {
}
