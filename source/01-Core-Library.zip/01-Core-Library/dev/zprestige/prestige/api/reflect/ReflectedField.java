package dev.zprestige.prestige.api.reflect;
import dev.zprestige.prestige.api.reflect.BoundFieldAccessor;
import dev.zprestige.prestige.api.reflect.FieldAccessMetadata;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.VarHandle;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.lenni0451.classtransform.TransformerManager;
import net.lenni0451.classtransform.mappings.AMapper;
import net.lenni0451.classtransform.utils.ASMUtils;
import net.lenni0451.classtransform.utils.mappings.MapRemapper;
import sun.misc.Unsafe;

public class ReflectedField extends ReflectionUtil {
   private final Field b;
   private final boolean c;
   private final Object d;
   private final long e;
   private final VarHandle f;
   private final Object g;
   private static final ConcurrentHashMap h;
   private static final long i = 106370906886851L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long[] t;
   private static final Integer[] u;
   private static final Map v;
   private static final Object[] B = new Object[112];
   private static final String[] C = new String[112];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;

   private ReflectedField(Field var1, boolean var2, Object var3, long var4, VarHandle var6, Object var7) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
      this.f = var6;
      this.g = var7;
   }

   private ReflectedField(FieldAccessMetadata var1, Object var2) {
      this(var1.a, var1.b, var1.c, var1.d, var1.e, var2);
   }

   public static ReflectedField aReturningcR_C0145(Object[] var0) {
      Class var1 = (Class)var0[0];
      String var4 = (String)var0[1];
      long var2 = (Long)var0[2];
      var2 = 106370906886851L ^ var2;
      long var5 = var2 ^ 15576893847497L;
      Object[] var8 = new Object[]{var1, var4, var5};
      FieldAccessMetadata var7 = ReflectionUtil.aReturningcU_C0151(var8);
      return new ReflectedField(var7, null);
   }

    public static ReflectedField bReturningcR_C0145(Object[] objectArray) {

        Object object;
        long l;
        long l2;
        String string;
        Object object2;
        block4: {
            block5: {
                object2 = objectArray[0];
                string = (String)objectArray[1];
                l2 = (Long)objectArray[2];
                l = (l2 = 0x60BE681E92C3L ^ l2) ^ 0x7E38BBE9BC33L;
                int n = ReflectedField.invokeBinding1(1063308075919855992L, l2);
                try {
                    try {
                        object = object2;
                        if (n == 0) break block4;
                        if (object != null) break block5;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedField.invokeBinding2(illegalArgumentException, 1069639689456977413L, l2);
                    }
                    throw new IllegalArgumentException(ReflectedField.invokeBinding3(32095, 0x317591CA8A8C9450L ^ l2));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedField.invokeBinding4(illegalArgumentException, 1069639689456977413L, l2);
                }
            }
            object = object2;
        }
        Object[] objectArray2 = new Object[3];
        objectArray2[2] = l;
        objectArray2[1] = string;
        objectArray2[0] = object.getClass();
        FieldAccessMetadata cU_C01512 = ReflectedField.invokeBinding5(objectArray2, 1066464474990947622L, l2);
        return new ReflectedField(cU_C01512, object2);
    
      
}

   public static ReflectedField cReturningcR_C0145(Object[] var0) {
      Class var4 = (Class)var0[0];
      String var5 = (String)var0[1];
      String var1 = (String)var0[2];
      long var2 = (Long)var0[3];
      var2 = 106370906886851L ^ var2;
      long var6 = var2 ^ 115060856903273L;
      FieldAccessMetadata var8 = invokeBinding6(new Object[]{var4, var5, var1, var6}, 5916545114197133479L, var2);
      return new ReflectedField(var8, null);
   }

    public static ReflectedField dReturningcR_C0145(Object[] objectArray) {

        Object object;
        long l;
        long l2;
        String string;
        String string2;
        Object object2;
        block4: {
            block5: {
                object2 = objectArray[0];
                string2 = (String)objectArray[1];
                string = (String)objectArray[2];
                l2 = (Long)objectArray[3];
                l = (l2 = 0x60BE681E92C3L ^ l2) ^ 0x451C2E52A59L;
                int n = ReflectedField.invokeBinding7(-5898310072571235939L, l2);
                try {
                    try {
                        object = object2;
                        if (n == 0) break block4;
                        if (object != null) break block5;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedField.invokeBinding8(illegalArgumentException, -5891481734423796000L, l2);
                    }
                    throw new IllegalArgumentException(ReflectedField.invokeBinding9(8267, 0x471A74E9A8C769A5L ^ l2));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedField.invokeBinding10(illegalArgumentException, -5891481734423796000L, l2);
                }
            }
            object = object2;
        }
        Object[] objectArray2 = new Object[4];
        objectArray2[3] = l;
        objectArray2[2] = string;
        objectArray2[1] = string2;
        objectArray2[0] = object.getClass();
        FieldAccessMetadata cU_C01512 = ReflectedField.invokeBinding11(objectArray2, -5896436101015473001L, l2);
        return new ReflectedField(cU_C01512, object2);
    
      
}

   public static BoundFieldAccessor aReturningbN_C0083(Object[] var0) {
      Object var4 = var0[0];
      String var1 = (String)var0[1];
      long var2 = (Long)var0[2];
      var2 = 106370906886851L ^ var2;
      long var5 = var2 ^ 16278141539626L;
      long var7 = var2 ^ 61345900064082L;
      ReflectedField var9 = invokeBinding12(new Object[]{var4, var1, var7}, 8164737585449773472L, var2);
      return invokeBinding13(var9, new Object[]{var5}, 8164984558847928794L, var2);
   }

   public static BoundFieldAccessor bReturningbN_C0083(Object[] var0) {
      Object var4;
      long var7;
      ReflectedField var51;
      var4 = var0[0];
      String var5 = (String)var0[1];
      Class var3 = (Class)var0[2];
      Class var6 = (Class)var0[3];
      long var1 = (Long)var0[4];
      var1 = 106370906886851L ^ var1;
      var7 = var1 ^ 52391320076L;
      long var9 = var1 ^ 87221221059579L;
      int var10000 = Event.bReturningInt();
      Class var12 = var4.getClass();
      FieldLookupKey var13 = new FieldLookupKey(var3, var5, var6, var12);
      int var11 = var10000;
      FieldLookupKey var22 = var13;
      ConcurrentHashMap var21 = h;
      ReflectedField var14 = (ReflectedField)var21.get(var22);
      int var53 = var11;
      ReflectedField var52 = var14;
      var51 = var52;
      ReflectedField var49 = var52;
      label19:
      if (var53 == 0) {
         ReflectedField var54 = var49;
         if (var54 == null) {
            Class var24 = var6;
            String var15 = ASMUtils.toFieldDescriptor(var24);
            AMapper var25 = TransformerManager.getRemapper();
            MapRemapper var26 = var25.getRemapper();
            MapRemapper var59 = var26.reverse();
            Class var27 = var3;
            String var10001 = var27.getName();
            short var10002 = 4078;
            long var10003 = 601281264719684270L ^ var1;
            byte var62 = 46;
            short var63 = 3468;
            long var10004 = 6294706455585972430L ^ var1;
            String var28 = var10001;
            String var32 = var28.replace('.', '/');
            MapRemapper var31 = var59;
            String var16 = var31.map(var32);
            AMapper var33 = TransformerManager.getRemapper();
            MapRemapper var34 = var33.getRemapper();
            MapRemapper var60 = var34.reverse();
            String var36 = var15;
            MapRemapper var35 = var60;
            String var17 = var35.mapDesc(var36);
            AMapper var37 = TransformerManager.getRemapper();
            MapRemapper var61 = var37.getRemapper();
            String var41 = var17;
            String var40 = var5;
            String var39 = var16;
            MapRemapper var38 = var61;
            String var18 = var38.mapFieldName(var39, var40, var41);
            Object[] var42 = new Object[]{var12, var18, var15, var9};
            FieldAccessMetadata var19 = ReflectionUtil.bReturningcU_C0151(var42);
            var14 = new ReflectedField(var19, null);
            ReflectedField var45 = var14;
            FieldLookupKey var44 = var13;
            ConcurrentHashMap var43 = h;
            ReflectedField var20 = ((dev.zprestige.prestige.api.reflect.ReflectedField)(Object)(var43.putIfAbsent(var44, var45)));
            int var56 = var11;
            ReflectedField var55 = var20;
            var51 = var55;
            ReflectedField var50 = var55;
            if (var56 != 0) {
               break label19;
            }

            ReflectedField var57 = var50;
            if (var57 != null) {
               var14 = var20;
            }
         }

         var51 = var14;
      }

      Object[] var48 = new Object[]{var4, var7};
      ReflectedField var47 = var51;
      return var47.dReturningbN_C0083(var48);
   }

   public static BoundFieldAccessor cReturningbN_C0083(Object[] var0) {

      Object var6 = var0[0];
      String var3 = (String)var0[1];
      Class var4 = (Class)var0[2];
      String var5 = (String)var0[3];
      long var1 = (Long)var0[4];
      var1 = 106370906886851L ^ var1;
      long var7 = var1 ^ 139927837338153L;
      long var9 = var1 ^ 52899135101918L;
      int var10000 = invokeBinding14(-6942696320856477147L, var1);
      Class var12 = var6.getClass();
      int var11 = var10000;
      FieldLookupKey var13 = new FieldLookupKey(var4, var3, var5, var12);
      ReflectedField var14 = (ReflectedField)invokeBinding15(h, var13, -6936812676781738742L, var1);

      label40: {
         try {
            int var27 = var11;
            ReflectedField var26 = var14;
            ReflectedField var25 = var26;
            ReflectedField var21 = var26;
            if (var27 != 0) {
               return invokeBinding35(var25, new Object[]{var6, var7}, -6943043812351528759L, var1);
            }

            ReflectedField var28 = var21;
            if (var28 != null) {
               break label40;
            }
         } catch (IllegalArgumentException var33) {
            throw invokeBinding16(var33, -6937103774981122201L, var1);
         }

         String var15 = "L" + var5 + ";";
         String var16 = invokeBinding24(
            invokeBinding19(invokeBinding18(invokeBinding17(-6940154420040163054L, var1), -6940515892695801111L, var1), -6940673868368436970L, var1),
            invokeBinding23(
               invokeBinding20(var4, -6940313856594040072L, var1),
               (char)invokeBinding21(8471, 6534539577915554929L ^ var1),
               (char)invokeBinding22(4234, 245226639172046318L ^ var1),
               -6942309685054057259L,
               var1
            ),
            -6942773629741567368L,
            var1
         );
         String var17 = invokeBinding28(
            invokeBinding27(invokeBinding26(invokeBinding25(-6940154420040163054L, var1), -6940515892695801111L, var1), -6940673868368436970L, var1),
            var15,
            -6943397042658601755L,
            var1
         );
         String var18 = invokeBinding31(
            invokeBinding30(invokeBinding29(-6940154420040163054L, var1), -6940515892695801111L, var1), var16, var3, var17, -6942446615326183493L, var1
         );
         FieldAccessMetadata var19 = invokeBinding32(new Object[]{var12, var18, var15, var9}, -6941011477345876720L, var1);
         var14 = new ReflectedField(var19, null);
         ReflectedField var20 = (ReflectedField)invokeBinding33(h, var13, var14, -6940083896410414740L, var1);

         try {
            int var30 = var11;
            ReflectedField var29 = var20;
            ReflectedField var35 = var29;
            ReflectedField var23 = var29;
            if (var30 != 0) {
               return invokeBinding35(var35, new Object[]{var6, var7}, -6943043812351528759L, var1);
            }

            ReflectedField var31 = var23;
            if (var31 == null) {
               break label40;
            }
         } catch (IllegalArgumentException var32) {
            throw invokeBinding34(var32, -6937103774981122201L, var1);
         }

         var14 = var20;
      }

      ReflectedField var36 = var14;
      return invokeBinding35(var36, new Object[]{var6, var7}, -6943043812351528759L, var1);
   
      
}

   public Field aReturningField(Object[] var1) {
      return this.b;
   }

   public Object aReturningObject(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      var3 = 106370906886851L ^ var3;
      long var5 = var3 ^ 96450789532732L;
      int var7 = Event.cReturningInt();

      try {
         int var34 = var7;
         Unsafe var33 = a;
         Object var22 = var33;
         Unsafe var21 = var33;
         if (var34 != 0) {
            Unsafe var35 = var21;
            if (var35 == null) {
               int var38 = var7;
               ReflectedField var37 = this;
               ReflectedField var28 = var37;
               ReflectedField var23 = var37;
               if (var38 != 0) {
                  VarHandle var39 = var23.f;
                  if (var39 != null) {
                     int var41 = var7;
                     ReflectedField var40 = this;
                     Object var27 = var40;
                     ReflectedField var24 = var40;
                     if (var41 != 0) {
                        ReflectedField var42 = var24;
                        ReflectedField var25 = var42;
                        boolean var43 = var25.c;
                        if (var43) {
                           return (Object)this.f.get();
                        }

                        var27 = (Object)this.f.get((Object)var2);
                     }

                     return var27;
                  }

                  var28 = this;
               }

               int var45 = var7;
               ReflectedField var44 = var28;
               Object var31 = var44;
               ReflectedField var29 = var44;
               if (var45 != 0) {
                  boolean var46 = var29.c;
                  if (var46) {
                     Object var18 = null;
                     Field var17 = this.b;
                     return var17.get(var18);
                  }

                  Object var20 = var2;
                  Field var19 = this.b;
                  var31 = var19.get(var20);
               }

               return var31;
            }

            Object[] var11 = new Object[]{var2, var5};
            ReflectedField var10 = this;
            Object var36 = var10.cReturningObject(var11);
            var22 = var36;
         }

         return var22;
      } catch (IllegalAccessException var47) {
         throw new RuntimeException(var47);
      }
   }

    public Object bReturningObject(Object[] objectArray) {

        Object object;
        block8: {
            long l;
            long l2;
            block9: {
                Object object2;
                block10: {
                    block11: {
                        l2 = (Long)objectArray[0];
                        l = (l2 = 0x60BE681E92C3L ^ l2) ^ 0x1446E0B20322L;
                        int n = ReflectedField.invokeBinding36(5621801793238241725L, l2);
                        try {
                            try {
                                try {
                                    try {
                                        object = this;
                                        if (n == 0) break block8;
                                        if (((ReflectedField)object).c) break block9;
                                    }
                                    catch (IllegalArgumentException illegalArgumentException) {
                                        throw ReflectedField.invokeBinding37(illegalArgumentException, 5628681896526431936L, l2);
                                    }
                                    object2 = this.g;
                                    if (n == 0) break block10;
                                }
                                catch (IllegalArgumentException illegalArgumentException) {
                                    throw ReflectedField.invokeBinding38(illegalArgumentException, 5628681896526431936L, l2);
                                }
                                if (object2 != null) break block11;
                            }
                            catch (IllegalArgumentException illegalArgumentException) {
                                throw ReflectedField.invokeBinding39(illegalArgumentException, 5628681896526431936L, l2);
                            }
                            throw new IllegalStateException(ReflectedField.invokeBinding40(9059, 0x4E88DDC4432E8AACL ^ l2));
                        }
                        catch (IllegalArgumentException illegalArgumentException) {
                            throw ReflectedField.invokeBinding41(illegalArgumentException, 5628681896526431936L, l2);
                        }
                    }
                    Object[] objectArray2 = new Object[2];
                    objectArray2[1] = l;
                    objectArray2[0] = this.g;
                    object2 = ReflectedField.invokeBinding42(this, objectArray2, 5621873009206525724L, l2);
                }
                return object2;
            }
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = l;
            objectArray3[0] = null;
            object = ReflectedField.invokeBinding43(this, objectArray3, 5621873009206525724L, l2);
        }
        return object;
    
      
}

   
   
   public void bReturningVoid(Object[] var1) {
      Object var2 = var1[0];
      Object var5 = var1[1];
      long var3 = (Long)var1[2];
      var3 = 106370906886851L ^ var3;
      long var6 = var3 ^ 108657652582656L;
      int var8 = Event.bReturningInt();
      boolean var33 = this.c;
      if (var33) {
         Unsafe var34 = a;
         if (var34 != null) {
            Object[] var12 = new Object[]{null, var5, var6};
            ReflectedField var11 = this;
            var11.dReturningVoid(var12);
         } else {
            int var36 = var8;
            ReflectedField var35 = this;
            ReflectedField var28 = var35;
            ReflectedField var27 = var35;
            if (var36 == 0) {
               VarHandle var37 = var27.f;
               if (var37 != null) {
                  this.f.set((Object)var5);
                  return;
               }

               try {
         dev.prestige.recovery.SourceSupport.<IllegalAccessException>checkedBoundary();

                  var28 = this;
               } catch (IllegalAccessException var43) {
                  throw new RuntimeException(var43);
               }
            }

            try {
               Object var18 = var5;
               Object var17 = null;
               Field var16 = var28.b;
               var16.set(var17, var18);
            } catch (IllegalAccessException var42) {
               throw new RuntimeException(var42);
            }
         }
      } else {
         Unsafe var38 = a;
         if (var38 != null) {
            Object[] var20 = new Object[]{var2, var5, var6};
            ReflectedField var19 = this;
            var19.dReturningVoid(var20);
         } else {
            int var40 = var8;
            ReflectedField var39 = this;
            ReflectedField var31 = var39;
            ReflectedField var30 = var39;
            if (var40 == 0) {
               VarHandle var41 = var30.f;
               if (var41 != null) {
                  this.f.set((Object)var2, (Object)var5);
                  return;
               }

               try {
         dev.prestige.recovery.SourceSupport.<IllegalAccessException>checkedBoundary();

                  var31 = this;
               } catch (IllegalAccessException var45) {
                  throw new RuntimeException(var45);
               }
            }

            try {
               Object var26 = var5;
               Object var25 = var2;
               Field var24 = var31.b;
               var24.set(var25, var26);
            } catch (IllegalAccessException var44) {
               throw new RuntimeException(var44);
            }
         }
      }
   }

   public void cReturningVoid(Object[] var1) {
      Object var4 = var1[0];
      long var2 = (Long)var1[1];
      var2 = 106370906886851L ^ var2;
      long var5 = var2 ^ 97064990161513L;
      int var7 = Event.bReturningInt();
      int var22 = var7;
      ReflectedField var21 = this;
      ReflectedField var20 = var21;
      ReflectedField var16 = var21;
      if (var22 == 0) {
         boolean var23 = var16.c;
         if (!var23) {
            int var25 = var7;
            ReflectedField var24 = this;
            ReflectedField var19 = var24;
            ReflectedField var17 = var24;
            if (var25 == 0) {
               ReflectedField var26 = var17;
               ReflectedField var18 = var26;
               Object var27 = var18.g;
               if (var27 == null) {
                  short var10002 = 22858;
                  long var10003 = 5390207666606651825L ^ var2;
                  throw new IllegalStateException("set(value) without target only valid for static fields or when bound to an instance");
               }

               var19 = this;
            }

            Object[] var13 = new Object[]{this.g, var4, var5};
            ReflectedField var12 = var19;
            var12.bReturningVoid(var13);
            return;
         }

         var20 = this;
      }

      Object[] var15 = new Object[]{null, var4, var5};
      ReflectedField var14 = var20;
      var14.bReturningVoid(var15);
   }

   private Object cReturningObject(Object[] var1) {
      Object var4 = var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 106370906886851L ^ var2;
      int var160 = Event.cReturningInt();
      Field var9 = this.b;
      Class var6 = var9.getType();
      Class var10 = var6;
      boolean var7 = var10.isPrimitive();
      int var5 = var160;
      int var114 = var5;
      ReflectedField var113 = this;
      ReflectedField var81 = var113;
      ReflectedField var80 = var113;
      Object var82;
      if (var114 != 0) {
         boolean var115 = var80.c;
         if (var115) {
            Object var116 = this.d;
            var82 = var116;
         } else {
            var82 = var4;
         }
      } else {
         ReflectedField var117 = var81;
         var82 = var117;
      }

      Object var8 = var82;
      boolean var118 = var7;
      if (!var118) {
         long var15 = this.e;
         Object var14 = var8;
         Unsafe var13 = a;
         return var13.getObject(var14, var15);
      }

      int var121 = var5;
      Class var120 = int.class;
      Class var119 = var6;
      Class var85 = var119;
      Class var86 = var120;
      Class var83 = var119;
      Class var84 = var120;
      if (var121 != 0) {
         Class var123 = var84;
         Class var122 = var83;
         if (var122 == var123) {
            long var21 = this.e;
            Object var20 = var8;
            Unsafe var19 = a;
            int var23 = var19.getInt(var20, var21);
            return var23;
         }

         var86 = long.class;
         var85 = var6;
      }

      int var126 = var5;
      Class var125 = var86;
      Class var124 = var85;
      Class var89 = var124;
      Class var90 = var125;
      Class var87 = var124;
      Class var88 = var125;
      if (var126 != 0) {
         Class var128 = var88;
         Class var127 = var87;
         if (var127 == var128) {
            long var28 = this.e;
            Object var27 = var8;
            Unsafe var26 = a;
            long var30 = var26.getLong(var27, var28);
            return var30;
         }

         var90 = boolean.class;
         var89 = var6;
      }

      int var131 = var5;
      Class var130 = var90;
      Class var129 = var89;
      Class var93 = var129;
      Class var94 = var130;
      Class var91 = var129;
      Class var92 = var130;
      if (var131 != 0) {
         Class var133 = var92;
         Class var132 = var91;
         if (var132 == var133) {
            long var36 = this.e;
            Object var35 = var8;
            Unsafe var34 = a;
            boolean var38 = var34.getBoolean(var35, var36);
            return var38;
         }

         var94 = byte.class;
         var93 = var6;
      }

      int var136 = var5;
      Class var135 = var94;
      Class var134 = var93;
      Class var97 = var134;
      Class var98 = var135;
      Class var95 = var134;
      Class var96 = var135;
      if (var136 != 0) {
         Class var138 = var96;
         Class var137 = var95;
         if (var137 == var138) {
            long var43 = this.e;
            Object var42 = var8;
            Unsafe var41 = a;
            byte var45 = var41.getByte(var42, var43);
            return var45;
         }

         var98 = char.class;
         var97 = var6;
      }

      int var141 = var5;
      Class var140 = var98;
      Class var139 = var97;
      Class var101 = var139;
      Class var102 = var140;
      Class var99 = var139;
      Class var100 = var140;
      if (var141 != 0) {
         Class var143 = var100;
         Class var142 = var99;
         if (var142 == var143) {
            long var50 = this.e;
            Object var49 = var8;
            Unsafe var48 = a;
            char var52 = var48.getChar(var49, var50);
            return var52;
         }

         var102 = short.class;
         var101 = var6;
      }

      int var146 = var5;
      Class var145 = var102;
      Class var144 = var101;
      Class var105 = var144;
      Class var106 = var145;
      Class var103 = var144;
      Class var104 = var145;
      if (var146 != 0) {
         Class var148 = var104;
         Class var147 = var103;
         if (var147 == var148) {
            long var57 = this.e;
            Object var56 = var8;
            Unsafe var55 = a;
            short var59 = var55.getShort(var56, var57);
            return var59;
         }

         var106 = float.class;
         var105 = var6;
      }

      int var151 = var5;
      Class var150 = var106;
      Class var149 = var105;
      Class var110 = var149;
      Class var111 = var150;
      Class var107 = var149;
      Class var108 = var150;
      if (var151 != 0) {
         Class var153 = var108;
         Class var152 = var107;
         if (var152 == var153) {
            long var64 = this.e;
            Object var63 = var8;
            Unsafe var62 = a;
            float var66 = var62.getFloat(var63, var64);
            return var66;
         }

         int var155 = var5;
         Class var154 = var6;
         Class var112 = var154;
         Class var109 = var154;
         if (var155 == 0) {
            return var112;
         }

         Class var157 = double.class;
         Class var156 = var109;
         var110 = var156;
         var111 = var157;
      }

      Class var159 = var111;
      Class var158 = var110;
      if (var158 == var159) {
         long var71 = this.e;
         Object var70 = var8;
         Unsafe var69 = a;
         double var73 = var69.getDouble(var70, var71);
         return var73;
      } else {
         long var78 = this.e;
         Object var77 = var8;
         Unsafe var76 = a;
         return var76.getObject(var77, var78);
      }
   }

   private void dReturningVoid(Object[] var1) {
      Object var5 = var1[0];
      Object var2 = var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 106370906886851L ^ var3;
      int var190 = Event.cReturningInt();
      Field var9 = this.b;
      Class var7 = var9.getType();
      int var6 = var190;
      int var125 = var6;
      ReflectedField var124 = this;
      ReflectedField var92 = var124;
      ReflectedField var91 = var124;
      Object var93;
      if (var125 != 0) {
         boolean var126 = var91.c;
         if (var126) {
            Object var127 = this.d;
            var93 = var127;
         } else {
            var93 = var5;
         }
      } else {
         ReflectedField var128 = var92;
         var93 = var128;
      }

      Object var8 = var93;
      int var130 = var6;
      Class var129 = var7;
      Class var95 = var129;
      Class var94 = var129;
      if (var130 != 0) {
         Class var12 = var94;
         boolean var131 = var12.isPrimitive();
         if (!var131) {
            Object var18 = var2;
            long var16 = this.e;
            Object var15 = var8;
            Unsafe var14 = a;
            var14.putObject(var15, var16, var18);
            return;
         }

         var95 = var7;
      }

      int var134 = var6;
      Class var133 = int.class;
      Class var132 = var95;
      Class var98 = var132;
      Class var99 = var133;
      Class var96 = var132;
      Class var97 = var133;
      if (var134 != 0) {
         Class var136 = var97;
         Class var135 = var96;
         if (var135 == var136) {
            Unsafe var191 = a;
            long var10002 = this.e;
            Number var21 = (Number)var2;
            int var26 = var21.intValue();
            long var24 = var10002;
            Object var23 = var8;
            Unsafe var22 = var191;
            var22.putInt(var23, var24, var26);
            int var137 = var6;
            if (var137 != 0) {
               return;
            }
         }

         Class var139 = long.class;
         Class var138 = var7;
         var98 = var138;
         var99 = var139;
      }

      int var142 = var6;
      Class var141 = var99;
      Class var140 = var98;
      Class var102 = var140;
      Class var103 = var141;
      Class var100 = var140;
      Class var101 = var141;
      if (var142 != 0) {
         Class var144 = var101;
         Class var143 = var100;
         if (var143 == var144) {
            Unsafe var192 = a;
            long var199 = this.e;
            Number var30 = (Number)var2;
            long var35 = var30.longValue();
            long var33 = var199;
            Object var32 = var8;
            Unsafe var31 = var192;
            var31.putLong(var32, var33, var35);
            int var145 = var6;
            if (var145 != 0) {
               return;
            }
         }

         Class var147 = boolean.class;
         Class var146 = var7;
         var102 = var146;
         var103 = var147;
      }

      int var150 = var6;
      Class var149 = var103;
      Class var148 = var102;
      Class var106 = var148;
      Class var107 = var149;
      Class var104 = var148;
      Class var105 = var149;
      if (var150 != 0) {
         Class var152 = var105;
         Class var151 = var104;
         if (var151 == var152) {
            Unsafe var193 = a;
            long var200 = this.e;
            Boolean var40 = (Boolean)var2;
            boolean var45 = var40;
            long var43 = var200;
            Object var42 = var8;
            Unsafe var41 = var193;
            var41.putBoolean(var42, var43, var45);
            int var153 = var6;
            if (var153 != 0) {
               return;
            }
         }

         Class var155 = byte.class;
         Class var154 = var7;
         var106 = var154;
         var107 = var155;
      }

      int var158 = var6;
      Class var157 = var107;
      Class var156 = var106;
      Class var110 = var156;
      Class var111 = var157;
      Class var108 = var156;
      Class var109 = var157;
      if (var158 != 0) {
         Class var160 = var109;
         Class var159 = var108;
         if (var159 == var160) {
            Unsafe var194 = a;
            long var201 = this.e;
            Number var49 = (Number)var2;
            byte var54 = var49.byteValue();
            long var52 = var201;
            Object var51 = var8;
            Unsafe var50 = var194;
            var50.putByte(var51, var52, var54);
            int var161 = var6;
            if (var161 != 0) {
               return;
            }
         }

         Class var163 = char.class;
         Class var162 = var7;
         var110 = var162;
         var111 = var163;
      }

      int var166 = var6;
      Class var165 = var111;
      Class var164 = var110;
      Class var114 = var164;
      Class var115 = var165;
      Class var112 = var164;
      Class var113 = var165;
      if (var166 != 0) {
         Class var168 = var113;
         Class var167 = var112;
         if (var167 == var168) {
            Unsafe var195 = a;
            long var202 = this.e;
            Character var58 = (Character)var2;
            char var63 = var58;
            long var61 = var202;
            Object var60 = var8;
            Unsafe var59 = var195;
            var59.putChar(var60, var61, var63);
            int var169 = var6;
            if (var169 != 0) {
               return;
            }
         }

         Class var171 = short.class;
         Class var170 = var7;
         var114 = var170;
         var115 = var171;
      }

      int var174 = var6;
      Class var173 = var115;
      Class var172 = var114;
      Class var118 = var172;
      Class var119 = var173;
      Class var116 = var172;
      Class var117 = var173;
      if (var174 != 0) {
         Class var176 = var117;
         Class var175 = var116;
         if (var175 == var176) {
            Unsafe var196 = a;
            long var203 = this.e;
            Number var67 = (Number)var2;
            short var72 = var67.shortValue();
            long var70 = var203;
            Object var69 = var8;
            Unsafe var68 = var196;
            var68.putShort(var69, var70, var72);
            int var177 = var6;
            if (var177 != 0) {
               return;
            }
         }

         Class var179 = float.class;
         Class var178 = var7;
         var118 = var178;
         var119 = var179;
      }

      int var182 = var6;
      Class var181 = var119;
      Class var180 = var118;
      Class var122 = var180;
      Class var123 = var181;
      Class var120 = var180;
      Class var121 = var181;
      if (var182 != 0) {
         Class var184 = var121;
         Class var183 = var120;
         if (var183 == var184) {
            Unsafe var197 = a;
            long var204 = this.e;
            Number var76 = (Number)var2;
            float var81 = var76.floatValue();
            long var79 = var204;
            Object var78 = var8;
            Unsafe var77 = var197;
            var77.putFloat(var78, var79, var81);
            int var185 = var6;
            if (var185 != 0) {
               return;
            }
         }

         Class var187 = double.class;
         Class var186 = var7;
         var122 = var186;
         var123 = var187;
      }

      Class var189 = var123;
      Class var188 = var122;
      if (var188 == var189) {
         Unsafe var198 = a;
         long var205 = this.e;
         Number var84 = (Number)var2;
         double var89 = var84.doubleValue();
         long var87 = var205;
         Object var86 = var8;
         Unsafe var85 = var198;
         var85.putDouble(var86, var87, var89);
      }
   }

   public BoundFieldAccessor dReturningbN_C0083(Object[] var1) {
      Object var4 = var1[0];
      long var2 = (Long)var1[1];
      var2 = 106370906886851L ^ var2;
      Object var5 = var4;
      if (var5 == null) {
         short var8 = 19362;
         long var9 = 4079154354157505316L ^ var2;
         throw new IllegalArgumentException("target cannot be null for instance bind");
      } else {
         boolean var6 = this.c;
         if (var6) {
            short var10002 = 953;
            long var10003 = 1763997976237146941L ^ var2;
            throw new IllegalStateException("Cannot bind static field to instance; access static field via get()/set() or FieldAccessor.of(Class,..)");
         } else {
            return new BoundFieldAccessor(this, var4);
         }
      }
   }

    public BoundFieldAccessor e(Object[] objectArray) {

        Object object;
        long l;
        block7: {
            block8: {
                l = (Long)objectArray[0];
                l = 0x60BE681E92C3L ^ l;
                int n = ReflectedField.invokeBinding44(-668335898818172672L, l);
                try {
                    try {
                        object = this;
                        if (n == 0) break block7;
                        if (!((ReflectedField)object).c) break block8;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedField.invokeBinding45(illegalArgumentException, -675497456545104259L, l);
                    }
                    throw new IllegalStateException(ReflectedField.invokeBinding46(14622, 0x6835A94B83C1A86FL ^ l));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedField.invokeBinding47(illegalArgumentException, -675497456545104259L, l);
                }
            }
            object = this.g;
        }
        try {
            if (object == null) {
                throw new IllegalStateException(ReflectedField.invokeBinding48(22241, 0x3AA368B46AFCC794L ^ l));
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw ReflectedField.invokeBinding49(illegalArgumentException, -675497456545104259L, l);
        }
        return new BoundFieldAccessor(this, this.g);
    
      
}

   public BoundFieldAccessor f(Object[] var1) {
      Object var4 = var1[0];
      long var2 = (Long)var1[1];
      var2 = 106370906886851L ^ var2;
      long var5 = var2 ^ 6224392671558L;
      return invokeBinding50(this, new Object[]{var4, var5}, -6572404860272047194L, var2);
   }

   public static FieldAccessor aReturningbO_C0085(Object[] var0) {
      Class var1 = (Class)var0[0];
      String var5 = (String)var0[1];
      Class var2 = (Class)var0[2];
      long var3 = (Long)var0[3];
      var3 = 106370906886851L ^ var3;
      long var6 = var3 ^ 61234932510417L;
      long var8 = var3 ^ 53645147180684L;
      long var10 = var3 ^ 125027315129742L;

      try {
         Class var17 = var2;
         String var12 = ASMUtils.toFieldDescriptor(var17);
         AMapper var18 = TransformerManager.getRemapper();
         MapRemapper var19 = var18.getRemapper();
         MapRemapper var10000 = var19.reverse();
         Class var20 = var1;
         String var10001 = var20.getName();
         short var10002 = 8471;
         long var10003 = 6534540305666550051L ^ var3;
         byte var42 = 46;
         short var43 = 4234;
         long var10004 = 245226838069680316L ^ var3;
         String var21 = var10001;
         String var25 = var21.replace('.', '/');
         MapRemapper var24 = var10000;
         String var13 = var24.map(var25);
         AMapper var26 = TransformerManager.getRemapper();
         MapRemapper var27 = var26.getRemapper();
         var10000 = var27.reverse();
         String var29 = var12;
         MapRemapper var28 = var10000;
         String var14 = var28.mapDesc(var29);
         AMapper var30 = TransformerManager.getRemapper();
         var10000 = var30.getRemapper();
         String var34 = var14;
         String var33 = var5;
         String var32 = var13;
         MapRemapper var31 = var10000;
         String var15 = var31.mapFieldName(var32, var33, var34);
         Object[] var35 = new Object[]{var1, var15, var12, var8};
         FieldAccessMetadata var16 = ReflectionUtil.bReturningcU_C0151(var35);
         return new FieldAccessor(var16, var6);
      } catch (Throwable var38) {
         return new FieldAccessor(var1, var5, var2, var10);
      }
   }

   static {

      {

      c();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(82341367190307L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[8];
      String var17 = "Y\u0017\u0094X\u0099:ÛÁ}Ë\tÊ¡ú\u001b.ÔÃÃµd¼\u009fg\u0006\u0000jt8=»¤Ï{PSìMÏ\u009a<Æª\u0016`\u001c£7ÉØÄ\u0003\u008fé\u0098öÅ\u009c@¼Øl\u001a½Zë\u000fJ¶\u0018@ÚM\u0011E\u0000Â9\u009a\u009eî&\u0002*³B\u001a\u008c |KåqÁØ,¤ÎÂ>G9SJ=\tÅ\u0098®YîÛà\u0003\u0094Ùmøê¨\\®\u0003nå(<ù\u0014´Íî§:¯¥q\rú\u0010\bhÛ¤?øMà\u0011£àç.\u0096 Ø¼è\u0098#¬ßú\u009b\u009aÜÛ\u0003ÁÄ[+\u0094öÁ\u0095+\u0084Ãª4Tl^éCmÿq#m`\u009eá¼\\T¡ô.Æn·>s\u009f¯µ\u0013\u0000ú@\u008fÈÅêZö?\r¢\u009dg¬5\u0014\u009fÍ\u008e\u001bYér\u001a\u008e«\u0091o\u008ebI<\u009dÜy \"\u001b¦(\u0088A¨8¼\"æà\u0083¢\u0091ç~\u0094\u009fÎ\u0004«\u0093DÐ\u009d¹ã\u0019rG\u0005l¿.\b\u001cé/¦i\u0094Ò¶H¢ÿLø0*Ó+jî\u0018÷Dº\tþ9\u0018£\u0001\u008dlìÑÎ\u0097\u009fé\u0082V<fíÅ\u0093u6ê <q\u0080\u0017jIê¾6\u0081\u0097hfë%á[\u009f·\u0012\u001a©å§t\u0006\u0018úßPnÆ<¨\u0085«2Î\u001a\u0019§5X\u0098\u0081ÃÃ!yKr\u0091\u0082W\u0015\u0018¤\u008a8\u008d¤\u0093{\u009f»¡Miâ@y\u008doÐe@®,\u0081Äê\u0098B\u0095=Æ:,ö¹ \u0090_\u0095\u0087\u0005à!14bÜßÍWy(.S}÷Å\u0085\u0087ë¶øK;ðº¤\u0097J\u0081z\u0089\u0010½\u0000l0{\u0002Í\\o)MT2ÞØ\u009f \u0098Åq\u007fà\u0091f\u009dÔQ\u009a wÖ<2(û\u0098\u0092ê*-µRßÉ\u0006¸L¶=v3²BÈ\u008c\u009d\u008aÅ\tá\u0094`\u0099ï,êÔý¤n+_k\u001f\u0088q«\u009có\u0010\b\u0012(u\u0083D^WmdeÊZ\u0092¼Õ`õ\u0097vÊÑ\u0097\\ì¥\u0001ÌVn÷\u0094r[q\u0088=¶«\u0087k{£Ú½6Ú4ÔýZ¤\u009b\u0097¸s\u008b,=È&²Å\u008d Éõ«ÿâ\u0096\u001c<Ì¤k\u0012Z-\u0098.ué$÷{ \u0094»n¬\u009cõ\u0082T\u0098gjµ\bÛzO$aß¹Ç\u0093\u0000LmÍy\u0090çù'\u0019\u0018äîù\u007f0\u000bÁ\u009eÓåJ";
      int var19 = "Y\u0017\u0094X\u0099:ÛÁ}Ë\tÊ¡ú\u001b.ÔÃÃµd¼\u009fg\u0006\u0000jt8=»¤Ï{PSìMÏ\u009a<Æª\u0016`\u001c£7ÉØÄ\u0003\u008fé\u0098öÅ\u009c@¼Øl\u001a½Zë\u000fJ¶\u0018@ÚM\u0011E\u0000Â9\u009a\u009eî&\u0002*³B\u001a\u008c |KåqÁØ,¤ÎÂ>G9SJ=\tÅ\u0098®YîÛà\u0003\u0094Ùmøê¨\\®\u0003nå(<ù\u0014´Íî§:¯¥q\rú\u0010\bhÛ¤?øMà\u0011£àç.\u0096 Ø¼è\u0098#¬ßú\u009b\u009aÜÛ\u0003ÁÄ[+\u0094öÁ\u0095+\u0084Ãª4Tl^éCmÿq#m`\u009eá¼\\T¡ô.Æn·>s\u009f¯µ\u0013\u0000ú@\u008fÈÅêZö?\r¢\u009dg¬5\u0014\u009fÍ\u008e\u001bYér\u001a\u008e«\u0091o\u008ebI<\u009dÜy \"\u001b¦(\u0088A¨8¼\"æà\u0083¢\u0091ç~\u0094\u009fÎ\u0004«\u0093DÐ\u009d¹ã\u0019rG\u0005l¿.\b\u001cé/¦i\u0094Ò¶H¢ÿLø0*Ó+jî\u0018÷Dº\tþ9\u0018£\u0001\u008dlìÑÎ\u0097\u009fé\u0082V<fíÅ\u0093u6ê <q\u0080\u0017jIê¾6\u0081\u0097hfë%á[\u009f·\u0012\u001a©å§t\u0006\u0018úßPnÆ<¨\u0085«2Î\u001a\u0019§5X\u0098\u0081ÃÃ!yKr\u0091\u0082W\u0015\u0018¤\u008a8\u008d¤\u0093{\u009f»¡Miâ@y\u008doÐe@®,\u0081Äê\u0098B\u0095=Æ:,ö¹ \u0090_\u0095\u0087\u0005à!14bÜßÍWy(.S}÷Å\u0085\u0087ë¶øK;ðº¤\u0097J\u0081z\u0089\u0010½\u0000l0{\u0002Í\\o)MT2ÞØ\u009f \u0098Åq\u007fà\u0091f\u009dÔQ\u009a wÖ<2(û\u0098\u0092ê*-µRßÉ\u0006¸L¶=v3²BÈ\u008c\u009d\u008aÅ\tá\u0094`\u0099ï,êÔý¤n+_k\u001f\u0088q«\u009có\u0010\b\u0012(u\u0083D^WmdeÊZ\u0092¼Õ`õ\u0097vÊÑ\u0097\\ì¥\u0001ÌVn÷\u0094r[q\u0088=¶«\u0087k{£Ú½6Ú4ÔýZ¤\u009b\u0097¸s\u008b,=È&²Å\u008d Éõ«ÿâ\u0096\u001c<Ì¤k\u0012Z-\u0098.ué$÷{ \u0094»n¬\u009cõ\u0082T\u0098gjµ\bÛzO$aß¹Ç\u0093\u0000LmÍy\u0090çù'\u0019\u0018äîù\u007f0\u000bÁ\u009eÓåJ"
         .length();
      char var16 = 'X';
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     n = var20;
                     o = new String[8];
                     v = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(82341367190307L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     String var4 = "#g\u0003\u007f¼(µ¾[ÄæoRE¹(";
                     int var5 = "#g\u0003\u007f¼(µ¾[ÄæoRE¹(".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    t = var6;
                                    u = new Integer[4];
                                    h = new ConcurrentHashMap();
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "8&§LÂ;Aãm\u0016Aë=\u009d¦\u008f";
                                 var5 = "8&§LÂ;Aãm\u0016Aë=\u009d¦\u008f".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "!à>\u0080\u0005b\u00996®\u009fÆPáWÒ!L'U\u0016-;ð¨:xª>¼°\u0012GÂ«\u0004\u009d\u001bÎ#@xñØQÎ\u0011\u0099iIÉì¤°\u0096\u001eÊêgN»|\u001c'ÅRC»RÅ7â\rËÙ£0\u008fç?'W«Í'K \u001bÐ\u0016\u0012´ Zï\u009d\u001c\u0004ÖùQ\u0019W\u007f\u009fÆ¸\u0086â¤<Ôå\u0092lÝ\u001cÖ\u0000Îkk\\ý6\u0012e½\u0018kf\n\"\nd\\ê~\u0088\r¸L5¨±\u0080þ}îü.\u0086\u0001èh@\u0016\u001f\u0087\u000e\u0092©";
                  var19 = "!à>\u0080\u0005b\u00996®\u009fÆPáWÒ!L'U\u0016-;ð¨:xª>¼°\u0012GÂ«\u0004\u009d\u001bÎ#@xñØQÎ\u0011\u0099iIÉì¤°\u0096\u001eÊêgN»|\u001c'ÅRC»RÅ7â\rËÙ£0\u008fç?'W«Í'K \u001bÐ\u0016\u0012´ Zï\u009d\u001c\u0004ÖùQ\u0019W\u007f\u009fÆ¸\u0086â¤<Ôå\u0092lÝ\u001cÖ\u0000Îkk\\ý6\u0012e½\u0018kf\n\"\nd\\ê~\u0088\r¸L5¨±\u0080þ}îü.\u0086\u0001èh@\u0016\u001f\u0087\u000e\u0092©"
                     .length();
                  var16 = '(';
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26584;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cR", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cR_C0145",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 720;
      if (u[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = t[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])v.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               v.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cR", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         u[var3] = var15;
      }

      return u[var3];
   }

   private static int d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = d(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cR_C0145",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = C[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = B[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 4;
            yield var15;
         }
         case 1 -> {
            byte var16 = 41;
            yield var16;
         }
         case 2 -> {
            byte var17 = 48;
            yield var17;
         }
         case 3 -> {
            byte var18 = 22;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 0;
            yield var20;
         }
         case 6 -> {
            byte var21 = 32;
            yield var21;
         }
         case 7 -> {
            byte var22 = 21;
            yield var22;
         }
         case 8 -> {
            byte var23 = 15;
            yield var23;
         }
         case 9 -> {
            byte var24 = 2;
            yield var24;
         }
         case 10 -> {
            byte var25 = 3;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 54;
            yield var27;
         }
         case 13 -> {
            byte var28 = 16;
            yield var28;
         }
         case 14 -> {
            byte var29 = 62;
            yield var29;
         }
         case 15 -> {
            byte var30 = 58;
            yield var30;
         }
         case 16 -> {
            byte var31 = 46;
            yield var31;
         }
         case 17 -> {
            byte var32 = 36;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 50;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 19;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 24;
            yield var38;
         }
         case 24 -> {
            byte var39 = 35;
            yield var39;
         }
         case 25 -> {
            byte var40 = 1;
            yield var40;
         }
         case 26 -> {
            byte var41 = 53;
            yield var41;
         }
         case 27 -> {
            byte var42 = 13;
            yield var42;
         }
         case 28 -> {
            byte var43 = 33;
            yield var43;
         }
         case 29 -> {
            byte var44 = 18;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 27;
            yield var46;
         }
         case 32 -> {
            byte var47 = 38;
            yield var47;
         }
         case 33 -> {
            byte var48 = 61;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 8;
            yield var50;
         }
         case 36 -> {
            byte var51 = 28;
            yield var51;
         }
         case 37 -> {
            byte var52 = 56;
            yield var52;
         }
         case 38 -> {
            byte var53 = 60;
            yield var53;
         }
         case 39 -> {
            byte var54 = 14;
            yield var54;
         }
         case 40 -> {
            byte var55 = 11;
            yield var55;
         }
         case 41 -> {
            byte var56 = 29;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 40;
            yield var59;
         }
         case 45 -> {
            byte var60 = 5;
            yield var60;
         }
         case 46 -> {
            byte var61 = 7;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 23;
            yield var63;
         }
         case 49 -> {
            byte var64 = 42;
            yield var64;
         }
         case 50 -> {
            byte var65 = 39;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 47;
            yield var67;
         }
         case 53 -> {
            byte var68 = 49;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 10;
            yield var70;
         }
         case 56 -> {
            byte var71 = 55;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 57;
            yield var73;
         }
         case 59 -> {
            byte var74 = 51;
            yield var74;
         }
         case 60 -> {
            byte var75 = 26;
            yield var75;
         }
         case 61 -> {
            byte var76 = 43;
            yield var76;
         }
         case 62 -> {
            byte var77 = 9;
            yield var77;
         }
         default -> 30;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            C[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      B[0] = "\u0017\u000e6\u0007E\u0014\u001c\u0001'H8\f\u000f\u0006.\u0001";
      B[1] = char.class;
      C[1] = "java/lang/Character";
      B[2] = "LD\u001f!E\u0000LO\u0002?\u001dP\u0013\u000f\bcH\u0016QU\u0019nG\u0016DN\u0019b\u0007\u0010VH\u0007|\u0007\bCQ\u001bfG\u0002Q\u000f&nY7GL\n\u007fY\u0000P";
      B[3] = "O,wb\u0000KY,r8\u0013\\Ngq>\u001fH_ f)TZn";
      B[4] = int.class;
      C[4] = "java/lang/Integer";
      B[5] = ":\u0010MK`\",\u0010H\u0011s5;[K\u0017\u007f!*\u001c\\\u000041\f";
      B[6] = "O\u001bq\u000e~j:;z\u0001o%[5q\nk\u007f/";
      B[7] = "\u0010\u007fXr5\u0016\u0006\u007f](&\u0001\u00114^.*\u0015\u0000sI9a\u0004:";
      B[8] = "\u001aY$7{\n\u0011V5x\u0016\n\u0011K!";
      B[9] = "ZXxK\u0010IZSeUH\u0019\u0005\u0013o\t\u001d_GI~\u0004\u0012_RR~\bRxF\\b\u0016\u001aCFPi\u00171MZ\\k\u0000\u000e";
      B[10] = "e\u000f\u0000ny>e\u0004\u001dp!n:D\u0017,t(x\u001e\u0006!{(m\u0005\u0006-;6j\u001a\u0004){<xD5\rt+{\u000f\u0006";
      B[11] = "A5w\f\u0001Y_=mCLCE7t\u001f]IE /.@BH!s\u001fJB_\u001c`\u001eGaJ$";
      B[12] = "TH!7cX_G0x\u0002VTL4\"";
      B[13] = "i=,nWO\u007f=)4DXhv*2HLy1=%\u0003\\\\";
      B[14] = "T2C~\u0010X!\u0012Hq\u0001\u0017@\u001cCz\u0005M4";
      B[15] = "If\u0001rT1_f\u0004(G&H-\u0007.K2Yj\u00109\u0000\"x";
      B[16] = "W_$j'\u001f\\P5%L\u000b^[\"\u007f`\u001cS";
      B[17] = "\u0011\u0005L\u001b\u001f[d%G\u0014\u000e\u0014\u0005+L\u001f\nNq";
      B[18] = void.class;
      C[18] = "java/lang/Void";
      B[19] = "]%\u0007\u0006\u0016)(\u0005\f\t\u0007fI\u000b\u0007\u0002\u0003<=";
      B[20] = "\u000fP\bAov\u000f[\u0015_7&P\u001b\u001f\u0003b`\u0012A\u000e\u000em`\u0007Z\u000e\u0002-f\u0015\\\u0010\u001c-R2x)\u001bj\u007f\u0012";
      B[21] = boolean.class;
      C[21] = "java/lang/Boolean";
      B[22] = "\u0005S\b\b|\b\u000e\\\u0019G\u0010\u000b\u0000^\u001b\b<";
      B[23] = "o\u00102<\u00129d\u001f#s\u007f=d\u0003%>H0w";
      B[24] = "`\fDGk\u0010`\u001a\u0004<h\nr\u001fO";
      B[25] = long.class;
      C[25] = "java/lang/Long";
      B[26] = "f{s_\u0013bmtb\u0010qab}";
      B[27] = "\u000ezM\u0001+e\u0005u\\NVa\u000biO";
      B[28] = "\u000bb\u001b\u0016``\u0000m\nY\b`\u000eb\u0019";
      B[29] = "%?,pKS.0=?'F;;";
      B[30] = "\u0011di\u0016I\u0003\u001akxY\u0015\n\u001diz\u0014\u0013A=lz\u001b\u0003";
      B[31] = byte.class;
      C[31] = "java/lang/Byte";
      B[32] = double.class;
      C[32] = "java/lang/Double";
      B[33] = short.class;
      C[33] = "java/lang/Short";
      B[34] = "(pX#FT#\u007fIl!V6tI'\u001a";
      B[35] = float.class;
      C[35] = "java/lang/Float";
      B[36] = "&@iR\u001a\u000f-Ox\u001dp\f9CsV";
      B[37] = "\u001bmJ$\u000e2nMA+\u001f}\u000fCJ \u001b'{";
      B[38] = "\u0011\u0019I[4gd9BT%(\u00057I_!rq";
      B[39] = "h\u0003cc^q\u001d#hlO>|-cgKd\b";
      B[40] = "(zc\u0012\t\\#ur]iE/yp\u0001";
      B[41] = "3/s\u000527F\u000fx\n#x'\u0001s\u0001'\"S";
      B[42] = "\bV*\u001bC*}v!\u0014Re\u001cx*\u001fV?h";
      B[43] = "\\]ZD\"?\u000f^^C\u0012/`\u001bW]|\u007f\u000f\u0001HX|E\\]ZD\"?\u000f^^C\u0012";
      B[44] = "3\u0003j\u001fg\\*\u00156\u0003^|\u0000'AfcC \u00021_7@7\u0002";
      B[45] = "#Wtt\u0010\u0019\"N)ba\u0014!VXr\b\u0001L\u001as+[\u0019+Jvn\u0004{,J,#\u0011\u00116UauaBuUiu\u0005\u00175Qs\u0012";
      B[46] = "\fO\u000ePf\u000e\rVSF\u0017\u0003\u000eN#Gk\u0001c\u0002\t\u000f-\u000e\u0004R\fJrl\u0003RV\u0007g\u0006\u0019M\u001bQ\u0017\b\u001dR\u0016O+\u000b\fR\u00076";
      B[47] = "`m5>B\u00153n19r\u0002\\+8'\u001cU31'\"\u001coa>$c\u0015^;8\"0r";
      B[48] = "A .\bHJ\u0010!$\u00031/q\u0016Yi\f\u0010Q3)PX\u0013F3";
      B[49] = "Se|Z8J\u0011;{\u0001IN\u000e%\u001b[)\u0018Y;|\u000b,]\u0006Y+\u000bp\u001b\u0001>{\u000e5Dc";
      B[50] = "z\u000ez7Tn{\u0017'!%cx\u000fY6Cc\u0015C}h\u001fnr\u0013x-@\fu\u0013\"`Ufo\fo6%luL,!Ovj\u0001zQ";
      B[51] = "\u0000j'D(I\u0001szRYS\u0012k\fE$A\u000bz@\u00129\u0012Uu'B<W\n\u0017 Bf\u001a\u001f}:]+Lor<R#F^l1\u00198+\u0004s%K2VQ(1GY";
      B[52] = "o\u000b|DSTn\u0012!R\"N}\n_EDY\u0000F{\u001b\u0018Tg\u0016~^G6`\u0016$\u0013R\\z\tiE\"V`I*RHL\u007f\u0004|\"IRe\u001fp_\u001c\tq\u0013\u001b";
      B[53] = "\u0002c\u0003SH]Q`\u0007TxN>3\u0004S\u0014D\u00020\u0007\b\u001e'T5\f[\u001b\u001bW6WQx";
      B[54] = "\u000f\u0000+P;K\u000e\u0019vFJF\r\u0001\u0017V-S\u001c}|Vs\u0013\u0002\u001a,S6L`\u001d,\t{Y\n\u00073D-)\u0006M>W4\u0016\u0007\u0000)FJ";
      B[55] = "\f\u0018D\u0011LE\r\u0001\u0019\u0007=_\u001e\u0019m\u0013ZN\u001fe\u0013\u0017\u0004\u001d\u0001\u0002C\u0012ABc\u0005CH\fW\t\u001f\\\u0005Z'\u0004\u0004GO\u0003I[\\\u0012L=L\u0007\u0000J\u001c@\u0019\\\u0014Fw";
      B[56] = "\u0012\u0014F\u00162sA\u0017B\u0011\u0002b.RK\u000fl3AHT\nl\t\u001eN\u0014H`nNKQ\u0017\u0002";
      B[57] = "4m\\i*\u0014bt\u0007`T\r;`GT=\u0002&d=3m\u0019!nYf-\u001d;\t";
      B[58] = "e)Wx\u001c\u001dd0\nnm\u0007w(wt\u000f\u0012a(0.\rF06W~\b\u0003oTP~RNz>Ja\u001f\u0018\ndP'W\u001dm4Ub\b\u007fa0Uw\u0006\u00024kA{m";
      B[59] = "\u0011!X|W]U;\u0006(,X\u001a-\u000eOEV\u0016<cuRR\u0014(_vCR\u0005Q";
      B[60] = "\u0012gTW;i\u0013~\tAJd\u0010f}U-b\u0001\u001a\u0003Qs1\u001f}ST6n}zS\u000e{{\u0017`LC-\u000b\u001a{W\tteE#\u0002\nJ";
      B[61] = "?\u0002z\u0010xc>\u001b'\u0006\ty-\u0003W\u0011ne=\u0016{v9aiE\u007f\u0011id,\u001a\u001d\u0016i>a\u000fw\fvs7\u007fp\u00121`*\u0004w\u0018m>P\u0014y\u0013`j-A\"\u0007l\u0001";
      B[62] = "yJ\u0001<K^*I\u0005;{HE\f\f%\u0015\u001e*\u0016\u0013 \u0015$.\u0014\u000f1\u0010Y{O\u001b={";
      B[63] = "O\u0018\u001dFW V\u000eAZn\"D\u0000\u0006R)2-\u0003\u001a[VbC\\B\u000eU\\O\u0018\u001dFW V\u000eAZn";
      B[64] = "$.a-x;r7:$\u00067\".}#A'Ks91|./&y5fI$.a-x;r7:$\u0006";
      B[65] = "R\u00052d,\u001d\nVf M\u001c\u0002\u0012\u0019< \u001d\u0007,>8 y\u000b\f913\u0005\t\u000f,]-\u001f\u0005\u0006)!/\u001c\u0010j7;#\u0015\u0015\u0016586y\u000b\f913\u0005\t\u000f,]";
      B[66] = "\\v\u0004\u001cSN\u0002z\u0007\\bYV.\u0006I%I?.\u0005D\u001d^\u0003-\u0014D\f'\\v\u0004\u001cSN\u0002z\u0007\\b";
      B[67] = "\u001d$\u00041\n<\u001f'\u0011]\u000e-\u0005&\u00036\u0019@D{\u0015'\u0013$\u0011;\u0011=tyD=\u0010:\u0010,\u00049\n]\u0014&\u0013.\u0014!\u0016%\u0006B";
      B[68] = "\u001dV\b\u000b,\u001cIU\u001f\u000b\u0011D[m\u0003\u0017tD\\T\u0007\u001b\u0011HD\r\u0018\fjONQFv";
      B[69] = "\u0007}\u001a\u001b!P_.N_@QWj\u007fB&ZRl\u0003@%O>r\u0019L,JBp\u001aY@";
      B[70] = "Ur\u0016ON\u001b\u001en\u0003V7\u0014o%\n^KO\u001eg\u001cK\n~";
      B[71] = "`-V\u001coaaz\b_\u001eyg\"DLYi\u000e+]\u0019\u007f}u,WE!\u0007`-V\u001coaaz\b_\u001e";
      B[72] = "f\rOx1Sg\u0014\u0012n@It\fix<19\u0010\u0011$\"Vi\u0015T{@QiO\u0019n*Kv\u0002O\u001ez@q\f\u0019o8VdM(u$T`\u001bU \u007f@lp";
      B[73] = "^3]^~\u0014\r0YYN\u0002buPG T\roOB n_`L\u0003)_\u0005fJPN";
      B[74] = "hIt!{ >P/(\u0005\u000eVuXB81vP({l2aP";
      B[75] = "\u001a\u0006k6\b\\\u001b\u001f6 yQ\u0018\u0007M6\u0005>E\u001b5j\u001bY\u0015\u001ep5y^\u0015D= \u0013D\n\tkPCO\r\u0007=!\u0001Y\u0018F\f";
      B[76] = "eQd\fhQ=\u00020H\tP5FMXr^\\^g[eK \\dN\tU:PmKuW9E\u0001";
      B[77] = "/=\u0017YN0~<\u001dR7w'7PUpgN3M\u0007\u0006y$)RJP\t/=\u0017YN0~<\u001dR7";
      B[78] = "a\u0006;\u007f?>2\u0005?x\u000f.]@6fa~2Z)caD6X5rd9c\u0003!~\u000f";
      B[79] = "xl\u001b%1:(hC>\r\u0005HI4E0:hlD|d9\u007fl";
      B[80] = "{oDK,V?u\u001a\u001fWUfb\u0015B:gh{\u0002KW\\}o\u0005KfBp$\u001e&";
      B[81] = "\u0007'Y8-\u0015Y+Zx\u001c 5Ck\u0000!\u001f\u0015f\u001b9u\u001c\u0002f";
      B[82] = "\u0016rk`bvEqogRe*4fy<6E.y|<\f\u001a(9>0kJ-|aR";
      B[83] = "u\u0004d\u0005u\u001f>\u0018q\u001c\f\u0011OSx\u0014pK>\u0011n\u00011z";
      B[84] = "!T\u0016(\u0003' \u0003Hkr+(X\u001dx\u001b'\u0011V\u001dh\u001fA\"[At\b:%Q\u001d*r";
      B[85] = "'.=u}\u0006c4c!\u0006\b;\"Xqb\u00140^<i~\u0015l/~\u007fkT]";
      B[86] = "B\u0000\u001b++}^^\u001a8\u0012lKM;1jn&\f\u00041o>\u001fX\u0007&o\u0003";
      B[87] = "\u0006}W:F^\u0007d\n,7S\u0004||;JV\rm0lW\u0005SbW<R@\f\u0000P<\b\r\u0019jJ#E[ieL,MQX{AgV<";
      B[88] = "I\\JK(eU\u0002KX\u0011`@\u00116\u0010q\"\u0017\u000fQ@tgHm\u0006@(!O\nVEm~-\u0006RExpPS\tQt\u001b";
      B[89] = "\u0000k\u0013:\u001e%\u0001rN,o?\u0012j>-\u0013*o&\u0014eU%\bv\u0011 \nG\u000fvKm\u001f-\u0015i\u0006;o#\u0011v\u000b%S \u0000v\u001a\\\u0004#\n\u007f\u001f!Qx\u001est";
      B[90] = "K:;)7\r\u000f e}L\u0019Q-z8\u0012\u000bU7mD*RC+~{+\u001fT:\u0000";
      B[91] = "o:\t\bHzd=\f\u0014s9`8K\u00174)\tfG\u0002\u000fvx$Q\u0017NGo:\t\bHzd=\f\u0014s";
      B[92] = "#8XN\u001bHs<\u0000U'U+!GC`EB#\n\\FU}\"GKW+#8XN\u001bHs<\u0000U'";
      B[93] = "\r]{\u0019\u0005'\fD&\u000ft=\u001f\\G\u001f\u0013?\u001e ,\u001fM\u007f\u0000G|\u001a\b b@|@E5\bZc\r\u0013E\u0004\u0010n\u001e\nz\u0005]y\u000ft.\u0006Eu\u0014\t{]Qy\u007f";
      B[94] = "]fD\u0006oL\\\u007f\u0019\u0010\u001eA_gd\n|CYg#P~\u0017\byD\u0000{RW\u001bC\u0000!\u001fBqY\u001flI2+CY$LU{F\u001c{.";
      B[95] = "G\u0012)%z\u0018FEwf\u000b\"x!\u000b\u00186\u001dX\u0004{!b\u001eO\u0004";
      B[96] = "\u0003?&9\u000f.W<192xS \u0011-Wz><1*^iB>2?2";
      B[97] = " \u0003O{l\u0003d\u0019\u0011/\u0017\u0002>\u0014\u001djI\u0005>\u000e\u0019\u0016p\r>KJx/UkHt";
      B[98] = "|\u0007na2\u000b,\u000b>9I\u000e/\u0018_3,\b:\u001ch$I^x\u000f~.2P}\u0001\u007f^";
      B[99] = "m\nt7)M/TslX^ JRh\u0011L&[uzX\u0016=\u000f)d?F8Jv\u0006hFd\fqa8C!S\u001368\u001fgTtf=Z86";
      B[100] = "X\u001bs\u0006\u0006{\nX2\u0013jfS*)\u0014\u000evx\t3\u0012\u0010{L\u0018/\u0003j'W\u00155DSsT\u00025y\n|Z\b6\u0005\b\u007fOd";
      B[101] = "O7zT\f+A2tU|?\u001dqKB\u00199\bu|U|i\u001fh(N\u00181L<l/";
      B[102] = "j\f6]0\u0004'H3\u0000H\r[J>F&^4P!C&d2L%_'\u0000dDgPH";
      B[103] = "D1^+\u0018vE(\u0003=ilV0r-\u0000n+|YtSvL,\\1\f\u0014K,\u0006|\u0019~Q3K*i-\u00123C*\rxR7YM\u0002pN%R0W+Z)9";
      B[104] = "7sSJG\u0005<tVV|d\u0000M!8A[ hQ\u0001\u0015X7h";
      B[105] = "y\u001c\u0012,i8{\u0012]\u007f\u0010!w\t\u001e|W1\u001e\b\u001faj2/\u0016\u0012*q_y\u001c\u0012,i8{\u0012]\u007f\u0010";
      B[106] = "N\u0013!\u0007\u0013\u000e\n\t\u007fSh\u0005S\u0005u4\u0001\u0005I\u000e\u001a\n\b^\u0005\u0013p\u0010\u0017\u0013Sc";
      B[107] = "hn$\u0002\u000ff0=pFnx<\u007f,A\u0015oQ8.^Wc5`}\n\u0013\u0002";
      B[108] = "~7\u001a\nTn\u007f.G\u001c%c|67\u000bBh|#\u001bl\u0015l(p\u001f\u000bEim/}\fE3 :\u0017\u0016Z~vJ\u0010\b\u001dmk1\u0017\u0002A3\u0011";
      B[109] = "74\u007fv\u000f\b5:0%v3\u0001\u001dCKK\f!83r\u001f\u000f68";
      B[110] = "gv\t#\r\u0007*2\f~u\rV0\u00018\u001b]9*\u001e=\u001bg?6\u001a!\u001a\u0003i>X.u";
      B[111] = "`\u001e\\z\u0004_|@]i=NiS !]\u0018>MGqX]a/\u0010q\u0004\u001bfH@tAD\u0004";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = B[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(C[var4]);
            B[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = B[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            B[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  B[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(860522429493706L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = B[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  B[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(860522429493706L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        B[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(860522429493706L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 104;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 221;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 71;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 200;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 228;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 110;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 104;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 221;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 71;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cR_C0145",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = g(MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Exception invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = b(MethodHandles.lookup(), "d", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Exception invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static FieldAccessMetadata invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cU_C0151;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (FieldAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static FieldAccessMetadata invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cU_C0151;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (FieldAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding7(long var0, long var2) {
         MethodHandle var8 = bindingCache7;
         MethodHandle var7 = bindingCache7;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache7 = g(MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Exception invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding9(int var0, long var1) {
         MethodHandle var7 = bindingCache9;
         MethodHandle var6 = bindingCache9;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache9 = b(MethodHandles.lookup(), "d", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Exception invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static FieldAccessMetadata invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cU_C0151;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (FieldAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ReflectedField invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cR_C0145;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ReflectedField)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundFieldAccessor invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = g(MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Object invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = g(
                  MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Exception invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static AMapper invokeBinding17(long var0, long var2) {
         MethodHandle var8 = bindingCache17;
         MethodHandle var7 = bindingCache17;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache17 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = g(MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = d(MethodHandles.lookup(), "h", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding22(int var0, long var1) {
         MethodHandle var7 = bindingCache22;
         MethodHandle var6 = bindingCache22;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache22 = d(MethodHandles.lookup(), "h", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding23(Object var0, char var1, char var2, long var3, long var5) {
         MethodHandle var11 = bindingCache23;
         MethodHandle var10 = bindingCache23;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache23 = g(
                  MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;CCJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (char)var1, (char)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding24(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = g(
                  MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding25(long var0, long var2) {
         MethodHandle var8 = bindingCache25;
         MethodHandle var7 = bindingCache25;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache25 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding28(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = g(
                  MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding29(long var0, long var2) {
         MethodHandle var8 = bindingCache29;
         MethodHandle var7 = bindingCache29;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache29 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding31(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache31;
         MethodHandle var11 = bindingCache31;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache31 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (String)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static FieldAccessMetadata invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cU_C0151;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (FieldAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding33(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache33;
         MethodHandle var10 = bindingCache33;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache33 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Exception invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundFieldAccessor invokeBinding35(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache35;
         MethodHandle var9 = bindingCache35;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache35 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding36(long var0, long var2) {
         MethodHandle var8 = bindingCache36;
         MethodHandle var7 = bindingCache36;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache36 = g(MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Exception invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Exception invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Exception invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding40(int var0, long var1) {
         MethodHandle var7 = bindingCache40;
         MethodHandle var6 = bindingCache40;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache40 = b(MethodHandles.lookup(), "d", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Exception invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding42(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache42;
         MethodHandle var9 = bindingCache42;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache42 = g(
                  MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding43(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache43;
         MethodHandle var9 = bindingCache43;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache43 = g(
                  MethodHandles.lookup(), "ä", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding44(long var0, long var2) {
         MethodHandle var8 = bindingCache44;
         MethodHandle var7 = bindingCache44;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache44 = g(MethodHandles.lookup(), "n", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Exception invokeBinding45(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache45;
         MethodHandle var8 = bindingCache45;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache45 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding46(int var0, long var1) {
         MethodHandle var7 = bindingCache46;
         MethodHandle var6 = bindingCache46;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache46 = b(MethodHandles.lookup(), "d", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Exception invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding48(int var0, long var1) {
         MethodHandle var7 = bindingCache48;
         MethodHandle var6 = bindingCache48;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache48 = b(MethodHandles.lookup(), "d", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Exception invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = g(
                  MethodHandles.lookup(), "n", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundFieldAccessor invokeBinding50(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache50;
         MethodHandle var9 = bindingCache50;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache50 = g(
                  MethodHandles.lookup(),
                  "ä",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bN_C0083;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundFieldAccessor)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
