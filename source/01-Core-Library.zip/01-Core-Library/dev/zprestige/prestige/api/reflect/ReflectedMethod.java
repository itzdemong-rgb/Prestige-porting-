package dev.zprestige.prestige.api.reflect;
import java.lang.reflect.InvocationTargetException;


import dev.zprestige.prestige.api.reflect.BoundMethodInvoker;
import dev.zprestige.prestige.api.reflect.MethodAccessMetadata;


import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.lenni0451.classtransform.mappings.AMapper;
import net.lenni0451.classtransform.utils.mappings.MapRemapper;

public class ReflectedMethod extends ReflectionUtil {
   private final Method a;
   private final MethodHandle b;
   private final boolean c;
   private final Object d;
   private volatile MethodHandle e;
   private volatile boolean f;
   private static final Object[] g;
   private static final ConcurrentHashMap h;
   private static final long i = 100108327331872L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long[] t;
   private static final Integer[] u;
   private static final Map v;
   private static final Object[] B = new Object[63];
   private static final String[] C = new String[63];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;
   private static volatile MethodHandle bindingCache93;
   private static volatile MethodHandle bindingCache94;
   private static volatile MethodHandle bindingCache95;
   private static volatile MethodHandle bindingCache96;

   private ReflectedMethod(Method var1, MethodHandle var2, boolean var3, Object var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   private ReflectedMethod(MethodAccessMetadata var1, Object var2) {
      this(var1.a, var1.b, var1.c, var2);
   }

   public static ReflectedMethod aReturningcT_C0149(Object[] var0) {
      Class var4 = (Class)var0[0];
      String var5 = (String)var0[1];
      Class[] var3 = (Class[])var0[2];
      long var1 = (Long)var0[3];
      var1 = 100108327331872L ^ var1;
      long var6 = var1 ^ 73770447269760L;
      MethodAccessMetadata var8 = invokeBinding1(new Object[]{var4, var5, var3, var6}, -8871482633727635440L, var1);
      return new ReflectedMethod(var8, null);
   }

   public static ReflectedMethod bReturningcT_C0149(Object[] var0) {
      Class var3 = (Class)var0[0];
      String var5 = (String)var0[1];
      String var4 = (String)var0[2];
      long var1 = (Long)var0[3];
      var1 = 100108327331872L ^ var1;
      long var6 = var1 ^ 39677773541648L;
      MethodAccessMetadata var8 = invokeBinding2(new Object[]{var3, var5, var4, var6}, -1999510706736142697L, var1);
      return new ReflectedMethod(var8, null);
   }

    public static ReflectedMethod cReturningcT_C0149(Object[] objectArray) {

        Object object;
        long l;
        long l2;
        Class[] classArray;
        String string;
        Object object2;
        block4: {
            block5: {
                object2 = objectArray[0];
                string = (String)objectArray[1];
                classArray = (Class[])objectArray[2];
                l2 = (Long)objectArray[3];
                l = (l2 = 0x5B0C494A2820L ^ l2) ^ 0x658FBD26FBFFL;
                int n = ReflectedMethod.invokeBinding3(-8026383213644335213L, l2);
                try {
                    try {
                        object = object2;
                        if (n != 0) break block4;
                        if (object != null) break block5;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedMethod.invokeBinding4(illegalArgumentException, -8025885645385333264L, l2);
                    }
                    throw new IllegalArgumentException(ReflectedMethod.invokeBinding5(3695, 0x766020DAD5C7CEEFL ^ l2));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedMethod.invokeBinding6(illegalArgumentException, -8025885645385333264L, l2);
                }
            }
            object = object2;
        }
        Object[] objectArray2 = new Object[4];
        objectArray2[3] = l;
        objectArray2[2] = classArray;
        objectArray2[1] = string;
        objectArray2[0] = object.getClass();
        MethodAccessMetadata cV_C01532 = ReflectedMethod.invokeBinding7(objectArray2, -8026242350085503889L, l2);
        return new ReflectedMethod(cV_C01532, object2);
    
      
}

    public static ReflectedMethod dReturningcT_C0149(Object[] objectArray) {

        Object object;
        long l;
        long l2;
        String string;
        String string2;
        Object object2;
        block4: {
            block5: {
                object2 = objectArray[0];
                string2 = (String)objectArray[1];
                string = (String)objectArray[2];
                l2 = (Long)objectArray[3];
                l = (l2 = 0x5B0C494A2820L ^ l2) ^ 0x26CB772BAF48L;
                int n = ReflectedMethod.invokeBinding8(-5036447034879959787L, l2);
                try {
                    try {
                        object = object2;
                        if (n != 0) break block4;
                        if (object != null) break block5;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedMethod.invokeBinding9(illegalArgumentException, -5037224083941642378L, l2);
                    }
                    throw new IllegalArgumentException(ReflectedMethod.invokeBinding10(14883, 0x101BBAB669E05023L ^ l2));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedMethod.invokeBinding11(illegalArgumentException, -5037224083941642378L, l2);
                }
            }
            object = object2;
        }
        Object[] objectArray2 = new Object[4];
        objectArray2[3] = l;
        objectArray2[2] = string;
        objectArray2[1] = string2;
        objectArray2[0] = object.getClass();
        MethodAccessMetadata cV_C01532 = ReflectedMethod.invokeBinding12(objectArray2, -5037191218344904497L, l2);
        return new ReflectedMethod(cV_C01532, object2);
    
      
}

   public static BoundMethodInvoker aReturningcE_C0119(Object[] var0) {

      Object var3 = var0[0];
      String var5 = (String)var0[1];
      Class var1 = (Class)var0[2];
      Class var4 = (Class)var0[3];
      Class[] var2 = (Class[])var0[4];
      long var6 = (Long)var0[5];
      var6 = 100108327331872L ^ var6;
      long var8 = var6 ^ 4909344605274L;
      long var10 = var6 ^ 47377056408851L;
      int var10000 = invokeBinding13(4661642667482840L, var6);
      MethodLookupKey var13 = new MethodLookupKey(var1, var5, var4, var2, var3.getClass());
      int var12 = var10000;
      ReflectedMethod var14 = (ReflectedMethod)invokeBinding14(h, var13, 5106240802783955L, var6);

      label56: {
         try {
            int var28 = var12;
            ReflectedMethod var27 = var14;
            ReflectedMethod var22 = var27;
            ReflectedMethod var20 = var27;
            if (var28 == 0) {
               return invokeBinding16(var22, new Object[]{var3, var10}, 4829824671352329L, var6);
            }

            ReflectedMethod var29 = var20;
            if (var29 == null) {
               break label56;
            }
         } catch (IllegalArgumentException var35) {
            throw invokeBinding15(var35, 5419516628440445L, var6);
         }

         ReflectedMethod var37 = var14;
         return invokeBinding16(var37, new Object[]{var3, var10}, 4829824671352329L, var6);
      }

      String var15 = invokeBinding24(
         invokeBinding19(invokeBinding18(invokeBinding17(6548489950643979L, var6), 6324717324628281L, var6), 6411496360150147L, var6),
         invokeBinding23(
            invokeBinding20(var1, 5788933814796170L, var6),
            (char)invokeBinding21(12837, 2220003546822712020L ^ var6),
            (char)invokeBinding22(15911, 2247863487810148053L ^ var6),
            4897031636053953L,
            var6
         ),
         4996417136527544L,
         var6
      );
      String var16 = invokeBinding29(
         invokeBinding27(invokeBinding26(invokeBinding25(6548489950643979L, var6), 6324717324628281L, var6), 6411496360150147L, var6),
         invokeBinding28(var4, var2, 5331126016870057L, var6),
         4595277240969305L,
         var6
      );
      String var17 = invokeBinding32(
         invokeBinding31(invokeBinding30(6548489950643979L, var6), 6324717324628281L, var6), var15, var5, var16, 5565495523084575L, var6
      );
      ReflectedMethod var18 = invokeBinding33(new Object[]{var3, var17, var2, var8}, 5273117902417253L, var6);
      ReflectedMethod var19 = (ReflectedMethod)invokeBinding34(h, var13, var18, 6497261100421029L, var6);

      ReflectedMethod var25;
      label57: {
         label32: {
            try {
               int var31 = var12;
               ReflectedMethod var30 = var19;
               var25 = var30;
               ReflectedMethod var23 = var30;
               if (var31 == 0) {
                  break label57;
               }

               ReflectedMethod var32 = var23;
               if (var32 == null) {
                  break label32;
               }
            } catch (IllegalArgumentException var34) {
               throw invokeBinding35(var34, 5419516628440445L, var6);
            }

            var25 = var19;
            break label57;
         }

         ReflectedMethod var26 = var18;
         return invokeBinding36(var26, new Object[]{var3, var10}, 4829824671352329L, var6);
      }

      ReflectedMethod var33 = var25;
      ReflectedMethod var38 = var33;
      return invokeBinding36(var38, new Object[]{var3, var10}, 4829824671352329L, var6);
   
      
}

   public static BoundMethodInvoker bReturningcE_C0119(Object[] var0) {
      Object var3 = var0[0];
      String var5 = (String)var0[1];
      String var4 = (String)var0[2];
      long var1 = (Long)var0[3];
      var1 = 100108327331872L ^ var1;
      long var6 = var1 ^ 123452748937230L;
      long var8 = var1 ^ 122768578059375L;
      ReflectedMethod var10 = invokeBinding37(new Object[]{var3, var5, var4, var8}, -961888841651683533L, var1);
      return invokeBinding38(var10, new Object[]{var6}, -961535485305695009L, var1);
   }

   public static ReflectedMethod eReturningcT_C0149(Object[] var0) {

      Class var5 = (Class)var0[0];
      String var2 = (String)var0[1];
      Class var6 = (Class)var0[2];
      Class[] var1 = (Class[])var0[3];
      long var3 = (Long)var0[4];
      var3 = 100108327331872L ^ var3;
      long var7 = var3 ^ 92554618671003L;
      MethodLookupKey var9 = new MethodLookupKey(var5, var2, var6, var1, var5);
      ReflectedMethod var10 = (ReflectedMethod)invokeBinding39(h, var9, -2329395834962190995L, var3);

      try {
         ReflectedMethod var19 = var10;
         if (var19 != null) {
            return var10;
         }
      } catch (IllegalArgumentException var23) {
         throw invokeBinding40(var23, -2329144097102378301L, var3);
      }

      String var11 = invokeBinding48(
         invokeBinding43(invokeBinding42(invokeBinding41(-2330272937280595787L, var3), -2330596858884411769L, var3), -2330417137346454723L, var3),
         invokeBinding47(
            invokeBinding44(var5, -2329794993560657868L, var3),
            (char)invokeBinding45(14712, 1023584767133830709L ^ var3),
            (char)invokeBinding46(7140, 60225036013202602L ^ var3),
            -2328621461786120065L,
            var3
         ),
         -2328441296488802554L,
         var3
      );
      String var12 = invokeBinding53(
         invokeBinding51(invokeBinding50(invokeBinding49(-2330272937280595787L, var3), -2330596858884411769L, var3), -2330417137346454723L, var3),
         invokeBinding52(var6, var1, -2329339105646683881L, var3),
         -2328882534937888793L,
         var3
      );
      String var13 = invokeBinding56(
         invokeBinding55(invokeBinding54(-2330272937280595787L, var3), -2330596858884411769L, var3), var11, var2, var12, -2329008598872828255L, var3
      );
      ReflectedMethod var14 = invokeBinding57(new Object[]{var5, var13, var1, var7}, -2329580167966075905L, var3);
      ReflectedMethod var15 = (ReflectedMethod)invokeBinding58(h, var9, var14, -2330221431404982245L, var3);

      try {
         ReflectedMethod var20 = var15;
         if (var20 != null) {
            return var15;
         }
      } catch (IllegalArgumentException var22) {
         throw invokeBinding59(var22, -2329144097102378301L, var3);
      }

      return var14;
   
      
}

    private MethodHandle aReturningMethodHandle(final Object[] array) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[7];
      recoveryLocals[0]=this;
      recoveryLocals[1]=array;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=5; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=6; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=8; { recoveryStack[0]=100108327331872L; }
                  recoveryAt=9; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=10; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=11; { recoveryLocals[2]=recoveryStack[0];  }
                  recoveryAt=12; { recoveryStack[0]=-5424683072943330689L; }
                  recoveryAt=13; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=14; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding60(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=15; { recoveryLocals[4]=recoveryStack[0];  }
                  recoveryAt=18; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=19; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=20; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=45; continue recoveryFlow;} recoveryPc=22; continue recoveryFlow; }
               }
               case 22 -> {
                  recoveryAt=22; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).f; }
                  recoveryAt=23; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=50; continue recoveryFlow;} recoveryPc=25; continue recoveryFlow; }
               }
               case 25 -> {
                  recoveryAt=25; { recoveryPc=34; continue recoveryFlow; }
               }
               case 28 -> {
                  recoveryAt=28; { recoveryStack[1]=-5425595359296577062L; }
                  recoveryAt=29; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=30; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding61(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=31; { throw (Throwable)recoveryStack[0]; }
               }
               case 34 -> {
                  recoveryAt=34; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=36; { recoveryPc=45; continue recoveryFlow; }
               }
               case 39 -> {
                  recoveryAt=39; { recoveryStack[1]=-5425595359296577062L; }
                  recoveryAt=40; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=41; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding62(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=42; { throw (Throwable)recoveryStack[0]; }
               }
               case 45 -> {
                  recoveryAt=45; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).e; }
                  recoveryAt=46; { return ((java.lang.invoke.MethodHandle)recoveryStack[0]); }
               }
               case 50 -> {
                  recoveryAt=50; { recoveryStack[0]=null; }
                  recoveryAt=51; { recoveryLocals[5]=recoveryStack[0];  }
                  recoveryAt=54; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=55; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).b; }
                  recoveryAt=56; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectedMethod.dReturningVoid(); }
                  recoveryAt=57; { recoveryStack[2]=-5425538216669131450L; }
                  recoveryAt=58; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=59; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=60; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=63; { recoveryStack[0]=((java.lang.reflect.Method)recoveryStack[0]).invoke(((java.lang.Object)recoveryStack[1]),((java.lang.Object[])recoveryStack[2])); }
                  recoveryAt=65; { recoveryPc=72; continue recoveryFlow; }
               }
               case 68 -> {
                  recoveryAt=68; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=69; { throw (Throwable)recoveryStack[0]; }
               }
               case 72 -> {
                  recoveryAt=72; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectedMethod.dReturningVoid(); }
                  recoveryAt=73; { recoveryStack[2]=-5425983351337855652L; }
                  recoveryAt=74; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=75; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=76; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=79; { recoveryStack[0]=((java.lang.reflect.Method)recoveryStack[0]).invoke(((java.lang.Object)recoveryStack[1]),((java.lang.Object[])recoveryStack[2])); }
                  recoveryAt=80; { recoveryStack[0]=((java.lang.Integer)recoveryStack[0]); }
                  recoveryAt=81; { recoveryStack[0]=((java.lang.Integer)recoveryStack[0]).intValue(); }
                  recoveryAt=83; { recoveryPc=90; continue recoveryFlow; }
               }
               case 86 -> {
                  recoveryAt=86; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=87; { throw (Throwable)recoveryStack[0]; }
               }
               case 90 -> {
                  recoveryAt=90; { recoveryLocals[6]=recoveryStack[0];  }
                  recoveryAt=93; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=94; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).b; }
                  recoveryAt=95; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=96; { recoveryStack[1]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[1]).b; }
                  recoveryAt=97; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.dReturningVoid(); }
                  recoveryAt=98; { recoveryStack[3]=-5425538216669131450L; }
                  recoveryAt=99; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=100; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=101; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=104; { recoveryStack[1]=((java.lang.reflect.Method)recoveryStack[1]).invoke(((java.lang.Object)recoveryStack[2]),((java.lang.Object[])recoveryStack[3])); }
                  recoveryAt=106; { recoveryPc=113; continue recoveryFlow; }
               }
               case 109 -> {
                  recoveryAt=109; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=110; { throw (Throwable)recoveryStack[0]; }
               }
               case 113 -> {
                  recoveryAt=113; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.dReturningVoid(); }
                  recoveryAt=114; { recoveryStack[3]=-5425327596821570276L; }
                  recoveryAt=115; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=116; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=117; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=120; { recoveryStack[1]=((java.lang.reflect.Method)recoveryStack[1]).invoke(((java.lang.Object)recoveryStack[2]),((java.lang.Object[])recoveryStack[3])); }
                  recoveryAt=122; { recoveryPc=129; continue recoveryFlow; }
               }
               case 125 -> {
                  recoveryAt=125; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=126; { throw (Throwable)recoveryStack[0]; }
               }
               case 129 -> {
                  recoveryAt=129; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectedMethod.bReturningVoid(((java.lang.Object)recoveryStack[1])); }
                  recoveryAt=130; { recoveryStack[2]=-5426490684700583260L; }
                  recoveryAt=131; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=132; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=133; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=136; { recoveryStack[0]=((java.lang.reflect.Method)recoveryStack[0]).invoke(((java.lang.Object)recoveryStack[1]),((java.lang.Object[])recoveryStack[2])); }
                  recoveryAt=138; { recoveryPc=145; continue recoveryFlow; }
               }
               case 141 -> {
                  recoveryAt=141; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=142; { throw (Throwable)recoveryStack[0]; }
               }
               case 145 -> {
                  recoveryAt=145; { recoveryStack[1]=java.lang.Object[].class; }
                  recoveryAt=146; { recoveryStack[2]=recoveryLocals[6];  }
                  recoveryAt=147; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectedMethod.aReturningVoid(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])); }
                  recoveryAt=148; { recoveryStack[2]=-5426659140191660456L; }
                  recoveryAt=149; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=150; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=151; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=154; { recoveryStack[0]=((java.lang.reflect.Method)recoveryStack[0]).invoke(((java.lang.Object)recoveryStack[1]),((java.lang.Object[])recoveryStack[2])); }
                  recoveryAt=155; { recoveryStack[0]=((java.lang.invoke.MethodHandle)recoveryStack[0]); }
                  recoveryAt=157; { recoveryPc=164; continue recoveryFlow; }
               }
               case 160 -> {
                  recoveryAt=160; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=161; { throw (Throwable)recoveryStack[0]; }
               }
               case 164 -> {
                  recoveryAt=164; { recoveryLocals[5]=recoveryStack[0];  }
                  recoveryAt=167; { recoveryPc=175; continue recoveryFlow; }
               }
               case 171 -> {
                  recoveryPc=175; continue recoveryFlow;
               }
               case 175 -> {
                  recoveryAt=175; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=176; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=177; { ((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).e=((java.lang.invoke.MethodHandle)recoveryStack[1]); }
                  recoveryAt=180; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=181; { recoveryStack[1]=1; }
                  recoveryAt=182; { ((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).f=((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]) & 1) != 0); }
                  recoveryAt=185; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=186; { return ((java.lang.invoke.MethodHandle)recoveryStack[0]); }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=21 && recoveryAt<35 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=39; continue recoveryFlow;}
            if(recoveryAt>=16 && recoveryAt<24 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=28; continue recoveryFlow;}
            if(recoveryAt>=153 && recoveryAt<156 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=160; continue recoveryFlow;}
            if(recoveryAt>=135 && recoveryAt<137 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=141; continue recoveryFlow;}
            if(recoveryAt>=119 && recoveryAt<121 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=125; continue recoveryFlow;}
            if(recoveryAt>=103 && recoveryAt<105 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=109; continue recoveryFlow;}
            if(recoveryAt>=78 && recoveryAt<82 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=86; continue recoveryFlow;}
            if(recoveryAt>=62 && recoveryAt<64 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=68; continue recoveryFlow;}
            if(recoveryAt>=52 && recoveryAt<165 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=171; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   public Method aReturningMethod(Object[] var1) {
      return this.a;
   }

   public Object aReturningObject(Object[] var1) throws Throwable {
      Object var3 = var1[0];
      Object[] var2 = (Object[])var1[1];
      long var4 = (Long)var1[2];
      var4 = 100108327331872L ^ var4;
      long var6 = var4 ^ 60806650840413L;
      return invokeBinding63(this, new Object[]{var3, var2, var6}, 8204096824907312573L, var4);
   }

   public Object bReturningObject(Object[] param1) throws Throwable {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[11];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Object)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=10; { recoveryLocals[5]=recoveryStack[1];  }
                  recoveryAt=11; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=12; { recoveryStack[2]=2; }
                  recoveryAt=13; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=14; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=16; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=18; { recoveryStack[0]=100108327331872L; }
                  recoveryAt=19; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=20; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=21; { recoveryLocals[2]=recoveryStack[0];  }
                  recoveryAt=22; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=23; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=24; { recoveryStack[2]=43867831009328L; }
                  recoveryAt=25; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=26; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=28; { recoveryStack[0]=-2282896557299513506L; }
                  recoveryAt=29; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=30; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding64(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=31; { recoveryLocals[8]=recoveryStack[0];  }
                  recoveryAt=34; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=35; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=36; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=102; continue recoveryFlow;} recoveryPc=38; continue recoveryFlow; }
               }
               case 38 -> {
                  recoveryAt=38; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).c; }
                  recoveryAt=39; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=91; continue recoveryFlow;} recoveryPc=41; continue recoveryFlow; }
               }
               case 41 -> {
                  recoveryAt=41; { recoveryPc=51; continue recoveryFlow; }
               }
               case 44 -> {
                  recoveryAt=44; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=45; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=46; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding65(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=47; { throw (Throwable)recoveryStack[0]; }
               }
               case 51 -> {
                  recoveryAt=51; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=52; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=53; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=78; continue recoveryFlow;} recoveryPc=55; continue recoveryFlow; }
               }
               case 55 -> {
                  recoveryAt=55; { recoveryPc=64; continue recoveryFlow; }
               }
               case 58 -> {
                  recoveryAt=58; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=59; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=60; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding66(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=61; { throw (Throwable)recoveryStack[0]; }
               }
               case 64 -> {
                  recoveryAt=64; { if(recoveryStack[0]!=null){recoveryPc=81; continue recoveryFlow;} recoveryPc=66; continue recoveryFlow; }
               }
               case 66 -> {
                  recoveryAt=66; { recoveryPc=75; continue recoveryFlow; }
               }
               case 69 -> {
                  recoveryAt=69; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=70; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=71; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding67(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=72; { throw (Throwable)recoveryStack[0]; }
               }
               case 75 -> {
                  recoveryAt=75; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.g; }
                  recoveryPc=78; continue recoveryFlow;
               }
               case 78 -> {
                  recoveryAt=78; { recoveryPc=84; continue recoveryFlow; }
               }
               case 81 -> {
                  recoveryAt=81; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryPc=84; continue recoveryFlow;
               }
               case 84 -> {
                  recoveryAt=84; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=86; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=87; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=204; continue recoveryFlow;} recoveryPc=91; continue recoveryFlow; }
               }
               case 91 -> {
                  recoveryAt=91; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=93; { recoveryPc=102; continue recoveryFlow; }
               }
               case 96 -> {
                  recoveryAt=96; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=97; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=98; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding68(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=99; { throw (Throwable)recoveryStack[0]; }
               }
               case 102 -> {
                  recoveryAt=102; { if(recoveryStack[0]!=null){recoveryPc=121; continue recoveryFlow;} recoveryPc=103; continue recoveryFlow; }
               }
               case 103 -> {
                  recoveryAt=103; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(java.lang.IllegalArgumentException.class); recoveryStack[0]=new Object(); }
                  recoveryAt=104; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=105; { recoveryStack[2]=25816; }
                  recoveryAt=106; { recoveryStack[3]=350061435969524886L; }
                  recoveryAt=107; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=108; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=109; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding69(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=110; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new java.lang.IllegalArgumentException(((java.lang.String)recoveryStack[2])); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=111; { throw (Throwable)recoveryStack[0]; }
               }
               case 114 -> {
                  recoveryAt=114; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=115; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=116; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding70(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=117; { throw (Throwable)recoveryStack[0]; }
               }
               case 121 -> {
                  recoveryAt=121; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=122; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=123; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=149; continue recoveryFlow;} recoveryPc=125; continue recoveryFlow; }
               }
               case 125 -> {
                  recoveryAt=125; { if(recoveryStack[0]!=null){recoveryPc=146; continue recoveryFlow;} recoveryPc=127; continue recoveryFlow; }
               }
               case 127 -> {
                  recoveryAt=127; { recoveryPc=136; continue recoveryFlow; }
               }
               case 130 -> {
                  recoveryAt=130; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=131; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=132; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding71(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=133; { throw (Throwable)recoveryStack[0]; }
               }
               case 136 -> {
                  recoveryAt=136; { recoveryStack[0]=0; }
                  recoveryAt=137; { recoveryPc=152; continue recoveryFlow; }
               }
               case 140 -> {
                  recoveryAt=140; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=141; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=142; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding72(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=143; { throw (Throwable)recoveryStack[0]; }
               }
               case 146 -> {
                  recoveryAt=146; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryPc=149; continue recoveryFlow;
               }
               case 149 -> {
                  recoveryAt=149; { recoveryStack[0]=java.lang.reflect.Array.getLength(recoveryStack[0]); }
                  recoveryPc=152; continue recoveryFlow;
               }
               case 152 -> {
                  recoveryAt=152; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=155; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=156; { recoveryStack[1]=1; }
                  recoveryAt=157; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]); }
                  recoveryAt=158; { recoveryStack[0]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])]; }
                  recoveryAt=159; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=162; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=163; { recoveryStack[1]=0; }
                  recoveryAt=164; { recoveryStack[2]=recoveryLocals[8];  }
                  recoveryAt=165; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])!=0){recoveryPc=195; continue recoveryFlow;} recoveryPc=167; continue recoveryFlow; }
               }
               case 167 -> {
                  recoveryAt=167; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=168; { ((Object[])recoveryStack[0])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])]=recoveryStack[2]; }
                  recoveryAt=171; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=172; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=0){recoveryPc=204; continue recoveryFlow;} recoveryPc=174; continue recoveryFlow; }
               }
               case 174 -> {
                  recoveryAt=174; { recoveryPc=183; continue recoveryFlow; }
               }
               case 177 -> {
                  recoveryAt=177; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=178; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=179; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding73(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=180; { throw (Throwable)recoveryStack[0]; }
               }
               case 183 -> {
                  recoveryAt=183; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=184; { recoveryStack[1]=0; }
                  recoveryAt=186; { recoveryPc=195; continue recoveryFlow; }
               }
               case 189 -> {
                  recoveryAt=189; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=190; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=191; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding74(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=192; { throw (Throwable)recoveryStack[0]; }
               }
               case 195 -> {
                  recoveryAt=195; { recoveryStack[2]=recoveryLocals[9];  }
                  recoveryAt=196; { recoveryStack[3]=1; }
                  recoveryAt=197; { recoveryStack[4]=recoveryLocals[10];  }
                  recoveryAt=198; { recoveryStack[5]=-2281124368326831579L; }
                  recoveryAt=199; { recoveryStack[6]=recoveryLocals[2];  }
                  recoveryAt=200; { dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding75(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[6])); }
                  recoveryPc=204; continue recoveryFlow;
               }
               case 204 -> {
                  recoveryAt=204; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=205; { recoveryStack[1]=recoveryLocals[6];  }
                  recoveryAt=206; { recoveryStack[2]=1; }
                  recoveryAt=207; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=208; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=209; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=211; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=212; { recoveryStack[4]=0; }
                  recoveryAt=213; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=214; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=215; { recoveryStack[2]=-2281878839641976664L; }
                  recoveryAt=216; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=217; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding76(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=218; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=221; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=222; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=223; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=270; continue recoveryFlow;} recoveryPc=225; continue recoveryFlow; }
               }
               case 225 -> {
                  recoveryAt=225; { if(recoveryStack[0]==null){recoveryPc=250; continue recoveryFlow;} recoveryPc=227; continue recoveryFlow; }
               }
               case 227 -> {
                  recoveryAt=227; { recoveryPc=237; continue recoveryFlow; }
               }
               case 230 -> {
                  recoveryAt=230; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=231; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=232; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding77(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=233; { throw (Throwable)recoveryStack[0]; }
               }
               case 237 -> {
                  recoveryAt=237; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=238; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=239; { recoveryStack[0]=((java.lang.invoke.MethodHandle)recoveryStack[0]).invoke(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=240; { return ((java.lang.Object)recoveryStack[0]); }
               }
               case 243 -> {
                  recoveryAt=243; { recoveryStack[1]=-2282382917411277507L; }
                  recoveryAt=244; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=245; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectedMethod.invokeBinding78(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=246; { throw (Throwable)recoveryStack[0]; }
               }
               case 250 -> {
                  recoveryAt=250; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=251; { recoveryStack[0]=((dev.zprestige.prestige.api.reflect.ReflectedMethod)recoveryStack[0]).b; }
                  recoveryAt=252; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=253; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectedMethod.bReturningVoid(((java.lang.Object)recoveryStack[1])); }
                  recoveryAt=254; { recoveryStack[2]=-2282116631794142901L; }
                  recoveryAt=255; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=256; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectedMethod.hReturningVoid(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=257; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=260; { recoveryStack[0]=((java.lang.reflect.Method)recoveryStack[0]).invoke(((java.lang.Object)recoveryStack[1]),((java.lang.Object[])recoveryStack[2])); }
                  recoveryAt=261; { recoveryStack[0]=((java.lang.Object)recoveryStack[0]); }
                  recoveryAt=263; { recoveryPc=270; continue recoveryFlow; }
               }
               case 266 -> {
                  recoveryAt=266; { recoveryStack[0]=((java.lang.reflect.InvocationTargetException)recoveryStack[0]).getTargetException(); }
                  recoveryAt=267; { throw (Throwable)recoveryStack[0]; }
               }
               case 270 -> {
                  recoveryAt=270; { return ((java.lang.Object)recoveryStack[0]); }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=32 && recoveryAt<40 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=44; continue recoveryFlow;}
            if(recoveryAt>=37 && recoveryAt<54 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=58; continue recoveryFlow;}
            if(recoveryAt>=48 && recoveryAt<65 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=69; continue recoveryFlow;}
            if(recoveryAt>=85 && recoveryAt<92 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=96; continue recoveryFlow;}
            if(recoveryAt>=100 && recoveryAt<112 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=114; continue recoveryFlow;}
            if(recoveryAt>=118 && recoveryAt<126 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=130; continue recoveryFlow;}
            if(recoveryAt>=124 && recoveryAt<138 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=140; continue recoveryFlow;}
            if(recoveryAt>=160 && recoveryAt<173 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=177; continue recoveryFlow;}
            if(recoveryAt>=166 && recoveryAt<185 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=189; continue recoveryFlow;}
            if(recoveryAt>=219 && recoveryAt<226 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=230; continue recoveryFlow;}
            if(recoveryAt>=224 && recoveryAt<241 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=243; continue recoveryFlow;}
            if(recoveryAt>=259 && recoveryAt<262 && recoveryFailure instanceof java.lang.reflect.InvocationTargetException){recoveryStack[0]=recoveryFailure; recoveryPc=266; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

    public Object cReturningObject(Object[] objectArray) throws Throwable {
        Object object;
        block4: {
            long l;
            long l2;
            Object[] objectArray2;
            block5: {
                objectArray2 = (Object[])objectArray[0];
                l2 = (Long)objectArray[1];
                l = (l2 = 0x5B0C494A2820L ^ l2) ^ 0x4C7C58C1DF19L;
                int n = ReflectedMethod.invokeBinding79(-426455079119674148L, l2);
                try {
                    try {
                        object = this;
                        if (n == 0) break block4;
                        if (((ReflectedMethod)object).c) break block5;
                    }
                    catch (Throwable throwable) {
                        throw ReflectedMethod.invokeBinding80(throwable, -425832170216165511L, l2);
                    }
                    throw new IllegalStateException(ReflectedMethod.invokeBinding81(30280, 0x33625738D673DC44L ^ l2));
                }
                catch (Throwable throwable) {
                    throw ReflectedMethod.invokeBinding82(throwable, -425832170216165511L, l2);
                }
            }
            Object[] objectArray3 = new Object[3];
            objectArray3[2] = l;
            objectArray3[1] = objectArray2;
            objectArray3[0] = null;
            object = ReflectedMethod.invokeBinding83(this, objectArray3, -427523819009821867L, l2);
        }
        return object;
    }

    public BoundMethodInvoker cReturningcE_C0119(Object[] objectArray) {

        Object object;
        long l;
        Object object2;
        block7: {
            block8: {
                object2 = objectArray[0];
                l = (Long)objectArray[1];
                l = 0x5B0C494A2820L ^ l;
                int n = ReflectedMethod.invokeBinding84(8202640004769502938L, l);
                try {
                    try {
                        object = this;
                        if (n != 0) break block7;
                        if (!((ReflectedMethod)object).c) break block8;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedMethod.invokeBinding85(illegalArgumentException, 8203162576075711673L, l);
                    }
                    throw new IllegalStateException(ReflectedMethod.invokeBinding86(22957, 0x3DF8BE0D4BADF865L ^ l));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedMethod.invokeBinding87(illegalArgumentException, 8203162576075711673L, l);
                }
            }
            object = object2;
        }
        try {
            if (object == null) {
                throw new IllegalArgumentException(ReflectedMethod.invokeBinding88(9254, 0x33C3DABA1EE505EBL ^ l));
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw ReflectedMethod.invokeBinding89(illegalArgumentException, 8203162576075711673L, l);
        }
        return new BoundMethodInvoker(this, object2);
    
      
}

    public BoundMethodInvoker dReturningcE_C0119(Object[] objectArray) {

        Object object;
        long l;
        block7: {
            block8: {
                l = (Long)objectArray[0];
                l = 0x5B0C494A2820L ^ l;
                int n = ReflectedMethod.invokeBinding90(-7026761157064377996L, l);
                try {
                    try {
                        object = this;
                        if (n != 0) break block7;
                        if (!((ReflectedMethod)object).c) break block8;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        throw ReflectedMethod.invokeBinding91(illegalArgumentException, -7027532358922368233L, l);
                    }
                    throw new IllegalStateException(ReflectedMethod.invokeBinding92(292, 0x788B026FC5DCF44L ^ l));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw ReflectedMethod.invokeBinding93(illegalArgumentException, -7027532358922368233L, l);
                }
            }
            object = this.d;
        }
        try {
            if (object == null) {
                throw new IllegalStateException(ReflectedMethod.invokeBinding94(25055, 0x528D7B3CD5B2FBAL ^ l));
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw ReflectedMethod.invokeBinding95(illegalArgumentException, -7027532358922368233L, l);
        }
        return new BoundMethodInvoker(this, this.d);
    
      
}

   public BoundMethodInvoker eReturningcE_C0119(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      var3 = 100108327331872L ^ var3;
      long var5 = var3 ^ 107651065425940L;
      return invokeBinding96(this, new Object[]{var2, var5}, -7703862027357220082L, var3);
   }

   static {

      {

      c();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(43657121613185L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[8];
      String var17 = "K\u0017Û¥é¸{\u008dQ\u0096]Þ\u0087g_\u0088éù§sØ³ù\u0094Üä\u009c+\u0086Y\u008dÙ\u0013ô¶a]Mä\u009aI\u0097\u0091zÎRûzã`á\u008cå!\u009e<r7VùtÌ}M6Ä5\u0093\u0090s\u0085\u0018MD2÷´¥ã÷\u0091É\u000e\u0001\u008fJ\n\u009bP\u008e¸Aª¨Z^æÙ\u000bRTIù¤^ºé¦ºXRÃÎÐ-òÀvÅfÏMky>G\u0019°\u0082\u0086ÎKÖ®\u0007aû\u0083´\u0081mxT`Ø\u000e6-7Nì\u0089dâ\f\u0087+¾ôÑ\u0016\u0001Bæ\u0017\u0000gÈÛ(ÛØmÏÀ\u008b\u0002#%J\u0092yê*ËÀ{\t\u0092\u0089OF\u0096\u0016\n){m\u0099\u0003DåPÞS}Z\u000eîF@\u0012à¦\u0002¿êp`\u0000l\u0013\u001e¬Ûu\u0097ð\u0005vä¬O±³©\n·?úB!Øµx\u0089Z\u0018cVÓ\u0095¥Å\u0015B;xu\u0005ßàM@\u0010\u008dõ;9iûñ¢\u0082ñ(MeÎ4'¬&\u009aq´èé\u008f+p\u0007i\u008fú®\u008eÙO2§ìP\u0082Q»\u0082Ç!\u001b±Õ\u008b\u008f\u0086/@¯s\u000f\u0089ã\u000bpÂRSôïíéõw*·$C¥\u0005\u00185uPðd¥×\u0017ÓÀ\u008eÃ\u0003\u0089L\u001aO7U±ø\u0091÷%\u0003}À\u009b\n\u008c0\u000eê0æÊ\u001f÷\u009d.+";
      int var19 = "K\u0017Û¥é¸{\u008dQ\u0096]Þ\u0087g_\u0088éù§sØ³ù\u0094Üä\u009c+\u0086Y\u008dÙ\u0013ô¶a]Mä\u009aI\u0097\u0091zÎRûzã`á\u008cå!\u009e<r7VùtÌ}M6Ä5\u0093\u0090s\u0085\u0018MD2÷´¥ã÷\u0091É\u000e\u0001\u008fJ\n\u009bP\u008e¸Aª¨Z^æÙ\u000bRTIù¤^ºé¦ºXRÃÎÐ-òÀvÅfÏMky>G\u0019°\u0082\u0086ÎKÖ®\u0007aû\u0083´\u0081mxT`Ø\u000e6-7Nì\u0089dâ\f\u0087+¾ôÑ\u0016\u0001Bæ\u0017\u0000gÈÛ(ÛØmÏÀ\u008b\u0002#%J\u0092yê*ËÀ{\t\u0092\u0089OF\u0096\u0016\n){m\u0099\u0003DåPÞS}Z\u000eîF@\u0012à¦\u0002¿êp`\u0000l\u0013\u001e¬Ûu\u0097ð\u0005vä¬O±³©\n·?úB!Øµx\u0089Z\u0018cVÓ\u0095¥Å\u0015B;xu\u0005ßàM@\u0010\u008dõ;9iûñ¢\u0082ñ(MeÎ4'¬&\u009aq´èé\u008f+p\u0007i\u008fú®\u008eÙO2§ìP\u0082Q»\u0082Ç!\u001b±Õ\u008b\u008f\u0086/@¯s\u000f\u0089ã\u000bpÂRSôïíéõw*·$C¥\u0005\u00185uPðd¥×\u0017ÓÀ\u008eÃ\u0003\u0089L\u001aO7U±ø\u0091÷%\u0003}À\u009b\n\u008c0\u000eê0æÊ\u001f÷\u009d.+"
         .length();
      char var16 = 'X';
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     n = var20;
                     o = new String[8];
                     v = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(43657121613185L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     String var4 = "\n\u0016è\u0084\u0001ÏN\u0015í\u008bi\u0087º\u0094\u0018¿";
                     int var5 = "\n\u0016è\u0084\u0001ÏN\u0015í\u008bi\u0087º\u0094\u0018¿".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    t = var6;
                                    u = new Integer[4];
                                    g = new Object[0];
                                    h = new ConcurrentHashMap();
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "¬UuþºNE0¨'^ï\u0004£%t";
                                 var5 = "¬UuþºNE0¨'^ï\u0004£%t".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "äw\u0007¾÷JvZ7Þ\u008aÕßn\\D\u001e]Âí O \u0097;*ÀÕ}(\u008dÍë¾5Ü¢öÆ4±UÚÞ\u001aÌ=Ð\u0080Æi\u008báV·\u001aC\u0010É«³îZa\u0004¤wé\u008f¼\u001aÂËÀ2aªg ;`FºÀ/\u0081¸\u0006\u0012ÌCs{ ,YïÊà(«»3ÖAî½Wc\u0003£¸T÷\u0080\u001cç8Ô\u0087\u0087_Q'\u0002ô´\u008e¹³¹5\u008dø\f\u000b\u009aöØÓ\u0084\u0098b)³®f\u0012ÏÇÒ©ddËW©Ã]à2ôZÙ\u0093E\u0092Mvo\u001c\u009eÔ£G\r\u0096";
                  var19 = "äw\u0007¾÷JvZ7Þ\u008aÕßn\\D\u001e]Âí O \u0097;*ÀÕ}(\u008dÍë¾5Ü¢öÆ4±UÚÞ\u001aÌ=Ð\u0080Æi\u008báV·\u001aC\u0010É«³îZa\u0004¤wé\u008f¼\u001aÂËÀ2aªg ;`FºÀ/\u0081¸\u0006\u0012ÌCs{ ,YïÊà(«»3ÖAî½Wc\u0003£¸T÷\u0080\u001cç8Ô\u0087\u0087_Q'\u0002ô´\u008e¹³¹5\u008dø\f\u000b\u009aöØÓ\u0084\u0098b)³®f\u0012ÏÇÒ©ddËW©Ã]à2ôZÙ\u0093E\u0092Mvo\u001c\u009eÔ£G\r\u0096"
                     .length();
                  var16 = 'P';
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable b(Throwable var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20502;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cT", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cT_C0149",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 10473;
      if (u[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = t[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])v.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               v.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cT", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         u[var3] = var15;
      }

      return u[var3];
   }

   private static int d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = d(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cT_C0149",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = C[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = B[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 10;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 35;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 28;
            yield var20;
         }
         case 6 -> {
            byte var21 = 52;
            yield var21;
         }
         case 7 -> {
            byte var22 = 3;
            yield var22;
         }
         case 8 -> {
            byte var23 = 31;
            yield var23;
         }
         case 9 -> {
            byte var24 = 34;
            yield var24;
         }
         case 10 -> {
            byte var25 = 15;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 45;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 21;
            yield var29;
         }
         case 15 -> {
            byte var30 = 19;
            yield var30;
         }
         case 16 -> {
            byte var31 = 6;
            yield var31;
         }
         case 17 -> {
            byte var32 = 17;
            yield var32;
         }
         case 18 -> {
            byte var33 = 27;
            yield var33;
         }
         case 19 -> {
            byte var34 = 46;
            yield var34;
         }
         case 20 -> {
            byte var35 = 24;
            yield var35;
         }
         case 21 -> {
            byte var36 = 53;
            yield var36;
         }
         case 22 -> {
            byte var37 = 58;
            yield var37;
         }
         case 23 -> {
            byte var38 = 5;
            yield var38;
         }
         case 24 -> {
            byte var39 = 9;
            yield var39;
         }
         case 25 -> {
            byte var40 = 32;
            yield var40;
         }
         case 26 -> {
            byte var41 = 59;
            yield var41;
         }
         case 27 -> {
            byte var42 = 11;
            yield var42;
         }
         case 28 -> {
            byte var43 = 42;
            yield var43;
         }
         case 29 -> {
            byte var44 = 30;
            yield var44;
         }
         case 30 -> {
            byte var45 = 36;
            yield var45;
         }
         case 31 -> {
            byte var46 = 39;
            yield var46;
         }
         case 32 -> {
            byte var47 = 44;
            yield var47;
         }
         case 33 -> {
            byte var48 = 7;
            yield var48;
         }
         case 34 -> {
            byte var49 = 38;
            yield var49;
         }
         case 35 -> {
            byte var50 = 13;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 4;
            yield var53;
         }
         case 39 -> {
            byte var54 = 26;
            yield var54;
         }
         case 40 -> {
            byte var55 = 23;
            yield var55;
         }
         case 41 -> {
            byte var56 = 48;
            yield var56;
         }
         case 42 -> {
            byte var57 = 25;
            yield var57;
         }
         case 43 -> {
            byte var58 = 57;
            yield var58;
         }
         case 44 -> {
            byte var59 = 51;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 56;
            yield var61;
         }
         case 47 -> {
            byte var62 = 61;
            yield var62;
         }
         case 48 -> {
            byte var63 = 20;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 16;
            yield var65;
         }
         case 51 -> {
            byte var66 = 40;
            yield var66;
         }
         case 52 -> {
            byte var67 = 0;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 43;
            yield var70;
         }
         case 56 -> {
            byte var71 = 60;
            yield var71;
         }
         case 57 -> {
            byte var72 = 54;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 1;
            yield var75;
         }
         case 61 -> {
            byte var76 = 55;
            yield var76;
         }
         case 62 -> {
            byte var77 = 18;
            yield var77;
         }
         default -> 29;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            C[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      B[0] = "\u007f]nin>i]k3})~\u0016h5q=oQ\u007f\":/^";
      B[1] = int.class;
      C[1] = "java/lang/Integer";
      B[2] = "kmt;\u0011\u001a}mqa\u0002\rj&rg\u000e\u0019{aepE\t[";
      B[3] = "B'u@'mI(d\u000f]iZ)t@kmM";
      B[4] = ".U\u0005\\\u001898U\u0000\u0006\u000b./\u001e\u0003\u0000\u0007:>Y\u0014\u0017L*\u001b";
      B[5] = "LY\u0014}~\u00059y\u001froJXw\u0014yk\u0010,";
      B[6] = "il5\\\u00108\u007fl0\u0006\u0003/h'3\u0000\u000f;y`$\u0017D+[";
      B[7] = "!\u00063\u001b3\u001bT&8\u0014\"T5(3\u001f&\u000eA";
      B[8] = "1i*T6\u0019:f;\u001bq\u001b-g7P68>|4Z|=:f8Y}";
      B[9] = "k!zK @\u001e\u0001qD1\u000f\u007f\u000fzO5U\u000b";
      B[10] = "\u001c1[\r\u0006N\u0017>JBg@\u001c5N\u0018";
      B[11] = "\u000fWhy{\u0004\u0004Xy6\u0006\u0011\u0016B{u";
      B[12] = void.class;
      C[12] = "java/lang/Void";
      B[13] = "#\u001aYp\u007f.V:R\u007fna74Ytj;C";
      B[14] = "B]u%;HIRdj|J^Sh!;iMHk+qpQLf";
      B[15] = "u#+]Q!~,:\u0012<!~1.";
      B[16] = "=YJ\u001e\u0003uHyA\u0011\u0012:)wJ\u001a\u0016`]";
      B[17] = "\t\rO(\u001d\u001a|-D'\fU\u001d#O,\b\u000fi";
      B[18] = "\u007f?Ae7-\n\u001fJj&bk\u0011Aa\"8\u001f";
      B[19] = "\u001dtW3c6\u000btRip!\u001c?Qo|5\rxFx7%<";
      B[20] = "mz[iR<fuJ&/$urCo";
      B[21] = char.class;
      C[21] = "java/lang/Character";
      B[22] = "q\u001e\u007f?\u001et\u0004>t0\u000f;e0\u007f;\u000ba\u0011";
      B[23] = "4B|O)64IaQqfk\tk\r$ )Sz\u0000+ <Hz\fk&.Nd\u0012k>;Wx\b+4)\tE\u00005\u0001?Ji\u001156(";
      B[24] = "!h/Q}\u0014!c2O%D~#8\u0013p\u0002<y)\u001e\u007f\u0002)b)\u0012?%=l5\fw\u001e=`>\r\\\u0010!l<\u001ac";
      B[25] = "~xf0\u0015]~s{.M\r!3qr\u0018Kci`\u007f\u0017Kvr`sWUqmbw\u0017_c3SS\u0018H`x`";
      B[26] = "OOT46CQGN{{YKMW'jSKZ\f\u0016wXF[P'}XQfC&p{D^";
      B[27] = "lHP\u001a\u0005jlCM\u0004]:3\u0003GX\b|qYVU\u0007|dBVYGzvDHGGNQ`q@\u0000cq";
      B[28] = "Ne[pjh;EP\u007f{'VEPbo2";
      B[29] = "@hOsJ95HD|[vTFOw_, ";
      B[30] = "p[K^M\u000b\u0005{@Q\\DduKZX\u001e\u0010";
      B[31] = " \u0015Zt\u0012\fU5Q{\u0003C4;Zp\u0007\u0019@";
      B[32] = "3J\f\u0004tL4L^]HK3RQ\t#\\^GDP3L0HP\u001d$13[\u0005\u001b5_<OH\fH\\>\u0013Q\\5[8A\b`";
      B[33] = "\u007fSgE5t![>\u0016\tfFU<Ev0{MjMw\r*Pn\u001cvo&V:\u0019\t";
      B[34] = "%H\\Zg\u007fw\f@\u001c\u0002w#\n1Jb+.NLMdywr\\G;vv\u000f[Ai/J";
      B[35] = "gg\u001aUm=lyD-\u007f^{;U\u001c{8m>\u001a-";
      B[36] = "`zysYA2>e5<If8Qc@Lh,XcGG\u000f-t7X\u0010r*re\u0001,b -j\u0000Qe&\u007f3<";
      B[37] = "p_KgZwrLWbg JF\u001e(\u0018tw^H \u0019Iv\u001dI \\)t@\\sg";
      B[38] = "oPK$1J1X\u0012w\rYVV\u0010$r\u000ekNF,s3i\u0003B$d]fIUm\r";
      B[39] = "@|W\u0013]ZKb\tkN9\\ \u0018ZK_J%Wk";
      B[40] = "\u0000\u0000i~XW^\b0-dD9Ykp\u0002\u001e\t\u0005i%\u0002.\u0003\u00017(T\u001e_\u0003b(d";
      B[41] = "9?ksP\u000b;,wvm_\u0003&><\u0012\b>>h4\u00135?}i4VU= |gm";
      B[42] = "-qHA\u000b?\u007f5T\u0007n7+3`Q\u00122%'cU\u000b?B&E\u0005\nn?!CWSR/+\u001cXR/(-N\u0001n?\"rA\u0000\u00138$ \u0018<\u00032{/\u0019A\u00044)v%";
      B[43] = "i-N\u0002\u001d\u0013gxD\u000bz\u0003&oHr\u0013B3r\u0015N\u0010\u0014<{%";
      B[44] = "0\u0012\u0014n\u001eA3D\u001bg.\u00124I\u001dqO\u0016YFMoKMeE\u001b`B}";
      B[45] = "*n0B\u0013*5\"rQt&&/L\u0004D {:\"\u000b\u000e72Ss\u000b\u001dy\"=|A\n0K";
      B[46] = "C\u0005E'\"L]GO0S\nFsP%8\f@GA9)vHED )\u0014EXV&S\u0015\u0019E_>0\n[]\u0007^>\u0016\u0018[\u0001#9\u0010J\u0002=";
      B[47] = "&\u0001j\u0011\t.x\t3B5<\u001f\u00071\u0011Jj\"\u001fg\u0019KW&\u0001j\u0011\t.x\t3B5";
      B[48] = "K\u007f\u00047`{\u0015w]d\\kry_7#?Oa\t?\"\u0002M,\r75lBf\u001a~\\";
      B[49] = "D=y)\u000e;\u001a5 z2+};\")M\u007f@#t!LBCdriU.M1x`2";
      B[50] = "^U\u001bv %\u0000]B%\u001c5gS@vcaZK\u0016~b\\^U\u001bv %\u0000]B%\u001c";
      B[51] = "\u0000@y\u0001J\r^H Rv\u00189F\"\u0001\tI\u0004^t\t\bt\u0000@y\u0001J\r^H Rv";
      B[52] = "O\bE\u001fi\u0012A]O\u0016\u000e\u001f\u0017LI\fc!\u0010NN&t\u0011\fWC\tr\u0005qW\u0015_qCLOCWp~N\u0002G_g\u0010AHP\u0016\u000e";
      B[53] = "J\u0005qx\u001bvIS~q+2JB|xF6NB^zV,_8i U{M^\u007f%\u001aJ";
      B[54] = "\u00125{\u0019\u0001/L=\"J=:+3 \u0019Bk\u0016+v\u0011CVG6r@B4K0&E=";
      B[55] = "/0\tK,\u0018\"-\u001bMV\u0015+66\\3\u0017F'\u0010\f2F; \u0016^kz";
      B[56] = "\u0010SA\u0003g'\u001dTD\tX3\u0012Qb\u001c=5\u0007UU\u000bX<\u001aWW\u0015#9\u0006C\u0001q";
      B[57] = "9{W8hO&7\u0015+\u000fT%:j/FF#+M=\u000f\u0013h/\u001b(a\u001c\"8RA0\u001c1vB/?V&?+~?Eh/EquR!F";
      B[58] = "uY\u001aO<\f&\u0015A\r_\u000e?\u001d\u0018\u00044\u0000=\u0016qJo\u000eu\u000e\u001fE%\u0019<g\rH!V+\u0001\u001bMngzW\u0018E6\tu\u001d\u000f\f_\u001bx\u0019@\u001b9\r}Vq\tb\u0019t\t\u0017\u001fgVEW\u001dN?\u0019;\u001f\u001b\r5g";
      B[59] = "A\u0000\t!rZOU\u0003(\u0015_\u0004a\u001a+x_\u0013W\u0018Q|L\u0006D\u00183qQ\u0014Bb-(HNT\u0004;-\u0007\u007f\u0004X:eQ\u0013\n\r0l6";
      B[60] = "[s.M#~^o:\u001bGjVj\u000eO\"lCn9XGj\u0001{)G*8Ego\"";
      B[61] = "5u\f\u000fH\u0001; \u0006\u0006/\u0004p\u0013\u0016\u0007Bmbr\u0003\u001a\u001fQa$\f\u0013/S1$\u0017\u0018C]d.\u001e\u007f";
      B[62] = "\u001bb5O0\u000bI&)\tU\u001c\u0019&5H.\u000bt7b_(\u0003\u0019e&Cnf";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = B[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(C[var4]);
            B[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = B[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            B[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  B[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(734290262103590L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = B[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  B[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(734290262103590L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        B[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(734290262103590L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 253;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 89;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 243;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 197;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 242;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 68;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 253;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 89;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 243;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cT_C0149",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Object[] d() {
      return new Object[0];
   }

   private static Object[] a(Object var0, int var1) {
      return new Object[]{var0, var1};
   }

   private static Object[] b(Object var0) {
      return new Object[]{var0};
   }

   private static MethodAccessMetadata invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cV_C0153;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (MethodAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MethodAccessMetadata invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cV_C0153;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (MethodAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding3(long var0, long var2) {
         MethodHandle var8 = bindingCache3;
         MethodHandle var7 = bindingCache3;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache3 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding5(int var0, long var1) {
         MethodHandle var7 = bindingCache5;
         MethodHandle var6 = bindingCache5;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache5 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MethodAccessMetadata invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cV_C0153;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MethodAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding8(long var0, long var2) {
         MethodHandle var8 = bindingCache8;
         MethodHandle var7 = bindingCache8;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache8 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MethodAccessMetadata invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cV_C0153;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MethodAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding13(long var0, long var2) {
         MethodHandle var8 = bindingCache13;
         MethodHandle var7 = bindingCache13;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache13 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Object invokeBinding14(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache14;
         MethodHandle var9 = bindingCache14;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache14 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundMethodInvoker invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding17(long var0, long var2) {
         MethodHandle var8 = bindingCache17;
         MethodHandle var7 = bindingCache17;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache17 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = g(MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = d(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding22(int var0, long var1) {
         MethodHandle var7 = bindingCache22;
         MethodHandle var6 = bindingCache22;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache22 = d(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding23(Object var0, char var1, char var2, long var3, long var5) {
         MethodHandle var11 = bindingCache23;
         MethodHandle var10 = bindingCache23;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache23 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;CCJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (char)var1, (char)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding24(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding25(long var0, long var2) {
         MethodHandle var8 = bindingCache25;
         MethodHandle var7 = bindingCache25;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache25 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding28(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding29(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding30(long var0, long var2) {
         MethodHandle var8 = bindingCache30;
         MethodHandle var7 = bindingCache30;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache30 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding32(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache32;
         MethodHandle var11 = bindingCache32;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache32 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (String)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static ReflectedMethod invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cT_C0149;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ReflectedMethod)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding34(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache34;
         MethodHandle var10 = bindingCache34;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache34 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Throwable invokeBinding35(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundMethodInvoker invokeBinding36(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache36;
         MethodHandle var9 = bindingCache36;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache36 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ReflectedMethod invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cT_C0149;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ReflectedMethod)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundMethodInvoker invokeBinding38(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache38;
         MethodHandle var9 = bindingCache38;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache38 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static AMapper invokeBinding41(long var0, long var2) {
         MethodHandle var8 = bindingCache41;
         MethodHandle var7 = bindingCache41;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache41 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = g(MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding45(int var0, long var1) {
         MethodHandle var7 = bindingCache45;
         MethodHandle var6 = bindingCache45;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache45 = d(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding46(int var0, long var1) {
         MethodHandle var7 = bindingCache46;
         MethodHandle var6 = bindingCache46;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache46 = d(MethodHandles.lookup(), "q", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding47(Object var0, char var1, char var2, long var3, long var5) {
         MethodHandle var11 = bindingCache47;
         MethodHandle var10 = bindingCache47;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache47 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;CCJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (char)var1, (char)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding48(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache48;
         MethodHandle var9 = bindingCache48;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache48 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding49(long var0, long var2) {
         MethodHandle var8 = bindingCache49;
         MethodHandle var7 = bindingCache49;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache49 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding50(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache50;
         MethodHandle var8 = bindingCache50;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache50 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MapRemapper invokeBinding51(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache51;
         MethodHandle var8 = bindingCache51;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache51 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding52(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache52;
         MethodHandle var9 = bindingCache52;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache52 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding53(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache53;
         MethodHandle var9 = bindingCache53;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache53 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static AMapper invokeBinding54(long var0, long var2) {
         MethodHandle var8 = bindingCache54;
         MethodHandle var7 = bindingCache54;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache54 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/lenni0451/classtransform/mappings/AMapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AMapper)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MapRemapper invokeBinding55(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache55;
         MethodHandle var8 = bindingCache55;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache55 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/lenni0451/classtransform/utils/mappings/MapRemapper;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MapRemapper)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding56(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache56;
         MethodHandle var11 = bindingCache56;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache56 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (String)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static ReflectedMethod invokeBinding57(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache57;
         MethodHandle var8 = bindingCache57;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache57 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cT_C0149;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ReflectedMethod)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding58(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache58;
         MethodHandle var10 = bindingCache58;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache58 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Throwable invokeBinding59(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache59;
         MethodHandle var8 = bindingCache59;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache59 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding60(long var0, long var2) {
         MethodHandle var8 = bindingCache60;
         MethodHandle var7 = bindingCache60;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache60 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding61(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache61;
         MethodHandle var8 = bindingCache61;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache61 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding62(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache62;
         MethodHandle var8 = bindingCache62;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache62 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding63(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache63;
         MethodHandle var9 = bindingCache63;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache63 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding64(long var0, long var2) {
         MethodHandle var8 = bindingCache64;
         MethodHandle var7 = bindingCache64;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache64 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding65(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache65;
         MethodHandle var8 = bindingCache65;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache65 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding66(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache66;
         MethodHandle var8 = bindingCache66;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache66 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding67(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache67;
         MethodHandle var8 = bindingCache67;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache67 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding68(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache68;
         MethodHandle var8 = bindingCache68;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache68 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding69(int var0, long var1) {
         MethodHandle var7 = bindingCache69;
         MethodHandle var6 = bindingCache69;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache69 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding70(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache70;
         MethodHandle var8 = bindingCache70;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache70 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding71(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache71;
         MethodHandle var8 = bindingCache71;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache71 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding72(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache72;
         MethodHandle var8 = bindingCache72;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache72 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding73(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache73;
         MethodHandle var8 = bindingCache73;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache73 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding74(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache74;
         MethodHandle var8 = bindingCache74;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache74 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding75(Object var0, int var1, Object var2, int var3, int var4, long var5, long var7) {
         MethodHandle var13 = bindingCache75;
         MethodHandle var12 = bindingCache75;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache75 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;ILjava/lang/Object;IIJJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var10.invokeExact((Object)var0, (int)var1, (Object)var2, (int)var3, (int)var4, (long)var5, (long)var7);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static MethodHandle invokeBinding76(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache76;
         MethodHandle var9 = bindingCache76;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache76 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/invoke/MethodHandle;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MethodHandle)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding78(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache78;
         MethodHandle var8 = bindingCache78;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache78 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding79(long var0, long var2) {
         MethodHandle var8 = bindingCache79;
         MethodHandle var7 = bindingCache79;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache79 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding80(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache80;
         MethodHandle var8 = bindingCache80;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache80 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding81(int var0, long var1) {
         MethodHandle var7 = bindingCache81;
         MethodHandle var6 = bindingCache81;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache81 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding82(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache82;
         MethodHandle var8 = bindingCache82;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache82 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding83(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache83;
         MethodHandle var9 = bindingCache83;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache83 = g(
                  MethodHandles.lookup(), "ò", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding84(long var0, long var2) {
         MethodHandle var8 = bindingCache84;
         MethodHandle var7 = bindingCache84;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache84 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding85(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache85;
         MethodHandle var8 = bindingCache85;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache85 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding86(int var0, long var1) {
         MethodHandle var7 = bindingCache86;
         MethodHandle var6 = bindingCache86;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache86 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding87(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache87;
         MethodHandle var8 = bindingCache87;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache87 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding88(int var0, long var1) {
         MethodHandle var7 = bindingCache88;
         MethodHandle var6 = bindingCache88;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache88 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding89(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache89;
         MethodHandle var8 = bindingCache89;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache89 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding90(long var0, long var2) {
         MethodHandle var8 = bindingCache90;
         MethodHandle var7 = bindingCache90;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache90 = g(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding91(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache91;
         MethodHandle var8 = bindingCache91;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache91 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding92(int var0, long var1) {
         MethodHandle var7 = bindingCache92;
         MethodHandle var6 = bindingCache92;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache92 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding93(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache93;
         MethodHandle var8 = bindingCache93;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache93 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding94(int var0, long var1) {
         MethodHandle var7 = bindingCache94;
         MethodHandle var6 = bindingCache94;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache94 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding95(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache95;
         MethodHandle var8 = bindingCache95;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache95 = g(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BoundMethodInvoker invokeBinding96(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache96;
         MethodHandle var9 = bindingCache96;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache96 = g(
                  MethodHandles.lookup(),
                  "ò",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cE_C0119;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BoundMethodInvoker)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
