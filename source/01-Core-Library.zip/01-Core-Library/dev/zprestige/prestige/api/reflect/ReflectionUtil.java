package dev.zprestige.prestige.api.reflect;
import java.util.ArrayList;




import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.io.PrintStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.VarHandle;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import sun.misc.Unsafe;

public abstract class ReflectionUtil {
   public static final Unsafe a;
   private static final Map b;
   private static final Map c;
   private static final long j = 87250790638136L;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long[] q;
   private static final Integer[] r;
   private static final Map s;
   private static final long[] w;
   private static final Long[] x;
   private static final Map y;
   private static final Object[] z = new Object[121];
   private static final String[] A = new String[121];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;

   public static AccessibleObject aReturningAccessibleObject(Object[] var0) {
      AccessibleObject var1 = (AccessibleObject)var0[0];
      long var2 = (Long)var0[1];
      var2 = 87250790638136L ^ var2;
      Unsafe var18 = a;
      if (var18 == null) {
         AccessibleObject var6 = var1;
         var6.setAccessible(true);
         return var1;
      }

      try {
         short var10002 = 28941;
         long var10003 = 4502482866971009333L ^ var2;
         AccessibleObject var10 = var1;
         Unsafe var9 = a;
         var9.putBoolean(var10, 12L, true);
         return var1;
      } catch (Throwable var20) {
            AccessibleObject var14 = var1;
            var14.setAccessible(true);
         } catch (Throwable var19) {
         }

         return var1;
      }
   }

   public static void aReturningVoid(Object[] var0) {
      Field var1 = (Field)var0[0];
      long var2 = (Long)var0[1];
      var2 = 87250790638136L ^ var2;

      try {
         short var10001 = 9324;
         long var10002 = 1890827712199170240L ^ var2;
         String var7 = "modifiers";
         Class<Field> var6 = Field.class;
         Field var4 = var6.getDeclaredField(var7);
         Field var8 = var4;
         var8.setAccessible(true);
         Field var10 = var1;
         int var5 = var10.getModifiers();
         var10001 = 3756;
         var10002 = 3167194889589797296L ^ var2;
         int var15 = var5 & 16;
         if (var15 != 0) {
            short var10003 = 10121;
            long var10004 = 3601779285808781470L ^ var2;
            int var13 = var5 & -17;
            Field var12 = var1;
            Field var11 = var4;
            var11.setInt(var12, var13);
      } catch (Throwable var16) {
      }
   }

   protected static FieldAccessMetadata aReturningcU_C0151(Object[] var0) {
      Class var1 = (Class)var0[0];
      String var4 = (String)var0[1];
      long var2 = (Long)var0[2];
      var2 = 87250790638136L ^ var2;
      long var5 = var2 ^ 132158651657893L;
      long var7 = var2 ^ 67915101745477L;
      int var10000 = Event.cReturningInt();
      Class var18 = var1;
      String var10 = var18.getName() + "#" + var4;
      String var20 = var10;
      Map var19 = b;
      FieldAccessMetadata var11 = (FieldAccessMetadata)var19.get(var20);
      int var9 = var10000;
      int var74 = var9;
      FieldAccessMetadata var73 = var11;
      FieldAccessMetadata var42 = var73;
      FieldAccessMetadata var41 = var73;
      if (var74 != 0) {
         FieldAccessMetadata var75 = var41;
         if (var75 == null) {
               String var23 = var4;
               Class var22 = var1;
               Field var12 = var22.getDeclaredField(var23);
               Object[] var24 = new Object[]{var12, var5};
               aReturningAccessibleObject(var24);
               Object[] var25 = new Object[]{var12, var7};
               aReturningVoid(var25);
               Field var26 = var12;
               int var27 = var26.getModifiers();
               boolean var13 = Modifier.isStatic(var27);
               VarHandle var14 = null;

               try {
                  Object[] var10001 = b();
                  Method var10003 = d(5823221932973592897L, var2);
                  Object[] var46 = var10001;
                  Object var45 = null;
                  Method var44 = var10003;
                  Class var43 = var1;

                  Class var47;
                  Object var48;
                  try {
                     var48 = var44.invoke(var45, var46);
                     var47 = var43;
                  } catch (InvocationTargetException var89) {
                     throw var89.getTargetException();
                  }

                  Object var77 = var48;
                  Class var76 = var47;
                  Class var50 = var76;
                  Object var51 = var77;
                  Object[] var96 = a(var50, var51);
                  Method var99 = d(5822686292973419499L, var2);
                  Object[] var54 = var96;
                  Object var53 = null;
                  Method var52 = var99;

                  Lookup var55;
                  try {
                     var55 = (Lookup)var52.invoke(var53, var54);
                  } catch (InvocationTargetException var88) {
                     throw var88.getTargetException();
                  }

                  Lookup var78 = var55;
                  Lookup var57 = var78;
                  Lookup var15 = var57;
                  boolean var79 = var13;
                  if (var79) {
                     Field var28 = var12;
                     var10001 = a((Object)var1, (Object)var4, (Object)var28.getType());
                     var10003 = d(5819448630547795373L, var2);
                     Object[] var60 = var10001;
                     Lookup var59 = var15;
                     Method var58 = var10003;

                     VarHandle var61;
                     try {
                        var61 = (VarHandle)var58.invoke(var59, var60);
                     } catch (InvocationTargetException var87) {
                        throw var87.getTargetException();
                     }

                     VarHandle var80 = var61;
                     VarHandle var63 = var80;
                     var14 = var63;
                  } else {
                     Field var29 = var12;
                     var10001 = a((Object)var1, (Object)var4, (Object)var29.getType());
                     var10003 = d(5820345103250796610L, var2);
                     Object[] var66 = var10001;
                     Lookup var65 = var15;
                     Method var64 = var10003;

                     VarHandle var67;
                     try {
                        var67 = (VarHandle)var64.invoke(var65, var66);
                     } catch (InvocationTargetException var86) {
                        throw var86.getTargetException();
                     }

                     VarHandle var81 = var67;
                     VarHandle var69 = var81;
                     var14 = var69;
               } catch (Throwable var90) {
               }

               label87: {
                  Unsafe var82 = a;
                  if (var82 == null) {
                     short var102 = 31260;
                     long var10006 = 3476629846313625274L ^ var2;
                     var11 = new FieldAccessMetadata(var12, var13, null, -1L, var14);
                     int var83 = var9;
                     if (var83 != 0) {
                        break label87;
                     }
                  }

                  boolean var84 = var13;
                  if (var84) {
                     Field var32 = var12;
                     Unsafe var31 = a;
                     Object var94 = var31.staticFieldBase(var32);
                     Field var34 = var12;
                     Unsafe var33 = a;
                     long var16 = var33.staticFieldOffset(var34);
                     var11 = new FieldAccessMetadata(var12, true, var94, var16, var14);
                     int var85 = var9;
                     if (var85 != 0) {
                        break label87;
                     }
                  }

                  Field var36 = var12;
                  Unsafe var35 = a;
                  long var95 = var35.objectFieldOffset(var36);
                  var11 = new FieldAccessMetadata(var12, false, null, var95, var14);
               }

               FieldAccessMetadata var39 = var11;
               String var38 = var10;
               Map var37 = b;
               var37.put(var38, var39);
               return var11;
            } catch (NoSuchFieldException var91) {
               Class var40 = var1;
               String var10002 = String.valueOf(var40);
               short var10004 = 8504;
               long var10005 = 5005013853452193519L ^ var2;
               throw new RuntimeException("Field not found: " + var10002 + "." + var4, var91);
            }
         }

         var42 = var11;
      }

      return var42;
   }

   protected static FieldAccessMetadata bReturningcU_C0151(Object[] var0) {
      Class var3 = (Class)var0[0];
      String var1 = (String)var0[1];
      String var2 = (String)var0[2];
      long var4 = (Long)var0[3];
      var4 = 87250790638136L ^ var4;
      long var6 = var4 ^ 102705573484586L;
      long var8 = var4 ^ 99028144929386L;
      long var10 = var4 ^ 27071779080138L;
      Class var26 = var3;
      String var12 = var26.getName() + "#" + var1 + ":" + var2;
      String var28 = var12;
      Map var27 = b;
      FieldAccessMetadata var13 = (FieldAccessMetadata)var27.get(var28);
      FieldAccessMetadata var89 = var13;
      if (var89 != null) {
         return var13;
      }

      Class var14 = var3;

      Class var15;
      try {
         Class var30 = var3;
         Object[] var31 = new Object[]{var2, var30.getClassLoader(), var8};
         var15 = aReturningClass(var31);
      } catch (ClassNotFoundException var105) {
         short var10003 = 25273;
         long var10004 = 5333755468641123302L ^ var4;
         throw new RuntimeException("Failed to parse field descriptor: " + var2, var105);
      }

      while (true) {
         Class var90 = var14;
         if (var90 == null) {
            Class var57 = var3;
            String var116 = String.valueOf(var57);
            short var122 = 19836;
            long var123 = 2095293822863414315L ^ var4;
            throw new RuntimeException("Field not found: " + var116 + "." + var1);
         }

         try {
            String var33 = var1;
            Class var32 = var14;
            Field var16 = var32.getDeclaredField(var33);
            Field var34 = var16;
            Class var10000 = var34.getType();
            Class var36 = var15;
            Class var35 = var10000;
            boolean var91 = var35.equals(var36);
            if (!var91) {
               Class var37 = var14;
               String var114 = String.valueOf(var37);
               Class var38 = var15;
               String var121 = String.valueOf(var38);
               Field var39 = var16;
               Class var40 = var39.getType();
               String var22 = String.valueOf(var40);
               String var23 = var121;
               String var24 = var1;
               String var25 = var114;
               short var115 = 17285;
               long var120 = 8967279812394457823L ^ var4;
               short var124 = 14777;
               long var10007 = 3953881152565240032L ^ var4;
               short var10008 = 25026;
               long var10009 = 925267164412983454L ^ var4;
               throw new RuntimeException("Field type mismatch for " + var25 + "." + var24 + ": expected " + var23 + " but found " + var22);
            }

            Object[] var41 = new Object[]{var16, var6};
            aReturningAccessibleObject(var41);
            Object[] var42 = new Object[]{var16, var10};
            aReturningVoid(var42);
            Field var43 = var16;
            int var44 = var43.getModifiers();
            boolean var17 = Modifier.isStatic(var44);
            VarHandle var18 = null;

            try {
               Object[] var10001 = b();
               Method var117 = d(7376641263449319374L, var4);
               Object[] var62 = var10001;
               Object var61 = null;
               Method var60 = var117;
               Class var59 = var14;

               Class var63;
               Object var64;
               try {
                  var64 = var60.invoke(var61, var62);
                  var63 = var59;
               } catch (InvocationTargetException var103) {
                  throw var103.getTargetException();
               }

               Object var93 = var64;
               Class var92 = var63;
               Class var66 = var92;
               Object var67 = var93;
               Object[] var111 = a(var66, var67);
               Method var10002 = d(7368296973473041764L, var4);
               Object[] var70 = var111;
               Object var69 = null;
               Method var68 = var10002;

               Lookup var71;
               try {
                  var71 = (Lookup)var68.invoke(var69, var70);
               } catch (InvocationTargetException var102) {
                  throw var102.getTargetException();
               }

               Lookup var94 = var71;
               Lookup var73 = var94;
               Lookup var19 = var73;
               boolean var95 = var17;
               if (var95) {
                  Field var45 = var16;
                  var10001 = a((Object)var14, (Object)var1, (Object)var45.getType());
                  var117 = d(7371813051951643426L, var4);
                  Object[] var76 = var10001;
                  Lookup var75 = var19;
                  Method var74 = var117;

                  VarHandle var77;
                  try {
                     var77 = (VarHandle)var74.invoke(var75, var76);
                  } catch (InvocationTargetException var100) {
                     throw var100.getTargetException();
                  }

                  VarHandle var96 = var77;
                  VarHandle var79 = var96;
                  var18 = var79;
               } else {
                  Field var46 = var16;
                  var10001 = a((Object)var14, (Object)var1, (Object)var46.getType());
                  var117 = d(7370457806982842061L, var4);
                  Object[] var82 = var10001;
                  Lookup var81 = var19;
                  Method var80 = var117;

                  VarHandle var83;
                  try {
                     var83 = (VarHandle)var80.invoke(var81, var82);
                  } catch (InvocationTargetException var101) {
                     throw var101.getTargetException();
                  }

                  VarHandle var97 = var83;
                  VarHandle var85 = var97;
                  var18 = var85;
            } catch (Throwable var104) {
            }

            Unsafe var98 = a;
            if (var98 == null) {
               short var10005 = 416;
               long var10006 = 634611395192335243L ^ var4;
               var13 = new FieldAccessMetadata(var16, var17, null, -1L, var18);
            } else {
               boolean var99 = var17;
               if (var99) {
                  Field var48 = var16;
                  Unsafe var47 = a;
                  Object var109 = var47.staticFieldBase(var48);
                  Field var50 = var16;
                  Unsafe var49 = a;
                  long var20 = var49.staticFieldOffset(var50);
                  var13 = new FieldAccessMetadata(var16, true, var109, var20, var18);
               } else {
                  Field var52 = var16;
                  Unsafe var51 = a;
                  long var110 = var51.objectFieldOffset(var52);
                  var13 = new FieldAccessMetadata(var16, false, null, var110, var18);
               }
            }

            FieldAccessMetadata var55 = var13;
            String var54 = var12;
            Map var53 = b;
            var53.put(var54, var55);
            return var13;
         } catch (NoSuchFieldException var106) {
            Class var56 = var14;
            var14 = var56.getSuperclass();
         }
      }
   }

   protected static MethodAccessMetadata aReturningcV_C0153(Object[] var0) {

      Class var2 = (Class)var0[0];
      String var5 = (String)var0[1];
      Class[] var1 = (Class[])var0[2];
      long var3 = (Long)var0[3];
      var3 = 87250790638136L ^ var3;
      long var6 = var3 ^ 99394958571304L;
      long var8 = var3 ^ 105106448828454L;
      String var10 = invokeBinding1(var2, -8554094755914123196L, var3)
         + "#"
         + var5
         + ":"
         + invokeBinding2(new Object[]{var1, var8}, -8556769399096828758L, var3);
      MethodAccessMetadata var11 = (MethodAccessMetadata)invokeBinding3(c, var10, -8555536049706727871L, var3);

      try {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

         MethodAccessMetadata var76 = var11;
         if (var76 != null) {
            return var11;
         }
      } catch (NoSuchMethodException var107) {
         throw invokeBinding4(var107, -8556766015311612128L, var3);
      }

      Class var12 = var2;

      label144:
      while (true) {
         Class var77 = var12;
         if (var77 != null) {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

         dev.prestige.recovery.SourceSupport.<IllegalAccessException>checkedBoundary();

               Method var111 = invokeBinding5(var12, var5, var1, -8556589169311799408L, var3);
               invokeBinding6(new Object[]{var111, var6}, -8548333807830158200L, var3);
               Object[] var119 = b();
               Method var124 = d(-8548642250561074996L, var3);
               Object[] var29 = var119;
               Object var28 = null;
               Method var27 = var124;
               Class var26 = var12;

               Class var30;
               Object var31;
               try {
                  var31 = var27.invoke(var28, var29);
                  var30 = var26;
               } catch (InvocationTargetException var97) {
                  throw var97.getTargetException();
               }

               Object var79 = var31;
               Class var78 = var30;
               Class var33 = var78;
               Object var34 = var79;
               Object[] var117 = a(var33, var34);
               Method var122 = d(-8555867316083383706L, var3);
               Object[] var37 = var117;
               Object var36 = null;
               Method var35 = var122;

               Lookup var38;
               try {
                  var38 = (Lookup)var35.invoke(var36, var37);
               } catch (InvocationTargetException var96) {
                  throw var96.getTargetException();
               }

               Lookup var80 = var38;
               Lookup var40 = var80;
               Lookup var112 = var40;
               var119 = a(var111);
               var124 = d(-8554443904368601468L, var3);
               Object[] var43 = var119;
               Lookup var42 = var112;
               Method var41 = var124;

               MethodHandle var44;
               try {
                  var44 = (MethodHandle)var41.invoke(var42, var43);
               } catch (InvocationTargetException var95) {
                  throw var95.getTargetException();
               }

               MethodHandle var81 = var44;
               MethodHandle var46 = var81;
               MethodHandle var113 = var46;
               boolean var114 = invokeBinding8(invokeBinding7(var111, -8555144596943462899L, var3), -8556165248896669661L, var3);
               var11 = new MethodAccessMetadata(var111, var113, var114);
               invokeBinding9(c, var10, var11, -8552669764942183407L, var3);
               return var11;
            } catch (NoSuchMethodException | IllegalAccessException var106) {
               Method[] var13 = invokeBinding10(var12, -8556379975165985824L, var3);
               int var14 = var13.length;
               while (true) {
                  int var83 = var14;
                  int var82 = var15;
                  if (var82 >= var83) {
                     var12 = invokeBinding24(var12, -8553630218287180394L, var3);
                     continue label144;
                  }

                  Method var16 = var13[var15];

                  label156: {
                     try {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

                        boolean var84 = invokeBinding12(invokeBinding11(var16, -8555063361137290091L, var3), var5, -8555836205499597759L, var3);
                        if (!var84) {
                           break label156;
                        }
                     } catch (NoSuchMethodException var105) {
                        throw invokeBinding13(var105, -8556766015311612128L, var3);
                     }

                     try {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

                        int var10000 = invokeBinding14(var16, -8553938244381624292L, var3);
                        int var86 = var1.length;
                        int var85 = var10000;
                        if (var85 != var86) {
                           break label156;
                        }
                     } catch (NoSuchMethodException var104) {
                        throw invokeBinding15(var104, -8556766015311612128L, var3);
                     }

                     byte var17 = 1;
                     Class[] var18 = invokeBinding16(var16, -8555210644003690792L, var3);
                     label124: {
                        while (true) {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

                              int var88 = var18.length;
                              int var87 = var19;
                              if (var87 >= var88) {
                                 break label124;
                              }

                              boolean var89 = invokeBinding17(var18[var19], var1[var19], -8548431752090243651L, var3);
                              if (!var89) {
                                 break;
                              }
                           } catch (NoSuchMethodException var103) {
                              throw invokeBinding18(var103, -8556766015311612128L, var3);
                           }

                           var19++;
                        }

                        var17 = 0;
                     }

                     try {
         dev.prestige.recovery.SourceSupport.<NoSuchMethodException>checkedBoundary();

                        byte var90 = var17;
                        if (var90 == 0) {
                           break label156;
                        }
                     } catch (NoSuchMethodException var102) {
                        throw invokeBinding19(var102, -8556766015311612128L, var3);
                     }

                     try {
                        invokeBinding20(new Object[]{var16, var6}, -8548333807830158200L, var3);
                        Object[] var10001 = b();
                        Method var10003 = d(-8548642250561074996L, var3);
                        Object[] var56 = var10001;
                        Object var55 = null;
                        Method var54 = var10003;
                        Class var53 = var12;

                        Class var57;
                        Object var58;
                        try {
                           var58 = var54.invoke(var55, var56);
                           var57 = var53;
                        } catch (InvocationTargetException var100) {
                           throw var100.getTargetException();
                        }

                        Object var92 = var58;
                        Class var91 = var57;
                        Class var60 = var91;
                        Object var61 = var92;
                        Object[] var116 = a(var60, var61);
                        Method var121 = d(-8555867316083383706L, var3);
                        Object[] var64 = var116;
                        Object var63 = null;
                        Method var62 = var121;

                        Lookup var65;
                        try {
                           var65 = (Lookup)var62.invoke(var63, var64);
                        } catch (InvocationTargetException var99) {
                           throw var99.getTargetException();
                        }

                        Lookup var93 = var65;
                        Lookup var67 = var93;
                        Lookup var115 = var67;
                        var10001 = a(var16);
                        var10003 = d(-8554443904368601468L, var3);
                        Object[] var70 = var10001;
                        Lookup var69 = var115;
                        Method var68 = var10003;

                        MethodHandle var71;
                        try {
                           var71 = (MethodHandle)var68.invoke(var69, var70);
                        } catch (InvocationTargetException var98) {
                           throw var98.getTargetException();
                        }

                        MethodHandle var94 = var71;
                        MethodHandle var73 = var94;
                        MethodHandle var20 = var73;
                        boolean var21 = invokeBinding22(invokeBinding21(var16, -8555144596943462899L, var3), -8556165248896669661L, var3);
                        var11 = new MethodAccessMetadata(var16, var20, var21);
                        invokeBinding23(c, var10, var11, -8552669764942183407L, var3);
                        return var11;
                     } catch (Throwable var101) {
                     }
                  }

                  var15++;
               }
            }
         }

         String var10002 = invokeBinding25(var2, -8554546047352959490L, var3);
         String var22 = invokeBinding26(var1, -8552896655134642380L, var3);
         String var23 = var5;
         String var24 = var10002;
         throw new RuntimeException(invokeBinding27(25117, 7084982704030536783L ^ var3) + var24 + "." + var23 + var22);
      }
   
      
}

   protected static MethodAccessMetadata bReturningcV_C0153(Object[] var0) {
      Class var4 = (Class)var0[0];
      String var5 = (String)var0[1];
      String var1 = (String)var0[2];
      long var2 = (Long)var0[3];
      var2 = 87250790638136L ^ var2;
      long var6 = var2 ^ 124225051925513L;
      long var8 = var2 ^ 129939439487344L;

      try {
         dev.prestige.recovery.SourceSupport.<ClassNotFoundException>checkedBoundary();

         Class[] var10 = invokeBinding29(new Object[]{var1, invokeBinding28(var4, -618007098547844393L, var2), var8}, -616090600566301290L, var2);
         return invokeBinding30(new Object[]{var4, var5, var10, var6}, -615826129751349314L, var2);
      } catch (ClassNotFoundException var13) {
         throw new RuntimeException(invokeBinding31(27361, 8284703895896138375L ^ var2) + var1, var13);
      }
   }

    private static String aReturningString(Object[] objectArray) {

        long l;
        Class[] classArray;
        block7: {
            classArray = (Class[])objectArray[0];
            l = (Long)objectArray[1];
            l = 0x4F5AA861E238L ^ l;
            try {
                try {
                    if (classArray != null && classArray.length != 0) break block7;
                }
                catch (RuntimeException runtimeException) {
                    throw ReflectionUtil.invokeBinding32(runtimeException, -6674806992565084866L, l);
                }
                return ReflectionUtil.invokeBinding33(21434, 0x211CC8F75C644FF0L ^ l);
            }
            catch (RuntimeException runtimeException) {
                throw ReflectionUtil.invokeBinding34(runtimeException, -6674806992565084866L, l);
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (Class clazz : classArray) {
            String string;
            StringBuilder stringBuilder2;
            try {
                stringBuilder2 = stringBuilder;
                string = clazz == null ? ReflectionUtil.invokeBinding35(12197, 0x7A8611B647B633E8L ^ l) : ReflectionUtil.invokeBinding37(clazz, -6676638233299856806L, l);
            }
            catch (RuntimeException runtimeException) {
                throw ReflectionUtil.invokeBinding36(runtimeException, -6674806992565084866L, l);
            }
            ReflectionUtil.invokeBinding40(ReflectionUtil.invokeBinding38(stringBuilder2, string, -6674388570166126790L, l), (char)ReflectionUtil.invokeBinding39(12910, 0x680D98912D462D90L ^ l), -6677223527306121504L, l);
        }
        return ReflectionUtil.invokeBinding41(stringBuilder, -6677678441575347953L, l);
    
      
}

    public static Class[] aReturningArrayOfClass(final Object[] array) throws ClassNotFoundException {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[22];
      recoveryLocals[0]=array;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.String)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.ClassLoader)recoveryStack[1]); }
                  recoveryAt=10; { recoveryLocals[1]=recoveryStack[1];  }
                  recoveryAt=11; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=12; { recoveryStack[2]=2; }
                  recoveryAt=13; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=14; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=16; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=18; { recoveryStack[0]=87250790638136L; }
                  recoveryAt=19; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=20; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=21; { recoveryLocals[3]=recoveryStack[0];  }
                  recoveryAt=22; { recoveryStack[0]=recoveryLocals[3];  }
                  recoveryAt=23; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=24; { recoveryStack[2]=78339585180753L; }
                  recoveryAt=25; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=26; { recoveryLocals[5]=recoveryStack[1];  }
                  recoveryAt=27; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=28; { recoveryStack[2]=24920221062036L; }
                  recoveryAt=29; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=30; { recoveryLocals[7]=recoveryStack[1];  }
                  recoveryAt=32; { recoveryStack[0]=2034886183207802046L; }
                  recoveryAt=33; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=34; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding42(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=35; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=38; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=39; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=40; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=68; continue recoveryFlow;} recoveryPc=42; continue recoveryFlow; }
               }
               case 42 -> {
                  recoveryAt=42; { if(recoveryStack[0]!=null){recoveryPc=65; continue recoveryFlow;} recoveryPc=44; continue recoveryFlow; }
               }
               case 44 -> {
                  recoveryAt=44; { recoveryPc=53; continue recoveryFlow; }
               }
               case 47 -> {
                  recoveryAt=47; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=48; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=49; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding43(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=50; { throw (Throwable)recoveryStack[0]; }
               }
               case 53 -> {
                  recoveryAt=53; { recoveryStack[0]=0; }
                  recoveryAt=54; { recoveryStack[0]=new java.lang.Class[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])]; }
                  recoveryAt=55; { return ((java.lang.Class[])recoveryStack[0]); }
               }
               case 58 -> {
                  recoveryAt=58; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=59; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=60; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding44(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=61; { throw (Throwable)recoveryStack[0]; }
               }
               case 65 -> {
                  recoveryAt=65; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryPc=68; continue recoveryFlow;
               }
               case 68 -> {
                  recoveryAt=68; { recoveryStack[1]=2132; }
                  recoveryAt=69; { recoveryStack[2]=3898444346121038024L; }
                  recoveryAt=70; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=71; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=72; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding45(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=73; { recoveryStack[2]=2028850250345993626L; }
                  recoveryAt=74; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=75; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding46(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=76; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=79; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=80; { recoveryStack[1]=3089; }
                  recoveryAt=81; { recoveryStack[2]=503258270168558723L; }
                  recoveryAt=82; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=83; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=84; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding47(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=85; { recoveryStack[2]=2028850250345993626L; }
                  recoveryAt=86; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=87; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding48(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=88; { recoveryLocals[11]=recoveryStack[0];  }
                  recoveryAt=91; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=92; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=93; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=108; continue recoveryFlow;} recoveryPc=94; continue recoveryFlow; }
               }
               case 94 -> {
                  recoveryAt=94; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<0){recoveryPc=129; continue recoveryFlow;} recoveryPc=96; continue recoveryFlow; }
               }
               case 96 -> {
                  recoveryAt=96; { recoveryPc=105; continue recoveryFlow; }
               }
               case 99 -> {
                  recoveryAt=99; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=100; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=101; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding49(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=102; { throw (Throwable)recoveryStack[0]; }
               }
               case 105 -> {
                  recoveryAt=105; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryPc=108; continue recoveryFlow;
               }
               case 108 -> {
                  recoveryAt=108; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=109; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=124; continue recoveryFlow;} recoveryPc=110; continue recoveryFlow; }
               }
               case 110 -> {
                  recoveryAt=110; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<0){recoveryPc=129; continue recoveryFlow;} recoveryPc=112; continue recoveryFlow; }
               }
               case 112 -> {
                  recoveryAt=112; { recoveryPc=121; continue recoveryFlow; }
               }
               case 115 -> {
                  recoveryAt=115; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=116; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=117; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding50(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=118; { throw (Throwable)recoveryStack[0]; }
               }
               case 121 -> {
                  recoveryAt=121; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryPc=124; continue recoveryFlow;
               }
               case 124 -> {
                  recoveryAt=124; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=125; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=150; continue recoveryFlow;} recoveryPc=129; continue recoveryFlow; }
               }
               case 129 -> {
                  recoveryAt=129; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(java.lang.IllegalArgumentException.class); recoveryStack[0]=new Object(); }
                  recoveryAt=130; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=131; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=132; { recoveryStack[3]=3944; }
                  recoveryAt=133; { recoveryStack[4]=5048089952794455118L; }
                  recoveryAt=134; { recoveryStack[5]=recoveryLocals[3];  }
                  recoveryAt=135; { recoveryStack[4]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5]); }
                  recoveryAt=136; { recoveryStack[3]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding51(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=137; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=138; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.concatenate("\u0001\u0001",new Object[]{((java.lang.String)recoveryStack[2]),((java.lang.String)recoveryStack[3])},new Object[]{}); }
                  recoveryAt=139; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new java.lang.IllegalArgumentException(((java.lang.String)recoveryStack[2])); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=140; { throw (Throwable)recoveryStack[0]; }
               }
               case 143 -> {
                  recoveryAt=143; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=144; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=145; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding52(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=146; { throw (Throwable)recoveryStack[0]; }
               }
               case 150 -> {
                  recoveryAt=150; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=151; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=152; { recoveryStack[2]=1; }
                  recoveryAt=153; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])+dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]); }
                  recoveryAt=154; { recoveryStack[2]=recoveryLocals[11];  }
                  recoveryAt=155; { recoveryStack[3]=2032984947328441872L; }
                  recoveryAt=156; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=157; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding53(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=158; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=161; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(java.util.ArrayList.class); recoveryStack[0]=new Object(); }
                  recoveryAt=162; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=163; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new java.util.ArrayList(); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=164; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=167; { recoveryStack[0]=0; }
                  recoveryAt=168; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryPc=172; continue recoveryFlow;
               }
               case 172 -> {
                  recoveryAt=172; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=173; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=174; { recoveryStack[2]=2028091388577600322L; }
                  recoveryAt=175; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=176; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding54(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=179; continue recoveryFlow;
               }
               case 179 -> {
                  recoveryAt=179; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=445; continue recoveryFlow;} recoveryPc=182; continue recoveryFlow; }
               }
               case 182 -> {
                  recoveryAt=182; { recoveryStack[0]=0; }
                  recoveryAt=183; { recoveryLocals[15]=recoveryStack[0];  }
                  recoveryPc=187; continue recoveryFlow;
               }
               case 187 -> {
                  recoveryAt=187; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=188; { recoveryStack[1]=recoveryLocals[12];  }
                  recoveryAt=189; { recoveryStack[2]=2028091388577600322L; }
                  recoveryAt=190; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=191; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding55(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=192; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=238; continue recoveryFlow;} recoveryPc=194; continue recoveryFlow; }
               }
               case 194 -> {
                  recoveryAt=194; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=195; { recoveryStack[1]=recoveryLocals[14];  }
                  recoveryAt=196; { recoveryStack[2]=2031302278659194893L; }
                  recoveryAt=197; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=198; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding56(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=199; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=200; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=245; continue recoveryFlow;} recoveryPc=201; continue recoveryFlow; }
               }
               case 201 -> {
                  recoveryAt=201; { recoveryStack[1]=31897; }
                  recoveryAt=202; { recoveryStack[2]=5609361115006426114L; }
                  recoveryAt=203; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=204; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=205; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding57(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=206; { recoveryStack[2]=recoveryLocals[9];  }
                  recoveryAt=207; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])==0){recoveryPc=179; continue recoveryFlow;} recoveryPc=209; continue recoveryFlow; }
               }
               case 209 -> {
                  recoveryAt=209; { recoveryPc=218; continue recoveryFlow; }
               }
               case 212 -> {
                  recoveryAt=212; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=213; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=214; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding58(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=215; { throw (Throwable)recoveryStack[0]; }
               }
               case 218 -> {
                  recoveryAt=218; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=238; continue recoveryFlow;} recoveryPc=221; continue recoveryFlow; }
               }
               case 221 -> {
                  recoveryAt=221; { recoveryLocals[15]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[15])+(1); }
                  recoveryAt=224; { recoveryLocals[14]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[14])+(1); }
                  recoveryAt=225; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=226; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=187; continue recoveryFlow;} recoveryPc=228; continue recoveryFlow; }
               }
               case 228 -> {
                  recoveryAt=228; { recoveryPc=238; continue recoveryFlow; }
               }
               case 231 -> {
                  recoveryAt=231; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=232; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=233; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding59(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=234; { throw (Throwable)recoveryStack[0]; }
               }
               case 238 -> {
                  recoveryAt=238; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=239; { recoveryStack[1]=recoveryLocals[14];  }
                  recoveryAt=240; { recoveryStack[2]=2031302278659194893L; }
                  recoveryAt=241; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=242; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding60(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryPc=245; continue recoveryFlow;
               }
               case 245 -> {
                  recoveryAt=245; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=248; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=249; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=250; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=377; continue recoveryFlow;} recoveryPc=251; continue recoveryFlow; }
               }
               case 251 -> {
                  recoveryAt=251; { recoveryStack[1]=433; }
                  recoveryAt=252; { recoveryStack[2]=2816905496043299113L; }
                  recoveryAt=253; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=254; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=255; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding61(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=256; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=366; continue recoveryFlow;} recoveryPc=258; continue recoveryFlow; }
               }
               case 258 -> {
                  recoveryAt=258; { recoveryPc=268; continue recoveryFlow; }
               }
               case 261 -> {
                  recoveryAt=261; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=262; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=263; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding62(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=264; { throw (Throwable)recoveryStack[0]; }
               }
               case 268 -> {
                  recoveryAt=268; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=269; { recoveryStack[1]=7364; }
                  recoveryAt=270; { recoveryStack[2]=3571478250634034270L; }
                  recoveryAt=271; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=272; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=273; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding63(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=274; { recoveryStack[2]=recoveryLocals[14];  }
                  recoveryAt=275; { recoveryStack[3]=2034163106126466801L; }
                  recoveryAt=276; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=277; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding64(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=278; { recoveryLocals[17]=recoveryStack[0];  }
                  recoveryAt=281; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=282; { recoveryStack[1]=recoveryLocals[14];  }
                  recoveryAt=283; { recoveryStack[2]=1; }
                  recoveryAt=284; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])+dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]); }
                  recoveryAt=285; { recoveryStack[2]=recoveryLocals[17];  }
                  recoveryAt=286; { recoveryStack[3]=2032984947328441872L; }
                  recoveryAt=287; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=288; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding65(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=289; { recoveryLocals[18]=recoveryStack[0];  }
                  recoveryAt=292; { recoveryStack[0]=recoveryLocals[18];  }
                  recoveryAt=293; { recoveryStack[1]=23094; }
                  recoveryAt=294; { recoveryStack[2]=2425310926526905003L; }
                  recoveryAt=295; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=296; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=297; { recoveryStack[1]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding66(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=298; { recoveryStack[2]=18928; }
                  recoveryAt=299; { recoveryStack[3]=636835654343584103L; }
                  recoveryAt=300; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=301; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=302; { recoveryStack[2]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding67(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=303; { recoveryStack[3]=2035068623654696712L; }
                  recoveryAt=304; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=305; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding68(((java.lang.Object)recoveryStack[0]),(char)dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),(char)dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=306; { recoveryLocals[19]=recoveryStack[0];  }
                  recoveryAt=309; { recoveryStack[0]=recoveryLocals[19];  }
                  recoveryAt=310; { recoveryStack[1]=0; }
                  recoveryAt=311; { recoveryStack[2]=recoveryLocals[1];  }
                  recoveryAt=312; { recoveryStack[3]=2033506282478774771L; }
                  recoveryAt=313; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=314; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding69(((java.lang.Object)recoveryStack[0]),((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]) & 1) != 0),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=315; { recoveryLocals[20]=recoveryStack[0];  }
                  recoveryAt=318; { recoveryStack[0]=recoveryLocals[20];  }
                  recoveryAt=319; { recoveryStack[1]=recoveryLocals[15];  }
                  recoveryAt=320; { recoveryStack[2]=recoveryLocals[7];  }
                  recoveryAt=321; { recoveryStack[3]=3; }
                  recoveryAt=322; { recoveryStack[3]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]; }
                  recoveryAt=323; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=324; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=326; { recoveryStack[4]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=327; { recoveryStack[5]=2; }
                  recoveryAt=328; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=329; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=330; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=331; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=332; { recoveryStack[3]=java.lang.Integer.valueOf(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])); }
                  recoveryAt=333; { recoveryStack[4]=1; }
                  recoveryAt=334; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=335; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=336; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=337; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=338; { recoveryStack[3]=0; }
                  recoveryAt=339; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=340; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=341; { recoveryStack[1]=2035327095308965891L; }
                  recoveryAt=342; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=343; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding70(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=344; { recoveryLocals[21]=recoveryStack[0];  }
                  recoveryAt=347; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=348; { recoveryStack[1]=recoveryLocals[21];  }
                  recoveryAt=349; { recoveryStack[2]=2031526962241051760L; }
                  recoveryAt=350; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=351; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding71(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=355; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=356; { recoveryStack[1]=1; }
                  recoveryAt=357; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]); }
                  recoveryAt=358; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=361; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=362; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=440; continue recoveryFlow;} recoveryPc=366; continue recoveryFlow; }
               }
               case 366 -> {
                  recoveryAt=366; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=368; { recoveryPc=377; continue recoveryFlow; }
               }
               case 371 -> {
                  recoveryAt=371; { recoveryStack[1]=2033731969778639449L; }
                  recoveryAt=372; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=373; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding72(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=374; { throw (Throwable)recoveryStack[0]; }
               }
               case 377 -> {
                  recoveryAt=377; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=378; { recoveryStack[2]=2; }
                  recoveryAt=379; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=380; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=381; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=383; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=384; { recoveryStack[4]=1; }
                  recoveryAt=385; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=386; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=387; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=388; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=389; { recoveryStack[2]=java.lang.Integer.valueOf(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])); }
                  recoveryAt=390; { recoveryStack[3]=0; }
                  recoveryAt=391; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=392; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=393; { recoveryStack[1]=2032848680752097321L; }
                  recoveryAt=394; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=395; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding73(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=396; { recoveryLocals[17]=recoveryStack[0];  }
                  recoveryAt=399; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=400; { recoveryStack[1]=recoveryLocals[15];  }
                  recoveryAt=401; { recoveryStack[2]=recoveryLocals[7];  }
                  recoveryAt=402; { recoveryStack[3]=3; }
                  recoveryAt=403; { recoveryStack[3]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]; }
                  recoveryAt=404; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=405; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=407; { recoveryStack[4]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=408; { recoveryStack[5]=2; }
                  recoveryAt=409; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=410; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=411; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=412; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=413; { recoveryStack[3]=java.lang.Integer.valueOf(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])); }
                  recoveryAt=414; { recoveryStack[4]=1; }
                  recoveryAt=415; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=416; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=417; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=418; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=419; { recoveryStack[3]=0; }
                  recoveryAt=420; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=421; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=422; { recoveryStack[1]=2035327095308965891L; }
                  recoveryAt=423; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=424; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding74(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=425; { recoveryLocals[18]=recoveryStack[0];  }
                  recoveryAt=428; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=429; { recoveryStack[1]=recoveryLocals[18];  }
                  recoveryAt=430; { recoveryStack[2]=2031526962241051760L; }
                  recoveryAt=431; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=432; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding75(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=436; { recoveryLocals[14]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[14])+(1); }
                  recoveryPc=440; continue recoveryFlow;
               }
               case 440 -> {
                  recoveryAt=440; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=441; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=172; continue recoveryFlow;} recoveryPc=445; continue recoveryFlow; }
               }
               case 445 -> {
                  recoveryAt=445; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=446; { recoveryStack[1]=0; }
                  recoveryAt=447; { recoveryStack[1]=new java.lang.Class[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])]; }
                  recoveryAt=448; { recoveryStack[2]=2033809686099533066L; }
                  recoveryAt=449; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=450; { recoveryStack[0]=dev.zprestige.prestige.api.reflect.ReflectionUtil.invokeBinding76(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=451; { recoveryStack[0]=((java.lang.Class[])recoveryStack[0]); }
                  recoveryAt=452; { return ((java.lang.Class[])recoveryStack[0]); }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=36 && recoveryAt<43 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=47; continue recoveryFlow;}
            if(recoveryAt>=41 && recoveryAt<56 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=58; continue recoveryFlow;}
            if(recoveryAt>=89 && recoveryAt<95 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=99; continue recoveryFlow;}
            if(recoveryAt>=106 && recoveryAt<111 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=115; continue recoveryFlow;}
            if(recoveryAt>=122 && recoveryAt<141 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=143; continue recoveryFlow;}
            if(recoveryAt>=193 && recoveryAt<208 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=212; continue recoveryFlow;}
            if(recoveryAt>=216 && recoveryAt<227 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=231; continue recoveryFlow;}
            if(recoveryAt>=246 && recoveryAt<257 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=261; continue recoveryFlow;}
            if(recoveryAt>=359 && recoveryAt<367 && recoveryFailure instanceof java.lang.ClassNotFoundException){recoveryStack[0]=recoveryFailure; recoveryPc=371; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   public static Class aReturningClass(Object[] var0) throws ClassNotFoundException {
      String var3 = (String)var0[0];
      long var1 = (Long)var0[2];
      var1 = 87250790638136L ^ var1;
      long var5 = var1 ^ 91998436238968L;
      long var7 = var1 ^ 2447692378557L;
      String var37 = var3;
      if (var37 == null) {
         short var56 = 22058;
         long var58 = 5107419128850110251L ^ var1;
         throw new IllegalArgumentException("Descriptor required");
      }

      while (true) {
         String var17 = var3;
         int var39 = var17.length();
         int var38 = var9;
         if (var38 >= var39) {
            break;
         }

         int var19 = var9;
         String var18 = var3;
         char var10000 = var18.charAt(var19);
         short var10001 = 15777;
         long var10002 = 8673213918713560862L ^ var1;
         byte var41 = 91;
         char var40 = var10000;
         if (var40 != var41) {
            break;
         }

         var10++;
         var9++;
      }

      int var23 = var9;
      String var22 = var3;
      char var11 = var22.charAt(var23);
      short var46 = 28865;
      long var52 = 375777174743937659L ^ var1;
      byte var43 = 76;
      char var42 = var11;
      if (var42 == var43) {
         var46 = 18068;
         var52 = 7587458668371985442L ^ var1;
         int var48 = 59;
         int var26 = var9;
         String var24 = var3;
         int var45 = var24.indexOf(59, var26);
         var48 = var9 + 1;
         int var29 = var45;
         int var28 = var48;
         String var27 = var3;
         String var13 = var27.substring(var28, var29);
         short var50 = 11926;
         var52 = 3038408184161217582L ^ var1;
         byte var51 = 47;
         short var55 = 32015;
         long var57 = 8566774728491302834L ^ var1;
         String var30 = var13;
         String var14 = var30.replace('/', '.');
         String var33 = var14;
         Class var15 = dev.prestige.recovery.RecoveryNames.forName(var33);
         Object[] var59 = new Object[]{null, null, var7};
         var59[1] = var10;
         var59[0] = var15;
         Object[] var34 = var59;
         return bReturningClass(var34);
      } else {
         Object[] var10003 = new Object[]{null, var5};
         var10003[0] = Integer.valueOf(var11);
         Object[] var35 = var10003;
         Class var12 = c(var35);
         Object[] var10004 = new Object[]{null, null, var7};
         var10004[1] = var10;
         var10004[0] = var12;
         Object[] var36 = var10004;
         return bReturningClass(var36);
      }
   }

   private static Class bReturningClass(Object[] var0) {
      Class var2 = (Class)var0[0];
      int var1 = (Integer)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 87250790638136L ^ var3;
      int var9 = var1;
      if (var9 == 0) {
         return var2;
      }

      Class var5 = var2;
      while (true) {
         int var11 = var1;
         int var10 = var6;
         if (var10 >= var11) {
            return var5;
         }

         Class var8 = var5;
         var5 = Array.newInstance(var8, 0).getClass();
         var6++;
      }
   }

   private static Class c(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 87250790638136L ^ var2;
      int var4 = var1;
      switch (var4) {
         case 66:
            return byte.class;
         case 67:
            return char.class;
         case 68:
            return double.class;
         case 69:
         case 71:
         case 72:
         case 75:
         case 76:
         case 77:
         case 78:
         case 79:
         case 80:
         case 81:
         case 82:
         case 84:
         case 85:
         case 87:
         case 88:
         case 89:
         default:
            short var10003 = 11249;
            long var10004 = 7503992364728970935L ^ var2;
            throw new IllegalArgumentException("Unknown primitive descriptor: " + var1);
         case 70:
            return float.class;
         case 73:
            return int.class;
         case 74:
            return long.class;
         case 83:
            return short.class;
         case 86:
            return void.class;
         case 90:
            return boolean.class;
      }
   }

   static {

      {

      aReturningVoid();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(24771246418645L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[15];
      String var26 = "²1\u0005\u0012V0\u009cßãGo¥Êíqðv$À\u00120Ù\u001euøÅ\u001dyÖPW\u0088fÕÆÅ\u0012¾(ê4\u009cçºc¤?\u001b\u0093\u0002_½\u007f\u0006«\u0019 Ñ8c*\u001f&\u008aH\u0010ßµ·§W\u0094u¤¤³\n\nAQEP\u0006o$úñ-¿8·\u0007Ú»ps\u00027\u0092y\rTuÂ¥\u009d\u0017q\u0083O\u0099y#\u0011\u009b\u0012½bc§\u0098kþÉ3Û\u0099Z\u009eÜ\u008f¡8ø·¸6\u0019\\K\u0004\u0096ðÌýo\u0018óÉ\u0083S\u0014äpéó¢\u001d°³v\u00970öÀÂJ}¥@8 M\"(\u009c2¿×F½ÝTµ\u0001\u0094Z±Oô\u0083Ë\u0015;J\n\u0010\u00800Û\u000bÌª\u001b(4\u0002M29Zc\u0098]\u0081°:áÆÈ$9\"ÅÃ\u0087\u009fj~tÉ P§¾>Z\u001aþÒ&Ý}Û\u0001\u0018X\u009dw½7É\u009fß\u0013Ëno\u0086\u0013!\u0012\u0095~n\u008e®\u0016\u009fö01\u0018äaÎ\r«Á\fËñA$Õ\u0014/,¬cµº#Ô{±]ã´W«£\u0013J\u0014\u0082ü®£·\u0086 \rr®d×¡@8YG\u008a&få9.\t\u000e \u0089ú¨0ò\u001e\u0086G H\u009dòð\"¿F\u0018Â\u0094ò%£á?2Ùÿ×\u0088G«sò±\u0002\u00822_YTýNz^ó8¯F\\ôð]\b¿\u00029ñi$Ëù A·,\u001bÝY-*\u0093¸|\u0087\u009d:ºÇ6Q\u0099ìpsä7+ñ\u0004\u0002ÜX5\u0090R\u001b-¡ê\u0016\u001eW(r1H{qÔ3¯\u008aÂkçÎ\u0007x*\u0000>\u0016\u00138;±ñ\u0004Î²©)¹åÌ\\Eé©ÌYb\u0005\u0010\u0006J\u0012ûY\u0018'leü~ÑÊ\u001d\u009eq\u00101ü\u0088°g\\àoä\u0097&6\u0016â¹\u0086";
      int var28 = "²1\u0005\u0012V0\u009cßãGo¥Êíqðv$À\u00120Ù\u001euøÅ\u001dyÖPW\u0088fÕÆÅ\u0012¾(ê4\u009cçºc¤?\u001b\u0093\u0002_½\u007f\u0006«\u0019 Ñ8c*\u001f&\u008aH\u0010ßµ·§W\u0094u¤¤³\n\nAQEP\u0006o$úñ-¿8·\u0007Ú»ps\u00027\u0092y\rTuÂ¥\u009d\u0017q\u0083O\u0099y#\u0011\u009b\u0012½bc§\u0098kþÉ3Û\u0099Z\u009eÜ\u008f¡8ø·¸6\u0019\\K\u0004\u0096ðÌýo\u0018óÉ\u0083S\u0014äpéó¢\u001d°³v\u00970öÀÂJ}¥@8 M\"(\u009c2¿×F½ÝTµ\u0001\u0094Z±Oô\u0083Ë\u0015;J\n\u0010\u00800Û\u000bÌª\u001b(4\u0002M29Zc\u0098]\u0081°:áÆÈ$9\"ÅÃ\u0087\u009fj~tÉ P§¾>Z\u001aþÒ&Ý}Û\u0001\u0018X\u009dw½7É\u009fß\u0013Ëno\u0086\u0013!\u0012\u0095~n\u008e®\u0016\u009fö01\u0018äaÎ\r«Á\fËñA$Õ\u0014/,¬cµº#Ô{±]ã´W«£\u0013J\u0014\u0082ü®£·\u0086 \rr®d×¡@8YG\u008a&få9.\t\u000e \u0089ú¨0ò\u001e\u0086G H\u009dòð\"¿F\u0018Â\u0094ò%£á?2Ùÿ×\u0088G«sò±\u0002\u00822_YTýNz^ó8¯F\\ôð]\b¿\u00029ñi$Ëù A·,\u001bÝY-*\u0093¸|\u0087\u009d:ºÇ6Q\u0099ìpsä7+ñ\u0004\u0002ÜX5\u0090R\u001b-¡ê\u0016\u001eW(r1H{qÔ3¯\u008aÂkçÎ\u0007x*\u0000>\u0016\u00138;±ñ\u0004Î²©)¹åÌ\\Eé©ÌYb\u0005\u0010\u0006J\u0012ûY\u0018'leü~ÑÊ\u001d\u009eq\u00101ü\u0088°g\\àoä\u0097&6\u0016â¹\u0086"
         .length();
      char var25 = '8';
      int var46 = -1;

      label83:
      while (true) {
         String var47 = var26.substring(++var46, var46 + var25);
         int var10001 = -1;

         while (true) {
            byte[] var30 = var22.doFinal(var47.getBytes("ISO-8859-1"));
            String var61 = a(var30).intern();
            switch (var10001) {
               case 0:
                  var29[var27++] = var61;
                  if ((var46 += var25) >= var28) {
                     k = var29;
                     l = new String[15];
                     s = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(24771246418645L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[15];
                     String var15 = "¢@Nn\u0005ýj,«<E#£y;\u0097\u0089K+éC\u008a]\u009e² ¹¡\f[ Â|yE\u0091\u009b1|q\u000f¡zËÎ\u0010\u0097\u0094#Wf¥«Ý:\"\u0083ú5û\u0092\u0083\u00137ê\u0017J\u0005ô\u000e\u0011¢°mþó\u0015\u0016\u008a\u0094I¦O ÿ#I\u0000\u0018 ©^DØS r=\u0003.Ù`\u0005V";
                     int var16 = "¢@Nn\u0005ýj,«<E#£y;\u0097\u0089K+éC\u008a]\u009e² ¹¡\f[ Â|yE\u0091\u009b1|q\u000f¡zËÎ\u0010\u0097\u0094#Wf¥«Ý:\"\u0083ú5û\u0092\u0083\u00137ê\u0017J\u0005ô\u000e\u0011¢°mþó\u0015\u0016\u008a\u0094I¦O ÿ#I\u0000\u0018 ©^DØS r=\u0003.Ù`\u0005V"
                        .length();
                     label65:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var50 = var17;
                        var10001 = var14++;
                        long var65 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var65;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var73 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var69) {
                              case 0:
                                 var50[var10001] = var73;
                                 if (var13 >= var16) {
                                    q = var17;
                                    r = new Integer[15];
                                    y = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(24771246418645L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[3];
                                    String var4 = "\u00010=\\\u0016zü3\u007fä[îp$¯Oh\"H}\u0081{ì\u009b";
                                    int var5 = "\u00010=\\\u0016zü3\u007fä[îp$¯Oh\"H}\u0081{ì\u009b".length();
                                    do {
                                       int var58 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var58, var2).getBytes("ISO-8859-1");
                                       var58 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var73 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       // var6[var58] = var73;
                                    } while (var2 < var5);

                                    w = var6;
                                    x = new Long[3];
                                    b = new ConcurrentHashMap();
                                    c = new ConcurrentHashMap();
                                    Unsafe var33 = null;

                                    try {
                                       String var36 = "theUnsafe";
                                       Class<Unsafe> var35 = Unsafe.class;
                                       Field var34 = var35.getDeclaredField(var36);
                                       Field var37 = var34;
                                       var37.setAccessible(true);
                                       Object var40 = null;
                                       Field var39 = var34;
                                       var33 = (Unsafe)var39.get(var40);
                                    } catch (Throwable var43) {
                                       PrintStream var42 = System.err;
                                       var43.printStackTrace(var42);
                                    }

                                    a = var33;
                                    break;
                                 }
                                 break;
                              default:
                                 var50[var10001] = var73;
                                 if (var13 < var16) {
                                    continue label65;
                                 }

                                 var15 = "Ej\u0099Ez\u009c¨¨9cY.\u0093\u0088sì";
                                 var16 = "Ej\u0099Ez\u009c¨¨9cY.\u0093\u0088sì".length();
                                 var13 = 0;
                           }

                           int var57 = var13;
                           var13 += 8;
                           var18 = var15.substring(var57, var13).getBytes("ISO-8859-1");
                           var50 = var17;
                           var10001 = var14++;
                           var65 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var69 = 0;
                        }
                     }
                  }

                  var25 = var26.charAt(var46);
                  break;
               default:
                  var29[var27++] = var61;
                  if ((var46 += var25) < var28) {
                     var25 = var26.charAt(var46);
                     continue label83;
                  }

                  var26 = "\u001cÀ\u008bå\u008fÌÑ,Â\u0013¥g½w\u0099ÁC@X9KÀþdÖü\u000bO\u0080ÐuÂ>þÖF\u001fK\u001a*(\u008eHvA\u0094ß\u0004°Uü8Ï6£\u009dÂ²ù\u008c§\f\u0096\u00016aXò6Á@Dªpççñ\u009c¸*\u0010";
                  var28 = "\u001cÀ\u008bå\u008fÌÑ,Â\u0013¥g½w\u0099ÁC@X9KÀþdÖü\u000bO\u0080ÐuÂ>þÖF\u001fK\u001a*(\u008eHvA\u0094ß\u0004°Uü8Ï6£\u009dÂ²ù\u008c§\f\u0096\u00016aXò6Á@Dªpççñ\u009c¸*\u0010"
                     .length();
                  var25 = '(';
                  var46 = -1;
            }

            var47 = var26.substring(++var46, var46 + var25);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16140;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])m.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               m.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cQ", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cQ_C0143",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15541;
      if (r[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = q[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])s.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cQ", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         r[var3] = var15;
      }

      return r[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cQ_C0143",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long e(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19578;
      if (x[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = w[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])y.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cQ", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         x[var3] = var15;
      }

      return x[var3];
   }

   private static long e(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = e(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite e(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cQ_C0143",
                        "e",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = A[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = z[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 32;
            yield var15;
         }
         case 1 -> {
            byte var16 = 33;
            yield var16;
         }
         case 2 -> {
            byte var17 = 37;
            yield var17;
         }
         case 3 -> {
            byte var18 = 58;
            yield var18;
         }
         case 4 -> {
            byte var19 = 54;
            yield var19;
         }
         case 5 -> {
            byte var20 = 63;
            yield var20;
         }
         case 6 -> {
            byte var21 = 31;
            yield var21;
         }
         case 7 -> {
            byte var22 = 51;
            yield var22;
         }
         case 8 -> {
            byte var23 = 57;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 11;
            yield var25;
         }
         case 11 -> {
            byte var26 = 42;
            yield var26;
         }
         case 12 -> {
            byte var27 = 7;
            yield var27;
         }
         case 13 -> {
            byte var28 = 13;
            yield var28;
         }
         case 14 -> {
            byte var29 = 27;
            yield var29;
         }
         case 15 -> {
            byte var30 = 50;
            yield var30;
         }
         case 16 -> {
            byte var31 = 22;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 35;
            yield var33;
         }
         case 19 -> {
            byte var34 = 18;
            yield var34;
         }
         case 20 -> {
            byte var35 = 26;
            yield var35;
         }
         case 21 -> {
            byte var36 = 10;
            yield var36;
         }
         case 22 -> {
            byte var37 = 44;
            yield var37;
         }
         case 23 -> {
            byte var38 = 55;
            yield var38;
         }
         case 24 -> {
            byte var39 = 47;
            yield var39;
         }
         case 25 -> {
            byte var40 = 40;
            yield var40;
         }
         case 26 -> {
            byte var41 = 20;
            yield var41;
         }
         case 27 -> {
            byte var42 = 49;
            yield var42;
         }
         case 28 -> {
            byte var43 = 5;
            yield var43;
         }
         case 29 -> {
            byte var44 = 41;
            yield var44;
         }
         case 30 -> {
            byte var45 = 9;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 28;
            yield var48;
         }
         case 34 -> {
            byte var49 = 16;
            yield var49;
         }
         case 35 -> {
            byte var50 = 46;
            yield var50;
         }
         case 36 -> {
            byte var51 = 43;
            yield var51;
         }
         case 37 -> {
            byte var52 = 15;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 25;
            yield var54;
         }
         case 40 -> {
            byte var55 = 39;
            yield var55;
         }
         case 41 -> {
            byte var56 = 24;
            yield var56;
         }
         case 42 -> {
            byte var57 = 61;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 2;
            yield var59;
         }
         case 45 -> {
            byte var60 = 1;
            yield var60;
         }
         case 46 -> {
            byte var61 = 56;
            yield var61;
         }
         case 47 -> {
            byte var62 = 21;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 29;
            yield var64;
         }
         case 50 -> {
            byte var65 = 45;
            yield var65;
         }
         case 51 -> {
            byte var66 = 8;
            yield var66;
         }
         case 52 -> {
            byte var67 = 19;
            yield var67;
         }
         case 53 -> {
            byte var68 = 60;
            yield var68;
         }
         case 54 -> {
            byte var69 = 17;
            yield var69;
         }
         case 55 -> {
            byte var70 = 36;
            yield var70;
         }
         case 56 -> {
            byte var71 = 53;
            yield var71;
         }
         case 57 -> {
            byte var72 = 0;
            yield var72;
         }
         case 58 -> {
            byte var73 = 38;
            yield var73;
         }
         case 59 -> {
            byte var74 = 6;
            yield var74;
         }
         case 60 -> {
            byte var75 = 3;
            yield var75;
         }
         case 61 -> {
            byte var76 = 52;
            yield var76;
         }
         case 62 -> {
            byte var77 = 14;
            yield var77;
         }
         default -> 4;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            A[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      z[0] = "LR\u0001\u0017T%G]\u0010X9%G@\u0004";
      z[1] = "Zjk\u0015].QezZ0.Qxn8\u001c#Tno";
      z[2] = "#IY\u0019V45I\\CE#\"\u0002_EI73EHR\u0002'\u0016";
      z[3] = "T\u000f~]\u0016|!/uR\u00073@!~Y\u0003i4";
      z[4] = "3\n/b\u001dt%\n*8\u000ec2A)>\u0002w#\u0006>)Ig\u0001";
      z[5] = "\u001a2F\u001e>oo\u0012M\u0011/ \u000e\u001cF\u001a+zz";
      z[6] = "\"wF\u000e\u0002PWWM\u0001\u0013\u001f:WM\u001c\u0007\n";
      z[7] = "f^t@\u001c$mQe\u000fa<~VlF";
      z[8] = char.class;
      A[8] = "java/lang/Character";
      z[9] = "\u001a#yR\u001f[o\u0003r]\u000e\u0014\u000e\ryV\nNz";
      z[10] = int.class;
      A[10] = "java/lang/Integer";
      z[11] = "If\u001e\"PW_f\u001bxC@H-\u0018~OTYj\u000fi\u0004Fh";
      z[12] = boolean.class;
      A[12] = "java/lang/Boolean";
      z[13] = "#:fM%/=2|\u0002G3:/";
      z[14] = "\u0003\r=]}t\b\u0002,\u0012\u001cz\u0003\t(H";
      z[15] = "\u0002p9t\u0012\u0004wP2{\u0003K\u0016^9p\u0007\u0011b";
      z[16] = "@\u0010\bA\u007f K\u001f\u0019\u000e\u0005$X\u001e\tA3 O";
      z[17] = "JF)\fd$?f\"\u0003uk^h)\bq1*";
      z[18] = "\n\u0018>\u0004z\u007f\u007f85\u000bk0\u001e6>\u0000ojj";
      z[19] = "5\u000e\u0004z\u0000\u0000@.\u000fu\u0011O! \u0004~\u0015\u0015U";
      z[20] = "('\u001agx,#(\u000b($%$*\te\"n\u0003%\u000fc%3+$\u0000c\u0019\"(#\u000fr";
      z[21] = "7\u000e\u000b\u0013k\u001b7\u0018Khh\u0001%\u001d\u0000";
      z[22] = "ZSr\u0002;;Q\\cMg2V^a\u0000ayv[a\u000fq";
      z[23] = long.class;
      A[23] = "java/lang/Long";
      z[24] = "C/6\b~jH 'G9h_!+\f~KL:(\u00064NH $\u00055u";
      z[25] = ";\u001e\u001anW\u00030\u0011\u000b!\u0010\u0001'\u0010\u0007jW\"4\u000b\u0004`\u001d'0\u0011\bc\u001c\u001cu3\u0003`\u0012\u001a!";
      z[26] = "{N)O\u0014rpA8\u0000H{wC:MN0\\@;G\\wt]";
      z[27] = "\u000e1$\u000f\u001d+{\u0011/\u0000\fd\u001a\u001f$\u000b\b>n";
      z[28] = void.class;
      A[28] = "java/lang/Void";
      z[29] = "S3}Je\u001aM;g\u0005\u0006\u000eI";
      z[30] = "\u0000|gHmP\u000bsv\u0007*R\u001crzLmj\u000boYH-X\u0006x";
      z[31] = "\u001f\u0010)`\u001bN\u0014\u001f8/fV\u0007\u00181fwW\u001c\u001d;dG";
      z[32] = "Q=\u0000^;\\Z2\u0011\u0011gU]0\u0013\\a\u001ev9\u0002WzT";
      z[33] = "\u0000\r\u001a(cBu-\u0011'r\r\u0018-\u0011:f\u0018";
      z[34] = "xe&q~/\rE-~o`QL*|m-W\u0007\u0001u|&LMw";
      z[35] = "DF0\t2[OI!FuYXH-\r2zKS.\u0007x\u007fOI\"\u0004y";
      z[36] = "\u0017rs+\u0017nbRx$\u0006!\u0003\\s/\u0002{w";
      z[37] = "/@f\u0012} Z`m\u001dlo7`m\u0000xz";
      z[38] = "]\"=n\f\u0002C*'!c\u0005E\"2|";
      z[39] = "Z9=\u0014\u0015N/\u00196\u001b\u0004\u0001N\u0017=\u0010\u0000[:";
      z[40] = "K]NKYR@R_\u0004\u0005[GP]I\u0003\u0010`NJK\u000e";
      z[41] = "=\")VqK6-8\u0019\u001cO61>T+B%";
      z[42] = "~)JZRxu&[\u0015/|{:H";
      z[43] = "\u0018QY\u0018s\u0014\u0013^HW\u001b\u0014\u001dQ[";
      z[44] = "\u0010Dw~!R\u001bKf1MQ\u0015Id~a";
      z[45] = "\u001bf\f*g?\u0010i\u001de\u000b*\u0005b";
      z[46] = "/f\u0014\u001bJ+$i\u0005T2(,c";
      z[47] = "\u0013!hR>\t\u0018.y\u001d\\\n\u0017'";
      z[48] = "\u0006.\u000e+j\r\r!\u001fd\r\u000f\u0018*\u001f/6";
      z[49] = ">R4*\u000br5]%eaq!Q..";
      z[50] = "<D\u0019\f\u0018ZId\u0012\u0003\t\u0015(j\u0019\b\rO\\";
      z[51] = "\u001fT$\u0004\f'\u001a\u001b\u0002\u0017K \u0001f&\u0017G/\u0018";
      z[52] = "\u0012\u0002y+o'\u0019\rhd\u00122\u000b\u0017j'";
      z[53] = "!\u0011\u001fW\"\fe\u0013\u0014\u001fPY\u0018\u000f\u000bS-\be\u0014\u0013\u0014n0uD\u001eO(Vt\u0006@EP";
      z[54] = "J\u001e\u001aArOKX[\u001e\fH\u0011KG\fKGw\u0018J\u001a2\u0010GK\u0010\u001cr)HGLB5\u0019\u001b\u001dJ\u0002\f";
      z[55] = "\t7\u0012\nL^Y-]E2D\u000e6\u0000\u001eNm\u00059\t\u0019uM\n/\u0000\t2M\u001a*T\tTE\u0014$\u0017u]J\u00010\u001dO\rO^,m";
      z[56] = "=!/dq\f96(\u001d'\u001f$\u000f+t3\t\u001c#&q%\bX}\u007ft1\b86)%.r";
      z[57] = "\u0016\n{Mm\u001b\u0016B=\u000e\\\u001c\u001e\u0014a\r$x\u0019\u0016f\f\"\u0003\u001c\u00103\u0001\\";
      z[58] = "\u0002vn<\u00131\u0006aiEK4.hu$E)\u000eyj(d5\u0000v\u000e O/\u001e*p$X(g#o;\u00127\u0015}~:\u0015O";
      z[59] = "GzK\u0007\u0002t\u000b>DMdXjYtu\u0001a[x\u0000\u000b\u0005v\\";
      z[60] = "an\u000f\u007fk\u0013c:Ov\u000b\tw.2wp\u0013s7\u0018|\u000b\n\u007f1\n(u\u000eh6s.k\t$hC}1\u000fdQBc2\f`3\u000eup\n\u001a";
      z[61] = "\u000bM\u00142~<\n\u000bUm\u0000>[\u0012Ks`Z\t\u0014B19jZNDq\u0000";
      z[62] = "\u0004@\u000fK\rR@YD[5o*c9;PV\u001bBMETA\u001c";
      z[63] = "]%G:\u007f]\u00113\u0005<\u0005R\u0015*\u0017=~?]%G:\u007f]\u00113\u0005<\u0005\u000f\r)F!wQ\u001c(AY";
      z[64] = "G\u001a%\n\b{GRcI9`R\u0002\"^Eul\u0004;TD`i\u0005\\R\\xQZ\"VK\u007f(\u00039SEfS\u0006?\u0006H\u0018H\u00068KGcM\u0000mF9";
      z[65] = "\u000eZ\u001f/\u00019\u000f\u0018A%y$\u000e\u001c1$\u00122\u0018\u001b\u0019%\u001d2cP\u00191A'\u0011\u000e\b0F_\u0001\r\u0016(\u0001`\u000eZ\u0019?y";
      z[66] = "9^\u0004\u001cR48\u0018EC,3b\u000bYQk<\u0004XTG\u0012k4\u000b\u000eARR;\u0007R\u001f\u0015bh]T_,md\u0001\n\u0018\u001c>>\u0007J!";
      z[67] = "scV%\u0012br%\u0017zli7'\u000f|\u0017\u0004\u007f(_{\u0016f3>\u001d}l4/$^`\u001ej>%Y\u0018";
      z[68] = ",\u001b\rsS)u\u0018\\$+86 J#W8&{\t*MgtKZpK'MKW4\u0013!?\u0015F5\u0014Y";
      z[69] = "0R(#V\u007ftP#k$*\tL<'Y{tW$`\u001aCqO24@&1\u00063k$";
      z[70] = ",t<l\u0005_z-es\u0006;x6/\u0014\u001dZ\u007f32h\u0005\u0004,v";
      z[71] = "T@\u001b\u00025wPW\u001c{bnKc\u0012\u001ea\t\f\u001cKFro\rZ\n\u0019\flTE\u0002BrhCB{";
      z[72] = "R^\f[\u0000iVI\u000b\"WpM}\u0005GT\u0017\n\u0002\\\u001fGq\u000bD\u001d@9'VETZKyGDS\"\u0000'^B\u0016BKq\u000f]lG\\wN\u0002\u0012CKp7";
      z[73] = "=q\u0011l8.mk^#F+-n$t!7={\b\u0013w!iq\u0014q;7+wn|/64bT,*i(\u0012^r8k(`\u0000c9lPp\u0003}!+o\u007fTr6S";
      z[74] = "0?\u007fSx lztMI1,>uU%Xi\u007f(\u000e7>h9iQI<-!x\u00021`h*f3";
      z[75] = "#5\tKpy'\"\u000e2&j:\u001c\u0004Y-n<=\u0005w${&7\u0005IIa6?\u0011@#7->\u00112";
      z[76] = "nMg]0u*Ol\u0015B WHn^x.o@jL>I=Mz\u001f%q5IhYB";
      z[77] = "\u0010n9roWTl2:\u001d\u0002)p-v`STk51#k\u00148o7c\r\u0015~.h\u001d";
      z[78] = "|[\u00124u\\xL\u0015M#Oer\u001f&(KcS\u001e\b!^yY\u001eMq\u001b)\u0003\f+p]h\\r5>^vZ\u0017uw_)>\u001754^g@\u000b35\\\u0019";
      z[79] = "ATT`\u0018r\u0001G\u0011cwi\u0017|Q{\u001edpDY}\n-\r_A:I\u0015\u0001GW|Oh\u001a_\u0010?w";
      z[80] = "\u001dMA?`l\u0015CO|\u001ce\u001eOzapk\u001dRR|g\nLSY8%:\u001f\t_x\u001c";
      z[81] = ":A|\u0019<x;\u0007=FBdj\u0000(M)s\u0007FuJ}{c\u0017<E.\u001e9A\"\u001b'zh\b-HB#>HqZ$\"x\t.$";
      z[82] = "[H.n\u0003.\u001fJ%&qxbV:j\f*\u001fM\"-O\u0012\u0007B(oHl\u0003U/\u0016";
      z[83] = "vZ?VR\u007f&@p\u0019,ygP<HGLzT$EkluB-U,leGyUJdkI:)Ck~]0\u0013\u0013n!A@";
      z[84] = "qGJ2BImAK0<XyCt'YZ\u0014\u0002\u000b~\u0001Ir\u0003M?^7";
      z[85] = "\u000b\n19S#\u0017\f0;-2\u0003\u000e\f\"A<\u0000\u0013$?V]Q\u0012/{\u0014m\u0002H);-";
      z[86] = "6=OkD;>9]-#{&3R-x\u007f59W\rYj7?4#Bi#5H;\u001c:fRV<Md$mYkBs\\";
      z[87] = "\u0019\u001d!Wv9\tF,PJ\u001a3 \u0006i/#\u0002\u0001r\u0017+4\u0005";
      z[88] = "^\u007f\u000e)\u001bpX~E/~\u0012s\u001a8@\u001b+B;L>\u001f<E";
      z[89] = "DB\u0001R\u0003\u0000\u0000@\n\u001aqU}\\\u0015V\f\u0004\u0000G\r\u0011O<FG\u0002X\u001fD\u0001CY\u0011q";
      z[90] = "\f\r}d(|\u0010\u000b|fVm\u0004\t]q,k\f\u0018yu,^\u0018\rhcVz\u001b\tj|3:R\b5\u0018";
      z[91] = "]\r\u000e?N\u0012\\[V.4~re|^QGCD\b UPD";
      z[92] = ")i =7>wvs&^:\u0016*-1`h&yw7 Q";
      z[93] = "g-&D~So#(\u0007\u0002Zd/\u0004\fzX\t6=\u001d{\fw2*\u001a\u0002";
      z[94] = "\u0004'UVYiT=\u001a\u0019'o\u0015-VHLZ\b)NEm}\u0012)*GYjP8LOWd\u0013D\u001b[\u001ew\u0013&WM\\qi";
      z[95] = "#7l!\u0010Y+3glr\t-w\u0007-\u0000_#qea\u0016\u001d%\u000b6nK\u0005:izx\t\u0003@";
      z[96] = "\u001fe^Z+P\u001brY#}C\u0006[C[\u007fT\u0011dWXi.\u001fe^Z+P\u001brY#";
      z[97] = "jM33c\u0003oKf>\u001d\u0016kN;\u0011t\u0002JA1#y\u0015\nM2/dAtI%(\u001dE3\u0018j1{DuY5Ox\u001djQn1|\nm(3~y\tlRm+o\t\n";
      z[98] = "FB)UB\u0006\u0002@\"\u001d0S\u007f\\=QM\u0002\u0002G%\u0016\u000e:\u001aH/T\tD\u001e_(-";
      z[99] = "P!\u0015\u00111j\fd\u001e\u000f\u0000{L \u001f\u0017l\u0012\na\u001cNev[(\u0013\u001d\u0000vM?\u0012@x*\b4\fq";
      z[100] = "nIs\u000b->rOr\tS/fMS\u001e))n\\w\u001a)\u000blLm\u000bS\u007fkW5Nc,1Quw";
      z[101] = "nOK%vM2\n@;GImmP?&Se6\u0011|w\btP\u0010:6W\n";
      z[102] = "yO\\g,gqAR$PzzMc8,\u0001&C\u001b=*cjUY;P>wW\u001cg`m-Q\\^2lyVZa=;vA\"";
      z[103] = "_-\u0015\u000eImW#\u001bM5p\\/\"\\^fJ(\n]Qf1c\nI\rsC=\u001bH\n\u000bS>\u0005PM4\\i\nG5";
      z[104] = "lF\u0019^~{(D\u0012\u0016\f.UX\rZq\u007f(C\u0015\u001d2G7D\u0011Atx8\u0013\u001eV\f";
      z[105] = "8x\u0019x  xeS&I\f\u0014Yl\u001f,5%x\u0018a(\"\"";
      z[106] = "AUjM|tEBm4*gXvcQ(\n\u0019\t:\t;l\u0018O{VE";
      z[107] = "\fk;aQx\r-z>/uQ;q\u0015S\u001e\u000e2mb\u0016.]hk\"/ \b<49KqA3g\\";
      z[108] = "ya\u0013z&t9rVyIz$ll*;*+z\u000ef-h-\u0000\\z7+0r\u0002k6,H";
      z[109] = "r[ ;+os\u001dadUw&\u0006mk\u0012gOSb?6s-\u001ft}0\tr[ ;+os\u001dadU";
      z[110] = "1\u0018j=^W5\u000fmD\bD(1g/\u0003@.\u0010f\n\u0006D0\u0011\ny^\u0019i\u0003lx\u0018X6}d:\u0019\u0010(\u001bl4\u0017ST";
      z[111] = "{\u001f\n\u0010M ~\u0019_\u001d3&}\u0000\u0003\u0002W6p\u0006n\tK#g\u0004\u0010\u0015M\"ez\t\u0006Rk%\u0018\u0010\u0014Z \u001b";
      z[112] = "M\u0019-{e3@Xuh\u001d\u0012czX\u0015x+R[,k|<U";
      z[113] = "!{kvFcey`>44\u0018e\u007frIge~g5\n_}qmw\r!yfj\u000e";
      z[114] = "A>\u001f\u0000\\\u0010D8J\r\"\u0005@=\u0017'^\u0002]:\u0010\"K\u0011a2\u001d\u0010F\u0006!>\u001e\u001c[R_:\t\u001b\"V\u0018kF\u0002DW^*\u0019|G\u000eA\"B\u0002C\u0019F[\u001fMF\u001aG!A\u0018P\u001a!";
      z[115] = "\u000bHB\brT\n\u000e\u0003W\fIK\u001b\tIvSP\u001er\nlT\bHBY6RHqMUj\f\u000fA\u001e\u000flL6LK\u00051LPM\rDn2";
      z[116] = "?\u0014\u0011%:\u00012G\u0014tZ=\u001e/8\u001f?\u0004/\u000eLa;\u0013(";
      z[117] = "\u00012TD6\"D*OXH/\u001f\tRN)5\u0017R_F4.@/D^smxo\u0017\u0004u-\u001enQE*S";
      z[118] = "u@\u0014F\u0012\u0017}D\u001f\u000bpPk\u0000\u007fJ\u0002\u0011u\u0006\u001d\u0006\u0014Ss|N\tIKl\u001e\u0002\u001f\u000bM\u0016M\rB\u0013Rt\u0001\u001b\u0000\u0015(";
      z[119] = "~[rZ,|}VwPP\u001c^b\u0006k5%oCr\u001512h";
      z[120] = "\u001bdCT$\u0003\u0013jM\u0017X\n\u0018f=\\*\\\u0016`_\u0010<\u001e\u0010\u001a\f\u001fa\u0006\u000fx@\t#\u0000u";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = z[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(A[var4]);
            z[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = z[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = A[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            z[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  z[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1012902022514902L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = z[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = A[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  z[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1012902022514902L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        z[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1012902022514902L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 99;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 195;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 219;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 234;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 105;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 111;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 99;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 195;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 219;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite f(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cQ_C0143",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Object[] b() {
      return new Object[0];
   }

   private static Object[] a(Object var0, Object var1, Object var2) {
      return new Object[]{var0, var1, var2};
   }

   private static Object[] a(Object var0, Object var1) {
      return new Object[]{var0, var1};
   }

   private static Object[] a(Object var0) {
      return new Object[]{var0};
   }

   private static String invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Method invokeBinding5(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache5;
         MethodHandle var10 = bindingCache5;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache5 = f(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/reflect/Method;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Method)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static AccessibleObject invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/reflect/AccessibleObject;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AccessibleObject)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding8(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(IJJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding9(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache9;
         MethodHandle var10 = bindingCache9;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache9 = f(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Method[] invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)[Ljava/lang/reflect/Method;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Method[])var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Class[] invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)[Ljava/lang/Class;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Class[])var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding17(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache17;
         MethodHandle var9 = bindingCache17;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache17 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static AccessibleObject invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/reflect/AccessibleObject;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (AccessibleObject)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding22(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(IJJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding23(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache23;
         MethodHandle var10 = bindingCache23;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache23 = f(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Class invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Class;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Class)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding27(int var0, long var1) {
         MethodHandle var7 = bindingCache27;
         MethodHandle var6 = bindingCache27;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache27 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static ClassLoader invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/ClassLoader;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClassLoader)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Class[] invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)[Ljava/lang/Class;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Class[])var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MethodAccessMetadata invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cV_C0153;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MethodAccessMetadata)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding31(int var0, long var1) {
         MethodHandle var7 = bindingCache31;
         MethodHandle var6 = bindingCache31;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache31 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding33(int var0, long var1) {
         MethodHandle var7 = bindingCache33;
         MethodHandle var6 = bindingCache33;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache33 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding35(int var0, long var1) {
         MethodHandle var7 = bindingCache35;
         MethodHandle var6 = bindingCache35;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache35 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static StringBuilder invokeBinding38(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache38;
         MethodHandle var9 = bindingCache38;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache38 = f(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/StringBuilder;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (StringBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding39(int var0, long var1) {
         MethodHandle var7 = bindingCache39;
         MethodHandle var6 = bindingCache39;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache39 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static StringBuilder invokeBinding40(Object var0, char var1, long var2, long var4) {
         MethodHandle var10 = bindingCache40;
         MethodHandle var9 = bindingCache40;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache40 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;CJJ)Ljava/lang/StringBuilder;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (StringBuilder)var7.invokeExact((Object)var0, (char)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding42(long var0, long var2) {
         MethodHandle var8 = bindingCache42;
         MethodHandle var7 = bindingCache42;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache42 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Throwable invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding45(int var0, long var1) {
         MethodHandle var7 = bindingCache45;
         MethodHandle var6 = bindingCache45;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache45 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding46(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IJJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding47(int var0, long var1) {
         MethodHandle var7 = bindingCache47;
         MethodHandle var6 = bindingCache47;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache47 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding48(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache48;
         MethodHandle var9 = bindingCache48;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache48 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IJJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding50(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache50;
         MethodHandle var8 = bindingCache50;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache50 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding51(int var0, long var1) {
         MethodHandle var7 = bindingCache51;
         MethodHandle var6 = bindingCache51;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache51 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding52(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache52;
         MethodHandle var8 = bindingCache52;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache52 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding53(Object var0, int var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache53;
         MethodHandle var10 = bindingCache53;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache53 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IIJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (int)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static int invokeBinding54(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache54;
         MethodHandle var8 = bindingCache54;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache54 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding55(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache55;
         MethodHandle var8 = bindingCache55;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache55 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static char invokeBinding56(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache56;
         MethodHandle var9 = bindingCache56;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache56 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IJJ)C", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (char)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding57(int var0, long var1) {
         MethodHandle var7 = bindingCache57;
         MethodHandle var6 = bindingCache57;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache57 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding58(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache58;
         MethodHandle var8 = bindingCache58;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache58 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Throwable invokeBinding59(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache59;
         MethodHandle var8 = bindingCache59;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache59 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static char invokeBinding60(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache60;
         MethodHandle var9 = bindingCache60;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache60 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IJJ)C", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (char)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding61(int var0, long var1) {
         MethodHandle var7 = bindingCache61;
         MethodHandle var6 = bindingCache61;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache61 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Throwable invokeBinding62(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache62;
         MethodHandle var8 = bindingCache62;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache62 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding63(int var0, long var1) {
         MethodHandle var7 = bindingCache63;
         MethodHandle var6 = bindingCache63;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache63 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding64(Object var0, int var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache64;
         MethodHandle var10 = bindingCache64;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache64 = f(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IIJJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var8.invokeExact((Object)var0, (int)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding65(Object var0, int var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache65;
         MethodHandle var10 = bindingCache65;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache65 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;IIJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (int)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static int invokeBinding66(int var0, long var1) {
         MethodHandle var7 = bindingCache66;
         MethodHandle var6 = bindingCache66;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache66 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding67(int var0, long var1) {
         MethodHandle var7 = bindingCache67;
         MethodHandle var6 = bindingCache67;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache67 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding68(Object var0, char var1, char var2, long var3, long var5) {
         MethodHandle var11 = bindingCache68;
         MethodHandle var10 = bindingCache68;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache68 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;CCJJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var8.invokeExact((Object)var0, (char)var1, (char)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Class invokeBinding69(Object var0, boolean var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache69;
         MethodHandle var10 = bindingCache69;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache69 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;ZLjava/lang/Object;JJ)Ljava/lang/Class;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Class)var8.invokeExact((Object)var0, (boolean)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Class invokeBinding70(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache70;
         MethodHandle var8 = bindingCache70;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache70 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Class;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Class)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding71(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache71;
         MethodHandle var9 = bindingCache71;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache71 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding72(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache72;
         MethodHandle var8 = bindingCache72;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache72 = f(
                  MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Class invokeBinding73(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache73;
         MethodHandle var8 = bindingCache73;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache73 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Class;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Class)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Class invokeBinding74(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache74;
         MethodHandle var8 = bindingCache74;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache74 = f(MethodHandles.lookup(), "o", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Class;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Class)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding75(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache75;
         MethodHandle var9 = bindingCache75;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache75 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object[] invokeBinding76(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache76;
         MethodHandle var9 = bindingCache76;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache76 = f(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)[Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object[])var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
