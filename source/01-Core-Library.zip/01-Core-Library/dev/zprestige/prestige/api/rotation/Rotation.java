package dev.zprestige.prestige.api.rotation;

public class Rotation {
   private float a;
   private float b;
   private boolean c;

   public Rotation(float var1, float var2) {
      this.a = var1;
      this.b = var2;
   }

   public float aReturningFloat(Object[] var1) {
      return this.a;
   }

   public void aReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.a = var2;
   }

   public float bReturningFloat(Object[] var1) {
      return this.b;
   }

   public void bReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.b = var2;
   }

   public boolean aReturningBoolean(Object[] var1) {
      return this.c;
   }

   public void cReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      this.c = var2;
   }
}
