package dev.zprestige.prestige.api.rotation;

public interface RotationSource {
   Rotation aReturningdx_C0210(Object[] var1);

   default int a() {
      return 0;
   }
}
