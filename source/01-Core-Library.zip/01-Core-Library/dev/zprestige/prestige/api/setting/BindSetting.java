package dev.zprestige.prestige.api.setting;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.annotation.NativeMarker;
import dev.zprestige.prestige.api.setting.SettingDefinition;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;

public class BindSetting extends SettingDefinition {
   private boolean a;
   private static final long f = 111912969394906L;
   private static final long[] h;
   private static final Integer[] i;
   private static final Map j = new HashMap(13);
   private static final Object[] m = new Object[24];
   private static final String[] n = new String[24];
   private static volatile MethodHandle bindingCache1;

   public BindSetting(String var1, int var2) {
      super(var1, var2);
   }

   @NativeMarker
   public boolean b() {
      return this.a;
   }

   @NativeMarker
   public void a(boolean var1) {
      this.a = var1;
   }

   public BindSetting aReturningBindSetting(Object[] var1) {
      Predicate var4 = (Predicate)var1[0];
      long var2 = (Long)var1[1];
      var2 = 111912969394906L ^ var2;
      long var5 = var2 ^ 89735667179960L;
      super.aReturningdF_C0175(new Object[]{var4, var5});
      return this;
   }

   @NativeMarker
   public BindSetting setDescriptionReturningBindSetting(String var1) {
      super.setDescriptionReturningdF_C0175(var1);
      return this;
   }

   public boolean cReturningBoolean(Object[] var1) {
      int var39;
      short var40;
      long var2 = (Long)var1[0];
      var2 = 111912969394906L ^ var2;
      int var4 = Event.bReturningInt();
      BindSetting var5 = this;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var45 = var4;
      // int var43 = var10000;
      var39 = var43;
      var40 = var44;
      int var29 = var43;
      byte var30 = var44;
      label42:
      if (var45 == 0) {
         byte var47 = var30;
         int var46 = var29;
         if (var46 != var47) {
            BindSetting var8 = this;
            Integer var9 = (Integer)var8.aReturningObject();
            var10000 = var9;
            short var10001 = 27145;
            long var10002 = 8699784755893352572L ^ var2;
            int var50 = var4;
            short var49 = 9994;
            int var48 = var10000;
            var39 = var48;
            var40 = var49;
            int var31 = var48;
            short var32 = var49;
            if (var50 != 0) {
               break label42;
            }

            short var52 = var32;
            int var51 = var31;
            int var33 = var51;
            short var34 = var52;
            short var54 = var34;
            int var53 = var33;
            if (var53 > var54) {
               MinecraftClient var12 = MinecraftClient.getInstance();
               Window var13 = var12.getWindow();
               long var73 = var13.getHandle();
               var10001 = 9534;
               var10002 = 8307090782117689162L ^ var2;
               BindSetting var14 = this;
               Integer var15 = (Integer)var14.aReturningObject();
               int var18 = 9999 - var15;
               long var16 = var73;
               var10000 = GLFW.glfwGetMouseButton(var16, var18);
               int var56 = var4;
               int var55 = var10000;
               int var37 = var55;
               int var35 = var55;
               if (var56 == 0) {
                  int var57 = var35;
                  int var36 = var57;
                  byte var59 = 1;
                  int var58 = var36;
                  if (var58 == var59) {
                     return true;
                  }

                  var37 = 0;
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var37);
            }
         }

         MinecraftClient var22 = MinecraftClient.getInstance();
         Window var23 = var22.getWindow();
         long var71 = var23.getHandle();
         BindSetting var24 = this;
         Integer var25 = (Integer)var24.aReturningObject();
         int var28 = var25;
         long var26 = var71;
         var10000 = GLFW.glfwGetKey(var26, var28);
         int var63 = var4;
         int var62 = var10000;
         int var41 = var62;
         int var38 = var62;
         if (var63 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var41);
         }

         byte var65 = 1;
         int var64 = var38;
         var39 = var64;
         var40 = var65;
      }

      short var67 = var40;
      int var66 = var39;
      return var66 == var67;
   }

   @Override
   public SettingDefinition aReturningdF_C0175(Object[] var1) {
      Predicate var2 = (Predicate)var1[0];
      long var3 = (Long)var1[1];
      long var5 = var3 ^ 57543742831458L;
      return invokeBinding1(this, new Object[]{var2, var5}, -7793896963506858699L, var3);
   }

   @NativeMarker
   @Override
   public SettingDefinition setDescriptionReturningdF_C0175(String var1) {
      String var5 = var1;
      BindSetting var4 = this;
      return var4.setDescriptionReturningBindSetting(var5);
   }

   static {

      d();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(28177954971107L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "hõC<j\u0092'\u0090\u0090X\u0013\t[\u000f\u0096D";
      int var7 = "hõC<j\u0092'\u0090\u0090X\u0013\t[\u000f\u0096D".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      h = var8;
      i = new Integer[2];
   
      
}

   private static MatchException b(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 13955;
      if (i[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = h[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])j.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dG", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         i[var3] = var15;
      }

      return i[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dG_C0177",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 3;
            yield var15;
         }
         case 1 -> {
            byte var16 = 27;
            yield var16;
         }
         case 2 -> {
            byte var17 = 56;
            yield var17;
         }
         case 3 -> {
            byte var18 = 45;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 30;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 46;
            yield var22;
         }
         case 8 -> {
            byte var23 = 29;
            yield var23;
         }
         case 9 -> {
            byte var24 = 44;
            yield var24;
         }
         case 10 -> {
            byte var25 = 36;
            yield var25;
         }
         case 11 -> {
            byte var26 = 13;
            yield var26;
         }
         case 12 -> {
            byte var27 = 49;
            yield var27;
         }
         case 13 -> {
            byte var28 = 31;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 53;
            yield var30;
         }
         case 16 -> {
            byte var31 = 21;
            yield var31;
         }
         case 17 -> {
            byte var32 = 55;
            yield var32;
         }
         case 18 -> {
            byte var33 = 1;
            yield var33;
         }
         case 19 -> {
            byte var34 = 8;
            yield var34;
         }
         case 20 -> {
            byte var35 = 7;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 16;
            yield var37;
         }
         case 23 -> {
            byte var38 = 15;
            yield var38;
         }
         case 24 -> {
            byte var39 = 5;
            yield var39;
         }
         case 25 -> {
            byte var40 = 17;
            yield var40;
         }
         case 26 -> {
            byte var41 = 32;
            yield var41;
         }
         case 27 -> {
            byte var42 = 62;
            yield var42;
         }
         case 28 -> {
            byte var43 = 9;
            yield var43;
         }
         case 29 -> {
            byte var44 = 60;
            yield var44;
         }
         case 30 -> {
            byte var45 = 42;
            yield var45;
         }
         case 31 -> {
            byte var46 = 41;
            yield var46;
         }
         case 32 -> {
            byte var47 = 14;
            yield var47;
         }
         case 33 -> {
            byte var48 = 54;
            yield var48;
         }
         case 34 -> {
            byte var49 = 58;
            yield var49;
         }
         case 35 -> {
            byte var50 = 37;
            yield var50;
         }
         case 36 -> {
            byte var51 = 18;
            yield var51;
         }
         case 37 -> {
            byte var52 = 52;
            yield var52;
         }
         case 38 -> {
            byte var53 = 40;
            yield var53;
         }
         case 39 -> {
            byte var54 = 48;
            yield var54;
         }
         case 40 -> {
            byte var55 = 12;
            yield var55;
         }
         case 41 -> {
            byte var56 = 43;
            yield var56;
         }
         case 42 -> {
            byte var57 = 28;
            yield var57;
         }
         case 43 -> {
            byte var58 = 0;
            yield var58;
         }
         case 44 -> {
            byte var59 = 2;
            yield var59;
         }
         case 45 -> {
            byte var60 = 10;
            yield var60;
         }
         case 46 -> {
            byte var61 = 6;
            yield var61;
         }
         case 47 -> {
            byte var62 = 34;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 4;
            yield var64;
         }
         case 50 -> {
            byte var65 = 39;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 38;
            yield var69;
         }
         case 55 -> {
            byte var70 = 47;
            yield var70;
         }
         case 56 -> {
            byte var71 = 35;
            yield var71;
         }
         case 57 -> {
            byte var72 = 24;
            yield var72;
         }
         case 58 -> {
            byte var73 = 11;
            yield var73;
         }
         case 59 -> {
            byte var74 = 51;
            yield var74;
         }
         case 60 -> {
            byte var75 = 25;
            yield var75;
         }
         case 61 -> {
            byte var76 = 63;
            yield var76;
         }
         case 62 -> {
            byte var77 = 50;
            yield var77;
         }
         default -> 20;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void d() {
      m[0] = "c\u001a\u007fQv1u\u001az\u000be&bQy\ri2s\u0016n\u001a\"%@";
      m[1] = "i*myi \u001c\nfvxo}\u0004m}|5\t";
      m[2] = "\u0003\rx~>i\b\u0002i1Cq\u001b\u0005`x";
      m[3] = "Z\u001bl[skZ\u001b{\u0007\u007fd@P{\u0019\u007fqG!)E*3";
      m[4] = long.class;
      n[4] = "java/lang/Long";
      m[5] = "\u007f.9\u001d\u007f\ti.<Gl\u001e~e?A`\no\"(V+\u0018^";
      m[6] = int.class;
      n[6] = "java/lang/Integer";
      m[7] = "&3f\u00010t-<wNSy81x%f{)\"d\tqv";
      m[8] = "Y\u001cGY]U\\\tLYVNP\u0019\u000e0}da";
      m[9] = "AN '\u0005oAN7{\t`[\u00057e\tu\\tg8X";
      m[10] = "\u000f\u0001UhyZ\u0019\u0001P2jM\u000eJS4fY\u001f\rD#-N-";
      m[11] = "\u000b/ro%\u001e\u0000 c D\u0010\u000b+gz";
      m[12] = "PX4#T\n[W%l3\bN\\%'\b";
      m[13] = "9YPLmw:XQLQ,j[]P=\u001e>\u001a\u0000\u000eQwyJF\u000botxKF7";
      m[14] = "\u0005\u0002\u0019\\!7\u0003\\\u000e\u0002K8:\r\u0006\u0002';\u0003[\u001aR\"Q";
      m[15] = "ypc\u0014r5%;2\u0015\u001f%/}\u0006\u0010{9$\u0001dGcx0:9\u0010r.I";
      m[16] = "I@gA7\u0017\u0001Z3\u0012\nH\u001eF<KfzO\u0006m\u0014\n\u0016IP8\u00144S\u001e_-,";
      m[17] = "RQ\u0002f<GY\u0010\u0006'P\u0016i\u0015\u0000cl\u0005RHWr:|";
      m[18] = ")\u0010D4Qw7Q\u0010\u000bV\u0018w\u0007\u0010b\u0000jq\u0014\u0018m<%$QA7N#7YN\u000b";
      m[19] = "`\u0012_/&|b\u0002\u0006{@u9\f\u0019^-f\u0018\u0005\u001bj-P \u001e\u001av&\u001afX\fux$#\u000f\u0003`@&c\u001eZh{{4\u000f\f\u0011|$!^\u001f*!s0\bf";
      m[20] = "K\u001c.\u000ey1U]z1o3T)/J\u007f$I\u001d>Ps8(\\,Mn.D\u001d-Cz^K\u001c.\u000ey1U]z1";
      m[21] = "yRV\u0017\u00010zSW\u0017=k*P[\u000bQY}\u0016\u0005\\\u0006\u000e}V\u0000\u0001\u000045LTR=";
      m[22] = "po;GD\u0006r\u007fb\u0013\"\u000f)q}6O\u001c\u000ersy\u0019Z'{:G\\\r(n\u0002E\u001c\u001cqf9\u0018K\r'\u001f>G^\\4$c\u0010O\nM";
      m[23] = "\f/_6?T\u0012n\u000b\t;;VnUp=\u0005T8RnRX\u0016:\fd=FWn3";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(781946594822134L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(781946594822134L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(781946594822134L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 206;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 217;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 82;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 193;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 69;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 216;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 206;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 217;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 82;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dG_C0177",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static BindSetting invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = c(
                  MethodHandles.lookup(),
                  "E",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/dG_C0177;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (BindSetting)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
