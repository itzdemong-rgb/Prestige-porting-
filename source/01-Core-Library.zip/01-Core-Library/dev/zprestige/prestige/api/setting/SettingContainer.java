package dev.zprestige.prestige.api.setting;

import dev.prestige.recovery.SourceSupport;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class SettingContainer {
   public final ArrayList a = new ArrayList();
   private static final long db = 91394228744290L;
   private static final Object[] sb = new Object[4];
   private static final String[] tb = new String[4];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;

   public BindSetting aReturningBindSetting(Object[] var1) {
      String var5 = (String)var1[0];
      int var2 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 91394228744290L ^ var3;
      BindSetting var6 = new BindSetting(var5, var2);
      BindSetting var8 = var6;
      ArrayList var7 = this.a;
      var7.add(var8);
      return var6;
   }

   public BooleanSetting aReturningBooleanSetting(Object[] var1) {
      String var5 = (String)var1[0];
      boolean var2 = (Boolean)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 91394228744290L ^ var3;
      BooleanSetting var6 = new BooleanSetting(var5, var2);
      BooleanSetting var8 = var6;
      ArrayList var7 = this.a;
      var7.add(var8);
      return var6;
   }

   public FloatSetting aReturningFloatSetting(Object[] var1) {
      String var3 = (String)var1[0];
      float var7 = (Float)var1[1];
      float var2 = (Float)var1[2];
      float var6 = (Float)var1[3];
      long var4 = (Long)var1[4];
      var4 = 91394228744290L ^ var4;
      FloatSetting var8 = new FloatSetting(var3, var7, var2, var6);
      invokeBinding1(this.a, var8, -5329565924661003668L, var4);
      return var8;
   }

   public IntSetting aReturningIntSetting(Object[] var1) {
      String var7 = (String)var1[0];
      int var3 = (Integer)var1[1];
      int var2 = (Integer)var1[2];
      int var6 = (Integer)var1[3];
      long var4 = (Long)var1[4];
      var4 = 91394228744290L ^ var4;
      IntSetting var8 = new IntSetting(var7, var3, var2, var6);
      invokeBinding2(this.a, var8, 4847147097599971105L, var4);
      return var8;
   }

   public MinMaxSetting aReturningMinMaxSetting(Object[] var1) {
      String var5 = (String)var1[0];
      float var4 = (Float)var1[1];
      float var8 = (Float)var1[2];
      float var3 = (Float)var1[3];
      float var2 = (Float)var1[4];
      long var6 = (Long)var1[5];
      var6 = 91394228744290L ^ var6;
      MinMaxSetting var9 = new MinMaxSetting(var5, var4, var8, var3, var2);
      invokeBinding3(this.a, var9, -466450865061120541L, var6);
      return var9;
   }

   public StringSetting aReturningStringSetting(Object[] var1) {
      String var5 = (String)var1[0];
      String var4 = (String)var1[1];
      String var6 = (String)var1[2];
      long var2 = (Long)var1[3];
      var2 = 91394228744290L ^ var2;
      StringSetting var7 = new StringSetting(var5, var4, var6);
      invokeBinding4(this.a, var7, -1975250437217998605L, var2);
      return var7;
   }

   public ModeSetting aReturningModeSetting(Object[] var1) {
      String var4 = (String)var1[0];
      String var6 = (String)var1[1];
      String[] var5 = (String[])var1[2];
      long var2 = (Long)var1[3];
      long var10000 = 91394228744290L ^ var2;
      ModeSetting var7 = new ModeSetting(var4, var6, var5);
      ModeSetting var9 = var7;
      ArrayList var8 = this.a;
      var8.add(var9);
      return var7;
   }

   public ColorSetting aReturningColorSetting(Object[] var1) {
      String var4 = (String)var1[0];
      Color var5 = (Color)var1[1];
      long var2 = (Long)var1[2];
      long var10000 = 91394228744290L ^ var2;
      ColorSetting var6 = new ColorSetting(var4, var5);
      ColorSetting var8 = var6;
      ArrayList var7 = this.a;
      var7.add(var8);
      return var6;
   }

   public MultiModeSetting aReturningMultiModeSetting(Object[] var1) {
      String var2 = (String)var1[0];
      String[] var3 = (String[])var1[1];
      boolean[] var6 = (boolean[])var1[2];
      long var4 = (Long)var1[3];
      var4 = 91394228744290L ^ var4;
      MultiModeSetting var7 = new MultiModeSetting(var2, var3, var6);
      invokeBinding5(this.a, var7, 4343312737676193827L, var4);
      return var7;
   }

   static {
      e();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = tb[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = sb[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 39;
            yield var15;
         }
         case 1 -> {
            byte var16 = 6;
            yield var16;
         }
         case 2 -> {
            byte var17 = 63;
            yield var17;
         }
         case 3 -> {
            byte var18 = 24;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 38;
            yield var20;
         }
         case 6 -> {
            byte var21 = 27;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 55;
            yield var23;
         }
         case 9 -> {
            byte var24 = 11;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 30;
            yield var26;
         }
         case 12 -> {
            byte var27 = 60;
            yield var27;
         }
         case 13 -> {
            byte var28 = 49;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 21;
            yield var30;
         }
         case 16 -> {
            byte var31 = 53;
            yield var31;
         }
         case 17 -> {
            byte var32 = 3;
            yield var32;
         }
         case 18 -> {
            byte var33 = 10;
            yield var33;
         }
         case 19 -> {
            byte var34 = 0;
            yield var34;
         }
         case 20 -> {
            byte var35 = 23;
            yield var35;
         }
         case 21 -> {
            byte var36 = 14;
            yield var36;
         }
         case 22 -> {
            byte var37 = 62;
            yield var37;
         }
         case 23 -> {
            byte var38 = 28;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 1;
            yield var40;
         }
         case 26 -> {
            byte var41 = 13;
            yield var41;
         }
         case 27 -> {
            byte var42 = 33;
            yield var42;
         }
         case 28 -> {
            byte var43 = 58;
            yield var43;
         }
         case 29 -> {
            byte var44 = 5;
            yield var44;
         }
         case 30 -> {
            byte var45 = 42;
            yield var45;
         }
         case 31 -> {
            byte var46 = 45;
            yield var46;
         }
         case 32 -> {
            byte var47 = 47;
            yield var47;
         }
         case 33 -> {
            byte var48 = 16;
            yield var48;
         }
         case 34 -> {
            byte var49 = 18;
            yield var49;
         }
         case 35 -> {
            byte var50 = 2;
            yield var50;
         }
         case 36 -> {
            byte var51 = 31;
            yield var51;
         }
         case 37 -> {
            byte var52 = 48;
            yield var52;
         }
         case 38 -> {
            byte var53 = 15;
            yield var53;
         }
         case 39 -> {
            byte var54 = 12;
            yield var54;
         }
         case 40 -> {
            byte var55 = 46;
            yield var55;
         }
         case 41 -> {
            byte var56 = 22;
            yield var56;
         }
         case 42 -> {
            byte var57 = 32;
            yield var57;
         }
         case 43 -> {
            byte var58 = 26;
            yield var58;
         }
         case 44 -> {
            byte var59 = 4;
            yield var59;
         }
         case 45 -> {
            byte var60 = 8;
            yield var60;
         }
         case 46 -> {
            byte var61 = 44;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 61;
            yield var63;
         }
         case 49 -> {
            byte var64 = 17;
            yield var64;
         }
         case 50 -> {
            byte var65 = 34;
            yield var65;
         }
         case 51 -> {
            byte var66 = 41;
            yield var66;
         }
         case 52 -> {
            byte var67 = 36;
            yield var67;
         }
         case 53 -> {
            byte var68 = 25;
            yield var68;
         }
         case 54 -> {
            byte var69 = 35;
            yield var69;
         }
         case 55 -> {
            byte var70 = 54;
            yield var70;
         }
         case 56 -> {
            byte var71 = 52;
            yield var71;
         }
         case 57 -> {
            byte var72 = 51;
            yield var72;
         }
         case 58 -> {
            byte var73 = 57;
            yield var73;
         }
         case 59 -> {
            byte var74 = 50;
            yield var74;
         }
         case 60 -> {
            byte var75 = 29;
            yield var75;
         }
         case 61 -> {
            byte var76 = 20;
            yield var76;
         }
         case 62 -> {
            byte var77 = 9;
            yield var77;
         }
         default -> 7;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            tb[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void e() {
      sb[0] = "GI\u001f\u0019f&YA\u0005V\t!_I\u00104! Y";
      sb[1] = "\u000bTrAa\u0007\u0000[c\u000e\u0000\t\u000bPgT";
      sb[2] = boolean.class;
      tb[2] = "java/lang/Boolean";
      sb[3] = "v\u001bE\r\u001f\\v^\n3\u0007WueBZ\u0011Fw\u0007@\u0003\u0001_\u0019\\\u0003\u000bR\u0002c\u0014\u001c\u000f\t;";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = sb[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(tb[var4]);
            sb[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = sb[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = tb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            sb[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  sb[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(132344951520405L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = sb[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = tb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  sb[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(132344951520405L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        sb[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(132344951520405L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 118;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 196;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 219;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 253;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 234;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 254;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 118;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 196;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 219;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite f(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dP_C0193",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static boolean invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = f(MethodHandles.lookup(), "ê", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = f(MethodHandles.lookup(), "ê", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = f(MethodHandles.lookup(), "ê", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = f(MethodHandles.lookup(), "ê", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding5(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = f(MethodHandles.lookup(), "ê", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
