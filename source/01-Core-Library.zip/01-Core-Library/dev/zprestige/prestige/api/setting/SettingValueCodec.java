package dev.zprestige.prestige.api.setting;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.api.setting.StringSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class SettingValueCodec {
   private static final long a = 64484543068669L;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[97];
   private static final String[] i = new String[97];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   private SettingValueCodec() {
   }

   public static void aReturningVoid(Object[] var0) {
      SettingDefinition var1 = (SettingDefinition)var0[0];
      Object var2 = var0[1];
      long var3 = (Long)var0[2];
      var3 = 64484543068669L ^ var3;
      long var5 = var3 ^ 102692271104312L;
      long var7 = var3 ^ 80847416625127L;
      long var9 = var3 ^ 56905603148065L;
      long var11 = var3 ^ 124424756174136L;
      long var13 = var3 ^ 140137267655150L;
      long var15 = var3 ^ 11139459936527L;
      int var17 = Event.cReturningInt();
      int var199 = var17;
      SettingDefinition var198 = var1;
      Object var152 = var198;
      SettingDefinition var151 = var198;
      if (var199 != 0) {
         SettingDefinition var200 = var151;
         if (var200 == null) {
            short var347 = 12601;
            long var356 = 1266892853558137657L ^ var3;
            throw new IllegalArgumentException("setting is missing");
         }

         var152 = var2;
      }

      int var202 = var17;
      Object var201 = var152;
      Object var154 = var201;
      Object var153 = var201;
      if (var202 != 0) {
         Object var203 = var153;
         if (var203 == null) {
            short var346 = 5147;
            long var355 = 4167736253788747288L ^ var3;
            throw new IllegalArgumentException("value is null");
         }

         var154 = var2;
      }

      Object var31 = var154;
      String var18 = var31.toString();
      int var10000 = (((var1 instanceof BooleanSetting) ? 1 : 0));
      int var205 = var17;
      boolean var204 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var156 = var204;
      boolean var155 = var204;
      if (var205 != 0) {
         boolean var206 = var155;
         if (var206) {
            BooleanSetting var288 = (BooleanSetting)var1;
            Object[] var33 = new Object[]{var18, var5};
            boolean var34 = aReturningBoolean(var33);
            Boolean var36 = var34;
            BooleanSetting var35 = var288;
            var35.aReturningVoid(var36);
            return;
         }

         var156 = var1 instanceof BindSetting;
      }

      int var208 = var17;
      boolean var207 = var156;
      boolean var172 = var207;
      boolean var157 = var207;
      if (var208 != 0) {
         boolean var209 = var157;
         if (var209) {
            BindSetting var287 = (BindSetting)var1;
            short var321 = 32114;
            long var339 = 3631573144636694396L ^ var3;
            String var39 = "\\.";
            String var38 = var18;
            String[] var293 = var38.split(var39, -1);
            var10000 = var293.length;
            int var211 = var17;
            int var210 = var10000;
            int var159 = var210;
            int var158 = var210;
            if (var211 != 0) {
               byte var213 = 2;
               int var212 = var158;
               if (var212 != var213) {
                  short var345 = 28221;
                  long var354 = 5430624139511860279L ^ var3;
                  throw new IllegalArgumentException("expected key.hold");
               }

               String var310 = var293[0];
               var321 = 2509;
               var339 = 6587065807695735753L ^ var3;
               Object[] var43 = new Object[]{var310, "key", var7};
               var159 = aReturningInt(var43);
            }

            label203: {
               int var296 = var159;
               Object[] var44 = new Object[]{var293[1], var5};
               boolean var299 = aReturningBoolean(var44);
               int var216 = var17;
               // int var214 = var296;
               int var162 = var214;
               short var163 = var215;
               int var160 = var214;
               byte var161 = var215;
               if (var216 != 0) {
                  byte var218 = var161;
                  int var217 = var160;
                  if (var217 < var218) {
                     break label203;
                  }

                  var321 = 11439;
                  var339 = 6494355887550115237L ^ var3;
                  short var220 = 348;
                  int var219 = var296;
                  var162 = var219;
                  var163 = var220;
               }

               label204: {
                  int var223 = var17;
                  short var222 = var163;
                  int var221 = var162;
                  int var166 = var221;
                  short var167 = var222;
                  int var164 = var221;
                  short var165 = var222;
                  if (var223 != 0) {
                     short var225 = var165;
                     int var224 = var164;
                     if (var224 <= var225) {
                        break label204;
                     }

                     var321 = 1497;
                     var339 = 350777183898141906L ^ var3;
                     short var227 = 9995;
                     int var226 = var296;
                     var166 = var226;
                     var167 = var227;
                  }

                  int var230 = var17;
                  short var229 = var167;
                  int var228 = var166;
                  int var170 = var228;
                  short var171 = var229;
                  int var168 = var228;
                  short var169 = var229;
                  if (var230 != 0) {
                     short var232 = var169;
                     int var231 = var168;
                     if (var231 < var232) {
                        break label203;
                     }

                     var321 = 29450;
                     var339 = 40037354222088706L ^ var3;
                     short var234 = 9999;
                     int var233 = var296;
                     var170 = var233;
                     var171 = var234;
                  }

                  short var236 = var171;
                  int var235 = var170;
                  if (var235 > var236) {
                     break label203;
                  }
               }

               int var52 = var296;
               Integer var54 = var52;
               BindSetting var53 = var287;
               var53.aReturningVoid(var54);
               boolean var56 = var299;
               BindSetting var55 = var287;
               var55.aReturningVoid(var56);
               return;
            }

            short var344 = 3955;
            long var353 = 6299156881027034469L ^ var3;
            throw new IllegalArgumentException("key is outside the supported bind range");
         }

         var172 = var1 instanceof ColorSetting;
      }

      int var238 = var17;
      boolean var237 = var172;
      boolean var176 = var237;
      boolean var173 = var237;
      if (var238 != 0) {
         boolean var239 = var173;
         if (var239) {
            ColorSetting var286 = (ColorSetting)var1;
            short var316 = 9564;
            long var333 = 7133353964729354069L ^ var3;
            String var59 = "\\.";
            String var58 = var18;
            String[] var292 = var58.split(var59, -1);
            var10000 = var292.length;
            int var241 = var17;
            int var240 = var10000;
            int var175 = var240;
            int var174 = var240;
            if (var241 != 0) {
               byte var243 = 4;
               int var242 = var174;
               if (var242 != var243) {
                  short var338 = 26272;
                  long var352 = 7132438737425073327L ^ var3;
                  throw new IllegalArgumentException("expected red.green.blue.alpha");
               }

               String var305 = var292[0];
               var316 = 23545;
               var333 = 5094739561465526769L ^ var3;
               Object[] var63 = new Object[]{var305, "red", var9};
               var175 = bReturningInt(var63);
            }

            int var295 = var175;
            String var306 = var292[1];
            var316 = 18283;
            var333 = 2554197510546105696L ^ var3;
            Object[] var64 = new Object[]{var306, "green", var9};
            int var298 = bReturningInt(var64);
            String var307 = var292[2];
            var316 = 5496;
            var333 = 4054559035587557224L ^ var3;
            Object[] var65 = new Object[]{var307, "blue", var9};
            int var300 = bReturningInt(var65);
            String var308 = var292[3];
            var316 = 2403;
            var333 = 5891686352016042853L ^ var3;
            Object[] var66 = new Object[]{var308, "alpha", var9};
            int var301 = bReturningInt(var66);
            Color var68 = new Color(var295, var298, var300, var301);
            ColorSetting var67 = var286;
            var67.aReturningVoid(var68);
            return;
         }

         var176 = var1 instanceof FloatSetting;
      }

      int var245 = var17;
      boolean var244 = var176;
      boolean var178 = var244;
      boolean var177 = var244;
      if (var245 != 0) {
         boolean var246 = var177;
         if (var246) {
            FloatSetting var285 = (FloatSetting)var1;
            Object[] var70 = new Object[]{var18, var11};
            float var291 = aReturningFloat(var70);
            FloatSetting var71 = var285;
            float var332 = var71.aReturningVoid();
            FloatSetting var72 = var285;
            float var75 = var72.bReturningVoid();
            float var74 = var332;
            float var73 = var291;
            float var76 = Math.clamp(var73, var74, var75);
            Float var78 = var76;
            FloatSetting var77 = var285;
            var77.aReturningVoid(var78);
            return;
         }

         var178 = var1 instanceof IntSetting;
      }

      int var248 = var17;
      boolean var247 = var178;
      boolean var180 = var247;
      boolean var179 = var247;
      if (var248 != 0) {
         boolean var249 = var179;
         if (var249) {
            IntSetting var284 = (IntSetting)var1;
            short var314 = 21937;
            long var330 = 2648605660198909867L ^ var3;
            Object[] var80 = new Object[]{var18, "integer", var7};
            int var290 = aReturningInt(var80);
            long var315 = var290;
            IntSetting var81 = var284;
            int var331 = var81.aReturningVoid();
            IntSetting var82 = var284;
            int var86 = var82.dReturningVoid();
            int var85 = var331;
            long var83 = var315;
            int var87 = Math.clamp(var83, var85, var86);
            Integer var89 = var87;
            IntSetting var88 = var284;
            var88.aReturningVoid(var89);
            return;
         }

         var180 = var1 instanceof ModeSetting;
      }

      int var251 = var17;
      boolean var250 = var180;
      boolean var184 = var250;
      boolean var181 = var250;
      if (var251 != 0) {
         boolean var252 = var181;
         if (var252) {
            ModeSetting var283 = (ModeSetting)var1;
            int var254 = var17;
            ModeSetting var253 = var283;
            ModeSetting var183 = var253;
            ModeSetting var182 = var253;
            if (var254 != 0) {
               ModeSetting var91 = var182;
               String[] var92 = var91.aReturningArrayOfString();
               Stream var303 = Arrays.stream(var92);
               String var93 = var18;
               Objects.requireNonNull(var93);
               Predicate var95 = invokeBinding1(var18);
               Stream var94 = var303;
               boolean var255 = var94.noneMatch(var95);
               if (var255) {
                  short var350 = 21876;
                  long var357 = 6827465518441223291L ^ var3;
                  Object[] var10006 = new Object[]{null, null, var15};
                  var10006[1] = 32;
                  var10006[0] = var18;
                  Object[] var97 = var10006;
                  String var329 = aReturningString(var97);
                  var350 = 31265;
                  var357 = 7117206894513297428L ^ var3;
                  throw new IllegalArgumentException("unknown mode '" + var329 + "'");
               }

               var183 = var283;
            }

            String var100 = var18;
            ModeSetting var99 = var183;
            var99.aReturningVoid(var100);
            return;
         }

         var184 = var1 instanceof MultiModeSetting;
      }

      int var257 = var17;
      boolean var256 = var184;
      boolean var186 = var256;
      boolean var185 = var256;
      if (var257 != 0) {
         boolean var258 = var185;
         if (var258) {
            MultiModeSetting var282 = (MultiModeSetting)var1;
            Object[] var102 = new Object[]{var282, var18, var13};
            Map var289 = aReturningMap(var102);
            Map var103 = var289;
            Set var104 = var103.entrySet();
            Iterator var294 = var104.iterator();

            int var260;
            do {
               Iterator var105 = var294;
               boolean var259 = var105.hasNext();
               if (!var259) {
                  break;
               }

               Iterator var106 = var294;
               Entry var297 = (Entry)var106.next();
               Entry var107 = var297;
               String var313 = (String)var107.getKey();
               Entry var108 = var297;
               Boolean var109 = (Boolean)var108.getValue();
               boolean var112 = var109;
               String var111 = var313;
               MultiModeSetting var110 = var282;
               var110.aReturningVoid(var111, var112);
               var260 = var17;
            } while (var260 != 0);

            return;
         }

         var186 = var1 instanceof MinMaxSetting;
      }

      SettingDefinition var197;
      label206: {
         int var262 = var17;
         boolean var261 = var186;
         boolean var196 = var261;
         boolean var187 = var261;
         if (var262 != 0) {
            boolean var263 = var187;
            if (var263) {
               MinMaxSetting var281 = (MinMaxSetting)var1;
               short var10001 = 28749;
               long var326 = 62745942419280478L ^ var3;
               String var115 = "\\|";
               String var114 = var18;
               String[] var20 = var114.split(var115, -1);
               int var265 = var17;
               String[] var264 = var20;
               String[] var189 = var264;
               String[] var188 = var264;
               if (var265 != 0) {
                  var10000 = var188.length;
                  byte var267 = 2;
                  int var266 = var10000;
                  if (var266 != var267) {
                     short var328 = 1848;
                     long var349 = 7767592712588387631L ^ var3;
                     throw new IllegalArgumentException("expected minimum|maximum");
                  }

                  var189 = var20;
               }

               Object[] var119 = new Object[]{var189[0], var11};
               float var21 = aReturningFloat(var119);
               Object[] var120 = new Object[]{var20[1], var11};
               float var22 = aReturningFloat(var120);
               MinMaxSetting var121 = var281;
               float var311 = var121.cReturningVoid();
               MinMaxSetting var122 = var281;
               float var125 = var122.dReturningVoid();
               float var124 = var311;
               float var123 = var21;
               float var23 = Math.clamp(var123, var124, var125);
               MinMaxSetting var126 = var281;
               float var312 = var126.cReturningVoid();
               MinMaxSetting var127 = var281;
               float var130 = var127.dReturningVoid();
               float var129 = var312;
               float var128 = var22;
               float var24 = Math.clamp(var128, var129, var130);
               int var269 = var17;
               float var268 = var23;
               float var191 = var268;
               float var190 = var268;
               if (var269 != 0) {
                  float var359;
                  int var270 = (var359 = var190 - var24) == 0.0F ? 0 : (var359 < 0.0F ? -1 : 1);
                  if (var270 > 0) {
                     short var327 = 29116;
                     long var348 = 1694888411027608497L ^ var3;
                     throw new IllegalArgumentException("minimum is greater than maximum");
                  }

                  Object[] var134 = new Object[0];
                  MinMaxSetting var133 = var281;
                  var191 = var133.eReturningFloat(var134);
               }

               float var25 = var191;
               int var272 = var17;
               float var271 = var25;
               float var193 = var271;
               float var192 = var271;
               float var194;
               if (var272 != 0) {
                  float var135 = var192;
                  boolean var273 = Float.isFinite(var135);
                  if (var273) {
                     float var139 = var24;
                     float var138 = var23;
                     float var137 = var25;
                     float var274 = Math.clamp(var137, var138, var139);
                     var194 = var274;
                  } else {
                     var194 = var23;
                  }
               } else {
                  float var275 = var193;
                  var194 = var275;
               }

               float var26 = var194;
               float var142 = var23;
               MinMaxSetting var141 = var281;
               var141.aReturningVoid(var142);
               float var144 = var24;
               MinMaxSetting var143 = var281;
               var143.bReturningVoid(var144);
               Object[] var146 = new Object[]{var26};
               MinMaxSetting var145 = var281;
               var145.cReturningVoid(var146);
               return;
            }

            int var277 = var17;
            SettingDefinition var276 = var1;
            var197 = var276;
            SettingDefinition var195 = var276;
            if (var277 == 0) {
               break label206;
            }

            boolean var278 = var195 instanceof StringSetting;
            var196 = var278;
         }

         boolean var279 = var196;
         if (!var279) {
            Class var150 = var1.getClass();
            String var10002 = var150.getSimpleName();
            short var10003 = 30536;
            long var10004 = 1632261586536797514L ^ var3;
            throw new IllegalArgumentException("unsupported setting type " + var10002);
         }

         var197 = var1;
      }

      StringSetting var19 = (StringSetting)var197;
      String var149 = var18;
      StringSetting var148 = var19;
      var148.aReturningVoid(var149);
   }

   public static boolean aReturningBoolean(Object[] var0) {
      Object var1 = var0[0];
      long var2 = (Long)var0[1];
      var2 = 64484543068669L ^ var2;
      int var4 = Event.bReturningInt();
      int var23 = var4;
      Object var22 = var1;
      Object var17 = var22;
      Object var16 = var22;
      if (var23 == 0) {
         Object var24 = var16;
         if (var24 == null) {
            short var35 = 21050;
            long var36 = 7024182217549834474L ^ var2;
            throw new IllegalArgumentException("value is null");
         }

         var17 = var1;
      }

      Object var8 = var17;
      String var9 = var8.toString();
      String var5 = var9.trim();
      short var10000 = 27023;
      long var10001 = 7447288266898461523L ^ var2;
      String var11 = var5;
      String var10 = "true";
      short var32 = ((short)((var10.equalsIgnoreCase(var11)) ? 1 : 0));
      int var26 = var4;
      byte var25 = (byte)var32;
      byte var19 = var25;
      byte var18 = var25;
      if (var26 == 0) {
         byte var27 = var18;
         if (var27 != 0) {
            return true;
         }

         var32 = 831;
         var10001 = 4012803041928395239L ^ var2;
         String var15 = var5;
         String var14 = "false";
         var19 = ((byte)((var14.equalsIgnoreCase(var15)) ? 1 : 0));
      }

      int var29 = var4;
      byte var28 = var19;
      byte var21 = var28;
      byte var20 = var28;
      if (var29 == 0) {
         byte var30 = var20;
         if (var30 == 0) {
            short var10002 = 22506;
            long var10003 = 7597461440302017832L ^ var2;
            throw new IllegalArgumentException("expected true or false");
         }

         var21 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var21);
   }

   
   
   public static float aReturningFloat(Object[] var0) {
      Object var1 = var0[0];
      long var2 = (Long)var0[1];
      var2 = 64484543068669L ^ var2;
      int var4 = Event.cReturningInt();
      int var19 = var4;
      Object var18 = var1;
      Object var14 = var18;
      Object var13 = var18;
      if (var19 != 0) {
         Object var20 = var13;
         if (var20 == null) {
            short var29 = 5147;
            long var32 = 4167674114321191645L ^ var2;
            throw new IllegalArgumentException("value is null");
         }

         try {
            var14 = var1;
         } catch (NumberFormatException var25) {
            short var10002 = 16953;
            long var10003 = 314630906883032292L ^ var2;
            throw new IllegalArgumentException("expected a number", var25);
         }
      }

      float var5;
      try {
         Object var9 = var14;
         String var10 = var9.toString();
         String var11 = var10.trim();
         var5 = Float.parseFloat(var11);
      } catch (NumberFormatException var24) {
         short var27 = 16953;
         long var30 = 314630906883032292L ^ var2;
         throw new IllegalArgumentException("expected a number", var24);
      }

      int var22 = var4;
      float var21 = var5;
      float var17 = var21;
      float var16 = var21;
      if (var22 != 0) {
         float var12 = var16;
         boolean var23 = Float.isFinite(var12);
         if (!var23) {
            short var28 = 21838;
            long var31 = 3994679686551163790L ^ var2;
            throw new IllegalArgumentException("number must be finite");
         }

         var17 = var5;
      }

      return var17;
   }

   private static Map aReturningMap(Object[] var0) {
      MultiModeSetting var1 = (MultiModeSetting)var0[0];
      String var2 = (String)var0[1];
      long var3 = (Long)var0[2];
      var3 = 64484543068669L ^ var3;
      long var5 = var3 ^ 27162750069035L;
      long var7 = var3 ^ 87892777761052L;
      int var10000 = Event.bReturningInt();
      LinkedHashMap var10 = new LinkedHashMap();
      int var9 = var10000;
      int var80 = var9;
      String var79 = var2;
      String var65 = var79;
      String var64 = var79;
      if (var80 == 0) {
         String var18 = var64;
         boolean var81 = var18.isEmpty();
         if (var81) {
            short var122 = 18191;
            long var129 = 6362296446160940302L ^ var3;
            throw new IllegalArgumentException("mode list is empty");
         }

         var65 = var2;
      }

      String var22 = "&";
      String var21 = var65;
      String[] var11 = var21.split(var22, -1);
      int var12 = var11.length;
      label100: {
         byte var78;
         while (true) {
            int var83 = var12;
            int var82 = var13;
            if (var82 < var83) {
               String var14 = var11[var13];
               String var24 = var14;
               byte var115 = ((byte)((var24.isEmpty()) ? 1 : 0));
               int var85 = var9;
               byte var84 = var115;
               var78 = var84;
               byte var66 = var84;
               if (var85 != 0) {
                  break;
               }

               label102: {
                  int var87 = var9;
                  byte var86 = var66;
                  int var69 = var86;
                  byte var67 = var86;
                  if (var87 == 0) {
                     byte var88 = var67;
                     byte var68 = var88;
                     byte var89 = var68;
                     if (var89 != 0) {
                        int var90 = var9;
                        if (var90 == 0) {
                           break label102;
                        }
                     }

                     short var10001 = 32196;
                     long var10002 = 5160511136861517018L ^ var3;
                     String var28 = var14;
                     int var91 = var28.lastIndexOf(46);
                     var69 = var91;
                  }

                  int var15 = var69;
                  int var93 = var9;
                  int var92 = var15;
                  int var71 = var92;
                  int var70 = var92;
                  if (var93 == 0) {
                     int var94 = var70;
                     if (var94 <= 0) {
                        break label100;
                     }

                     var71 = var15;
                  }

                  String var32 = var14;
                  int var96 = var32.length() - 1;
                  int var95 = var71;
                  if (var95 == var96) {
                     break label100;
                  }

                  LinkedHashMap var76;
                  String var77;
                  label103: {
                     byte var117 = 0;
                     int var36 = var15;
                     String var34 = var14;
                     String var16 = var34.substring(0, var36);
                     MultiModeSetting var37 = var1;
                     String[] var38 = var37.aReturningArrayOfString();
                     Stream var116 = Arrays.stream(var38);
                     String var39 = var16;
                     Objects.requireNonNull(var39);
                     Predicate var41 = invokeBinding2(var16);
                     Stream var40 = var116;
                     boolean var17 = var40.anyMatch(var41);
                     int var98 = var9;
                     boolean var97 = var17;
                     boolean var75 = var97;
                     boolean var72 = var97;
                     if (var98 == 0) {
                        boolean var99 = var72;
                        if (!var99) {
                           short var124 = 27402;
                           long var131 = 3256637848762081815L ^ var3;
                           Object[] var135 = new Object[]{null, null, var7};
                           var135[1] = 32;
                           var135[0] = var16;
                           Object[] var43 = var135;
                           String var119 = aReturningString(var43);
                           var124 = 29595;
                           var131 = 1430531662168725907L ^ var3;
                           throw new IllegalArgumentException("unknown option '" + var119 + "'");
                        }

                        int var102 = var9;
                        String var101 = var16;
                        LinkedHashMap var100 = var10;
                        var76 = var100;
                        var77 = var101;
                        LinkedHashMap var73 = var100;
                        String var74 = var101;
                        if (var102 != 0) {
                           break label103;
                        }

                        String var46 = var74;
                        LinkedHashMap var45 = var73;
                        boolean var103 = var45.containsKey(var46);
                        var75 = var103;
                     }

                     boolean var104 = var75;
                     if (var104) {
                        short var10003 = 21876;
                        long var10004 = 6827530043442093160L ^ var3;
                        Object[] var10006 = new Object[]{null, null, var7};
                        var10006[1] = 32;
                        var10006[0] = var16;
                        Object[] var48 = var10006;
                        String var118 = aReturningString(var48);
                        var10003 = 10538;
                        var10004 = 8920935866806158133L ^ var3;
                        throw new IllegalArgumentException("duplicate option '" + var118 + "'");
                     }

                     var77 = var16;
                     var76 = var10;
                  }

                  int var51 = var15 + 1;
                  String var50 = var14;
                  Object[] var52 = new Object[]{var50.substring(var51), var5};
                  boolean var53 = aReturningBoolean(var52);
                  Boolean var56 = var53;
                  String var55 = var77;
                  LinkedHashMap var54 = var76;
                  var54.put(var55, var56);
               }

               var13++;
               int var105 = var9;
               if (var105 == 0) {
                  continue;
               }
            }

            MultiModeSetting var57 = var1;
            var11 = var57.aReturningArrayOfString();
            var12 = var11.length;
            var78 = 0;
            break;
         }

         var13 = var78;

         int var111;
         do {
            int var107 = var12;
            int var106 = var13;
            if (var106 >= var107) {
               break;
            }

            String var114 = var11[var13];
            int var108 = var9;
            if (var108 == 0) {
               String var58 = var114;
               boolean var109 = var58.isEmpty();
               if (!var109) {
                  String var61 = var114;
                  LinkedHashMap var60 = var10;
                  boolean var110 = var60.containsKey(var61);
                  if (!var110) {
                     short var127 = 21876;
                     long var133 = 6827530043442093160L ^ var3;
                     Object[] var136 = new Object[]{null, null, var7};
                     var136[1] = 32;
                     var136[0] = var114;
                     Object[] var63 = var136;
                     String var121 = aReturningString(var63);
                     var127 = 15633;
                     var133 = 4132360559701186332L ^ var3;
                     throw new IllegalArgumentException("missing option '" + var121 + "'");
                  }
               }

               var13++;
            }

            var111 = var9;
         } while (var111 == 0);

         return var10;
      }

      short var120 = 20667;
      long var126 = 7448306329737837241L ^ var3;
      throw new IllegalArgumentException("expected option.true or option.false");
   }

   private static int aReturningInt(Object[] var0) {
      String var3 = (String)var0[0];
      String var4 = (String)var0[1];
      long var1 = (Long)var0[2];
      var1 = 64484543068669L ^ var1;

      try {
         String var6 = var3;
         String var7 = var6.trim();
         return Integer.parseInt(var7);
      } catch (NumberFormatException var10) {
         short var10003 = 32508;
         long var10004 = 6230598680999912167L ^ var1;
         throw new IllegalArgumentException("expected " + var4, var10);
      }
   }

   private static int bReturningInt(Object[] var0) {
      String var3;
      long var21;
      label24: {
         String var4 = (String)var0[0];
         var3 = (String)var0[1];
         long var1 = (Long)var0[2];
         var21 = 64484543068669L ^ var1;
         long var5 = var21 ^ 71345405040443L;
         int var10000 = Event.cReturningInt();
         short var10003 = 16919;
         long var10004 = 5138235886305390815L ^ var21;
         Object[] var9 = new Object[]{var4, var3 + " channel", var5};
         int var8 = aReturningInt(var9);
         int var7 = var10000;
         int var15 = var7;
         int var14 = var8;
         int var11 = var14;
         int var10 = var14;
         if (var15 != 0) {
            int var16 = var10;
            if (var16 < 0) {
               break label24;
            }

            var11 = var8;
         }

         int var18 = var7;
         int var17 = var11;
         int var13 = var17;
         int var12 = var17;
         if (var18 != 0) {
            short var10001 = 3138;
            long var10002 = 6221211862738148754L ^ var21;
            short var20 = 255;
            int var19 = var12;
            if (var19 > var20) {
               break label24;
            }

            var13 = var8;
         }

         return var13;
      }

      short var22 = 9672;
      long var23 = 8136905528126068488L ^ var21;
      throw new IllegalArgumentException(var3 + " channel must be between 0 and 255");
   }

   private static String aReturningString(Object[] var0) {
      String var1 = (String)var0[0];
      int var4 = (Integer)var0[1];
      long var2 = (Long)var0[2];
      var2 = 64484543068669L ^ var2;
      int var5 = Event.bReturningInt();
      int var15 = var5;
      String var14 = var1;
      String var13 = var14;
      String var12 = var14;
      if (var15 == 0) {
         String var6 = var12;
         int var10000 = var6.length();
         int var17 = var4;
         int var16 = var10000;
         if (var16 <= var17) {
            return var1;
         }

         short var10001 = 0;
         int var11 = var4 - 3;
         String var9 = var1;
         String var19 = var9.substring(0, var11);
         var10001 = 15400;
         long var10002 = 5446738950757799621L ^ var2;
         var13 = var19 + "...";
      }

      return var13;
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(51604619649896L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[33];
      String var17 = "\u0098z\t\u0016à;?Ájªü§ DuóÏÎ\u0081;\u0086ÆùÃ\u0018-è\\½Ø\u0007î\u0017Ûµµ!ocx\u0012=¾\u009f\u0016àRm\"8íÕ!\u0013\u000fÁèü»\u0097\u0014\u0082\u0013®Hú\u0087\u001b`\u009f-·ER\u001fpæÃ6ç\u0099õ\u009a¥]ë]Â°ªùkÌç\u0017àÒ \u001c\u0099¶<©ø:\u0083@þ\u0019\u001eö3vR8)Ø@OFIxr\u001d6Æ5\u0098M\u001e\u0011±\u0092+\u0003>\u007fíÇÇ&J/NN6¶ù\u0005«ÍÈÙ÷Õ&\bÜ\u0006\u0012\u008dÒI/Í\u00018Ü+]\u009d@Æû\u0097Ó\u0097]ê·t\u009aGúÊë8l.is`<Å\u0087\u0016¹ì¥\u001d\u0010\u0005Ó\u001d:\u0013op\u0004Y}H|Þ\u000b\u0098\u001bw\u008a\u0081\rù²\u0010õq\u008fÕ\u001d!W\u0013\u0094\\W\u009e\u0010Ö£)¸©\u0092ë\u0012\u0001fJ£\u0010Þô3\u0010\u0002S2¡:]$PÉ½P§|\u001f\u0086ß(¨\u001f¡|\u009bu\u0018cö»´«\u000b>Ù\u0010X\u0093VðhÁ\u007f÷£î\u0011\u0089GN$g«X#Qòó½_\u0010kQyÅ nÅ[Ø\u001f\u000f¿¿÷\u009e9@È\u0087\u0081\u0084q\u0089Ä!\u0010\u0084´G\u0000Ì¥1\u0002\u009f\u009bí\u0091i!s\u009e\u0018P\u001d)ñ\u0004\u008a*\u00817ãÝR\u0083YbG±ßò±Á¥Kö\u0099hù¦I°\u009c\u00ad\u0002ÓÈ!]|\u0010¼Q\u0017£÷ä\u008a\u0083í¿k÷öî\u001eN(\u008c:µ±¦\u0000Äß\u001f\u0000\u001cÂò\u007f\n\u0093sU\u000bõ[\u0083ç¯¡^A\u0095\u009dÍ¸ßäP#B\u0002Ã\u001cî\u0010sÞÔzÄ\u0001\u0083ý\u0005ÝþªØU\u0019ì(\u001a\u0015\f¬§\u0081èÏ \u0010\u0017\u001dEF\\Ü\u0015M«ú¹Ö]\u009d³¸\u0083\u0086qÄdâ\u001c\u001aé\u008b±Q\u0086x(6\u0088\u008c\u000e\u001d&4¹l&\u0085ä\u001fJ]CoÜ\u008e\u0003ZØûàÎò\u0012Ê\b¢ñjì\u000f\u008f¦º\u0080\u0000§\u0010Ü!j,]¿r¿s$Î²É\f\u001cÁ(V\u001eà\u00967½\u001b¥µ\u000bó°¦ðÁ~á\f/©Gê\u0001\u0089ç\u0088\u008bÅ]?*\u008a,ÃEaúø\u0000\u0096\u0010åpD\\Î\u009e³¼\u008e¨Ð\u009f\u001f\u0011\u008700åLÃüÖ¨\u0092}\u009d£Ó\u0097£\u0005\u0090ý\u001cF¸}k3r\u001c\u0018Ud\u001c\"\n×!e &OUOI\u0099»¡ks\u007fÜOÐ\u0010,(\u00902á{J=âJïØ\u008ee®i Àw£\"£¬¬Øþ\u0004¡»\\¿CMJF¬\u0013 «\u001dÁv@óåBi{í(Ôk\u0000bº+nÏûÚE$0\u0082\u0091ªÙ\u0098¹XÐa¯k{O~±\u0095èÞc+7\u009ej\u0094\u0007\u0096¦\u0018É\u0085fj²ÚäF0I®·!Ì³F\u0000âõï\\\u0094ÙÃ8bÐýÑXÓo)\u0093]\u0013léÊÏñ_¦Ûó\f\u0000Ûú\u0083÷\u0014)+&Bn`\u0083ésÙ\u0001\u008c¯¯\u000e\u0089¢Ê©Y9\"\u0099Uu\u009f\u0084kÊ8L5\u009fM\u0013h\u001cÀÒ\u0081f\"M\u008eZÕb5\u0014±@Äð.\u0019b\u0092[\u0098GM×\u00870\u0089ý\u008dVå\u0004½(\u000f\u0018G\u0088\u000e\u000bsWwûý;\u0004\u001d(\u0084\u0090\r§ëS¾1Àe\u0018ùüèý;«ðÚTHó#÷\u000f\u008aZ\u009dó\u00969Uüßk\u0014ú%ªE8õ\u008bìÔ\u0098\fhYnR\u0011Ðå\u0003UÖQX\u0013ºh\f¯¼.ºü&ÿÌ'Ö¬¤ñÞtÌ©\u009fñäYí:æ\u0086\u0088³4vs\u001a1!1\u0010Å|×+Esæùö\u001em_|[\u0080o\u0010Þ\u0015\u001cõÁöz·\u0001_T½´À\u008c\"\u00105\u009d¢\u00843g\u009a\u001eÅx*\u001eqP¢ü\u0010\b)\u0012ÿn\u0083ã\u001bEÅY*Ãµ\f*";
      int var19 = "\u0098z\t\u0016à;?Ájªü§ DuóÏÎ\u0081;\u0086ÆùÃ\u0018-è\\½Ø\u0007î\u0017Ûµµ!ocx\u0012=¾\u009f\u0016àRm\"8íÕ!\u0013\u000fÁèü»\u0097\u0014\u0082\u0013®Hú\u0087\u001b`\u009f-·ER\u001fpæÃ6ç\u0099õ\u009a¥]ë]Â°ªùkÌç\u0017àÒ \u001c\u0099¶<©ø:\u0083@þ\u0019\u001eö3vR8)Ø@OFIxr\u001d6Æ5\u0098M\u001e\u0011±\u0092+\u0003>\u007fíÇÇ&J/NN6¶ù\u0005«ÍÈÙ÷Õ&\bÜ\u0006\u0012\u008dÒI/Í\u00018Ü+]\u009d@Æû\u0097Ó\u0097]ê·t\u009aGúÊë8l.is`<Å\u0087\u0016¹ì¥\u001d\u0010\u0005Ó\u001d:\u0013op\u0004Y}H|Þ\u000b\u0098\u001bw\u008a\u0081\rù²\u0010õq\u008fÕ\u001d!W\u0013\u0094\\W\u009e\u0010Ö£)¸©\u0092ë\u0012\u0001fJ£\u0010Þô3\u0010\u0002S2¡:]$PÉ½P§|\u001f\u0086ß(¨\u001f¡|\u009bu\u0018cö»´«\u000b>Ù\u0010X\u0093VðhÁ\u007f÷£î\u0011\u0089GN$g«X#Qòó½_\u0010kQyÅ nÅ[Ø\u001f\u000f¿¿÷\u009e9@È\u0087\u0081\u0084q\u0089Ä!\u0010\u0084´G\u0000Ì¥1\u0002\u009f\u009bí\u0091i!s\u009e\u0018P\u001d)ñ\u0004\u008a*\u00817ãÝR\u0083YbG±ßò±Á¥Kö\u0099hù¦I°\u009c\u00ad\u0002ÓÈ!]|\u0010¼Q\u0017£÷ä\u008a\u0083í¿k÷öî\u001eN(\u008c:µ±¦\u0000Äß\u001f\u0000\u001cÂò\u007f\n\u0093sU\u000bõ[\u0083ç¯¡^A\u0095\u009dÍ¸ßäP#B\u0002Ã\u001cî\u0010sÞÔzÄ\u0001\u0083ý\u0005ÝþªØU\u0019ì(\u001a\u0015\f¬§\u0081èÏ \u0010\u0017\u001dEF\\Ü\u0015M«ú¹Ö]\u009d³¸\u0083\u0086qÄdâ\u001c\u001aé\u008b±Q\u0086x(6\u0088\u008c\u000e\u001d&4¹l&\u0085ä\u001fJ]CoÜ\u008e\u0003ZØûàÎò\u0012Ê\b¢ñjì\u000f\u008f¦º\u0080\u0000§\u0010Ü!j,]¿r¿s$Î²É\f\u001cÁ(V\u001eà\u00967½\u001b¥µ\u000bó°¦ðÁ~á\f/©Gê\u0001\u0089ç\u0088\u008bÅ]?*\u008a,ÃEaúø\u0000\u0096\u0010åpD\\Î\u009e³¼\u008e¨Ð\u009f\u001f\u0011\u008700åLÃüÖ¨\u0092}\u009d£Ó\u0097£\u0005\u0090ý\u001cF¸}k3r\u001c\u0018Ud\u001c\"\n×!e &OUOI\u0099»¡ks\u007fÜOÐ\u0010,(\u00902á{J=âJïØ\u008ee®i Àw£\"£¬¬Øþ\u0004¡»\\¿CMJF¬\u0013 «\u001dÁv@óåBi{í(Ôk\u0000bº+nÏûÚE$0\u0082\u0091ªÙ\u0098¹XÐa¯k{O~±\u0095èÞc+7\u009ej\u0094\u0007\u0096¦\u0018É\u0085fj²ÚäF0I®·!Ì³F\u0000âõï\\\u0094ÙÃ8bÐýÑXÓo)\u0093]\u0013léÊÏñ_¦Ûó\f\u0000Ûú\u0083÷\u0014)+&Bn`\u0083ésÙ\u0001\u008c¯¯\u000e\u0089¢Ê©Y9\"\u0099Uu\u009f\u0084kÊ8L5\u009fM\u0013h\u001cÀÒ\u0081f\"M\u008eZÕb5\u0014±@Äð.\u0019b\u0092[\u0098GM×\u00870\u0089ý\u008dVå\u0004½(\u000f\u0018G\u0088\u000e\u000bsWwûý;\u0004\u001d(\u0084\u0090\r§ëS¾1Àe\u0018ùüèý;«ðÚTHó#÷\u000f\u008aZ\u009dó\u00969Uüßk\u0014ú%ªE8õ\u008bìÔ\u0098\fhYnR\u0011Ðå\u0003UÖQX\u0013ºh\f¯¼.ºü&ÿÌ'Ö¬¤ñÞtÌ©\u009fñäYí:æ\u0086\u0088³4vs\u001a1!1\u0010Å|×+Esæùö\u001em_|[\u0080o\u0010Þ\u0015\u001cõÁöz·\u0001_T½´À\u008c\"\u00105\u009d¢\u00843g\u009a\u001eÅx*\u001eqP¢ü\u0010\b)\u0012ÿn\u0083ã\u001bEÅY*Ãµ\f*"
         .length();
      char var16 = 24;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = a(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     b = var20;
                     c = new String[33];
                     g = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(51604619649896L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[7];
                     String var4 = "Ù8\u0016¹z©$\u000eý1+\u001do\u0091\u0019û\n\u0016\t\r\u0087\u0089(°<¦n(µð8r\u001bî\u0088\u001cáÛ\u0006S";
                     int var5 = "Ù8\u0016¹z©$\u000eý1+\u001do\u0091\u0019û\n\u0016\t\r\u0087\u0089(°<¦n(µð8r\u001bî\u0088\u001cáÛ\u0006S".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    e = var6;
                                    f = new Integer[7];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0001\u009bÏqúÜHòÖQñ#$FÓc";
                                 var5 = "\u0001\u009bÏqúÜHòÖQñ#$FÓc".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "Ìï*\u0091ôªÕ\rñ\u0003V¼_\u0083ËÆÉ£ÿ3ÐÏ}3w²\u0083\u001a l¯\u008cF\u0010±\n\u0099\u0096íÓ V·ß\u0014\u0085\u0086ì\f\u00ad'YËÊ´\u0012L£ÉWsì|à¯k¹\u0005\u0017ÎÃo\u009c";
                  var19 = "Ìï*\u0091ôªÕ\rñ\u0003V¼_\u0083ËÆÉ£ÿ3ÐÏ}3w²\u0083\u001a l¯\u008cF\u0010±\n\u0099\u0096íÓ V·ß\u0014\u0085\u0086ì\f\u00ad'YËÊ´\u0012L£ÉWsì|à¯k¹\u0005\u0017ÎÃo\u009c"
                     .length();
                  var16 = '(';
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 4680;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])d.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               d.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/f6", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f6",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29011;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])g.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/f6", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f6",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 56;
            yield var15;
         }
         case 1 -> {
            byte var16 = 31;
            yield var16;
         }
         case 2 -> {
            byte var17 = 16;
            yield var17;
         }
         case 3 -> {
            byte var18 = 29;
            yield var18;
         }
         case 4 -> {
            byte var19 = 9;
            yield var19;
         }
         case 5 -> {
            byte var20 = 48;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 57;
            yield var22;
         }
         case 8 -> {
            byte var23 = 0;
            yield var23;
         }
         case 9 -> {
            byte var24 = 41;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 60;
            yield var26;
         }
         case 12 -> {
            byte var27 = 28;
            yield var27;
         }
         case 13 -> {
            byte var28 = 36;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 37;
            yield var30;
         }
         case 16 -> {
            byte var31 = 42;
            yield var31;
         }
         case 17 -> {
            byte var32 = 47;
            yield var32;
         }
         case 18 -> {
            byte var33 = 4;
            yield var33;
         }
         case 19 -> {
            byte var34 = 18;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 52;
            yield var36;
         }
         case 22 -> {
            byte var37 = 43;
            yield var37;
         }
         case 23 -> {
            byte var38 = 49;
            yield var38;
         }
         case 24 -> {
            byte var39 = 46;
            yield var39;
         }
         case 25 -> {
            byte var40 = 12;
            yield var40;
         }
         case 26 -> {
            byte var41 = 55;
            yield var41;
         }
         case 27 -> {
            byte var42 = 30;
            yield var42;
         }
         case 28 -> {
            byte var43 = 61;
            yield var43;
         }
         case 29 -> {
            byte var44 = 21;
            yield var44;
         }
         case 30 -> {
            byte var45 = 17;
            yield var45;
         }
         case 31 -> {
            byte var46 = 32;
            yield var46;
         }
         case 32 -> {
            byte var47 = 19;
            yield var47;
         }
         case 33 -> {
            byte var48 = 2;
            yield var48;
         }
         case 34 -> {
            byte var49 = 7;
            yield var49;
         }
         case 35 -> {
            byte var50 = 38;
            yield var50;
         }
         case 36 -> {
            byte var51 = 22;
            yield var51;
         }
         case 37 -> {
            byte var52 = 1;
            yield var52;
         }
         case 38 -> {
            byte var53 = 33;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 40;
            yield var56;
         }
         case 42 -> {
            byte var57 = 44;
            yield var57;
         }
         case 43 -> {
            byte var58 = 63;
            yield var58;
         }
         case 44 -> {
            byte var59 = 8;
            yield var59;
         }
         case 45 -> {
            byte var60 = 23;
            yield var60;
         }
         case 46 -> {
            byte var61 = 51;
            yield var61;
         }
         case 47 -> {
            byte var62 = 20;
            yield var62;
         }
         case 48 -> {
            byte var63 = 11;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 24;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 13;
            yield var67;
         }
         case 53 -> {
            byte var68 = 62;
            yield var68;
         }
         case 54 -> {
            byte var69 = 50;
            yield var69;
         }
         case 55 -> {
            byte var70 = 35;
            yield var70;
         }
         case 56 -> {
            byte var71 = 27;
            yield var71;
         }
         case 57 -> {
            byte var72 = 10;
            yield var72;
         }
         case 58 -> {
            byte var73 = 45;
            yield var73;
         }
         case 59 -> {
            byte var74 = 53;
            yield var74;
         }
         case 60 -> {
            byte var75 = 3;
            yield var75;
         }
         case 61 -> {
            byte var76 = 58;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 14;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "\u0013`\u00134(9\u0018o\u0002{U!\u000bh\u000b2";
      h[1] = "eB!bhJnM0-\u000fH{F0f4";
      h[2] = int.class;
      i[2] = "java/lang/Integer";
      h[3] = "6b\f>@\u0007 b\tdS\u00107)\nb_\u0004&n\u001du\u0014\u0016\u0017";
      h[4] = boolean.class;
      i[4] = "java/lang/Boolean";
      h[5] = "N\u001fP$YOX\u001fU~JXOTVxFL^\u0013Ao\rY\u001c";
      h[6] = "IU/?\u0015\u0003BZ>pr\u0003OQ>?W.QS,3^\u0001Wq!=^\u001fW]60";
      h[7] = "\u0015\u000f^PD%\u001e\u0000O\u001f%+\u0015\u000bKE";
      h[8] = "\b\ffv\u001f7\u0003\u0003w9s4\r\u0001uv_";
      h[9] = "xCB?3\u001cfKXpP\bb\u0006q0i\u001bk";
      h[10] = "VZZ\u001a1e@Z_@\"rW\u0011\\F.fFVKQeq~";
      h[11] = "\u0010\u001f\u0001\u00002'e?\n\u000f#h\u00041\u0001\u0004'2p";
      h[12] = void.class;
      i[12] = "java/lang/Void";
      h[13] = "M\b\u0012:\u0005DF\u0007\u0003uhDF\u001a\u0017";
      h[14] = "\u0015J_\u0002c\u0005\u000bBEM\u0004\u0004\u001aYH\u0017\"\u0002";
      h[15] = "HqWo_Y=Q\\`N\u0016\\_WkJL(";
      h[16] = "\"m&\n\u001c=<e<E\u007f)8";
      h[17] = "\u0002'[+:0w\u0007P$+\u007f\u0016\t[//%b";
      h[18] = float.class;
      i[18] = "java/lang/Float";
      h[19] = "zIL%m1\u000fiG*|~ngL!x$\u001a";
      h[20] = "f\u001576[\u001ep\u00152lH\tg^1jD\u001dv\u0019&}\u000f\nI";
      h[21] = "(6bO@\u0010]\u0016i@Q_<\u0018bKU\u0005H";
      h[22] = "\r\u0003ilp\u0001\u0013\u000bs#\r\u0011\u0013";
      h[23] = "\u0011C=Y$\u0006\u0007C8\u00037\u0011\u0010\b;\u0005;\u0005\u0001O,\u0012p\u00122";
      h[24] = "sN\u0011w\t\u000fxA\u00008j\u0002mG";
      h[25] = "#b\u001f\u0014QqVB\u0014\u001b@>7L\u001f\u0010DdC";
      h[26] = "ILdoZ6WD~ ;!IHqz\u0007";
      h[27] = "(ze\u0016\u007fb>z`Llu)1cJ`a8vt]+v\u0001";
      h[28] = "p\\\u0011A.F\u0005|\u001aN?\txd\tI6@\u0010";
      h[29] = "t,\"f\f&j$8)Q'l(5j\f\u0000j?1fO";
      h[30] = "\u001fm\n]+o\u0001e\u0010\u0012co\u001bo\bUjt[\\\u000eYas\u0016m\bY";
      h[31] = "S bX0g&\u0000iW!(G\u000eb\\%r3";
      h[32] = "\u0000\u0019\u0017cs\u0002\u000b\u0016\u0006,\u001b\u0002\u0005\u0019\u0015";
      h[33] = "3\u001e9V\u00031%\u001e<\f\u0010&2U?\n\u001c2#\u0012(\u001dW%\u001d";
      h[34] = "5F\u0006:II@f\r5X\u0006!h\u0006>\\\\U";
      h[35] = "\rf\u0006\nN%\u001bf\u0003P]2\f-\u0000VQ&\u001dj\u0017A\u001a1/";
      h[36] = long.class;
      i[36] = "java/lang/Long";
      h[37] = "|FH5I\tjFMoZ\u001e}\rNiV\nlJY~\u001d\u001dV";
      h[38] = "%\u001bW%\u001fV;\u0013MjpQ=\u001bX7";
      h[39] = "\u000f\u000e\u007fH\tDz.tG\u0018\u000b\u001b \u007fL\u001cQo";
      h[40] = "\u0011UU1Ppdu^>A?\u0019mM9Hvq";
      h[41] = "\t\u00024\"\u001f\u001c|\"?-\u000eS\u0001:,*\u0007\u001ai";
      h[42] = "\u000b\u0018dYAdVC>B'dX\u0005CTV\u000b\b\u0010yTVw\t\u0017mT'";
      h[43] = "\bN\u0017\u0014V~V\u0015\u0004\t(-7_\u001dAM6[LM\fFF\u0007Z\t\tW+IB\u0005\u0011(";
      h[44] = "\u0017g\u0004Y\u0011^\u000em\u0000\u001fiToz\u001c\u001bPE\u0006`D\u0006\u0019=";
      h[45] = "K\u001bwXY6K\u0005/#\u0002'@\u001b6Cfs]\u001e;GW.\u0016\b.#";
      h[46] = "u\u000eUI*L|\rUW[TqA\u0015)f[e\\\u0018Ug\\q\\i";
      h[47] = "Y^\u0005\u0017RCY@]l\u0016B^JD\u0016\fY[1\u0001\u0017\u0007NP\u0000\\\\\u0011[4\\WQ\u0016\u0000H\\I\tm";
      h[48] = "\r\\\u000fM\"^\rBW6|Y-VJJl\"[^IW$_\fTK]\u001d";
      h[49] = "==\u000bp\\)=#S\u000b\u001f/176f\fh+mJf\u00120P";
      h[50] = "f\u0007X\u001bcq:\u0005]S\u001be]\u0007\nY~|1\u0014Z\u0014u\f0\u0012^\u0012$p0\f\u0006i";
      h[51] = "SMPXO\b\r\u0016CE1\\lMMMCRV\\\r^J0";
      h[52] = "\u0011\u00115\u0013\u000bm\u0000S6O7tp\u0011;U\u000ee\u0019\u000bcHG\u001d";
      h[53] = "U\n\u0017<&N@\f\u00020\u001eUG\u0007\u0011%bSAj\u0002s\"TJ\u0014\u000bp\"J;";
      h[54] = "6\u001e7\u001a!\u0003hE$\u0007_V\t\u000f=O:Ke\u001cm\u00021;b\u000b$\r=\u0001sK7\u0004_";
      h[55] = "\u0011\u0016B#vz\u0004\u0002C~La\u000f5Iu-|\u0019{Cm<r\u0016AR-/{t@Eh-9\t\u0017Oj'\u0000";
      h[56] = "S\u0017l\u0003\t?Z\u0010nUm+>\u0010v\u0000\u001c&\u000fM=\u0016\tB";
      h[57] = "0rTc>Pn)G~@\u0002\u000frIv2\n5c\te;h?fJ~?\u0005q~Ff@";
      h[58] = "G*d)r#R>etH'K#st\u000f7\",pi:;\u0018=0z3YG*d)r#R>etH";
      h[59] = ";Of:i,e\u0014u'\u0017}\u0004O{/ev>^;<l\u00144[x'hyzCt?\u0017";
      h[60] = " \u000e2jxE*\u00169bAQF\f ~3Z|\u001d`m:8";
      h[61] = "\t)wx5+\u0013~qnI \f?#n,[\n,~b97\u0019|3iI8\u0014tpz3jO..\u0007";
      h[62] = "\\\u0004\\L\u0014\u000f\\\u001a\u00047P\u000bU\n\u001d7F\u001c\f\u0010^KF\u0002TkXLA\u0002UZ\u0005\u0007W\u00171\u0010\u0000I\u0012\u000bX\nXT[s";
      h[63] = "L2H\n\u001a\f\u0013;\u0003\n\u007fVvb\u0003\\\u000eXG?HJ\u001b<";
      h[64] = "7\u0012\"fFe1\u00129m#tc\u000b$odd\nT4yB3w\u0003>{H\n7\u0012\"fFe1\u00129m#";
      h[65] = "~IY:S]xIB16X$SF3_T\u001d]F#[2xYY?\u000fO/S[56";
      h[66] = "\u0002\u0000DBO3]\t\u000fB*h8P\u000f\u0014[g\t\rD\u0002N\u0003";
      h[67] = "Y$4?%\n\t.09X\u000f\u00051\n2=\u0018\f \u0017:=\rh >n#_\u0014  6X";
      h[68] = "\u001b[\u007f`HZ\u0001\u0005;v%[\u0016_}gDV\nzl\u007f%\r\u0018@l\u007fY\f\u001fTl\u000e\u001e]\nX8sIW\bR\u0001";
      h[69] = "\u001fN\u000e8nlCL\u000bp\u0016x$N\\zsaH]\f7x\u0011NVK${{T\b\u000f2\u0016";
      h[70] = "Ri=J/)\u000ek8\u0002W=iio\b2$\u0005z?E9T\u0002mvJ5n\u0013-eCW";
      h[71] = "h\\~oKGa_~q:Yh\u0018\u0004bJE\u0001X/t[\u0000|\u000f%vQ9";
      h[72] = "87{dQKd5~,)_\u00037)&LFo$ykG68 ;w\u0010Ko*9})";
      h[73] = "3OGf\u0005Y:HE0aH^H]e\u0010@o\u0015\u0016s\u0005$";
      h[74] = "\u0006Y1QRvZ[4\u0019*b=Yc\u0013O{QJ3^D\u000b\u0004X`RN:Y\u0013vG*";
      h[75] = "\f,z9g\u0011\f2\"B<\u0004\u001a?\u0006$4\u0000\u0011\u0004)Ba\u0016\u000b2#s<]\u001d'G{#\u0007\u0010'v&h\u0011\u0005C";
      h[76] = "\u0017\u000bkr\u0006-\rU/dk*\u001b\u0015om0*\u0001i{|\u00177E\u0013nz\u0002;}";
      h[77] = "\u0000\rA\nw\u007f\tX@\u0002\t;PXZ\u0005N+9\u0005\\\u0002x!\bX\u0017\u0014mE\u0000\rA\nw\u007f\tX@\u0002\t";
      h[78] = "A\u001d\u0006*\u0005QO\u0018Z9>D.O\u00072_\u0014S\u0018\r0U-\u001e\u000b\u00171A@P\u0013\u001b)>";
      h[79] = "-\u0007(5'\u000e}\u0011'e\u001a\u0001&\u001f.-\u001a\u0001<\u000697 \u0010|\u00150Uq\u00142\u0004)o`T!\rK>d\u001a0\u0014q/$\t9v +j\u0018 L1ky\u0011B";
      h[80] = "ko\u000eXx\u001bplSP\u0015\u001bgr\u0012Xo\fLl\t\u007fh\u0005n\u000bRPl\f{wSWx\f\n6\u0006@x\u0010v7\u0001Txa";
      h[81] = "/8Y\u00034W/&\u0001xfR?>\u0000\u0003JD$0\u001e\u0015@B9:d\u0015d\u00169h\u0018\u0015zNBl\t\u0003j\u0012?;\u0003\u0001`+";
      h[82] = "#\u0015Qw/V\u007f\u0017T?WB\u0018S\u0001a4Er\u000b[8n+$\u0004\u000ef9A|^W<W";
      h[83] = "\u0018$5\u007f\u001do\r04\"'m\u00143$\"iq\u001a #OJz@2`3Jd\u0018I41Wg\u001fs%qDn}";
      h[84] = "J.wkz\u000b\u0018u-5\u0007\u0017N,+\u0010n\rB*F1j\u0014M:&29\u0012UJ}8|\u0010\u00107*2~\u001a)";
      h[85] = "N\u0019bLZ%O\u001evL+%\u0014+g[J?\u001cpvN\u0016\"L\fvPNY";
      h[86] = ">N\u001d8\u0013\u001d7\u001b\u001c0m_n\u0005\u00007,A{\u007f\u00165P\\8\u0003\u0016+\b'>\u0004\u0011+\t\u0016cO\u0007>m";
      h[87] = "\u0002\u00048\u0000i\u0005\b\u001c3\bP\u0012d\u0006*\u0014\"\u001a^\u0017j\u0007+x";
      h[88] = "\fDz\u0014\u0002Y^\u001f J\u007fJ\tQ\u000eC\u0003H\u000f /G\u001aG\u001f@,\u0014\u001c_o\u001b&Q\u001e\u001a\u0012L,S\u0014#";
      h[89] = "\"M,j\u001fi|\u0016?wa:\u001dM1\u007f\u00133'\\ql\u001aQ";
      h[90] = "\f\u007fnqe~P}k9\u001di7\u007f<3xs[ll~s\u0003\u000e~?ry2S5)g\u001d";
      h[91] = "CGV\u001b66\u001e\u001c\f\u0000P6\u0010Zl\u00124$\u0010&\u000f\u0012)4\fZ\u000e\u0015=4}";
      h[92] = "\u001a63m$\u0005\u0000'7oI\u0015}`gn$\r\u0001a`z$|M\"so6\u0011\u0003:\u007fwI";
      h[93] = "}IfW\u000e,-_i\u00073#vQ`O30|SaT_xo\u0007\u007f7\n3xIa\u0006Wxn\\\u0005\u000eH\"c\\4S\u00034v8<LY9v\ta\u0007O,\u0012";
      h[94] = "j\u001dv\u001f|\u001es\u0017rY\u0004\u0014\u0012\u0016`\u001e\u007fBn\u0016~F\u0004F\u007f\u0000n\u001ay\u0011u\u0002d#4\u0002o\u0003pNz\u001ac\u001b\u000f";
      h[95] = "NzU\u0017\u0001\u0004Nd\rlE\u0005In\u0014\u0016_\u001eL\u0015Q\u0017T\tG$\f\\B\u001c#,\u0013\u0006O\u001c\u0012qX\u0010ZxNzU\u0017\u0001\u0004Nd\rl";
      h[96] = "(Kq0\u0002\u00172\u00155&o\u0005?U\u000fc\u0006\u0004/Xsb\u0001\u0010/)27\u0016\u00103U30\u0002\u0010B\u0014f'\u0002\f>\u0015a3\u0002}";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(538080930401270L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(538080930401270L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(538080930401270L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 163;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 67;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 84;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 199;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 86;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 36;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 163;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 67;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 84;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f6",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(String var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ljava/lang/String;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "java/lang/String", "equals", "(Ljava/lang/Object;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((String)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(String var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ljava/lang/String;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "java/lang/String", "equals", "(Ljava/lang/Object;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((String)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
