package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class BlockUtil implements MinecraftAccess {
   private static final MinecraftClient b = MinecraftClient.getInstance();
   private static final long a = 126927211874952L;
   private static final Object[] c = new Object[92];
   private static final String[] d = new String[92];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;

   public static boolean aReturningBoolean(Object[] var0) {
      Entity var3 = (Entity)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 126927211874952L ^ var1;
      MinecraftClient var15 = b;
      ClientPlayerEntity var16 = var15.player;
      Vec3d var5 = var16.getEyePos();
      int var61 = Event.cReturningInt();
      Entity var17 = var3;
      Vec3d var6 = var17.getEyePos();
      int var4 = var61;
      Entity var18 = var3;
      Box var7 = var18.getBoundingBox();
      Vec3d var20 = var5;
      Vec3d var19 = var6;
      Vec3d var21 = var19.subtract(var20);
      Vec3d var8 = var21.normalize();
      Vec3d var23 = var6;
      Vec3d var22 = var5;
      double var9 = var22.distanceTo(var23);
      int var60;
      do {
         double var64;
         int var50 = (var64 = var11 - var9) == 0.0 ? 0 : (var64 < 0.0 ? -1 : 1);
         if (var50 >= 0) {
            break;
         }

         Vec3d var13;
         label48: {
            double var25 = var11;
            Vec3d var24 = var8;
            Vec3d var28 = var24.multiply(var25);
            Vec3d var27 = var5;
            var13 = var27.add(var28);
            int var52 = var4;
            Box var51 = var7;
            Box var47 = var51;
            Box var46 = var51;
            if (var52 != 0) {
               Box var53 = var46;
               if (var53 == null) {
                  break label48;
               }

               var47 = var7;
            }

            Vec3d var31 = var13;
            Box var30 = var47;
            boolean var62 = var30.contains(var31);
            int var55 = var4;
            boolean var54 = var62;
            boolean var49 = var54;
            boolean var48 = var54;
            if (var55 == 0) {
               return var49;
            }

            boolean var56 = var48;
            if (var56) {
               return false;
            }
         }

         Vec3d var33 = var13;
         Vec3d var34 = var13;
         Vec3d var35 = var13;
         double var40 = var35.z;
         double var38 = var34.y;
         double var36 = var33.x;
         BlockPos var14 = BlockPos.ofFloored(var36, var38, var40);
         int var57 = var4;
         if (var57 != 0) {
            MinecraftClient var42 = b;
            BlockPos var44 = var14;
            ClientWorld var43 = var42.world;
            BlockState var45 = var43.getBlockState(var44);
            Block var63 = var45.getBlock();
            Block var59 = Blocks.COBWEB;
            Block var58 = var63;
            if (var58 == var59) {
               return true;
            }

            var11 += 0.1;
         }

         var60 = var4;
      } while (var60 != 0);

      return false;
   }

   public static BlockPos aReturningBlockPos(Object[] var0) {
      BlockHitResult var3 = (BlockHitResult)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 126927211874952L ^ var1;
      BlockHitResult var4 = var3;
      BlockPos var15 = var4.getBlockPos();
      BlockHitResult var5 = var3;
      Direction var6 = var5.getSide();
      int var10001 = var6.getOffsetX();
      BlockHitResult var7 = var3;
      Direction var8 = var7.getSide();
      int var10002 = var8.getOffsetY();
      BlockHitResult var9 = var3;
      Direction var10 = var9.getSide();
      int var14 = var10.getOffsetZ();
      int var13 = var10002;
      int var12 = var10001;
      BlockPos var11 = var15;
      return var11.add(var12, var13, var14);
   }

   public static boolean bReturningBoolean(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      Block var2 = (Block)var0[1];
      long var3 = (Long)var0[2];
      var3 = 126927211874952L ^ var3;
      long var5 = var3 ^ 36292471594652L;
      Object[] var7 = new Object[]{var1, var5};
      BlockState var10000 = aReturningBlockState(var7);
      Block var9 = var2;
      BlockState var8 = var10000;
      return var8.isOf(var9);
   }

   public static boolean cReturningBoolean(Object[] var0) {
      HitResult var3 = (HitResult)var0[0];
      long var1 = (Long)var0[1];
      var1 = 126927211874952L ^ var1;
      long var4 = var1 ^ 26458298228159L;
      BlockHitResult var6 = (BlockHitResult)var3;
      Object[] var7 = new Object[]{var6.getBlockPos(), var4};
      return eReturningBoolean(var7);
   }

   public static boolean dReturningBoolean(Object[] var0) {
      BlockHitResult var3 = (BlockHitResult)var0[0];
      long var1 = (Long)var0[1];
      var1 = 126927211874952L ^ var1;
      long var4 = var1 ^ 44681719308835L;
      BlockHitResult var6 = var3;
      Object[] var7 = new Object[]{var6.getBlockPos(), var4};
      return eReturningBoolean(var7);
   }

   public static boolean eReturningBoolean(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      long var2 = (Long)var0[1];
      var2 = 126927211874952L ^ var2;
      long var4 = var2 ^ 3666048913869L;
      int var6 = Event.cReturningInt();
      MinecraftClient var7 = b;
      BlockPos var9 = var1;
      ClientWorld var8 = var7.world;
      BlockState var10 = var8.getBlockState(var9);
      byte var10000 = ((byte)((var10.isReplaceable()) ? 1 : 0));
      int var52 = var6;
      byte var51 = var10000;
      int var49 = var51;
      byte var40 = var51;
      if (var52 != 0) {
         byte var53 = var40;
         if (var53 == 0) {
            return true;
         }

         MinecraftClient var12 = b;
         BlockPos var14 = var1;
         ClientWorld var13 = var12.world;
         BlockState var74 = var13.getBlockState(var14);
         Block var16 = Blocks.FIRE;
         BlockState var15 = var74;
         var10000 = ((byte)((var15.isOf(var16)) ? 1 : 0));
         int var55 = var6;
         byte var54 = var10000;
         var49 = var54;
         byte var41 = var54;
         if (var55 != 0) {
            byte var56 = var41;
            byte var42 = var56;
            byte var57 = var42;
            if (var57 != 0) {
               return true;
            }

            MinecraftClient var19 = b;
            BlockPos var21 = var1;
            ClientWorld var20 = var19.world;
            BlockState var76 = var20.getBlockState(var21);
            Object[] var22 = new Object[]{var4};
            Block var24 = aReturningBlock(var22);
            BlockState var23 = var76;
            var10000 = ((byte)((var23.isOf(var24)) ? 1 : 0));
            int var59 = var6;
            byte var58 = var10000;
            var49 = var58;
            byte var43 = var58;
            if (var59 != 0) {
               byte var60 = var43;
               byte var44 = var60;
               byte var61 = var44;
               if (var61 != 0) {
                  return true;
               }

               MinecraftClient var27 = b;
               BlockPos var29 = var1;
               ClientWorld var28 = var27.world;
               BlockState var78 = var28.getBlockState(var29);
               Block var31 = Blocks.SNOW;
               BlockState var30 = var78;
               var10000 = ((byte)((var30.isOf(var31)) ? 1 : 0));
               int var63 = var6;
               byte var62 = var10000;
               int var47 = var62;
               byte var45 = var62;
               if (var63 != 0) {
                  byte var64 = var45;
                  byte var46 = var64;
                  byte var65 = var46;
                  if (var65 == 0) {
                     return false;
                  }

                  MinecraftClient var34 = b;
                  BlockPos var36 = var1;
                  ClientWorld var35 = var34.world;
                  BlockState var80 = var35.getBlockState(var36);
                  IntProperty var38 = Properties.LAYERS;
                  BlockState var37 = var80;
                  Integer var39 = (Integer)var37.get((Property)var38);
                  int var66 = var39;
                  var47 = var66;
               }

               int var68 = var6;
               int var67 = var47;
               var49 = var67;
               int var48 = var67;
               if (var68 == 0) {
                  return dev.prestige.recovery.SourceSupport.asBoolean(var49);
               }

               byte var70 = 1;
               int var69 = var48;
               if (var69 == var70) {
                  return true;
               }

               return false;
            }
         }
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var49);
   }

   public static Block aReturningBlock(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 126927211874952L ^ var1;
      return Blocks.SHORT_GRASS;
   }

   public static boolean fReturningBoolean(Object[] var0) {
      BlockPos var1;
      long var6;
      int var8;
      byte var23;
      var1 = (BlockPos)var0[0];
      long var2 = (Long)var0[1];
      var2 = 126927211874952L ^ var2;
      long var4 = var2 ^ 28018318045124L;
      var6 = var2 ^ 132657865699000L;
      var8 = Event.bReturningInt();
      Object[] var9 = new Object[]{var1, Blocks.OBSIDIAN, var4};
      byte var10000 = ((byte)((bReturningBoolean(var9)) ? 1 : 0));
      int var30 = var8;
      byte var29 = var10000;
      var23 = var29;
      byte var20 = var29;
      label39:
      if (var30 == 0) {
         byte var31 = var20;
         if (var31 == 0) {
            Object[] var11 = new Object[]{var1, Blocks.BEDROCK, var4};
            var10000 = ((byte)((bReturningBoolean(var11)) ? 1 : 0));
            int var33 = var8;
            byte var32 = var10000;
            var23 = var32;
            byte var21 = var32;
            if (var33 != 0) {
               break label39;
            }

            byte var34 = var21;
            byte var22 = var34;
            byte var35 = var22;
            if (var35 == 0) {
               return false;
            }
         }

         BlockPos var14 = var1;
         Object[] var15 = new Object[]{var14.up(), Blocks.AIR, var4};
         byte var36 = ((byte)((bReturningBoolean(var15)) ? 1 : 0));
         var23 = var36;
      }

      int var38 = var8;
      byte var37 = var23;
      byte var25 = var37;
      byte var24 = var37;
      if (var38 == 0) {
         byte var39 = var24;
         if (var39 == 0) {
            return false;
         }

         BlockPos var18 = var1;
         Object[] var19 = new Object[]{var18.up(), var6};
         byte var40 = ((byte)((gReturningBoolean(var19)) ? 1 : 0));
         var25 = var40;
      }

      int var42 = var8;
      byte var41 = var25;
      byte var27 = var41;
      byte var26 = var41;
      if (var42 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var27);
      } else {
         byte var43 = var26;
         if (var43 == 0) {
            var27 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var27);
         } else {
            return false;
         }
      }
   }

   public static boolean gReturningBoolean(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 126927211874952L ^ var1;
      int var25 = Event.cReturningInt();
      BlockPos var6 = var3;
      double var10003 = var6.getX();
      BlockPos var7 = var3;
      double var10004 = var7.getY();
      BlockPos var8 = var3;
      double var10005 = var8.getZ();
      BlockPos var9 = var3;
      double var10006 = var9.getX() + 1.0;
      BlockPos var10 = var3;
      double var10007 = var10.getY() + 1.0;
      BlockPos var11 = var3;
      Box var5 = new Box(var10003, var10004, var10005, var10006, var10007, var11.getZ() + 1.0);
      int var4 = var25;
      MinecraftClient var12 = b;
      ClientWorld var26 = var12.world;
      Predicate var16 = invokeBinding1();
      Box var15 = var5;
      Object var14 = null;
      ClientWorld var13 = var26;
      List var17 = var13.getOtherEntities((Entity)var14, var15, var16);
      byte var27 = ((byte)((var17.isEmpty()) ? 1 : 0));
      int var22 = var4;
      byte var21 = var27;
      byte var19 = var21;
      byte var18 = var21;
      if (var22 != 0) {
         byte var23 = var18;
         if (var23 != 0) {
            return false;
         }

         var19 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var19);
   }

   public static boolean h(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      long var1 = (Long)var0[1];
      var1 = 126927211874952L ^ var1;
      int var10000 = invokeBinding2(1554149416585975761L, var1);
      Box var5 = new Box(
         invokeBinding3(var3, 1554826100427450613L, var1),
         invokeBinding4(var3, 1553757608711587780L, var1),
         invokeBinding5(var3, 1554388356667572260L, var1),
         invokeBinding6(var3, 1554826100427450613L, var1) + 1.0,
         invokeBinding7(var3, 1553757608711587780L, var1) + 1.0,
         invokeBinding8(var3, 1554388356667572260L, var1) + 1.0
      );
      int var4 = var10000;

      try {
         byte var16 = ((byte)((invokeBinding12(
            invokeBinding11(invokeBinding9(b, 1554694504895740058L, var1), null, var5, invokeBinding10(), 1555973958976684765L, var1),
            1553732438735944063L,
            var1
         )) ? 1 : 0));
         int var11 = var4;
         byte var10 = var16;
         byte var8 = var10;
         byte var6 = var10;
         if (var11 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var8);
         }

         byte var12 = var6;
         if (var12 != 0) {
            return false;
         }
      } catch (MatchException var14) {
         throw invokeBinding13(var14, 1552778210072849970L, var1);
      }

      byte var17 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var17);
   }

   public static boolean i(Object[] var0) {
      BlockPos var4 = (BlockPos)var0[0];
      float var1 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 126927211874952L ^ var2;
      int var10000 = invokeBinding14(796053324395039052L, var2);
      Box var6 = invokeBinding21(
         new Box(
            invokeBinding15(var4, 796731374035990120L, var2),
            invokeBinding16(var4, 796392485633497433L, var2),
            invokeBinding17(var4, 796889840758398649L, var2),
            invokeBinding18(var4, 796731374035990120L, var2) + 1.0,
            invokeBinding19(var4, 796392485633497433L, var2) + 1.0,
            invokeBinding20(var4, 796889840758398649L, var2) + 1.0
         ),
         var1,
         798926438622721524L,
         var2
      );
      int var5 = var10000;

      try {
         byte var17 = ((byte)((invokeBinding25(
            invokeBinding24(invokeBinding22(b, 796634130478982663L, var2), null, var6, invokeBinding23(), 795653882007608384L, var2), 797879875077826530L, var2
         )) ? 1 : 0));
         int var12 = var5;
         byte var11 = var17;
         byte var9 = var11;
         byte var7 = var11;
         if (var12 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var9);
         }

         byte var13 = var7;
         if (var13 != 0) {
            return false;
         }
      } catch (MatchException var15) {
         throw invokeBinding26(var15, 797637828513296559L, var2);
      }

      byte var18 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var18);
   }

   public static boolean jReturningBoolean(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      long var2 = (Long)var0[1];
      var2 = 126927211874952L ^ var2;
      int var10000 = invokeBinding27(7649104657197683994L, var2);
      Box var5 = new Box(
         invokeBinding28(var1, 7648444846336677698L, var2),
         invokeBinding29(var1, 7649197224164587635L, var2),
         invokeBinding30(var1, 7648570053914787731L, var2),
         invokeBinding31(var1, 7648444846336677698L, var2) + 1.0,
         invokeBinding32(var1, 7649197224164587635L, var2) + 1.0,
         invokeBinding33(var1, 7648570053914787731L, var2) + 1.0
      );
      int var4 = var10000;

      try {
         byte var16 = ((byte)((invokeBinding37(
            invokeBinding36(invokeBinding34(b, 7648242892575901485L, var2), null, var5, invokeBinding35(), 7647261818397343082L, var2),
            7654027421031597768L,
            var2
         )) ? 1 : 0));
         int var11 = var4;
         byte var10 = var16;
         byte var8 = var10;
         byte var6 = var10;
         if (var11 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var8);
         }

         byte var12 = var6;
         if (var12 != 0) {
            return false;
         }
      } catch (MatchException var14) {
         throw invokeBinding38(var14, 7654981952473174405L, var2);
      }

      byte var17 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var17);
   }

   public static List aReturningList(Object[] var0) {
      int var1 = (Integer)var0[0];
      Predicate var2 = (Predicate)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 126927211874952L ^ var3;
      ArrayList var6 = new ArrayList();
      MinecraftClient var15 = b;
      ClientPlayerEntity var16 = var15.player;
      BlockPos var7 = var16.getBlockPos();
      int var51 = Event.bReturningInt();
      BlockPos var17 = var7;
      int var8 = var17.getX();
      BlockPos var18 = var7;
      int var9 = var18.getY();
      BlockPos var19 = var7;
      int var10 = var19.getZ();
      Mutable var11 = new Mutable();
      int var12 = -var1;
      int var5 = var51;

      while (true) {
         int var30 = var12;

         label53:
         while (true) {
            int var36 = var1;
            int var35 = var30;
            if (var35 > var36) {
               return var6;
            }

            int var13 = -var1;

            label50:
            while (true) {
               int var31 = var13;

               label48:
               while (true) {
                  int var38 = var1;
                  int var37 = var31;
                  if (var37 > var38) {
                     break label50;
                  }

                  int var52 = -var1;
                  int var40 = var5;
                  int var39 = var52;
                  var30 = var39;
                  int var32 = var39;
                  if (var40 != 0) {
                     continue label53;
                  }

                  int var14 = var32;

                  int var48;
                  do {
                     int var42 = var1;
                     int var41 = var14;
                     if (var41 > var42) {
                        break;
                     }

                     int var10001 = var8 + var12;
                     int var10002 = var9 + var13;
                     int var23 = var10 + var14;
                     int var22 = var10002;
                     int var21 = var10001;
                     Mutable var20 = var11;
                     var20.set(var21, var22, var23);
                     int var43 = var5;
                     if (var43 == 0) {
                        Mutable var25 = var11;
                        Predicate var24 = var2;
                        byte var53 = ((byte)((var24.test(var25)) ? 1 : 0));
                        int var45 = var5;
                        byte var44 = var53;
                        var31 = var44;
                        byte var33 = var44;
                        if (var45 != 0) {
                           continue label48;
                        }

                        byte var46 = var33;
                        byte var34 = var46;
                        byte var47 = var34;
                        if (var47 != 0) {
                           Mutable var27 = var11;
                           BlockPos var29 = var27.toImmutable();
                           ArrayList var28 = var6;
                           var28.add(var29);
                        }

                        var14++;
                     }

                     var48 = var5;
                  } while (var48 == 0);

                  var13++;
                  int var49 = var5;
                  if (var49 != 0) {
                     break label50;
                  }
                  break;
               }
            }

            var12++;
            int var50 = var5;
            if (var50 != 0) {
               return var6;
            }
            break;
         }
      }
   }

   public static void aReturningVoid(Object[] var0) {
      int var5 = (Integer)var0[0];
      Predicate var2 = (Predicate)var0[1];
      Consumer var1 = (Consumer)var0[2];
      long var3 = (Long)var0[3];
      var3 = 126927211874952L ^ var3;
      BlockPos var7 = invokeBinding40(invokeBinding39(b, 100767535015014671L, var3), 107813679978979555L, var3);
      int var8 = invokeBinding41(var7, 106057519308864542L, var3);
      int var10000 = invokeBinding42(106787834743275078L, var3);
      int var9 = invokeBinding43(var7, 106712593573516079L, var3);
      int var10 = invokeBinding44(var7, 106216260651357391L, var3);
      Mutable var11 = new Mutable();
      int var12 = -var5;
      int var6 = var10000;

      while (true) {
         int var15 = var12;

         label68:
         while (true) {
            int var23 = var5;
            int var22 = var15;
            if (var22 > var23) {
               return;
            }

            int var13 = -var5;

            label65:
            while (true) {
               int var16 = var13;

               label63:
               while (true) {
                  int var25 = var5;
                  int var24 = var16;
                  if (var24 > var25) {
                     break label65;
                  }

                  var10000 = -var5;
                  int var27 = var6;
                  int var26 = var10000;
                  var15 = var26;
                  int var17 = var26;
                  if (var27 != 0) {
                     continue label68;
                  }

                  int var14 = var17;

                  int var35;
                  do {
                     int var29 = var5;
                     int var28 = var14;
                     if (var28 > var29) {
                        break;
                     }

                     label77: {
                        byte var18;
                        try {
                           invokeBinding45(var11, var8 + var12, var9 + var13, var10 + var14, 100602105515447730L, var3);
                           int var30 = var6;
                           if (var30 != 0) {
                              break label77;
                           }

                           byte var42 = ((byte)((invokeBinding46(var2, var11, 107903718590828635L, var3)) ? 1 : 0));
                           int var32 = var6;
                           byte var31 = var42;
                           var16 = var31;
                           var18 = var31;
                           if (var32 != 0) {
                              continue label63;
                           }
                        } catch (MatchException var39) {
                           throw invokeBinding47(var39, 101193930032937689L, var3);
                        }

                        byte var33 = var18;
                        byte var20 = var33;

                        try {
                           byte var34 = var20;
                           if (var34 != 0) {
                              invokeBinding48(var1, var11, 100010978477979444L, var3);
                           }
                        } catch (MatchException var38) {
                           throw invokeBinding49(var38, 101193930032937689L, var3);
                        }

                        var14++;
                     }

                     var35 = var6;
                  } while (var35 == 0);

                  var13++;
                  int var36 = var6;
                  if (var36 != 0) {
                     break label65;
                  }
                  break;
               }
            }

            var12++;
            int var37 = var6;
            if (var37 != 0) {
               return;
            }
            break;
         }
      }
   }

   public static boolean kReturningBoolean(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      Block var2 = (Block)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 126927211874952L ^ var3;
      MinecraftClient var5 = b;
      BlockPos var7 = var1;
      ClientWorld var6 = var5.world;
      BlockState var8 = var6.getBlockState(var7);
      Block var13 = var8.getBlock();
      Block var11 = var2;
      Block var10 = var13;
      byte var9;
      if (var10 == var11) {
         byte var12 = 1;
         var9 = var12;
      } else {
         var9 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   public static BlockState aReturningBlockState(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 126927211874952L ^ var1;
      MinecraftClient var4 = b;
      BlockPos var6 = var3;
      ClientWorld var5 = var4.world;
      return var5.getBlockState(var6);
   }

   public static int aReturningInt(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      long var1 = (Long)var0[1];
      var1 = 126927211874952L ^ var1;
      long var4 = var1 ^ 75175552861524L;
      Object[] var6 = new Object[]{var3, var4};
      BlockState var10000 = aReturningBlockState(var6);
      IntProperty var8 = Properties.CHARGES;
      BlockState var7 = var10000;
      Integer var9 = (Integer)var7.get((Property)var8);
      return var9;
   }

   private static boolean lambda$hasCrystal$3(Entity var0) {
      return var0 instanceof EndCrystalEntity;
   }

   private static boolean lambda$collidesWithEntity$2(Entity var0) {
      int var3 = Event.cReturningInt();
      byte var10000 = ((byte)((var0 instanceof ItemEntity) ? 1 : 0));
      int var8 = var3;
      byte var7 = var10000;
      byte var5 = var7;
      byte var4 = var7;
      if (var8 != 0) {
         byte var9 = var4;
         if (var9 != 0) {
            return false;
         }

         var5 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var5);
   }

   private static boolean lambda$collidesWithEntityIgnoringCrystal$1(Entity var0) {
      int var3 = Event.cReturningInt();
      byte var10000 = ((byte)((var0 instanceof ItemEntity) ? 1 : 0));
      int var10 = var3;
      byte var9 = var10000;
      byte var5 = var9;
      byte var4 = var9;
      if (var10 != 0) {
         byte var11 = var4;
         if (var11 != 0) {
            return false;
         }

         byte var12 = ((byte)((var0 instanceof EndCrystalEntity) ? 1 : 0));
         var5 = var12;
      }

      int var14 = var3;
      byte var13 = var5;
      byte var7 = var13;
      byte var6 = var13;
      if (var14 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var7);
      } else {
         byte var15 = var6;
         if (var15 == 0) {
            var7 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var7);
         } else {
            return false;
         }
      }
   }

   private static boolean lambda$collidesWithEntity$0(Entity var0) {
      int var3 = Event.cReturningInt();
      byte var10000 = ((byte)((var0 instanceof ItemEntity) ? 1 : 0));
      int var8 = var3;
      byte var7 = var10000;
      byte var5 = var7;
      byte var4 = var7;
      if (var8 != 0) {
         byte var9 = var4;
         if (var9 != 0) {
            return false;
         }

         var5 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var5);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 30;
            yield var15;
         }
         case 1 -> {
            byte var16 = 21;
            yield var16;
         }
         case 2 -> {
            byte var17 = 33;
            yield var17;
         }
         case 3 -> {
            byte var18 = 57;
            yield var18;
         }
         case 4 -> {
            byte var19 = 31;
            yield var19;
         }
         case 5 -> {
            byte var20 = 16;
            yield var20;
         }
         case 6 -> {
            byte var21 = 40;
            yield var21;
         }
         case 7 -> {
            byte var22 = 60;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 26;
            yield var24;
         }
         case 10 -> {
            byte var25 = 8;
            yield var25;
         }
         case 11 -> {
            byte var26 = 58;
            yield var26;
         }
         case 12 -> {
            byte var27 = 37;
            yield var27;
         }
         case 13 -> {
            byte var28 = 44;
            yield var28;
         }
         case 14 -> {
            byte var29 = 42;
            yield var29;
         }
         case 15 -> {
            byte var30 = 29;
            yield var30;
         }
         case 16 -> {
            byte var31 = 35;
            yield var31;
         }
         case 17 -> {
            byte var32 = 23;
            yield var32;
         }
         case 18 -> {
            byte var33 = 43;
            yield var33;
         }
         case 19 -> {
            byte var34 = 2;
            yield var34;
         }
         case 20 -> {
            byte var35 = 28;
            yield var35;
         }
         case 21 -> {
            byte var36 = 20;
            yield var36;
         }
         case 22 -> {
            byte var37 = 54;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 32;
            yield var39;
         }
         case 25 -> {
            byte var40 = 59;
            yield var40;
         }
         case 26 -> {
            byte var41 = 6;
            yield var41;
         }
         case 27 -> {
            byte var42 = 45;
            yield var42;
         }
         case 28 -> {
            byte var43 = 62;
            yield var43;
         }
         case 29 -> {
            byte var44 = 52;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 1;
            yield var46;
         }
         case 32 -> {
            byte var47 = 22;
            yield var47;
         }
         case 33 -> {
            byte var48 = 18;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 25;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 47;
            yield var52;
         }
         case 38 -> {
            byte var53 = 19;
            yield var53;
         }
         case 39 -> {
            byte var54 = 61;
            yield var54;
         }
         case 40 -> {
            byte var55 = 41;
            yield var55;
         }
         case 41 -> {
            byte var56 = 55;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 49;
            yield var58;
         }
         case 44 -> {
            byte var59 = 4;
            yield var59;
         }
         case 45 -> {
            byte var60 = 38;
            yield var60;
         }
         case 46 -> {
            byte var61 = 9;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 27;
            yield var64;
         }
         case 50 -> {
            byte var65 = 10;
            yield var65;
         }
         case 51 -> {
            byte var66 = 5;
            yield var66;
         }
         case 52 -> {
            byte var67 = 51;
            yield var67;
         }
         case 53 -> {
            byte var68 = 7;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 56;
            yield var71;
         }
         case 57 -> {
            byte var72 = 17;
            yield var72;
         }
         case 58 -> {
            byte var73 = 46;
            yield var73;
         }
         case 59 -> {
            byte var74 = 11;
            yield var74;
         }
         case 60 -> {
            byte var75 = 0;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 24;
            yield var77;
         }
         default -> 48;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "\u0005<\td\u0010I\u0013<\f>\u0003^\u0004w\u000f8\u000fJ\u00150\u0018/DX\r";
      c[1] = "rf*.\b'yi;ak*ld4\n^(}w(&I%";
      c[2] = "-ag\u000eN,;abT];,*aRQ/=mvE\u001a=\f";
      c[3] = int.class;
      d[3] = "java/lang/Integer";
      c[4] = "7k'U|T7k0\tp[- 0\u0017pN*Q`J!";
      c[5] = "AX\nq)'AX\u001d-%([\u0013\u001d3%=\\bHl|";
      c[6] = "\r[\u001c\u0014[\u001d\r[\u000bHW\u0012\u0017\u0010\u000bVW\u0007\u0010aZ\t\u0005L";
      c[7] = "\u000eA\u007fB1\u0010\u000eAh\u001e=\u001f\u0014\nh\u0000=\n\u0013{9ZdI";
      c[8] = "\f$: y%\f$-|u*\u0016o-bu?\u0011\u001e|< z";
      c[9] = "T\tS?NbT\tDcBmNBD}BxI3\u0015#\u00173";
      c[10] = "m$&k^\fm$17R\u0003wo1)R\u0016p\u001ecw\nR";
      c[11] = "DqVM)\u0012DqA\u0011%\u001d^:A\u000f%\bYK\u0010P|";
      c[12] = "ds\u001ayi\u0003z{\u00006!\u0003`q\u0018q(\u0018 B\u001e}#\u001fms\u0018}";
      c[13] = "GO\u0016B\rIYG\f\roU^Z";
      c[14] = boolean.class;
      d[14] = "java/lang/Boolean";
      c[15] = ">UK\u007f\u0018s>U\\#\u0014|$\u001e\\=\u0014i#o\rfC#";
      c[16] = "uC;f8h~L*)UkrR,uwfsG";
      c[17] = "Q\u000194\"mZ\u000e({EoO\u0005(0~";
      c[18] = "\u001a\u0001s\fn\u001f\u001a\u0001dPb\u0010\u0000JdNb\u0005\u0007;5\u00157G";
      c[19] = "&#1_c/&#&\u0003o <h&\u001do5;\u0019wF;~";
      c[20] = "\u0014\u00105#\u0013\u0001a0>,\u0002N\u0000>5'\u0006\u0014t";
      c[21] = double.class;
      d[21] = "java/lang/Double";
      c[22] = "Si>p6I&I5\u007f'\u0006GG>t#\\3";
      c[23] = ":.aTp;:.v\b|4 ev\u0016|!'\u0014&C+g";
      c[24] = "^\u0016+oPX^\u0016<3\\WD]<-\\BC,hu\u000b";
      c[25] = "\u001fQX3\u007fa\u001fQOosn\u0005\u001aOqs{\u0002k\u001e)!";
      c[26] = "$.\u001b\u0017_s$.\fKS|>e\fUSi9\u0014]\n\u0007*";
      c[27] = "V\u0002?UprV\u0002(\t|}LI(\u0017|hK8yH.#\u001c\u0004'\u001anhgUxH$";
      c[28] = "3\u000e\rA\u0007Q8\u0001\u001c\u000ef_3\n\u0018T";
      c[29] = ")\tf\u001cP)7\u0001|S\u0018)-\u000bd\u0014\u00112m+\u007f\u0013\r).\rb";
      c[30] = void.class;
      d[30] = "java/lang/Void";
      c[31] = "Ycg;0~,Cl4!1MMg?%k9";
      c[32] = "0bw!\u0018cEB|.\t,$Lw%\rvP";
      c[33] = "\u0012%uj\b\u0007g\u0005~e\u0019H\u0006\u000bun\u001d\u0012r";
      c[34] = "6`pOI\"q$k\u0016u7f\"nI\u0019\u00052g0\u0013IRb\"b@\u001b(wbo\\u8be`UJ>dop.";
      c[35] = "\u0012aq\u00166dS3a\u0017W6M<u\u001f\u0000i\u001da.si;R*cB5d\u001do";
      c[36] = "\u0013\u0013\u0002pl*RA\u0012q\rxLN\u0006yZ/\u0015\u001e^-\r(N]\u0019g<t\u0011\u0012\\";
      c[37] = "k\nM1\u001fF,NVh#S;HS7Oal\n\th\u001f6hWM+Q\u00074\b\u0002n#";
      c[38] = "a5b<jA17ab\u0013]0qx9\u007fom6#e\u0013\u00073=)`b\u0002:`e^,D'2!#\"F#|\u0018ni\u00068ae8aJ,\r)5r\u0007:6#?/R]";
      c[39] = "*\u00157zC.8D`w,t'\u0005\u000fnHh,ykiJp%\u00184aC+A";
      c[40] = "U;J[ad\u00033\u0006O\re\b:\b>oa\u0001,\u0010Lw{\u0001%t\u000ft!\n \u000e\u0007qaXA";
      c[41] = "Id\u0019g@D\u0019z\u0014b+\u001bK~\u001dcG)\u001c>@=\u0016~\u001a2\u001beZAYlB}+";
      c[42] = "<ecw\u0019\u001anjl7g@3'i \u000brgc1y]%bko&\u0016\u001a!56>g";
      c[43] = "&\u0014|\u0011~|v\nq\u0014\u0015#$\u000ex\u0015y\u0011rI%M,F)\u001e)Ojv-Ke\u0014\u0015";
      c[44] = "\u001cqFhK ]#Vi*rC,Ba}%\u001a}\u0019<*\"A?]\u007f\u001b~\u001ep\u0018";
      c[45] = "@\u007f$\"#vD*hy\\(A~qs\u000b\u007f\u001b./\u001f2~X/(gg9Ba";
      c[46] = "S6\rO1\u0019WcA\u0014NGR7X\u001e\u0019\u0010\bg\u0005r \u0011Kf\u0001\nuVQ(";
      c[47] = "?Rtmhao\u00066m\u0018<3\u0015$2t\u000egQ}k%Yd\u0007\"0|8;\u000f+k\u0018";
      c[48] = "\f2w\u0014w*Ol.\f\u0006p]~q\u0012jB\t:+K>\u0015\nlw\u0010btUd~K\u0006";
      c[49] = "p\u0011\u000b4_w1C\u001b5>%/L\u000f=irv\u001dTn>u-_\u0010#\u000f)r\u0010U";
      c[50] = "Pp'5K\u0004^r#{r\u001c\u0002p=m\u001e.V4e4r\u0019\u0003=`uB\u001dVq;\nC\u0000Wc<pK\u0005\u00171]";
      c[51] = "R)!\u0003\u007fH\u0011wx\u001b\u000e\u0012\u0003e'\u0005b R(yY1w\u0000!?^3\u000fUf%\u0010\u000e\u0019Va{_vL\u0011{5b`O\u0016%z\u001a5\b\fkG^>\u0011\u000fhx\u001d`H\u0017\u0019";
      c[52] = "d;\u0016?0\u0019%}\u00126B\u0012>oOc\u0015Ea2\u0014\u000f~D%`Rv.F&>";
      c[53] = "2\"\u007fW\u0011)q|&O`scnyQ\fA7*!\u0006\\\u00162\"\u007fW\u0011)q|&O`";
      c[54] = "\fL%\u007f0\rO\u0012|gAW]\u0000#y-e\tDy z2\n\u0012%{%SU\u001a, A";
      c[55] = "'\u0007\"\u0013C #RnH<u*\u0017sIPG~S)\u0016<p+Z.Q\ft~\u0016u.\\|vVl\u001eX):\r\u0013";
      c[56] = "h}Qs\\k1`\u0006da|Q#\u0001s\u0004r0|\tz_\u0016";
      c[57] = "\u001f2N\\\u0016\u0012\\l\u0017DgHN~HZ\u000bz\u001a:\u0012\u0003[-\u0019lNX\u0003LFdG\u0003g";
      c[58] = "4\u000bO\u0001C\b0^\u0003Z<]9\u001b\u001e[Pom_D\r<X8VCC\f\\m\u001a\u0018<";
      c[59] = "J1TIC,\u000bcDH\"~\u0015lP@u)L8\u000e\u0010\".\u0017\u007fO^\u0013rH0\n";
      c[60] = "[pq(ZO\u0002m&?gYb.!(\u0002V\u0003q)!Y2";
      c[61] = "!\u0004\u0014D\"\u0000+\u0012I\u0014\u001d\u0013+\u0011OIJDpA\u0010\u001b\u001d\u0011'\u001bZ[v\f$\u0013W";
      c[62] = "`uS\u00149ne|\u000eX\u0007z2g\u0003BkHb+Y\u0014\u0007 #a\\\u001cz.!e\u0012%";
      c[63] = " 5VH4~asRAF~vp\u000b\u001f*L\"1VAF \"1[\n#ad5Rx";
      c[64] = "0\u0002s}\u00069b\r|=xc?@y*\u0014Qk\u0004 uC\u0006hR\u007f(\u001cg7Zvsx<<Z|)\u0019c4S'MBh4Y},\u001d`=\u0002\u0019/FlbB&}Ic\"<";
      c[65] = "2\u000e'~ $6[k%_z3\u000fr/\b-i_.C1,*^+;dk0\u0010";
      c[66] = "\u001e^v\u001d7\n_\u0018r\u0014E\u0001D\n/A\u0012V\u001a]w-*\tA\u0004 \u0017z\u0017L\u0001";
      c[67] = "#i}b\b\u0004s=?bxY/.-=\u0014k{jtfH<x<+?\u001c]'4\"dx";
      c[68] = "=%$%']|w4$F\u000fbx ,\u0011X;.x{F_`k?2w\u0003?$z";
      c[69] = "/~rnd\u0019++>5\u001bL\"n#4w~v*yi\u001bI##~,+Mvo%Su\u00117.~+ V-`C";
      c[70] = "\b\u000f\u0012\u0018,x\u0002\u0005OMK\"B)\u0016_729U\n\u001f$\"C]\u000f_vC";
      c[71] = "^i\u00113\u00030C8\u0005-}l\\y\u001b)\u0011^\b:DqB\t\r5\u001d/\f6NkD7}";
      c[72] = " Le\u0015\u001ckg\b~L ~p\u000e{\u0013LL!O'K\u001c\u001b,\u000b#\u001bAa$\u000ecI ";
      c[73] = ";Q'\u001e @f\f{\u007f-/f\u00005\u0006~\u0011\u007f\r7\u0018B\u001eyT*\u001e8\u0016|\u0014x\u007f";
      c[74] = "N\u0019\u0000x&;\u001e\u001b\u0003&_'\u001f]\u001a}3\u0015B\u001a@\"_~BG\u001bk`=\u001c\u001e\u0003\u001ab|\f@Fj%8\u0017\u0019z";
      c[75] = "y{\u000e_\f|$&R>\u0007\u0013<:\u0000N\u0003-?+\u0002>\u0010o.6\u0001\u0000\u0013~,F";
      c[76] = "Ge\u0015*\u001e\u0018\u001a8IK\u0011w\u001a4\u00072@I\u00039\u0005,|F\u0005`\u0018*\u0006N\u0000 JK";
      c[77] = "X\u0014Aztt]\u001d\u001c6J`\n\u0006\u0011,&R\\ALts\u0005\u0007\u0016@v55\u0003C\f-J";
      c[78] = ":G\u0000:\u0019\ng\u001a\\[\u0011eg\u0016\u0012\"G[~\u001b\u0010<{TxB\r:\u0001\\}\u0002_[";
      c[79] = "Su\bD\fCY\u007fU\u0011k\u0011\u000eri\u0019\u0013\u001c\u000fz\u001b\u0001\t\u001c\u0006\u001eX\u0002S\u0017\u0003dP\u0007\u0013Eb";
      c[80] = "B\u0018)?\u007fqFMed\u0000$O\bxel\u0016\u001bL!3\u0000!NE%}0%\u001b\t~\u0002`-\u0013Ig2dx_\u0012\u0018";
      c[81] = "tZqF%'$\u000e3FUzx\u001d!\u00199H,Yx@i\u001f/\u000f'\u001b1~p\u0007.@U";
      c[82] = "\fH\u001c1\u001cn\u0006^Aa#}\u0006]G<t)\\\t\u0013o#\u007f\nWR.Hb\t__";
      c[83] = "\\.\u0017EE:\u0001sK$NU\u0001\u007f\u0005]\u001bk\u0018r\u0007C'hYm\u0014\u0018W/\u001dvM$";
      c[84] = "\u000e%2K0\"\np~\u0010Ow\u00035c\u0011#EWq9OO|V1?K7)\u0011+qv/~_t|F++\u0013/\u0003";
      c[85] = "\u00108-Wy7\u001e:)\u0019@/B87\u000f,\u001d\u0016|nT@$\u0017<kU8qP&%h\u007f6U{n\u0015q4Q5W";
      c[86] = "X 7k\u0006 \u0019r'jgr\u0007}3b0%^(l0g\"\u0005n,|V~Z!i";
      c[87] = "1vZg\u0014:r(\u0003\u007fe``:\\a\tR4~\u00048T\u00057(Zc\u0001dh S8e?c Yb\u0004`k)\u0002\u0006_kk#Xg\u0000cbx<:Ucl7\u0003y\u000b:tF";
      c[88] = "<j\u001fn]I?$S)lX4>\u000en\u00101=-\u0007{\bC%7\u0007rlUbdYgT\u0000$-\u001f\u0016";
      c[89] = "5c\u001f\u0002a\u0018h>Ccjwh2\r\u001a?Iq?\u000f\u0004\u0003Im \u0006\u00112\u00152oCc";
      c[90] = "j_\u0004/Wyw\u000e\u00101)%hO\u000e5E\u0017<\fQb\u0011@d\b^jYx4\\\u001cj)";
      c[91] = "\u001d\u0007?\u0002K\nZC$[w\u001fME!\u0004\u001b-\u001a\u0006q^Mz\u001eZ?\u0018\u0005KB\u0005p]wKY\u0001.\u0002\rC\\A|c";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(2001844376646393L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(2001844376646393L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(2001844376646393L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 240;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 226;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 121;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 224;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 249;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 107;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 240;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 226;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 121;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/al_C0026",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/al" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/al_C0026", "lambda$collidesWithEntity$0", "(Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static int invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = a(MethodHandles.lookup(), "k", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientWorld invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = a(
                  MethodHandles.lookup(),
                  "ð",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Predicate invokeBinding10() {
         MethodHandle var4 = bindingCache10;
         MethodHandle var3 = bindingCache10;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/al_C0026",
                     "lambda$collidesWithEntityIgnoringCrystal$1",
                     "(Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static List invokeBinding11(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache11;
         MethodHandle var11 = bindingCache11;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache11 = a(
                  MethodHandles.lookup(),
                  "ù",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/util/List;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (List)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static boolean invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = a(
                  MethodHandles.lookup(), "k", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = a(MethodHandles.lookup(), "k", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Box invokeBinding21(Object var0, double var1, long var3, long var5) {
         MethodHandle var11 = bindingCache21;
         MethodHandle var10 = bindingCache21;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache21 = a(
                  MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;DJJ)Lnet/minecraft/util/math/Box;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Box)var8.invokeExact((Object)var0, (double)var1, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static ClientWorld invokeBinding22(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = a(
                  MethodHandles.lookup(),
                  "ð",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Predicate invokeBinding23() {
         MethodHandle var4 = bindingCache23;
         MethodHandle var3 = bindingCache23;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache23 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/al_C0026", "lambda$collidesWithEntity$2", "(Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static List invokeBinding24(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache24;
         MethodHandle var11 = bindingCache24;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache24 = a(
                  MethodHandles.lookup(),
                  "ù",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/util/List;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (List)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static boolean invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = a(
                  MethodHandles.lookup(), "k", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding27(long var0, long var2) {
         MethodHandle var8 = bindingCache27;
         MethodHandle var7 = bindingCache27;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache27 = a(MethodHandles.lookup(), "k", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientWorld invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = a(
                  MethodHandles.lookup(),
                  "ð",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Predicate invokeBinding35() {
         MethodHandle var4 = bindingCache35;
         MethodHandle var3 = bindingCache35;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache35 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/al_C0026", "lambda$hasCrystal$3", "(Lnet/minecraft/entity/Entity;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static List invokeBinding36(Object var0, Object var1, Object var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache36;
         MethodHandle var11 = bindingCache36;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache36 = a(
                  MethodHandles.lookup(),
                  "ù",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/util/List;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (List)var9.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static boolean invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = a(
                  MethodHandles.lookup(), "k", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = a(
                  MethodHandles.lookup(),
                  "ð",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BlockPos invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = a(
                  MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/BlockPos;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BlockPos)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding42(long var0, long var2) {
         MethodHandle var8 = bindingCache42;
         MethodHandle var7 = bindingCache42;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache42 = a(MethodHandles.lookup(), "k", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = a(MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Mutable invokeBinding45(Object var0, int var1, int var2, int var3, long var4, long var6) {
         MethodHandle var12 = bindingCache45;
         MethodHandle var11 = bindingCache45;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache45 = a(
                  MethodHandles.lookup(),
                  "ù",
                  SourceSupport.methodType("(Ljava/lang/Object;IIIJJ)Lnet/minecraft/util/math/BlockPos$Mutable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Mutable)var9.invokeExact((Object)var0, (int)var1, (int)var2, (int)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static boolean invokeBinding46(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = a(
                  MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = a(
                  MethodHandles.lookup(), "k", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding48(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache48;
         MethodHandle var9 = bindingCache48;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache48 = a(
                  MethodHandles.lookup(), "ù", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = a(
                  MethodHandles.lookup(), "k", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
