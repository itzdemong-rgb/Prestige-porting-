package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.NotNull;

public class ConcurrentIdentitySet implements Iterable {
   private final Set a;
   private final Set b;
   private static final long c = 40911860639096L;
   private static final Object[] d = new Object[27];
   private static final String[] e = new String[27];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;

   public ConcurrentIdentitySet(Object[] var1, long var2) {
      super();
      long var10000 = 40911860639096L ^ var2;

      this.a = ConcurrentHashMap.newKeySet();
      Set var4 = this.a;
      this.b = Collections.unmodifiableSet(var4);
      Object[] var6 = var1;
      Set var5 = this.a;
      Collections.addAll(var5, var6);
   }

   public boolean aReturningBoolean(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 40911860639096L ^ var3;
      Object var6 = var2;
      Set var5 = this.a;
      return var5.add(var6);
   }

   public boolean bReturningBoolean(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      var3 = 40911860639096L ^ var3;
      return invokeBinding1(this.a, var2, -4743385124969938474L, var3);
   }

   public boolean cReturningBoolean(Object[] var1) {
      Collection var2 = (Collection)var1[0];
      long var3 = (Long)var1[1];
      var3 = 40911860639096L ^ var3;
      int var10000 = invokeBinding2(5610275715228470530L, var3);
      Iterator var7 = invokeBinding3(var2, 5610344568918531266L, var3);
      int var5 = var10000;

      int var10;
      while (true) {
         boolean var11 = invokeBinding4(var7, 5609677145524201871L, var3);
         if (var11) {
            Object var8 = invokeBinding5(var7, 5609997494092079603L, var3);
            var10000 = var6 | (((invokeBinding6(this.a, var8, 5609855291006358549L, var3)) ? 1 : 0));
            int var13 = var5;
            int var12 = var10000;
            var10 = var12;
            int var9 = var12;
            if (var13 == 0) {
               break;
            }

            var6 = var9;
            int var14 = var5;
            if (var14 != 0) {
               continue;
            }
         }

         var10 = var6;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var10);
   }

   public boolean dReturningBoolean(Object[] var1) {
      Collection var2 = (Collection)var1[0];
      long var3 = (Long)var1[1];
      var3 = 40911860639096L ^ var3;
      int var10000 = invokeBinding7(9161773567140558581L, var3);
      Iterator var7 = invokeBinding8(var2, 9161038188072693307L, var3);
      int var5 = var10000;

      int var10;
      while (true) {
         boolean var11 = invokeBinding9(var7, 9160579738461985654L, var3);
         if (var11) {
            Object var8 = invokeBinding10(var7, 9161394661099737866L, var3);
            var10000 = var6 | (((invokeBinding11(this.a, var8, 9160972223037194456L, var3)) ? 1 : 0));
            int var13 = var5;
            int var12 = var10000;
            var10 = var12;
            int var9 = var12;
            if (var13 != 0) {
               break;
            }

            var6 = var9;
            int var14 = var5;
            if (var14 == 0) {
               continue;
            }
         }

         var10 = var6;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var10);
   }

   public void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 40911860639096L ^ var2;
      invokeBinding12(this.a, -1116805868287224003L, var2);
   }

   public boolean eReturningBoolean(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      var3 = 40911860639096L ^ var3;
      return invokeBinding13(this.a, var2, 2941695446626416008L, var3);
   }

   public int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 40911860639096L ^ var2;
      return invokeBinding14(this.a, 4037994999759530012L, var2);
   }

   public boolean fReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 40911860639096L ^ var2;
      Set var4 = this.a;
      return var4.isEmpty();
   }

   public Set aReturningSet(Object[] var1) {
      return this.b;
   }

   @NotNull
   @Override
   public Iterator iterator() {
      Set var3 = this.b;
      return var3.iterator();
   }

   static {
      aReturningVoid();
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = e[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = d[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 52;
            yield var15;
         }
         case 1 -> {
            byte var16 = 26;
            yield var16;
         }
         case 2 -> {
            byte var17 = 54;
            yield var17;
         }
         case 3 -> {
            byte var18 = 45;
            yield var18;
         }
         case 4 -> {
            byte var19 = 51;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 32;
            yield var21;
         }
         case 7 -> {
            byte var22 = 10;
            yield var22;
         }
         case 8 -> {
            byte var23 = 42;
            yield var23;
         }
         case 9 -> {
            byte var24 = 5;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 40;
            yield var26;
         }
         case 12 -> {
            byte var27 = 8;
            yield var27;
         }
         case 13 -> {
            byte var28 = 3;
            yield var28;
         }
         case 14 -> {
            byte var29 = 62;
            yield var29;
         }
         case 15 -> {
            byte var30 = 30;
            yield var30;
         }
         case 16 -> {
            byte var31 = 33;
            yield var31;
         }
         case 17 -> {
            byte var32 = 44;
            yield var32;
         }
         case 18 -> {
            byte var33 = 11;
            yield var33;
         }
         case 19 -> {
            byte var34 = 21;
            yield var34;
         }
         case 20 -> {
            byte var35 = 37;
            yield var35;
         }
         case 21 -> {
            byte var36 = 49;
            yield var36;
         }
         case 22 -> {
            byte var37 = 53;
            yield var37;
         }
         case 23 -> {
            byte var38 = 46;
            yield var38;
         }
         case 24 -> {
            byte var39 = 13;
            yield var39;
         }
         case 25 -> {
            byte var40 = 58;
            yield var40;
         }
         case 26 -> {
            byte var41 = 7;
            yield var41;
         }
         case 27 -> {
            byte var42 = 55;
            yield var42;
         }
         case 28 -> {
            byte var43 = 24;
            yield var43;
         }
         case 29 -> {
            byte var44 = 0;
            yield var44;
         }
         case 30 -> {
            byte var45 = 28;
            yield var45;
         }
         case 31 -> {
            byte var46 = 9;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 56;
            yield var48;
         }
         case 34 -> {
            byte var49 = 61;
            yield var49;
         }
         case 35 -> {
            byte var50 = 6;
            yield var50;
         }
         case 36 -> {
            byte var51 = 18;
            yield var51;
         }
         case 37 -> {
            byte var52 = 2;
            yield var52;
         }
         case 38 -> {
            byte var53 = 59;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 39;
            yield var55;
         }
         case 41 -> {
            byte var56 = 19;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 4;
            yield var58;
         }
         case 44 -> {
            byte var59 = 12;
            yield var59;
         }
         case 45 -> {
            byte var60 = 36;
            yield var60;
         }
         case 46 -> {
            byte var61 = 23;
            yield var61;
         }
         case 47 -> {
            byte var62 = 50;
            yield var62;
         }
         case 48 -> {
            byte var63 = 60;
            yield var63;
         }
         case 49 -> {
            byte var64 = 57;
            yield var64;
         }
         case 50 -> {
            byte var65 = 22;
            yield var65;
         }
         case 51 -> {
            byte var66 = 43;
            yield var66;
         }
         case 52 -> {
            byte var67 = 15;
            yield var67;
         }
         case 53 -> {
            byte var68 = 35;
            yield var68;
         }
         case 54 -> {
            byte var69 = 17;
            yield var69;
         }
         case 55 -> {
            byte var70 = 14;
            yield var70;
         }
         case 56 -> {
            byte var71 = 38;
            yield var71;
         }
         case 57 -> {
            byte var72 = 1;
            yield var72;
         }
         case 58 -> {
            byte var73 = 41;
            yield var73;
         }
         case 59 -> {
            byte var74 = 20;
            yield var74;
         }
         case 60 -> {
            byte var75 = 47;
            yield var75;
         }
         case 61 -> {
            byte var76 = 25;
            yield var76;
         }
         case 62 -> {
            byte var77 = 34;
            yield var77;
         }
         default -> 31;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            e[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      d[0] = "*\u001dO\u001f\u0001A4\u0015UP|Q4";
      d[1] = boolean.class;
      e[1] = "java/lang/Boolean";
      d[2] = void.class;
      e[2] = "java/lang/Void";
      d[3] = "F=[/rJM2J`\u0013DF9N:";
      d[4] = "rF$rU@lN>=8ZtK7p\u000f\\wI!";
      d[5] = "\u0006\u00078\u000f\u0015w\u0018\u000f\"@xm\u0000\n+\rOk\u0003\b";
      d[6] = "fp\t\r\u001f,\u0013P\u0002\u0002\u000ecr^\t\t\n9\u0006";
      d[7] = "D\u007fmA\u001akZww\u000eWq@}nRF{@j5c[pMkiRQpZVzS\\SOn";
      d[8] = "fN?ZP\u0017xF%\u0015\u001d\rbL<I\f\u0007b[gx\u0011\foZ;I\u001b\fxg(H\u0016/m_mp\u001b\u001b_J=m\u0017\u0007{";
      d[9] = int.class;
      e[9] = "java/lang/Integer";
      d[10] = "\\\u0001sDT\u0019J\u0001v\u001eG\u000e]Ju\u0018K\u001aL\rb\u000f\u0000\b}";
      d[11] = "R\u001e!!\u00147L\u0016;ns6]\r64U0";
      d[12] = "\nAX\r\u0005\u0005C\u0016S\u001fbQ]\u0016*\u0015\u00068\n\u001b\u0000\u0012\u000e\\]\n\f\fb\u0004W\u001e\u001c\u0010_I\rE\u0007q\u0010^Q\b\u0013\u0017\u0013_\nz";
      d[13] = "\u00158=)\u0000JP)0ffL*k-uZIA5#%]&";
      d[14] = "(\tfgp\t.\u00176\u0018p\u00100\u0018\f&{\u001d~\u001agxuMyu";
      d[15] = "DK\u0005POF\u0018\u001dOXs\u001e\u0014^wS\u0002#\u0014]4\u0003\f\u001f\u0000BR\u0001\u0016\u0014\u001e!";
      d[16] = "|\u0003NB\u000f\u000bz\u001d\u001e=\u000e\u001es\u0018ZPtIu\u0005\\D\u0017\u0011i\u0018]=\u0006\u0015v\rT[\u0005\u0014-\u007f";
      d[17] = "\u0005\n\u0000W\u0005$\u0003\u0014P(\u001f \u0002\f\u0003T\u0019&oFVG\u00100T\rQF\u0017\\";
      d[18] = "fPi\u00033]#AdLUZY\u0003y_i^2]w\u000fn1";
      d[19] = "AOg\u001a\u0017\u0002\u0016^k\u0004{\u0007\u0006C~\u0010\u0007\u0001\u0000.4E\u0014\b\u0016\u0015\u007fB\u0015\u000fz";
      d[20] = "\\\u00105sC7Z\u000ee\fQ#ZleoB7O\u000f=s_66\u001e9lJ?P\u001d878";
      d[21] = "9\u007f_tjM?a\u000f\u000bzR5\u007f\\jwNS9VqiL0aJlh5!eUyaS\"d\u000e\u000b";
      d[22] = "?;&QP;t<'V<fbw5?\u0006cu\u007f0\\^\u007fh~I";
      d[23] = "I}RE$\u0006Oc\u0002:>\u0005nd@F.~QgXH/\u0018Rf\u0003:";
      d[24] = "xgT1&\u000e10_#AN%9\b! ]\"5\u0005),h. o'=Y<'\u0017!#\tC6\u0013'>H;0\rwA";
      d[25] = "U\u007fNBR}Sa\u001e=BaRj^=\u0010kGi\u0018SR9Ec$";
      d[26] = "VEq\u000eR\r\u001dBp\t>V\u000f\u0002X\rNJf\u000bx\u0000LF\u0000\by[>";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = d[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(e[var4]);
            d[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = d[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            d[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  d[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(261713970116666L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = d[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  d[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(261713970116666L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        d[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(261713970116666L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 222;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 216;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 98;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 238;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 83;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 207;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 222;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 216;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 98;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cW_C0155",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cW" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static boolean invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = a(MethodHandles.lookup(), "Ï", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Iterator invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = a(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/Iterator;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Iterator)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding7(long var0, long var2) {
         MethodHandle var8 = bindingCache7;
         MethodHandle var7 = bindingCache7;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache7 = a(MethodHandles.lookup(), "Ï", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Iterator invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = a(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/Iterator;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Iterator)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding11(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = a(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = a(
                  MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = a(MethodHandles.lookup(), "S", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
