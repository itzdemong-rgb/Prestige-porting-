package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class DroppedItemUtil implements MinecraftAccess {
   private static final long a = 127644118950842L;
   private static final Object[] c = new Object[57];
   private static final String[] d = new String[57];

   public static boolean aReturningBoolean(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      long var1 = (Long)var0[1];
      var1 = 127644118950842L ^ var1;
      long var4 = var1 ^ 117841366975599L;
      int var10000 = Event.bReturningInt();
      int var6 = var10000;
      MinecraftClient var11 = b;
      ClientWorld var12 = var11.world;
      Iterable var13 = var12.getEntities();
      Iterator var8 = var13.iterator();

      int var38;
      while (true) {
         Iterator var14 = var8;
         boolean var42 = var14.hasNext();
         if (var42) {
            label63: {
               Iterator var15 = var8;
               Entity var9 = (Entity)var15.next();
               int var44 = var6;
               Entity var43 = var9;
               Entity var33 = var43;
               Entity var30 = var43;
               if (var44 == 0) {
                  byte var65 = ((byte)((var30 instanceof ItemEntity) ? 1 : 0));
                  int var46 = var6;
                  byte var45 = var65;
                  var38 = var45;
                  byte var31 = var45;
                  if (var46 != 0) {
                     break;
                  }

                  byte var47 = var31;
                  byte var32 = var47;
                  byte var48 = var32;
                  if (var48 == 0) {
                     break label63;
                  }

                  var33 = var9;
               }

               ItemEntity var10 = (ItemEntity)var33;
               ItemEntity var18 = var10;
               double var66 = var18.getY();
               BlockPos var19 = var3;
               double var68;
               var10000 = (var68 = var66 - var19.getY()) == 0.0 ? 0 : (var68 < 0.0 ? -1 : 1);
               int var50 = var6;
               int var49 = var10000;
               int var35 = var49;
               int var34 = var49;
               if (var50 == 0) {
                  int var51 = var34;
                  if (var51 < 0) {
                     continue;
                  }

                  ItemEntity var21 = var10;
                  ItemStack var22 = var21.getStack();
                  Object[] var23 = new Object[]{var22.getItem(), var4};
                  var35 = (((bReturningBoolean(var23)) ? 1 : 0));
               }

               int var53 = var6;
               int var52 = var35;
               int var37 = var52;
               int var36 = var52;
               if (var53 == 0) {
                  int var54 = var36;
                  if (var54 == 0) {
                     continue;
                  }

                  BlockPos var25 = var3;
                  Vec3d var27 = var25.toCenterPos();
                  ItemEntity var26 = var10;
                  double var28 = var26.squaredDistanceTo(var27);
                  double var69;
                  var37 = (var69 = Math.sqrt(var28) - 15.0) == 0.0 ? 0 : (var69 < 0.0 ? -1 : 1);
               }

               int var55 = var37;
               if (var55 > 0) {
                  int var56 = var6;
                  if (var56 == 0) {
                     continue;
                  }
               }

               var7++;
            }

            int var57 = var6;
            if (var57 == 0) {
               continue;
            }
         }

         var38 = var7;
         break;
      }

      int var59 = var6;
      int var58 = var38;
      int var40 = var58;
      int var39 = var58;
      int var41;
      if (var59 == 0) {
         byte var61 = 3;
         int var60 = var39;
         if (var60 > var61) {
            byte var62 = 1;
            var41 = var62;
         } else {
            var41 = 0;
         }
      } else {
         int var63 = var40;
         var41 = var63;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var41);
   }

   public static boolean bReturningBoolean(Object[] var0) {
      Item var3 = (Item)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 127644118950842L ^ var1;
      int var4 = Event.bReturningInt();
      Item var6 = Items.DIAMOND_HELMET;
      Item var5 = var3;
      byte var223 = ((byte)((var5.equals(var6)) ? 1 : 0));
      int var136 = var4;
      byte var135 = var223;
      byte var133 = var135;
      byte var90 = var135;
      if (var136 == 0) {
         byte var137 = var90;
         if (var137 == 0) {
            Item var9 = Items.DIAMOND_CHESTPLATE;
            Item var8 = var3;
            boolean var224 = var8.equals(var9);
            int var139 = var4;
            boolean var138 = var224;
            byte var245 = ((byte)((var138) ? 1 : 0));
            boolean var91 = var138;
            if (var139 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var245);
            }

            boolean var140 = var91;
            boolean var92 = var140;
            boolean var141 = var92;
            if (!var141) {
               Item var13 = Items.DIAMOND_LEGGINGS;
               Item var12 = var3;
               boolean var225 = var12.equals(var13);
               int var143 = var4;
               boolean var142 = var225;
               var245 = ((byte)((var142) ? 1 : 0));
               boolean var93 = var142;
               if (var143 != 0) {
                  return ((((int)(var245) & 1) != 0));
               }

               boolean var144 = var93;
               boolean var94 = var144;
               boolean var145 = var94;
               if (!var145) {
                  Item var17 = Items.DIAMOND_BOOTS;
                  Item var16 = var3;
                  boolean var226 = var16.equals(var17);
                  int var147 = var4;
                  boolean var146 = var226;
                  var245 = ((byte)((var146) ? 1 : 0));
                  boolean var95 = var146;
                  if (var147 != 0) {
                     return ((((int)(var245) & 1) != 0));
                  }

                  boolean var148 = var95;
                  boolean var96 = var148;
                  boolean var149 = var96;
                  if (!var149) {
                     Item var21 = Items.NETHERITE_HELMET;
                     Item var20 = var3;
                     boolean var227 = var20.equals(var21);
                     int var151 = var4;
                     boolean var150 = var227;
                     var245 = ((byte)((var150) ? 1 : 0));
                     boolean var97 = var150;
                     if (var151 != 0) {
                        return ((((int)(var245) & 1) != 0));
                     }

                     boolean var152 = var97;
                     boolean var98 = var152;
                     boolean var153 = var98;
                     if (!var153) {
                        Item var25 = Items.NETHERITE_CHESTPLATE;
                        Item var24 = var3;
                        boolean var228 = var24.equals(var25);
                        int var155 = var4;
                        boolean var154 = var228;
                        var245 = ((byte)((var154) ? 1 : 0));
                        boolean var99 = var154;
                        if (var155 != 0) {
                           return ((((int)(var245) & 1) != 0));
                        }

                        boolean var156 = var99;
                        boolean var100 = var156;
                        boolean var157 = var100;
                        if (!var157) {
                           Item var29 = Items.NETHERITE_LEGGINGS;
                           Item var28 = var3;
                           boolean var229 = var28.equals(var29);
                           int var159 = var4;
                           boolean var158 = var229;
                           var245 = ((byte)((var158) ? 1 : 0));
                           boolean var101 = var158;
                           if (var159 != 0) {
                              return ((((int)(var245) & 1) != 0));
                           }

                           boolean var160 = var101;
                           boolean var102 = var160;
                           boolean var161 = var102;
                           if (!var161) {
                              Item var33 = Items.NETHERITE_BOOTS;
                              Item var32 = var3;
                              boolean var230 = var32.equals(var33);
                              int var163 = var4;
                              boolean var162 = var230;
                              var245 = ((byte)((var162) ? 1 : 0));
                              boolean var103 = var162;
                              if (var163 != 0) {
                                 return ((((int)(var245) & 1) != 0));
                              }

                              boolean var164 = var103;
                              boolean var104 = var164;
                              boolean var165 = var104;
                              if (!var165) {
                                 Item var37 = Items.DIAMOND_PICKAXE;
                                 Item var36 = var3;
                                 boolean var231 = var36.equals(var37);
                                 int var167 = var4;
                                 boolean var166 = var231;
                                 var245 = ((byte)((var166) ? 1 : 0));
                                 boolean var105 = var166;
                                 if (var167 != 0) {
                                    return ((((int)(var245) & 1) != 0));
                                 }

                                 boolean var168 = var105;
                                 boolean var106 = var168;
                                 boolean var169 = var106;
                                 if (!var169) {
                                    Item var41 = Items.NETHERITE_PICKAXE;
                                    Item var40 = var3;
                                    boolean var232 = var40.equals(var41);
                                    int var171 = var4;
                                    boolean var170 = var232;
                                    var245 = ((byte)((var170) ? 1 : 0));
                                    boolean var107 = var170;
                                    if (var171 != 0) {
                                       return ((((int)(var245) & 1) != 0));
                                    }

                                    boolean var172 = var107;
                                    boolean var108 = var172;
                                    boolean var173 = var108;
                                    if (!var173) {
                                       Item var45 = Items.DIAMOND_SWORD;
                                       Item var44 = var3;
                                       boolean var233 = var44.equals(var45);
                                       int var175 = var4;
                                       boolean var174 = var233;
                                       var245 = ((byte)((var174) ? 1 : 0));
                                       boolean var109 = var174;
                                       if (var175 != 0) {
                                          return ((((int)(var245) & 1) != 0));
                                       }

                                       boolean var176 = var109;
                                       boolean var110 = var176;
                                       boolean var177 = var110;
                                       if (!var177) {
                                          Item var49 = Items.NETHERITE_SWORD;
                                          Item var48 = var3;
                                          boolean var234 = var48.equals(var49);
                                          int var179 = var4;
                                          boolean var178 = var234;
                                          var245 = ((byte)((var178) ? 1 : 0));
                                          boolean var111 = var178;
                                          if (var179 != 0) {
                                             return ((((int)(var245) & 1) != 0));
                                          }

                                          boolean var180 = var111;
                                          boolean var112 = var180;
                                          boolean var181 = var112;
                                          if (!var181) {
                                             Item var53 = Items.DIAMOND_AXE;
                                             Item var52 = var3;
                                             boolean var235 = var52.equals(var53);
                                             int var183 = var4;
                                             boolean var182 = var235;
                                             var245 = ((byte)((var182) ? 1 : 0));
                                             boolean var113 = var182;
                                             if (var183 != 0) {
                                                return ((((int)(var245) & 1) != 0));
                                             }

                                             boolean var184 = var113;
                                             boolean var114 = var184;
                                             boolean var185 = var114;
                                             if (!var185) {
                                                Item var57 = Items.NETHERITE_AXE;
                                                Item var56 = var3;
                                                boolean var236 = var56.equals(var57);
                                                int var187 = var4;
                                                boolean var186 = var236;
                                                var245 = ((byte)((var186) ? 1 : 0));
                                                boolean var115 = var186;
                                                if (var187 != 0) {
                                                   return ((((int)(var245) & 1) != 0));
                                                }

                                                boolean var188 = var115;
                                                boolean var116 = var188;
                                                boolean var189 = var116;
                                                if (!var189) {
                                                   Item var61 = Items.TOTEM_OF_UNDYING;
                                                   Item var60 = var3;
                                                   boolean var237 = var60.equals(var61);
                                                   int var191 = var4;
                                                   boolean var190 = var237;
                                                   var245 = ((byte)((var190) ? 1 : 0));
                                                   boolean var117 = var190;
                                                   if (var191 != 0) {
                                                      return ((((int)(var245) & 1) != 0));
                                                   }

                                                   boolean var192 = var117;
                                                   boolean var118 = var192;
                                                   boolean var193 = var118;
                                                   if (!var193) {
                                                      Item var65 = Items.GOLDEN_APPLE;
                                                      Item var64 = var3;
                                                      boolean var238 = var64.equals(var65);
                                                      int var195 = var4;
                                                      boolean var194 = var238;
                                                      var245 = ((byte)((var194) ? 1 : 0));
                                                      boolean var119 = var194;
                                                      if (var195 != 0) {
                                                         return ((((int)(var245) & 1) != 0));
                                                      }

                                                      boolean var196 = var119;
                                                      boolean var120 = var196;
                                                      boolean var197 = var120;
                                                      if (!var197) {
                                                         Item var69 = Items.ENCHANTED_GOLDEN_APPLE;
                                                         Item var68 = var3;
                                                         boolean var239 = var68.equals(var69);
                                                         int var199 = var4;
                                                         boolean var198 = var239;
                                                         var245 = ((byte)((var198) ? 1 : 0));
                                                         boolean var121 = var198;
                                                         if (var199 != 0) {
                                                            return ((((int)(var245) & 1) != 0));
                                                         }

                                                         boolean var200 = var121;
                                                         boolean var122 = var200;
                                                         boolean var201 = var122;
                                                         if (!var201) {
                                                            Item var73 = Items.ENDER_PEARL;
                                                            Item var72 = var3;
                                                            boolean var240 = var72.equals(var73);
                                                            int var203 = var4;
                                                            boolean var202 = var240;
                                                            var245 = ((byte)((var202) ? 1 : 0));
                                                            boolean var123 = var202;
                                                            if (var203 != 0) {
                                                               return ((((int)(var245) & 1) != 0));
                                                            }

                                                            boolean var204 = var123;
                                                            boolean var124 = var204;
                                                            boolean var205 = var124;
                                                            if (!var205) {
                                                               Item var77 = Items.EXPERIENCE_BOTTLE;
                                                               Item var76 = var3;
                                                               boolean var241 = var76.equals(var77);
                                                               int var207 = var4;
                                                               boolean var206 = var241;
                                                               var245 = ((byte)((var206) ? 1 : 0));
                                                               boolean var125 = var206;
                                                               if (var207 != 0) {
                                                                  return ((((int)(var245) & 1) != 0));
                                                               }

                                                               boolean var208 = var125;
                                                               boolean var126 = var208;
                                                               boolean var209 = var126;
                                                               if (!var209) {
                                                                  Item var81 = Items.END_CRYSTAL;
                                                                  Item var80 = var3;
                                                                  boolean var242 = var80.equals(var81);
                                                                  int var211 = var4;
                                                                  boolean var210 = var242;
                                                                  var245 = ((byte)((var210) ? 1 : 0));
                                                                  boolean var127 = var210;
                                                                  if (var211 != 0) {
                                                                     return ((((int)(var245) & 1) != 0));
                                                                  }

                                                                  boolean var212 = var127;
                                                                  boolean var128 = var212;
                                                                  boolean var213 = var128;
                                                                  if (!var213) {
                                                                     Item var85 = Items.RESPAWN_ANCHOR;
                                                                     Item var84 = var3;
                                                                     boolean var243 = var84.equals(var85);
                                                                     int var215 = var4;
                                                                     boolean var214 = var243;
                                                                     var245 = ((byte)((var214) ? 1 : 0));
                                                                     boolean var129 = var214;
                                                                     if (var215 != 0) {
                                                                        return ((((int)(var245) & 1) != 0));
                                                                     }

                                                                     boolean var216 = var129;
                                                                     boolean var130 = var216;
                                                                     boolean var217 = var130;
                                                                     if (!var217) {
                                                                        Item var89 = Items.GLOWSTONE;
                                                                        Item var88 = var3;
                                                                        byte var244 = ((byte)((var88.equals(var89)) ? 1 : 0));
                                                                        int var219 = var4;
                                                                        byte var218 = var244;
                                                                        var245 = var218;
                                                                        byte var131 = var218;
                                                                        if (var219 != 0) {
                                                                           return dev.prestige.recovery.SourceSupport.asBoolean(var245);
                                                                        }

                                                                        byte var220 = var131;
                                                                        byte var132 = var220;
                                                                        byte var221 = var132;
                                                                        if (var221 == 0) {
                                                                           return false;
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         var133 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var133);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 4;
            yield var15;
         }
         case 1 -> {
            byte var16 = 31;
            yield var16;
         }
         case 2 -> {
            byte var17 = 38;
            yield var17;
         }
         case 3 -> {
            byte var18 = 19;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 34;
            yield var21;
         }
         case 7 -> {
            byte var22 = 11;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 26;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 15;
            yield var26;
         }
         case 12 -> {
            byte var27 = 32;
            yield var27;
         }
         case 13 -> {
            byte var28 = 21;
            yield var28;
         }
         case 14 -> {
            byte var29 = 2;
            yield var29;
         }
         case 15 -> {
            byte var30 = 36;
            yield var30;
         }
         case 16 -> {
            byte var31 = 56;
            yield var31;
         }
         case 17 -> {
            byte var32 = 54;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 1;
            yield var35;
         }
         case 21 -> {
            byte var36 = 55;
            yield var36;
         }
         case 22 -> {
            byte var37 = 35;
            yield var37;
         }
         case 23 -> {
            byte var38 = 51;
            yield var38;
         }
         case 24 -> {
            byte var39 = 17;
            yield var39;
         }
         case 25 -> {
            byte var40 = 50;
            yield var40;
         }
         case 26 -> {
            byte var41 = 7;
            yield var41;
         }
         case 27 -> {
            byte var42 = 16;
            yield var42;
         }
         case 28 -> {
            byte var43 = 46;
            yield var43;
         }
         case 29 -> {
            byte var44 = 29;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 3;
            yield var46;
         }
         case 32 -> {
            byte var47 = 10;
            yield var47;
         }
         case 33 -> {
            byte var48 = 49;
            yield var48;
         }
         case 34 -> {
            byte var49 = 27;
            yield var49;
         }
         case 35 -> {
            byte var50 = 37;
            yield var50;
         }
         case 36 -> {
            byte var51 = 43;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 61;
            yield var54;
         }
         case 40 -> {
            byte var55 = 42;
            yield var55;
         }
         case 41 -> {
            byte var56 = 45;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 62;
            yield var59;
         }
         case 45 -> {
            byte var60 = 39;
            yield var60;
         }
         case 46 -> {
            byte var61 = 20;
            yield var61;
         }
         case 47 -> {
            byte var62 = 41;
            yield var62;
         }
         case 48 -> {
            byte var63 = 18;
            yield var63;
         }
         case 49 -> {
            byte var64 = 24;
            yield var64;
         }
         case 50 -> {
            byte var65 = 58;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 52;
            yield var67;
         }
         case 53 -> {
            byte var68 = 8;
            yield var68;
         }
         case 54 -> {
            byte var69 = 60;
            yield var69;
         }
         case 55 -> {
            byte var70 = 47;
            yield var70;
         }
         case 56 -> {
            byte var71 = 28;
            yield var71;
         }
         case 57 -> {
            byte var72 = 5;
            yield var72;
         }
         case 58 -> {
            byte var73 = 44;
            yield var73;
         }
         case 59 -> {
            byte var74 = 30;
            yield var74;
         }
         case 60 -> {
            byte var75 = 14;
            yield var75;
         }
         case 61 -> {
            byte var76 = 6;
            yield var76;
         }
         case 62 -> {
            byte var77 = 23;
            yield var77;
         }
         default -> 9;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "I \f*4~I \u001bv8qSk\u001bh8dT\u001aI<i%";
      c[1] = ":\u000b1uaA:\u000b&)mN @&7m['1tl5\u001a";
      c[2] = "\u001bJ\u001d=\\j\rJ\u0018gO}\u001a\u0001\u001baCi\u000bF\fv\b{:";
      c[3] = int.class;
      d[3] = "java/lang/Integer";
      c[4] = "l\u001eg\u0004/pg\u0011vKN~l\u001ar\u0011";
      c[5] = boolean.class;
      d[5] = "java/lang/Boolean";
      c[6] = "\n\u001f?x=\n\u001c\u001f:\".\u001d\u000bT9$\"\t\u001a\u0013.3i\u001d\u000f";
      c[7] = "k\u001fy]'\u0015`\u0010h\u0012D\u0018u\u001dgyq\u001ad\u000e{Uf\u0017";
      c[8] = "002QVwE\u00109^G8$\u001e2UCbP";
      c[9] = "\u0011W\u001a\u001b8P\u0011W\rG4_\u000b\u001c\rY4J\fm_\u0000a\u000b";
      c[10] = double.class;
      d[10] = "java/lang/Double";
      c[11] = "C~\u0013!&\u0007Hq\u0002nA\u001fLm\u0004\"d\u000e";
      c[12] = "\u0017^Trmm\tVN=\nl\u0018MCg,j";
      c[13] = "m,.r%Dm,9.)Kwg90)^p\u0016kkq\u0014";
      c[14] = "\\\u001b]\t6(\\\u001bJU:'FPJK:2A!\u001b\u0014hy";
      c[15] = "i|\f\u001dD i|\u001bAH/s7\u001b_H:tFK\u0002\u0019";
      c[16] = "\u0011G1]J\u0019\u0011G&\u0001F\u0016\u000b\f&\u001fF\u0003\f}s@\u001f";
      c[17] = "5\u0012\u0001=1\u000b5\u0012\u0016a=\u0004/Y\u0016\u007f=\u0011((G'o";
      c[18] = "Wr\u00076>X\\}\u0016y]UI{";
      c[19] = "\u0011\u0015P\u000bL\u0013\u0014\u0019\u0012L \u0003-OK@L\u0005\u0011O_APi\u0016\f@\u0000I\u000eQ\n\u001e\u001e ";
      c[20] = "S \u00029I\u0005U5\u0005XAY^8\u0004\u000f\u001f\u0005\u000ebha\u0014\u0001O9\u0016$\u0014BN";
      c[21] = "O#hs\n@I6o\u0012\u0002\u001cB;nEVG\u0017e8\u0012UF\u0016#gl\u0010FU\"";
      c[22] = "\u0018iN9\t'X7Jhw#!<\u001a7\n-O:\u0013)\u001cI";
      c[23] = "H+?\u001aZ\u0007\u000b<e\u00130\u000e\u001b1c\u001a\\<Lv8D\u0000kI,e\u001cS\u0014\u000e|b\u000f0";
      c[24] = "\u0018i;;5`\u001e|<Z=<\u0015q=\rcgH*Qchd\u0004p/&h'\u0005";
      c[25] = "4#{\u0011\n*a8s\u00044/h?}\u0013X\u001d:r%E4s>za\u0011J6>9`t";
      c[26] = "\u0000e\u000em\u001e'\u0006p\t\f\u0016{\r}\b[B X#X\fA!Ye\u0001r\u0004!\u001ad";
      c[27] = "fa\u0012\u000e\n8`t\u0015o\u0002dky\u00148\\>9\"xVW<zx\u0006\u0013W\u007f{";
      c[28] = "\u001dmM\\1=UsTV\u000fiAcQ\\c[\u0015'\u000b\u00053\f\u0016rQFkb\u0010{OP\u000f";
      c[29] = "K,64R6\u0014x898:\u001614P\u00032\u001cp.,Z0K.H";
      c[30] = "&.@uf# ;G\u0014n\u007f+6FC0$vo*-;':7Th;d;";
      c[31] = "\u0010\u0000-\u0019fD\u0016\u0015*xn\u0018\u001d\u0018+/:CHFwx9BI\u0000\"\u0006|B\n\u0001";
      c[32] = "T8'x\f\u0005\r:p&j\u0014\u0016+)-\u0011yT8'x\f\u0005\r:p&jB\u001190 \r\u0005\u0017g.I";
      c[33] = "\u001d0\u0015_K9\u001b%\u0012>Ce\u0010(\u0013i\u001d?Eu\u007f\u0007\u0016=\u0001)\u0001B\u0016~\u0000";
      c[34] = "*&4<w8,33]\u007fd'>2\n!>vj^d*<6? !*\u007f7";
      c[35] = "b\u001c5\u001bqYd\t2zy\u0005o\u00043--^:Znz._;\u001c:\u0004k_x\u001d";
      c[36] = "N<79NpH)0XF,C$1\u000f\u0018s\u0015|]a\u0013tR%#$\u00137S";
      c[37] = "\u000b1I\u001b\u0012~\u001c.\nM/|\u00191Lt\u0010f\u0006*S\u000bW6\u000190KNa\u0001(O\f\u001ef\u0012K";
      c[38] = "l\u0007F\u00198R3SH\u0014RX5\u0011~\u0010\"D\\QF\u0012\"Q;\u0016@L<8";
      c[39] = "\u000fh\u001eK\u0003T\nd\\\foG32QH\rIBa\u0002P\u0016.\u000e?\u0019R\b_]l\u0001Io";
      c[40] = "Lp)\u001fg=Hp2\u0010\u0007f\u000fa)F{`\t\fcByc\u0019f<\u0016wns";
      c[41] = "G;pW7-A.w6?qJ#vaa*\u0017w\u001a\u000fj)[\"dJjjZ";
      c[42] = "HJ{r[:N_|\u0013SfER}D\r7\u0010\u000b\u0011*\u0006>TSoo\u0006}U";
      c[43] = "\u007fE\u0006\u0004yLyP\u0001eq\u0010r]\u00002%J&\u0005Ue&J&E\t\u001bcJeD";
      c[44] = "m\u000f\r\u0010EMk\u001a\nqM\u0011`\u0017\u000b&\u0019J5IXq\u001aK4\u000f\u0002\u000f_Kw\u000e";
      c[45] = "B\u0015\u001en\u0001TD\u0000\u0019\u000f\t\bO\r\u0018X]S\u001aRL\u000f^R\u001b\u0015\u0011q\u001bRX\u0014";
      c[46] = "noKP\u001aGm%[\u0004uYfyD\u0005\"\u000e9$\u001fi\u001fR9i\u0019\u0019LTco";
      c[47] = "\u0004\u0007\tg\u0003XL\u0019\u0010m=\fX\t\u0015gQ>\tKH=\ri^NIf]V\u000e\u0005\u0017x=";
      c[48] = "\u0003YO#]X\u0005LHBU\u0004\u000eAI\u0015\u000bY]\u001e%{\u0000\\\u001f@[>\u0000\u001f\u001e";
      c[49] = "\u0000.2y^*\u0006;5\u0018Vv\r64O\b/]bX!\u0003.\u001c7&d\u0003m\u001d";
      c[50] = "~lsB\n@xyt#\u0002\u001cstut\\M&)\u0019\u001aWDbug_W\u0007c";
      c[51] = "NwD\u000eEP\r`\u001e\u0007/Y\u001dm\u0018\u000eCkN HR/\r\u0010w\u001dWOX\u000b\u007f\bi";
      c[52] = "-<>;\u0010B+)9Z\u0018\u001e $8\rFOuzTcMF1%*&M\u00050";
      c[53] = "{\u0015S\u001a#R}\u0000T{+\u000ev\rU,uT%V9B~Vg\fG\u0007~\u0015f";
      c[54] = "8Ffy{D>Sa\u0018s\u00185^`O'C`\u00001\u0018$BaFifaB\"G";
      c[55] = "U;CRN\u001f\u0006=\u0019Tw\nR\"\u001dH\u001b8\u0006nD\u0016Mo\u0000\"\u0007\u001f\u0017U\u0004\"\u001c\u0010w";
      c[56] = "\\\u0014Rf#&\u001f\u0003\boI/\u000f\u000e\u000ef%\u001d_MV>I!YN\bavq\u0012\u0010\u0016\u0001v+\u0004\u0013\r~1{\u0003\u0000n";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(348898289930944L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(348898289930944L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(348898289930944L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 253;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 120;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 251;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 203;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 235;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 236;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 253;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 120;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 251;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ga_C0326",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ga" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
