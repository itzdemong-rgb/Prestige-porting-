package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.DoubleUnaryOperator;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum Easing {
   LINEAR(invokeBinding2()),
   SINE_IN(invokeBinding3()),
   SINE_OUT(invokeBinding4()),
   SINE_IN_OUT(invokeBinding5()),
   CUBIC_IN(invokeBinding6()),
   CUBIC_OUT(invokeBinding7()),
   CUBIC_IN_OUT(invokeBinding8()),
   QUAD_IN(invokeBinding9()),
   QUAD_OUT(invokeBinding10()),
   QUAD_IN_OUT(invokeBinding11()),
   QUART_IN(invokeBinding12()),
   QUART_OUT(invokeBinding13()),
   QUART_IN_OUT(invokeBinding14()),
   QUINT_IN(invokeBinding15()),
   QUINT_OUT(invokeBinding16()),
   QUINT_IN_OUT(invokeBinding17()),
   CIRC_IN(invokeBinding18()),
   CIRC_OUT(invokeBinding19()),
   CIRC_IN_OUT(invokeBinding20()),
   EXPO_IN(invokeBinding21()),
   EXPO_OUT(invokeBinding22()),
   EXPO_IN_OUT(invokeBinding23()),
   ELASTIC_IN(invokeBinding24()),
   ELASTIC_OUT(invokeBinding25()),
   ELASTIC_IN_OUT(invokeBinding26()),
   BACK_IN(invokeBinding27()),
   BACK_OUT(invokeBinding28()),
   BACK_IN_OUT(invokeBinding29());
   private final DoubleUnaryOperator a;
   private static final Easing[] b;
   private static final long c = 106677562987092L;
   private static final long[] d;
   private static final Integer[] e;
   private static final Map f;
   private static final Object[] g = new Object[23];
   private static final String[] h = new String[23];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;

   public static Easing valueOf(String var0, long var1) {
      var1 = 106677562987092L ^ var1;
      return (Easing)invokeBinding1(Easing.class, var0, -4239622029088552126L, var1);
   }

   Easing(DoubleUnaryOperator var3) {
      this.a = var3;
   }

   public double aReturningDouble(Object[] var1) {
      double var2 = (Double)var1[0];
      long var4 = (Long)var1[1];
      long var10000 = 106677562987092L ^ var4;
      double var7 = var2;
      DoubleUnaryOperator var6 = this.a;
      return var6.applyAsDouble(var7);
   }

   private static double lambda$static$27(double var0) {
      int var4 = Event.bReturningInt();
      int var29 = var4;
      double var27 = 0.5;
      double var25 = var0;
      double var19 = var25;
      double var21 = var27;
      double var15 = var25;
      double var17 = var27;
      if (var29 == 0) {
         double var35;
         int var30 = (var35 = var15 - var17) == 0.0 ? 0 : (var35 < 0.0 ? -1 : 1);
         if (var30 < 0) {
            double var34 = 2.0 * var0;
            double var8 = 2.0;
            double var6 = var34;
            return Math.pow(var6, var8) * (7.189819 * var0 - 2.5949095) / 2.0;
         }

         double var10000 = 2.0 * var0 - 2.0;
         double var13 = 2.0;
         double var11 = var10000;
         var10000 = Math.pow(var11, var13) * (3.5949095 * (var0 * 2.0 - 2.0) + 2.5949095) + 2.0;
         var21 = 2.0;
         var19 = var10000;
      }

      return var19 / var21;
   }

   private static double lambda$static$26(double var0) {
      double var10002 = var0 - 1.0;
      double var6 = 3.0;
      double var4 = var10002;
      double var10000 = 1.0 + 2.70158 * Math.pow(var4, var6);
      var10002 = var0 - 1.0;
      double var10 = 2.0;
      double var8 = var10002;
      return var10000 + 1.70158 * Math.pow(var8, var10);
   }

   private static double lambda$static$25(double var0) {
      return 2.70158 * var0 * var0 * var0 - 1.70158 * var0 * var0;
   }

   private static double lambda$static$24(double var0) {
      int var4 = Event.cReturningInt();
      double var59;
      int var10000 = (var59 = var0 - 0.0) == 0.0 ? 0 : (var59 < 0.0 ? -1 : 1);
      int var38 = var4;
      int var37 = var10000;
      int var24 = var37;
      int var23 = var37;
      if (var38 != 0) {
         int var39 = var23;
         if (var39 == 0) {
            return 0.0;
         }

         double var60;
         var24 = (var60 = var0 - 1.0) == 0.0 ? 0 : (var60 < 0.0 ? -1 : 1);
      }

      int var43 = var4;
      int var42 = var24;
      int var30 = var42;
      int var25 = var42;
      if (var43 != 0) {
         int var44 = var25;
         if (var44 == 0) {
            return 1.0;
         }

         int var51 = var4;
         double var49 = 0.5;
         double var47 = var0;
         double var31 = var47;
         double var33 = var49;
         double var26 = var47;
         double var28 = var49;
         if (var51 == 0) {
            return var31 + var33;
         }

         double var61;
         int var52 = (var61 = var26 - var28) == 0.0 ? 0 : (var61 < 0.0 ? -1 : 1);
         var30 = var52;
      }

      int var53 = var30;
      if (var53 < 0) {
         double var12 = 20.0 * var0 - 10.0;
         double var10 = 2.0;
         double var58 = Math.pow(var10, var12);
         double var14 = (20.0 * var0 - 11.125) * (Math.PI * 4.0 / 9.0);
         return -(var58 * Math.sin(var14)) / 2.0;
      } else {
         double var19 = -20.0 * var0 + 10.0;
         double var17 = 2.0;
         double var56 = Math.pow(var17, var19);
         double var21 = (20.0 * var0 - 11.125) * (Math.PI * 4.0 / 9.0);
         double var57 = var56 * Math.sin(var21) / 2.0;
         double var63 = 1.0;
         double var62 = var57;
         return var62 + var63;
      }
   }

   private static double lambda$static$23(double var0) {
      int var4 = Event.bReturningInt();
      double var43;
      int var10000 = (var43 = var0 - 0.0) == 0.0 ? 0 : (var43 < 0.0 ? -1 : 1);
      int var28 = var4;
      int var27 = var10000;
      int var20 = var27;
      int var15 = var27;
      if (var28 == 0) {
         int var29 = var15;
         if (!((var29) != 0)) {
            return 0.0;
         }

         int var36 = var4;
         double var34 = 1.0;
         double var32 = var0;
         double var21 = var32;
         double var23 = var34;
         double var16 = var32;
         double var18 = var34;
         if (var36 != 0) {
            return var21 + var23;
         }

         double var44;
         int var37 = (var44 = var16 - var18) == 0.0 ? 0 : (var44 < 0.0 ? -1 : 1);
         var20 = var37;
      }

      int var38 = var20;
      if (!((var38) != 0)) {
         return 1.0;
      }

      double var11 = -10.0 * var0;
      double var9 = 2.0;
      double var41 = Math.pow(var9, var11);
      double var13 = (var0 * 10.0 - 0.75) * (Math.PI * 2.0 / 3.0);
      double var42 = var41 * Math.sin(var13);
      double var46 = 1.0;
      double var45 = var42;
      return var45 + var46;
   }

   private static double lambda$static$22(double var0) {
      int var4 = Event.cReturningInt();
      double var42;
      int var10000 = (var42 = var0 - 0.0) == 0.0 ? 0 : (var42 < 0.0 ? -1 : 1);
      int var28 = var4;
      int var27 = var10000;
      int var20 = var27;
      int var15 = var27;
      if (var28 != 0) {
         int var29 = var15;
         if (!((var29) != 0)) {
            return 0.0;
         }

         int var36 = var4;
         double var34 = 1.0;
         double var32 = var0;
         double var21 = var32;
         double var23 = var34;
         double var16 = var32;
         double var18 = var34;
         if (var36 == 0) {
            return var21 * var23;
         }

         double var43;
         int var37 = (var43 = var16 - var18) == 0.0 ? 0 : (var43 < 0.0 ? -1 : 1);
         var20 = var37;
      }

      int var38 = var20;
      if (!((var38) != 0)) {
         return 1.0;
      }

      double var11 = 10.0 * var0 - 10.0;
      double var9 = 2.0;
      double var41 = -Math.pow(var9, var11);
      double var13 = (var0 * 10.0 - 10.75) * (Math.PI * 2.0 / 3.0);
      double var45 = Math.sin(var13);
      double var44 = var41;
      return var44 * var45;
   }

   private static double lambda$static$21(double var0) {
      int var4 = Event.bReturningInt();
      double var53;
      int var10000 = (var53 = var0 - 0.0) == 0.0 ? 0 : (var53 < 0.0 ? -1 : 1);
      int var34 = var4;
      int var33 = var10000;
      int var20 = var33;
      int var19 = var33;
      if (var34 == 0) {
         int var35 = var19;
         if (var35 == 0) {
            return 0.0;
         }

         double var54;
         var20 = (var54 = var0 - 1.0) == 0.0 ? 0 : (var54 < 0.0 ? -1 : 1);
      }

      int var39 = var4;
      int var38 = var20;
      int var26 = var38;
      int var21 = var38;
      if (var39 == 0) {
         int var40 = var21;
         if (var40 == 0) {
            return 1.0;
         }

         int var47 = var4;
         double var45 = 0.5;
         double var43 = var0;
         double var27 = var43;
         double var29 = var45;
         double var22 = var43;
         double var24 = var45;
         if (var47 != 0) {
            return var27 / var29;
         }

         double var55;
         int var48 = (var55 = var22 - var24) == 0.0 ? 0 : (var55 < 0.0 ? -1 : 1);
         var26 = var48;
      }

      int var49 = var26;
      if (var49 < 0) {
         double var12 = 20.0 * var0 - 10.0;
         double var10 = 2.0;
         return Math.pow(var10, var12) / 2.0;
      } else {
         double var17 = -20.0 * var0 + 10.0;
         double var15 = 2.0;
         double var52 = 2.0 - Math.pow(var15, var17);
         double var57 = 2.0;
         double var56 = var52;
         return var56 / var57;
      }
   }

   private static double lambda$static$20(double var0) {
      int var4 = Event.bReturningInt();
      int var25 = var4;
      double var23 = 1.0;
      double var21 = var0;
      double var15 = var21;
      double var17 = var23;
      double var11 = var21;
      double var13 = var23;
      if (var25 == 0) {
         double var29;
         int var26 = (var29 = var11 - var13) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
         if (!((var26) != 0)) {
            return 1.0;
         }

         double var9 = -10.0 * var0;
         double var7 = 2.0;
         var17 = Math.pow(var7, var9);
         var15 = 1.0;
      }

      return var15 - var17;
   }

   private static double lambda$static$19(double var0) {
      int var4 = Event.bReturningInt();
      int var25 = var4;
      double var21 = var0;
      double var15 = var21;
      double var17 = var23;
      double var11 = var21;
      double var13 = var23;
      if (var25 == 0) {
         double var29;
         int var26 = (var29 = var11 - var13) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
         if (!((var26) != 0)) {
            return 0.0;
         }

         var17 = 10.0 * var0 - 10.0;
         var15 = 2.0;
      }

      double var9 = var17;
      double var7 = var15;
      return Math.pow(var7, var9);
   }

   private static double lambda$static$18(double var0) {
      int var4 = Event.cReturningInt();
      int var33 = var4;
      double var31 = 0.5;
      double var29 = var0;
      double var23 = var29;
      double var25 = var31;
      double var19 = var29;
      double var21 = var31;
      if (var33 != 0) {
         double var37;
         int var34 = (var37 = var19 - var21) == 0.0 ? 0 : (var37 < 0.0 ? -1 : 1);
         if (var34 < 0) {
            double var10002 = 2.0 * var0;
            double var8 = 2.0;
            double var6 = var10002;
            double var10 = 1.0 - Math.pow(var6, var8);
            return (1.0 - Math.sqrt(var10)) / 2.0;
         }

         double var10001 = -2.0 * var0 + 2.0;
         double var15 = 2.0;
         double var13 = var10001;
         double var17 = 1.0 - Math.pow(var13, var15);
         double var10000 = Math.sqrt(var17) + 1.0;
         var25 = 2.0;
         var23 = var10000;
      }

      return var23 / var25;
   }

   private static double lambda$static$17(double var0) {
      double var10001 = var0 - 1.0;
      double var6 = 2.0;
      double var4 = var10001;
      double var8 = 1.0 - Math.pow(var4, var6);
      return Math.sqrt(var8);
   }

   private static double lambda$static$16(double var0) {
      double var6 = 2.0;
      double var4 = var0;
      double var8 = 1.0 - Math.pow(var4, var6);
      return 1.0 - Math.sqrt(var8);
   }

   private static double lambda$static$15(double var0) {
      int var4 = Event.cReturningInt();
      int var25 = var4;
      double var23 = 0.5;
      double var21 = var0;
      double var15 = var21;
      double var17 = var23;
      double var11 = var21;
      double var13 = var23;
      if (var25 != 0) {
         double var29;
         int var26 = (var29 = var11 - var13) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
         if (var26 < 0) {
            return 16.0 * var0 * var0 * var0 * var0 * var0;
         }

         double var10001 = -2.0 * var0 + 2.0;
         double var9 = 5.0;
         double var7 = var10001;
         var17 = Math.pow(var7, var9) / 2.0;
         var15 = 1.0;
      }

      return var15 - var17;
   }

   private static double lambda$static$14(double var0) {
      double var10001 = 1.0 - var0;
      double var6 = 5.0;
      double var4 = var10001;
      return 1.0 - Math.pow(var4, var6);
   }

   private static double lambda$static$13(double var0) {
      return var0 * var0 * var0 * var0 * var0;
   }

   private static double lambda$static$12(double var0) {
      int var4 = Event.bReturningInt();
      int var25 = var4;
      double var23 = 0.5;
      double var21 = var0;
      double var15 = var21;
      double var17 = var23;
      double var11 = var21;
      double var13 = var23;
      if (var25 == 0) {
         double var29;
         int var26 = (var29 = var11 - var13) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
         if (var26 < 0) {
            return 8.0 * var0 * var0 * var0 * var0;
         }

         double var10001 = -2.0 * var0 + 2.0;
         double var9 = 4.0;
         double var7 = var10001;
         var17 = Math.pow(var7, var9) / 2.0;
         var15 = 1.0;
      }

      return var15 - var17;
   }

   private static double lambda$static$11(double var0) {
      double var10001 = 1.0 - var0;
      double var6 = 4.0;
      double var4 = var10001;
      return 1.0 - Math.pow(var4, var6);
   }

   private static double lambda$static$10(double var0) {
      return var0 * var0 * var0 * var0;
   }

   private static double lambda$static$9(double var0) {
      int var4 = Event.cReturningInt();
      int var25 = var4;
      double var23 = 0.5;
      double var21 = var0;
      double var15 = var21;
      double var17 = var23;
      double var11 = var21;
      double var13 = var23;
      if (var25 != 0) {
         double var29;
         int var26 = (var29 = var11 - var13) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
         if (var26 < 0) {
            return 2.0 * var0 * var0;
         }

         double var10001 = -2.0 * var0 + 2.0;
         double var9 = 2.0;
         double var7 = var10001;
         var17 = Math.pow(var7, var9) / 2.0;
         var15 = 1.0;
      }

      return var15 - var17;
   }

   private static double lambda$static$8(double var0) {
      return 1.0 - (1.0 - var0) * (1.0 - var0);
   }

   private static double lambda$static$7(double var0) {
      return var0 * var0;
   }

   private static double lambda$static$6(double var0) {
      int var4 = Event.bReturningInt();
      int var25 = var4;
      double var23 = 0.5;
      double var21 = var0;
      double var15 = var21;
      double var17 = var23;
      double var11 = var21;
      double var13 = var23;
      if (var25 == 0) {
         double var29;
         int var26 = (var29 = var11 - var13) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
         if (var26 < 0) {
            return 4.0 * var0 * var0 * var0;
         }

         double var10001 = -2.0 * var0 + 2.0;
         double var9 = 3.0;
         double var7 = var10001;
         var17 = Math.pow(var7, var9) / 2.0;
         var15 = 1.0;
      }

      return var15 - var17;
   }

   private static double lambda$static$5(double var0) {
      double var10001 = 1.0 - var0;
      double var6 = 3.0;
      double var4 = var10001;
      return 1.0 - Math.pow(var4, var6);
   }

   private static double lambda$static$4(double var0) {
      return var0 * var0 * var0;
   }

   private static double lambda$static$3(double var0) {
      double var4 = Math.PI * var0;
      return -(Math.cos(var4) - 1.0) / 2.0;
   }

   private static double lambda$static$2(double var0) {
      double var4 = var0 * Math.PI / 2.0;
      return Math.sin(var4);
   }

   private static double lambda$static$1(double var0) {
      double var4 = var0 * Math.PI / 2.0;
      return 1.0 - Math.cos(var4);
   }

   private static double lambda$static$0(double var0) {
      return var0;
   }

   private static Easing[] aReturningArrayOfl_C0424(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 106677562987092L ^ var1;
      short var10000 = 26472;
      long var10001 = 6404726631254515854L ^ var1;
      Easing[] var4 = new Easing[]{
         LINEAR,
         SINE_IN,
         SINE_OUT,
         SINE_IN_OUT,
         CUBIC_IN,
         CUBIC_OUT,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null
      };
      short var10002 = 30974;
      long var10003 = 6941606837042904849L ^ var1;
      var4[6] = CUBIC_IN_OUT;
      var10002 = 22541;
      var10003 = 9205148827423236092L ^ var1;
      var4[7] = QUAD_IN;
      var10002 = 11136;
      var10003 = 7379826693799226482L ^ var1;
      var4[8] = QUAD_OUT;
      var10002 = 15186;
      var10003 = 1268575240618196139L ^ var1;
      var4[9] = QUAD_IN_OUT;
      var10002 = 14310;
      var10003 = 8211465104987729942L ^ var1;
      var4[10] = QUART_IN;
      var10002 = 8894;
      var10003 = 964052690563278191L ^ var1;
      var4[11] = QUART_OUT;
      var10002 = 8187;
      var10003 = 5153131269301704740L ^ var1;
      var4[12] = QUART_IN_OUT;
      var10002 = 20321;
      var10003 = 4815251462606866611L ^ var1;
      var4[13] = QUINT_IN;
      var10002 = 3051;
      var10003 = 5548481792498371584L ^ var1;
      var4[14] = QUINT_OUT;
      var10002 = 17549;
      var10003 = 8221029485848249193L ^ var1;
      var4[15] = QUINT_IN_OUT;
      var10002 = 30567;
      var10003 = 4865741360826708100L ^ var1;
      var4[16] = CIRC_IN;
      var10002 = 23868;
      var10003 = 2882212188170803921L ^ var1;
      var4[17] = CIRC_OUT;
      var10002 = 5028;
      var10003 = 8570547302024942714L ^ var1;
      var4[18] = CIRC_IN_OUT;
      var10002 = 26938;
      var10003 = 3548881930027298510L ^ var1;
      var4[19] = EXPO_IN;
      var10002 = 595;
      var10003 = 535171304556561829L ^ var1;
      var4[20] = EXPO_OUT;
      var10002 = 23018;
      var10003 = 2786576635792055819L ^ var1;
      var4[21] = EXPO_IN_OUT;
      var10002 = 22495;
      var10003 = 9158253817739890751L ^ var1;
      var4[22] = ELASTIC_IN;
      var10002 = 1262;
      var10003 = 8664428845571474178L ^ var1;
      var4[23] = ELASTIC_OUT;
      var10002 = 9317;
      var10003 = 1501039003053892482L ^ var1;
      var4[24] = ELASTIC_IN_OUT;
      var10002 = 3330;
      var10003 = 6002058877658073824L ^ var1;
      var4[25] = BACK_IN;
      var10002 = 4076;
      var10003 = 2994855432248264727L ^ var1;
      var4[26] = BACK_OUT;
      var10002 = 15473;
      var10003 = 3279075452187098023L ^ var1;
      var4[27] = BACK_IN_OUT;
      return var4;
   }

   static {

      {

      long var10001 = 64146706953038L ^ 102886144519972L;
      aReturningVoid();
      Cipher var12;
      Cipher var10000 = var12 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var13 = 1; var13 < 8; var13++) {
         var10003[var13] = (byte)(64146706953038L << var13 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var11 = new String[28];
      String var16 = "O\u001d=ÿ¹_\u0086MrÎ:=H=\u007fç\u001000w;w?\u008bÑ\\^\u007fR³]`\u0089\u0010IZËÓÂvt\u0083\"+ªf\u0095¾\u0099%\u0010rC\fÂ\u0011x\n\u0083·\u0014>\u001b%êz\u0012\u0010\u0087uíç4ì\u0000\u0013tq\u008enSèëï\u0010Aåô>ÉóðCtC²²\u009d-µ8\b.§\u009eÖôd\u00010\b>ëÅç]=¢\u0002\u0010O\u001d=ÿ¹_\u0086Mê?Çx\bA÷ü\u0010õþFb\u0017Ëw\u0019ÑÎ6\u0015\u00059HZ\u0010¡'\u0087ïî³sImp=e§\nõð\bøÈ¸\u0011\u009fcÌ\u0087\u0010T\u0015s\u0016\u0096¨\t\u0094\u0092Å¡\u0005ì\n\u0012\u0094\u0010=>|ã$eú\u001c¢Îúâ\u0098t\u001fÊ\u0010D\u0000\u0017z\u008eC\nÅÚ¿Ç½;±\u00adØ\u0010O\u00849»TÜjz9u\u0088\u0085æßúf\u00109\u0007|Ô,\b8\u0095Ïª÷f3\u0002ÅR\b\u008b½F\u0093º\u008bb¯\u0010O\u001d=ÿ¹_\u0086M\u0094¢?°nq¢Ý\u0010\u009e<~\u0010«\u000f\u0093@Ä»\u0088®\u0002ÅKe\u0010T\u0015s\u0016\u0096¨\t\u0094öP\u008eeFé4\u009e\u0010á\u0086\u0016\u009f0µ=\u0012\u0095b¯\u001d\u0014+\u000b\u008b\u0010yiìþê9(\u001bf\u007f ÀÈi\u0012)\b¾\u001eôÚH\"û[\u0010¬\u0088æ\u0015H$nîD\u001f9\u008d\u0087'\u009e¾\u0010yiìþê9(\u001bm¼\u0099]sL.\u0015";
      int var18 = "O\u001d=ÿ¹_\u0086MrÎ:=H=\u007fç\u001000w;w?\u008bÑ\\^\u007fR³]`\u0089\u0010IZËÓÂvt\u0083\"+ªf\u0095¾\u0099%\u0010rC\fÂ\u0011x\n\u0083·\u0014>\u001b%êz\u0012\u0010\u0087uíç4ì\u0000\u0013tq\u008enSèëï\u0010Aåô>ÉóðCtC²²\u009d-µ8\b.§\u009eÖôd\u00010\b>ëÅç]=¢\u0002\u0010O\u001d=ÿ¹_\u0086Mê?Çx\bA÷ü\u0010õþFb\u0017Ëw\u0019ÑÎ6\u0015\u00059HZ\u0010¡'\u0087ïî³sImp=e§\nõð\bøÈ¸\u0011\u009fcÌ\u0087\u0010T\u0015s\u0016\u0096¨\t\u0094\u0092Å¡\u0005ì\n\u0012\u0094\u0010=>|ã$eú\u001c¢Îúâ\u0098t\u001fÊ\u0010D\u0000\u0017z\u008eC\nÅÚ¿Ç½;±\u00adØ\u0010O\u00849»TÜjz9u\u0088\u0085æßúf\u00109\u0007|Ô,\b8\u0095Ïª÷f3\u0002ÅR\b\u008b½F\u0093º\u008bb¯\u0010O\u001d=ÿ¹_\u0086M\u0094¢?°nq¢Ý\u0010\u009e<~\u0010«\u000f\u0093@Ä»\u0088®\u0002ÅKe\u0010T\u0015s\u0016\u0096¨\t\u0094öP\u008eeFé4\u009e\u0010á\u0086\u0016\u009f0µ=\u0012\u0095b¯\u001d\u0014+\u000b\u008b\u0010yiìþê9(\u001bf\u007f ÀÈi\u0012)\b¾\u001eôÚH\"û[\u0010¬\u0088æ\u0015H$nîD\u001f9\u008d\u0087'\u009e¾\u0010yiìþê9(\u001bm¼\u0099]sL.\u0015"
         .length();
      char var15 = 16;
      int var27 = -1;

      label54:
      while (true) {
         String var28 = var16.substring(++var27, var27 + var15);
         // while (true) {
            byte[] var19 = var12.doFinal(var28.getBytes("ISO-8859-1"));
            String var40 = a(var19).intern();
            switch (var32) {
               case 0:
                  var11[var17++] = var40;
                  if ((var27 += var15) >= var18) {
                     f = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(64146706953038L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[45];
                     String var4 = " 27\u0091y%h¸ÿ@\u001f«®áÌ4ó×3pJº\u0015Îô|\u000fà\u0090ÛA\u000féä\u0099\u00ad\u001fc\u001d©XlAý\u001aÉìæ\u0087\u009c¶õ0\n\u008a\u0016Áç\u009brpM\u0099¬Ûò¡\tñûæ¯7{\u0014I÷Rq\u0002£½Á1\f<´g*ÍõÏ\u0018U8\u009býÿÆ·+~Á\u0012\u008e ³p\u0087,\u00898¦\f\\t#J}ÜÛCôäwª\u0084\u009c¸¢\u008fPL¹9\u0015Åüâ¶\u008dJ\u0019IÀiM¶d\u0007\u0003\u008b\u009b¡*OºÑJC\u009e\nÆô~¯7díu¸¥\u0081þ\u0012\u0007\u001cïY\u0011`óhL\u0091\u0083\u0090ê? »\u0080Ü»\u0019\u001d°Çr\u0013«\u008fLã~ÃoD¶·wn)S\u001cà\u0014\u0007÷¦{\u00ad\tKCVÄY\u0088ùÝ.CáîfæM\u009c\u008a)þ\u000e¹÷%m4\u0019+\u0080\u0089\u008eZÞ)s\"ß;\u000e\u0004F\u001f\u0091\u001e\u009aÎ\u0016,¿\u001dG<\u0010Gõ²\u0010àtã\u0081Jå\u0093R#.Ò5«Ùó\u0095¿{\u0083\"T?|2h\u0000}4ó,Á&nî\u0003\u00992µÙ\u008f\u00928\u009f®\u009ab1ø3ï&Ë\u001aîÊ \u0003ªÄ{G\u000eR\u000b\u0099";
                     int var5 = " 27\u0091y%h¸ÿ@\u001f«®áÌ4ó×3pJº\u0015Îô|\u000fà\u0090ÛA\u000féä\u0099\u00ad\u001fc\u001d©XlAý\u001aÉìæ\u0087\u009c¶õ0\n\u008a\u0016Áç\u009brpM\u0099¬Ûò¡\tñûæ¯7{\u0014I÷Rq\u0002£½Á1\f<´g*ÍõÏ\u0018U8\u009býÿÆ·+~Á\u0012\u008e ³p\u0087,\u00898¦\f\\t#J}ÜÛCôäwª\u0084\u009c¸¢\u008fPL¹9\u0015Åüâ¶\u008dJ\u0019IÀiM¶d\u0007\u0003\u008b\u009b¡*OºÑJC\u009e\nÆô~¯7díu¸¥\u0081þ\u0012\u0007\u001cïY\u0011`óhL\u0091\u0083\u0090ê? »\u0080Ü»\u0019\u001d°Çr\u0013«\u008fLã~ÃoD¶·wn)S\u001cà\u0014\u0007÷¦{\u00ad\tKCVÄY\u0088ùÝ.CáîfæM\u009c\u008a)þ\u000e¹÷%m4\u0019+\u0080\u0089\u008eZÞ)s\"ß;\u000e\u0004F\u001f\u0091\u001e\u009aÎ\u0016,¿\u001dG<\u0010Gõ²\u0010àtã\u0081Jå\u0093R#.Ò5«Ùó\u0095¿{\u0083\"T?|2h\u0000}4ó,Á&nî\u0003\u00992µÙ\u008f\u00928\u009f®\u009ab1ø3ï&Ë\u001aîÊ \u0003ªÄ{G\u000eR\u000b\u0099"
                        .length();
                     label36:
                     while (true) {
                        int var36 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var36, var2).getBytes("ISO-8859-1");
                        long[] var31 = var6;
                        int var37 = var3++;
                        long var44 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var44;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var49 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var47) {
                              case 0:
                                 var31[var37] = var49;
                                 if (var2 >= var5) {
                                    d = var6;
                                    e = new Integer[45];
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    Object[] var24 = new Object[]{114093083516010L};
                                    b = aReturningArrayOfl_C0424(var24);
                                    break;
                                 }
                                 break;
                              default:
                                 var31[var37] = var49;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "©iÃç\u0096\u0011\u0095\u0081\u0006é°hÞSW\u0093";
                                 var5 = "©iÃç\u0096\u0011\u0095\u0081\u0006é°hÞSW\u0093".length();
                                 var2 = 0;
                           }

                           int var38 = var2;
                           var2 += 8;
                           var7 = var4.substring(var38, var2).getBytes("ISO-8859-1");
                           var31 = var6;
                           var37 = var3++;
                           var44 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var47 = 0;
                        }
                     }
                  }

                  var15 = var16.charAt(var27);
                  break;
               default:
                  var11[var17++] = var40;
                  if ((var27 += var15) < var18) {
                     var15 = var16.charAt(var27);
                     continue label54;
                  }

                  var16 = "IZËÓÂvt\u0083åE\u0005~KW\"\u008b\b\u009d\\\u0096ñô\u0010²Õ";
                  var18 = "IZËÓÂvt\u0083åE\u0005~KW\"\u008b\b\u009d\\\u0096ñô\u0010²Õ".length();
                  var15 = 16;
                  var27 = -1;
            }

            var28 = var16.substring(++var27, var27 + var15);
            var32 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2504;
      if (e[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = d[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])f.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               f.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/l", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         e[var3] = var15;
      }

      return e[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/l_C0424",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/l" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = h[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = g[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 44;
            yield var15;
         }
         case 1 -> {
            byte var16 = 59;
            yield var16;
         }
         case 2 -> {
            byte var17 = 62;
            yield var17;
         }
         case 3 -> {
            byte var18 = 39;
            yield var18;
         }
         case 4 -> {
            byte var19 = 14;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 38;
            yield var22;
         }
         case 8 -> {
            byte var23 = 12;
            yield var23;
         }
         case 9 -> {
            byte var24 = 41;
            yield var24;
         }
         case 10 -> {
            byte var25 = 3;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 22;
            yield var27;
         }
         case 13 -> {
            byte var28 = 58;
            yield var28;
         }
         case 14 -> {
            byte var29 = 42;
            yield var29;
         }
         case 15 -> {
            byte var30 = 13;
            yield var30;
         }
         case 16 -> {
            byte var31 = 61;
            yield var31;
         }
         case 17 -> {
            byte var32 = 32;
            yield var32;
         }
         case 18 -> {
            byte var33 = 55;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 21;
            yield var36;
         }
         case 22 -> {
            byte var37 = 9;
            yield var37;
         }
         case 23 -> {
            byte var38 = 29;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 52;
            yield var40;
         }
         case 26 -> {
            byte var41 = 49;
            yield var41;
         }
         case 27 -> {
            byte var42 = 31;
            yield var42;
         }
         case 28 -> {
            byte var43 = 37;
            yield var43;
         }
         case 29 -> {
            byte var44 = 33;
            yield var44;
         }
         case 30 -> {
            byte var45 = 0;
            yield var45;
         }
         case 31 -> {
            byte var46 = 46;
            yield var46;
         }
         case 32 -> {
            byte var47 = 4;
            yield var47;
         }
         case 33 -> {
            byte var48 = 60;
            yield var48;
         }
         case 34 -> {
            byte var49 = 28;
            yield var49;
         }
         case 35 -> {
            byte var50 = 40;
            yield var50;
         }
         case 36 -> {
            byte var51 = 15;
            yield var51;
         }
         case 37 -> {
            byte var52 = 45;
            yield var52;
         }
         case 38 -> {
            byte var53 = 30;
            yield var53;
         }
         case 39 -> {
            byte var54 = 24;
            yield var54;
         }
         case 40 -> {
            byte var55 = 16;
            yield var55;
         }
         case 41 -> {
            byte var56 = 18;
            yield var56;
         }
         case 42 -> {
            byte var57 = 7;
            yield var57;
         }
         case 43 -> {
            byte var58 = 8;
            yield var58;
         }
         case 44 -> {
            byte var59 = 35;
            yield var59;
         }
         case 45 -> {
            byte var60 = 54;
            yield var60;
         }
         case 46 -> {
            byte var61 = 51;
            yield var61;
         }
         case 47 -> {
            byte var62 = 20;
            yield var62;
         }
         case 48 -> {
            byte var63 = 34;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 2;
            yield var65;
         }
         case 51 -> {
            byte var66 = 53;
            yield var66;
         }
         case 52 -> {
            byte var67 = 48;
            yield var67;
         }
         case 53 -> {
            byte var68 = 17;
            yield var68;
         }
         case 54 -> {
            byte var69 = 26;
            yield var69;
         }
         case 55 -> {
            byte var70 = 63;
            yield var70;
         }
         case 56 -> {
            byte var71 = 5;
            yield var71;
         }
         case 57 -> {
            byte var72 = 27;
            yield var72;
         }
         case 58 -> {
            byte var73 = 36;
            yield var73;
         }
         case 59 -> {
            byte var74 = 47;
            yield var74;
         }
         case 60 -> {
            byte var75 = 25;
            yield var75;
         }
         case 61 -> {
            byte var76 = 23;
            yield var76;
         }
         case 62 -> {
            byte var77 = 19;
            yield var77;
         }
         default -> 50;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            h[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      g[0] = "\t\u000eW\u0010\u0012\\\u001f\u000eRJ\u0001K\bEQL\r_\u0019\u0002F[FM(";
      g[1] = int.class;
      h[1] = "java/lang/Integer";
      g[2] = "zK{=fUlK~guB{\u0000}ayVjGjv2I";
      g[3] = "\u0017+6\u0018VM\u001c$'W5@\t)(<\u0000B\u0018:4\u0010\u0017O";
      g[4] = "V\u001b\u0015\u0003J[]\u0014\u0004L)VH\u0012";
      g[5] = double.class;
      h[5] = "java/lang/Double";
      g[6] = "v\\xik\u001c}Si&\u0000\u001eiP";
      g[7] = "-gS{\u001aJ&hB4wJ&uV";
      g[8] = "H\u0004YUh_C\u000bH\u001a\u0015GP\fAS";
      g[9] = "\u001dS-;{0hs&4j\u007f\t}-?n%}";
      g[10] = "a9\u0001s_\u001b@\u0005\u0017sZAS\u0012\u00008YG_\u0006\u0011\u007fNP\u0014\u0019^";
      g[11] = "*8:>)*40 qa*.:86h1n\u001d#*e3%\f\">u&\u000f))-f+/+";
      g[12] = "/X^gIQ$WO((_/\\Kr";
      g[13] = "}}FY\u0004X3g\u000bGu\u000e5o\u001fJ<\u001c\u0001p\u0006Q\u0011\nM,\u0006KI\u001a!/\u000bU\u0018gvj\u000b\u0007\b\u000bug\u0015Vu";
      g[14] = "\u000eT]Vg6CE@\n\u0000\"[KOXG22\u0013LKrfWMNLo\\\f\u0011[Ki>M\u0010^M\u0000`I@QRj-X]\r5";
      g[15] = "\u000eK\u0000R]E\u0016^\u001d-V#T\t\u0004\u0010\u0007R\u0000B\u001eS<";
      g[16] = "\u0013e}GQ\u000fH$xU;OI<D\u0011FD\u0014'(\u0012KZEZ\u007fWK\bU6|ZUY(";
      g[17] = "\u001e'y\u0007mOEf|\u0015\u0007\u001fBc@Qz\u0004\u0019e,Rw\u001aH\u0018{\u0017wHXtx\u001ai\u0019%";
      g[18] = "kCm)gE0\u0002h;\r\u0005)\u0006(D6\u0003 @)(5\u000e>\u0011T\u007fp\u000el\u00018|}\u0010=|";
      g[19] = "K|u\u0019t\u001bSihf~}\u0011>q[.\fEuk\u0018\u0015";
      g[20] = "\u000e\u000eklmYJ\u0012?-\u001fW7LmomTR\u001a5nz>\r\u001f\u007ffu[[G~q\u001f";
      g[21] = "E\u001cp&4\\\u001e]u4^\u001f\u0019\\Ip#\u0017B^%s.\t\u0013#r6.[\u0003Oq;0\n~\u00184;b\u001a\u0012\u001b9%3g";
      g[22] = "c99D[6'%m\u0005)8Z\u007f5Y\u0016-j 0BXQe}5\f\u0017l >)\u0000)";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = g[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = g[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = h[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            g[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  g[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(853356261217019L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = g[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = h[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  g[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(853356261217019L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        g[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(853356261217019L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 80;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 71;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 107;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 164;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 253;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 36;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 80;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 71;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 107;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/l_C0424",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/l" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Enum invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = b(
                  MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Enum;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Enum)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static DoubleUnaryOperator invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$0", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$1", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$2", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding5() {
         MethodHandle var4 = bindingCache5;
         MethodHandle var3 = bindingCache5;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$3", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding6() {
         MethodHandle var4 = bindingCache6;
         MethodHandle var3 = bindingCache6;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$4", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding7() {
         MethodHandle var4 = bindingCache7;
         MethodHandle var3 = bindingCache7;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$5", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding8() {
         MethodHandle var4 = bindingCache8;
         MethodHandle var3 = bindingCache8;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$6", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding9() {
         MethodHandle var4 = bindingCache9;
         MethodHandle var3 = bindingCache9;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$7", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding10() {
         MethodHandle var4 = bindingCache10;
         MethodHandle var3 = bindingCache10;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$8", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding11() {
         MethodHandle var4 = bindingCache11;
         MethodHandle var3 = bindingCache11;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$9", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding12() {
         MethodHandle var4 = bindingCache12;
         MethodHandle var3 = bindingCache12;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache12 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$10", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding13() {
         MethodHandle var4 = bindingCache13;
         MethodHandle var3 = bindingCache13;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache13 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$11", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding14() {
         MethodHandle var4 = bindingCache14;
         MethodHandle var3 = bindingCache14;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache14 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$12", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding15() {
         MethodHandle var4 = bindingCache15;
         MethodHandle var3 = bindingCache15;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache15 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$13", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding16() {
         MethodHandle var4 = bindingCache16;
         MethodHandle var3 = bindingCache16;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache16 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$14", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding17() {
         MethodHandle var4 = bindingCache17;
         MethodHandle var3 = bindingCache17;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache17 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$15", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding18() {
         MethodHandle var4 = bindingCache18;
         MethodHandle var3 = bindingCache18;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache18 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$16", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding19() {
         MethodHandle var4 = bindingCache19;
         MethodHandle var3 = bindingCache19;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache19 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$17", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding20() {
         MethodHandle var4 = bindingCache20;
         MethodHandle var3 = bindingCache20;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache20 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$18", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding21() {
         MethodHandle var4 = bindingCache21;
         MethodHandle var3 = bindingCache21;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache21 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$19", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding22() {
         MethodHandle var4 = bindingCache22;
         MethodHandle var3 = bindingCache22;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache22 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$20", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding23() {
         MethodHandle var4 = bindingCache23;
         MethodHandle var3 = bindingCache23;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache23 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$21", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding24() {
         MethodHandle var4 = bindingCache24;
         MethodHandle var3 = bindingCache24;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache24 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$22", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding25() {
         MethodHandle var4 = bindingCache25;
         MethodHandle var3 = bindingCache25;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache25 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$23", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding26() {
         MethodHandle var4 = bindingCache26;
         MethodHandle var3 = bindingCache26;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache26 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$24", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding27() {
         MethodHandle var4 = bindingCache27;
         MethodHandle var3 = bindingCache27;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache27 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$25", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding28() {
         MethodHandle var4 = bindingCache28;
         MethodHandle var3 = bindingCache28;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache28 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$26", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static DoubleUnaryOperator invokeBinding29() {
         MethodHandle var4 = bindingCache29;
         MethodHandle var3 = bindingCache29;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache29 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/DoubleUnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/l_C0424", "lambda$static$27", "(D)D"),
                  SourceSupport.methodType("(D)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DoubleUnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
