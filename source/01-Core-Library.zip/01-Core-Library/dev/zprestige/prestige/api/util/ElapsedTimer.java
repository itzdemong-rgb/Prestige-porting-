package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ElapsedTimer {
   private long a;
   private static final long b = 91745044019231L;
   private static final Object[] c = new Object[17];
   private static final String[] d = new String[17];
   private static volatile MethodHandle bindingCache1;

   public ElapsedTimer(long var1) {
      super();
      var1 = 91745044019231L ^ var1;

      this.a = invokeBinding1(1095955985751584998L, var1);
   }

   public boolean aReturningBoolean(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 91745044019231L ^ var3;
      int var5 = Event.cReturningInt();
      float var14;
      int var13 = (var14 = (float)(System.currentTimeMillis() - this.a) - var2) == 0.0F ? 0 : (var14 < 0.0F ? -1 : 1);
      int var10 = var5;
      int var9 = var13;
      int var7 = var9;
      int var6 = var9;
      if (var10 != 0) {
         int var11 = var6;
         if (var11 <= 0) {
            return false;
         }

         var7 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   public float aReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 91745044019231L ^ var2;
      return (float)(System.currentTimeMillis() - this.a);
   }

   public boolean bReturningBoolean(Object[] var1) {
      MinMaxSetting var4 = (MinMaxSetting)var1[0];
      long var2 = (Long)var1[1];
      var2 = 91745044019231L ^ var2;
      long var5 = var2 ^ 99934674105456L;
      Object[] var8 = new Object[0];
      MinMaxSetting var7 = var4;
      float var10001 = var7.eReturningFloat(var8);
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var10001;
      Object[] var10 = var10004;
      ElapsedTimer var9 = this;
      return var9.aReturningBoolean(var10);
   }

   public void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 91745044019231L ^ var2;
      this.a = System.currentTimeMillis();
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 52;
            yield var15;
         }
         case 1 -> {
            byte var16 = 40;
            yield var16;
         }
         case 2 -> {
            byte var17 = 46;
            yield var17;
         }
         case 3 -> {
            byte var18 = 31;
            yield var18;
         }
         case 4 -> {
            byte var19 = 21;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 55;
            yield var21;
         }
         case 7 -> {
            byte var22 = 63;
            yield var22;
         }
         case 8 -> {
            byte var23 = 23;
            yield var23;
         }
         case 9 -> {
            byte var24 = 13;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 39;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 5;
            yield var31;
         }
         case 17 -> {
            byte var32 = 3;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 2;
            yield var34;
         }
         case 20 -> {
            byte var35 = 25;
            yield var35;
         }
         case 21 -> {
            byte var36 = 15;
            yield var36;
         }
         case 22 -> {
            byte var37 = 33;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 12;
            yield var39;
         }
         case 25 -> {
            byte var40 = 53;
            yield var40;
         }
         case 26 -> {
            byte var41 = 35;
            yield var41;
         }
         case 27 -> {
            byte var42 = 6;
            yield var42;
         }
         case 28 -> {
            byte var43 = 54;
            yield var43;
         }
         case 29 -> {
            byte var44 = 38;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 22;
            yield var46;
         }
         case 32 -> {
            byte var47 = 11;
            yield var47;
         }
         case 33 -> {
            byte var48 = 50;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 56;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 20;
            yield var52;
         }
         case 38 -> {
            byte var53 = 34;
            yield var53;
         }
         case 39 -> {
            byte var54 = 32;
            yield var54;
         }
         case 40 -> {
            byte var55 = 48;
            yield var55;
         }
         case 41 -> {
            byte var56 = 14;
            yield var56;
         }
         case 42 -> {
            byte var57 = 24;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 9;
            yield var59;
         }
         case 45 -> {
            byte var60 = 28;
            yield var60;
         }
         case 46 -> {
            byte var61 = 36;
            yield var61;
         }
         case 47 -> {
            byte var62 = 42;
            yield var62;
         }
         case 48 -> {
            byte var63 = 45;
            yield var63;
         }
         case 49 -> {
            byte var64 = 17;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 4;
            yield var66;
         }
         case 52 -> {
            byte var67 = 7;
            yield var67;
         }
         case 53 -> {
            byte var68 = 29;
            yield var68;
         }
         case 54 -> {
            byte var69 = 51;
            yield var69;
         }
         case 55 -> {
            byte var70 = 0;
            yield var70;
         }
         case 56 -> {
            byte var71 = 41;
            yield var71;
         }
         case 57 -> {
            byte var72 = 61;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 57;
            yield var74;
         }
         case 60 -> {
            byte var75 = 49;
            yield var75;
         }
         case 61 -> {
            byte var76 = 58;
            yield var76;
         }
         case 62 -> {
            byte var77 = 62;
            yield var77;
         }
         default -> 47;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "K/icv#@ x,\u000b6R:zo";
      c[1] = long.class;
      d[1] = "java/lang/Long";
      c[2] = "\u0002J\fe1V\u0014J\t?\"A\u0003\u0001\n9.U\u0012F\u001d.e@?";
      c[3] = "Ux-xh\u0001 X&wyNAV-|}\u00145";
      c[4] = boolean.class;
      d[4] = "java/lang/Boolean";
      c[5] = "9g=_lz/g8\u0005\u007fm8,;\u0003sy)k,\u00148n\u0011";
      c[6] = "Kb|r\u000bQ>Bw}\u001a\u001e_L|v\u001eD+";
      c[7] = float.class;
      d[7] = "java/lang/Float";
      c[8] = "\u001b_(\u000f2[\r_-U!L\u001a\u0014.S-X\u000bS9DfJ:";
      c[9] = int.class;
      d[9] = "java/lang/Integer";
      c[10] = "]><o0TV1- SYC<\"Kf[R/>gqV";
      c[11] = "\u0010:\u000f#v \u001b5\u001el\u0017.\u0010>\u001a6";
      c[12] = "\u001f\u000e\u000e\u0018hbW\u0000\u000f\bRm&O\u000e\u0017oa\u0017\f\u000fEb\u0004\u0019AQD75Z@\u0003IR";
      c[13] = "Y-)\u000b\u0018t\u0011#(\u001b\"{`osQRw\u00007j\u0001B\u0012[k~UHt\u0005-q\u0017\"";
      c[14] = "f\u001e\u001fckM1\u0006\u000bR0Q,\u0006\u001b4'p7\u0019\u001b\u0017:H2\u001d\rRb\u0014=\u0003\r9#F(\u001bv";
      c[15] = "V\u0014et\u001a\u001c\u000eAqa#Mh\u0015myR]\u001aP>dB&";
      c[16] = "kzM97O+~CjSHP;T;#@0cMk3%mlUplDj7\u0003;S";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(815534947945097L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(815534947945097L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(815534947945097L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 198;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 101;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 186;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 74;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 113;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 211;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 198;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 101;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 186;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fY_C0319",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fY" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = a(MethodHandles.lookup(), "Ó", SourceSupport.methodType("(JJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }
}
