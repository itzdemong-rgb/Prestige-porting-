package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

public class EntityUtil implements MinecraftAccess {
   private static final long a = 131038243302647L;
   private static final Object[] c = new Object[83];
   private static final String[] d = new String[83];

   public static PlayerEntity aReturningPlayerEntity(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 131038243302647L ^ var1;
      long var3 = var1 ^ 118366702509858L;
      long var5 = var1 ^ 23914860453943L;
      Object var8 = null;
      int var10000 = Event.cReturningInt();
      MinecraftClient var11 = b;
      ClientWorld var12 = var11.world;
      List var13 = var12.getPlayers();
      Iterator var9 = var13.iterator();
      int var7 = var10000;

      Object var51;
      while (true) {
         Iterator var14 = var9;
         boolean var52 = var14.hasNext();
         if (var52) {
            Iterator var15 = var9;
            PlayerEntity var10 = (PlayerEntity)var15.next();
            int var54 = var7;
            PlayerEntity var53 = var10;
            var51 = var53;
            PlayerEntity var39 = var53;
            if (var54 == 0) {
               break;
            }

            PlayerEntity var16 = var39;
            boolean var77 = var16.isAlive();
            int var56 = var7;
            boolean var55 = var77;
            boolean var42 = var55;
            boolean var40 = var55;
            if (var56 != 0) {
               boolean var57 = var40;
               boolean var41 = var57;
               boolean var58 = var41;
               if (!var58) {
                  continue;
               }

               MinecraftClient var19 = b;
               ClientPlayerEntity var21 = var19.player;
               PlayerEntity var20 = var10;
               var42 = var20.equals(var21);
            }

            int var60 = var7;
            boolean var59 = var42;
            boolean var44 = var59;
            boolean var43 = var59;
            if (var60 != 0) {
               boolean var61 = var43;
               if (var61) {
                  continue;
               }

               SocialsManager var78 = Prestige.g;
               PlayerEntity var23 = var10;
               Text var24 = var23.getName();
               Object[] var26 = new Object[]{var24.getString(), var5};
               SocialsManager var25 = var78;
               var44 = var25.aReturningBoolean(var26);
            }

            int var63 = var7;
            boolean var62 = var44;
            boolean var46 = var62;
            boolean var45 = var62;
            if (var63 != 0) {
               boolean var64 = var45;
               if (var64) {
                  continue;
               }

               PlayerValidationTracker var79 = Prestige.i;
               Object[] var29 = new Object[]{var10, var3};
               PlayerValidationTracker var28 = var79;
               var46 = var28.aReturningBoolean(var29);
            }

            boolean var65 = var46;
            if (!var65) {
               int var66 = var7;
               if (var66 != 0) {
                  continue;
               }
            }

            label55: {
               Object var50;
               int var68 = var7;
               Object var67 = var8;
               var50 = var67;
               Object var47 = var67;
               label54:
               if (var68 != 0) {
                  Object var69 = var47;
                  if (var69 != null) {
                     MinecraftClient var32 = b;
                     int var71 = var7;
                     ClientPlayerEntity var70 = var32.player;
                     var50 = var70;
                     ClientPlayerEntity var48 = var70;
                     if (var71 == 0) {
                        break label54;
                     }

                     ClientPlayerEntity var72 = var48;
                     ClientPlayerEntity var49 = var72;
                     PlayerEntity var35 = var10;
                     ClientPlayerEntity var34 = var49;
                     double var80 = var34.squaredDistanceTo((Entity)var35);
                     MinecraftClient var36 = b;
                     Object var38 = var8;
                     ClientPlayerEntity var37 = var36.player;
                     double var81;
                     int var73 = (var81 = var80 - var37.squaredDistanceTo((Entity)var38)) == 0.0 ? 0 : (var81 < 0.0 ? -1 : 1);
                     if (var73 >= 0) {
                        break label55;
                     }
                  }

                  PlayerEntity var74 = var10;
                  var50 = var74;
               }

               var8 = var50;
            }

            int var75 = var7;
            if (var75 != 0) {
               continue;
            }
         }

         var51 = var8;
         break;
      }

      return (PlayerEntity)var51;
   }

   public static PlayerEntity bReturningPlayerEntity(Object[] var0) {
      float var3 = (Float)var0[0];
      long var1 = (Long)var0[1];
      var1 = 131038243302647L ^ var1;
      long var4 = var1 ^ 116355754309384L;
      long var6 = var1 ^ 43320272289101L;
      long var8 = var1 ^ 99244235540040L;
      long var10 = var1 ^ 97861651022424L;
      int var10000 = Event.cReturningInt();
      PlayerEntity var13 = null;
      int var12 = var10000;
      MinecraftClient var16 = b;
      ClientWorld var17 = var16.world;
      List var18 = var17.getPlayers();
      Iterator var14 = var18.iterator();

      PlayerEntity var63;
      while (true) {
         Iterator var19 = var14;
         boolean var64 = var19.hasNext();
         if (var64) {
            Iterator var20 = var14;
            PlayerEntity var15 = (PlayerEntity)var20.next();
            int var66 = var12;
            PlayerEntity var65 = var15;
            var63 = var65;
            PlayerEntity var48 = var65;
            if (var66 == 0) {
               break;
            }

            PlayerEntity var21 = var48;
            int var93 = (((var21.isAlive()) ? 1 : 0));
            int var68 = var12;
            boolean var67 = dev.prestige.recovery.SourceSupport.asBoolean(var93);
            boolean var51 = var67;
            boolean var49 = var67;
            if (var68 != 0) {
               boolean var69 = var49;
               boolean var50 = var69;
               boolean var70 = var50;
               if (!var70) {
                  continue;
               }

               MinecraftClient var24 = b;
               ClientPlayerEntity var26 = var24.player;
               PlayerEntity var25 = var15;
               var51 = var25.equals(var26);
            }

            int var72 = var12;
            boolean var71 = var51;
            boolean var53 = var71;
            boolean var52 = var71;
            if (var72 != 0) {
               boolean var73 = var52;
               if (var73) {
                  continue;
               }

               SocialsManager var94 = Prestige.g;
               PlayerEntity var28 = var15;
               Text var29 = var28.getName();
               Object[] var31 = new Object[]{var29.getString(), var10};
               SocialsManager var30 = var94;
               var53 = var30.aReturningBoolean(var31);
            }

            int var75 = var12;
            boolean var74 = var53;
            boolean var55 = var74;
            boolean var54 = var74;
            if (var75 != 0) {
               boolean var76 = var54;
               if (var76) {
                  continue;
               }

               PlayerValidationTracker var95 = Prestige.i;
               Object[] var34 = new Object[]{var15, var6};
               PlayerValidationTracker var33 = var95;
               var55 = var33.aReturningBoolean(var34);
            }

            boolean var77 = var55;
            if (!var77) {
               int var78 = var12;
               if (var78 != 0) {
                  continue;
               }
            }

            label69: {
               PlayerEntity var62;
               label85: {
                  int var61;
                  label86: {
                     int var80 = var12;
                     PlayerEntity var79 = var13;
                     PlayerEntity var59 = var79;
                     PlayerEntity var56 = var79;
                     if (var80 != 0) {
                        PlayerEntity var81 = var56;
                        if (var81 != null) {
                           MinecraftClient var37 = b;
                           PlayerEntity var39 = var15;
                           ClientPlayerEntity var38 = var37.player;
                           double var96 = var38.squaredDistanceTo((Entity)var39);
                           MinecraftClient var40 = b;
                           PlayerEntity var42 = var13;
                           ClientPlayerEntity var41 = var40.player;
                           double var98;
                           var93 = (var98 = var96 - var41.squaredDistanceTo((Entity)var42)) == 0.0 ? 0 : (var98 < 0.0 ? -1 : 1);
                           int var83 = var12;
                           int var82 = var93;
                           var61 = var82;
                           int var57 = var82;
                           if (var83 == 0) {
                              break label86;
                           }

                           int var84 = var57;
                           int var58 = var84;
                           int var85 = var58;
                           if (var85 >= 0) {
                              break label69;
                           }
                        }

                        var59 = var15;
                     }

                     int var87 = var12;
                     PlayerEntity var86 = var59;
                     var62 = var86;
                     PlayerEntity var60 = var86;
                     if (var87 == 0) {
                        break label85;
                     }

                     PlayerEntity var45 = var60;
                     Object[] var46 = new Object[]{var45.getEyePos(), var8};
                     Object[] var47 = new Object[]{RotationUtil.aReturningdx_C0210(var46), var4};
                     float var99;
                     int var88 = (var99 = RotationUtil.aReturningFloat(var47) - var3) == 0.0F ? 0 : (var99 < 0.0F ? -1 : 1);
                     var61 = var88;
                  }

                  int var89 = var61;
                  if (var89 > 0) {
                     int var90 = var12;
                     if (var90 != 0) {
                        continue;
                     }
                  }

                  var62 = var15;
               }

               var13 = var62;
            }

            int var91 = var12;
            if (var91 != 0) {
               continue;
            }
         }

         var63 = var13;
         break;
      }

      return var63;
   }

   public static Entity aReturningEntity(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 131038243302647L ^ var1;
      long var3 = var1 ^ 117649603641497L;
      long var5 = var1 ^ 23532517457804L;
      Object var8 = null;
      int var10000 = Event.bReturningInt();
      MinecraftClient var11 = b;
      ClientWorld var12 = var11.world;
      Iterable var13 = var12.getEntities();
      Iterator var9 = var13.iterator();
      int var7 = var10000;

      Object var55;
      while (true) {
         Iterator var14 = var9;
         boolean var56 = var14.hasNext();
         if (var56) {
            Iterator var15 = var9;
            Entity var10 = (Entity)var15.next();
            int var58 = var7;
            Entity var57 = var10;
            var55 = var57;
            Entity var41 = var57;
            if (var58 != 0) {
               break;
            }

            Entity var16 = var41;
            boolean var84 = var16.isAlive();
            int var60 = var7;
            boolean var59 = var84;
            boolean var44 = var59;
            boolean var42 = var59;
            if (var60 == 0) {
               boolean var61 = var42;
               boolean var43 = var61;
               boolean var62 = var43;
               if (!var62) {
                  continue;
               }

               MinecraftClient var19 = b;
               ClientPlayerEntity var21 = var19.player;
               Entity var20 = var10;
               var44 = var20.equals(var21);
            }

            int var64 = var7;
            boolean var63 = var44;
            boolean var46 = var63;
            boolean var45 = var63;
            if (var64 == 0) {
               boolean var65 = var45;
               if (var65) {
                  continue;
               }

               SocialsManager var85 = Prestige.g;
               Entity var23 = var10;
               Text var24 = var23.getName();
               Object[] var26 = new Object[]{var24.getString(), var5};
               SocialsManager var25 = var85;
               var46 = var25.aReturningBoolean(var26);
            }

            int var67 = var7;
            boolean var66 = var46;
            boolean var48 = var66;
            boolean var47 = var66;
            if (var67 == 0) {
               boolean var68 = var47;
               if (var68) {
                  continue;
               }

               Entity var28 = var10;
               var48 = var28.isAttackable();
            }

            int var70 = var7;
            boolean var69 = var48;
            boolean var50 = var69;
            boolean var49 = var69;
            if (var70 == 0) {
               boolean var71 = var49;
               if (!var71) {
                  continue;
               }

               PlayerValidationTracker var86 = Prestige.i;
               Object[] var31 = new Object[]{var10, var3};
               PlayerValidationTracker var30 = var86;
               var50 = var30.aReturningBoolean(var31);
            }

            boolean var72 = var50;
            if (!var72) {
               int var73 = var7;
               if (var73 == 0) {
                  continue;
               }
            }

            label63: {
               Object var54;
               int var75 = var7;
               Object var74 = var8;
               var54 = var74;
               Object var51 = var74;
               label62:
               if (var75 == 0) {
                  Object var76 = var51;
                  if (var76 != null) {
                     MinecraftClient var34 = b;
                     int var78 = var7;
                     ClientPlayerEntity var77 = var34.player;
                     var54 = var77;
                     ClientPlayerEntity var52 = var77;
                     if (var78 != 0) {
                        break label62;
                     }

                     ClientPlayerEntity var79 = var52;
                     ClientPlayerEntity var53 = var79;
                     Entity var37 = var10;
                     ClientPlayerEntity var36 = var53;
                     double var87 = var36.squaredDistanceTo(var37);
                     MinecraftClient var38 = b;
                     Object var40 = var8;
                     ClientPlayerEntity var39 = var38.player;
                     double var88;
                     int var80 = (var88 = var87 - var39.squaredDistanceTo((Entity)var40)) == 0.0 ? 0 : (var88 < 0.0 ? -1 : 1);
                     if (var80 >= 0) {
                        break label63;
                     }
                  }

                  Entity var81 = var10;
                  var54 = var81;
               }

               var8 = var54;
            }

            int var82 = var7;
            if (var82 == 0) {
               continue;
            }
         }

         var55 = var8;
         break;
      }

      return (Entity)var55;
   }

   public static boolean aReturningBoolean(Object[] var0) {
      PlayerEntity var3;
      long var4;
      int var6;
      PlayerEntity var28;
      var3 = (PlayerEntity)var0[0];
      long var1 = (Long)var0[1];
      var1 = 131038243302647L ^ var1;
      var4 = var1 ^ 27069829018140L;
      var6 = Event.bReturningInt();
      int var35 = var6;
      PlayerEntity var34 = var3;
      var28 = var34;
      PlayerEntity var22 = var34;
      label47:
      if (var35 == 0) {
         PlayerEntity var7 = var22;
         ItemStack var8 = var7.getMainHandStack();
         Item var10000 = var8.getItem();
         Item var37 = Items.SHIELD;
         Item var36 = var10000;
         if (var36 != var37) {
            PlayerEntity var10 = var3;
            ItemStack var11 = var10.getOffHandStack();
            var10000 = var11.getItem();
            int var39 = var6;
            Item var38 = var10000;
            Object var27 = var38;
            Item var23 = var38;
            if (var39 == 0) {
               Item var40 = var23;
               Item var24 = var40;
               Item var42 = Items.SHIELD;
               Item var41 = var24;
               if (var41 != var42) {
                  return false;
               }

               int var44 = var6;
               PlayerEntity var43 = var3;
               var28 = var43;
               PlayerEntity var25 = var43;
               if (var44 != 0) {
                  break label47;
               }

               PlayerEntity var45 = var25;
               PlayerEntity var26 = var45;
               PlayerEntity var15 = var26;
               ItemStack var58 = var15.getMainHandStack();
               ComponentType var17 = DataComponentTypes.FOOD;
               ItemStack var16 = var58;
               Object var46 = var16.get(var17);
               var27 = var46;
            }

            Object var47 = var27;
            if (var47 != null) {
               return false;
            }
         }

         var28 = var3;
      }

      PlayerEntity var19 = var28;
      byte var59 = ((byte)((var19.isUsingItem()) ? 1 : 0));
      int var49 = var6;
      byte var48 = var59;
      byte var30 = var48;
      byte var29 = var48;
      if (var49 == 0) {
         byte var50 = var29;
         if (var50 == 0) {
            return false;
         }

         Object[] var21 = new Object[]{var3, var4};
         byte var51 = ((byte)((bReturningBoolean(var21)) ? 1 : 0));
         var30 = var51;
      }

      int var53 = var6;
      byte var52 = var30;
      byte var32 = var52;
      byte var31 = var52;
      if (var53 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var32);
      } else {
         byte var54 = var31;
         if (var54 == 0) {
            var32 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var32);
         } else {
            return false;
         }
      }
   }

   private static boolean bReturningBoolean(Object[] var0) {
      PlayerEntity var3 = (PlayerEntity)var0[0];
      long var1 = (Long)var0[1];
      var1 = 131038243302647L ^ var1;
      long var4 = var1 ^ 110527357650546L;
      long var6 = var1 ^ 57695002946508L;
      int var8 = Event.cReturningInt();
      MinecraftClient var17 = b;
      int var55 = var8;
      ClientPlayerEntity var54 = var17.player;
      Object var50 = var54;
      ClientPlayerEntity var49 = var54;
      if (var55 != 0) {
         ClientPlayerEntity var56 = var49;
         if (var56 == null) {
            return false;
         }

         var50 = var3;
      }

      Object var57 = var50;
      if (var57 != null) {
         Object[] var19 = new Object[]{var4};
         Vec3d var9 = RaycastUtil.bReturningVec3d(var19);
         Object[] var20 = new Object[]{var3, var6};
         Vec3d var10 = RaycastUtil.aReturningVec3d(var20);
         Vec3d var22 = var10;
         Vec3d var21 = var9;
         Vec3d var23 = var21.subtract(var22);
         Vec3d var11 = var23.normalize();
         PlayerEntity var24 = var3;
         float var12 = var24.getYaw();
         PlayerEntity var25 = var3;
         float var13 = var25.getPitch();
         double var26 = var12;
         double var28 = Math.toRadians(var26);
         double var10002 = -Math.sin(var28);
         double var30 = var13;
         double var32 = Math.toRadians(var30);
         var10002 *= Math.cos(var32);
         double var34 = var13;
         double var36 = Math.toRadians(var34);
         double var10003 = -Math.sin(var36);
         double var38 = var12;
         double var40 = Math.toRadians(var38);
         double var10004 = Math.cos(var40);
         double var42 = var13;
         double var44 = Math.toRadians(var42);
         Vec3d var46 = new Vec3d(var10002, var10003, var10004 * Math.cos(var44));
         Vec3d var14 = var46.normalize();
         Vec3d var48 = var11;
         Vec3d var47 = var14;
         double var15 = var47.dotProduct(var48);
         double var64;
         int var10000 = (var64 = var15 - 0.0) == 0.0 ? 0 : (var64 < 0.0 ? -1 : 1);
         int var59 = var8;
         int var58 = var10000;
         int var52 = var58;
         int var51 = var58;
         if (var59 != 0) {
            int var60 = var51;
            if (var60 >= 0) {
               return false;
            }

            var52 = 1;
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(var52);
      } else {
         return false;
      }
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 27;
            yield var15;
         }
         case 1 -> {
            byte var16 = 50;
            yield var16;
         }
         case 2 -> {
            byte var17 = 17;
            yield var17;
         }
         case 3 -> {
            byte var18 = 43;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 41;
            yield var20;
         }
         case 6 -> {
            byte var21 = 19;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 31;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 29;
            yield var25;
         }
         case 11 -> {
            byte var26 = 24;
            yield var26;
         }
         case 12 -> {
            byte var27 = 56;
            yield var27;
         }
         case 13 -> {
            byte var28 = 60;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 5;
            yield var30;
         }
         case 16 -> {
            byte var31 = 2;
            yield var31;
         }
         case 17 -> {
            byte var32 = 42;
            yield var32;
         }
         case 18 -> {
            byte var33 = 54;
            yield var33;
         }
         case 19 -> {
            byte var34 = 35;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 9;
            yield var36;
         }
         case 22 -> {
            byte var37 = 58;
            yield var37;
         }
         case 23 -> {
            byte var38 = 4;
            yield var38;
         }
         case 24 -> {
            byte var39 = 14;
            yield var39;
         }
         case 25 -> {
            byte var40 = 39;
            yield var40;
         }
         case 26 -> {
            byte var41 = 33;
            yield var41;
         }
         case 27 -> {
            byte var42 = 45;
            yield var42;
         }
         case 28 -> {
            byte var43 = 21;
            yield var43;
         }
         case 29 -> {
            byte var44 = 22;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 38;
            yield var46;
         }
         case 32 -> {
            byte var47 = 63;
            yield var47;
         }
         case 33 -> {
            byte var48 = 62;
            yield var48;
         }
         case 34 -> {
            byte var49 = 30;
            yield var49;
         }
         case 35 -> {
            byte var50 = 11;
            yield var50;
         }
         case 36 -> {
            byte var51 = 49;
            yield var51;
         }
         case 37 -> {
            byte var52 = 26;
            yield var52;
         }
         case 38 -> {
            byte var53 = 40;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 46;
            yield var55;
         }
         case 41 -> {
            byte var56 = 1;
            yield var56;
         }
         case 42 -> {
            byte var57 = 8;
            yield var57;
         }
         case 43 -> {
            byte var58 = 7;
            yield var58;
         }
         case 44 -> {
            byte var59 = 51;
            yield var59;
         }
         case 45 -> {
            byte var60 = 16;
            yield var60;
         }
         case 46 -> {
            byte var61 = 20;
            yield var61;
         }
         case 47 -> {
            byte var62 = 12;
            yield var62;
         }
         case 48 -> {
            byte var63 = 6;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 32;
            yield var65;
         }
         case 51 -> {
            byte var66 = 23;
            yield var66;
         }
         case 52 -> {
            byte var67 = 34;
            yield var67;
         }
         case 53 -> {
            byte var68 = 44;
            yield var68;
         }
         case 54 -> {
            byte var69 = 48;
            yield var69;
         }
         case 55 -> {
            byte var70 = 3;
            yield var70;
         }
         case 56 -> {
            byte var71 = 53;
            yield var71;
         }
         case 57 -> {
            byte var72 = 13;
            yield var72;
         }
         case 58 -> {
            byte var73 = 10;
            yield var73;
         }
         case 59 -> {
            byte var74 = 36;
            yield var74;
         }
         case 60 -> {
            byte var75 = 25;
            yield var75;
         }
         case 61 -> {
            byte var76 = 57;
            yield var76;
         }
         case 62 -> {
            byte var77 = 0;
            yield var77;
         }
         default -> 28;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "(\u0010\u0010\"^+(\u0010\u0007~R$2[\u0007`R15*U:\u0006u";
      c[1] = float.class;
      d[1] = "java/lang/Float";
      c[2] = "\u000b\u0018tz\u0013;\u001d\u0018q \u0000,\nSr&\f8\u001b\u0014e1G(\\";
      c[3] = "&Q\u001a\u00159JSq\u0011\u001a(\u00052\u007f\u001a\u0011,_F";
      c[4] = "\u000ejP\u0019fz\u000ejGEju\u0014!G[j`\u0013P\u0016\u00038";
      c[5] = "\u001cf1_/n\u0017i \u0010Lc\u0002o";
      c[6] = double.class;
      d[6] = "java/lang/Double";
      c[7] = "A\ftd\u0017xW\fq>\u0004o@Gr8\b{Q\u0000e/Cnp";
      c[8] = "D;GRj\u0010O4V\u001d\t\u001dZ9Yv<\u001fK*EZ+\u0012";
      c[9] = "Mx;^1t[x>\u0004\"cL3=\u0002.w]t*\u0015eel";
      c[10] = int.class;
      d[10] = "java/lang/Integer";
      c[11] = "F{\u001d$\u0011{3[\u0016+\u00004RU\u001d \u0004n&";
      c[12] = "Igz\u0007\u000f5Igm[\u0003:S,mE\u0003/T]=\u0018R";
      c[13] = "\t\"e^\u0000*\t\"r\u0002\f%\u0013ir\u001c\f0\u0014\u0018&D[";
      c[14] = "ZzK\u001dsGZz\\A\u007fH@1\\_\u007f]G@\t\u0000&";
      c[15] = "sq Q\u001c@my:\u001e~\\jd";
      c[16] = boolean.class;
      d[16] = "java/lang/Boolean";
      c[17] = "\u0015Fh{IM\u0003Fm!ZZ\u0014\rn'VN\u0005Jy0\u001d^\u001dJ{;G\u0013!Q{&GT\u0016F";
      c[18] = "N\u0004\u001a\n#WX\u0004\u001fP0@OO\u001cV<T^\b\u000bAwFL";
      c[19] = " ]%U%\u0000U}.Z4O4s%Q0\u0015@";
      c[20] = "cfY6\u0016ruf\\l\u0005eb-_j\tqsjH}BfE";
      c[21] = ".!.\u0014y0[\u0001%\u001bh\u007f:\u000f.\u0010l%N";
      c[22] = "uS&m\u0005>cS#7\u0016)t\u0018 1\u001a=e_7&Q*i";
      c[23] = "\u0003tF\u007fz\u0004\b{W0\u001b\n\u0003pSj";
      c[24] = "'7\u000b-_^17\u000ewLI&|\rq@]7;\u001af\u000bH\f";
      c[25] = "@~rH\">5^yG3qTPrL7+ ";
      c[26] = "\u0001Uo\rs\u0016\u0001UxQ\u007f\u0019\u001b\u001exO\u007f\f\u001co*\u0011'H";
      c[27] = "\tx/bC\u0004\u0017p5-$\u0005\u0006k8w\u0002\u0003";
      c[28] = "D ;6YFD ,jUI^k,tU\\Y\u001a}-\u0002\u001e";
      c[29] = "\\_B\u0014\u0002FWPS[\u007f^DWZ\u0012";
      c[30] = "p$Hd[u\u0005\u0004CkJ:d\nH`N`\u0010";
      c[31] = "5,}\u0006=r>#lIZj:?j\u0005\u007f{";
      c[32] = "|[CGsx|[T\u001b\u007fwf\u0010T\u0005\u007fbaa\u0006^'(";
      c[33] = "\r\u001eHt(\u0002\r\u001e_($\r\u0017U_6$\u0018\u0010$\u0005ivZ";
      c[34] = "q\u000b\r\u0014Snq\u000b\u001aH_ak@\u001aV_tl1@\t\r3";
      c[35] = "OPWF'\u0018OP@\u001a+\u0017U\u001b@\u0004+\u0002Rj\u0012_sC";
      c[36] = "\u007ffTAzB\nF_Nk\rkHTEoW\u001f";
      c[37] = "\u001d\u0005Jmo]\u001d\u0005]1cR\u0007N]/cG\u0000?\u000f{2\u0006";
      c[38] = "t-KH\u0007\u0014(,P@|J|1I]\u0010x,}\u0017\u000b@/wtQ\u0001\fF '\u0010W|@p \u0015\u0002\u0017OstE:";
      c[39] = "\u0007{PjEc\u0016$\u0007`{;l._u\u0002e\u001etZ?\u001f";
      c[40] = "\tC5\u000f&oSF\u007f\u0012\u0019tbXy\u000e|t\u0018M%Nb\u001d\bNz\u000f% \u001bY.N\u0019";
      c[41] = "\u0012tAQ|\t\u0000(@U@\n\u007fa\u0014P%\n\u0005tH\u0010;c\u0011sCI9\u001eO`IS@";
      c[42] = "\u0011[\"AQ$V\u0015'K1w/\u001b1\\JvT[nAU\u001d";
      c[43] = "e?]cA\u0012o9Pn%Y??<6GCc#Uc\u0014BfY\u0000hD\u001f$0U;E\u001a^";
      c[44] = "5\u00146b>f1N%\u0010:guJ<|\b41\u0015j\u0010:jkX +fkpP[";
      c[45] = "y\u000eiD=$%\u000frLFzq\u0012kQ*H#_3\u0007FxfVtZ:!~Tw6";
      c[46] = "[ax%C\u0015J>//}C00l-\u0004K@or6\u001e";
      c[47] = "3q3t[9mie*#e?h>rOWo+e/#j<)')\u001ey+}f\u0015";
      c[48] = "\u001bj{;\b:\u0010mp+c9Li*'\u000f\u000b\u0018-pqcf^$1+\u0005mY/!@";
      c[49] = "UOO\u0003Ja\u0004W\u0013_vbi\f\u0011UHeRW\u0017S\u0018\u000bTR\u001d\u0004\u00180\u000fT\u001bTv";
      c[50] = "N@o6q.\u001b\u00186*O&\u0012\u000665#\u0014BJkbO\"\u001a\u00177*v|\u0002AiRs!\u001eG,;&r\u001fBV";
      c[51] = "#+R\t\tn3-]Ix16&Y\u0011\u000470KAA\u001d/'!N\u0019\u001blJ";
      c[52] = "{\u001f3)_|<Q6#?.E_ 4D.>\u001f\u007f)[E";
      c[53] = "\u0015xp;\u0012DK`&ej\u0018\u0019a}=\u0006*I-%gj\u0017\u001a dfW\u0004\rt%Z";
      c[54] = "\u0018y5e,(Fac;T|\u0000a1`/\u0011\u0016}58lz\u0019~ahT{\u0017!!8ih\u0000u`\u0004";
      c[55] = "\u0011\u0012/8t)@\nsdH)-\u0014,y-*W\u0001p93CG\u0002/xt~T\u0015{9H";
      c[56] = "JRmdOG@T`i+\u000b\u0016neaJ\u001e\u0017O\f1I\u0016LNed\u001a\u0017I40oJJ\u000b]e<KOq";
      c[57] = "bc(p|\u000bid#`\u0017\b5`yl{:a$#5\u0017W'-b`q\\ &r\u000b+\u000f9!cb~\\8$\u0019";
      c[58] = "L4MNTkClK\r9gC}T1V`C1\u0010ZYc\u0017a(";
      c[59] = "\bJ\u00042+\u000f\f\u0010\u0017@/\u000eH\u0014\u000e,\u001dX\u000fIVyJYKE\u0012+,RLN\u0002@";
      c[60] = "I\u0012n\u001a\\BC\u0014c\u00178\u0019\u0015\u000f\u000fOZ\u0013O\u000ef\u001a\t\u0012Jt3\u0011YO\b\u001dfBXJr";
      c[61] = "ej\u0014t(A-k\u0014tZ\u00164`\u0016v\rAj7N\u001akBliLw>\u001a5u";
      c[62] = "r/ Gfa{1aX\u001ab}=JA`lv.\u0011^w6~{`\u0003unsA";
      c[63] = "z$\\\u0015lK$<\nK\u0014\u0017v=Q\u0013x%&}\u000eK\u0014\u0010upK\bx\u0019k1Tt";
      c[64] = "+\u001a\u0003[\u0019p$B\u0005\u0018tz X I\u0004fII\b\u0019\r&tZ\u001fML\u001a";
      c[65] = "v.\u0007/\u0011`rt\u0014]\u0015a6p\r1'2r,U]\u0015l(b\u0011fIm3jj";
      c[66] = "1V\u001cW\u0016\u00035\f\u000f%\u0012\u0002q\b\u0016I R1WN%\u0015\u0001<\u0012\rI\u001c\u001f}\rq";
      c[67] = "TMGi^\u0005P\u0017T\u001bZ\u0004\u0014\u0013MwhRVO\u0017&?\u0010X\u001c[fCV\fM*";
      c[68] = "FHJ\n\u0016wEMJE&lB]@SJ^\u0016\u0011\u001c\t\u0018\tFAQEW7VG^\u0005&";
      c[69] = "$)rv\u001a\u0010fk0%f\t\u001d#4?\u0003\tg6h\u007f\u001d`'$;<\r\u0006,#0,f";
      c[70] = "[\u0003dKe\u0011_Yw9a\u0010\u001b]nUS@W\u000549n\u0013ZD5\u0004}\u0004\u000e\u0005\t";
      c[71] = "\b\u0011]\u0015H\u0005\u0013\u0018\\\b4\r\u000f\u0018\t\u0015c^VMRD4\u0005W\rV\t]R\u0004L\u0000";
      c[72] = "~\u0007\u00047fya\u0010\u001c'\t$f\u0013\u0005#u\"`~\u001dsl:w\u0014\u0012+jy\u001a";
      c[73] = "7k;\u0018!k31(j-~v<2\u0011@hj8jR+gil:j*i6,jW9~bmV";
      c[74] = "\u0014U\u001aK3\u0010KK\u0001QT\t{UAJ1\t\u0001@\u001d\n/`\u0011CBKh]\u0002T\u0016\nT";
      c[75] = "Su1`',\u00117s3[6j\u007fw)>5\u0010j+i \\Pxx*0:[\u007fs:[";
      c[76] = "\u0018XF=2>PYF=@iIRD?\u0017>\u0016\u000f\u001fS)nB\u0001\u0010-*kBN";
      c[77] = "\u0003]X?h]D\u0001X(\fZ\u001b\u0001\u0003/[\u0004@QZCkNB\u0013\u000b?2V@\u0010";
      c[78] = " Z;]\u0012T2\u0006:Y.WMOn\\KW7Z2\u001cU>4\u0007?USBrSn$";
      c[79] = "\u001dS \u0017X\u0010\u0019\t3e\\\u0011]\r*\tnG\u001fQpY9\u0005\u0011\u0002<\u0018ECESM";
      c[80] = "\u0000~\u0004(?w\u000by\u000f8TtW}U48F\u00039\u000fkT+E0N82 B;^Snn\u000bz^5ei\u0000j5";
      c[81] = "|\u007f\u000bd)\u0011\u007fz\u000b+\u0019\nxj\u0001=u8,&Xc#oqo\u001a'vSnx\u00027\u0019";
      c[82] = "-\n9.4A)P*\\0@mT30\u0002\u0013(\ri\\?C,Mha,Tx\fT";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1676845111428769L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1676845111428769L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1676845111428769L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 231;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 36;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 205;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 246;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 232;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 105;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 231;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 36;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 205;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fU_C0311",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
