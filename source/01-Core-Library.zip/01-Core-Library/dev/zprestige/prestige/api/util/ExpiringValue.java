package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class ExpiringValue {
   private final Supplier a;
   private final boolean b;
   private final Supplier c;
   private long d;
   private boolean e;
   private static final long f = 108609913136681L;
   private static final long g;
   private static final Object[] h = new Object[26];
   private static final String[] i = new String[26];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public ExpiringValue(Supplier var1, boolean var2, Supplier var3, long var4) {
      super();
      long var10000 = 108609913136681L ^ var4;

      this.d = g;
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.e = var2;
   }

   public ExpiringValue(float var1, boolean var2, Easing var3, long var4) {
      this(invokeBinding1(var1), var2, invokeBinding2(var3), ((108609913136681L ^ (108609913136681L ^ var4)) ^ 4250369631234L));
      var4 = 108609913136681L ^ var4;
      long var6 = var4 ^ 4250369631234L;

   }

   public ExpiringValue(Supplier var1, boolean var2, Easing var3, long var4) {
      this(var1, var2, invokeBinding3(var3), ((108609913136681L ^ (108609913136681L ^ var4)) ^ 99327091274521L));
      var4 = 108609913136681L ^ var4;
      long var6 = var4 ^ 99327091274521L;

   }

   public ExpiringValue(float var1, boolean var2, Supplier var3, long var4) {
      this(invokeBinding4(var1), var2, var3, ((108609913136681L ^ (108609913136681L ^ var4)) ^ 42765611280943L));
      var4 = 108609913136681L ^ var4;
      long var6 = var4 ^ 42765611280943L;

   }

   public boolean aReturningBoolean(Object[] var1) {
      return this.e;
   }

   public void aReturningVoid(Object[] var1) {
      boolean var4;
      label18: {
         long var5;
         label17: {
            var4 = (Boolean)var1[0];
            long var2 = (Long)var1[1];
            var2 = 108609913136681L ^ var2;
            var5 = var2 ^ 92149409491413L;
            int var7 = Event.cReturningInt();
            int var18 = var7;
            if (var18 != 0) {
               boolean var19 = var4;
               if (var19) {
                  break label17;
               }

               long var10001 = System.currentTimeMillis();
               Object[] var10 = new Object[]{var5};
               ExpiringValue var9 = this;
               double var10002 = 1.0 - var9.aReturningDouble(var10);
               Supplier var11 = this.a;
               Float var12 = (Float)var11.get();
               this.d = var10001 - (long)(var10002 * var12.floatValue());
            }

            int var20 = var7;
            if (var20 != 0) {
               break label18;
            }
         }

         long var22 = System.currentTimeMillis();
         Object[] var15 = new Object[]{var5};
         ExpiringValue var14 = this;
         double var23 = var14.aReturningDouble(var15);
         Supplier var16 = this.a;
         Float var17 = (Float)var16.get();
         this.d = var22 - (long)(var23 * var17.floatValue());
      }

      this.e = var4;
   }

   public float aReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 108609913136681L ^ var2;
      long var4 = var2 ^ 89854803840831L;
      int var6 = Event.bReturningInt();
      int var38 = var6;
      ExpiringValue var37 = this;
      Object var36 = var37;
      ExpiringValue var35 = var37;
      if (var38 == 0) {
         boolean var39 = var35.e;
         if (var39) {
            Supplier var8 = this.c;
            Easing var41 = (Easing)var8.get();
            double var10003 = System.currentTimeMillis() - this.d;
            Supplier var9 = this.a;
            Float var10 = (Float)var9.get();
            double var13 = var10003 / var10.floatValue();
            double var17 = Math.max(var11, var13);
            double var15 = 1.0;
            double var42 = Math.min(var15, var17);
            Object[] var44 = new Object[]{null, var4};
            var44[0] = var42;
            Object[] var20 = var44;
            Easing var19 = var41;
            return (float)var19.aReturningDouble(var20);
         }

         Supplier var22 = this.c;
         var36 = var22.get();
      }

      Easing var10000 = (Easing)var36;
      double var10004 = System.currentTimeMillis() - this.d;
      Supplier var23 = this.a;
      Float var24 = (Float)var23.get();
      double var27 = 1.0 - var10004 / var24.floatValue();
      double var31 = Math.max(var25, var27);
      double var29 = 1.0;
      double var10001 = Math.min(var29, var31);
      Object[] var43 = new Object[]{null, var4};
      var43[0] = var10001;
      Object[] var34 = var43;
      Easing var33 = var10000;
      return (float)var33.aReturningDouble(var34);
   }

   public void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 108609913136681L ^ var2;
      long var4 = var2 ^ 53377702193024L;
      int var10000 = Event.bReturningInt();
      this.e = this.b;
      int var6 = var10000;
      int var21 = var6;
      ExpiringValue var20 = this;
      ExpiringValue var19 = var20;
      ExpiringValue var18 = var20;
      if (var21 == 0) {
         boolean var22 = var18.b;
         if (var22) {
            long var10001 = System.currentTimeMillis();
            Object[] var9 = new Object[]{var4};
            ExpiringValue var8 = this;
            double var10002 = 1.0 - var8.aReturningDouble(var9);
            Supplier var10 = this.a;
            Float var11 = (Float)var10.get();
            this.d = var10001 - (long)(var10002 * var11.floatValue());
            int var23 = var6;
            if (var23 == 0) {
               return;
            }
         }

         ExpiringValue var24 = this;
         var19 = var24;
      }

      long var26 = System.currentTimeMillis();
      Object[] var15 = new Object[]{var4};
      ExpiringValue var14 = this;
      double var27 = var14.aReturningDouble(var15);
      Supplier var16 = this.a;
      Float var17 = (Float)var16.get();
      var19.d = var26 - (long)(var27 * var17.floatValue());
   }

   private double aReturningDouble(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 108609913136681L ^ var2;
      boolean var25 = this.e;
      if (!var25) {
         double var10003 = System.currentTimeMillis() - this.d;
         Supplier var4 = this.a;
         Float var5 = (Float)var4.get();
         double var8 = 1.0 - var10003 / var5.floatValue();
         double var12 = Math.max(var6, var8);
         double var10 = 1.0;
         return Math.min(var10, var12);
      } else {
         double var10002 = System.currentTimeMillis() - this.d;
         Supplier var15 = this.a;
         Float var16 = (Float)var15.get();
         double var19 = var10002 / var16.floatValue();
         double var23 = Math.max(var17, var19);
         double var21 = 1.0;
         return Math.min(var21, var23);
      }
   }

   private static Float lambda$new$3(float var0) {
      float var3 = var0;
      return var3;
   }

   private static Easing lambda$new$2(Easing var0) {
      return var0;
   }

   private static Easing lambda$new$1(Easing var0) {
      return var0;
   }

   private static Float lambda$new$0(float var0) {
      float var3 = var0;
      return var3;
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(136766570734911L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 3069761848796412670L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)42L,
            (byte)10905L,
            (byte)2791932L,
            (byte)714734627L,
            (byte)182972064542L,
            (byte)46840848522894L,
            (byte)11991257221860986L,
            (byte)3069761848796412670L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // g = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 22;
            yield var15;
         }
         case 1 -> {
            byte var16 = 4;
            yield var16;
         }
         case 2 -> {
            byte var17 = 8;
            yield var17;
         }
         case 3 -> {
            byte var18 = 55;
            yield var18;
         }
         case 4 -> {
            byte var19 = 12;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 31;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 7;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 34;
            yield var25;
         }
         case 11 -> {
            byte var26 = 9;
            yield var26;
         }
         case 12 -> {
            byte var27 = 28;
            yield var27;
         }
         case 13 -> {
            byte var28 = 23;
            yield var28;
         }
         case 14 -> {
            byte var29 = 39;
            yield var29;
         }
         case 15 -> {
            byte var30 = 43;
            yield var30;
         }
         case 16 -> {
            byte var31 = 3;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 16;
            yield var33;
         }
         case 19 -> {
            byte var34 = 26;
            yield var34;
         }
         case 20 -> {
            byte var35 = 29;
            yield var35;
         }
         case 21 -> {
            byte var36 = 49;
            yield var36;
         }
         case 22 -> {
            byte var37 = 48;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 53;
            yield var39;
         }
         case 25 -> {
            byte var40 = 5;
            yield var40;
         }
         case 26 -> {
            byte var41 = 37;
            yield var41;
         }
         case 27 -> {
            byte var42 = 62;
            yield var42;
         }
         case 28 -> {
            byte var43 = 44;
            yield var43;
         }
         case 29 -> {
            byte var44 = 20;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 32;
            yield var46;
         }
         case 32 -> {
            byte var47 = 57;
            yield var47;
         }
         case 33 -> {
            byte var48 = 25;
            yield var48;
         }
         case 34 -> {
            byte var49 = 54;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 59;
            yield var51;
         }
         case 37 -> {
            byte var52 = 18;
            yield var52;
         }
         case 38 -> {
            byte var53 = 33;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 24;
            yield var55;
         }
         case 41 -> {
            byte var56 = 0;
            yield var56;
         }
         case 42 -> {
            byte var57 = 17;
            yield var57;
         }
         case 43 -> {
            byte var58 = 19;
            yield var58;
         }
         case 44 -> {
            byte var59 = 46;
            yield var59;
         }
         case 45 -> {
            byte var60 = 2;
            yield var60;
         }
         case 46 -> {
            byte var61 = 36;
            yield var61;
         }
         case 47 -> {
            byte var62 = 42;
            yield var62;
         }
         case 48 -> {
            byte var63 = 60;
            yield var63;
         }
         case 49 -> {
            byte var64 = 14;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 50;
            yield var66;
         }
         case 52 -> {
            byte var67 = 10;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 6;
            yield var69;
         }
         case 55 -> {
            byte var70 = 47;
            yield var70;
         }
         case 56 -> {
            byte var71 = 38;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 35;
            yield var75;
         }
         case 61 -> {
            byte var76 = 45;
            yield var76;
         }
         case 62 -> {
            byte var77 = 11;
            yield var77;
         }
         default -> 58;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "\rw# \u001b\u000e\u001bw&z\b\u0019\f<%|\u0004\r\u001d{2kO\u001f,";
      h[1] = int.class;
      i[1] = "java/lang/Integer";
      h[2] = "7NGi[\r<AV&8\u0000)G";
      h[3] = double.class;
      i[3] = "java/lang/Double";
      h[4] = "@>\u001d/a;K1\f`\u001c.Y+\u000e#";
      h[5] = long.class;
      i[5] = "java/lang/Long";
      h[6] = "\u0018L%^\u000e\u0016\u0006D?\u0011F\u0016\u001cN'VO\r\\~&OP\u000f\u001bH!";
      h[7] = ")%eWs}\"*t\u0018\u0012s)!pB";
      h[8] = " -*R\u001a\u00126-/\b\t\u0005!f,\u000e\u0005\u00110!;\u0019N\u000e";
      h[9] = "\"vw\fZ\u0007WV|\u0003KH6Xw\bO\u0012B";
      h[10] = "Q\tRmUJZ\u0006C\"=JT\tP";
      h[11] = float.class;
      i[11] = "java/lang/Float";
      h[12] = "\bE\u001fP\fe\u001eE\u001a\n\u001fr\t\u000e\u0019\f\u0013f\u0018I\u000e\u001bXt\t";
      h[13] = "hNcpGEcAr?$HvL}T\u0011Jg_ax\u0006G";
      h[14] = "#u\u0004&H5VU\u000f)Yz7[\u0004\"] C";
      h[15] = "\u001b1\u0017v\u001f\u0006A8\u0018sm\u0001+o\bn\t\u0010G!FhTh\u00113Fn\u000e\u0002@7\u0019ym";
      h[16] = "\u000e3\u0016!\u000b\u0000_4_KX?Z;\u0006'IM\u0001=\u0000q2";
      h[17] = ">(|;|\u001d5v-`\u000e\u0018ma\u0010<cBzrzmg\u001dm\u0011*k1\u0003g{{on\u0014\u0004+}9p\u001enzyfg}";
      h[18] = "L\u00182<n|\u0014\u001f0!\rh\u0017D4-So\u0017^0Q2z\u0001C3,c}CO]";
      h[19] = "\u001d6'Lj\u0005\u0016hv\u0017\u0018\u0000FiKKuZYl!\u001aq\u0005N\u000fq\u001c'\u001bDe \u0018x\f'5&Nf\u0006Md\"\u0011qe";
      h[20] = "\u0006@,0\u0010>^G.-s:P\u001f>04*9D?/\u0013*D\u00158m\u001fD\u0006@,0\u0010>^G.-s";
      h[21] = "tk\u0006b5\u0018~m\u001aiL\u001d3o\u001db*\n\u0012t\u0002b\t\u0017*q\u0006tLJuw\u0007b}F+g_\u000f";
      h[22] = "^Q+\u0010{|[Z DE,\u000fIBI%/\u0010L;\u000f~9\u001d5";
      h[23] = "\u007fsP!9k.t\u0019KkT+{@'{&p}Fq\u0000";
      h[24] = ";h\u0017I\u0004\u0012aa\u0018Lv\u0015\u000b6\u001bM\u0012D:6I\u0010\u000e|:e\u001bKNM:7FWv";
      h[25] = "#\u0015/\u001eC%q\u0019:\n\"*\u001d\u0018.\u0004F;qV`\u0002\u001bC'D`\u0004A)v@?\u0013\"";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(556855190385692L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(556855190385692L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(556855190385692L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 114;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 181;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 102;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 82;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 107;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 223;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 114;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 181;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 102;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ae_C0012",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ae" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Supplier invokeBinding1(float var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("(F)Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/ae_C0012", "lambda$new$0", "(F)Ljava/lang/Float;"),
                  SourceSupport.methodType("()Ljava/lang/Float;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var2.invokeExact((float)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Supplier invokeBinding2(Easing var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/l_C0424;)Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/ae_C0012",
                     "lambda$new$1",
                     "(Ldev/zprestige/prestige/l_C0424;)Ldev/zprestige/prestige/l_C0424;"
                  ),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/l_C0424;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var2.invokeExact((Easing)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Supplier invokeBinding3(Easing var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/l_C0424;)Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/ae_C0012",
                     "lambda$new$2",
                     "(Ldev/zprestige/prestige/l_C0424;)Ldev/zprestige/prestige/l_C0424;"
                  ),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/l_C0424;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var2.invokeExact((Easing)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Supplier invokeBinding4(float var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("(F)Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/ae_C0012", "lambda$new$3", "(F)Ljava/lang/Float;"),
                  SourceSupport.methodType("()Ljava/lang/Float;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Supplier)var2.invokeExact((float)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
