package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.api.accessor.RaycastContextAccessor;
import dev.zprestige.prestige.api.accessor.Vec3dAccessor;
import dev.zprestige.prestige.api.events.WorldResetEvent;

import dev.zprestige.prestige.api.util.DifficultySwitchMap;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.ObjectIterable;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageSources;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameMode;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import net.minecraft.world.explosion.Explosion;

public class ExplosionDamageUtil implements MinecraftAccess {
   private final Vec3d a;
   private Explosion c;
   private RaycastContext d;
   private volatile long e;
   private final ConcurrentHashMap f;
   private static final ThreadLocal g;
   private static final long h = 89392438692766L;
   private static final long i;
   private static final Object[] j = new Object[221];
   private static final String[] k = new String[221];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public ExplosionDamageUtil(long var1) {
      super();
      var1 = 89392438692766L ^ var1;
      long var3 = var1 ^ 47981076692610L;

      this.a = new Vec3d(0.0, 0.0, 0.0);
      this.e = i;
      this.f = new ConcurrentHashMap();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      MinecraftClient var4 = b;
      this.d = new RaycastContext(null, null, ShapeType.COLLIDER, FluidHandling.ANY, var4.player);
   }

   public double aReturningDouble(Object[] var1) {
      LivingEntity var4 = (LivingEntity)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      long var2 = (Long)var1[2];
      var2 = 89392438692766L ^ var2;
      long var6 = var2 ^ 81874235843440L;
      Object[] var10008 = new Object[]{null, null, null, null, null, var6};
      var10008[4] = false;
      var10008[3] = null;
      var10008[2] = false;
      var10008[1] = var5;
      var10008[0] = var4;
      Object[] var9 = var10008;
      ExplosionDamageUtil var8 = this;
      return var8.bReturningDouble(var9);
   }

   public double bReturningDouble(Object[] var1) {
      boolean var2;
      Vec3d var3;
      LivingEntity var6;
      BlockPos var7;
      boolean var8;
      long var9;
      int var11;
      label23: {
         var6 = (LivingEntity)var1[0];
         var3 = (Vec3d)var1[1];
         var8 = (Boolean)var1[2];
         var7 = (BlockPos)var1[3];
         var2 = (Boolean)var1[4];
         long var4 = (Long)var1[5];
         var4 = 89392438692766L ^ var4;
         var9 = var4 ^ 43329356543725L;
         int var10000 = Event.bReturningInt();
         MinecraftClient var18 = b;
         ClientWorld var19 = var18.world;
         long var12 = var19.getTime();
         var11 = var10000;
         int var39 = var11;
         if (var39 == 0) {
            long var46;
            int var40 = (var46 = var12 - this.e) == 0L ? 0 : (var46 < 0L ? -1 : 1);
            if (!((var40) != 0)) {
               break label23;
            }

            ConcurrentHashMap var21 = this.f;
            var21.clear();
         }

         this.e = var12;
      }

      Vec3d var23 = var3;
      Vec3d var24 = var3;
      Vec3d var25 = var3;
      ExplosionTargetSnapshot var14 = new ExplosionTargetSnapshot(var6, var23.x, var24.y, var25.z, var8, var7, var2);
      ExplosionTargetSnapshot var27 = var14;
      ConcurrentHashMap var26 = this.f;
      Double var15 = (Double)var26.get(var27);
      int var42 = var11;
      Double var41 = var15;
      Double var38 = var41;
      Double var37 = var41;
      if (var42 == 0) {
         Double var43 = var37;
         if (var43 == null) {
            Object[] var10008 = new Object[]{null, null, null, null, null, var9};
            var10008[4] = var2;
            var10008[3] = var7;
            var10008[2] = var8;
            var10008[1] = var3;
            var10008[0] = var6;
            Object[] var31 = var10008;
            ExplosionDamageUtil var30 = this;
            double var16 = var30.cReturningDouble(var31);
            ConcurrentHashMap var45 = this.f;
            double var32 = var16;
            Double var36 = var32;
            ExplosionTargetSnapshot var35 = var14;
            ConcurrentHashMap var34 = var45;
            var34.put(var35, var36);
            return var16;
         }

         var38 = var15;
      }

      Double var29 = var38;
      return var29;
   }

   private double cReturningDouble(Object[] var1) {
      LivingEntity var2 = (LivingEntity)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      boolean var6 = (Boolean)var1[2];
      BlockPos var8 = (BlockPos)var1[3];
      boolean var7 = (Boolean)var1[4];
      long var3 = (Long)var1[5];
      var3 = 89392438692766L ^ var3;
      long var9 = var3 ^ 104677125410657L;
      long var11 = var3 ^ 3646519468673L;
      long var13 = var3 ^ 10043481142042L;
      long var15 = var3 ^ 106025701104958L;
      long var17 = var3 ^ 32341203950166L;
      long var19 = var3 ^ 38329636572858L;
      int var21 = Event.cReturningInt();
      int var124 = var21;
      LivingEntity var123 = var2;
      LivingEntity var98 = var123;
      LivingEntity var94 = var123;
      if (var124 != 0) {
         boolean var125 = var94 instanceof PlayerEntity;
         label51:
         if (var125) {
            MinecraftClient var32 = b;
            ClientPlayNetworkHandler var10000 = var32.getNetworkHandler();
            LivingEntity var33 = var2;
            UUID var35 = var33.getUuid();
            ClientPlayNetworkHandler var34 = var10000;
            PlayerListEntry var166 = var34.getPlayerListEntry(var35);
            int var127 = var21;
            PlayerListEntry var126 = var166;
            PlayerListEntry var97 = var126;
            PlayerListEntry var95 = var126;
            if (var127 != 0) {
               PlayerListEntry var128 = var95;
               PlayerListEntry var96 = var128;
               PlayerListEntry var129 = var96;
               if (var129 == null) {
                  break label51;
               }

               MinecraftClient var38 = b;
               var10000 = var38.getNetworkHandler();
               LivingEntity var39 = var2;
               UUID var41 = var39.getUuid();
               ClientPlayNetworkHandler var40 = var10000;
               PlayerListEntry var130 = var40.getPlayerListEntry(var41);
               var97 = var130;
            }

            PlayerListEntry var43 = var97;
            GameMode var168 = var43.getGameMode();
            GameMode var132 = GameMode.CREATIVE;
            GameMode var131 = var168;
            if (var131 == var132) {
               return 0.0;
            }
         }

         var98 = var2;
      }

      label44: {
         Object[] var45 = new Object[]{var98, var17};
         Vec3d var22 = RaycastUtil.aReturningVec3d(var45);
         Vec3dAccessor var169 = new Vec3dAccessor(this.a);
         Vec3d var46 = var22;
         Vec3d var47 = var22;
         Vec3d var48 = var22;
         int var140 = var21;
         double var138 = var48.z;
         double var136 = var47.y;
         double var134 = var46.x;
         Vec3dAccessor var133 = var169;
         Vec3dAccessor var106 = var133;
         double var107 = var134;
         double var109 = var136;
         double var111 = var138;
         Vec3dAccessor var99 = var133;
         double var100 = var134;
         double var102 = var136;
         double var104 = var138;
         if (var140 != 0) {
            Object[] var10006 = new Object[]{null, null, null, var11};
            var10006[2] = var104;
            var10006[1] = var102;
            var10006[0] = var100;
            Object[] var50 = var10006;
            Vec3dAccessor var49 = var99;
            var49.dReturningVoid(var50);
            boolean var141 = var6;
            if (!var141) {
               break label44;
            }

            var169 = new Vec3dAccessor(this.a);
            Vec3d var52 = this.a;
            double var10001 = var52.x;
            LivingEntity var53 = var2;
            Vec3d var54 = var53.getVelocity();
            var10001 += var54.x;
            Vec3d var55 = this.a;
            double var10002 = var55.y;
            LivingEntity var56 = var2;
            Vec3d var57 = var56.getVelocity();
            var10002 += var57.y;
            Vec3d var58 = this.a;
            double var10003 = var58.z;
            LivingEntity var59 = var2;
            Vec3d var60 = var59.getVelocity();
            double var147 = var10003 + var60.z;
            double var145 = var10002;
            double var143 = var10001;
            Vec3dAccessor var142 = var169;
            var106 = var142;
            var107 = var143;
            var109 = var145;
            var111 = var147;
         }

         Object[] var180 = new Object[]{null, null, null, var11};
         var180[2] = var111;
         var180[1] = var109;
         var180[0] = var107;
         Object[] var63 = var180;
         Vec3dAccessor var62 = var106;
         var62.dReturningVoid(var63);
      }

      Vec3d var65 = var5;
      Vec3d var64 = this.a;
      double var66 = var64.squaredDistanceTo(var65);
      double var23 = Math.sqrt(var66);
      int var151 = var21;
      double var149 = var23;
      double var115 = var149;
      double var113 = var149;
      if (var151 != 0) {
         double var181;
         int var152 = (var181 = var113 - 12.0) == 0.0 ? 0 : (var181 < 0.0 ? -1 : 1);
         if (var152 > 0) {
            return 0.0;
         }

         RaycastContext var10004 = this.d;
         Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, var15};
         var10012[5] = var7;
         var10012[4] = var8;
         var10012[3] = var10004;
         var10012[2] = var6;
         var10012[1] = var2;
         var10012[0] = var5;
         Object[] var71 = var10012;
         ExplosionDamageUtil var70 = this;
         var115 = var70.o(var71);
      }

      double var25 = var115;
      double var27 = (1.0 - var23 / 12.0) * var25;
      double var29 = (var27 * var27 + var27) / 2.0 * 7.0 * 12.0 + 1.0;
      Object[] var178 = new Object[]{null, var13};
      var178[0] = var29;
      Object[] var73 = var178;
      ExplosionDamageUtil var72 = this;
      var29 = var72.mReturningVoid(var73);
      float var172 = (float)var29;
      MinecraftClient var74 = b;
      ClientWorld var75 = var74.world;
      DamageSources var174 = var75.getDamageSources();
      Object var77 = null;
      DamageSources var76 = var174;
      DamageSource var175 = var76.explosion((Explosion)var77);
      LivingEntity var78 = var2;
      float var177 = var78.getArmor();
      RegistryEntry var80 = EntityAttributes.ARMOR_TOUGHNESS;
      LivingEntity var79 = var2;
      EntityAttributeInstance var81 = var79.getAttributeInstance(var80);
      float var86 = (float)var81.getValue();
      float var85 = var177;
      DamageSource var84 = var175;
      float var83 = var172;
      LivingEntity var82 = var2;
      var29 = DamageUtil.getDamageLeft(var82, var83, var84, var85, var86);
      Object[] var10005 = new Object[]{null, null, var19};
      var10005[1] = var29;
      var10005[0] = var2;
      Object[] var88 = var10005;
      ExplosionDamageUtil var87 = this;
      var29 = var87.nReturningVoid(var88);
      MinecraftClient var89 = b;
      ClientWorld var90 = var89.world;
      var174 = var90.getDamageSources();
      Object var92 = null;
      DamageSources var91 = var174;
      var10005 = new Object[]{null, null, var91.explosion((Explosion)var92), var9};
      var10005[1] = var29;
      var10005[0] = var2;
      Object[] var93 = var10005;
      var29 = j(var93);
      int var155 = var21;
      double var153 = var29;
      double var119 = var153;
      double var117 = var153;
      double var121;
      if (var155 != 0) {
         double var182;
         int var156 = (var182 = var117 - 0.0) == 0.0 ? 0 : (var182 < 0.0 ? -1 : 1);
         if (var156 < 0) {
            var121 = var157;
         } else {
            var121 = var29;
         }
      } else {
         double var159 = var119;
         var121 = var159;
      }

      return var121;
   }

   public double dReturningDouble(Object[] var1) {
      LivingEntity var5 = (LivingEntity)var1[0];
      Vec3d var6 = (Vec3d)var1[1];
      Vec3d var7 = (Vec3d)var1[2];
      BlockPos var2 = (BlockPos)var1[3];
      long var3 = (Long)var1[4];
      var3 = 89392438692766L ^ var3;
      long var8 = var3 ^ 79263054391615L;
      long var10 = var3 ^ 22487671522527L;
      long var12 = var3 ^ 34925631005636L;
      long var14 = var3 ^ 32988485326148L;
      long var16 = var3 ^ 11307863129096L;
      long var18 = var3 ^ 59367261759716L;
      int var20 = Event.cReturningInt();
      int var95 = var20;
      if (var95 != 0) {
         boolean var96 = var5 instanceof PlayerEntity;
         label40:
         if (var96) {
            MinecraftClient var31 = b;
            ClientPlayNetworkHandler var10000 = var31.getNetworkHandler();
            LivingEntity var32 = var5;
            UUID var34 = var32.getUuid();
            ClientPlayNetworkHandler var33 = var10000;
            PlayerListEntry var123 = var33.getPlayerListEntry(var34);
            int var98 = var20;
            PlayerListEntry var97 = var123;
            PlayerListEntry var84 = var97;
            PlayerListEntry var82 = var97;
            if (var98 != 0) {
               PlayerListEntry var99 = var82;
               PlayerListEntry var83 = var99;
               PlayerListEntry var100 = var83;
               if (var100 == null) {
                  break label40;
               }

               MinecraftClient var37 = b;
               var10000 = var37.getNetworkHandler();
               LivingEntity var38 = var5;
               UUID var40 = var38.getUuid();
               ClientPlayNetworkHandler var39 = var10000;
               PlayerListEntry var101 = var39.getPlayerListEntry(var40);
               var84 = var101;
            }

            PlayerListEntry var42 = var84;
            GameMode var125 = var42.getGameMode();
            GameMode var103 = GameMode.CREATIVE;
            GameMode var102 = var125;
            if (var102 == var103) {
               return 0.0;
            }
         }

         Vec3dAccessor var126 = new Vec3dAccessor(this.a);
         Vec3d var44 = var7;
         double var10001 = var44.x;
         Vec3d var45 = var7;
         double var10002 = var45.y;
         Vec3d var46 = var7;
         double var10003 = var46.z;
         Object[] var10006 = new Object[]{null, null, null, var10};
         var10006[2] = var10003;
         var10006[1] = var10002;
         var10006[0] = var10001;
         Object[] var48 = var10006;
         Vec3dAccessor var47 = var126;
         var47.dReturningVoid(var48);
      }

      Vec3d var50 = var6;
      Vec3d var49 = this.a;
      double var51 = var49.squaredDistanceTo(var50);
      double var21 = Math.sqrt(var51);
      int var106 = var20;
      double var104 = var21;
      double var87 = var104;
      double var85 = var104;
      if (var106 != 0) {
         double var134;
         int var107 = (var134 = var85 - 12.0) == 0.0 ? 0 : (var134 < 0.0 ? -1 : 1);
         if (var107 <= 0) {
            Object[] var55 = new Object[]{var5, var16};
            Vec3d var57 = RaycastUtil.aReturningVec3d(var55);
            Vec3d var56 = var7;
            Vec3d var23 = var56.subtract(var57);
            RaycastContext var10004 = this.d;
            Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
            var10012[5] = false;
            var10012[4] = var2;
            var10012[3] = var10004;
            var10012[2] = var23;
            var10012[1] = var5;
            var10012[0] = var6;
            Object[] var59 = var10012;
            ExplosionDamageUtil var58 = this;
            double var24 = var58.p(var59);
            double var26 = (1.0 - var21 / 12.0) * var24;
            double var28 = (var26 * var26 + var26) / 2.0 * 7.0 * 12.0 + 1.0;
            Object[] var132 = new Object[]{null, var14};
            var132[0] = var28;
            Object[] var61 = var132;
            ExplosionDamageUtil var60 = this;
            var28 = var60.mReturningVoid(var61);
            float var127 = (float)var28;
            MinecraftClient var62 = b;
            ClientWorld var63 = var62.world;
            DamageSources var128 = var63.getDamageSources();
            Object var65 = null;
            DamageSources var64 = var128;
            DamageSource var129 = var64.explosion((Explosion)var65);
            LivingEntity var66 = var5;
            float var131 = var66.getArmor();
            RegistryEntry var68 = EntityAttributes.ARMOR_TOUGHNESS;
            LivingEntity var67 = var5;
            EntityAttributeInstance var69 = var67.getAttributeInstance(var68);
            float var74 = (float)var69.getValue();
            float var73 = var131;
            DamageSource var72 = var129;
            float var71 = var127;
            LivingEntity var70 = var5;
            var28 = DamageUtil.getDamageLeft(var70, var71, var72, var73, var74);
            Object[] var10005 = new Object[]{null, null, var18};
            var10005[1] = var28;
            var10005[0] = var5;
            Object[] var76 = var10005;
            ExplosionDamageUtil var75 = this;
            var28 = var75.nReturningVoid(var76);
            MinecraftClient var77 = b;
            ClientWorld var78 = var77.world;
            var128 = var78.getDamageSources();
            Object var80 = null;
            DamageSources var79 = var128;
            var10005 = new Object[]{null, null, var79.explosion((Explosion)var80), var8};
            var10005[1] = var28;
            var10005[0] = var5;
            Object[] var81 = var10005;
            var28 = j(var81);
            int var112 = var20;
            double var110 = var28;
            double var91 = var110;
            double var89 = var110;
            double var93;
            if (var112 != 0) {
               double var135;
               int var113 = (var135 = var89 - 0.0) == 0.0 ? 0 : (var135 < 0.0 ? -1 : 1);
               if (var113 < 0) {
                  var93 = var114;
               } else {
                  var93 = var28;
               }
            } else {
               double var116 = var91;
               var93 = var116;
            }

            return var93;
         }

         var87 = var108;
      }

      return var87;
   }

   public double e(Object[] var1) {
      LivingEntity var2 = (LivingEntity)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      long var3 = (Long)var1[2];
      var3 = 89392438692766L ^ var3;
      long var6 = var3 ^ 26173473218206L;
      return invokeBinding1(this, new Object[]{var2, var5, null, null, null, var6}, -4637897145735615390L, var3);
   }

   private double f(Object[] var1) {
      BlockPos var4;
      BlockState var5;
      LivingEntity var6;
      Vec3d var7;
      BlockPos var8;
      long var9;
      long var11;
      long var13;
      long var15;
      int var17;
      Object var65;
      var6 = (LivingEntity)var1[0];
      var7 = (Vec3d)var1[1];
      var4 = (BlockPos)var1[2];
      var8 = (BlockPos)var1[3];
      var5 = (BlockState)var1[4];
      long var2 = (Long)var1[5];
      var2 = 89392438692766L ^ var2;
      var9 = var2 ^ 87400802282971L;
      var11 = var2 ^ 27951395869088L;
      var13 = var2 ^ 123315346079620L;
      var15 = var2 ^ 55619012455424L;
      var17 = Event.bReturningInt();
      int var77 = var17;
      LivingEntity var76 = var6;
      var65 = var76;
      LivingEntity var62 = var76;
      label38:
      if (var77 == 0) {
         boolean var78 = var62 instanceof PlayerEntity;
         if (var78) {
            PlayerEntity var10000 = (PlayerEntity)var6;
            int var80 = var17;
            PlayerEntity var79 = var10000;
            var65 = var79;
            PlayerEntity var63 = var79;
            if (var80 != 0) {
               break label38;
            }

            PlayerEntity var81 = var63;
            PlayerEntity var64 = var81;
            PlayerEntity var28 = var64;
            PlayerAbilities var29 = var28.getAbilities();
            boolean var82 = var29.creativeMode;
            if (var82) {
               return 0.0;
            }
         }

         var65 = var6;
      }

      Vec3d var33 = var7;
      Object var32 = var65;
      double var34 = ((LivingEntity)var32).squaredDistanceTo(var33);
      double var18 = Math.sqrt(var34);
      int var85 = var17;
      double var83 = var18;
      double var68 = var83;
      double var66 = var83;
      if (var85 == 0) {
         double var104;
         int var86 = (var104 = var66 - 10.0) == 0.0 ? 0 : (var104 < 0.0 ? -1 : 1);
         if (var86 > 0) {
            return 0.0;
         }

         RaycastContext var10004 = this.d;
         Object[] var10012 = new Object[]{null, null, null, null, null, null, var4, var8, var5, var13};
         var10012[5] = false;
         var10012[4] = null;
         var10012[3] = var10004;
         var10012[2] = false;
         var10012[1] = var6;
         var10012[0] = var7;
         Object[] var39 = var10012;
         ExplosionDamageUtil var38 = this;
         var68 = var38.o(var39);
      }

      double var20 = var68;
      double var22 = (1.0 - var18 / 10.0) * var20;
      double var24 = (var22 * var22 + var22) / 2.0 * 7.0 * 10.0 + 1.0;
      Object[] var102 = new Object[]{null, var11};
      var102[0] = var24;
      Object[] var41 = var102;
      ExplosionDamageUtil var40 = this;
      var24 = var40.mReturningVoid(var41);
      Object[] var10005 = new Object[]{null, null, var15};
      var10005[1] = var24;
      var10005[0] = var6;
      Object[] var43 = var10005;
      ExplosionDamageUtil var42 = this;
      var24 = var42.nReturningVoid(var43);
      float var10001 = (float)var24;
      MinecraftClient var44 = b;
      ClientWorld var45 = var44.world;
      DamageSources var10002 = var45.getDamageSources();
      Object var47 = null;
      DamageSources var46 = var10002;
      DamageSource var100 = var46.explosion((Explosion)var47);
      LivingEntity var48 = var6;
      float var10003 = var48.getArmor();
      RegistryEntry var50 = EntityAttributes.ARMOR_TOUGHNESS;
      LivingEntity var49 = var6;
      EntityAttributeInstance var51 = var49.getAttributeInstance(var50);
      float var56 = (float)var51.getValue();
      float var55 = var10003;
      DamageSource var54 = var100;
      float var53 = var10001;
      LivingEntity var52 = var6;
      var24 = DamageUtil.getDamageLeft(var52, var53, var54, var55, var56);
      MinecraftClient var57 = b;
      ClientWorld var58 = var57.world;
      var10002 = var58.getDamageSources();
      Object var60 = null;
      DamageSources var59 = var10002;
      var10005 = new Object[]{null, null, var59.explosion((Explosion)var60), var9};
      var10005[1] = var24;
      var10005[0] = var6;
      Object[] var61 = var10005;
      var24 = j(var61);
      int var89 = var17;
      double var87 = var24;
      double var72 = var87;
      double var70 = var87;
      double var74;
      if (var89 == 0) {
         double var105;
         int var90 = (var105 = var70 - 0.0) == 0.0 ? 0 : (var105 < 0.0 ? -1 : 1);
         if (var90 < 0) {
            var74 = var91;
         } else {
            var74 = var24;
         }
      } else {
         double var93 = var72;
         var74 = var93;
      }

      return var74;
   }

   public double g(Object[] var1) {
      LivingEntity var7 = (LivingEntity)var1[0];
      Vec3d var6 = (Vec3d)var1[1];
      double var2 = (Double)var1[2];
      long var4 = (Long)var1[3];
      var4 = 89392438692766L ^ var4;
      long var8 = var4 ^ 126785054047756L;
      Object[] var10009 = new Object[]{null, null, null, null, null, null, var8};
      var10009[2] = var2;
      var10009[1] = var6;
      var10009[0] = var7;
      Object[] var11 = var10009;
      ExplosionDamageUtil var10 = this;
      return var10.iReturningVoid(var11);
   }

   public double h(Object[] var1) {
      LivingEntity var5 = (LivingEntity)var1[0];
      Vec3d var3 = (Vec3d)var1[1];
      double var7 = (Double)var1[2];
      BlockPos var6 = (BlockPos)var1[3];
      BlockPos var2 = (BlockPos)var1[4];
      BlockState var4 = (BlockState)var1[5];
      long var9 = (Long)var1[6];
      var9 = 89392438692766L ^ var9;
      long var11 = var9 ^ 105380215552988L;
      Object[] var10009 = new Object[]{null, null, null, var6, var2, var4, var11};
      var10009[2] = var7;
      var10009[1] = var3;
      var10009[0] = var5;
      Object[] var14 = var10009;
      ExplosionDamageUtil var13 = this;
      return var13.iReturningVoid(var14);
   }

   private double i(Object[] var1) {
      BlockPos var2;
      BlockState var3;
      LivingEntity var4;
      BlockPos var5;
      Vec3d var8;
      double var9;
      long var11;
      long var13;
      long var15;
      long var17;
      int var19;
      label34: {
         var4 = (LivingEntity)var1[0];
         var8 = (Vec3d)var1[1];
         var9 = (Double)var1[2];
         var5 = (BlockPos)var1[3];
         var2 = (BlockPos)var1[4];
         var3 = (BlockState)var1[5];
         long var6 = (Long)var1[6];
         var6 = 89392438692766L ^ var6;
         var11 = var6 ^ 28702763159028L;
         var13 = var6 ^ 83616684110223L;
         var15 = var6 ^ 40960576757675L;
         var17 = var6 ^ 114292179307567L;
         var19 = Event.bReturningInt();
         boolean var10000 = var4 instanceof PlayerEntity;
         int var82 = var19;
         boolean var81 = var10000;
         boolean var70 = var81;
         boolean var69 = var81;
         if (var82 == 0) {
            boolean var83 = var69;
            if (!var83) {
               break label34;
            }

            PlayerEntity var31 = (PlayerEntity)var4;
            PlayerAbilities var32 = var31.getAbilities();
            boolean var84 = var32.creativeMode;
            var70 = var84;
         }

         boolean var85 = var70;
         if (var85) {
            return 0.0;
         }
      }

      double var37 = 5.0;
      double var35 = var9;
      double var20 = 4.0 + 1.5 * Math.min(var35, var37);
      Vec3d var40 = var8;
      LivingEntity var39 = var4;
      double var41 = var39.squaredDistanceTo(var40);
      double var22 = Math.sqrt(var41);
      int var88 = var19;
      double var86 = var22;
      double var73 = var86;
      double var71 = var86;
      if (var88 == 0) {
         double var107;
         int var89 = (var107 = var71 - var20 * 2.0) == 0.0 ? 0 : (var107 < 0.0 ? -1 : 1);
         if (var89 > 0) {
            return 0.0;
         }

         RaycastContext var10004 = this.d;
         Object[] var10012 = new Object[]{null, null, null, null, null, null, null, var2, var3, var15};
         var10012[5] = false;
         var10012[4] = var5;
         var10012[3] = var10004;
         var10012[2] = false;
         var10012[1] = var4;
         var10012[0] = var8;
         Object[] var46 = var10012;
         ExplosionDamageUtil var45 = this;
         var73 = var45.o(var46);
      }

      double var24 = var73;
      double var26 = (1.0 - var22 / (var20 * 2.0)) * var24;
      double var28 = (var26 * var26 + var26) / 2.0 * 7.0 * (var20 * 2.0) + 1.0;
      Object[] var105 = new Object[]{null, var13};
      var105[0] = var28;
      Object[] var48 = var105;
      ExplosionDamageUtil var47 = this;
      var28 = var47.mReturningVoid(var48);
      Object[] var10005 = new Object[]{null, null, var17};
      var10005[1] = var28;
      var10005[0] = var4;
      Object[] var50 = var10005;
      ExplosionDamageUtil var49 = this;
      var28 = var49.nReturningVoid(var50);
      float var10001 = (float)var28;
      MinecraftClient var51 = b;
      ClientWorld var52 = var51.world;
      DamageSources var10002 = var52.getDamageSources();
      Object var54 = null;
      DamageSources var53 = var10002;
      DamageSource var103 = var53.explosion((Explosion)var54);
      LivingEntity var55 = var4;
      float var10003 = var55.getArmor();
      RegistryEntry var57 = EntityAttributes.ARMOR_TOUGHNESS;
      LivingEntity var56 = var4;
      EntityAttributeInstance var58 = var56.getAttributeInstance(var57);
      float var63 = (float)var58.getValue();
      float var62 = var10003;
      DamageSource var61 = var103;
      float var60 = var10001;
      LivingEntity var59 = var4;
      var28 = DamageUtil.getDamageLeft(var59, var60, var61, var62, var63);
      MinecraftClient var64 = b;
      ClientWorld var65 = var64.world;
      var10002 = var65.getDamageSources();
      Object var67 = null;
      DamageSources var66 = var10002;
      var10005 = new Object[]{null, null, var66.explosion((Explosion)var67), var11};
      var10005[1] = var28;
      var10005[0] = var4;
      Object[] var68 = var10005;
      var28 = j(var68);
      int var92 = var19;
      double var90 = var28;
      double var77 = var90;
      double var75 = var90;
      double var79;
      if (var92 == 0) {
         double var108;
         int var93 = (var108 = var75 - 0.0) == 0.0 ? 0 : (var108 < 0.0 ? -1 : 1);
         if (var93 < 0) {
            var79 = var94;
         } else {
            var79 = var28;
         }
      } else {
         double var96 = var77;
         var79 = var96;
      }

      return var79;
   }

   private static double j(Object[] var0) {
      LivingEntity var4 = (LivingEntity)var0[0];
      double var5 = (Double)var0[1];
      DamageSource var3 = (DamageSource)var0[2];
      long var1 = (Long)var0[3];
      var1 = 89392438692766L ^ var1;
      long var7 = var1 ^ 94537829870892L;
      long var9 = var1 ^ 60025267114778L;
      int var11 = Event.bReturningInt();
      TagKey var23 = DamageTypeTags.BYPASSES_INVULNERABILITY;
      DamageSource var22 = var3;
      byte var10000 = ((byte)((var22.isIn(var23)) ? 1 : 0));
      int var83 = var11;
      byte var82 = var10000;
      byte var63 = var82;
      byte var62 = var82;
      if (var83 == 0) {
         byte var84 = var62;
         if (var84 != 0) {
            return var5;
         }

         var63 = 0;
      }

      int var12 = var63;
      ThreadLocal var26 = g;
      Object2IntMap var13 = (Object2IntMap)var26.get();
      AttributeModifierSlot var27 = AttributeModifierSlot.ARMOR;
      Iterator var14 = var27.iterator();

      int var118;
      do {
         Iterator var28 = var14;
         boolean var85 = var28.hasNext();
         if (!var85) {
            break;
         }

         Iterator var29 = var14;
         EquipmentSlot var15 = (EquipmentSlot)var29.next();
         EquipmentSlot var31 = var15;
         LivingEntity var30 = var4;
         ItemStack var16 = var30.getEquippedStack(var31);
         Object[] var32 = new Object[]{var16, var13, var7};
         aReturningVoid(var32);
         Object[] var33 = new Object[]{var13, Enchantments.PROTECTION, var9};
         int var17 = aReturningInt(var33);
         int var87 = var11;
         int var86 = var17;
         int var65 = var86;
         int var64 = var86;
         if (var87 == 0) {
            int var88 = var64;
            if (var88 > 0) {
               var12 += var17;
            }

            Object[] var35 = new Object[]{var13, Enchantments.FIRE_PROTECTION, var9};
            var65 = aReturningInt(var35);
         }

         int var69;
         int var18 = var65;
         int var90 = var11;
         int var89 = var18;
         var69 = var89;
         int var66 = var89;
         label98:
         if (var90 == 0) {
            int var91 = var66;
            if (var91 > 0) {
               TagKey var38 = DamageTypeTags.IS_FIRE;
               DamageSource var37 = var3;
               var10000 = ((byte)((var37.isIn(var38)) ? 1 : 0));
               int var93 = var11;
               byte var92 = var10000;
               var69 = var92;
               byte var67 = var92;
               if (var93 != 0) {
                  break label98;
               }

               byte var94 = var67;
               byte var68 = var94;
               byte var95 = var68;
               if (var95 != 0) {
                  var12 += 2 * var18;
               }
            }

            Object[] var41 = new Object[]{var13, Enchantments.BLAST_PROTECTION, var9};
            var69 = aReturningInt(var41);
         }

         int var73;
         int var19 = var69;
         int var97 = var11;
         int var96 = var19;
         var73 = var96;
         int var70 = var96;
         label91:
         if (var97 == 0) {
            int var98 = var70;
            if (var98 > 0) {
               TagKey var44 = DamageTypeTags.IS_EXPLOSION;
               DamageSource var43 = var3;
               var10000 = ((byte)((var43.isIn(var44)) ? 1 : 0));
               int var100 = var11;
               byte var99 = var10000;
               var73 = var99;
               byte var71 = var99;
               if (var100 != 0) {
                  break label91;
               }

               byte var101 = var71;
               byte var72 = var101;
               byte var102 = var72;
               if (var102 != 0) {
                  var12 += 2 * var19;
               }
            }

            Object[] var47 = new Object[]{var13, Enchantments.PROJECTILE_PROTECTION, var9};
            var73 = aReturningInt(var47);
         }

         int var77;
         int var20 = var73;
         int var104 = var11;
         int var103 = var20;
         var77 = var103;
         int var74 = var103;
         label84:
         if (var104 == 0) {
            int var105 = var74;
            if (var105 > 0) {
               TagKey var50 = DamageTypeTags.IS_PROJECTILE;
               DamageSource var49 = var3;
               var10000 = ((byte)((var49.isIn(var50)) ? 1 : 0));
               int var107 = var11;
               byte var106 = var10000;
               var77 = var106;
               byte var75 = var106;
               if (var107 != 0) {
                  break label84;
               }

               byte var108 = var75;
               byte var76 = var108;
               byte var109 = var76;
               if (var109 != 0) {
                  var12 += 2 * var20;
               }
            }

            Object[] var53 = new Object[]{var13, Enchantments.FEATHER_FALLING, var9};
            var77 = aReturningInt(var53);
         }

         label106: {
            int var21 = var77;
            int var111 = var11;
            int var110 = var21;
            int var79 = var110;
            int var78 = var110;
            if (var111 == 0) {
               int var112 = var78;
               if (var112 <= 0) {
                  break label106;
               }

               TagKey var56 = DamageTypeTags.IS_FALL;
               DamageSource var55 = var3;
               byte var113 = ((byte)((var55.isIn(var56)) ? 1 : 0));
               var79 = var113;
            }

            int var115 = var11;
            int var114 = var79;
            int var81 = var114;
            int var80 = var114;
            if (var115 == 0) {
               int var116 = var80;
               if (var116 == 0) {
                  break label106;
               }

               int var117 = var12 + 3 * var21;
               var81 = var117;
            }

            var12 = var81;
         }

         var118 = var11;
      } while (var118 == 0);

      float var123 = (float)var5;
      float var61 = var12;
      float var60 = var123;
      return DamageUtil.getInflictedDamage(var60, var61);
   }

   public static void aReturningVoid(Object[] var0) {
      ItemStack var2 = (ItemStack)var0[0];
      Object2IntMap var1 = (Object2IntMap)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 89392438692766L ^ var3;
      int var46 = Event.bReturningInt();
      Object2IntMap var9 = var1;
      var9.clear();
      int var5 = var46;
      int var36 = var5;
      ItemStack var35 = var2;
      ItemStack var31 = var35;
      ItemStack var30 = var35;
      if (var36 == 0) {
         ItemStack var10 = var30;
         boolean var37 = var10.isEmpty();
         if (var37) {
            return;
         }

         ItemStack var38 = var2;
         var31 = var38;
      }

      Set var34;
      label28: {
         int var40 = var5;
         ItemStack var39 = var31;
         ItemStack var33 = var39;
         ItemStack var32 = var39;
         if (var40 == 0) {
            ItemStack var13 = var32;
            Item var47 = var13.getItem();
            Item var42 = Items.ENCHANTED_BOOK;
            Item var41 = var47;
            if (var41 == var42) {
               ItemEnchantmentsComponent var17 = ItemEnchantmentsComponent.DEFAULT;
               ComponentType var16 = DataComponentTypes.STORED_ENCHANTMENTS;
               ItemStack var15 = var2;
               ItemEnchantmentsComponent var18 = (ItemEnchantmentsComponent)var15.getOrDefault(var16, var17);
               Set var43 = var18.getEnchantmentEntries();
               var34 = var43;
               break label28;
            }

            var33 = var2;
         }

         ItemStack var20 = var33;
         ItemEnchantmentsComponent var21 = var20.getEnchantments();
         var34 = var21.getEnchantmentEntries();
      }

      Set var6 = var34;
      Set var22 = var6;
      Iterator var7 = var22.iterator();

      int var45;
      do {
         Iterator var23 = var7;
         boolean var44 = var23.hasNext();
         if (!var44) {
            break;
         }

         Iterator var24 = var7;
         Entry var8 = (Entry)var24.next();
         Entry var25 = var8;
         RegistryEntry var10001 = (RegistryEntry)var25.getKey();
         Entry var26 = var8;
         int var29 = var26.getIntValue();
         RegistryEntry var28 = var10001;
         Object2IntMap var27 = var1;
         var27.put(var28, var29);
         var45 = var5;
      } while (var45 == 0);
   }

   public static int aReturningInt(Object[] var0) {
      Object2IntMap var4 = (Object2IntMap)var0[0];
      RegistryKey var3 = (RegistryKey)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 89392438692766L ^ var1;
      int var32 = Event.cReturningInt();
      Object2IntMap var8 = var4;
      ObjectIterable var9 = Object2IntMaps.fastIterable(var8);
      ObjectIterator var6 = var9.iterator();
      int var5 = var32;

      byte var22;
      while (true) {
         ObjectIterator var10 = var6;
         boolean var23 = ((Iterator)var10).hasNext();
         if (var23) {
            ObjectIterator var11 = var6;
            Entry var7 = (Entry)((Iterator)var11).next();
            Entry var12 = var7;
            RegistryEntry var33 = (RegistryEntry)var12.getKey();
            RegistryKey var14 = var3;
            RegistryEntry var13 = var33;
            byte var34 = ((byte)((var13.matchesKey(var14)) ? 1 : 0));
            int var25 = var5;
            byte var24 = var34;
            var22 = var24;
            byte var18 = var24;
            if (var25 == 0) {
               break;
            }

            int var27 = var5;
            byte var26 = var18;
            int var21 = var26;
            byte var19 = var26;
            if (var27 == 0) {
               return var21;
            }

            byte var28 = var19;
            byte var20 = var28;
            byte var29 = var20;
            if (var29 != 0) {
               Entry var17 = var7;
               int var30 = var17.getIntValue();
               var21 = var30;
               return var21;
            }

            int var31 = var5;
            if (var31 != 0) {
               continue;
            }
         }

         var22 = 0;
         break;
      }

      return var22;
   }

   public double k(Object[] var1) {
      LivingEntity var5 = (LivingEntity)var1[0];
      Vec3d var2 = (Vec3d)var1[1];
      long var3 = (Long)var1[2];
      var3 = 89392438692766L ^ var3;
      long var6 = var3 ^ 43296884029748L;
      Vec3d var8 = var2;
      Object[] var10 = new Object[]{var5, var2, BlockPos.ofFloored((Position)var8), null, null, var6};
      ExplosionDamageUtil var9 = this;
      return var9.fReturningVoid(var10);
   }

   public double l(Object[] var1) {
      LivingEntity var7 = (LivingEntity)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      BlockPos var2 = (BlockPos)var1[2];
      BlockState var6 = (BlockState)var1[3];
      long var3 = (Long)var1[4];
      var3 = 89392438692766L ^ var3;
      long var8 = var3 ^ 10180622955848L;
      Vec3d var10 = var5;
      Object[] var12 = new Object[]{var7, var5, BlockPos.ofFloored((Position)var10), var2, var6, var8};
      ExplosionDamageUtil var11 = this;
      return var11.fReturningVoid(var12);
   }

   
   
    private double m(Object[] objectArray) {
        double d = (Double)objectArray[0];
        long l = (Long)objectArray[1];
        long cfr_ignored_0 = 0x514D4C8DCB9EL ^ l;
        MinecraftClient minecraftClient = b;
        ClientWorld clientWorld = minecraftClient.world;
        Difficulty difficulty = clientWorld.getDifficulty();
        return switch (DifficultySwitchMap.a[difficulty.ordinal()]) {
            case 1 -> 0.0;
            case 2 -> {
                double var12_7 = d;
                double var10_8 = d / 2.0 + 1.0;
                yield Math.min(var10_8, var12_7);
            }
            case 3 -> d * 3.0 / 2.0;
            default -> d;
        };
    }

   private double n(Object[] var1) {
      LivingEntity var2 = (LivingEntity)var1[0];
      double var3 = (Double)var1[1];
      long var5 = (Long)var1[2];
      long var10000 = 89392438692766L ^ var5;
      int var35 = Event.bReturningInt();
      double var8 = var3;
      int var7 = var35;
      RegistryEntry var12 = StatusEffects.RESISTANCE;
      LivingEntity var11 = var2;
      byte var36 = ((byte)((var11.hasStatusEffect(var12)) ? 1 : 0));
      int var26 = var7;
      byte var25 = var36;
      int var20 = var25;
      byte var17 = var25;
      if (var26 == 0) {
         byte var27 = var17;
         if (var27 != 0) {
            RegistryEntry var15 = StatusEffects.RESISTANCE;
            LivingEntity var14 = var2;
            StatusEffectInstance var16 = var14.getStatusEffect(var15);
            int var10 = var16.getAmplifier() + 1;
            var8 *= 1.0 - var10 * 0.2;
         }

         int var30 = var7;
         double var28 = var8;
         double var21 = var28;
         double var18 = var28;
         if (var30 != 0) {
            return var21;
         }

         double var37;
         int var31 = (var37 = var18 - 0.0) == 0.0 ? 0 : (var37 < 0.0 ? -1 : 1);
         var20 = var31;
      }

      int var32 = var20;
      return var32 >= 0 ? var8 : 0.0;
   }

   private double o(Object[] var1) {
      Vec3d var12 = (Vec3d)var1[0];
      Entity var10 = (Entity)var1[1];
      boolean var7 = (Boolean)var1[2];
      RaycastContext var4 = (RaycastContext)var1[3];
      BlockPos var6 = (BlockPos)var1[4];
      boolean var9 = (Boolean)var1[5];
      BlockPos var5 = (BlockPos)var1[6];
      BlockPos var8 = (BlockPos)var1[7];
      BlockState var11 = (BlockState)var1[8];
      long var2 = (Long)var1[9];
      var2 = 89392438692766L ^ var2;
      long var13 = var2 ^ 63506758685498L;
      boolean var32 = var7;
      Entity var31 = var10;
      Vec3d var30 = var12;
      ExplosionDamageUtil var29 = this;
      ExplosionDamageUtil var22 = var29;
      Vec3d var23 = var30;
      Entity var24 = var31;
      ExplosionDamageUtil var19 = var29;
      Vec3d var20 = var30;
      Entity var21 = var31;
      ExplosionDamageUtil var25;
      Vec3d var26;
      Entity var27;
      Vec3d var28;
      if (var32) {
         Entity var15 = var10;
         Vec3d var36 = var15.getVelocity();
         Entity var35 = var21;
         Vec3d var34 = var20;
         ExplosionDamageUtil var33 = var19;
         var25 = var33;
         var26 = var34;
         var27 = var35;
         var28 = var36;
      } else {
         var28 = null;
         var27 = var24;
         var26 = var23;
         var25 = var22;
      }

      Object[] var10012 = new Object[]{null, null, null, null, null, null, var5, var8, var11, var13};
      var10012[5] = var9;
      var10012[4] = var6;
      var10012[3] = var4;
      var10012[2] = var28;
      var10012[1] = var27;
      var10012[0] = var26;
      Object[] var18 = var10012;
      ExplosionDamageUtil var17 = var25;
      return var17.p(var18);
   }

   private double p(Object[] var1) {
      Vec3d var9 = (Vec3d)var1[0];
      Entity var11 = (Entity)var1[1];
      Vec3d var8 = (Vec3d)var1[2];
      RaycastContext var10 = (RaycastContext)var1[3];
      BlockPos var3 = (BlockPos)var1[4];
      boolean var12 = (Boolean)var1[5];
      BlockPos var2 = (BlockPos)var1[6];
      BlockPos var4 = (BlockPos)var1[7];
      BlockState var7 = (BlockState)var1[8];
      long var5 = (Long)var1[9];
      var5 = 89392438692766L ^ var5;
      long var13 = var5 ^ 100044232846469L;
      long var15 = var5 ^ 16058084119172L;
      long var17 = var5 ^ 82929205475060L;
      int var10000 = Event.cReturningInt();
      Entity var47 = var11;
      Box var20 = var47.getBoundingBox();
      int var19 = var10000;
      Vec3d var125 = var8;
      if (var125 != null) {
         Vec3d var48 = var8;
         Vec3d var49 = var8;
         Vec3d var50 = var8;
         double var56 = var50.z;
         double var54 = var49.y;
         double var52 = var48.x;
         Box var51 = var20;
         var20 = var51.offset(var52, var54, var56);
      }

      Box var58 = var20;
      Box var59 = var20;
      double var21 = 1.0 / ((var58.maxX - var59.minX) * 2.0 + 1.0);
      Box var60 = var20;
      Box var61 = var20;
      double var23 = 1.0 / ((var60.maxY - var61.minY) * 2.0 + 1.0);
      Box var62 = var20;
      Box var63 = var20;
      double var25 = 1.0 / ((var62.maxZ - var63.minZ) * 2.0 + 1.0);
      double var64 = 1.0 / var21;
      double var27 = (1.0 - Math.floor(var64) * var21) / 2.0;
      double var66 = 1.0 / var25;
      double var29 = (1.0 - Math.floor(var66) * var25) / 2.0;
      int var128 = var19;
      double var126 = var21;
      double var123 = var126;
      double var105 = var126;
      if (var128 != 0) {
         double var160;
         int var129 = (var160 = var105 - 0.0) == 0.0 ? 0 : (var160 < 0.0 ? -1 : 1);
         if (var129 >= 0) {
            int var132 = var19;
            double var130 = var23;
            var123 = var130;
            double var107 = var130;
            if (var132 == 0) {
               return var123;
            }

            double var133 = var107;
            double var109 = var133;
            double var161;
            int var135 = (var161 = var109 - 0.0) == 0.0 ? 0 : (var161 < 0.0 ? -1 : 1);
            if (var135 >= 0) {
               int var138 = var19;
               double var136 = var25;
               var123 = var136;
               double var111 = var136;
               if (var138 == 0) {
                  return var123;
               }

               double var139 = var111;
               double var113 = var139;
               double var162;
               int var141 = (var162 = var113 - 0.0) == 0.0 ? 0 : (var162 < 0.0 ? -1 : 1);
               if (var141 >= 0) {
                  Vec3dAccessor var33 = new Vec3dAccessor(this.a);
                  RaycastContextAccessor var34 = new RaycastContextAccessor(var10);
                  double var121;
                  while (true) {
                     double var163;
                     int var142 = (var163 = var35 - 1.0) == 0.0 ? 0 : (var163 < 0.0 ? -1 : 1);
                     if (var142 <= 0) {
                        int var145 = var19;
                        var121 = var143;
                        double var115 = var143;
                        if (var145 == 0) {
                           break;
                        }

                        double var37 = var115;

                        double var119;
                        label68: {
                           int var156;
                           do {
                              double var164;
                              int var146 = (var164 = var37 - 1.0) == 0.0 ? 0 : (var164 < 0.0 ? -1 : 1);
                              if (var146 > 0) {
                                 break;
                              }

                              int var149 = var19;
                              var119 = var147;
                              double var117 = var147;
                              if (var149 == 0) {
                                 break label68;
                              }

                              double var39 = var117;

                              while (true) {
                                 double var165;
                                 int var150 = (var165 = var39 - 1.0) == 0.0 ? 0 : (var165 < 0.0 ? -1 : 1);
                                 if (var150 <= 0) {
                                    Box var73 = var20;
                                    Box var74 = var20;
                                    double var79 = var74.maxX;
                                    double var77 = var73.minX;
                                    double var75 = var35;
                                    double var41 = MathHelper.lerp(var75, var77, var79);
                                    Box var81 = var20;
                                    Box var82 = var20;
                                    double var87 = var82.maxY;
                                    double var85 = var81.minY;
                                    double var83 = var37;
                                    double var43 = MathHelper.lerp(var83, var85, var87);
                                    Box var89 = var20;
                                    Box var90 = var20;
                                    double var95 = var90.maxZ;
                                    double var93 = var89.minZ;
                                    double var91 = var39;
                                    double var45 = MathHelper.lerp(var91, var93, var95);
                                    double var10001 = var41 + var27;
                                    double var10003 = var45 + var29;
                                    Object[] var10006 = new Object[]{null, null, null, var13};
                                    var10006[2] = var10003;
                                    var10006[1] = var43;
                                    var10006[0] = var10001;
                                    Object[] var98 = var10006;
                                    Vec3dAccessor var97 = var33;
                                    var97.dReturningVoid(var98);
                                    Object[] var100 = new Object[]{this.a, var9, ShapeType.COLLIDER, FluidHandling.NONE, var11, var17};
                                    RaycastContextAccessor var99 = var34;
                                    var99.fReturningVoid(var100);
                                    int var151 = var19;
                                    if (var151 == 0) {
                                       break;
                                    }

                                    int var152 = var19;
                                    if (var152 != 0) {
                                       Object[] var10009 = new Object[]{null, null, null, var2, var4, var7, var15};
                                       var10009[2] = var12;
                                       var10009[1] = var3;
                                       var10009[0] = var10;
                                       Object[] var103 = var10009;
                                       ExplosionDamageUtil var102 = this;
                                       BlockHitResult var104 = var102.aReturningBlockHitResult(var103);
                                       Type var159 = var104.getType();
                                       Type var154 = Type.MISS;
                                       Type var153 = var159;
                                       if (var153 == var154) {
                                          var31++;
                                       }

                                       var32++;
                                       var39 += var25;
                                    }

                                    int var155 = var19;
                                    if (var155 != 0) {
                                       continue;
                                    }
                                 }

                                 var37 += var23;
                                 break;
                              }

                              var156 = var19;
                           } while (var156 != 0);

                           var119 = var35 + var21;
                        }

                        var35 = var119;
                        int var157 = var19;
                        if (var157 != 0) {
                           continue;
                        }
                     }

                     var121 = (double)var31 / var32;
                     break;
                  }

                  return var121;
               }
            }
         }

         var123 = 0.0;
      }

      return var123;
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      RaycastContext var3 = (RaycastContext)var1[0];
      BlockPos var4 = (BlockPos)var1[1];
      boolean var9 = (Boolean)var1[2];
      BlockPos var7 = (BlockPos)var1[3];
      BlockPos var2 = (BlockPos)var1[4];
      BlockState var8 = (BlockState)var1[5];
      long var5 = (Long)var1[6];
      long var10000 = 89392438692766L ^ var5;
      RaycastContext var10 = var3;
      Vec3d var17 = var10.getStart();
      RaycastContext var11 = var3;
      Vec3d var10001 = var11.getEnd();
      BiFunction var10003 = invokeBinding2(var7, var2, var8, var4, var9);
      Function var16 = invokeBinding3();
      BiFunction var15 = var10003;
      RaycastContext var14 = var3;
      Vec3d var13 = var10001;
      Vec3d var12 = var17;
      return (BlockHitResult)BlockView.raycast(var12, var13, var14, var15, var16);
   }

   private static BlockHitResult lambda$raycast$1(RaycastContext var0) {
      RaycastContext var4 = var0;
      Vec3d var10000 = var4.getStart();
      RaycastContext var5 = var0;
      Vec3d var7 = var5.getEnd();
      Vec3d var6 = var10000;
      Vec3d var3 = var6.subtract(var7);
      RaycastContext var8 = var0;
      var10000 = var8.getEnd();
      Vec3d var9 = var3;
      Vec3d var10 = var3;
      Vec3d var11 = var3;
      double var16 = var11.z;
      double var14 = var10.y;
      double var12 = var9.x;
      Direction var10001 = Direction.getFacing(var12, var14, var16);
      RaycastContext var18 = var0;
      Vec3d var19 = var18.getEnd();
      BlockPos var22 = BlockPos.ofFloored((Position)var19);
      Direction var21 = var10001;
      Vec3d var20 = var10000;
      return BlockHitResult.createMissed(var20, var21, var22);
   }

   private static BlockHitResult lambda$raycast$0(
      BlockPos var0, BlockPos var1, BlockState var2, BlockPos var3, boolean var4, RaycastContext var5, BlockPos var6
   ) {
      BlockState var10;
      label80: {
         int var9;
         BlockPos var75;
         var9 = Event.cReturningInt();
         int var89 = var9;
         BlockPos var88 = var0;
         var75 = var88;
         BlockPos var72 = var88;
         label76:
         if (var89 != 0) {
            BlockPos var90 = var72;
            if (var90 != null) {
               int var92 = var9;
               BlockPos var91 = var6;
               var75 = var91;
               BlockPos var73 = var91;
               if (var92 == 0) {
                  break label76;
               }

               BlockPos var93 = var73;
               BlockPos var74 = var93;
               BlockPos var24 = var0;
               BlockPos var23 = var74;
               boolean var94 = var23.equals(var24);
               if (var94) {
                  Block var26 = Blocks.AIR;
                  var10 = var26.getDefaultState();
                  int var95 = var9;
                  if (var95 != 0) {
                     break label80;
                  }
               }
            }

            BlockPos var96 = var1;
            var75 = var96;
         }

         boolean var80;
         label66: {
            int var98 = var9;
            BlockPos var97 = var75;
            BlockPos var79 = var97;
            BlockPos var76 = var97;
            if (var98 != 0) {
               BlockPos var99 = var76;
               if (var99 != null) {
                  BlockPos var30 = var1;
                  BlockPos var29 = var6;
                  boolean var10000 = var29.equals(var30);
                  int var101 = var9;
                  boolean var100 = var10000;
                  var80 = var100;
                  boolean var77 = var100;
                  if (var101 == 0) {
                     break label66;
                  }

                  boolean var102 = var77;
                  boolean var78 = var102;
                  boolean var103 = var78;
                  if (var103) {
                     var10 = var2;
                     int var104 = var9;
                     if (var104 != 0) {
                        break label80;
                     }
                  }
               }

               BlockPos var105 = var6;
               var79 = var105;
            }

            BlockPos var35 = var3;
            BlockPos var34 = var79;
            var80 = var34.equals(var35);
         }

         boolean var106 = var80;
         if (var106) {
            Block var36 = Blocks.OBSIDIAN;
            var10 = var36.getDefaultState();
            int var107 = var9;
            if (var107 != 0) {
               break label80;
            }
         }

         MinecraftClient var37 = b;
         BlockPos var39 = var6;
         ClientWorld var38 = var37.world;
         var10 = var38.getBlockState(var39);
         BlockState var40 = var10;
         Block var41 = var40.getBlock();
         float var123;
         int var120 = (var123 = var41.getBlastResistance() - 600.0F) == 0.0F ? 0 : (var123 < 0.0F ? -1 : 1);
         int var109 = var9;
         int var108 = var120;
         int var82 = var108;
         int var81 = var108;
         if (var109 != 0) {
            int var110 = var81;
            if (var110 >= 0) {
               break label80;
            }

            var82 = (((var4) ? 1 : 0));
         }

         int var111 = var82;
         if (var111 != 0) {
            Block var43 = Blocks.AIR;
            var10 = var43.getDefaultState();
         }
      }

      RaycastContext var44 = var5;
      Vec3d var11 = var44.getStart();
      RaycastContext var45 = var5;
      Vec3d var12 = var45.getEnd();
      MinecraftClient var46 = b;
      BlockPos var50 = var6;
      ClientWorld var49 = var46.world;
      BlockState var48 = var10;
      RaycastContext var47 = var5;
      VoxelShape var13 = var47.getBlockShape(var48, (BlockView)var49, var50);
      MinecraftClient var51 = b;
      BlockState var57 = var10;
      VoxelShape var56 = var13;
      BlockPos var55 = var6;
      Vec3d var54 = var12;
      Vec3d var53 = var11;
      ClientWorld var52 = var51.world;
      BlockHitResult var14 = var52.raycastBlock(var53, var54, var55, var56, var57);
      VoxelShape var15 = VoxelShapes.empty();
      BlockPos var61 = var6;
      Vec3d var60 = var12;
      Vec3d var59 = var11;
      VoxelShape var58 = var15;
      BlockHitResult var16 = var58.raycast(var59, var60, var61);
      BlockHitResult var112 = var14;
      double var83;
      if (var112 == null) {
         double var113 = Double.MAX_VALUE;
         var83 = var113;
      } else {
         RaycastContext var63 = var5;
         Vec3d var121 = var63.getStart();
         BlockHitResult var64 = var14;
         Vec3d var66 = var64.getPos();
         Vec3d var65 = var121;
         var83 = var65.squaredDistanceTo(var66);
      }

      double var17 = var83;
      BlockHitResult var115 = var16;
      double var85;
      if (var115 == null) {
         double var116 = Double.MAX_VALUE;
         var85 = var116;
      } else {
         RaycastContext var68 = var5;
         Vec3d var122 = var68.getStart();
         BlockHitResult var69 = var16;
         Vec3d var71 = var69.getPos();
         Vec3d var70 = var122;
         var85 = var70.squaredDistanceTo(var71);
      }

      double var19 = var85;
      double var124;
      int var118 = (var124 = var17 - var19) == 0.0 ? 0 : (var124 < 0.0 ? -1 : 1);
      BlockHitResult var87;
      if (var118 <= 0) {
         BlockHitResult var119 = var14;
         var87 = var119;
      } else {
         var87 = var16;
      }

      return var87;
   }

   static {

      aReturningVoid();
      Cipher var0;
      Cipher var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(83513408085033L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -1112612351380951745L;
      byte[] var4 = var0.doFinal(
         new byte[]{
            (byte)240L,
            (byte)61583L,
            (byte)15765300L,
            (byte)4035917046L,
            (byte)1033194763799L,
            (byte)264497859532601L,
            (byte)67711452040346093L,
            (byte)-1112612351380951745L
         }
      );
      long var9 = (var4[0] & 255L) << 56
         | (var4[1] & 255L) << 48
         | (var4[2] & 255L) << 40
         | (var4[3] & 255L) << 32
         | (var4[4] & 255L) << 24
         | (var4[5] & 255L) << 16
         | (var4[6] & 255L) << 8
         | var4[7] & 255L;
      // i = var9;
      Supplier var7 = invokeBinding4();
      g = ThreadLocal.withInitial(var7);
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = k[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = j[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 60;
            yield var15;
         }
         case 1 -> {
            byte var16 = 42;
            yield var16;
         }
         case 2 -> {
            byte var17 = 14;
            yield var17;
         }
         case 3 -> {
            byte var18 = 41;
            yield var18;
         }
         case 4 -> {
            byte var19 = 19;
            yield var19;
         }
         case 5 -> {
            byte var20 = 45;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 25;
            yield var22;
         }
         case 8 -> {
            byte var23 = 40;
            yield var23;
         }
         case 9 -> {
            byte var24 = 48;
            yield var24;
         }
         case 10 -> {
            byte var25 = 61;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 49;
            yield var27;
         }
         case 13 -> {
            byte var28 = 30;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 28;
            yield var30;
         }
         case 16 -> {
            byte var31 = 59;
            yield var31;
         }
         case 17 -> {
            byte var32 = 17;
            yield var32;
         }
         case 18 -> {
            byte var33 = 53;
            yield var33;
         }
         case 19 -> {
            byte var34 = 34;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 1;
            yield var36;
         }
         case 22 -> {
            byte var37 = 37;
            yield var37;
         }
         case 23 -> {
            byte var38 = 24;
            yield var38;
         }
         case 24 -> {
            byte var39 = 23;
            yield var39;
         }
         case 25 -> {
            byte var40 = 55;
            yield var40;
         }
         case 26 -> {
            byte var41 = 8;
            yield var41;
         }
         case 27 -> {
            byte var42 = 15;
            yield var42;
         }
         case 28 -> {
            byte var43 = 7;
            yield var43;
         }
         case 29 -> {
            byte var44 = 58;
            yield var44;
         }
         case 30 -> {
            byte var45 = 3;
            yield var45;
         }
         case 31 -> {
            byte var46 = 36;
            yield var46;
         }
         case 32 -> {
            byte var47 = 21;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 5;
            yield var49;
         }
         case 35 -> {
            byte var50 = 43;
            yield var50;
         }
         case 36 -> {
            byte var51 = 13;
            yield var51;
         }
         case 37 -> {
            byte var52 = 57;
            yield var52;
         }
         case 38 -> {
            byte var53 = 4;
            yield var53;
         }
         case 39 -> {
            byte var54 = 18;
            yield var54;
         }
         case 40 -> {
            byte var55 = 46;
            yield var55;
         }
         case 41 -> {
            byte var56 = 2;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 22;
            yield var58;
         }
         case 44 -> {
            byte var59 = 0;
            yield var59;
         }
         case 45 -> {
            byte var60 = 29;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 27;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 44;
            yield var64;
         }
         case 50 -> {
            byte var65 = 12;
            yield var65;
         }
         case 51 -> {
            byte var66 = 31;
            yield var66;
         }
         case 52 -> {
            byte var67 = 62;
            yield var67;
         }
         case 53 -> {
            byte var68 = 11;
            yield var68;
         }
         case 54 -> {
            byte var69 = 38;
            yield var69;
         }
         case 55 -> {
            byte var70 = 33;
            yield var70;
         }
         case 56 -> {
            byte var71 = 35;
            yield var71;
         }
         case 57 -> {
            byte var72 = 52;
            yield var72;
         }
         case 58 -> {
            byte var73 = 50;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 51;
            yield var75;
         }
         case 61 -> {
            byte var76 = 20;
            yield var76;
         }
         case 62 -> {
            byte var77 = 6;
            yield var77;
         }
         default -> 56;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            k[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      j[0] = "ED\u0006lc\u000bSD\u00036p\u001cD\u000f\u00000|\bUH\u0017'7\u001aY";
      j[1] = "AO#euv4o(jd9Ua#a`c!";
      j[2] = double.class;
      k[2] = "java/lang/Double";
      j[3] = "\"[_s\u0019\f\"[H/\u0015\u00038\u0010H1\u0015\u0016?a\u0018dA\\h]G<\u0007\u0016\u0013\f\u001fo";
      j[4] = "\u0010\u0016a\u0006n]\u0010\u0016vZbR\n]vDbG\r,&\u00193";
      j[5] = "I\u0017rFN6I\u0017e\u001aB9S\\e\u0004B,T-1\\\u0015";
      j[6] = "k\u0001\na\u0010dk\u0001\u001d=\u001ckqJ\u001d#\u001c~v;MvH4!\u0007\u0012.\u000e~ZWGyM";
      j[7] = "HdL\u000e8\u000bHd[R4\u0004R/[L4\u0011U^\u000b\u0019`[";
      j[8] = "\"\u0002P\u001eqU\"\u0002GB}Z8IG\\}O?8\u0016\u0004/";
      j[9] = "oKee#\u0005oKr9/\nu\u0000r'/\u001frq r|^";
      j[10] = "D-\u0011Z\u0018EO\"\u0000\u0015yKD)\u0004O";
      j[11] = ")&m\fo%7.wC'%-$o\u0004.>m\u0005r+4> 3r\u0002/";
      j[12] = "d\u0002A\u0018!\u0017z\n[Wi\u0017`\u0000C\u0010`\f %B\u0017l\u0016g\fY";
      j[13] = "\u0011y =M\u0002\u0011y7aA\r\u000b27\u007fA\u0018\fCb \u0018";
      j[14] = "07z<|F07m`pI*|m~p\\-\r? '\u0018";
      j[15] = int.class;
      k[15] = "java/lang/Integer";
      j[16] = ">PDE_\u00185_U\n<\u0015 RZa\t\u00171AFM\u001e\u001a";
      j[17] = "*Ns\u0002W\u0001!AbM4\f4G";
      j[18] = "a\u0010=3j\u0006a\u0010*of\t{[*qf\u001c|*{/3W";
      j[19] = "h:k`\u0017\th:|<\u001b\u0006rq|\"\u001b\u0013u\u0000-xBP";
      j[20] = ":\u001d`rdB:\u001dw.hM Vw0hX''&n=\u001d";
      j[21] = "OH\u000fu\u0013_OH\u0018)\u001fPU\u0003\u00187\u001fERrInG";
      j[22] = "\u0012@\u001cZpP\u0012@\u000b\u0006|_\b\u000b\u000b\u0018|J\u000fzZB(";
      j[23] = "I?4p>9I?#,26St#22#T\u0005rm`h";
      j[24] = float.class;
      k[24] = "java/lang/Float";
      j[25] = "\u001fE\u0006O{X\u001fE\u0011\u0013wW\u0005\u000e\u0011\rwB\u0002\u007fAX \u0004";
      j[26] = "\u0004\f\u0002Gg_\u0012\f\u0007\u001dtH\u0005G\u0004\u001bx\\\u0014\u0000\u0013\f3N%";
      j[27] = boolean.class;
      k[27] = "java/lang/Boolean";
      j[28] = "kR^V$<kRI\n(3q\u0019I\u0014(&vh\u0018K~a";
      j[29] = ".WS\b&/.WDT* 4\u001cDJ*53m\u0016\u0011r\u007f";
      j[30] = "9LW\u0014s)9L@H\u007f&#\u0007@V\u007f3$v\u001a\t-q";
      j[31] = "?3\u0011u\u0018\u0015?3\u0006)\u0014\u001a%x\u00067\u0014\u000f\"\tTlLN";
      j[32] = "XH\u001eCBLXH\t\u001fNCB\u0003\t\u0001NVErS^\u001f\u0011";
      j[33] = "4qW\u0005xw*yMJ\u0005g*";
      j[34] = "oe\u0010K\u0006gkx\u0010Z\u001bg(w_M\u001c{rxR\u0010\u0007llt]J\u001b IsT[\u000bz4XPJ%ov";
      j[35] = "wfPgU`inJ(2axuGr\u0014g";
      j[36] = "UIeMx\u0001UIr\u0011t\u000eO\u0002r\u000ft\u001bHs(P&\\";
      j[37] = "\u001cf\u0012G Y\u0018{\u0012V=Y[t]A:E\u0001{P\u001c!R\u001fw_F=\u001e:pVW-DG[RF\u0003Q\u00056y\\:B\f";
      j[38] = void.class;
      k[38] = "java/lang/Void";
      j[39] = "\b49d1/\b4.8= \u0012\u007f.&=5\u0015\u000e|rlt";
      j[40] = "\u0010B.g\u000b4eb%h\u001a{\u0004l.c\u001e!p";
      j[41] = "F0c\u001fM[F0tCAT\\{t]AA[\n!\u0005\u0010";
      j[42] = "8W\u000f3\u001c/8W\u0018o\u0010 \"\u001c\u0018q\u00105%mJ$Br";
      j[43] = "\u001d\u0015C\u0014\u0005\"\u001d\u0015TH\t-\u0007^TV\t8\u0000/\u0006\tZ\u007f";
      j[44] = "GI M[,GI7\u0011W#]\u00027\u000fW6ZslR\u0006|";
      j[45] = "N_K'!+N_\\{-$T\u0014\\e-1Se\u000e0~u";
      j[46] = "d\u0001m\u0011ztd\u0001zMv{~JzSvny;(\r//";
      j[47] = "[A;yUu[A,%YzA\n,;YoF{~d\b%";
      j[48] = "?.\r\t\b1?.\u001aU\u0004>%e\u001aK\u0004+\"\u0014O\u0014Q";
      j[49] = "[P\t\u0007(pEX\u0013HSPxu";
      j[50] = "%zDk@)%zS7L&?1S)L38@\u0001w\u0015p";
      j[51] = "PY0KPMFY5\u0011CZQ\u00126\u0017ON@U!\u0000\u0004^\u0007";
      j[52] = "J\u0005\n#>;?%\u0001,/t^+\n'+.*";
      j[53] = "znx'\u001c<\u000fNs(\rsn@x#\t)\u001a";
      j[54] = "\u0004{eC;%\u0012{`\u0019(2\u00050c\u001f$&\u0014wt\bo4\u0002";
      j[55] = "\u001d\t\"\u001ax/h))\u0015i`\t'\"\u001em:}";
      j[56] = "R&\r+PT'\u0006\u0006$A\u001bF\b\r/EA2";
      j[57] = "8M\u0006ef\u001bMm\rjwT,c\u0006as\u000eX";
      j[58] = "\u001eN\"\u000b3 kn)\u0004\"o\n`\"\u000f&5~";
      j[59] = "';sHNw';d\u0014Bx=pd\nBm:\u00012W\u0010*";
      j[60] = "_\u001d!>E\u0007_\u001d6bI\bEV6|I\u001dB'c(\u0010^";
      j[61] = "mW\u0012\u001e+#\u0018w\u0019\u0011:lyy\u0012\u001a>6\r";
      j[62] = "q+Wp\u007f|q+@,ssk`@2sfl\u0011\u0012l+\"";
      j[63] = "NZ!\u0002\u0005rNZ6^\t}T\u00116@\thS`d\u001eQ(";
      j[64] = "i>A$3\\i>Vx?SsuVf?Ft\u0004\u00048g\u0001";
      j[65] = ":\u000e|b\u0007X:\u000ek>\u000bW Ek \u000bB'49z_\u0007";
      j[66] = "1F{G/\u001b1Fl\u001b#\u0014+\rl\u0005#\u0001,|>_wE";
      j[67] = "\u000br/ /I\u000br8|#F\u001198b#S\u0016Hi=z";
      j[68] = "\"j\u001dG1z\"j\n\u001b=u8!\n\u0005=`?P[Ze7/c\b\u001a/L~;Y";
      j[69] = "D~R\t\rCD~EU\u0001L^5EK\u0001YYD\u0015\u0012S\u0018";
      j[70] = "o<\u001blIr\u001a\u001c\u0010cX={\u0012\u001bh\\g\u000f";
      j[71] = "XL[RY}NL^\bJjY\u0007]\u000eF~H@J\u0019\rZ";
      j[72] = "\u001e=\u0000S{{k\u001d\u000b\\j4\n\u0013\u0000Wnn~";
      j[73] = "s\rA\u000ep\\s\rVR|SiFVL|Fn7\r\u0011-\u0006";
      j[74] = "A@n\u0018?\u0006A@yD3\t[\u000byZ3\u001c\\z,\u000ed]";
      j[75] = "O:@]=vO:W\u00011yUqW\u001f1lR\u0000\u0005@`+";
      j[76] = "\"\u0013oU\u001b'\"\u0013x\t\u0017(8Xx\u0017\u0017=?)*CO}";
      j[77] = "Y\u001bs\u0003xOY\u001bd_t@CPdAtUD!2\u001e'\u0017";
      j[78] = "\u0002}\u0005r&ww]\u000e}78\u0016S\u0005v3bb";
      j[79] = "<\r4\u0010\u00026<\r#L\u000e9&F#R\u000e,!7y\fXk";
      j[80] = "\u001co<\u001d<tiO7\u0012-;\bA<\u0019)a|";
      j[81] = "T\u0013_)\u0001e_\u001cNf{aL\u0017H,cf]\u0013E";
      j[82] = ":\n\u0011\u001c\u007fY1\u0005\u0000S\u0015Z%\t\u000b\u0018";
      j[83] = "q\u0005lZJ\b\u0004%gU[Ge+l^_\u001d\u0011";
      j[84] = "D}\b\u0007o\u0007Zu\u0012H\"\u001d@\u007f\u000b\u00143\u0017@hP%.\u001cMi\f\u0014$\u001cZT\u001f\u0015)?Ol";
      j[85] = long.class;
      k[85] = "java/lang/Long";
      j[86] = "ga]Z+\u001bc|]K6\u001b s\u0012\\1\u0007z|\u001f\u0001*\u0010dp\u0010[6\\Aw\u0019J&\u0006<\\\u001d[\b\u0013~f";
      j[87] = "~gy\u0004\u000b\u0010zzy\u0015\u0016\u00109u6\u0002\u0011\fcz;_\n\u001b}v4\u0005\u0016WXq=\u0014\u0006\r^g2\u0003\u0004\u001b{v";
      j[88] = "II[<k+MT[-v+\u000e[\u0014:q7TT\u0019gj JX\u0016=vlo_\u001f,f6iI\u0010;d6OO";
      j[89] = "T\u0018=\u007fv)T\u0018*#z&NS*=z3I\"{b.p";
      j[90] = "ZqKO,&LqN\u0015?1[:M\u00133%J}Z\u0004x5R}X\u000f\"xnfX\u0012\"?Yq";
      j[91] = ":]\u001bTVv,]\u001e\u000eEa;\u0016\u001d\bIu*Q\n\u001f\u0002d\u0012";
      j[92] = "0%2O~\u0005E\u00059@oJ$\u000b2Kk\u0010P";
      j[93] = "1~%Bu*/v?\r=*5|'J41uL&S+32z!";
      j[94] = "lm\u000b\u0005Wo\u0019M\u0000\nF xC\u000b\u0001Bz\f";
      j[95] = ">bD'Q\u000e.*H(hR/lI?\u0004`|)\u0018dh\u000e\"m\u00127\u000fI(bMX";
      j[96] = "T\u0006\u000f\tG?Z\u001b\u0002\u0006!:Y\u001b\u001a\u001avm\u0000KBN!?]\u001a\u0013L\u001a6UM\u0013";
      j[97] = "(\rd]\t9~\tj\u0012Z^\u007f\u0005mF[\t(_:\u00187gq\u0019;MP {\u0016d";
      j[98] = "N \u001baW\u0005O0\u00031*\u0001O<\u0011kF3\u0018~K4\u0016dI%\u001da\u0010_@-Ja*";
      j[99] = "jD#\u001ba\u00134\u0001\u007f\u0004\u000bUqCEE3\u0014lA+\u00014\u001cw?/B7RlF\"B{T\fU}FtMuX}\nr-";
      j[100] = "w@6NcB~HaNY\u001cqY:D5.-\u0018`\u001bY\u0019'\u00185X:\u0018s\\&#";
      j[101] = "B\u0015+@)PFV1Z\u0014YP\u0012;Gxk\u0000Qc\u001f\u0014\u0002\u0007V:\u001b%GZPg -\\@U4GjVO\n[";
      j[102] = "\u000b54\u0014\f\u0014Q|'\nl\t@+/\u0016\u0005\n:-vL\u0013\u000eC v\u0000\u0015n";
      j[103] = "\nXn\u0013Z+B\u0000c\u000fc V\u001b?\u0011\u000f\u0012\u0002X`J^E\u0005]g\u0017Xt@\u0000aJc{\u0001_>MR>\\Ycv\f{\u0007X H\u0019=V\u0005_\u0018\u0002y\u000b\u001d!\n]+\u0002g3\u0016\t(F\u00062\u0006\u0011x;\u00074J\u001d#A\\>\r\u0018E";
      j[104] = "9*-E).0n'@s\\ex5L,0W,y\u0013zl\u0000+s\u0014*g1n.\u0012w\\";
      j[105] = "\u001bQ{w\fj\bP`1it\u0011\n\u00180\tlK\u0003\u007fw\u0003c\u0014l!i\u0014*\u001f\u000bfc\u001bupUxtR~\u0017\u0012r{\r\u0011";
      j[106] = "wwjg\u0019\u0017dvq!|\u0017e0u\u0019E\faqf~\u0002\u0006n.\t \u001c\u0011'%ng\u0016\u001exJ";
      j[107] = "EC%RS3\u001fE6V\u0012Y\u0016:cET:C['E\u0011b\u0019";
      j[108] = "V\u001aB\tHh\u001a\u0006\u0016\u000b6k\u0005\u001bN\u0002ZYQX\u0011Y\n\u000eV]\u0016\u0004\r?\u0013\u0000\u0010Y60R_O^\u0007u\u000fY\u0012e\t6Q\u0007P\u000bM1Y\u001c.ZMk\r\u001e\u001e\u0005Ys\rg\u001e\u0017\u0006e\u000fVSTL\u007fhX\u0016\\Vp\u0006\u001c\u0011TM\u000e";
      j[109] = "\b\bmC?QK]*\u001fk4_Xy\u00196c\u000e\u0005+BZV\u0001FfF*L]]w";
      j[110] = "R|{^q]V?aDLT@{kY f\u001095\u0001L@GcgX+VB\u007fl>";
      j[111] = "-+\r\u0000!V't\f\bS\u0007v$\u0018\u0016\u0004P,uLzi\u000bf3\u000eEcTg;";
      j[112] = "\u007fK\u001cU\t%oKJTt/cK\u0015M\u0018\u001d3\u000bD\u0014t5uG\u0015\u0017\u001816]\u000f*\u0014q3X\u000eI\u0015%wKuU\u0019zp\\E\u0012Ks?7\u0015\u0011I%uT\u0014E\r6\u000eWN\u0017\u001b1mV\u001aS\bJn\fHE\u000f)oX\fVt";
      j[113] = " y\u0019\u001f<Hea\u0010E8!vw\u000e ?\u0019 z\fN{\u001e(ar";
      j[114] = "|\u0001Vi3\u0018'\u000b\u0011lU\u0007q\u0016\np95%UU'nb%\u0000\u0006u+\u0004 \u0012Pt-b";
      j[115] = "\u0007H{vsM\u0003\u000balND\u0015Okq\"vF\n2&N\u0018\u0017]gw\u007fSAQqrNB\u0012Bd(>N\u001bHm\u0016";
      j[116] = "C\\'IuV@\u001diKO\u0003K\u00107J#1\u001bSj\u0016~f@\u00002D(\u001e\u001b\\<]O";
      j[117] = "\u0013l=IqpW2n@o\u0017FUkYj,\u00174mW~f\u0012U+N6w\u001a8k\u0019ru*";
      j[118] = "3\u001f@q[Lw\u0005[1=\u0011c\bJmQ#7K\u00157\u0005t0N\u0012k\u0006Eu\u0013\u00146=";
      j[119] = "\u000eb_**>U>Q3M'\u0014c@*1!\u0012\u000e]?2{\u0017aJss&h";
      j[120] = "ot!brKg}3={08x2?zgj#ef.0ow.gz\u000e5k1!{";
      j[121] = "\u0013N8K4FEJ6\u0004g!DF1Pfv\u0013\u001cf\u000f\n\u0018JZg[m_@U8";
      j[122] = "b-5;5p:.$:tI5\"3>D561!(a$[-3$d#esvx{Ib,!:9wk$\"8cI";
      j[123] = "%\u0002Rd\u00186`_T9#bvD\nbOP\"\u0000P8#9!\u0000\u000b>\u0012||\u0006V\u0005\u001agf\u0003\u0005b]mi\\j";
      j[124] = "\b/\br@\u001f\fl\u0012h}\u0016\u001a(\u0018u\u0011$NdG#MsIn@sFB\f3F.}";
      j[125] = "\u0018\u0003\u0013\u001fk\"Y\r\\\\eHD\u0007PBm$vQ\u0015\u001f6y!S\u001d[4-D\u0010H\u001chy!";
      j[126] = "u\u000fKKV\\0RM\u0016m\b&I\u0013M\u0001:r\rI\u0012mSq\r\u0012\u0011\\\u0016,\u000bO*SWsTH\u001b\u0016\nu\ts";
      j[127] = ">\u001fF\b|;8B\u0002N\u000e6*\\;\u0013r\u0007.D\u0007\u0018\u000e3\u007f\u001c\u0005\u0015w>\u007fP\u0003u";
      j[128] = ";K\u001b=S\u007fs\u0013\u0016!jtg\bJ?\u0006F6D\u001bfQ\u0011tH\u0013>\u0000\u007fi\u0013Faj";
      j[129] = "jF}9&|-\u00142\u007f>L=H`f)\u001bb\u00104;Eu3G6c/(oT<`";
      j[130] = "@\u0017}\u0005{g\r\u0014\u007fS\u001enQS \fr\\\u0006\u001e}[\u001ew\u0003Q|V{hY^2k";
      j[131] = "q<~#m=}5t*S(\u007f*o+?\u001a/f1}nMv;07?$,nh\"Sr*oo2=6-gtLlu+6q\"(r#-\u000f";
      j[132] = "l\b\\QsA`\u0001VXMTb\u001eMY!f0S\u0015\u000fMUq\tCY2\tm\u001d\u0015>";
      j[133] = "\u0005pVdST\u00061\u0018fi\n\u0001-Bl>XQ{\u0016=i\u0001P0B:Y\u0002\u0011~@";
      j[134] = "\u0010U\u0019[e\u001a\u0018\\\u000b\u0004laGY\n\u0006m6\u0015\u0002]^>a\u0010V\u0016^m_JJ\t\u0018l";
      j[135] = "\u001e/RB\u007fFB*\u001f!,9\u001d3\u0007\u001axX\u001b=\u0013P}9Nw_^%@Cw\u0013XE";
      j[136] = ":,1sH)\u007ftso\u000b@b1 o\u001c<d7Mr\t?>2\"eE~cM";
      j[137] = "\fXOu\rZ\fS\u000bnk\fm\u0002L9\u0014\u0007\u0014\u000fLu\u0012g";
      j[138] = "|4C/Z\u0013*0M`\tt 0[0\u0003\u0018\u0012l\u0017adM% \u001c?\u0003\n//CP]\u00148fH7\u001a\u001e79'i\u0004\t~2@.\u000e\u0006!]\u001e9\u0000\u000b{:H=\u000eD(]";
      j[139] = "\u001dja\r3%X2#\u0011pLJjp\u000fb\u001b\u0018:'Q2L\u001dja\r3%X2#\u0011p";
      j[140] = "A\u0006$\u0013\u00163\u0004[\"N-l\u001eQx\u001ez;D\u0001$r\u0014b\u0002\u0007s\u0015Sh\rX";
      j[141] = "0\ro\u0015x2vA:\u0013G<j^g\u0010\u0010k4\t?||+yA|Av1bH";
      j[142] = "i\u0013H\u0012d!`\u001bK\u0010>\u001f1\bL\u00101c7\u000e!S %)H\u0011\b$plL!";
      j[143] = "M\u0002}Q45\u0011\u000702`JN\u001e(\t3+H\u0010<C6JN\u00021\ta-\t\b>V\u000e";
      j[144] = "s\n\u001dgmj\"\n\u000b!\u0003>.\u0003\u00163TipSOo\u0003l+\u0001J19=+\u0017\f";
      j[145] = "g\u0013 P(8p_a\rW7i\u0014\u0019\u0000'+\u0000\ro\u0012%lp\u00173\t4W";
      j[146] = "4uFqvcp,_~f\u0019aqKystS\u007fRnz\u00194vK(x~s|Dw\u0017";
      j[147] = "M&m\tF\u0016Iew\u0013{\u001f_!}\u000e\u0017-\fe X{C\u000f$pV\u0016\u0015\n8-\u000f{\u0018\u0002\"oR\u000b\u0002^9~i";
      j[148] = "T8h(?_\u0013jagT\nF)8188\u0017egfeo\u0012;)j8QH'6,9oIe'$o\u001fS9<5T";
      j[149] = "v\u0000U\u0007I\\*\u0005\u0018d\u001a#u\u001c\u0000_NBs\u0012\u0014\u0015K#,\u000bX\u001a\u0015Yw\u0001\u001f\u001fs";
      j[150] = "Jb2RDl\u0006xpC$wWd.KHE\u0000(q\u0015$cP|\"JCuU`),X*\u0007v+@\u0015)\u0005 N";
      j[151] = " Y\u0001o\rs|\\L\f\\\f#ET7\nm%K@}\u000f\f#YM7XkdSBh7";
      j[152] = "GT.iQ~\u0017\u00140x\u0007\u0003\u0010\u0005=v\u0002TCUh-n:C\u001d=-\u0003lF\u0001`t";
      j[153] = "&\u001cUE\u0007\u0002c\u0004\\\u001f\u0003k`\u001eB\u001az\r~\u0003_\u0013_k&\u0003\u0006\u0013V\u0014aC\u0005\u001d\nk&\u001cUE\u0007\u0002c\u0004\\\u001f\u0003k";
      j[154] = "\u0019BC8\u001aRX\r\n\"aG\u0000\u001f_76\u0015PL\u0007`aM\fM@7\b\u0017Y\u0015U";
      j[155] = "E\bqvF\u0017\u0001QhyVm\u0002\u0002eiJ*\u0012k8tZV\u0013\f\u007f~U\t|RbdE\f\u0006\u0016;}J\u001c|";
      j[156] = "%-\u0001%'_)$\u000b,\u0019J+;\u0010-ux{wNw&/#w\u0000.#\u001f 6N,\u0019";
      j[157] = "UP%\u0015DHEPs\u00149BIP,\rUp\u0019\u0010}U9G\u001f\u0011#\u0011ZFKU0jY\u001c\u0019C7\tXH]PL\n\u0002\u001aKW/\u000bV^X,";
      j[158] = "K_{}1W\u0002\u0000$|ig\u001c\u0003)fg0HY{86gK_=o4\n\u001dZ!2m";
      j[159] = "S\u0012\u0005~\u00101\u000f\u0017H\u001dCNP\u000eP&\u0017/V\u0000Dl\u0012N\u0010\u0019\f}\u001a#PNH\u007f*";
      j[160] = "p,0q(Gy$gq\u0012\u0019v5<{~+*tb \u0012\u0010{#1as\u0011k;a\u001c";
      j[161] = "M*>8$\u0013E#,g-h\u001a&-e,?H}z=qhM)1=,V\u00175.{-";
      j[162] = "uF)tI!h\u001d|+#*f\u0006puO\u00187J *\u001cOu\u0000m/E)2@(i#0fJny\u0013w4C!\u0012";
      j[163] = ")}ZwY\u0016%tP~g\u0003'kK\u007f\u000b1u&\u0015 g\u0004zhY#\u0017\u001e&sH\u0018";
      j[164] = "[0\u0002tsI\u001d|WrLL\rr\u000ez ~Y3P'LY\u001ar\u0010}2\u0015\u00000\u0001\u001d";
      j[165] = "\u0019kqmM]\u000e'002T\u0013grP\r\nGwp>I\rOl\u000e";
      j[166] = "![\u0012\u000ehms\u0004\tQe\\}\t\u001e\b~0OY_W)\\r\\^\u0017y%\u007f\\\u0012\u0011\u0019";
      j[167] = "\u0004I`*:\u0015\u0002G/+k|RA,InD\u0004L.'*C\fWPviE]R>2nMF,";
      j[168] = "\u0005\u0010Fi\u0011\bS\u0014H&BoR\u0018OrC8\u0005B\u0018//V\\\u0004\u0019yH\u0011V\u000bF";
      j[169] = "YCaw\\<F\u0019n9a7D\u0011{'6h\u001fF'K\u001df[@\".\u0002<T\u000e";
      j[170] = "M\u001cw\u0010\u0001R\u0005Dz\f8Y\u0011_&\u0012TkL\u001f~J8\r\u000eY\"\u0015BWGJ<u";
      j[171] = "\f\u000fV`9'IRP=\u0002xSX\nmU/\t\bT\u0001;vO\u000e\u0001f||@Q";
      j[172] = "bZ27\r\u0012'\u00074j6M=\rn:a\u001ag]3V\u000fC![e1HI.\u0004";
      j[173] = "^C\u0013[$\t\u0002F^8xv]_F\u0003#\u0017[QRI&v]C_\u0003q\u0011\u001aIP\\\u001e";
      j[174] = "\u0005I9bw\\^C~g\u0011C\b^e{}q\\\u001d:#!&[\u0018=}*\u0017\u001eE; \u0011\u001f\u001d^~,|\u0016^H{y\u0011I[\u001e:c/\\\u001dOg\u001cqMY\\cf*G\u001eY\u0005";
      j[175] = "zS\u001bAOi=\u0001T\u0007WY-]\u0006\u001e@\u000er\u0005SE,`#RP\u001bF=\u007fAZ\u0018";
      j[176] = "\u0002\u0002HrVET\u0006F=\u0005\"U\nAi\u0004u\u0002P\u00165h\u001b[\u0016\u0017b\u000f\\Q\u0019H";
      j[177] = "DPB\u0019T\u0001\u0018U\u000fz\u0016~GL\u0017AS\u001fAB\u0003\u000bV~GP\u000eA\u0001\u0019\u0000Z\u0001\u001en";
      j[178] = "S\u000fS87$\u000f\n\u001e[o[P\u0013\u0006`0:V\u001d\u0012*5[P\u000f\u001f`b<\u0017\u0005\u0010?\r";
      j[179] = "Q^\u0017AZ!\u0017\u0012BGe/\u000b\r\u001fD2xTPD(T~[\u0005BF\u001c&V\u0019";
      j[180] = "3L=Y@;eI!\u0004\u0019Vo\u001c8T\u0018:]M|\u000eEk\nH$ZD7`\u0015xIN4\n\u0013tK\rmz\t(P\u001cV";
      j[181] = "V\u001bTP\u0005\u0000\u0011I\u001b\u0016\u001d0\u0001\u0015I\u000f\ng^M\u001eZf\t\u000f\u001a\u001f\n\fTS\t\u0015\t";
      j[182] = "5o95>K )hhA\u00107-em-\"f`;1qu8->uy\u000f<ob7A\u001adm:u\u007f\u000f\"<g\n";
      j[183] = "\u001c}8\u0002 \u000fXg#BFRLj2\u001e*`\u0018)mEy7\u001f,j\u0018}\u0006ZqlEF";
      j[184] = "z\u007fmM/P>\u007f(\u0015u1*\u0005oRt\n~di\\`@{\u0005/E(Qsho\u0012lSC";
      j[185] = ",7bG)}(tx]\u0014t>0r@xFn}#\u0019\u0014(n5\u007f\u0018y~k)\"A\u0014m!!m\u001e-}i-b'";
      j[186] = "h\u007f\u0010j\u0018F6:Lur\u0013ji\u001fqr\u0001e<\u0016;\u001fA2x\u0014\u000b";
      j[187] = "kpcn>Yk{'uX\u000e\n*`\"'\u0004s'`n!d";
      j[188] = "MG5N2'\u0010\u0006|JL/MD'\u0014 \u001d\u0019\u0000xHL$A\u0004w\t26\u001eV~s";
      j[189] = "6KHcBR3Y\u001ebD4a@IePc6\u001a\u001f:<\reMF\u007fZ\bw\u001bGy";
      j[190] = "}E\u0014\u001a\u001dX!@Yy@'~YAB\u001aFxWU\b\u001f'~EXBH@9OW\u001d'";
      j[191] = "B\u0007<wFf\u0018\u0014:)D\u0005\u001e\u0001-sXi,Uo/\u0004;{U1n\u0004j\u001c\u0012;a[\u0005B\f,(Pb\u0005\u0006#w?<\u001b\u0011j|X{\u0011\u001e5\u0013\u0006e\u0006W>tAo\t\bQ";
      j[192] = "~\u00182\u0012Jep\u0005?\u001d,`s\u0005'\u0001{7*QyQ,ew\u0004.W\u0017l\u007fS.";
      j[193] = "`qn0H\\d2t*uUrv~7\u0019g!2/nuZ'6a0\fW'zgP";
      j[194] = "`]QM}\u001cr\u0002\u0003D\u0007\u0007c@\r\u001ak57\u0004\\G\u0007\\4\u0004\fF6\u0019i\u0002Q}9X6]VL|\u00050\u0000m\u00129^1CS\u0007\u007f\u000fl<\r\u0016;\u001chFV\u001c|\u0019\u000e";
      j[195] = "TG%.\u0004N]\u0003/+^<\b\u0015='\u0001P:Eq}W<T\u0011%8X[\u0002\u0015+w\u000b<";
      j[196] = "]96WMF\u0001<{4\u001e9\r0cZ\u001eSW#zJwS\u000e=i]\u001d\t\u001d$y4";
      j[197] = "\u0002b\u000e\u0014ugTf\u0000[&\u0000Uj\u0007\u000f'W\u00020PVK9[vQ\u0004,~Qy\u000e";
      j[198] = ";V6m\u000e\u001d|\u0004y+\u0016-lX+2\u0001z3\u0001whm\u0014bW}7\u0007I>Dw4";
      j[199] = "!\u001e;UB\u00194Xj\b=J7]n\u000eF'q\u0018>\nCI5\u001f6\u0011=E~_uQM_\"Ddj";
      j[200] = "\u001aXp\u000799Z_mY!BM42K!y\u001eU4E53\u001b4r\\}\"\u0013Y2\u000b9 #";
      j[201] = "\u0016\u0015|z\\HJ\u00101\u0019\u00077\u0015\t)\"[V\u0013\u0007=h^7\u0015\u00150\"\tPR\u001f?}f";
      j[202] = "#\u0014`Vr(u\u0010n\u0019!Ot\u001ciM \u0018#F>\u0015Lvz\u0000?F+1p\u000f`";
      j[203] = "\u00169)\u0004h\u0004\u001e0;[a\u007fA5:Y`(\u0013nm\u00012\u007f\u0016:&\u0001`AL&9Ga";
      j[204] = "A#\u0011\f\u001c.\t{\u001c\u0010%%\u001d`@\u000eI\u0017@'\u001aQ%/N \u001f\u0016\u001b:\bqBiI \u001aq]\bH0\u0002! ";
      j[205] = "\u0013q\"G.JT#m\u00016zD\u007f?\u0018!-\u001b&cAMCJpi\u001d'\u001e\u0016cc\u001e";
      j[206] = "\u001bf\u001bLqM\u001dhTM $IgFF`$[h\u0013O*I\u001b?WM\u001a";
      j[207] = "VR\u0014q6T\nWY\u0012f+UNA)1JS@Uc4+URX)cL\u0012XWv\f";
      j[208] = "wC&_#a\u007fJ4\u0000*\u001a O5\u0002+Mr\u0014bZ}\u001aw@)Z+$-\\6\u001c*";
      j[209] = "!&\"o\fUm8\",|VSbfvG\u00022dhb\r\u0007Se *\u001d\u0004b },@?";
      j[210] = "y\\owxTj]t1\u001dAv\u0006ks\u001d\u0016r\u001c7fzQx\u0013h\t$OoZcncE`\u0005\f";
      j[211] = "H\u0014\f\tmE\f\u000e\u0017I\u000b\u0018\u0018\u0003\u0006\u0015g*L@YN;}\u0019\u001f\f\u001fv\u001c\u0018\u000f\u0014O\u000bC\b\u0013\n\fm\u000f\u0014G\brdCI@\u0019Lq\u0005\u0018\u001df\u001cjAE\u0005\u0018\u000e5\u0013L\u007f";
      j[212] = "G\bGsx=MWF{\nl\u001c\u0007Re];FV\t\t0`\f\u0010D6:?\r\u0018";
      j[213] = "V\u0019$\u001c\u0016<RZ>\u0006+5D\u001e4\u001bG\u0007\u0017[mF+i\u0014\u001b9CF?\u0011\u0007d\u001a+i\u0016\u00122\r\u001a;I\tm\u0000+";
      j[214] = "M1^\u0005\u007fj\u0016;\u0019\u0000\u0019u@&\u0002\u001cuG\u0014e]K%\u0010\u0013`Z\u001a\"!V=\\G\u0019";
      j[215] = "$6*4p%\"knr\u0002(0uU$sGb1/)|)&6'2\u0002";
      j[216] = "(\u001fQ\u0001\u0011].\u0011\u001e\u0000@4i\u0007\u001dbE\f(\u001a\u001f\f\u0001\u000b \u0001a]B\rq\u0004\u000f\u0019E\u0005jz^ZCTo\u0014\u001a]KO\u0011";
      j[217] = "\u00049R\ng-X<\u001fi8R\u0007%\u0007R`3\u0001+\u0013\u0018eR\u00079\u001eR25@3\u0011\r]";
      j[218] = "|\u001cB[[/u_T^\u000eB \tB@\f.\u0012]\u0006\u0019WxE]^]P-\"\u001aTR\u000fB|\u0004C\u001b\u0004%;\u000eLDk{%\u0019\u0005O\f</\u0016Z R:9\u001f\u000eM[y/\u001a[ ";
      j[219] = "Isc{pY\u0001+ngIR\u001502y%`Gqh q7A*j%sW\u001a/)\"u7";
      j[220] = "a\u0003{$}kt@n'\u0017~zT{\"@ &\b/NsnpWx1/rd\u0001";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = j[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = j[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            j[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  j[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(711036967104208L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = j[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  j[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(711036967104208L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        j[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(711036967104208L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 81;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 194;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 107;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 192;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 255;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 120;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 81;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 194;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 107;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ax_C0050",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ax" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static double invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = a(MethodHandles.lookup(), "ÿ", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (double)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BiFunction invokeBinding2(BlockPos var0, BlockPos var1, BlockState var2, BlockPos var3, boolean var4) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType(
                     "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Z)Ljava/util/function/BiFunction;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/ax_C0050",
                     "lambda$raycast$0",
                     "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;ZLnet/minecraft/world/RaycastContext;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/hit/BlockHitResult;"
                  ),
                  SourceSupport.methodType(
                     "(Lnet/minecraft/world/RaycastContext;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/hit/BlockHitResult;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         try {
            return (BiFunction)var6.invokeExact((BlockPos)var0, (BlockPos)var1, (BlockState)var2, (BlockPos)var3, (boolean)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/ax_C0050",
                     "lambda$raycast$1",
                     "(Lnet/minecraft/world/RaycastContext;)Lnet/minecraft/util/hit/BlockHitResult;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/world/RaycastContext;)Lnet/minecraft/util/hit/BlockHitResult;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Supplier invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 8, "it/unimi/dsi/fastutil/objects/Object2IntOpenHashMap", "<init>", "()V"),
                  SourceSupport.methodType("()Lit/unimi/dsi/fastutil/objects/Object2IntOpenHashMap;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
