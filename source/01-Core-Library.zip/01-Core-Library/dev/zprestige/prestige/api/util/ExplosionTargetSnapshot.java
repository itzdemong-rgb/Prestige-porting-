package dev.zprestige.prestige.api.util;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;

public record ExplosionTargetSnapshot(LivingEntity as, double at, double au, double av, boolean aw, BlockPos ax, boolean ay) {
}
