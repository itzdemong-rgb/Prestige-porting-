package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class FeetCollisionProbe extends CollisionProbe {
   private static final long a = 93827299591112L;
   private static final Object[] e = new Object[27];
   private static final String[] f = new String[27];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   @Override
   public void aReturningVoid(Object[] var1) {
      MotionPredictor var2 = (MotionPredictor)var1[0];
      boolean var3 = (Boolean)var1[1];
      long var4 = (Long)var1[2];
      long var6 = var4 ^ 74069208640L;
      long var8 = var4 ^ 77487657413996L;
      int var10 = Event.bReturningInt();
      int var80 = var10;
      if (var80 == 0) {
         boolean var81 = var3;
         if (var81) {
            MinecraftClient var18 = MinecraftAccess.b;
            ClientWorld var10000 = var18.world;
            Vec3d var19 = var2.c;
            Vec3d var20 = var2.c;
            Vec3d var21 = var2.c;
            Vec3d var22 = var2.d;
            double var27 = var21.z + var22.z;
            double var25 = var20.y;
            double var23 = var19.x;
            BlockPos var30 = BlockPos.ofFloored(var23, var25, var27);
            ClientWorld var29 = var10000;
            BlockState var11 = var29.getBlockState(var30);
            Object[] var32 = new Object[]{var11, var8};
            FeetCollisionProbe var31 = this;
            boolean var82 = var31.aReturningBoolean(var32);
            if (!var82) {
               Vec3d var33 = var2.d;
               Vec3d var34 = var2.d;
               Vec3d var35 = var2.d;
               var2.d = new Vec3d(var33.x, var34.y, var35.z * -0.8);
            }

            MinecraftClient var37 = MinecraftAccess.b;
            var10000 = var37.world;
            Vec3d var38 = var2.c;
            Vec3d var39 = var2.c;
            Vec3d var40 = var2.d;
            double var10002 = var39.y + var40.y;
            Vec3d var41 = var2.c;
            double var46 = var41.z;
            double var44 = var10002;
            double var42 = var38.x;
            BlockPos var49 = BlockPos.ofFloored(var42, var44, var46);
            ClientWorld var48 = var10000;
            BlockState var12 = var48.getBlockState(var49);
            Object[] var51 = new Object[]{var12, var8};
            FeetCollisionProbe var50 = this;
            boolean var83 = var50.aReturningBoolean(var51);
            if (!var83) {
               Vec3d var52 = var2.d;
               double var10003 = var52.x * 0.999F;
               Vec3d var53 = var2.d;
               double var10004 = var53.y * -0.6;
               Vec3d var54 = var2.d;
               var2.d = new Vec3d(var10003, var10004, var54.z * 0.999F);
            }

            MinecraftClient var56 = MinecraftAccess.b;
            var10000 = var56.world;
            Vec3d var57 = var2.c;
            Vec3d var58 = var2.d;
            double var10001 = var57.x + var58.x;
            Vec3d var59 = var2.c;
            Vec3d var60 = var2.c;
            double var65 = var60.z;
            double var63 = var59.y;
            double var61 = var10001;
            BlockPos var68 = BlockPos.ofFloored(var61, var63, var65);
            ClientWorld var67 = var10000;
            BlockState var13 = var67.getBlockState(var68);
            int var85 = var10;
            FeetCollisionProbe var84 = this;
            FeetCollisionProbe var79 = var84;
            FeetCollisionProbe var78 = var84;
            if (var85 == 0) {
               Object[] var70 = new Object[]{var13, var8};
               FeetCollisionProbe var69 = var78;
               boolean var86 = var69.aReturningBoolean(var70);
               if (!var86) {
                  Vec3d var72 = var2.d;
                  double var89 = var72.x * -0.8;
                  Vec3d var73 = var2.d;
                  Vec3d var74 = var2.d;
                  var2.d = new Vec3d(var89, var73.y, var74.z);
               }

               var79 = this;
            }

            Object[] var77 = new Object[]{var2, var6};
            FeetCollisionProbe var76 = var79;
            var76.bReturningVoid(var77);
            return;
         }

         Object[] var16 = new Object[]{var2, var6};
         FeetCollisionProbe var15 = this;
         var15.bReturningVoid(var16);
      }
   }

   private void bReturningVoid(Object[] var1) {
      MotionPredictor var4 = (MotionPredictor)var1[0];
      long var2 = (Long)var1[1];
      var2 = 93827299591112L ^ var2;
      var4.c = invokeBinding1(var4.c, var4.d, 6164627085438133081L, var2);
      var4.d = new Vec3d(
         invokeBinding2(var4.d, 6164742145481674535L, var2) / 0.999998F,
         invokeBinding3(var4.d, 6164391030806173486L, var2) - 5.5E-6,
         invokeBinding4(var4.d, 6164808513225387803L, var2) / 0.999998F
      );
   }

   static {
      b();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = f[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = e[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 53;
            yield var15;
         }
         case 1 -> {
            byte var16 = 56;
            yield var16;
         }
         case 2 -> {
            byte var17 = 38;
            yield var17;
         }
         case 3 -> {
            byte var18 = 4;
            yield var18;
         }
         case 4 -> {
            byte var19 = 34;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 35;
            yield var21;
         }
         case 7 -> {
            byte var22 = 55;
            yield var22;
         }
         case 8 -> {
            byte var23 = 21;
            yield var23;
         }
         case 9 -> {
            byte var24 = 44;
            yield var24;
         }
         case 10 -> {
            byte var25 = 14;
            yield var25;
         }
         case 11 -> {
            byte var26 = 40;
            yield var26;
         }
         case 12 -> {
            byte var27 = 8;
            yield var27;
         }
         case 13 -> {
            byte var28 = 1;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 27;
            yield var30;
         }
         case 16 -> {
            byte var31 = 26;
            yield var31;
         }
         case 17 -> {
            byte var32 = 24;
            yield var32;
         }
         case 18 -> {
            byte var33 = 15;
            yield var33;
         }
         case 19 -> {
            byte var34 = 3;
            yield var34;
         }
         case 20 -> {
            byte var35 = 23;
            yield var35;
         }
         case 21 -> {
            byte var36 = 0;
            yield var36;
         }
         case 22 -> {
            byte var37 = 42;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 50;
            yield var39;
         }
         case 25 -> {
            byte var40 = 12;
            yield var40;
         }
         case 26 -> {
            byte var41 = 37;
            yield var41;
         }
         case 27 -> {
            byte var42 = 57;
            yield var42;
         }
         case 28 -> {
            byte var43 = 33;
            yield var43;
         }
         case 29 -> {
            byte var44 = 22;
            yield var44;
         }
         case 30 -> {
            byte var45 = 59;
            yield var45;
         }
         case 31 -> {
            byte var46 = 29;
            yield var46;
         }
         case 32 -> {
            byte var47 = 54;
            yield var47;
         }
         case 33 -> {
            byte var48 = 18;
            yield var48;
         }
         case 34 -> {
            byte var49 = 58;
            yield var49;
         }
         case 35 -> {
            byte var50 = 13;
            yield var50;
         }
         case 36 -> {
            byte var51 = 61;
            yield var51;
         }
         case 37 -> {
            byte var52 = 30;
            yield var52;
         }
         case 38 -> {
            byte var53 = 60;
            yield var53;
         }
         case 39 -> {
            byte var54 = 31;
            yield var54;
         }
         case 40 -> {
            byte var55 = 62;
            yield var55;
         }
         case 41 -> {
            byte var56 = 17;
            yield var56;
         }
         case 42 -> {
            byte var57 = 39;
            yield var57;
         }
         case 43 -> {
            byte var58 = 52;
            yield var58;
         }
         case 44 -> {
            byte var59 = 48;
            yield var59;
         }
         case 45 -> {
            byte var60 = 25;
            yield var60;
         }
         case 46 -> {
            byte var61 = 10;
            yield var61;
         }
         case 47 -> {
            byte var62 = 20;
            yield var62;
         }
         case 48 -> {
            byte var63 = 5;
            yield var63;
         }
         case 49 -> {
            byte var64 = 11;
            yield var64;
         }
         case 50 -> {
            byte var65 = 6;
            yield var65;
         }
         case 51 -> {
            byte var66 = 45;
            yield var66;
         }
         case 52 -> {
            byte var67 = 28;
            yield var67;
         }
         case 53 -> {
            byte var68 = 2;
            yield var68;
         }
         case 54 -> {
            byte var69 = 32;
            yield var69;
         }
         case 55 -> {
            byte var70 = 47;
            yield var70;
         }
         case 56 -> {
            byte var71 = 51;
            yield var71;
         }
         case 57 -> {
            byte var72 = 46;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 41;
            yield var74;
         }
         case 60 -> {
            byte var75 = 16;
            yield var75;
         }
         case 61 -> {
            byte var76 = 9;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 43;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            f[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      e[0] = "~[xa\"8~[o=.7d\u0010o#.\"ca>{|";
      e[1] = double.class;
      f[1] = "java/lang/Double";
      e[2] = "\b\u0003\u000e_\u0012\u0007\u001e\u0003\u000b\u0005\u0001\u0010\tH\b\u0003\r\u0004\u0018\u000f\u001f\u0014F\u0016)";
      e[3] = int.class;
      f[3] = "java/lang/Integer";
      e[4] = "puJwC\u0015fuO-P\u0002q>L+\\\u0016`y[<\u0017\u0007$";
      e[5] = " \u0010-\u0005gT+\u001f<J\u0004Y>\u00123!1[/\u0001/\r&V";
      e[6] = "E{`\\xN0[kSi\u0001QU`Xm[%";
      e[7] = void.class;
      f[7] = "java/lang/Void";
      e[8] = ";\u0013\u001c\u001b\u0013\u000b;\u0013\u000bG\u001f\u0004!X\u000bY\u001f\u0011&)Z\u0006MZ";
      e[9] = "\\1\b\u0006w\u001d\\1\u001fZ{\u0012Fz\u001fD{\u0007A\u000bO\u0019*";
      e[10] = "B\u001ccsbWB\u001ct/nXXWt1nM_&!n7";
      e[11] = "\u000fJFD\u00152\u0019JC\u001e\u0006%\u000e\u0001@\u0018\n1\u001fFW\u000fA 2";
      e[12] = "?\u0007\u0011\u0015d;J'\u001a\u001aut+)\u0011\u0011q._";
      e[13] = boolean.class;
      f[13] = "java/lang/Boolean";
      e[14] = "]VRl_~]VE0SqG\u001dE.Sd@l\u0014t\n'";
      e[15] = "\u0017&\u0019\u007fYO\u001c)\b08A\u0017\"\fj";
      e[16] = "4NH#}vh\\F+\u001d&kLS,Jq4\u0011\b@\")hDS<~1hK";
      e[17] = ")#|QMg{9#4Ctn8*Xq *a|4\u001db#=&JOx|XvO\u0017|y&$UH\u0019";
      e[18] = "\u0013f<r?\u000fA|c\u0017:\u0010Eya@mJ\u0015%\ri?\rCo0u=H";
      e[19] = ",#<aMQ~9c\u0004HNz<aS\u001f\u0014*b\rzMS|*0fO\u0016";
      e[20] = "\u0016\u001fS7\u0014oD\u0005\fR\u0011p@\u0000\u000e\u0005F*\u0010]b,\u0014mF\u0016_0\u0016(";
      e[21] = "_`I\u000f+\u001f\bgL\u0004F\u001fec\u001d\u00157O\u000ei\u000e\u001axu";
      e[22] = "Pk\u001eZ0\u0010\u0005h\u0010]A\u0010j.\nE=\t\u0005pCR|yQe\u001c_1\u0016\u000f,\u000b\u001eA";
      e[23] = "\u0014\u001er\n\u000b!V\u001fn\u0000ox$\u0016g\u0000Ux\u0019\u001au^Q\u0011\u0015M3\u000b^(\\[pHo";
      e[24] = "7j|+J\u0014bir,;\u0017\r$tb\u0001\u00140(f<\u0005}0.# ]\u0002od\u007f.;";
      e[25] = "\u0005B\t\u001ezOYZ\t\u0011\u001eVW_\u000b\u001crd\n\u0018QC\u001e\u000eGOT\u001bnP]Q\u0013{/O]\u001b\u0002\u0002\"N]Ck";
      e[26] = " \u0006Un?8~\u001cK)_-p\u0007Y63\u001f!J\u0007j`Hc\u0010E:-u\u007f\u0012\u0000Q!#a\u0010Kl=!${G:##oF[8fH \u0006Un?8~\u001cK)_";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = e[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            e[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  e[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1105245460615244L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  e[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1105245460615244L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        e[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1105245460615244L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 197;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 224;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 107;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 212;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 235;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 121;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 197;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 224;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 107;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b0",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b0" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Vec3d invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = b(
                  MethodHandles.lookup(),
                  "ë",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Vec3d)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
