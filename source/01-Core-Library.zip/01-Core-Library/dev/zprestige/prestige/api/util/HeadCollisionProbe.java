package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class HeadCollisionProbe extends CollisionProbe {
   private static final long a = 85762098463119L;
   private static final Object[] e = new Object[27];
   private static final String[] f = new String[27];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   @Override
   public void aReturningVoid(Object[] var1) {
      MotionPredictor var2 = (MotionPredictor)var1[0];
      boolean var3 = (Boolean)var1[1];
      long var4 = (Long)var1[2];
      long var6 = var4 ^ 77487657413996L;
      long var8 = var4 ^ 5281500342654L;
      int var10 = Event.bReturningInt();
      int var80 = var10;
      if (var80 == 0) {
         boolean var81 = var3;
         if (var81) {
            MinecraftClient var18 = MinecraftAccess.b;
            ClientWorld var10000 = var18.world;
            Vec3d var19 = var2.c;
            Vec3d var20 = var2.c;
            Vec3d var21 = var2.c;
            Vec3d var22 = var2.d;
            double var27 = var21.z + var22.z;
            double var25 = var20.y;
            double var23 = var19.x;
            BlockPos var30 = BlockPos.ofFloored(var23, var25, var27);
            ClientWorld var29 = var10000;
            BlockState var11 = var29.getBlockState(var30);
            Object[] var32 = new Object[]{var11, var6};
            HeadCollisionProbe var31 = this;
            boolean var82 = var31.aReturningBoolean(var32);
            if (!var82) {
               Vec3d var33 = var2.d;
               Vec3d var34 = var2.d;
               Vec3d var35 = var2.d;
               var2.d = new Vec3d(var33.x, var34.y, var35.z * -0.8);
            }

            MinecraftClient var37 = MinecraftAccess.b;
            var10000 = var37.world;
            Vec3d var38 = var2.c;
            Vec3d var39 = var2.c;
            Vec3d var40 = var2.d;
            double var10002 = var39.y + var40.y;
            Vec3d var41 = var2.c;
            double var46 = var41.z;
            double var44 = var10002;
            double var42 = var38.x;
            BlockPos var49 = BlockPos.ofFloored(var42, var44, var46);
            ClientWorld var48 = var10000;
            BlockState var12 = var48.getBlockState(var49);
            Object[] var51 = new Object[]{var12, var6};
            HeadCollisionProbe var50 = this;
            boolean var83 = var50.aReturningBoolean(var51);
            if (!var83) {
               Vec3d var52 = var2.d;
               double var10003 = var52.x * 0.999F;
               Vec3d var53 = var2.d;
               double var10004 = var53.y * -0.6;
               Vec3d var54 = var2.d;
               var2.d = new Vec3d(var10003, var10004, var54.z * 0.999F);
            }

            MinecraftClient var56 = MinecraftAccess.b;
            var10000 = var56.world;
            Vec3d var57 = var2.c;
            Vec3d var58 = var2.d;
            double var10001 = var57.x + var58.x;
            Vec3d var59 = var2.c;
            Vec3d var60 = var2.c;
            double var65 = var60.z;
            double var63 = var59.y;
            double var61 = var10001;
            BlockPos var68 = BlockPos.ofFloored(var61, var63, var65);
            ClientWorld var67 = var10000;
            BlockState var13 = var67.getBlockState(var68);
            int var85 = var10;
            HeadCollisionProbe var84 = this;
            HeadCollisionProbe var79 = var84;
            HeadCollisionProbe var78 = var84;
            if (var85 == 0) {
               Object[] var70 = new Object[]{var13, var6};
               HeadCollisionProbe var69 = var78;
               boolean var86 = var69.aReturningBoolean(var70);
               if (!var86) {
                  Vec3d var72 = var2.d;
                  double var89 = var72.x * -0.8;
                  Vec3d var73 = var2.d;
                  Vec3d var74 = var2.d;
                  var2.d = new Vec3d(var89, var73.y, var74.z);
               }

               var79 = this;
            }

            Object[] var77 = new Object[]{var2, var8};
            HeadCollisionProbe var76 = var79;
            var76.bReturningVoid(var77);
            return;
         }

         Object[] var16 = new Object[]{var2, var8};
         HeadCollisionProbe var15 = this;
         var15.bReturningVoid(var16);
      }
   }

   private void bReturningVoid(Object[] var1) {
      MotionPredictor var2 = (MotionPredictor)var1[0];
      long var3 = (Long)var1[1];
      var3 = 85762098463119L ^ var3;
      var2.c = invokeBinding1(var2.c, var2.d, -8336427499468113666L, var3);
      var2.d = new Vec3d(
         invokeBinding2(var2.d, -8336176694417504410L, var3) / 0.999998F,
         invokeBinding3(var2.d, -8336658954022168880L, var3) - 1.5E-6,
         invokeBinding4(var2.d, -8336253799483312998L, var3) / 0.999998F
      );
   }

   static {
      b();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = f[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = e[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 20;
            yield var15;
         }
         case 1 -> {
            byte var16 = 28;
            yield var16;
         }
         case 2 -> {
            byte var17 = 6;
            yield var17;
         }
         case 3 -> {
            byte var18 = 30;
            yield var18;
         }
         case 4 -> {
            byte var19 = 33;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 5;
            yield var21;
         }
         case 7 -> {
            byte var22 = 26;
            yield var22;
         }
         case 8 -> {
            byte var23 = 1;
            yield var23;
         }
         case 9 -> {
            byte var24 = 18;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 9;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 46;
            yield var28;
         }
         case 14 -> {
            byte var29 = 10;
            yield var29;
         }
         case 15 -> {
            byte var30 = 27;
            yield var30;
         }
         case 16 -> {
            byte var31 = 39;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 3;
            yield var33;
         }
         case 19 -> {
            byte var34 = 52;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 58;
            yield var36;
         }
         case 22 -> {
            byte var37 = 32;
            yield var37;
         }
         case 23 -> {
            byte var38 = 49;
            yield var38;
         }
         case 24 -> {
            byte var39 = 8;
            yield var39;
         }
         case 25 -> {
            byte var40 = 38;
            yield var40;
         }
         case 26 -> {
            byte var41 = 54;
            yield var41;
         }
         case 27 -> {
            byte var42 = 25;
            yield var42;
         }
         case 28 -> {
            byte var43 = 62;
            yield var43;
         }
         case 29 -> {
            byte var44 = 16;
            yield var44;
         }
         case 30 -> {
            byte var45 = 50;
            yield var45;
         }
         case 31 -> {
            byte var46 = 56;
            yield var46;
         }
         case 32 -> {
            byte var47 = 60;
            yield var47;
         }
         case 33 -> {
            byte var48 = 23;
            yield var48;
         }
         case 34 -> {
            byte var49 = 2;
            yield var49;
         }
         case 35 -> {
            byte var50 = 4;
            yield var50;
         }
         case 36 -> {
            byte var51 = 0;
            yield var51;
         }
         case 37 -> {
            byte var52 = 14;
            yield var52;
         }
         case 38 -> {
            byte var53 = 41;
            yield var53;
         }
         case 39 -> {
            byte var54 = 48;
            yield var54;
         }
         case 40 -> {
            byte var55 = 17;
            yield var55;
         }
         case 41 -> {
            byte var56 = 59;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 45;
            yield var58;
         }
         case 44 -> {
            byte var59 = 11;
            yield var59;
         }
         case 45 -> {
            byte var60 = 24;
            yield var60;
         }
         case 46 -> {
            byte var61 = 61;
            yield var61;
         }
         case 47 -> {
            byte var62 = 21;
            yield var62;
         }
         case 48 -> {
            byte var63 = 7;
            yield var63;
         }
         case 49 -> {
            byte var64 = 31;
            yield var64;
         }
         case 50 -> {
            byte var65 = 19;
            yield var65;
         }
         case 51 -> {
            byte var66 = 35;
            yield var66;
         }
         case 52 -> {
            byte var67 = 40;
            yield var67;
         }
         case 53 -> {
            byte var68 = 53;
            yield var68;
         }
         case 54 -> {
            byte var69 = 15;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 34;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 37;
            yield var74;
         }
         case 60 -> {
            byte var75 = 57;
            yield var75;
         }
         case 61 -> {
            byte var76 = 42;
            yield var76;
         }
         case 62 -> {
            byte var77 = 12;
            yield var77;
         }
         default -> 51;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            f[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      e[0] = "R\u0007wqX;R\u0007`-T4HL`3T!O=1k\u0006";
      e[1] = double.class;
      f[1] = "java/lang/Double";
      e[2] = "D\fJ\u0017\u001e}R\fOM\rjEGLK\u0001~T\u0000[\\Jle";
      e[3] = int.class;
      f[3] = "java/lang/Integer";
      e[4] = "VNjZ&\n@No\u00005\u001dW\u0005l\u00069\tFB{\u0011r\u0018h";
      e[5] = "?\u0014\u001a\"G\u0001J4\u0011-VN+:\u001a&R\u0014_";
      e[6] = void.class;
      f[6] = "java/lang/Void";
      e[7] = "wyt\u000fP\u0018|ve@3\u0015i{j+\u0006\u0017xhv\u0007\u0011\u001a";
      e[8] = "\u001e\fBA 1\u001e\fU\u001d,>\u0004GU\u0003,+\u00036\u0004\\~`";
      e[9] = "{$ZH\u0014v{$M\u0014\u0018yaoM\n\u0018lf\u001e\u001dWI";
      e[10] = "\u0019X\r=nw\u0019X\u001aabx\u0003\u0013\u001a\u007fbm\u0004bO ;";
      e[11] = "\u00156\u0011\u0017y\u001e\u00036\u0014Mj\t\u0014}\u0017Kf\u001d\u0005:\u0000\\-\f(";
      e[12] = ":\u0004\u0006wsmO$\rxb\".*\u0006sfxZ";
      e[13] = boolean.class;
      f[13] = "java/lang/Boolean";
      e[14] = "&6O=h\u000f&6Xad\u0000<}X\u007fd\u0015;\f\t%=V";
      e[15] = "J\rxv}]A\u0002i9\u001cSJ\tmc";
      e[16] = "bH=:VD=Co\u0006\u000eJ!D3j<\u001ee\u001de\u0006TK4\u0018ie\u000b@f$kj\u0002\u001b`G4aP'";
      e[17] = ">>NJr\\d>\u0000\u0015JIa3\u001bH\u001d\u001e>n@$u\u0018>\"\u0001F,[p<";
      e[18] = ":8\u0007,Q/e3U\u0010\u0002-h0\u0002GUw8lnl\b'g,\u0001o\u0005'";
      e[19] = "\u0003RH\u0003Yh\\Y\u001a?\njQZMh]0\u0001\u0004!C\u0000`^FN@\r`";
      e[20] = "\u0016hE\u0007\u001ezIc\u0017;MxD`@l\u001a\"\u0014=,GGrK|CDJr";
      e[21] = "G\u0007'L\u0017\f\u0000\u0004,Br\u001c}\u00047I\u0014L\u0005P:[\fv";
      e[22] = "mC\f\u000f/m$\u0015G\u000eM7VJ\u0017\u0014!$k\bMA|]j\u0006IHr-<\u0006\u0019\fM";
      e[23] = "IDYk\u000fR\u0018[@\u007fq\u0006v\u0012Dk\u001d\u0016KP\u001e>@oGA\u0014~\n\u001eGO\u001b1q";
      e[24] = "\ra}MQ\u0014D76L3M6dyM]\u001c[!<I\b$\n'y\\\u000bIOb}\t3";
      e[25] = "_DdHA\u0007\u0006\u0007*V?\u0000\r\u0007:SS2P@`\f?X\u0010\u001ed_B\u001a\n\u0015'4\u000e\u0014ZJcJMU\u0019\u0010Z";
      e[26] = "+6*0\fYi,!sgA{:/i\u000bs*wq5X$j\"$l\u001fKi/$\u000e\u001b@}$7a\u0018M}F3j\fFn)0g\f$+6*0\fYi,!sg";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = e[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            e[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  e[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1062096920754512L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  e[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1062096920754512L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        e[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1062096920754512L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 225;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 248;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 75;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 85;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 164;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 86;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 225;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 248;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 75;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bZ_C0107",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bZ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Vec3d invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = b(
                  MethodHandles.lookup(),
                  "¤",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Vec3d)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
