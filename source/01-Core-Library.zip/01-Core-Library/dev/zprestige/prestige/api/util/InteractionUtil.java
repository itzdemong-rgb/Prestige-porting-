package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class InteractionUtil implements MinecraftAccess {
   private static final double a = 4.25;
   private static final double c = 8.0;
   private static final long d = 66168623973003L;
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g = new HashMap(13);
   private static final Object[] h = new Object[55];
   private static final String[] i = new String[55];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public static Vec3d aReturningVec3d(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      long var2 = (Long)var0[1];
      var2 = 66168623973003L ^ var2;
      long var4 = var2 ^ 45853938605420L;
      long var6 = var2 ^ 130867502183143L;
      int var10000 = Event.bReturningInt();
      short var10001 = 16938;
      long var10002 = 4195211588775249312L ^ var2;
      Vec3d[] var239 = new Vec3d[]{
         new Vec3d(0.5, 1.0, 0.5),
         new Vec3d(0.5, 0.5, 0.0),
         new Vec3d(0.0, 0.5, 0.5),
         new Vec3d(1.0, 0.5, 0.5),
         new Vec3d(0.5, 0.5, 1.0),
         new Vec3d(1.0, 0.0, 1.0),
         null,
         null,
         null,
         null,
         null,
         null,
         null
      };
      short var10003 = 22448;
      long var10004 = 7726873333930135612L ^ var2;
      var239[6] = new Vec3d(0.0, 0.0, 1.0);
      var10003 = 2990;
      var10004 = 6942376584329317408L ^ var2;
      var239[7] = new Vec3d(1.0, 0.0, 0.0);
      var10003 = 22202;
      var10004 = 3529171611888783671L ^ var2;
      var239[8] = new Vec3d(0.0, 0.0, 0.0);
      var10003 = 20695;
      var10004 = 4711212623584270174L ^ var2;
      var239[9] = new Vec3d(1.0, 1.0, 1.0);
      var10003 = 18286;
      var10004 = 3927090666396123366L ^ var2;
      var239[10] = new Vec3d(0.0, 1.0, 1.0);
      var10003 = 6659;
      var10004 = 7099096731914755464L ^ var2;
      var239[11] = new Vec3d(1.0, 1.0, 0.0);
      var10003 = 29793;
      var10004 = 7342954757381174254L ^ var2;
      var239[12] = new Vec3d(0.0, 1.0, 0.0);
      Vec3d[] var9 = var239;
      Vec3d var10 = null;
      int var8 = var10000;

      while (true) {
         int var170 = var9.length;
         int var169 = var11;
         label155:
         if (var169 < var170) {
            Vec3d var12 = var9[var11];
            int var171 = var8;
            if (var171 != 0) {
               break;
            }

            byte var173 = 4;
            int var172 = var11;
            if (var172 > var173) {
               int var174 = var8;
               if (var174 == 0) {
                  break label155;
               }
            }

            label148: {
               label165: {
                  BlockPos var20 = var1;
                  double var244 = var20.getX();
                  Vec3d var21 = var12;
                  double var245 = var244 + var21.x;
                  BlockPos var22 = var1;
                  double var254 = var22.getY();
                  Vec3d var23 = var12;
                  double var255 = var254 + var23.y;
                  BlockPos var24 = var1;
                  double var270 = var24.getZ();
                  Vec3d var25 = var12;
                  Vec3d var13 = new Vec3d(var245, var255, var270 + var25.z);
                  MinecraftClient var26 = b;
                  ClientPlayerEntity var27 = var26.player;
                  Vec3d var229 = var27.getEyePos();
                  int var176 = var8;
                  Vec3d var175 = var229;
                  Vec3d var151 = var175;
                  Vec3d var150 = var175;
                  if (var176 == 0) {
                     Vec3d var29 = var13;
                     Vec3d var28 = var150;
                     double var30 = var28.squaredDistanceTo(var29);
                     double var274;
                     int var177 = (var274 = Math.sqrt(var30) - 4.25) == 0.0 ? 0 : (var274 < 0.0 ? -1 : 1);
                     if (var177 > 0) {
                        int var178 = var8;
                        if (var178 == 0) {
                           break label165;
                        }
                     }

                     Vec3d var179 = var13;
                     var151 = var179;
                  }

                  Object[] var35 = new Object[]{var151, var6};
                  HitResult var14 = aReturningHitResult(var35);
                  int var180 = var8;
                  if (var180 != 0) {
                     break label148;
                  }

                  HitResult var181 = var14;
                  if (var181 != null) {
                     HitResult var37 = var14;
                     Vec3d var230 = var37.getPos();
                     Vec3d var39 = var13;
                     Vec3d var38 = var230;
                     double var275;
                     int var182 = (var275 = var38.distanceTo(var39) - 0.1F) == 0.0 ? 0 : (var275 < 0.0 ? -1 : 1);
                     label139:
                     if (var182 < 0) {
                        MinecraftClient var41 = b;
                        ClientPlayerEntity var231 = var41.player;
                        MinecraftClient var42 = b;
                        float var44 = 1.0F;
                        ClientPlayerEntity var43 = var42.player;
                        Vec3d var240 = var43.getCameraPosVec(var44);
                        MinecraftClient var45 = b;
                        ClientPlayerEntity var46 = var45.player;
                        Box var256 = var46.getBoundingBox();
                        Object[] var47 = new Object[]{var4};
                        Vec3d var49 = RaycastUtil.bReturningVec3d(var47);
                        Vec3d var48 = var13;
                        Vec3d var51 = var48.subtract(var49);
                        Box var50 = var256;
                        Box var257 = var50.stretch(var51);
                        double var57 = 1.0;
                        double var55 = 1.0;
                        double var53 = 1.0;
                        Box var52 = var257;
                        Box var258 = var52.expand(var53, var55, var57);
                        Predicate var271 = invokeBinding1();
                        MinecraftClient var59 = b;
                        float var61 = 1.0F;
                        ClientPlayerEntity var60 = var59.player;
                        Vec3d var63 = var60.getCameraPosVec(var61);
                        Vec3d var62 = var13;
                        double var69 = var62.distanceTo(var63);
                        Predicate var68 = var271;
                        Box var67 = var258;
                        Vec3d var66 = var13;
                        Vec3d var65 = var240;
                        ClientPlayerEntity var64 = var231;
                        EntityHitResult var15 = ProjectileUtil.raycast((Entity)var64, var65, var66, var67, var68, var69);
                        EntityHitResult var183 = var15;
                        if (var183 != null) {
                           int var184 = var8;
                           if (var184 == 0) {
                              break label139;
                           }
                        }

                        int var156;
                        label133: {
                           label167: {
                              int var186 = var8;
                              Vec3d var185 = var10;
                              Vec3d var154 = var185;
                              Vec3d var152 = var185;
                              if (var186 == 0) {
                                 Vec3d var187 = var152;
                                 Vec3d var153 = var187;
                                 Vec3d var188 = var153;
                                 if (var188 == null) {
                                    break label167;
                                 }

                                 MinecraftClient var74 = b;
                                 ClientPlayerEntity var75 = var74.player;
                                 Vec3d var189 = var75.getEyePos();
                                 var154 = var189;
                              }

                              Vec3d var78 = var13;
                              Vec3d var77 = var154;
                              double var232 = var77.distanceTo(var78);
                              MinecraftClient var79 = b;
                              ClientPlayerEntity var80 = var79.player;
                              Vec3d var241 = var80.getEyePos();
                              Vec3d var82 = var10;
                              Vec3d var81 = var241;
                              double var276;
                              var10000 = (var276 = var232 - var81.distanceTo(var82)) == 0.0 ? 0 : (var276 < 0.0 ? -1 : 1);
                              int var191 = var8;
                              int var190 = var10000;
                              var156 = var190;
                              int var155 = var190;
                              if (var191 != 0) {
                                 break label133;
                              }

                              int var192 = var155;
                              if (var192 >= 0) {
                                 break label139;
                              }
                           }

                           var156 = var11;
                        }

                        int var193 = var156;
                        if (var193 == 0) {
                           return var13;
                        }

                        var10 = var13;
                     }
                  }
               }

               var11++;
            }

            int var194 = var8;
            if (var194 == 0) {
               continue;
            }
         }

         int var196 = var8;
         Vec3d var195 = var10;
         Vec3d var158 = var195;
         Vec3d var157 = var195;
         if (var196 != 0) {
            return var158;
         }

         Vec3d var197 = var157;
         if (var197 != null) {
            var158 = var10;
            return var158;
         }
         break;
      }

      Vec3d[] var224 = var9;
      int var225 = var224.length;
      Vec3d var168;
      while (true) {
         int var199 = var225;
         int var198 = var226;
         if (var198 < var199) {
            Vec3d var227 = var224[var226];
            BlockPos var86 = var1;
            double var246 = var86.getX();
            Vec3d var87 = var227;
            double var247 = var246 + var87.x;
            BlockPos var88 = var1;
            double var259 = var88.getY();
            Vec3d var89 = var227;
            double var260 = var259 + var89.y;
            BlockPos var90 = var1;
            double var272 = var90.getZ();
            Vec3d var91 = var227;
            Vec3d var228 = new Vec3d(var247, var260, var272 + var91.z);
            MinecraftClient var92 = b;
            ClientPlayerEntity var93 = var92.player;
            Vec3d var234 = var93.getEyePos();
            int var201 = var8;
            Vec3d var200 = var234;
            var168 = var200;
            Vec3d var159 = var200;
            if (var201 != 0) {
               break;
            }

            label105: {
               label169: {
                  int var203 = var8;
                  Vec3d var202 = var159;
                  Vec3d var162 = var202;
                  Vec3d var160 = var202;
                  if (var203 == 0) {
                     Vec3d var204 = var160;
                     Vec3d var161 = var204;
                     Vec3d var96 = var228;
                     Vec3d var95 = var161;
                     double var97 = var95.squaredDistanceTo(var96);
                     double var277;
                     int var205 = (var277 = Math.sqrt(var97) - 4.25) == 0.0 ? 0 : (var277 < 0.0 ? -1 : 1);
                     if (var205 > 0) {
                        int var206 = var8;
                        if (var206 == 0) {
                           break label169;
                        }
                     }

                     Vec3d var207 = var228;
                     var162 = var207;
                  }

                  Object[] var102 = new Object[]{var162, var6};
                  HitResult var16 = aReturningHitResult(var102);
                  int var208 = var8;
                  if (var208 != 0) {
                     break label105;
                  }

                  HitResult var209 = var16;
                  if (var209 != null) {
                     HitResult var104 = var16;
                     Vec3d var235 = var104.getPos();
                     Vec3d var106 = var228;
                     Vec3d var105 = var235;
                     double var278;
                     int var210 = (var278 = var105.distanceTo(var106) - 0.1F) == 0.0 ? 0 : (var278 < 0.0 ? -1 : 1);
                     label96:
                     if (var210 < 0) {
                        MinecraftClient var108 = b;
                        ClientPlayerEntity var236 = var108.player;
                        MinecraftClient var109 = b;
                        float var111 = 1.0F;
                        ClientPlayerEntity var110 = var109.player;
                        Vec3d var242 = var110.getCameraPosVec(var111);
                        MinecraftClient var112 = b;
                        ClientPlayerEntity var113 = var112.player;
                        Box var261 = var113.getBoundingBox();
                        Object[] var114 = new Object[]{var4};
                        Vec3d var116 = RaycastUtil.bReturningVec3d(var114);
                        Vec3d var115 = var228;
                        Vec3d var118 = var115.subtract(var116);
                        Box var117 = var261;
                        Box var262 = var117.stretch(var118);
                        double var124 = 1.0;
                        double var122 = 1.0;
                        double var120 = 1.0;
                        Box var119 = var262;
                        Box var263 = var119.expand(var120, var122, var124);
                        Predicate var273 = invokeBinding2();
                        MinecraftClient var126 = b;
                        float var128 = 1.0F;
                        ClientPlayerEntity var127 = var126.player;
                        Vec3d var130 = var127.getCameraPosVec(var128);
                        Vec3d var129 = var228;
                        double var136 = var129.distanceTo(var130);
                        Predicate var135 = var273;
                        Box var134 = var263;
                        Vec3d var133 = var228;
                        Vec3d var132 = var242;
                        ClientPlayerEntity var131 = var236;
                        EntityHitResult var17 = ProjectileUtil.raycast((Entity)var131, var132, var133, var134, var135, var136);
                        EntityHitResult var211 = var17;
                        if (var211 != null) {
                           int var212 = var8;
                           if (var212 == 0) {
                              break label96;
                           }
                        }

                        Vec3d var167;
                        int var214 = var8;
                        Vec3d var213 = var10;
                        var167 = var213;
                        Vec3d var163 = var213;
                        label90:
                        if (var214 == 0) {
                           Vec3d var215 = var163;
                           Vec3d var164 = var215;
                           Vec3d var216 = var164;
                           if (var216 != null) {
                              MinecraftClient var141 = b;
                              ClientPlayerEntity var142 = var141.player;
                              Vec3d var237 = var142.getEyePos();
                              int var218 = var8;
                              Vec3d var217 = var237;
                              var167 = var217;
                              Vec3d var165 = var217;
                              if (var218 != 0) {
                                 break label90;
                              }

                              Vec3d var219 = var165;
                              Vec3d var166 = var219;
                              Vec3d var145 = var228;
                              Vec3d var144 = var166;
                              double var238 = var144.distanceTo(var145);
                              MinecraftClient var146 = b;
                              ClientPlayerEntity var147 = var146.player;
                              Vec3d var243 = var147.getEyePos();
                              Vec3d var149 = var10;
                              Vec3d var148 = var243;
                              double var279;
                              int var220 = (var279 = var238 - var148.distanceTo(var149)) == 0.0 ? 0 : (var279 < 0.0 ? -1 : 1);
                              if (var220 >= 0) {
                                 break label96;
                              }
                           }

                           Vec3d var221 = var228;
                           var167 = var221;
                        }

                        var10 = var167;
                     }
                  }
               }

               var226++;
            }

            int var222 = var8;
            if (var222 == 0) {
               continue;
            }
         }

         var168 = var10;
         break;
      }

      return var168;
   }

   public static Vec3d bReturningVec3d(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      long var1 = (Long)var0[1];
      var1 = 66168623973003L ^ var1;
      long var4 = var1 ^ 109226148512925L;
      long var6 = var1 ^ 68062154484502L;
      Vec3d[] var9 = new Vec3d[]{
         new Vec3d(0.5, 1.0, 0.5), new Vec3d(0.1, 1.0, 0.1), new Vec3d(0.9, 1.0, 0.1), new Vec3d(0.1, 1.0, 0.9), new Vec3d(0.9, 1.0, 0.9)
      };
      int var10000 = Event.bReturningInt();
      Vec3d var10 = null;
      int var8 = var10000;

      Vec3d var87;
      while (true) {
         int var89 = var9.length;
         int var88 = var11;
         if (var88 < var89) {
            Vec3d var12 = var9[var11];
            BlockPos var16 = var3;
            double var10002 = var16.getX();
            Vec3d var17 = var12;
            var10002 += var17.x;
            BlockPos var18 = var3;
            double var10003 = var18.getY();
            Vec3d var19 = var12;
            var10003 += var19.y;
            BlockPos var20 = var3;
            double var10004 = var20.getZ();
            Vec3d var21 = var12;
            Vec3d var13 = new Vec3d(var10002, var10003, var10004 + var21.z);
            MinecraftClient var22 = b;
            ClientPlayerEntity var23 = var22.player;
            Vec3d var114 = var23.getEyePos();
            int var91 = var8;
            Vec3d var90 = var114;
            var87 = var90;
            Vec3d var79 = var90;
            if (var91 != 0) {
               break;
            }

            label67: {
               label77: {
                  int var93 = var8;
                  Vec3d var92 = var79;
                  Vec3d var82 = var92;
                  Vec3d var80 = var92;
                  if (var93 == 0) {
                     Vec3d var94 = var80;
                     Vec3d var81 = var94;
                     Vec3d var26 = var13;
                     Vec3d var25 = var81;
                     double var126;
                     int var95 = (var126 = var25.distanceTo(var26) - 4.25) == 0.0 ? 0 : (var126 < 0.0 ? -1 : 1);
                     if (var95 > 0) {
                        int var96 = var8;
                        if (var96 == 0) {
                           break label77;
                        }
                     }

                     Vec3d var97 = var13;
                     var82 = var97;
                  }

                  Object[] var30 = new Object[]{var82, var6};
                  HitResult var14 = aReturningHitResult(var30);
                  int var98 = var8;
                  if (var98 != 0) {
                     break label67;
                  }

                  HitResult var99 = var14;
                  if (var99 != null) {
                     HitResult var32 = var14;
                     Vec3d var115 = var32.getPos();
                     Vec3d var34 = var13;
                     Vec3d var33 = var115;
                     double var127;
                     int var100 = (var127 = var33.distanceTo(var34) - 0.1F) == 0.0 ? 0 : (var127 < 0.0 ? -1 : 1);
                     label58:
                     if (var100 < 0) {
                        MinecraftClient var36 = b;
                        ClientPlayerEntity var116 = var36.player;
                        MinecraftClient var37 = b;
                        float var39 = 1.0F;
                        ClientPlayerEntity var38 = var37.player;
                        Vec3d var10001 = var38.getCameraPosVec(var39);
                        MinecraftClient var40 = b;
                        ClientPlayerEntity var41 = var40.player;
                        Box var122 = var41.getBoundingBox();
                        Object[] var42 = new Object[]{var4};
                        Vec3d var44 = RaycastUtil.bReturningVec3d(var42);
                        Vec3d var43 = var13;
                        Vec3d var46 = var43.subtract(var44);
                        Box var45 = var122;
                        Box var123 = var45.stretch(var46);
                        double var52 = 1.0;
                        double var50 = 1.0;
                        double var48 = 1.0;
                        Box var47 = var123;
                        Box var124 = var47.expand(var48, var50, var52);
                        Predicate var125 = invokeBinding3();
                        MinecraftClient var54 = b;
                        float var56 = 1.0F;
                        ClientPlayerEntity var55 = var54.player;
                        Vec3d var58 = var55.getCameraPosVec(var56);
                        Vec3d var57 = var13;
                        double var64 = var57.distanceTo(var58);
                        Predicate var63 = var125;
                        Box var62 = var124;
                        Vec3d var61 = var13;
                        Vec3d var60 = var10001;
                        ClientPlayerEntity var59 = var116;
                        EntityHitResult var15 = ProjectileUtil.raycast((Entity)var59, var60, var61, var62, var63, var64);
                        EntityHitResult var101 = var15;
                        if (var101 != null) {
                           int var102 = var8;
                           if (var102 == 0) {
                              break label58;
                           }
                        }

                        int var103 = var11;
                        if (var103 == 0) {
                           return var13;
                        }

                        Vec3d var86;
                        int var105 = var8;
                        Vec3d var104 = var10;
                        var86 = var104;
                        Vec3d var83 = var104;
                        label51:
                        if (var105 == 0) {
                           Vec3d var106 = var83;
                           if (var106 != null) {
                              MinecraftClient var70 = b;
                              ClientPlayerEntity var71 = var70.player;
                              Vec3d var117 = var71.getEyePos();
                              int var108 = var8;
                              Vec3d var107 = var117;
                              var86 = var107;
                              Vec3d var84 = var107;
                              if (var108 != 0) {
                                 break label51;
                              }

                              Vec3d var109 = var84;
                              Vec3d var85 = var109;
                              Vec3d var74 = var13;
                              Vec3d var73 = var85;
                              double var118 = var73.distanceTo(var74);
                              MinecraftClient var75 = b;
                              ClientPlayerEntity var76 = var75.player;
                              var10001 = var76.getEyePos();
                              Vec3d var78 = var10;
                              Vec3d var77 = var10001;
                              double var128;
                              int var110 = (var128 = var118 - var77.distanceTo(var78)) == 0.0 ? 0 : (var128 < 0.0 ? -1 : 1);
                              if (var110 >= 0) {
                                 break label58;
                              }
                           }

                           Vec3d var111 = var13;
                           var86 = var111;
                        }

                        var10 = var86;
                     }
                  }
               }

               var11++;
            }

            int var112 = var8;
            if (var112 == 0) {
               continue;
            }
         }

         var87 = var10;
         break;
      }

      return var87;
   }

   private static HitResult aReturningHitResult(Object[] var0) {
      Vec3d var1 = (Vec3d)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 66168623973003L ^ var2;
      MinecraftClient var4 = b;
      ClientWorld var10 = var4.world;
      MinecraftClient var5 = b;
      ClientPlayerEntity var6 = var5.player;
      Vec3d var10003 = var6.getEyePos();
      MinecraftClient var7 = b;
      RaycastContext var9 = new RaycastContext(var10003, var1, ShapeType.COLLIDER, FluidHandling.NONE, var7.player);
      ClientWorld var8 = var10;
      return var8.raycast(var9);
   }

   private static boolean lambda$interactTopFace$2(Entity var0) {
      int var3 = Event.bReturningInt();
      Entity var4 = var0;
      byte var10000 = ((byte)((var4.isSpectator()) ? 1 : 0));
      int var13 = var3;
      byte var12 = var10000;
      byte var8 = var12;
      byte var7 = var12;
      if (var13 == 0) {
         byte var14 = var7;
         if (var14 != 0) {
            return false;
         }

         Entity var6 = var0;
         byte var15 = ((byte)((var6.canHit()) ? 1 : 0));
         var8 = var15;
      }

      int var17 = var3;
      byte var16 = var8;
      byte var10 = var16;
      byte var9 = var16;
      if (var17 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var10);
      } else {
         byte var18 = var9;
         if (var18 != 0) {
            var10 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var10);
         } else {
            return false;
         }
      }
   }

   private static boolean lambda$interact$1(Entity var0) {
      int var3 = Event.bReturningInt();
      Entity var4 = var0;
      byte var10000 = ((byte)((var4.isSpectator()) ? 1 : 0));
      int var13 = var3;
      byte var12 = var10000;
      byte var8 = var12;
      byte var7 = var12;
      if (var13 == 0) {
         byte var14 = var7;
         if (var14 != 0) {
            return false;
         }

         Entity var6 = var0;
         byte var15 = ((byte)((var6.canHit()) ? 1 : 0));
         var8 = var15;
      }

      int var17 = var3;
      byte var16 = var8;
      byte var10 = var16;
      byte var9 = var16;
      if (var17 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var10);
      } else {
         byte var18 = var9;
         if (var18 != 0) {
            var10 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var10);
         } else {
            return false;
         }
      }
   }

   private static boolean lambda$interact$0(Entity var0) {
      int var3 = Event.bReturningInt();
      Entity var4 = var0;
      byte var10000 = ((byte)((var4.isSpectator()) ? 1 : 0));
      int var13 = var3;
      byte var12 = var10000;
      byte var8 = var12;
      byte var7 = var12;
      if (var13 == 0) {
         byte var14 = var7;
         if (var14 != 0) {
            return false;
         }

         Entity var6 = var0;
         byte var15 = ((byte)((var6.canHit()) ? 1 : 0));
         var8 = var15;
      }

      int var17 = var3;
      byte var16 = var8;
      byte var10 = var16;
      byte var9 = var16;
      if (var17 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var10);
      } else {
         byte var18 = var9;
         if (var18 != 0) {
            var10 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var10);
         } else {
            return false;
         }
      }
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(91078830881903L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[8];
      String var6 = "¡qÄ\u0089×Ù¾ÿJ\u009c\u0094\u0001&g¯.±\u0015\tøå\tf'?~è\u0089ßÅ\t\u0084:û1Ñ\u0098·õ\u0089Y\u009eù/\u0015ö'<";
      int var7 = "¡qÄ\u0089×Ù¾ÿJ\u009c\u0094\u0001&g¯.±\u0015\tøå\tf'?~è\u0089ßÅ\t\u0084:û1Ñ\u0098·õ\u0089Y\u009eù/\u0015ö'<".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     e = var8;
                     f = new Integer[8];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "IÓÊ¹3\u008a$¦kÚY\u0092ÑAV\u0017";
                  var7 = "IÓÊ¹3\u008a$¦kÚY\u0092ÑAV\u0017".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25905;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])g.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/c2", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c2",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 45;
            yield var15;
         }
         case 1 -> {
            byte var16 = 26;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 48;
            yield var18;
         }
         case 4 -> {
            byte var19 = 30;
            yield var19;
         }
         case 5 -> {
            byte var20 = 5;
            yield var20;
         }
         case 6 -> {
            byte var21 = 20;
            yield var21;
         }
         case 7 -> {
            byte var22 = 4;
            yield var22;
         }
         case 8 -> {
            byte var23 = 35;
            yield var23;
         }
         case 9 -> {
            byte var24 = 17;
            yield var24;
         }
         case 10 -> {
            byte var25 = 32;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 18;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 53;
            yield var32;
         }
         case 18 -> {
            byte var33 = 62;
            yield var33;
         }
         case 19 -> {
            byte var34 = 57;
            yield var34;
         }
         case 20 -> {
            byte var35 = 36;
            yield var35;
         }
         case 21 -> {
            byte var36 = 9;
            yield var36;
         }
         case 22 -> {
            byte var37 = 34;
            yield var37;
         }
         case 23 -> {
            byte var38 = 46;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 15;
            yield var40;
         }
         case 26 -> {
            byte var41 = 22;
            yield var41;
         }
         case 27 -> {
            byte var42 = 0;
            yield var42;
         }
         case 28 -> {
            byte var43 = 63;
            yield var43;
         }
         case 29 -> {
            byte var44 = 33;
            yield var44;
         }
         case 30 -> {
            byte var45 = 55;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 8;
            yield var47;
         }
         case 33 -> {
            byte var48 = 14;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 59;
            yield var50;
         }
         case 36 -> {
            byte var51 = 11;
            yield var51;
         }
         case 37 -> {
            byte var52 = 3;
            yield var52;
         }
         case 38 -> {
            byte var53 = 54;
            yield var53;
         }
         case 39 -> {
            byte var54 = 23;
            yield var54;
         }
         case 40 -> {
            byte var55 = 6;
            yield var55;
         }
         case 41 -> {
            byte var56 = 39;
            yield var56;
         }
         case 42 -> {
            byte var57 = 47;
            yield var57;
         }
         case 43 -> {
            byte var58 = 13;
            yield var58;
         }
         case 44 -> {
            byte var59 = 1;
            yield var59;
         }
         case 45 -> {
            byte var60 = 42;
            yield var60;
         }
         case 46 -> {
            byte var61 = 25;
            yield var61;
         }
         case 47 -> {
            byte var62 = 52;
            yield var62;
         }
         case 48 -> {
            byte var63 = 50;
            yield var63;
         }
         case 49 -> {
            byte var64 = 28;
            yield var64;
         }
         case 50 -> {
            byte var65 = 60;
            yield var65;
         }
         case 51 -> {
            byte var66 = 24;
            yield var66;
         }
         case 52 -> {
            byte var67 = 10;
            yield var67;
         }
         case 53 -> {
            byte var68 = 29;
            yield var68;
         }
         case 54 -> {
            byte var69 = 27;
            yield var69;
         }
         case 55 -> {
            byte var70 = 16;
            yield var70;
         }
         case 56 -> {
            byte var71 = 49;
            yield var71;
         }
         case 57 -> {
            byte var72 = 58;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 31;
            yield var74;
         }
         case 60 -> {
            byte var75 = 19;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 41;
            yield var77;
         }
         default -> 37;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "\t\u001aQPr\u000e\u001f\u001aT\na\u0019\bQW\fm\r\u0019\u0016@\u001b&\u001f(";
      h[1] = int.class;
      i[1] = "java/lang/Integer";
      h[2] = "yUbT\u001c1yUu\b\u0010>c\u001eu\u0016\u0010+do'HHo";
      h[3] = boolean.class;
      i[3] = "java/lang/Boolean";
      h[4] = "o5fNRGy5c\u0014APn~`\u0012MD\u007f9w\u0005\u0006T9";
      h[5] = "|]%\u0001P$wR4N3)b_;%\u0006+sL'\t\u0011&";
      h[6] = "\u0014j\u0012D G\u0014j\u0005\u0018,H\u000e!\u0005\u0006,]\tPQ^{";
      h[7] = "x%J[\u0016/x%]\u0007\u001a bn]\u0019\u001a5e\u001f\fAH";
      h[8] = "-{xF\u001fX-{o\u001a\u0013W70o\u0004\u0013B0A:[J";
      h[9] = "\u001f4AI\u00040\u001f4V\u0015\b?\u0005\u007fV\u000b\b*\u0002\u000e\u0006^\\`";
      h[10] = "v]9irDv].5~Kl\u0016.+~^kg~~)\u0018";
      h[11] = "\u0003\u0017\u001ba:\u0013\u0003\u0017\f=6\u001c\u0019\\\f#6\t\u001e-\\~g";
      h[12] = "7\u001b(w\n)7\u001b?+\u0006&-P?5\u00063*!o`Ry}\u001d08\u00143\u0006MeoW";
      h[13] = "tB\u000b\u0000(2tB\u001c\\$=n\t\u001cB$(ixL\u0017pb>D\u0013O6(E\u0015K\u001c";
      h[14] = float.class;
      i[14] = "java/lang/Float";
      h[15] = "6\"\u001d\nET6\"\nVI[,i\nHIN+\u0018[\u0017\u0010";
      h[16] = double.class;
      i[16] = "java/lang/Double";
      h[17] = "Td{_?\\Tdl\u00033SN/l\u001d3FI^=Ba\r";
      h[18] = ":6N\\T8O\u0016ESEw.\u0018NXA-Z";
      h[19] = "s6\u0019QOXs6\u000e\rCWi}\u000e\u0013CBn\f_L\u001b";
      h[20] = "7p#K7\u0004!p&\u0011$\u00136;%\u0017(\u0007'|2\u0000c\u0017`";
      h[21] = "pY4x\b\t\u0005y?w\u0019Fdw4|\u001d\u001c\u0010";
      h[22] = "F\u0001sR0fF\u0001d\u000e<i\\Jd\u0010<|[;6Jj:";
      h[23] = "t7,N\t`j?6\u0001A`p5.FH{0\u0006(JC|}7.J";
      h[24] = "x\tJ/E|x\t]sIsbB]mIfe3\r8\u001e#";
      h[25] = "\u0015c{(\u0014[\u001eljgwV\u000bj";
      h[26] = "I{;\u0014[\u0015Bt*[:\u001bI\u007f.\u0001";
      h[27] = "!rQ&$.5cVl\\,%\u007f\u000fp0\u001eq;W&\\#ul\u0011ul1s\u007f\u0013\u00176t'}\r'$r4\u007fo}a&6a_og54\u0003\u0006fbx0d\u0012we2H";
      h[28] = "g\u001d? P\nd\u0015-\u001a_h$\u001d;cK\u0011`\nn\u001a";
      h[29] = "_&<\u0019FV\u000ep0\u000f+\tY`=\u0006G;\r$g_\u0017lNz0\u0018U\u0015\nmea";
      h[30] = "[\u000b,i ,O\u001a+#X._\u0006r?4\u001c\u000bJ\"`dK\u000fEc1'5\fKl2X\"CD# ?6RCiX";
      h[31] = "rYaA|\u00018\u00111\u0017\u001cXHD8BmR*WoCq1$D1\u0003z\u0001%[:C\u001c";
      h[32] = "Wq\\Qq\u0018\u00176UIM\u001b\u00062VU!)V~\f\u0003M\u0017\u001ap\u0007J*\u0003\u000bwM2";
      h[33] = "}gP/x07/\u0000y\u0018iG,\bt#r|e\u001e/s\u0000|q\t(j;5gRx\u0018";
      h[34] = "/\u001f_\u0014!R,\u0011P\u0017^BsMJ\u0011\t\u0015)\u001d\u0016}4\u0011}^LM&\u0017n\\";
      h[35] = "\u0012\u0011vS2\u001c\f\u001c-PKH\u0011\u001d'Q'zEQ\u007f\tv-F[x\u000e,O\u0015\u0003y\nK\u0010C\u0010.I5\u0013M\u001f-6v\u0012\r\b8Hu\u001c\u0002\u000bG_:\u0013M\u0019 K+\u0014\u0007a(\rrW\u0016_)Sp]|\u000bzY5OL\u0019|J7-\u0013\u0007(L,\u0012\u0003\u0005._K";
      h[36] = ";\u0013:\u0016\u0002\u001b:\f1VdN:\u00024\u000f\b|nAkXX+jA%\u0001\u001bUiO*\u0002d";
      h[37] = "_GAk\\x\u0005QD)0k\u0001WL~g<_\u0000\u0014\u0012\f:\nY\u0014tL}\u0003A";
      h[38] = "\u000eI\"J^8\n\f#\u000e\"&\u0017MdwH`\u0001IzGZf\u0012K\u0018\u001d\u001f2\u0010U(\u000f\u0019!\u00127";
      h[39] = "\b2%t\u001a9\u00001vw'mY=yvp:\u0007m *'3Zhs'\u001d;Y;p";
      h[40] = "\u001cfM8\u007fP\u001fhB;\u0000KL%\\6ly\u0018a\u0006k\u0000\u0013\u001e(U.~\u0010\u0010'VQj\u0013N'^ax\u0015]%<";
      h[41] = "FG\u001dwe\u001a\u001b\u001b\u0014`\u0018\u001a\u0016\u0016\u0016`OMLGB\f)H\u0018\u0000\u000fbt\u0014\u0011\u0017";
      h[42] = "{@\u001fC-^;\u0007\u0016[\u0011]*\u0003\u0015G}ozON\u001e\u0011Qw\u0005NImH6EL ,\u00076\u0016\n^/\t9\u0015u";
      h[43] = "Mf \" 5\r!):\u001c6\u001c%*&p\u0004Jbw~%SLf;(c-Oh4+\u001c";
      h[44] = "\u0003\u0006OILs\u0000\b@J3c_TZLd4\u0005\u0004\u0004 Y0QG\\\u0010K6BE";
      h[45] = "\r\\\u00140\u0001\u000b\u000eR\u001b3~\u001bQ\u000e\u00015)L\u000b^\\Y\u0014H_\u001d\u0007i\u0006NL\u001f";
      h[46] = "}^;~yT.\u0006:z\u001eS*\u0018d!rax_>{\u001e\f(\u000en\"/L{\u0007{F";
      h[47] = "\u000b0#J9\u0005Zf/\\TZ\rv\"U8hY2x\fl?\u001al/K*F^{z2";
      h[48] = "Zo$\u0015XZ\u000bv&\biY7k\u007fK\u0018PUx(J\u00043\n9i\u001d\u0016M\t7f\u001ei";
      h[49] = "h\u001c\"U-\u0001+\u001c+\u000eK\\8\u001br\b'nlX-Sq9k\u001anVv]eXx\fK\u0006<\u000e(\u0006+\u00023\u0007lo";
      h[50] = "I5+\u001eQa\u0013#.\\=r\u0017%&\u000bj%Hx}g\u0000gFr$_CgO)";
      h[51] = "N+~&|O\u001ds\u007f\"\u001bH\u0019m!ywzI!\u007f%\u001b\u0017\u001b{+z*WHr>\u001e";
      h[52] = "M|c*yy\u001c*o<\u0014&K:b5x\u0014\u001f~8l/C\\ o+j:\u00187:R";
      h[53] = "!gg^\u0017j\"ih]hqq$vP\u0004C%`,\nh)#)\u007fH\u0016*-&|7\u0002)s&t\u0007\u0010/`$\u0016";
      h[54] = "\u0002\u0012[HX\"\u0001\u001cTK'9RQJFK\u000b\u0006\u0015\u0010\u0019'a\u0000\\C^Yb\u000eS@!\u001acNDU_\u0019mAG*";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1831074124496513L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1831074124496513L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1831074124496513L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 84;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 213;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 200;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 101;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 68;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 218;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 84;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 213;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 200;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c2",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/c2", "lambda$interact$0", "(Lnet/minecraft/entity/Entity;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/c2", "lambda$interact$1", "(Lnet/minecraft/entity/Entity;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/c2", "lambda$interactTopFace$2", "(Lnet/minecraft/entity/Entity;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
