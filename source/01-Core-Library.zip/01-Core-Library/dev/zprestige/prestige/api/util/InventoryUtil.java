package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.client.management.PacketQueueManager;



import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public class InventoryUtil implements MinecraftAccess {
   private static final long a = 12128752710147L;
   private static final long[] c;
   private static final Integer[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[135];
   private static final String[] g = new String[135];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;
   private static volatile MethodHandle bindingCache93;
   private static volatile MethodHandle bindingCache94;
   private static volatile MethodHandle bindingCache95;
   private static volatile MethodHandle bindingCache96;
   private static volatile MethodHandle bindingCache97;
   private static volatile MethodHandle bindingCache98;
   private static volatile MethodHandle bindingCache99;
   private static volatile MethodHandle bindingCache100;
   private static volatile MethodHandle bindingCache101;
   private static volatile MethodHandle bindingCache102;
   private static volatile MethodHandle bindingCache103;
   private static volatile MethodHandle bindingCache104;

   public static boolean aReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var1;
      int var4 = Event.bReturningInt();
      ItemStack var5 = var3;
      Item var79 = var5.getItem();
      int var43 = var4;
      Item var42 = Items.DIAMOND_SWORD;
      Item var41 = var79;
      Item var22 = var41;
      Item var23 = var42;
      Item var20 = var41;
      Item var21 = var42;
      if (var43 == 0) {
         Item var45 = var21;
         Item var44 = var20;
         if (var44 == var45) {
            return true;
         }

         ItemStack var7 = var3;
         Item var80 = var7.getItem();
         Item var47 = Items.NETHERITE_SWORD;
         Item var46 = var80;
         var22 = var46;
         var23 = var47;
      }

      int var50 = var4;
      Item var49 = var23;
      Item var48 = var22;
      Item var26 = var48;
      Item var27 = var49;
      Item var24 = var48;
      Item var25 = var49;
      if (var50 == 0) {
         Item var52 = var25;
         Item var51 = var24;
         if (var51 == var52) {
            return true;
         }

         ItemStack var10 = var3;
         Item var81 = var10.getItem();
         Item var54 = Items.IRON_SWORD;
         Item var53 = var81;
         var26 = var53;
         var27 = var54;
      }

      int var57 = var4;
      Item var56 = var27;
      Item var55 = var26;
      Item var30 = var55;
      Item var31 = var56;
      Item var28 = var55;
      Item var29 = var56;
      if (var57 == 0) {
         Item var59 = var29;
         Item var58 = var28;
         if (var58 == var59) {
            return true;
         }

         ItemStack var13 = var3;
         Item var82 = var13.getItem();
         Item var61 = Items.GOLDEN_SWORD;
         Item var60 = var82;
         var30 = var60;
         var31 = var61;
      }

      int var64 = var4;
      Item var63 = var31;
      Item var62 = var30;
      Item var34 = var62;
      Item var35 = var63;
      Item var32 = var62;
      Item var33 = var63;
      if (var64 == 0) {
         Item var66 = var33;
         Item var65 = var32;
         if (var65 == var66) {
            return true;
         }

         ItemStack var16 = var3;
         Item var83 = var16.getItem();
         Item var68 = Items.STONE_SWORD;
         Item var67 = var83;
         var34 = var67;
         var35 = var68;
      }

      int var71 = var4;
      Item var70 = var35;
      Item var69 = var34;
      Item var38 = var69;
      Item var39 = var70;
      Item var36 = var69;
      Item var37 = var70;
      if (var71 == 0) {
         Item var73 = var37;
         Item var72 = var36;
         if (var72 == var73) {
            return true;
         }

         ItemStack var19 = var3;
         Item var84 = var19.getItem();
         Item var75 = Items.WOODEN_SWORD;
         Item var74 = var84;
         var38 = var74;
         var39 = var75;
      }

      Item var77 = var39;
      Item var76 = var38;
      return var76 == var77;
   }

   public static boolean bReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var1;
      int var4 = Event.cReturningInt();
      ItemStack var5 = var3;
      Item var79 = var5.getItem();
      int var43 = var4;
      Item var42 = Items.DIAMOND_AXE;
      Item var41 = var79;
      Item var22 = var41;
      Item var23 = var42;
      Item var20 = var41;
      Item var21 = var42;
      if (var43 != 0) {
         Item var45 = var21;
         Item var44 = var20;
         if (var44 == var45) {
            return true;
         }

         ItemStack var7 = var3;
         Item var80 = var7.getItem();
         Item var47 = Items.NETHERITE_AXE;
         Item var46 = var80;
         var22 = var46;
         var23 = var47;
      }

      int var50 = var4;
      Item var49 = var23;
      Item var48 = var22;
      Item var26 = var48;
      Item var27 = var49;
      Item var24 = var48;
      Item var25 = var49;
      if (var50 != 0) {
         Item var52 = var25;
         Item var51 = var24;
         if (var51 == var52) {
            return true;
         }

         ItemStack var10 = var3;
         Item var81 = var10.getItem();
         Item var54 = Items.IRON_AXE;
         Item var53 = var81;
         var26 = var53;
         var27 = var54;
      }

      int var57 = var4;
      Item var56 = var27;
      Item var55 = var26;
      Item var30 = var55;
      Item var31 = var56;
      Item var28 = var55;
      Item var29 = var56;
      if (var57 != 0) {
         Item var59 = var29;
         Item var58 = var28;
         if (var58 == var59) {
            return true;
         }

         ItemStack var13 = var3;
         Item var82 = var13.getItem();
         Item var61 = Items.GOLDEN_AXE;
         Item var60 = var82;
         var30 = var60;
         var31 = var61;
      }

      int var64 = var4;
      Item var63 = var31;
      Item var62 = var30;
      Item var34 = var62;
      Item var35 = var63;
      Item var32 = var62;
      Item var33 = var63;
      if (var64 != 0) {
         Item var66 = var33;
         Item var65 = var32;
         if (var65 == var66) {
            return true;
         }

         ItemStack var16 = var3;
         Item var83 = var16.getItem();
         Item var68 = Items.STONE_AXE;
         Item var67 = var83;
         var34 = var67;
         var35 = var68;
      }

      int var71 = var4;
      Item var70 = var35;
      Item var69 = var34;
      Item var38 = var69;
      Item var39 = var70;
      Item var36 = var69;
      Item var37 = var70;
      if (var71 != 0) {
         Item var73 = var37;
         Item var72 = var36;
         if (var72 == var73) {
            return true;
         }

         ItemStack var19 = var3;
         Item var84 = var19.getItem();
         Item var75 = Items.WOODEN_AXE;
         Item var74 = var84;
         var38 = var74;
         var39 = var75;
      }

      Item var77 = var39;
      Item var76 = var38;
      return var76 == var77;
   }

   public static boolean cReturningBoolean(Object[] var0) {
      ItemStack var1 = (ItemStack)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var2;
      int var4 = Event.cReturningInt();
      ItemStack var5 = var1;
      Item var79 = var5.getItem();
      int var43 = var4;
      Item var42 = Items.DIAMOND_PICKAXE;
      Item var41 = var79;
      Item var22 = var41;
      Item var23 = var42;
      Item var20 = var41;
      Item var21 = var42;
      if (var43 != 0) {
         Item var45 = var21;
         Item var44 = var20;
         if (var44 == var45) {
            return true;
         }

         ItemStack var7 = var1;
         Item var80 = var7.getItem();
         Item var47 = Items.NETHERITE_PICKAXE;
         Item var46 = var80;
         var22 = var46;
         var23 = var47;
      }

      int var50 = var4;
      Item var49 = var23;
      Item var48 = var22;
      Item var26 = var48;
      Item var27 = var49;
      Item var24 = var48;
      Item var25 = var49;
      if (var50 != 0) {
         Item var52 = var25;
         Item var51 = var24;
         if (var51 == var52) {
            return true;
         }

         ItemStack var10 = var1;
         Item var81 = var10.getItem();
         Item var54 = Items.IRON_PICKAXE;
         Item var53 = var81;
         var26 = var53;
         var27 = var54;
      }

      int var57 = var4;
      Item var56 = var27;
      Item var55 = var26;
      Item var30 = var55;
      Item var31 = var56;
      Item var28 = var55;
      Item var29 = var56;
      if (var57 != 0) {
         Item var59 = var29;
         Item var58 = var28;
         if (var58 == var59) {
            return true;
         }

         ItemStack var13 = var1;
         Item var82 = var13.getItem();
         Item var61 = Items.GOLDEN_PICKAXE;
         Item var60 = var82;
         var30 = var60;
         var31 = var61;
      }

      int var64 = var4;
      Item var63 = var31;
      Item var62 = var30;
      Item var34 = var62;
      Item var35 = var63;
      Item var32 = var62;
      Item var33 = var63;
      if (var64 != 0) {
         Item var66 = var33;
         Item var65 = var32;
         if (var65 == var66) {
            return true;
         }

         ItemStack var16 = var1;
         Item var83 = var16.getItem();
         Item var68 = Items.STONE_PICKAXE;
         Item var67 = var83;
         var34 = var67;
         var35 = var68;
      }

      int var71 = var4;
      Item var70 = var35;
      Item var69 = var34;
      Item var38 = var69;
      Item var39 = var70;
      Item var36 = var69;
      Item var37 = var70;
      if (var71 != 0) {
         Item var73 = var37;
         Item var72 = var36;
         if (var72 == var73) {
            return true;
         }

         ItemStack var19 = var1;
         Item var84 = var19.getItem();
         Item var75 = Items.WOODEN_PICKAXE;
         Item var74 = var84;
         var38 = var74;
         var39 = var75;
      }

      Item var77 = var39;
      Item var76 = var38;
      return var76 == var77;
   }

    public static boolean dReturningBoolean(Object[] objectArray) {
        Item item;
        Item item2;
        long l;
        block126: {
            int n;
            ItemStack itemStack;
            block125: {
                block124: {
                    block123: {
                        block122: {
                            block121: {
                                block120: {
                                    block119: {
                                        block118: {
                                            block117: {
                                                block116: {
                                                    block115: {
                                                        block114: {
                                                            block113: {
                                                                block112: {
                                                                    block111: {
                                                                        block110: {
                                                                            block109: {
                                                                                block108: {
                                                                                    block107: {
                                                                                        block106: {
                                                                                            block105: {
                                                                                                block104: {
                                                                                                    block103: {
                                                                                                        block102: {
                                                                                                            itemStack = (ItemStack)objectArray[0];
                                                                                                            l = (Long)objectArray[1];
                                                                                                            l = 0xB07F1FF3203L ^ l;
                                                                                                            n = InventoryUtil.invokeBinding1(1632665889284007651L, l);
                                                                                                            try {
                                                                                                                try {
                                                                                                                    item2 = InventoryUtil.invokeBinding2(itemStack, 1632172840288037601L, l);
                                                                                                                    item = InventoryUtil.invokeBinding3(1634224024779406553L, l);
                                                                                                                    if (n == 0) break block102;
                                                                                                                    if (item2 == item) return 1 != 0;
                                                                                                                }
                                                                                                                catch (MatchException matchException) {
                                                                                                                    throw InventoryUtil.invokeBinding4(matchException, 1625890025909708782L, l);
                                                                                                                }
                                                                                                                item2 = InventoryUtil.invokeBinding5(itemStack, 1632172840288037601L, l);
                                                                                                                item = InventoryUtil.invokeBinding6(1631339260678724928L, l);
                                                                                                            }
                                                                                                            catch (MatchException matchException) {
                                                                                                                throw InventoryUtil.invokeBinding7(matchException, 1625890025909708782L, l);
                                                                                                            }
                                                                                                        }
                                                                                                        try {
                                                                                                            try {
                                                                                                                if (n == 0) break block103;
                                                                                                                if (item2 == item) return 1 != 0;
                                                                                                            }
                                                                                                            catch (MatchException matchException) {
                                                                                                                throw InventoryUtil.invokeBinding8(matchException, 1625890025909708782L, l);
                                                                                                            }
                                                                                                            item2 = InventoryUtil.invokeBinding9(itemStack, 1632172840288037601L, l);
                                                                                                            item = InventoryUtil.invokeBinding10(1633394824265960229L, l);
                                                                                                        }
                                                                                                        catch (MatchException matchException) {
                                                                                                            throw InventoryUtil.invokeBinding11(matchException, 1625890025909708782L, l);
                                                                                                        }
                                                                                                    }
                                                                                                    try {
                                                                                                        try {
                                                                                                            if (n == 0) break block104;
                                                                                                            if (item2 == item) return 1 != 0;
                                                                                                        }
                                                                                                        catch (MatchException matchException) {
                                                                                                            throw InventoryUtil.invokeBinding12(matchException, 1625890025909708782L, l);
                                                                                                        }
                                                                                                        item2 = InventoryUtil.invokeBinding13(itemStack, 1632172840288037601L, l);
                                                                                                        item = InventoryUtil.invokeBinding14(1632913997895466121L, l);
                                                                                                    }
                                                                                                    catch (MatchException matchException) {
                                                                                                        throw InventoryUtil.invokeBinding15(matchException, 1625890025909708782L, l);
                                                                                                    }
                                                                                                }
                                                                                                try {
                                                                                                    try {
                                                                                                        if (n == 0) break block105;
                                                                                                        if (item2 == item) return 1 != 0;
                                                                                                    }
                                                                                                    catch (MatchException matchException) {
                                                                                                        throw InventoryUtil.invokeBinding16(matchException, 1625890025909708782L, l);
                                                                                                    }
                                                                                                    item2 = InventoryUtil.invokeBinding17(itemStack, 1632172840288037601L, l);
                                                                                                    item = InventoryUtil.invokeBinding18(1630930408317643096L, l);
                                                                                                }
                                                                                                catch (MatchException matchException) {
                                                                                                    throw InventoryUtil.invokeBinding19(matchException, 1625890025909708782L, l);
                                                                                                }
                                                                                            }
                                                                                            try {
                                                                                                try {
                                                                                                    if (n == 0) break block106;
                                                                                                    if (item2 == item) return 1 != 0;
                                                                                                }
                                                                                                catch (MatchException matchException) {
                                                                                                    throw InventoryUtil.invokeBinding20(matchException, 1625890025909708782L, l);
                                                                                                }
                                                                                                item2 = InventoryUtil.invokeBinding21(itemStack, 1632172840288037601L, l);
                                                                                                item = InventoryUtil.invokeBinding22(1633117248796848938L, l);
                                                                                            }
                                                                                            catch (MatchException matchException) {
                                                                                                throw InventoryUtil.invokeBinding23(matchException, 1625890025909708782L, l);
                                                                                            }
                                                                                        }
                                                                                        try {
                                                                                            try {
                                                                                                if (n == 0) break block107;
                                                                                                if (item2 == item) return 1 != 0;
                                                                                            }
                                                                                            catch (MatchException matchException) {
                                                                                                throw InventoryUtil.invokeBinding24(matchException, 1625890025909708782L, l);
                                                                                            }
                                                                                            item2 = InventoryUtil.invokeBinding25(itemStack, 1632172840288037601L, l);
                                                                                            item = InventoryUtil.invokeBinding26(1639161120399563538L, l);
                                                                                        }
                                                                                        catch (MatchException matchException) {
                                                                                            throw InventoryUtil.invokeBinding27(matchException, 1625890025909708782L, l);
                                                                                        }
                                                                                    }
                                                                                    try {
                                                                                        try {
                                                                                            if (n == 0) break block108;
                                                                                            if (item2 == item) return 1 != 0;
                                                                                        }
                                                                                        catch (MatchException matchException) {
                                                                                            throw InventoryUtil.invokeBinding28(matchException, 1625890025909708782L, l);
                                                                                        }
                                                                                        item2 = InventoryUtil.invokeBinding29(itemStack, 1632172840288037601L, l);
                                                                                        item = InventoryUtil.invokeBinding30(1634445561000129554L, l);
                                                                                    }
                                                                                    catch (MatchException matchException) {
                                                                                        throw InventoryUtil.invokeBinding31(matchException, 1625890025909708782L, l);
                                                                                    }
                                                                                }
                                                                                try {
                                                                                    try {
                                                                                        if (n == 0) break block109;
                                                                                        if (item2 == item) return 1 != 0;
                                                                                    }
                                                                                    catch (MatchException matchException) {
                                                                                        throw InventoryUtil.invokeBinding32(matchException, 1625890025909708782L, l);
                                                                                    }
                                                                                    item2 = InventoryUtil.invokeBinding33(itemStack, 1632172840288037601L, l);
                                                                                    item = InventoryUtil.invokeBinding34(1633470032453979722L, l);
                                                                                }
                                                                                catch (MatchException matchException) {
                                                                                    throw InventoryUtil.invokeBinding35(matchException, 1625890025909708782L, l);
                                                                                }
                                                                            }
                                                                            try {
                                                                                try {
                                                                                    if (n == 0) break block110;
                                                                                    if (item2 == item) return 1 != 0;
                                                                                }
                                                                                catch (MatchException matchException) {
                                                                                    throw InventoryUtil.invokeBinding36(matchException, 1625890025909708782L, l);
                                                                                }
                                                                                item2 = InventoryUtil.invokeBinding37(itemStack, 1632172840288037601L, l);
                                                                                item = InventoryUtil.invokeBinding38(1633678057307586631L, l);
                                                                            }
                                                                            catch (MatchException matchException) {
                                                                                throw InventoryUtil.invokeBinding39(matchException, 1625890025909708782L, l);
                                                                            }
                                                                        }
                                                                        try {
                                                                            try {
                                                                                if (n == 0) break block111;
                                                                                if (item2 == item) return 1 != 0;
                                                                            }
                                                                            catch (MatchException matchException) {
                                                                                throw InventoryUtil.invokeBinding40(matchException, 1625890025909708782L, l);
                                                                            }
                                                                            item2 = InventoryUtil.invokeBinding41(itemStack, 1632172840288037601L, l);
                                                                            item = InventoryUtil.invokeBinding42(1626330448713177909L, l);
                                                                        }
                                                                        catch (MatchException matchException) {
                                                                            throw InventoryUtil.invokeBinding43(matchException, 1625890025909708782L, l);
                                                                        }
                                                                    }
                                                                    try {
                                                                        try {
                                                                            if (n == 0) break block112;
                                                                            if (item2 == item) return 1 != 0;
                                                                        }
                                                                        catch (MatchException matchException) {
                                                                            throw InventoryUtil.invokeBinding44(matchException, 1625890025909708782L, l);
                                                                        }
                                                                        item2 = InventoryUtil.invokeBinding45(itemStack, 1632172840288037601L, l);
                                                                        item = InventoryUtil.invokeBinding46(1630857446986772201L, l);
                                                                    }
                                                                    catch (MatchException matchException) {
                                                                        throw InventoryUtil.invokeBinding47(matchException, 1625890025909708782L, l);
                                                                    }
                                                                }
                                                                try {
                                                                    try {
                                                                        if (n == 0) break block113;
                                                                        if (item2 == item) return 1 != 0;
                                                                    }
                                                                    catch (MatchException matchException) {
                                                                        throw InventoryUtil.invokeBinding48(matchException, 1625890025909708782L, l);
                                                                    }
                                                                    item2 = InventoryUtil.invokeBinding49(itemStack, 1632172840288037601L, l);
                                                                    item = InventoryUtil.invokeBinding50(1632821417748224790L, l);
                                                                }
                                                                catch (MatchException matchException) {
                                                                    throw InventoryUtil.invokeBinding51(matchException, 1625890025909708782L, l);
                                                                }
                                                            }
                                                            try {
                                                                try {
                                                                    if (n == 0) break block114;
                                                                    if (item2 == item) return 1 != 0;
                                                                }
                                                                catch (MatchException matchException) {
                                                                    throw InventoryUtil.invokeBinding52(matchException, 1625890025909708782L, l);
                                                                }
                                                                item2 = InventoryUtil.invokeBinding53(itemStack, 1632172840288037601L, l);
                                                                item = InventoryUtil.invokeBinding54(1639271959172479046L, l);
                                                            }
                                                            catch (MatchException matchException) {
                                                                throw InventoryUtil.invokeBinding55(matchException, 1625890025909708782L, l);
                                                            }
                                                        }
                                                        try {
                                                            try {
                                                                if (n == 0) break block115;
                                                                if (item2 == item) return 1 != 0;
                                                            }
                                                            catch (MatchException matchException) {
                                                                throw InventoryUtil.invokeBinding56(matchException, 1625890025909708782L, l);
                                                            }
                                                            item2 = InventoryUtil.invokeBinding57(itemStack, 1632172840288037601L, l);
                                                            item = InventoryUtil.invokeBinding58(1638678009998523998L, l);
                                                        }
                                                        catch (MatchException matchException) {
                                                            throw InventoryUtil.invokeBinding59(matchException, 1625890025909708782L, l);
                                                        }
                                                    }
                                                    try {
                                                        try {
                                                            if (n == 0) break block116;
                                                            if (item2 == item) return 1 != 0;
                                                        }
                                                        catch (MatchException matchException) {
                                                            throw InventoryUtil.invokeBinding60(matchException, 1625890025909708782L, l);
                                                        }
                                                        item2 = InventoryUtil.invokeBinding61(itemStack, 1632172840288037601L, l);
                                                        item = InventoryUtil.invokeBinding62(1630375701624539419L, l);
                                                    }
                                                    catch (MatchException matchException) {
                                                        throw InventoryUtil.invokeBinding63(matchException, 1625890025909708782L, l);
                                                    }
                                                }
                                                try {
                                                    try {
                                                        if (n == 0) break block117;
                                                        if (item2 == item) return 1 != 0;
                                                    }
                                                    catch (MatchException matchException) {
                                                        throw InventoryUtil.invokeBinding64(matchException, 1625890025909708782L, l);
                                                    }
                                                    item2 = InventoryUtil.invokeBinding65(itemStack, 1632172840288037601L, l);
                                                    item = InventoryUtil.invokeBinding66(1639070171086826818L, l);
                                                }
                                                catch (MatchException matchException) {
                                                    throw InventoryUtil.invokeBinding67(matchException, 1625890025909708782L, l);
                                                }
                                            }
                                            try {
                                                try {
                                                    if (n == 0) break block118;
                                                    if (item2 == item) return 1 != 0;
                                                }
                                                catch (MatchException matchException) {
                                                    throw InventoryUtil.invokeBinding68(matchException, 1625890025909708782L, l);
                                                }
                                                item2 = InventoryUtil.invokeBinding69(itemStack, 1632172840288037601L, l);
                                                item = InventoryUtil.invokeBinding70(1630303334344072185L, l);
                                            }
                                            catch (MatchException matchException) {
                                                throw InventoryUtil.invokeBinding71(matchException, 1625890025909708782L, l);
                                            }
                                        }
                                        try {
                                            try {
                                                if (n == 0) break block119;
                                                if (item2 == item) return 1 != 0;
                                            }
                                            catch (MatchException matchException) {
                                                throw InventoryUtil.invokeBinding72(matchException, 1625890025909708782L, l);
                                            }
                                            item2 = InventoryUtil.invokeBinding73(itemStack, 1632172840288037601L, l);
                                            item = InventoryUtil.invokeBinding74(1638795241252157023L, l);
                                        }
                                        catch (MatchException matchException) {
                                            throw InventoryUtil.invokeBinding75(matchException, 1625890025909708782L, l);
                                        }
                                    }
                                    try {
                                        try {
                                            if (n == 0) break block120;
                                            if (item2 == item) return 1 != 0;
                                        }
                                        catch (MatchException matchException) {
                                            throw InventoryUtil.invokeBinding76(matchException, 1625890025909708782L, l);
                                        }
                                        item2 = InventoryUtil.invokeBinding77(itemStack, 1632172840288037601L, l);
                                        item = InventoryUtil.invokeBinding78(1632895220180837889L, l);
                                    }
                                    catch (MatchException matchException) {
                                        throw InventoryUtil.invokeBinding79(matchException, 1625890025909708782L, l);
                                    }
                                }
                                try {
                                    try {
                                        if (n == 0) break block121;
                                        if (item2 == item) return 1 != 0;
                                    }
                                    catch (MatchException matchException) {
                                        throw InventoryUtil.invokeBinding80(matchException, 1625890025909708782L, l);
                                    }
                                    item2 = InventoryUtil.invokeBinding81(itemStack, 1632172840288037601L, l);
                                    item = InventoryUtil.invokeBinding82(1634528150413211245L, l);
                                }
                                catch (MatchException matchException) {
                                    throw InventoryUtil.invokeBinding83(matchException, 1625890025909708782L, l);
                                }
                            }
                            try {
                                try {
                                    if (n == 0) break block122;
                                    if (item2 == item) return 1 != 0;
                                }
                                catch (MatchException matchException) {
                                    throw InventoryUtil.invokeBinding84(matchException, 1625890025909708782L, l);
                                }
                                item2 = InventoryUtil.invokeBinding85(itemStack, 1632172840288037601L, l);
                                item = InventoryUtil.invokeBinding86(1633954562796887092L, l);
                            }
                            catch (MatchException matchException) {
                                throw InventoryUtil.invokeBinding87(matchException, 1625890025909708782L, l);
                            }
                        }
                        try {
                            try {
                                if (n == 0) break block123;
                                if (item2 == item) return 1 != 0;
                            }
                            catch (MatchException matchException) {
                                throw InventoryUtil.invokeBinding88(matchException, 1625890025909708782L, l);
                            }
                            item2 = InventoryUtil.invokeBinding89(itemStack, 1632172840288037601L, l);
                            item = InventoryUtil.invokeBinding90(1634130097392552738L, l);
                        }
                        catch (MatchException matchException) {
                            throw InventoryUtil.invokeBinding91(matchException, 1625890025909708782L, l);
                        }
                    }
                    try {
                        try {
                            if (n == 0) break block124;
                            if (item2 == item) return 1 != 0;
                        }
                        catch (MatchException matchException) {
                            throw InventoryUtil.invokeBinding92(matchException, 1625890025909708782L, l);
                        }
                        item2 = InventoryUtil.invokeBinding93(itemStack, 1632172840288037601L, l);
                        item = InventoryUtil.invokeBinding94(1638503453976844798L, l);
                    }
                    catch (MatchException matchException) {
                        throw InventoryUtil.invokeBinding95(matchException, 1625890025909708782L, l);
                    }
                }
                try {
                    try {
                        if (n == 0) break block125;
                        if (item2 == item) return 1 != 0;
                    }
                    catch (MatchException matchException) {
                        throw InventoryUtil.invokeBinding96(matchException, 1625890025909708782L, l);
                    }
                    item2 = InventoryUtil.invokeBinding97(itemStack, 1632172840288037601L, l);
                    item = InventoryUtil.invokeBinding98(1638977775737898659L, l);
                }
                catch (MatchException matchException) {
                    throw InventoryUtil.invokeBinding99(matchException, 1625890025909708782L, l);
                }
            }
            try {
                try {
                    if (n == 0) break block126;
                    if (item2 == item) return 1 != 0;
                }
                catch (MatchException matchException) {
                    throw InventoryUtil.invokeBinding100(matchException, 1625890025909708782L, l);
                }
                item2 = InventoryUtil.invokeBinding101(itemStack, 1632172840288037601L, l);
                item = InventoryUtil.invokeBinding102(1638604204190844296L, l);
            }
            catch (MatchException matchException) {
                throw InventoryUtil.invokeBinding103(matchException, 1625890025909708782L, l);
            }
        }
        try {
            if (item2 != item) return 0 != 0;
            return 1 != 0;
        }
        catch (MatchException matchException) {
            throw InventoryUtil.invokeBinding104(matchException, 1625890025909708782L, l);
        }
    }

   public static boolean eReturningBoolean(Object[] var0) {
      int var3 = (Integer)var0[0];
      int var5 = (Integer)var0[1];
      SlotActionType var4 = (SlotActionType)var0[2];
      long var1 = (Long)var0[3];
      long var10000 = 12128752710147L ^ var1;
      int var6 = Event.bReturningInt();
      MinecraftClient var7 = b;
      byte var37 = ((byte)((var7.currentScreen instanceof InventoryScreen) ? 1 : 0));
      int var35 = var6;
      byte var34 = var37;
      byte var33 = var34;
      byte var32 = var34;
      if (var35 == 0) {
         byte var36 = var32;
         if (var36 == 0) {
            MinecraftClient var9 = b;
            MinecraftClient var10 = b;
            ClientPlayerEntity var11 = var10.player;
            ScreenHandler var12 = var11.currentScreenHandler;
            MinecraftClient var13 = b;
            ClientPlayerEntity var19 = var13.player;
            SlotActionType var18 = var4;
            int var17 = var5;
            int var16 = var3;
            int var15 = var12.syncId;
            ClientPlayerInteractionManager var14 = var9.interactionManager;
            var14.clickSlot(var15, var16, var17, var18, (PlayerEntity)var19);
            return false;
         }

         MinecraftClient var21 = b;
         ClientPlayerInteractionManager var38 = var21.interactionManager;
         MinecraftClient var22 = b;
         InventoryScreen var23 = (InventoryScreen)var22.currentScreen;
         PlayerScreenHandler var24 = (PlayerScreenHandler)var23.getScreenHandler();
         MinecraftClient var25 = b;
         ClientPlayerEntity var31 = var25.player;
         SlotActionType var30 = var4;
         int var29 = var5;
         int var28 = var3;
         int var27 = var24.syncId;
         ClientPlayerInteractionManager var26 = var38;
         var26.clickSlot(var27, var28, var29, var30, (PlayerEntity)var31);
         var33 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var33);
   }

   public static boolean fReturningBoolean(Object[] var0) {
      int var4 = (Integer)var0[0];
      int var1 = (Integer)var0[1];
      long var2 = (Long)var0[2];
      var2 = 12128752710147L ^ var2;
      long var5 = var2 ^ 41988893745787L;
      long var7 = var2 ^ 114419199716875L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var11 = b;
      boolean var10 = var11.currentScreen instanceof InventoryScreen;
      int var9 = var10000;
      int var20 = var9;
      PacketQueueManager var19 = Prestige.u;
      PacketQueueManager var18 = var19;
      PacketQueueManager var17 = var19;
      if (var20 == 0) {
         PacketQueueManager var21 = var17;
         if (var21 == null) {
            Object[] var23 = new Object[]{null, null, SlotActionType.SWAP, var7};
            var23[1] = var1;
            var23[0] = var4;
            Object[] var13 = var23;
            eReturningBoolean(var13);
            return var10;
         }

         var18 = Prestige.u;
      }

      Object[] var10005 = new Object[]{null, null, var5};
      var10005[1] = var1;
      var10005[0] = var4;
      Object[] var16 = var10005;
      PacketQueueManager var15 = var18;
      var15.aReturningp_C0432(var16);
      return var10;
   }

   public static boolean gReturningBoolean(Object[] var0) {
      int var3 = (Integer)var0[0];
      int var5 = (Integer)var0[1];
      SlotActionType var4 = (SlotActionType)var0[2];
      long var1 = (Long)var0[3];
      long var10000 = 12128752710147L ^ var1;
      int var6 = Event.cReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var8 = var7.player;
      byte var27 = ((byte)((var8.currentScreenHandler instanceof GenericContainerScreenHandler) ? 1 : 0));
      int var25 = var6;
      byte var24 = var27;
      byte var23 = var24;
      byte var22 = var24;
      if (var25 != 0) {
         byte var26 = var22;
         if (var26 == 0) {
            return false;
         }

         MinecraftClient var11 = b;
         MinecraftClient var12 = b;
         ClientPlayerEntity var13 = var12.player;
         ScreenHandler var14 = var13.currentScreenHandler;
         MinecraftClient var15 = b;
         ClientPlayerEntity var21 = var15.player;
         SlotActionType var20 = var4;
         int var19 = var5;
         int var18 = var3;
         int var17 = var14.syncId;
         ClientPlayerInteractionManager var16 = var11.interactionManager;
         var16.clickSlot(var17, var18, var19, var20, (PlayerEntity)var21);
         var23 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var23);
   }

   public static boolean h(Object[] var0) {
      Item var1 = (Item)var0[0];
      long var2 = (Long)var0[1];
      var2 = 12128752710147L ^ var2;
      long var4 = var2 ^ 76680199943658L;
      long var6 = var2 ^ 91225995459354L;
      int var10000 = Event.cReturningInt();
      Object[] var10 = new Object[]{var1, var4};
      Integer var9 = aReturningBoxedInteger(var10);
      int var8 = var10000;
      int var18 = var8;
      Integer var17 = var9;
      Integer var16 = var17;
      Integer var15 = var17;
      if (var18 != 0) {
         Integer var19 = var15;
         if (var19 == null) {
            return false;
         }

         var16 = var9;
      }

      Integer var13 = var16;
      var10000 = var13;
      Object[] var10003 = new Object[]{null, var6};
      var10003[0] = var10000;
      Object[] var14 = var10003;
      aReturningVoid(var14);
      return true;
   }

   public static boolean i(Object[] var0) {
      Block var3 = (Block)var0[0];
      long var1 = (Long)var0[1];
      var1 = 12128752710147L ^ var1;
      long var4 = var1 ^ 44049581673525L;
      Block var6 = var3;
      Object[] var7 = new Object[]{var6.asItem(), var4};
      return h(var7);
   }

   public static void aReturningVoid(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 12128752710147L ^ var1;
      int var4 = Event.bReturningInt();
      int var14 = var4;
      int var13 = var3;
      int var12 = var13;
      int var11 = var13;
      if (var14 == 0) {
         short var10001 = 27762;
         long var10002 = 6982990287487310999L ^ var1;
         byte var16 = 8;
         int var15 = var11;
         if (var15 > var16) {
            return;
         }

         int var17 = var3;
         var12 = var17;
      }

      int var18 = var12;
      if (var18 >= 0) {
         MinecraftClient var7 = b;
         ClientPlayerEntity var8 = var7.player;
         PlayerInventory var10000 = var8.getInventory();
         int var10 = var3;
         PlayerInventory var9 = var10000;
         var9.setSelectedSlot(var10);
      }
   }

   public static void bReturningVoid(Object[] var0) {
      int var1 = (Integer)var0[0];
      Runnable var5 = (Runnable)var0[1];
      int var4 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var0[2]))))))))) ? 1 : 0);
      long var2 = (Long)var0[3];
      var2 = 12128752710147L ^ var2;
      long var6 = var2 ^ 114783173989888L;
      long var8 = var2 ^ 5030796366969L;
      int var10000 = Event.cReturningInt();
      Object[] var12 = new Object[]{var6};
      int var11 = aReturningInt(var12);
      int var10 = var10000;
      Object[] var10003 = new Object[]{null, var8};
      var10003[0] = var1;
      Object[] var13 = var10003;
      aReturningVoid(var13);
      Runnable var14 = var5;
      var14.run();
      int var20 = var10;
      int var19 = var4;
      int var18 = var19;
      int var17 = var19;
      if (var20 != 0) {
         int var21 = var17;
         if (var21 == 0) {
            return;
         }

         var18 = var11;
      }

      var10003 = new Object[]{null, var8};
      var10003[0] = var18;
      Object[] var16 = var10003;
      aReturningVoid(var16);
   }

   public static boolean jReturningBoolean(Object[] var0) {
      Item var3 = (Item)var0[0];
      Runnable var2 = (Runnable)var0[1];
      boolean var1 = (Boolean)var0[2];
      long var4 = (Long)var0[3];
      var4 = 12128752710147L ^ var4;
      long var6 = var4 ^ 32393579999454L;
      long var8 = var4 ^ 6215386404948L;
      int var10000 = Event.cReturningInt();
      Object[] var12 = new Object[]{var3, var6};
      Integer var11 = aReturningBoxedInteger(var12);
      int var10 = var10000;
      int var20 = var10;
      Integer var19 = var11;
      Integer var18 = var19;
      Integer var17 = var19;
      if (var20 != 0) {
         Integer var21 = var17;
         if (var21 == null) {
            return false;
         }

         var18 = var11;
      }

      Integer var15 = var18;
      var10000 = var15;
      Object[] var10005 = new Object[]{null, null, null, var8};
      var10005[2] = var1;
      var10005[1] = var2;
      var10005[0] = var10000;
      Object[] var16 = var10005;
      bReturningVoid(var16);
      return true;
   }

   public static boolean kReturningBoolean(Object[] var0) {
      Block var3 = (Block)var0[0];
      Runnable var5 = (Runnable)var0[1];
      boolean var4 = (Boolean)var0[2];
      long var1 = (Long)var0[3];
      var1 = 12128752710147L ^ var1;
      long var6 = var1 ^ 33218465551879L;
      Block var8 = var3;
      Item var10000 = var8.asItem();
      Object[] var10005 = new Object[]{null, null, null, var6};
      var10005[2] = var4;
      var10005[1] = var5;
      var10005[0] = var10000;
      Object[] var9 = var10005;
      return jReturningBoolean(var9);
   }

   public static Integer aReturningBoxedInteger(Object[] var0) {
      Item var3 = (Item)var0[0];
      long var1 = (Long)var0[1];
      var1 = 12128752710147L ^ var1;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      int var19;
      do {
         short var10001 = 27762;
         long var10002 = 6982980682649080423L ^ var1;
         byte var15 = 8;
         int var14 = var5;
         if (var14 > var15) {
            break;
         }

         MinecraftClient var7 = b;
         ClientPlayerEntity var8 = var7.player;
         PlayerInventory var21 = var8.getInventory();
         int var10 = var5;
         PlayerInventory var9 = var21;
         ItemStack var6 = var9.getStack(var10);
         int var16 = var4;
         if (var16 != 0) {
            ItemStack var11 = var6;
            Item var22 = var11.getItem();
            Item var18 = var3;
            Item var17 = var22;
            if (var17 == var18) {
               int var13 = var5;
               return var13;
            }

            var5++;
         }

         var19 = var4;
      } while (var19 != 0);

      return null;
   }

   public static Integer bReturningBoxedInteger(Object[] var0) {
      Item var1 = (Item)var0[0];
      long var2 = (Long)var0[1];
      var2 = 12128752710147L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      int var23;
      do {
         short var10001 = 27762;
         long var10002 = 6983076715230162702L ^ var2;
         byte var17 = 8;
         int var16 = var5;
         if (var16 > var17) {
            break;
         }

         MinecraftClient var7 = b;
         ClientPlayerEntity var8 = var7.player;
         PlayerInventory var25 = var8.getInventory();
         int var10 = var5;
         PlayerInventory var9 = var25;
         ItemStack var6 = var9.getStack(var10);
         int var18 = var4;
         if (var18 == 0) {
            ItemStack var11 = var6;
            Item var26 = var11.getItem();
            Item var20 = var1;
            Item var19 = var26;
            if (var19 != var20) {
               ItemStack var13 = var6;
               Item var27 = var13.getItem();
               Item var22 = Items.AIR;
               Item var21 = var27;
               if (var21 != var22) {
                  int var15 = var5;
                  return var15;
               }
            }

            var5++;
         }

         var23 = var4;
      } while (var23 == 0);

      return null;
   }

   public static Integer cReturningBoxedInteger(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 12128752710147L ^ var1;
      long var3 = var1 ^ 13066142860570L;
      int var10000 = Event.cReturningInt();
      int var5 = var10000;

      int var19;
      do {
         short var10001 = 27762;
         long var10002 = 6982975136667938718L ^ var1;
         byte var16 = 8;
         int var15 = var6;
         if (var15 > var16) {
            break;
         }

         MinecraftClient var8 = b;
         ClientPlayerEntity var9 = var8.player;
         PlayerInventory var21 = var9.getInventory();
         int var11 = var6;
         PlayerInventory var10 = var21;
         ItemStack var7 = var10.getStack(var11);
         int var17 = var5;
         if (var17 != 0) {
            Object[] var12 = new Object[]{var7, var3};
            boolean var18 = o(var12);
            if (var18) {
               int var14 = var6;
               return var14;
            }

            var6++;
         }

         var19 = var5;
      } while (var19 != 0);

      return null;
   }

   public static Integer dReturningBoxedInteger(Object[] var0) {
      Block var1 = (Block)var0[0];
      long var2 = (Long)var0[1];
      var2 = 12128752710147L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      int var20;
      do {
         short var10001 = 26018;
         long var10002 = 3226402944576859926L ^ var2;
         byte var16 = 8;
         int var15 = var5;
         if (var15 > var16) {
            break;
         }

         MinecraftClient var7 = b;
         ClientPlayerEntity var8 = var7.player;
         PlayerInventory var22 = var8.getInventory();
         int var10 = var5;
         PlayerInventory var9 = var22;
         ItemStack var6 = var9.getStack(var10);
         int var17 = var4;
         if (var17 != 0) {
            ItemStack var11 = var6;
            Item var23 = var11.getItem();
            Block var12 = var1;
            Item var19 = var12.asItem();
            Item var18 = var23;
            if (var18 == var19) {
               int var14 = var5;
               return var14;
            }

            var5++;
         }

         var20 = var4;
      } while (var20 != 0);

      return null;
   }

   public static List aReturningList(Object[] var0) {
      Item var4;
      int var5;
      ArrayList var6;
      byte var19;
      long var29;
      label29: {
         var4 = (Item)var0[0];
         byte var1 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var0[1]))))))))) ? 1 : 0);
         var29 = (Long)var0[2];
         var29 = 12128752710147L ^ var29;
         int var10000 = Event.cReturningInt();
         var6 = new ArrayList();
         var5 = var10000;
         int var21 = var5;
         byte var20 = var1;
         byte var18 = var20;
         byte var17 = var20;
         if (var21 != 0) {
            byte var22 = var17;
            if (var22 == 0) {
               short var30 = 20216;
               long var10001 = 6330063332014576722L ^ var29;
               var19 = 9;
               break label29;
            }

            var18 = 0;
         }

         byte var23 = var18;
         var19 = var23;
      }

      int var7 = var19;

      int var28;
      do {
         short var33 = 647;
         long var10002 = 4515966829726210089L ^ var29;
         byte var25 = 35;
         int var24 = var7;
         if (var24 > var25) {
            break;
         }

         MinecraftClient var9 = b;
         ClientPlayerEntity var10 = var9.player;
         PlayerInventory var31 = var10.getInventory();
         int var12 = var7;
         PlayerInventory var11 = var31;
         ItemStack var13 = var11.getStack(var12);
         Item var32 = var13.getItem();
         Item var27 = var4;
         Item var26 = var32;
         if (var26 == var27) {
            int var14 = var7;
            Integer var16 = var14;
            ArrayList var15 = var6;
            var15.add(var16);
         }

         var7++;
         var28 = var5;
      } while (var28 != 0);

      return var6;
   }

   public static List bReturningList(Object[] var0) {
      Item var4;
      int var5;
      ArrayList var6;
      byte var19;
      long var29;
      label29: {
         var4 = (Item)var0[0];
         byte var1 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var0[1]))))))))) ? 1 : 0);
         var29 = (Long)var0[2];
         var29 = 12128752710147L ^ var29;
         int var10000 = Event.bReturningInt();
         var6 = new ArrayList();
         var5 = var10000;
         int var21 = var5;
         byte var20 = var1;
         byte var18 = var20;
         byte var17 = var20;
         if (var21 == 0) {
            byte var22 = var17;
            if (var22 == 0) {
               short var30 = 21396;
               long var10001 = 5972512514037968459L ^ var29;
               var19 = 9;
               break label29;
            }

            var18 = 0;
         }

         byte var23 = var18;
         var19 = var23;
      }

      int var7 = var19;

      int var28;
      do {
         short var33 = 10431;
         long var10002 = 3890440535364769122L ^ var29;
         byte var25 = 35;
         int var24 = var7;
         if (var24 > var25) {
            break;
         }

         MinecraftClient var9 = b;
         ClientPlayerEntity var10 = var9.player;
         PlayerInventory var31 = var10.getInventory();
         int var12 = var7;
         PlayerInventory var11 = var31;
         ItemStack var13 = var11.getStack(var12);
         Item var32 = var13.getItem();
         Item var27 = var4;
         Item var26 = var32;
         if (var26 == var27) {
            int var14 = var7;
            Integer var16 = var14;
            ArrayList var15 = var6;
            var15.add(var16);
         }

         var7++;
         var28 = var5;
      } while (var28 == 0);

      return var6;
   }

   public static boolean lReturningBoolean(Object[] var0) {
      Item var1 = (Item)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var2;
      MinecraftClient var4 = b;
      ClientPlayerEntity var5 = var4.player;
      ItemStack var6 = var5.getMainHandStack();
      Item var11 = var6.getItem();
      Item var9 = var1;
      Item var8 = var11;
      byte var7;
      if (var8 == var9) {
         byte var10 = 1;
         var7 = var10;
      } else {
         var7 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   public static Item aReturningItem(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 12128752710147L ^ var1;
      MinecraftClient var3 = b;
      ClientPlayerEntity var4 = var3.player;
      ItemStack var5 = var4.getMainHandStack();
      return var5.getItem();
   }

   public static boolean mReturningBoolean(Object[] var0) {
      Item var1 = (Item)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var2;
      MinecraftClient var4 = b;
      ClientPlayerEntity var5 = var4.player;
      ItemStack var6 = var5.getOffHandStack();
      Item var11 = var6.getItem();
      Item var9 = var1;
      Item var8 = var11;
      byte var7;
      if (var8 == var9) {
         byte var10 = 1;
         var7 = var10;
      } else {
         var7 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   public static int aReturningInt(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 12128752710147L ^ var1;
      MinecraftClient var3 = b;
      ClientPlayerEntity var4 = var3.player;
      PlayerInventory var5 = var4.getInventory();
      return var5.getSelectedSlot();
   }

   public static Integer eReturningBoxedInteger(Object[] var0) {
      int var1 = (Integer)var0[0];
      int var4 = (Integer)var0[1];
      RegistryEntry var5 = (RegistryEntry)var0[2];
      long var2 = (Long)var0[3];
      var2 = 12128752710147L ^ var2;
      long var6 = var2 ^ 64460093372635L;
      int var10000 = Event.bReturningInt();
      int var9 = var1;
      int var8 = var10000;

      int var26;
      label43: {
         while (true) {
            int var28 = var4;
            int var27 = var9;
            if (var27 >= var28) {
               break;
            }

            label39: {
               label48: {
                  MinecraftClient var11 = b;
                  ClientPlayerEntity var12 = var11.player;
                  PlayerInventory var41 = var12.getInventory();
                  int var14 = var9;
                  PlayerInventory var13 = var41;
                  ItemStack var10 = var13.getStack(var14);
                  ItemStack var15 = var10;
                  Item var42 = var15.getItem();
                  Item var30 = Items.SPLASH_POTION;
                  Item var29 = var42;
                  if (var29 != var30) {
                     int var31 = var8;
                     if (var31 == 0) {
                        break label48;
                     }
                  }

                  RegistryEntry var32 = var5;
                  if (var32 == null) {
                     break label39;
                  }

                  Object[] var18 = new Object[]{var10, var5, var6};
                  byte var43 = ((byte)((nReturningBoolean(var18)) ? 1 : 0));
                  int var34 = var8;
                  byte var33 = var43;
                  var26 = var33;
                  byte var24 = var33;
                  if (var34 != 0) {
                     break label43;
                  }

                  byte var35 = var24;
                  byte var25 = var35;
                  byte var36 = var25;
                  if (var36 != 0) {
                     break label39;
                  }

                  int var37 = var8;
                  if (var37 != 0) {
                     break label39;
                  }
               }

               var9++;
               int var39 = var8;
               if (var39 == 0) {
                  continue;
               }
               break;
            }

            int var38 = var9;
            var26 = var38;
            break label43;
         }

         return null;
      }

      int var23 = var26;
      return var23;
   }

   public static boolean nReturningBoolean(Object[] var0) {
      ItemStack var1 = (ItemStack)var0[0];
      RegistryEntry var2 = (RegistryEntry)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 12128752710147L ^ var3;
      int var20 = Event.bReturningInt();
      byte var6 = 0;
      int var5 = var20;
      ComponentType var10 = DataComponentTypes.POTION_CONTENTS;
      ItemStack var9 = var1;
      PotionContentsComponent var11 = (PotionContentsComponent)var9.get(var10);
      Iterable var12 = var11.getEffects();
      Iterator var7 = var12.iterator();

      int var19;
      do {
         Iterator var13 = var7;
         boolean var16 = var13.hasNext();
         if (!var16) {
            break;
         }

         Iterator var14 = var7;
         StatusEffectInstance var8 = (StatusEffectInstance)var14.next();
         StatusEffectInstance var15 = var8;
         RegistryEntry var21 = var15.getEffectType();
         RegistryEntry var18 = var2;
         RegistryEntry var17 = var21;
         if (var17 == var18) {
            var6 = 1;
         }

         var19 = var5;
      } while (var19 == 0);

      return dev.prestige.recovery.SourceSupport.asBoolean(var6);
   }

   public static boolean o(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var1;
      ItemStack var4 = var3;
      Item var7 = var4.getItem();
      Item var6 = Items.MACE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   public static boolean p(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 12128752710147L ^ var1;
      ItemStack var4 = var3;
      Item var7 = var4.getItem();
      Item var6 = Items.WIND_CHARGE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(47616947021963L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[6];
      String var6 = "'yPs\"EåGÛÃhgí\u009a\u009dFçÓÅë-6Ä-«)°,A\u009d\fü";
      int var7 = "'yPs\"EåGÛÃhgí\u009a\u009dFçÓÅë-6Ä-«)°,A\u009d\fü".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     c = var8;
                     d = new Integer[6];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "\u0013\u0014\u0007\"\u0019\u0099\u0080[f´\r§\u000b7<¯";
                  var7 = "\u0013\u0014\u0007\"\u0019\u0099\u0080[f´\r§\u000b7<¯".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1938;
      if (d[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])e.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/co", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         d[var3] = var15;
      }

      return d[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/co_C0140",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/co" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 13;
            yield var15;
         }
         case 1 -> {
            byte var16 = 60;
            yield var16;
         }
         case 2 -> {
            byte var17 = 25;
            yield var17;
         }
         case 3 -> {
            byte var18 = 24;
            yield var18;
         }
         case 4 -> {
            byte var19 = 39;
            yield var19;
         }
         case 5 -> {
            byte var20 = 45;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 40;
            yield var22;
         }
         case 8 -> {
            byte var23 = 47;
            yield var23;
         }
         case 9 -> {
            byte var24 = 52;
            yield var24;
         }
         case 10 -> {
            byte var25 = 15;
            yield var25;
         }
         case 11 -> {
            byte var26 = 61;
            yield var26;
         }
         case 12 -> {
            byte var27 = 0;
            yield var27;
         }
         case 13 -> {
            byte var28 = 54;
            yield var28;
         }
         case 14 -> {
            byte var29 = 51;
            yield var29;
         }
         case 15 -> {
            byte var30 = 48;
            yield var30;
         }
         case 16 -> {
            byte var31 = 21;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 43;
            yield var33;
         }
         case 19 -> {
            byte var34 = 20;
            yield var34;
         }
         case 20 -> {
            byte var35 = 58;
            yield var35;
         }
         case 21 -> {
            byte var36 = 12;
            yield var36;
         }
         case 22 -> {
            byte var37 = 46;
            yield var37;
         }
         case 23 -> {
            byte var38 = 53;
            yield var38;
         }
         case 24 -> {
            byte var39 = 28;
            yield var39;
         }
         case 25 -> {
            byte var40 = 14;
            yield var40;
         }
         case 26 -> {
            byte var41 = 27;
            yield var41;
         }
         case 27 -> {
            byte var42 = 32;
            yield var42;
         }
         case 28 -> {
            byte var43 = 44;
            yield var43;
         }
         case 29 -> {
            byte var44 = 7;
            yield var44;
         }
         case 30 -> {
            byte var45 = 59;
            yield var45;
         }
         case 31 -> {
            byte var46 = 49;
            yield var46;
         }
         case 32 -> {
            byte var47 = 2;
            yield var47;
         }
         case 33 -> {
            byte var48 = 57;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 30;
            yield var50;
         }
         case 36 -> {
            byte var51 = 38;
            yield var51;
         }
         case 37 -> {
            byte var52 = 22;
            yield var52;
         }
         case 38 -> {
            byte var53 = 50;
            yield var53;
         }
         case 39 -> {
            byte var54 = 26;
            yield var54;
         }
         case 40 -> {
            byte var55 = 5;
            yield var55;
         }
         case 41 -> {
            byte var56 = 55;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 17;
            yield var58;
         }
         case 44 -> {
            byte var59 = 4;
            yield var59;
         }
         case 45 -> {
            byte var60 = 10;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 19;
            yield var63;
         }
         case 49 -> {
            byte var64 = 33;
            yield var64;
         }
         case 50 -> {
            byte var65 = 42;
            yield var65;
         }
         case 51 -> {
            byte var66 = 31;
            yield var66;
         }
         case 52 -> {
            byte var67 = 18;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 36;
            yield var69;
         }
         case 55 -> {
            byte var70 = 3;
            yield var70;
         }
         case 56 -> {
            byte var71 = 23;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 16;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 11;
            yield var75;
         }
         case 61 -> {
            byte var76 = 41;
            yield var76;
         }
         case 62 -> {
            byte var77 = 62;
            yield var77;
         }
         default -> 35;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "\u001d}OQu^\u000b}J\u000bfI\u001c6I\rj]\rq^\u001a!M\u0016";
      f[1] = "F\u000e\u0018uZh3.\u0013zK'R \u0018qO}&";
      f[2] = boolean.class;
      g[2] = "java/lang/Boolean";
      f[3] = ":\u0019c\u0017\u0005b:\u0019tK\tm RtU\tx'#%\u000b\\3";
      f[4] = "\rc\u000ef\u0007f\rc\u0019:\u000bi\u0017(\u0019$\u000b|\u0010YK\u007fS=";
      f[5] = "\u0017CCz\u0013\u0005\u001cLR5t\u0007\tGR~O";
      f[6] = int.class;
      g[6] = "java/lang/Integer";
      f[7] = "xe\u0019HR\u000f\rE\u0012GC@lK\u0019LG\u001a\u0018";
      f[8] = "R9#<YbR94`UmHr4~UxO\u0003`&\u0002";
      f[9] = "G|\u0012~wMG|\u0005\"{B]7\u0005<{WZFWf,\u0015";
      f[10] = "M<\r0GQ[<\bjTFLw\u000blXR]0\u001c{\u0013@l";
      f[11] = "D\u001dl4W\u0012D\u001d{h[\u001d^V{v[\bY')-\u0003B";
      f[12] = "\u001d\u000bu\u000b`o\u0016\u0004dD\u0003b\u0003\tk/6`\u0012\u001aw\u0003!m";
      f[13] = " \u00181\u0017\u001bo \u0018&K\u0017`:S&U\u0017u=\"v\bF";
      f[14] = void.class;
      g[14] = "java/lang/Void";
      f[15] = "Pyr\u001e\"\u0007PyeB.\bJ2e\\.\u001dMC7\b\u007f\\";
      f[16] = "\u0010,lH\nl\u0010,{\u0014\u0006c\ng{\n\u0006v\r\u0016!UT4";
      f[17] = "4w~\u007f/D?xo0NJ4skj";
      f[18] = "\u001c#\r\u0002#D\u0017,\u001cMD\\\u00130\u001a\u0001aM";
      f[19] = "]scT#\u001aC{y\u001bD\u001bR`tAb\u001d";
      f[20] = "mf\u0000\u0015z\u000bmf\u0017Iv\u0004w-\u0017Wv\u0011p\\E\t.Q";
      f[21] = "/z\u0015?zz/z\u0002cvu51\u0002}v`2@W)/#";
      f[22] = "\u001cq\u001cBtY\u001cq\u000b\u001exV\u0006:\u000b\u0000xC\u0001KQ_*\u0004";
      f[23] = "s\u0019\rYf$s\u0019\u001a\u0005j+iR\u001a\u001bj>n#HO?y";
      f[24] = "Y\u00113525,18:#zM?31' 9";
      f[25] = ">\th\u0007FBK)c\bW\r*'h\u0003SW^";
      f[26] = "}\u0004(\u0001V\u001f\b$#\u000eGPi*(\u0005C\n\u001d";
      f[27] = "<,X_Oi\"$B\u0010-u%9";
      f[28] = "F eKp F r\u0017|/\\kr\t|:[\u001a'V+";
      f[29] = "^0{q9{^0l-5tD{l35aC\n>he!";
      f[30] = "hl5{~{hl\"'rtr'\"9rauVpc&%";
      f[31] = "\u0014Q-\u0018rw\u0014Q:D~x\u000e\u001a:Z~m\tkh\u0001/-";
      f[32] = "1N.\u0017\u000bSDn%\u0018\u001a\u001c%`.\u0013\u001eFQ";
      f[33] = "R79[NzD7<\u0001]mS|?\u0007QyB;(\u0010\u001aiZ;*\u001b@$f *\u0006@cQ7";
      f[34] = "_ADe\u0016\u0004IAA?\u0005\u0013^\nB9\t\u0007OMU.B\u0016m";
      f[35] = "=F4W\u0000\\=F#\u000b\fS'\r#\u0015\fF |tJZ";
      f[36] = "\u001a|]\u0001I-o\\V\u000eXb\u000eR]\u0005\\8z";
      f[37] = "\u0017M9bsa\u0001M<8`v\u0016\u0006?>lb\u0007A()'a";
      f[38] = "$o\u0019\u001bl'QO\u0012\u0014}h0A\u0019\u001fy2D";
      f[39] = "e\u0012\u0015:+^\u00102\u001e5:\u0011q<\u0015>>K\u0005";
      f[40] = "\rw\u0001**U\u0006x\u0010eVL\tx\u0016)h\\";
      f[41] = "b\u0001:{W`b\u0001-'[oxJ-9[z\u007f;zl\n";
      f[42] = "\u0018#='oj\u0018#*{ce\u0002h*ecp\u0005\u0019x>00";
      f[43] = "s\u0014& d\u0000\u00064-/uOg:&$q\u0015\u0013";
      f[44] = "i\u0005\u001du\u0015M<\u0018\u0010;kL;\u000b\u001b-\u0007~kGE{W)<\u001a\u001b%WS&\u001c\u0011:kBoK\u00031\u0005Km\u001c\u0018J";
      f[45] = "O\u000b\\_\n!HJ\u001d\u001cn9Y\u000b\u0005@\u0002\u000b\rHX\u0018Q\\P\u000b\u0015\\\u0014'F\u000e\u0014Kn";
      f[46] = "bO^}iG5VM\"\u0018D2PQ&tvd\u0015\f}(!aMN?(F<GP(\u0018";
      f[47] = "\u0012Nf^0\u0007\u0007MjSPP\u001aB`T\u0007\u0004A\u0017>\u0004P\u0005G@tJ.R\u0000Me";
      f[48] = "_\t\u0014D\u0003XJ\n\u0018Ic\u000fW\u0005\u0012N4Q\rWI\"X]Y\u0018\u0004\\\u000f\u001aT\t";
      f[49] = ";\fP%/3.\u000f\\(Od3\u0000V/\u0018:iR\u000bCt6=\u001d@=#q0\f";
      f[50] = "igD4\u0006\u000b!%C7m]94D$:\ngd\u001dH\nS'#B2\u0015Sb+";
      f[51] = "/\u00123\f)\u000f9\u00172\u001bS\u001a*\u0003'\u001b\u0004KtPxwo\u0019.\u001f2\u001cj\u001bv\r";
      f[52] = "\u001a\u000e\u00188e.\u000f\r\u00145\u0005y\u0012\u0002\u001e2R'HPB^>+\u001c\u001f\b il\u0011\u000e";
      f[53] = "=p\u0003[zs(s\u000fV\u001a$5|\u0005QMzi.^=!v;a\u0013Cv16p";
      f[54] = "G\u0013\u001c^/UR\u0010\u0010SO\u0002O\u001f\u001aT\u0018\\\u0012K@8tPA\u0002\fF#\u0017L\u0013";
      f[55] = "\u0006\u0016\u0013\u0018\u0006\bD\u0003H\u0014dU[\u001b}L\u0000IPg\u001fH\u0001EL\f\u001aJYW=";
      f[56] = "!\u007f)5_}$}x\u007f!q r8EJ.qz?+C,&aD";
      f[57] = "F\t\u007fNd\u000bS\nsC\u0004\\N\u0005yDS\u0002\u0015Q-(?\u000e@\u0018oVhIM\t";
      f[58] = "\u0007At7\u0001m\u0012Bx:a:\u000fMr=6dS\u001f.QZh\u0001Pd/\r/\fA";
      f[59] = "=:x\u0011\u0006*48/\n})/~-\r\u0006D=:x\u0011\u0006*48/\n}}->5P\u0001;ke6i";
      f[60] = "lRC.k;yQO#\u000bld^E$\\8?\u000b\u001by\u000b99\\Q:un~Q@";
      f[61] = "\u0001u1\u001aU\t\u0014v=\u00175^\ty7\u0010b\u0000R$h|\u000e\f\u0007d!\u0002YK\nu";
      f[62] = "-FW&v\u00068E[+\u0016Q%JQ,A\u000fz\u0018\u0005@-\u0003+WG>zD&F";
      f[63] = "KP:-S\u0013\u0019Kd9.LDT`(y\u001e\u0014\u00079}.HHYkxTRNSt";
      f[64] = "W++EaDB('H\u0001\u0013_'-OVM\u0001wr#:AQ:;]m\u0006\\+";
      f[65] = "Cb\u0017E{sVa\u001bH\u001b$Kn\u0011OLz\u001a<N# vEs\u0007]w1Hb";
      f[66] = "X'\u0011\u0019o6M$\u001d\u0014\u000faP+\u0017\u0013X?\nvL\u007f43^6\u0001\u0001ctS'";
      f[67] = "K\u001fB\u0019Q\u0017NAK\bl\u0000-BDP\u0007\r\u0011_K\u001b\r";
      f[68] = ":a).>\u001d,y7V(--b1o.Q2}9iA\u0016  n4}T5{bV";
      f[69] = "B41'1WW7=*Q\u0000J87-\u0006^\u0013kiAjRD%!?=\u0015I4";
      f[70] = "kbZm:\n~aV`Z]cn\\g\r\u0003<=\u0000\u000ba\u000fmsJu6H`b";
      f[71] = "tWg!\u000ef)]y6>d'Jx8RVt\u000f$n\u0000\u0001v[}.OjsY%<>01[)3[h/Ut_";
      f[72] = "?\"<9e&):\"Ap\u0016(!$xuj7>,~\u001a'/>w-\u007f\u007f10*A";
      f[73] = "\t6v\r\u0003e\u001c5z\u0000c2\u0001:p\u00074fZo.Tcg\\8d\u0019\u001d0\u001b5u";
      f[74] = "@9T\u0015\n(\u001d3J\u0002:*\u0013$K\fV\u0018Cd\u0010[:s\u0013=Z\u001aQv\u0011eHk\u0005=\u0018gU\u000fP \u0015)+";
      f[75] = "7A{jq{%]f7Ok*Oag\u0018:t\u001c>\u000bsh.St`vjvA";
      f[76] = "AWBK\u007f\u007f\u0016NQ\u0014\u000e|\u0011HM\u0010bNB\f\u0012F\u000e&\u000eR\u0012\tjs\u0013_\\w";
      f[77] = "1~JvaY$}F{\u0001\u000e9rL|VPd'\u0013\u0010:\\7oZnm\u001b:~";
      f[78] = "L}$fk$Y~(k\u000bsDq\"l\\-\u001b y\u00000!Jl4~gfG}";
      f[79] = "^\\P?\u001b}K_\\2{*VPV5,t\u000f\u0000\u0002Y@xXM@'\u0017?U\\";
      f[80] = "f\u000b{,*\u0011p\u0013eT5!q\bcm:]n\u0017kkU\u0018vGpm)^0\u001csT";
      f[81] = "AJEtv\u0012\\E\u000e~\u0006G'I\u000e}?A[V\u0011u9._R\u001bvvNDK\u0001!\u0006";
      f[82] = "fEhOX2p]v7J\u0002qFp\u000eH~nYx\b';v\tc\u000e[}0R`7";
      f[83] = "\\c\u001eAT3I`\u0012L4dTo\u0018Kc:\u00058A'\u000f6Zr\u000eYXqWc";
      f[84] = "\n\u0018\u001az^0\u001f\u001b\u0016w>g\u0002\u0014\u001cpi9SAB\u001c\u00055\f\t\nbRr\u0001\u0018";
      f[85] = "hf2Gy\\}e>J\u0019\u000b`j4MN_;?j\u001c\u0019^=h Sg\tze1";
      f[86] = "P|\u0004\u0002\u001ddE\u007f\b\u000f}3Xp\u0002\b*m\t![dFaVm\u0014\u001a\u0011&[|";
      f[87] = "QA{H)\u001a\nF:\u001eP\u0014nD(\u0012!\u000f\u0005A*J3~";
      f[88] = "\u0019\u001dC\u0003?\t\f\u001eO\u000e_^\u0011\u0011E\t\b\u0000MA\u001fed\f\u001f\fS\u001b3K\u0012\u001d";
      f[89] = "h&[.v\u0016}%W#\u0016A`*]$A\u0015;\u007f\u0003r\u0016\u0014=(I:hCz%X";
      f[90] = "r<#KsE:~$H\u0018\u0013\"o#[OD|<~7z\u0013yz(Q&\u0007z8";
      f[91] = "\u001a_.\u000f\u0010SOB#AnRHQ(W\u0002`\u001a\u001cp\u0001n\f\u0019B8B\u0010[^O)0";
      f[92] = "WO\\\u0019~4AWBah\u0004@LDXnx_SL^\u00015GS\u0017\rdmY]Ja";
      f[93] = "\u0018.H\u0017\u00026\r-D\u001aba\u0010\"N\u001d5?Jt\u0017qY3\u001e?X\u000f\u000et\u0013.";
      f[94] = "R\u001f\u0010g[BD\u0007\u000e\u001fBrE\u001c\b&K\u000eZ\u0003\u0000 $KBS\u001b&X\r\u0004\b\u0018\u001f";
      f[95] = "75Y/}Jj?G8MHd(F6!z7k\u001bjw-59C <F0;\u001b2M";
      f[96] = "=\u000fk(H@f\b*~1O\u0002\n8r@Ui\u000f:*R$";
      f[97] = "'g\u001f7M\u001ao%\u00184&Lw4\u001f'q\u001b)cGK\u001bAye\n-LXj:";
      f[98] = "K\u0000\u001e~\n\\^\u0003\u0012sj\u000bC\f\u0018t=U\u0012_F\u0018QYM\u0011\u000ef\u0006\u001e@\u0000";
      f[99] = "7\u001b~\u000fT\"!\u0003`wI\u0012 \u0018fNDn?\u0007nH++'WuNWma\fvw";
      f[100] = "\u001b\u0003YO<\b\u000e\u0000UB\\_\u0013\u000f_E\u000b\u0001HR\u0006)g\r\u001d\u0012IW0J\u0010\u0003";
      f[101] = "k|<,$-~\u007f0!Dzcp:&\u0013$9$eJ\u007f(mm,4(o`|";
      f[102] = "Y[2j* LX>gJwQW4`\u001d#\n\u0002j<J\"\fU ~4uKX1";
      f[103] = "]<7\u0006\u0002%H?;\u000bbrU01\f5,\tge`Y [-'\u001e\u000egV<";
      f[104] = "~\u000f6f[Uh\u0017(\u001eMei\f.'K\u0019v\u0013&!$Yx\u001b=oO\\zC/\u001e";
      f[105] = "M\u0017FPTyL\u0010U\t*mJ\n8QQz\u0006\u0000]\tOt[l";
      f[106] = "S7GNuFF4KC\u0015\u0011[;ADBO\u0001j\u0015(.CU&WVy\u0004X7";
      f[107] = "{b\u0016q#B~`G;]H~d=l-T\u0017&\u0000<,\u0011k`Fg/(";
      f[108] = "\u000f;\u0004e\u0013u\u001a8\bhs\"\u00077\u0002o$|Yf]\u0003Hp\t*\u0014}\u001f7\u0004;";
      f[109] = "yB\u0000|cHz\u0015\u00014\t\u0011.Y\u001ebe#s\u001eN4\tO\u007fJ\u000eww\u00188G\u001f\u0005";
      f[110] = "w1}RL_b2q_,\b\u007f={X{V#j$4\u0017Zq mJ@\u001d|1";
      f[111] = "&]\u0012a\u007f\u001cdHIm\u001d^tH_1ZN\u001d\u0010O9lQv\u0015Ma~ &]\u0012a\u007f\u001cdHIm\u001d";
      f[112] = "\u001f4STA}\n7_Y!*\u00178U^vtOk\u000b2\u001ax\u0019%CLM?\u00144";
      f[113] = "O\u0007\u00116a:Y\u001f\u000fNy\nX\u0004\twqvG\u001b\u0001q\u001e3_K\u001awbu\u0019\u0010\u0019N";
      f[114] = "\u0011{\u0004(\u001fW\u0004x\b%\u007f\u0000\u0019w\u0002\"(^H!]NDR\u0017j\u00140\u0013\u0015\u001a{";
      f[115] = "NE5j(k\u001bZroPwYJsf,q_'er=f[M`pl,%";
      f[116] = "3+l9\u001d\u0005d2\u007ffl\u0006c4cb\u000040p?:l\\|.<{\b\ta#r\u0005";
      f[117] = "\u000fk4N4uS\u007f7\f[v\u0000ynQ7DW46\b[/\u0000`\u007fG0*\u00028m6g~\bt\u007f]b|Pf\u000e\n6v\u001cte\u000f4.\u000e\u0005mO;n\u0017u|Sgoma5Sf,R>6\b8\u0013\\~c\u00077v\u0004`mZ[";
      f[118] = "[&\"^J\u0006N%.S*QS*$T}\u000f\u0002\u007f}8\u0011\u0003]72FFDP&";
      f[119] = "R?5\u0010[;G<9\u001d;lZ33\u001al2\u0001`hv\u0000>T.%\bWyY?";
      f[120] = "\u00109\u0015ve'\u0005:\u0019{\u0005p\u00185\u0013|R\"H`F \u0005%E7\u0007b{r\u0002:\u0016";
      f[121] = "?@Ec>2*CIn^e7LCi\t;j\u001a\u0019\u0005e79QU{2p4@";
      f[122] = "[\u0016H.\u0000jZ\u000f\fu:cV\u00032!\u00036B\u0014\\(\u0001aYo\u000b1\u0007{\u0003\u0013Mw\\x:";
      f[123] = "(]o8Z>=^c5:i Qi2m={\u00046f:<}S},Dk:^l";
      f[124] = "ss!cl\b$j2<\u001d\u0000/}*3JQs)t_y\u0012>k4$o\u0017?|";
      f[125] = "\u0010\u000f2\bRg\u0005\f>\u000520\u0018\u00034\u0002enA_hn\tb\u0016\u001e\"\u0010^%\u001b\u000f";
      f[126] = "\u001c\u000eyL\f5\t\ruAlb\u0014\u0002\u007fF;<IP&*W0\u001a\u001fiT\u0000w\u0017\u000e";
      f[127] = "\u0019\u0000\u0016\f|O\f\u0003\u001a\u0001\u001c\u0018\u0011\f\u0010\u0006KFHPMj'J\u001f\u0011\u0006\u0014p\r\u0012\u0000";
      f[128] = "R\u000e&\u001fY\u0012D\u00168gO\"\t\u0013=V@GV\u0007`\u0019&\u0012U\u001em\u0001CMAC\"g";
      f[129] = "[%K\"vRJ9\u0017#\fLY1O3[\u001d\u0007m\u0012_o[X!Q/~G\u0004 ";
      f[130] = "/QM~#&9\u001f\u0002g\u001b|/\u0012\\xwN\u007fS\u0003.\u001bt%_\fdah)\u001c]\u001f";
      f[131] = "\\|:O\u001e0I\u007f6B~gTp<E)9\t%f)E5Zm*W\u0012rW|";
      f[132] = "d\u0000\u00071\u001bM6ZD\"'Rf\u001d\u001b,K`6^@z\u00187`\u0003G._J5\u001c\u0000+'";
      f[133] = "!a{x\u0000\u00194bwu`N)m}r7\u001cy0 \"`\u001btoil\u001eL3bx";
      f[134] = "<}ram^)~~l\r\t4qtkZWn-.\u00076[:lbya\u001c7}";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1221910185281204L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1221910185281204L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1221910185281204L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 236;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 238;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 225;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 222;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 246;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 71;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 236;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 238;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 225;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/co_C0140",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/co" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = b(MethodHandles.lookup(), "G", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Item invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding3(long var0, long var2) {
         MethodHandle var8 = bindingCache3;
         MethodHandle var7 = bindingCache3;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache3 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding6(long var0, long var2) {
         MethodHandle var8 = bindingCache6;
         MethodHandle var7 = bindingCache6;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache6 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding10(long var0, long var2) {
         MethodHandle var8 = bindingCache10;
         MethodHandle var7 = bindingCache10;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache10 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding18(long var0, long var2) {
         MethodHandle var8 = bindingCache18;
         MethodHandle var7 = bindingCache18;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache18 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding22(long var0, long var2) {
         MethodHandle var8 = bindingCache22;
         MethodHandle var7 = bindingCache22;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache22 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding26(long var0, long var2) {
         MethodHandle var8 = bindingCache26;
         MethodHandle var7 = bindingCache26;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache26 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding30(long var0, long var2) {
         MethodHandle var8 = bindingCache30;
         MethodHandle var7 = bindingCache30;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache30 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding34(long var0, long var2) {
         MethodHandle var8 = bindingCache34;
         MethodHandle var7 = bindingCache34;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache34 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding35(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding38(long var0, long var2) {
         MethodHandle var8 = bindingCache38;
         MethodHandle var7 = bindingCache38;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache38 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding42(long var0, long var2) {
         MethodHandle var8 = bindingCache42;
         MethodHandle var7 = bindingCache42;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache42 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding45(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache45;
         MethodHandle var8 = bindingCache45;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache45 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding46(long var0, long var2) {
         MethodHandle var8 = bindingCache46;
         MethodHandle var7 = bindingCache46;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache46 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding48(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding50(long var0, long var2) {
         MethodHandle var8 = bindingCache50;
         MethodHandle var7 = bindingCache50;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache50 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding51(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache51;
         MethodHandle var8 = bindingCache51;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache51 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding52(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache52;
         MethodHandle var8 = bindingCache52;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache52 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding53(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache53;
         MethodHandle var8 = bindingCache53;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache53 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding54(long var0, long var2) {
         MethodHandle var8 = bindingCache54;
         MethodHandle var7 = bindingCache54;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache54 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding55(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache55;
         MethodHandle var8 = bindingCache55;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache55 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding56(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache56;
         MethodHandle var8 = bindingCache56;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache56 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding57(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache57;
         MethodHandle var8 = bindingCache57;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache57 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding58(long var0, long var2) {
         MethodHandle var8 = bindingCache58;
         MethodHandle var7 = bindingCache58;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache58 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding59(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache59;
         MethodHandle var8 = bindingCache59;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache59 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding60(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache60;
         MethodHandle var8 = bindingCache60;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache60 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding61(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache61;
         MethodHandle var8 = bindingCache61;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache61 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding62(long var0, long var2) {
         MethodHandle var8 = bindingCache62;
         MethodHandle var7 = bindingCache62;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache62 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding63(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache63;
         MethodHandle var8 = bindingCache63;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache63 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding64(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache64;
         MethodHandle var8 = bindingCache64;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache64 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding65(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache65;
         MethodHandle var8 = bindingCache65;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache65 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding66(long var0, long var2) {
         MethodHandle var8 = bindingCache66;
         MethodHandle var7 = bindingCache66;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache66 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding67(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache67;
         MethodHandle var8 = bindingCache67;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache67 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding68(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache68;
         MethodHandle var8 = bindingCache68;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache68 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding69(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache69;
         MethodHandle var8 = bindingCache69;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache69 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding70(long var0, long var2) {
         MethodHandle var8 = bindingCache70;
         MethodHandle var7 = bindingCache70;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache70 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding71(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache71;
         MethodHandle var8 = bindingCache71;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache71 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding72(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache72;
         MethodHandle var8 = bindingCache72;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache72 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding73(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache73;
         MethodHandle var8 = bindingCache73;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache73 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding74(long var0, long var2) {
         MethodHandle var8 = bindingCache74;
         MethodHandle var7 = bindingCache74;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache74 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding75(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache75;
         MethodHandle var8 = bindingCache75;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache75 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding76(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache76;
         MethodHandle var8 = bindingCache76;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache76 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding78(long var0, long var2) {
         MethodHandle var8 = bindingCache78;
         MethodHandle var7 = bindingCache78;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache78 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding79(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache79;
         MethodHandle var8 = bindingCache79;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache79 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding80(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache80;
         MethodHandle var8 = bindingCache80;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache80 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding81(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache81;
         MethodHandle var8 = bindingCache81;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache81 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding82(long var0, long var2) {
         MethodHandle var8 = bindingCache82;
         MethodHandle var7 = bindingCache82;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache82 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding83(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache83;
         MethodHandle var8 = bindingCache83;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache83 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding84(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache84;
         MethodHandle var8 = bindingCache84;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache84 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding85(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache85;
         MethodHandle var8 = bindingCache85;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache85 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding86(long var0, long var2) {
         MethodHandle var8 = bindingCache86;
         MethodHandle var7 = bindingCache86;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache86 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding87(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache87;
         MethodHandle var8 = bindingCache87;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache87 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding88(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache88;
         MethodHandle var8 = bindingCache88;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache88 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding89(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache89;
         MethodHandle var8 = bindingCache89;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache89 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding90(long var0, long var2) {
         MethodHandle var8 = bindingCache90;
         MethodHandle var7 = bindingCache90;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache90 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding91(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache91;
         MethodHandle var8 = bindingCache91;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache91 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding92(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache92;
         MethodHandle var8 = bindingCache92;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache92 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding93(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache93;
         MethodHandle var8 = bindingCache93;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache93 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding94(long var0, long var2) {
         MethodHandle var8 = bindingCache94;
         MethodHandle var7 = bindingCache94;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache94 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding95(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache95;
         MethodHandle var8 = bindingCache95;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache95 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding96(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache96;
         MethodHandle var8 = bindingCache96;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache96 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding97(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache97;
         MethodHandle var8 = bindingCache97;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache97 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding98(long var0, long var2) {
         MethodHandle var8 = bindingCache98;
         MethodHandle var7 = bindingCache98;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache98 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding99(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache99;
         MethodHandle var8 = bindingCache99;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache99 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding100(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache100;
         MethodHandle var8 = bindingCache100;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache100 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding101(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache101;
         MethodHandle var8 = bindingCache101;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache101 = b(
                  MethodHandles.lookup(), "ö", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding102(long var0, long var2) {
         MethodHandle var8 = bindingCache102;
         MethodHandle var7 = bindingCache102;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache102 = b(MethodHandles.lookup(), "á", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding103(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache103;
         MethodHandle var8 = bindingCache103;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache103 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding104(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache104;
         MethodHandle var8 = bindingCache104;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache104 = b(
                  MethodHandles.lookup(), "G", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
