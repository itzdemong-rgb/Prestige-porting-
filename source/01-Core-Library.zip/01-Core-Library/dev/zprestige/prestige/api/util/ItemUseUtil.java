package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.client.management.RotationManager;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public class ItemUseUtil implements MinecraftAccess {
   private static final long a = 6177900224927L;
   private static final Object[] c = new Object[58];
   private static final String[] d = new String[58];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public static boolean aReturningBoolean(Object[] var0) {
      BlockHitResult var3 = (BlockHitResult)var0[0];
      long var1 = (Long)var0[1];
      var1 = 6177900224927L ^ var1;
      long var4 = var1 ^ 127204794810356L;
      Object[] var6 = new Object[]{var3, Hand.MAIN_HAND, var4};
      return bReturningBoolean(var6);
   }

   public static boolean bReturningBoolean(Object[] var0) {
      BlockHitResult var4 = (BlockHitResult)var0[0];
      Hand var1 = (Hand)var0[1];
      long var2 = (Long)var0[2];
      long var10000 = 6177900224927L ^ var2;
      int var34 = Event.bReturningInt();
      MinecraftClient var7 = b;
      MinecraftClient var8 = b;
      BlockHitResult var12 = var4;
      Hand var11 = var1;
      ClientPlayerEntity var10 = var8.player;
      ClientPlayerInteractionManager var9 = var7.interactionManager;
      ActionResult var6 = var9.interactBlock(var10, var11, var12);
      int var5 = var34;
      MinecraftClient var13 = b;
      ClientPlayerEntity var14 = var13.player;
      byte var35 = ((byte)((var14.isSpectator()) ? 1 : 0));
      int var29 = var5;
      byte var28 = var35;
      byte var25 = var28;
      byte var24 = var28;
      if (var29 == 0) {
         byte var30 = var24;
         if (var30 == 0) {
            RotationManager var36 = Prestige.o;
            Object[] var17 = new Object[]{true};
            RotationManager var16 = var36;
            var16.fReturningVoid(var17);
         }

         ActionResult var19 = var6;
         var25 = ((byte)((var19.isAccepted()) ? 1 : 0));
      }

      int var32 = var5;
      byte var31 = var25;
      byte var27 = var31;
      byte var26 = var31;
      if (var32 == 0) {
         byte var33 = var26;
         if (var33 != 0) {
            MinecraftClient var21 = b;
            Hand var23 = var1;
            ClientPlayerEntity var22 = var21.player;
            var22.swingHand(var23);
            return true;
         }

         var27 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var27);
   }

   public static void aReturningVoid(Object[] var0) {
      Entity var1 = (Entity)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 6177900224927L ^ var2;
      MinecraftClient var4 = b;
      MinecraftClient var5 = b;
      Entity var8 = var1;
      ClientPlayerEntity var7 = var5.player;
      ClientPlayerInteractionManager var6 = var4.interactionManager;
      var6.attackEntity((PlayerEntity)var7, var8);
      MinecraftClient var9 = b;
      Hand var11 = Hand.MAIN_HAND;
      ClientPlayerEntity var10 = var9.player;
      var10.swingHand(var11);
      RotationManager var14 = Prestige.o;
      Object[] var13 = new Object[]{true};
      RotationManager var12 = var14;
      var12.fReturningVoid(var13);
   }

   public static boolean cReturningBoolean(Object[] var0) {
      Hand var1 = (Hand)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 6177900224927L ^ var2;
      int var32 = Event.bReturningInt();
      MinecraftClient var6 = b;
      MinecraftClient var7 = b;
      Hand var10 = var1;
      ClientPlayerEntity var9 = var7.player;
      ClientPlayerInteractionManager var8 = var6.interactionManager;
      ActionResult var5 = var8.interactItem((PlayerEntity)var9, var10);
      int var4 = var32;
      MinecraftClient var11 = b;
      ClientPlayerEntity var12 = var11.player;
      byte var33 = ((byte)((var12.isSpectator()) ? 1 : 0));
      int var27 = var4;
      byte var26 = var33;
      byte var23 = var26;
      byte var22 = var26;
      if (var27 == 0) {
         byte var28 = var22;
         if (var28 == 0) {
            RotationManager var34 = Prestige.o;
            Object[] var15 = new Object[]{true};
            RotationManager var14 = var34;
            var14.fReturningVoid(var15);
         }

         ActionResult var17 = var5;
         var23 = ((byte)((var17.isAccepted()) ? 1 : 0));
      }

      int var30 = var4;
      byte var29 = var23;
      byte var25 = var29;
      byte var24 = var29;
      if (var30 == 0) {
         byte var31 = var24;
         if (var31 != 0) {
            MinecraftClient var19 = b;
            Hand var21 = Hand.MAIN_HAND;
            ClientPlayerEntity var20 = var19.player;
            var20.swingHand(var21);
            return true;
         }

         var25 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var25);
   }

   public static void bReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 6177900224927L ^ var1;
      MinecraftClient var3 = b;
      ClientPlayerEntity var4 = var3.player;
      var4.startGliding();
   }

   public static float aReturningFloat(Object[] var0) {
      boolean var1 = (Boolean)var0[0];
      boolean var3 = var1;
      float var2;
      if (var3) {
         float var4 = 5.0F;
         var2 = var4;
      } else {
         var2 = 4.5F;
      }

      return var2;
   }

   public static float bReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 6177900224927L ^ var1;
      MinecraftClient var3 = b;
      ClientPlayerEntity var4 = var3.player;
      Object[] var5 = new Object[]{var4.isCreative()};
      return aReturningFloat(var5);
   }

   public static boolean dReturningBoolean(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 6177900224927L ^ var1;
      long var3 = var1 ^ 50017035425016L;
      int var5 = Event.bReturningInt();
      MinecraftClient var6 = b;
      int var30 = var5;
      ClientPlayerEntity var29 = var6.player;
      ClientPlayerEntity var20 = var29;
      ClientPlayerEntity var19 = var29;
      if (var30 == 0) {
         ClientPlayerEntity var7 = var19;
         boolean var31 = var7.isUsingItem();
         if (!var31) {
            return false;
         }

         MinecraftClient var9 = b;
         ClientPlayerEntity var32 = var9.player;
         var20 = var32;
      }

      label44: {
         ClientPlayerEntity var11 = var20;
         ItemStack var12 = var11.getMainHandStack();
         Item var10000 = var12.getItem();
         int var35 = var5;
         Item var34 = Items.SHIELD;
         Item var33 = var10000;
         Item var23 = var33;
         Item var24 = var34;
         Item var21 = var33;
         Item var22 = var34;
         if (var35 == 0) {
            Item var37 = var22;
            Item var36 = var21;
            if (var36 == var37) {
               break label44;
            }

            MinecraftClient var14 = b;
            ClientPlayerEntity var15 = var14.player;
            ItemStack var16 = var15.getOffHandStack();
            var10000 = var16.getItem();
            Item var39 = Items.SHIELD;
            Item var38 = var10000;
            var23 = var38;
            var24 = var39;
         }

         Item var41 = var24;
         Item var40 = var23;
         if (var40 != var41) {
            return false;
         }

         Object[] var18 = new Object[]{var3};
         byte var49 = ((byte)((eReturningBoolean(var18)) ? 1 : 0));
         int var43 = var5;
         byte var42 = var49;
         byte var27 = var42;
         byte var25 = var42;
         if (var43 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var27);
         }

         byte var44 = var25;
         byte var26 = var44;
         byte var45 = var26;
         if (var45 != 0) {
            return false;
         }
      }

      byte var50 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var50);
   }

   public static boolean eReturningBoolean(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 6177900224927L ^ var1;
      int var3 = Event.bReturningInt();
      MinecraftClient var4 = b;
      ClientPlayerEntity var5 = var4.player;
      ItemStack var115 = var5.getMainHandStack();
      int var70 = var3;
      ItemStack var69 = var115;
      ItemStack var43 = var69;
      ItemStack var42 = var69;
      if (var70 == 0) {
         ComponentType var7 = DataComponentTypes.FOOD;
         ItemStack var6 = var42;
         Object var71 = var6.get(var7);
         if (var71 != null) {
            return true;
         }

         MinecraftClient var10 = b;
         ClientPlayerEntity var11 = var10.player;
         var43 = var11.getMainHandStack();
      }

      ItemStack var12 = var43;
      byte var116 = ((byte)((var12.getItem() instanceof PotionItem) ? 1 : 0));
      int var73 = var3;
      byte var72 = var116;
      byte var67 = var72;
      byte var44 = var72;
      if (var73 == 0) {
         byte var74 = var44;
         label64:
         if (var74 == 0) {
            MinecraftClient var14 = b;
            ClientPlayerEntity var15 = var14.player;
            ItemStack var16 = var15.getMainHandStack();
            Item var117 = var16.getItem();
            int var77 = var3;
            Item var76 = Items.SNOWBALL;
            Item var75 = var117;
            Item var49 = var75;
            Item var50 = var76;
            Item var45 = var75;
            Item var46 = var76;
            if (var77 == 0) {
               Item var79 = var46;
               Item var78 = var45;
               Item var47 = var78;
               Item var48 = var79;
               Item var81 = var48;
               Item var80 = var47;
               if (var80 == var81) {
                  break label64;
               }

               MinecraftClient var19 = b;
               ClientPlayerEntity var20 = var19.player;
               ItemStack var21 = var20.getMainHandStack();
               Item var118 = var21.getItem();
               Item var83 = Items.EGG;
               Item var82 = var118;
               var49 = var82;
               var50 = var83;
            }

            int var86 = var3;
            Item var85 = var50;
            Item var84 = var49;
            Item var53 = var84;
            Item var54 = var85;
            Item var51 = var84;
            Item var52 = var85;
            if (var86 == 0) {
               Item var88 = var52;
               Item var87 = var51;
               if (var87 == var88) {
                  break label64;
               }

               MinecraftClient var24 = b;
               ClientPlayerEntity var25 = var24.player;
               ItemStack var26 = var25.getMainHandStack();
               Item var119 = var26.getItem();
               Item var90 = Items.ENDER_PEARL;
               Item var89 = var119;
               var53 = var89;
               var54 = var90;
            }

            int var93 = var3;
            Item var92 = var54;
            Item var91 = var53;
            Item var57 = var91;
            Item var58 = var92;
            Item var55 = var91;
            Item var56 = var92;
            if (var93 == 0) {
               Item var95 = var56;
               Item var94 = var55;
               if (var94 == var95) {
                  break label64;
               }

               MinecraftClient var29 = b;
               ClientPlayerEntity var30 = var29.player;
               ItemStack var31 = var30.getMainHandStack();
               Item var120 = var31.getItem();
               Item var97 = Items.EXPERIENCE_BOTTLE;
               Item var96 = var120;
               var57 = var96;
               var58 = var97;
            }

            int var100 = var3;
            Item var99 = var58;
            Item var98 = var57;
            Item var61 = var98;
            Item var62 = var99;
            Item var59 = var98;
            Item var60 = var99;
            if (var100 == 0) {
               Item var102 = var60;
               Item var101 = var59;
               if (var101 == var102) {
                  break label64;
               }

               MinecraftClient var34 = b;
               ClientPlayerEntity var35 = var34.player;
               ItemStack var36 = var35.getMainHandStack();
               Item var121 = var36.getItem();
               Item var104 = Items.SPLASH_POTION;
               Item var103 = var121;
               var61 = var103;
               var62 = var104;
            }

            int var107 = var3;
            Item var106 = var62;
            Item var105 = var61;
            Item var65 = var105;
            Item var66 = var106;
            Item var63 = var105;
            Item var64 = var106;
            if (var107 == 0) {
               Item var109 = var64;
               Item var108 = var63;
               if (var108 == var109) {
                  break label64;
               }

               MinecraftClient var39 = b;
               ClientPlayerEntity var40 = var39.player;
               ItemStack var41 = var40.getMainHandStack();
               Item var122 = var41.getItem();
               Item var111 = Items.LINGERING_POTION;
               Item var110 = var122;
               var65 = var110;
               var66 = var111;
            }

            Item var113 = var66;
            Item var112 = var65;
            if (var112 != var113) {
               return false;
            }
         }

         var67 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var67);
   }

   public static boolean fReturningBoolean(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 6177900224927L ^ var1;
      return invokeBinding3(invokeBinding2(invokeBinding1(b, 2131377742927775763L, var1), 2132143583899009822L, var1), 2133205778559650392L, var1) instanceof BlockItem;
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 18;
            yield var15;
         }
         case 1 -> {
            byte var16 = 46;
            yield var16;
         }
         case 2 -> {
            byte var17 = 51;
            yield var17;
         }
         case 3 -> {
            byte var18 = 0;
            yield var18;
         }
         case 4 -> {
            byte var19 = 55;
            yield var19;
         }
         case 5 -> {
            byte var20 = 37;
            yield var20;
         }
         case 6 -> {
            byte var21 = 56;
            yield var21;
         }
         case 7 -> {
            byte var22 = 40;
            yield var22;
         }
         case 8 -> {
            byte var23 = 38;
            yield var23;
         }
         case 9 -> {
            byte var24 = 25;
            yield var24;
         }
         case 10 -> {
            byte var25 = 17;
            yield var25;
         }
         case 11 -> {
            byte var26 = 49;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 29;
            yield var28;
         }
         case 14 -> {
            byte var29 = 60;
            yield var29;
         }
         case 15 -> {
            byte var30 = 16;
            yield var30;
         }
         case 16 -> {
            byte var31 = 1;
            yield var31;
         }
         case 17 -> {
            byte var32 = 32;
            yield var32;
         }
         case 18 -> {
            byte var33 = 5;
            yield var33;
         }
         case 19 -> {
            byte var34 = 53;
            yield var34;
         }
         case 20 -> {
            byte var35 = 12;
            yield var35;
         }
         case 21 -> {
            byte var36 = 15;
            yield var36;
         }
         case 22 -> {
            byte var37 = 61;
            yield var37;
         }
         case 23 -> {
            byte var38 = 4;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 44;
            yield var40;
         }
         case 26 -> {
            byte var41 = 13;
            yield var41;
         }
         case 27 -> {
            byte var42 = 11;
            yield var42;
         }
         case 28 -> {
            byte var43 = 43;
            yield var43;
         }
         case 29 -> {
            byte var44 = 42;
            yield var44;
         }
         case 30 -> {
            byte var45 = 10;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 2;
            yield var47;
         }
         case 33 -> {
            byte var48 = 8;
            yield var48;
         }
         case 34 -> {
            byte var49 = 36;
            yield var49;
         }
         case 35 -> {
            byte var50 = 62;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 31;
            yield var52;
         }
         case 38 -> {
            byte var53 = 26;
            yield var53;
         }
         case 39 -> {
            byte var54 = 34;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 7;
            yield var56;
         }
         case 42 -> {
            byte var57 = 9;
            yield var57;
         }
         case 43 -> {
            byte var58 = 28;
            yield var58;
         }
         case 44 -> {
            byte var59 = 41;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 6;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 54;
            yield var63;
         }
         case 49 -> {
            byte var64 = 21;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 47;
            yield var66;
         }
         case 52 -> {
            byte var67 = 22;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 20;
            yield var70;
         }
         case 56 -> {
            byte var71 = 23;
            yield var71;
         }
         case 57 -> {
            byte var72 = 24;
            yield var72;
         }
         case 58 -> {
            byte var73 = 59;
            yield var73;
         }
         case 59 -> {
            byte var74 = 35;
            yield var74;
         }
         case 60 -> {
            byte var75 = 58;
            yield var75;
         }
         case 61 -> {
            byte var76 = 27;
            yield var76;
         }
         case 62 -> {
            byte var77 = 50;
            yield var77;
         }
         default -> 45;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "\u0014\\E J<\u0014\\R|F3\u000e\u0017RbF&\tf\u0000<\u0011l";
      c[1] = boolean.class;
      d[1] = "java/lang/Boolean";
      c[2] = "eb1tm^sb4.~Id)7(r]un ?9OD";
      c[3] = int.class;
      d[3] = "java/lang/Integer";
      c[4] = "6f\u0010ziQ6f\u0007&e^,-\u00078eK+\\We4";
      c[5] = "\"sXT-[\"sO\b!T88O\u0016!A?I\u001aIv";
      c[6] = "m\u0003={=hm\u0003*'1gwH*91rp9~af";
      c[7] = "\txAd9s\u001fxD>*d\b3G8&p\u0019tP/mg\u0014";
      c[8] = "7^g\u001e\t\u0015B~l\u0011\u0018Z#pg\u001a\u001c\u0000W";
      c[9] = void.class;
      d[9] = "java/lang/Void";
      c[10] = "\f\bOt\u00053\f\bX(\t<\u0016CX6\t)\u00112\nh^b";
      c[11] = "}\u0007\u001f*}'k\u0007\u001apn0|L\u0019vb$m\u000b\u000ea)4u\u000b\fjsyI\u0010\fws>~\u0007";
      c[12] = "\ri]\f\u0007\u0017\u001biXV\u0014\u0000\f\"[P\u0018\u0014\u001deLGS\u0004\u0005";
      c[13] = "(X{5\"c#WjzAn6Ze\u0011tl'Iy=ca";
      c[14] = "\u0019K\u001f:\u0010S\u0019K\bf\u001c\\\u0003\u0000\bx\u001cI\u0004qX-K\u000f";
      c[15] = "V\u0011sT<8V\u0011d\b07LZd\u00160\"K+6Mhh";
      c[16] = "4iK+I|4i\\wEs.\"\\iEf)S\u00066\u0017$";
      c[17] = "*\u0013L;S_!\u001c]t2Q*\u0017Y.";
      c[18] = "_'\u001b\u0011J\u001e_'\fMF\u0011El\fSF\u0004B\u001dV\f\u0014C";
      c[19] = "\u0013\u0019)PD8\u0013\u0019>\fH7\tR>\u0012H\"\u000e#lI\u0010c";
      c[20] = "\u0010\u0012\u0010d;7\u0010\u0012\u0007878\nY\u0007&7-\r(Urfl";
      c[21] = "R#s|\u0006L'\u0003xs\u0017\u0003F\rsx\u0013Y2";
      c[22] = float.class;
      d[22] = "java/lang/Float";
      c[23] = "MC\u0002G3{MC\u0015\u001b?tW\b\u0015\u0005?aPyG_k%";
      c[24] = "BZgW,J7zlX=\u0005VtgS9_\"";
      c[25] = "O\u0001\\z\u000e}O\u0001K&\u0002rUJK8\u0002gR;\u0019fZ#";
      c[26] = "Zm\u0018w@`/M\u0013xQ/NC\u0018sUu:";
      c[27] = "$M'OR\u0002,\\7Lj\u000b I5S\u00069p\u0005k\u0005Vn'\t8F\u0011\b=Y)\u000fj\u0005uN/PQ\u001fw\t44";
      c[28] = ")A\u001f$K2.D\u0005CT55F\u001b/fbr\u0018B~1auM\u0007,[5sLAC";
      c[29] = "\u001fm0E.\r\u001d6e\u001bP\b%n<\u00179\u0010\u001a65\u001b,b";
      c[30] = "\\d-wR{[64?ni\u00069/+9>XjrGUg\u0001,q#\u0016j[o";
      c[31] = "\b~hR)K\u0000oxQ\u0011B\fzzN}p^7\"\u0018\u0011K\u00029g\u0012`D\u0007oz)";
      c[32] = "+C*NG['\u001eoU8_'\u00120Po\u0001|Ok<TRy\u0002oM[W/\u001f";
      c[33] = "!9Ij\u0007uf%N<u p9\u0015k\u0019\u0012#uE3EE$y\u001ew\u001a/p\u007f\u001f1u";
      c[34] = "Q\u0013\u001b\u0006\u0003\"\u0016\u000f\u001cPqw\u0000\u0013G\u0007\u001dEWT\u0019^@\u0012S\f\u0018\u0001\u0010jW\bL\u0006q";
      c[35] = "\u0018vR\u0019MS[{\bZwRNjT\u0006\u001b`\u0019'\rQwXMnQ\u0006\u0006U\u001foXa\u0017WIxH\u0018\u0012\u000fR/4_\u0014\bBwL[\u0010\\E\u0016";
      c[36] = "*P?*4UuSjyTZ\u0016O:\u007f%\u0005&@i$m4(M9%5L,Im\"T";
      c[37] = "N\b`z(\u000bIZy2\u0014\u0019\u0014Ub&CNJ\u0002:J(\u000bI^tzo\u0017N\b";
      c[38] = "G(\u0005hC\u000f\u0004%_+y\u000e\u00114\u0003w\u0015<FyZ!y\u0004\u00120\u0006w\b\t@1\u000f\u0010FP\f9\u001a,E[G9cp\u001e\b\u001b2\tw\u001b\u0012|";
      c[39] = "O?\u0007)1|\b#\u0000\u007fC)\u001e?[(/\u001bMz\u0003sCsH3J6\u007fpCxJO}/L\"Z7y+\u0018%;";
      c[40] = "[@8\u0014\u001f>\u0019\u001c&\u0004s2kF4P\u001d5\n\u00197\u0005N";
      c[41] = "P1R\u007f>i\\l\u0017dAm\\`Ha\u00163\u00036\u0010\r-`\u0002p\u0017|\"eTm";
      c[42] = "eMM=Vw&@\u0017~lv3QK\"\u0000Dd\u001d\u001a{l/\"\u0011M7\\h>\u0016\u001bES(.\\RyP#e\\+t\u0012ao\\O#\b\u007f7-K\"\u000ft$GL'\u0015\u0013";
      c[43] = "=bS\u001a\u007fL)`G\u0019\u0007\u001e7oRLPMn:\t\u001d\u0007\u001ajoD[a\u0000:~\r";
      c[44] = "bz\u0004Q^\u0001n'AJ!\u0005n+\u001eOv[6{B#M\b0;ARB\rf&";
      c[45] = "8I\u001b9+p\u007fU\u001coY%iIG85\u0017;\u000e\u001dbYy8^\\03->_\u001a_";
      c[46] = "/eG#aYhy@u\u0013\f~e\u001b\"\u007f>-!Gz\u0013\u0000kk\u0000}\u007f\bz{\u0003E";
      c[47] = "2\u0016\u00181\u0013\u0007b\u0014\r2.\u001f\u0002\fIj_G2\u0003\u001a1\u0017vl\f\u00162W\u0016r\u0011\u001f0.";
      c[48] = "\u0005\u0000\u0013\rp\u0014U\u0002\u0006\u000eM\u000f5\u001aBV<T\u0005\u0015\u0011\rte\fG\u0015\u0016\"\u000fXA\u0014PM";
      c[49] = "T\u001dYh*zX@\u001csU~XLCv\u0002 \t\u0019\u001c\u001a9s\u0006\\\u001ck6vPA";
      c[50] = ">&\u0019Eh\u001f2{\\^\u0017\u001b2w\u0003[@Eo!Y7{\u0016lg\\Ft\u0013:z";
      c[51] = "Je\r\u001a<CF8H\u0001CGF4\u0017\u0004\u0014\u0019\u001ddNh/J\u0018$H\u0019 ON9";
      c[52] = "F\u0007]\u0003%\u001c\u0001\u001bZUWI\u0017\u0007\u0001\u0002;{DC^TWE\u0002\t\u001a];M\u0013\u0019\u0019e";
      c[53] = "AL\u001aV:\u0007BGQVCU\u001f\u001a\u000eK\u0014\u0006NOZ'|\u0000\u000e\u0006\u0013\u001b\u007f\u000bE\u0006";
      c[54] = "dj, Y\u001eh7i;&\u001ah;6>qD4jiRJ\u00176+i#E\u0012`6";
      c[55] = ":Z!\t\u0013SjX4\n.O\n@pR_\u0013:O#\t\u0017\"3\u001d'\u0012AHg\u001b&T.";
      c[56] = "e,5*~w5. )CoUfg%!x%-a{|\u0006dh7(=v/niuC";
      c[57] = "[\u001bha *\u001c\u0007o7R\u007f\n\u001b4`>MY^m:R#[\f/h8w]\ri\u0007";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1220973726156354L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1220973726156354L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1220973726156354L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 109;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 112;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 115;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 242;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 120;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 89;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 109;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 112;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 115;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cl_C0134",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cl" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static ClientPlayerEntity invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = a(
                  MethodHandles.lookup(),
                  "m",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ItemStack invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = a(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/ItemStack;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ItemStack)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = a(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
