package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.client.management.KeyReleaseTickListener;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;

public final class KeyBindingUtil implements MinecraftAccess {
   private static int a = 0;
   private static boolean c = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private static final long d = 105483963514682L;
   private static final Object[] e = new Object[30];
   private static final String[] f = new String[30];

   private KeyBindingUtil() {
   }

   public static void aReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 105483963514682L ^ var1;
      long var3 = var1 ^ 103520761007691L;
      int var5 = Event.cReturningInt();
      int var16 = var5;
      byte var15 = ((byte)((c) ? 1 : 0));
      byte var14 = var15;
      byte var13 = var15;
      if (var16 != 0) {
         byte var17 = var13;
         if (var17 == 0) {
            c = dev.prestige.recovery.SourceSupport.asBoolean(1);
            EventBus var10000 = Prestige.b;
            Object[] var8 = new Object[]{new KeyReleaseTickListener(), var3};
            EventBus var7 = var10000;
            var7.aReturningVoid(var8);
         }

         MinecraftClient var10 = b;
         GameOptions var11 = var10.options;
         KeyBinding var12 = var11.jumpKey;
         var12.setPressed(true);
         var14 = 2;
      }

      a = var14;
   }

   public static void bReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 105483963514682L ^ var1;
      long var3 = var1 ^ 121688453527359L;
      int var5 = Event.cReturningInt();
      int var11 = var5;
      int var10 = a;
      int var9 = var10;
      int var8 = var10;
      if (var11 != 0) {
         int var12 = var8;
         if (var12 <= 0) {
            return;
         }

         var9 = 0;
      }

      a = var9;
      Object[] var7 = new Object[]{var3};
      cReturningVoid(var7);
   }

   private static void cReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 105483963514682L ^ var1;
      int var3 = Event.bReturningInt();
      int var19 = var3;
      MinecraftClient var18 = b;
      MinecraftClient var17 = var18;
      MinecraftClient var16 = var18;
      if (var19 == 0) {
         MinecraftClient var4 = var16;
         Window var22 = var4.getWindow();
         MinecraftClient var5 = b;
         GameOptions var6 = var5.options;
         KeyBinding var7 = var6.jumpKey;
         Key var8 = var7.getDefaultKey();
         int var10 = var8.getCode();
         Window var9 = var22;
         boolean var20 = InputUtil.isKeyPressed(var9, var10);
         if (var20) {
            return;
         }

         MinecraftClient var21 = b;
         var17 = var21;
      }

      MinecraftClient var13 = var17;
      GameOptions var14 = var13.options;
      KeyBinding var15 = var14.jumpKey;
      var15.setPressed(false);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = f[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = e[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 48;
            yield var15;
         }
         case 1 -> {
            byte var16 = 8;
            yield var16;
         }
         case 2 -> {
            byte var17 = 32;
            yield var17;
         }
         case 3 -> {
            byte var18 = 7;
            yield var18;
         }
         case 4 -> {
            byte var19 = 18;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 29;
            yield var21;
         }
         case 7 -> {
            byte var22 = 30;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 50;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 9;
            yield var28;
         }
         case 14 -> {
            byte var29 = 45;
            yield var29;
         }
         case 15 -> {
            byte var30 = 28;
            yield var30;
         }
         case 16 -> {
            byte var31 = 58;
            yield var31;
         }
         case 17 -> {
            byte var32 = 36;
            yield var32;
         }
         case 18 -> {
            byte var33 = 11;
            yield var33;
         }
         case 19 -> {
            byte var34 = 26;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 14;
            yield var36;
         }
         case 22 -> {
            byte var37 = 46;
            yield var37;
         }
         case 23 -> {
            byte var38 = 40;
            yield var38;
         }
         case 24 -> {
            byte var39 = 16;
            yield var39;
         }
         case 25 -> {
            byte var40 = 2;
            yield var40;
         }
         case 26 -> {
            byte var41 = 1;
            yield var41;
         }
         case 27 -> {
            byte var42 = 0;
            yield var42;
         }
         case 28 -> {
            byte var43 = 23;
            yield var43;
         }
         case 29 -> {
            byte var44 = 39;
            yield var44;
         }
         case 30 -> {
            byte var45 = 21;
            yield var45;
         }
         case 31 -> {
            byte var46 = 61;
            yield var46;
         }
         case 32 -> {
            byte var47 = 22;
            yield var47;
         }
         case 33 -> {
            byte var48 = 20;
            yield var48;
         }
         case 34 -> {
            byte var49 = 55;
            yield var49;
         }
         case 35 -> {
            byte var50 = 15;
            yield var50;
         }
         case 36 -> {
            byte var51 = 51;
            yield var51;
         }
         case 37 -> {
            byte var52 = 3;
            yield var52;
         }
         case 38 -> {
            byte var53 = 49;
            yield var53;
         }
         case 39 -> {
            byte var54 = 35;
            yield var54;
         }
         case 40 -> {
            byte var55 = 60;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 42;
            yield var58;
         }
         case 44 -> {
            byte var59 = 4;
            yield var59;
         }
         case 45 -> {
            byte var60 = 62;
            yield var60;
         }
         case 46 -> {
            byte var61 = 53;
            yield var61;
         }
         case 47 -> {
            byte var62 = 13;
            yield var62;
         }
         case 48 -> {
            byte var63 = 54;
            yield var63;
         }
         case 49 -> {
            byte var64 = 33;
            yield var64;
         }
         case 50 -> {
            byte var65 = 10;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 38;
            yield var68;
         }
         case 54 -> {
            byte var69 = 5;
            yield var69;
         }
         case 55 -> {
            byte var70 = 6;
            yield var70;
         }
         case 56 -> {
            byte var71 = 37;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 27;
            yield var73;
         }
         case 59 -> {
            byte var74 = 24;
            yield var74;
         }
         case 60 -> {
            byte var75 = 17;
            yield var75;
         }
         case 61 -> {
            byte var76 = 19;
            yield var76;
         }
         case 62 -> {
            byte var77 = 43;
            yield var77;
         }
         default -> 44;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            f[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      e[0] = "t>\u001d\\{0b>\u0018\u0006h'uu\u001b\u0000d3d2\f\u0017/#b";
      e[1] = "!\u0015<\u0013^u*\u001a-\\=x?\u0017\"7\bz.\u0004>\u001b\u001fw";
      e[2] = "\u007f/;|\u0004\u001ei/>&\u0017\t~d= \u001b\u001do#*7P\u000f^";
      e[3] = int.class;
      f[3] = "java/lang/Integer";
      e[4] = "k|W\u00100j\u001e\\\\\u001f!%\u007fRW\u0014%\u007f\u000b";
      e[5] = void.class;
      f[5] = "java/lang/Void";
      e[6] = "uP<fz'uP+:v(o\u001b+$v=hj{y'";
      e[7] = "D@^X@3D@I\u0004L<^\u000bI\u001aL)Yz\u0019G\u0018";
      e[8] = "{3{#S1{3l\u007f_>axla_+f\t<=\n";
      e[9] = boolean.class;
      f[9] = "java/lang/Boolean";
      e[10] = "iXV\u0007\u001eh\u007fXS]\r\u007fh\u0013P[\u0001kyTGLJ{aTEG\u00106]OEZ\u0010qjX";
      e[11] = "ec}\u0010r\u0013scxJa\u0004d({Lm\u0010uol[&\u0001M";
      e[12] = "fVEu{5\u0013vNzjzrxEqn \u0006";
      e[13] = "V}^2\u0004]V}In\bRL6Ip\bGKG\u0019*^\u0001\u001c{F}\u001aGg+\u001a*";
      e[14] = "\u0000fG#\u0013\r\u0000fP\u007f\u001f\u0002\u001a-Pa\u001f\u0017\u001d\\\u0000;IQ";
      e[15] = "\u000b2\u001b41e\u000b2\fh=j\u0011y\fv=\u007f\u0016\b^*h=";
      e[16] = "\u0017.3t+S\u001c!\";J]\u0017*&a";
      e[17] = ")ja\u0012lPnlk\b\u000e@\u0010,{\u001e`Qyl/Oq*";
      e[18] = "\u0005;\u000e[n2\t'\u0018aj^\u0012&\u0006\u000b|!T6\u000ba~#\b1\u001e\u001e83\u0005[";
      e[19] = "\u0018ArM`fGDw\u0001\u000fhEEk\\X?\u001a\u00197026\u001dOdTc>B\u0013";
      e[20] = "ul`\u0001U\r$d?]>\u0007)1=\niPydbf\u0003\u001605eYZV*!";
      e[21] = "\u001a\u0013=N\u0015JY\u0013j\u0013)SF\u000efLEa\u0012N:\u0017)\f@\u001dhP@L\u0014Ly+";
      e[22] = "S\nVxnY\u0014\f\\b\fHjLLtbX\u0003\f\u0018%s#";
      e[23] = "\u0000fTHLwY&N\\p-PeLF\u001c\u001f\u0007\"\u0010\u0011IH\u0003xR\u001b\u000fu\u0006kJ\u0010ps]sAZK(_~V!";
      e[24] = "I\u000b}O\u0006V\u001eA.Iw\rMFw\u0012\u001b?\u0019\u0007&EHhIK}I\u0006YIY{DwRKUy\u000e\u001e\u0012\u001f\u0004huI\t^\u0000hHL\u001aF\u000b\u0017";
      e[25] = "Z}V@s\u0003Va@zuo\u0000q@GwVZ|TF\u001eTPwT\u0001%\u000fRzCz";
      e[26] = "&Juu4\u001c%UcmK\u0007\u0018\u0007hz-\u000f(Jr(;";
      e[27] = ")W\u007fL;RdM-ZY\u000b\u0016\u0017\u007fSd\u000b/MrGeb-GyG\"YvEtPY";
      e[28] = "cLf\u001dnN<IcQ\u0001K2Y{\u0007mye\u001f%P:.6Tq\\p\u001f6FwQ\u0001";
      e[29] = "Ro\u0002T'\u0001\u000b/\u0018@\u001b[\u0002l\u001aZwiV,@\f\u001b\u000f\u000e+\u001f\u0001gL\u000e|B=";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = e[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            e[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  e[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1135722441298655L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  e[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1135722441298655L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        e[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1135722441298655L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 228;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 200;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 220;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 73;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 80;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 194;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 228;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 200;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 220;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cr_C0146",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cr" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

    public static int recoveryAccess_read_a() { return dev.zprestige.prestige.api.util.KeyBindingUtil.a; }

    public static void recoveryAccess_call_cReturningVoid(java.lang.Object[] p0) { dev.zprestige.prestige.api.util.KeyBindingUtil.cReturningVoid(p0); }

   public static int recoveryAccess_preDecrement_a() { return --a; }

}
