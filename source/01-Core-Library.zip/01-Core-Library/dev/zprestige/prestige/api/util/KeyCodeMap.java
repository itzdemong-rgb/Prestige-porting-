package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class KeyCodeMap {
   private static final Map a;
   private static final long b = 117382157390029L;
   private static final Object[] c = new Object[15];
   private static final String[] d = new String[15];

   private KeyCodeMap() {
   }

   public static int aReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 117382157390029L ^ var2;
      int var4 = Event.bReturningInt();
      Map var21 = a;
      int var5 = var1;
      Integer var7 = var5;
      Map var6 = var21;
      byte var22 = ((byte)((var6.containsKey(var7)) ? 1 : 0));
      int var19 = var4;
      byte var18 = var22;
      int var17 = var18;
      byte var16 = var18;
      if (var19 == 0) {
         byte var20 = var16;
         if (var20 == 0) {
            return var1;
         }

         Map var23 = a;
         int var10 = var1;
         Integer var10001 = var10;
         int var11 = var1;
         Integer var14 = var11;
         Integer var13 = var10001;
         Map var12 = var23;
         Integer var15 = ((java.lang.Integer)(Object)(var12.getOrDefault(var13, var14)));
         var17 = var15;
      }

      return var17;
   }

   static {

      {

      aReturningVoid();
      Cipher var1;
      Cipher var10000 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(22641959502565L << var2 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[108];
      String var5 = "ÿ\u0004JvÕ\u008fà¦öHÌ\u001d>¤±\n\u007fÁ\u0015\u0089sZg/¨`os\u0080\u0001à\u0017øí½S^P\u0083[uá»\u0003\u0013ÙôÊi\u001enÅúÄè\u001aAýzsºw\n¦þ\u007f\u0094`4\n±wÓÐ:@\u0014\u000fÃE\u0087îè±\u0088\u0092!\u0017\u008fÊy±\u0091ÜjÇ\u0016\u001f¯\u009c`\u001f¬U\u0093\\\u001aô³°«Zá\trJEZ/³TÃ\u009f9¤\u0099\u0080\u0097Æ1-oC\u0000\u0014ìÞþÅ*»»#GH\u0018h¬4hóGÁÝR·\u0095x$©[A\u001eÉÌïK\u001a\u0018\u008aZ÷@;FVß,Ì\u0090zÌ\u0091\u0098M1\u009aá\u001cEÂØô îÎ8\\¬\u000f°\u0096\u001bg\n\u0087.z'\u000bð(¦µ¼iÉ\u0099MZo\u0018Nì\u0004?ý\u0086Ì\të\\\u008a\u008cµF\u0082þxÒJ\t\t»H\u0087â?»]¯G\u0012\u00adR-SÉ\u001cp\u0018*\u0098D\u0086çÓB\u00adk\u0085Ý\u008c^ý0\u00123\u0097ãmRß\u0002««¿¦ÜÔVJ[\u0080\u0098)\u0016ôâ\u008aH\u0097\u0082Còïc¦|ì¶bM~|Oç5z/Q\u008b5ª<±3\u009d_Üâ\u0097\u009c<\\ì_0\u0017\u0004\u0092lÕ\n/VI\u009c.Ó\u0010\u009a?ÑT°E%ÀÿiqÀj;ò q<_\"/k\u0083Èv\u0003\u009b~âÎ&ä/ÞÎ\rË\u0095¬¯}>¥j\u0006w\u009f\tË\u0086\u0084mÛÐ\u00834'`¿^\u008bNÈèËI5¹°G§\u0001«\u0094\u009fÔp\n¡(Ä¤^\u0000],¨Óu\u0093aæ1\u0087^ê|Ó\u008fFe}à}\u0016é\u0086S¨\u0094Np\u009d\u008e\u0089&Óg*¥»w·\u0093|D;Ç\u0019;\u008b¶ó)õnAØçyt\u0018æëïÑÂp(ýK\u0018\u0006u\u0086aìÌh%vb¼Å®3Új·\u008d6Óá§;A\u0090|µ»´E\rðy¿Ó,Î\u0011\u008e\u001b»b \u0005É\u0017¾\u008cØ\u0087\u0093ã\u009d³\u001b\u0094\u009fo©\u008fÂ¢¨ª\u008cüi \u0012\u008a8\u009f¶«\u0012gn{\u0006\u0088ªrëYRS\u001bWx\u0096s-\u0094Ú\u0094ø%\u0013\u000eUûÚ*\u009d\u0001\u0099\u0081ì'R\u0095\u0080êíÐ¯D\u0098\u0010eã\u008d*]H¯BA¨¦ssV[?þ2·#\u0082\u0002»¾½eªæÏi\u0094\u0007\u00148¸\f[\u009281Íu«>W\u0095Â\u008eÃ³µ\u0089\u00989\"êmÝ¤¢\u008fµ\u001cG(\u0013Hue\u008b@'\u008cájP\u008e¶\u0002\u0091æ;\u0013¦fÊ¯,gzõ8\u0093å\u000e\u009dê¶\u0003°IX\f\u001eP~Þ\u007f\u0098Ò&\u0080¸ûåYÂf½ßt\u0098k\u008a\u009bl\u0000\u0085º&¶\u001cÏÊSØºJ\f\u0087NÒN-°³\u0007\u009cíÆ± Ue`\u001e\u0082ùz\u008eE\r¥\u001eõ\u0093\u0091¨÷þsÞô·ôl\u0099ÈjÖiÿÈ\\\u009d\u0080x\u0015»ý\u008b 7\tI!ª;,>ai!§\u009böd÷z\u0084\u0093\u0016\u0012§V;)ÆÒ·¹UPÒëÖ";
      int var6 = "ÿ\u0004JvÕ\u008fà¦öHÌ\u001d>¤±\n\u007fÁ\u0015\u0089sZg/¨`os\u0080\u0001à\u0017øí½S^P\u0083[uá»\u0003\u0013ÙôÊi\u001enÅúÄè\u001aAýzsºw\n¦þ\u007f\u0094`4\n±wÓÐ:@\u0014\u000fÃE\u0087îè±\u0088\u0092!\u0017\u008fÊy±\u0091ÜjÇ\u0016\u001f¯\u009c`\u001f¬U\u0093\\\u001aô³°«Zá\trJEZ/³TÃ\u009f9¤\u0099\u0080\u0097Æ1-oC\u0000\u0014ìÞþÅ*»»#GH\u0018h¬4hóGÁÝR·\u0095x$©[A\u001eÉÌïK\u001a\u0018\u008aZ÷@;FVß,Ì\u0090zÌ\u0091\u0098M1\u009aá\u001cEÂØô îÎ8\\¬\u000f°\u0096\u001bg\n\u0087.z'\u000bð(¦µ¼iÉ\u0099MZo\u0018Nì\u0004?ý\u0086Ì\të\\\u008a\u008cµF\u0082þxÒJ\t\t»H\u0087â?»]¯G\u0012\u00adR-SÉ\u001cp\u0018*\u0098D\u0086çÓB\u00adk\u0085Ý\u008c^ý0\u00123\u0097ãmRß\u0002««¿¦ÜÔVJ[\u0080\u0098)\u0016ôâ\u008aH\u0097\u0082Còïc¦|ì¶bM~|Oç5z/Q\u008b5ª<±3\u009d_Üâ\u0097\u009c<\\ì_0\u0017\u0004\u0092lÕ\n/VI\u009c.Ó\u0010\u009a?ÑT°E%ÀÿiqÀj;ò q<_\"/k\u0083Èv\u0003\u009b~âÎ&ä/ÞÎ\rË\u0095¬¯}>¥j\u0006w\u009f\tË\u0086\u0084mÛÐ\u00834'`¿^\u008bNÈèËI5¹°G§\u0001«\u0094\u009fÔp\n¡(Ä¤^\u0000],¨Óu\u0093aæ1\u0087^ê|Ó\u008fFe}à}\u0016é\u0086S¨\u0094Np\u009d\u008e\u0089&Óg*¥»w·\u0093|D;Ç\u0019;\u008b¶ó)õnAØçyt\u0018æëïÑÂp(ýK\u0018\u0006u\u0086aìÌh%vb¼Å®3Új·\u008d6Óá§;A\u0090|µ»´E\rðy¿Ó,Î\u0011\u008e\u001b»b \u0005É\u0017¾\u008cØ\u0087\u0093ã\u009d³\u001b\u0094\u009fo©\u008fÂ¢¨ª\u008cüi \u0012\u008a8\u009f¶«\u0012gn{\u0006\u0088ªrëYRS\u001bWx\u0096s-\u0094Ú\u0094ø%\u0013\u000eUûÚ*\u009d\u0001\u0099\u0081ì'R\u0095\u0080êíÐ¯D\u0098\u0010eã\u008d*]H¯BA¨¦ssV[?þ2·#\u0082\u0002»¾½eªæÏi\u0094\u0007\u00148¸\f[\u009281Íu«>W\u0095Â\u008eÃ³µ\u0089\u00989\"êmÝ¤¢\u008fµ\u001cG(\u0013Hue\u008b@'\u008cájP\u008e¶\u0002\u0091æ;\u0013¦fÊ¯,gzõ8\u0093å\u000e\u009dê¶\u0003°IX\f\u001eP~Þ\u007f\u0098Ò&\u0080¸ûåYÂf½ßt\u0098k\u008a\u009bl\u0000\u0085º&¶\u001cÏÊSØºJ\f\u0087NÒN-°³\u0007\u009cíÆ± Ue`\u001e\u0082ùz\u008eE\r¥\u001eõ\u0093\u0091¨÷þsÞô·ôl\u0099ÈjÖiÿÈ\\\u009d\u0080x\u0015»ý\u008b 7\tI!ª;,>ai!§\u009böd÷z\u0084\u0093\u0016\u0012§V;)ÆÒ·¹UPÒëÖ"
         .length();
      label60:
      while (true) {
         int var10001 = var3;
         var3 += 8;
         byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
         long[] var282 = var0;
         var10001 = var4++;
         long var389 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         
            long var8 = var389;
            byte[] var10 = var1.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var393 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var391) {
               case 0:
                  var282[var10001] = var393;
                  if (var3 >= var6) {
                     a = new HashMap();

                     for (var13 < (int)var0[106]; var13++) {
                        Map var283 = a;
                        int var14 = (int)var0[23] + var13;
                        Integer var337 = var14;
                        int var15 = (int)var0[32] + var13;
                        Integer var18 = var15;
                        Integer var17 = var337;
                        Map var16 = var283;
                        var16.put(var17, var18);
                     }

                     for (var279 < (int)var0[98]; var279++) {
                        Map var284 = a;
                        int var20 = (int)var0[46] + var279;
                        Integer var338 = var20;
                        int var21 = (int)var0[80] + var279;
                        Integer var24 = var21;
                        Integer var23 = var338;
                        Map var22 = var284;
                        var22.put(var23, var24);
                     }

                     Map var285 = a;
                     int var26 = (int)var0[99];
                     Integer var339 = var26;
                     int var27 = (int)var0[43];
                     Integer var30 = var27;
                     Integer var29 = var339;
                     Map var28 = var285;
                     var28.put(var29, var30);
                     Map var286 = a;
                     int var31 = (int)var0[42];
                     var339 = var31;
                     int var32 = (int)var0[71];
                     Integer var35 = var32;
                     Integer var34 = var339;
                     Map var33 = var286;
                     var33.put(var34, var35);
                     Map var287 = a;
                     int var36 = (int)var0[54];
                     var339 = var36;
                     int var37 = (int)var0[83];
                     Integer var40 = var37;
                     Integer var39 = var339;
                     Map var38 = var287;
                     var38.put(var39, var40);
                     Map var288 = a;
                     int var41 = (int)var0[73];
                     var339 = var41;
                     int var42 = (int)var0[105];
                     Integer var45 = var42;
                     Integer var44 = var339;
                     Map var43 = var288;
                     var43.put(var44, var45);
                     Map var289 = a;
                     int var46 = (int)var0[4];
                     var339 = var46;
                     int var47 = (int)var0[6];
                     Integer var50 = var47;
                     Integer var49 = var339;
                     Map var48 = var289;
                     var48.put(var49, var50);
                     Map var290 = a;
                     int var51 = (int)var0[15];
                     var339 = var51;
                     int var52 = (int)var0[61];
                     Integer var55 = var52;
                     Integer var54 = var339;
                     Map var53 = var290;
                     var53.put(var54, var55);
                     Map var291 = a;
                     int var56 = (int)var0[45];
                     var339 = var56;
                     int var57 = (int)var0[40];
                     Integer var60 = var57;
                     Integer var59 = var339;
                     Map var58 = var291;
                     var58.put(var59, var60);
                     Map var292 = a;
                     int var61 = (int)var0[85];
                     var339 = var61;
                     int var62 = (int)var0[33];
                     Integer var65 = var62;
                     Integer var64 = var339;
                     Map var63 = var292;
                     var63.put(var64, var65);
                     Map var293 = a;
                     int var66 = (int)var0[12];
                     var339 = var66;
                     int var67 = (int)var0[34];
                     Integer var70 = var67;
                     Integer var69 = var339;
                     Map var68 = var293;
                     var68.put(var69, var70);
                     Map var294 = a;
                     int var71 = (int)var0[24];
                     var339 = var71;
                     int var72 = (int)var0[102];
                     Integer var75 = var72;
                     Integer var74 = var339;
                     Map var73 = var294;
                     var73.put(var74, var75);
                     Map var295 = a;
                     int var76 = (int)var0[7];
                     var339 = var76;
                     int var77 = (int)var0[38];
                     Integer var80 = var77;
                     Integer var79 = var339;
                     Map var78 = var295;
                     var78.put(var79, var80);
                     Map var296 = a;
                     int var81 = (int)var0[88];
                     var339 = var81;
                     int var82 = (int)var0[26];
                     Integer var85 = var82;
                     Integer var84 = var339;
                     Map var83 = var296;
                     var83.put(var84, var85);
                     Map var297 = a;
                     int var86 = (int)var0[100];
                     var339 = var86;
                     int var87 = (int)var0[13];
                     Integer var90 = var87;
                     Integer var89 = var339;
                     Map var88 = var297;
                     var88.put(var89, var90);
                     Map var298 = a;
                     int var91 = (int)var0[84];
                     var339 = var91;
                     int var92 = (int)var0[28];
                     Integer var95 = var92;
                     Integer var94 = var339;
                     Map var93 = var298;
                     var93.put(var94, var95);
                     Map var299 = a;
                     int var96 = (int)var0[59];
                     var339 = var96;
                     int var97 = (int)var0[67];
                     Integer var100 = var97;
                     Integer var99 = var339;
                     Map var98 = var299;
                     var98.put(var99, var100);
                     Map var300 = a;
                     int var101 = (int)var0[69];
                     var339 = var101;
                     int var102 = (int)var0[93];
                     Integer var105 = var102;
                     Integer var104 = var339;
                     Map var103 = var300;
                     var103.put(var104, var105);
                     Map var301 = a;
                     int var106 = (int)var0[0];
                     var339 = var106;
                     int var107 = (int)var0[17];
                     Integer var110 = var107;
                     Integer var109 = var339;
                     Map var108 = var301;
                     var108.put(var109, var110);
                     Map var302 = a;
                     int var111 = (int)var0[82];
                     var339 = var111;
                     int var112 = (int)var0[19];
                     Integer var115 = var112;
                     Integer var114 = var339;
                     Map var113 = var302;
                     var113.put(var114, var115);
                     Map var303 = a;
                     int var116 = (int)var0[31];
                     var339 = var116;
                     int var117 = (int)var0[55];
                     Integer var120 = var117;
                     Integer var119 = var339;
                     Map var118 = var303;
                     var118.put(var119, var120);
                     Map var304 = a;
                     int var121 = (int)var0[29];
                     var339 = var121;
                     int var122 = (int)var0[41];
                     Integer var125 = var122;
                     Integer var124 = var339;
                     Map var123 = var304;
                     var123.put(var124, var125);
                     Map var305 = a;
                     int var126 = (int)var0[53];
                     var339 = var126;
                     int var127 = (int)var0[35];
                     Integer var130 = var127;
                     Integer var129 = var339;
                     Map var128 = var305;
                     var128.put(var129, var130);
                     Map var306 = a;
                     int var131 = (int)var0[76];
                     var339 = var131;
                     int var132 = (int)var0[11];
                     Integer var135 = var132;
                     Integer var134 = var339;
                     Map var133 = var306;
                     var133.put(var134, var135);
                     Map var307 = a;
                     int var136 = (int)var0[78];
                     var339 = var136;
                     int var137 = (int)var0[27];
                     Integer var140 = var137;
                     Integer var139 = var339;
                     Map var138 = var307;
                     var138.put(var139, var140);
                     Map var308 = a;
                     int var141 = (int)var0[47];
                     var339 = var141;
                     int var142 = (int)var0[48];
                     Integer var145 = var142;
                     Integer var144 = var339;
                     Map var143 = var308;
                     var143.put(var144, var145);
                     Map var309 = a;
                     int var146 = (int)var0[89];
                     var339 = var146;
                     int var147 = (int)var0[72];
                     Integer var150 = var147;
                     Integer var149 = var339;
                     Map var148 = var309;
                     var148.put(var149, var150);
                     Map var310 = a;
                     int var151 = (int)var0[63];
                     var339 = var151;
                     int var152 = (int)var0[91];
                     Integer var155 = var152;
                     Integer var154 = var339;
                     Map var153 = var310;
                     var153.put(var154, var155);
                     Map var311 = a;
                     int var156 = (int)var0[8];
                     var339 = var156;
                     int var157 = (int)var0[58];
                     Integer var160 = var157;
                     Integer var159 = var339;
                     Map var158 = var311;
                     var158.put(var159, var160);
                     Map var312 = a;
                     int var161 = (int)var0[90];
                     var339 = var161;
                     int var162 = (int)var0[49];
                     Integer var165 = var162;
                     Integer var164 = var339;
                     Map var163 = var312;
                     var163.put(var164, var165);
                     Map var313 = a;
                     int var166 = (int)var0[52];
                     var339 = var166;
                     int var167 = (int)var0[75];
                     Integer var170 = var167;
                     Integer var169 = var339;
                     Map var168 = var313;
                     var168.put(var169, var170);
                     Map var314 = a;
                     int var171 = (int)var0[20];
                     var339 = var171;
                     int var172 = (int)var0[107];
                     Integer var175 = var172;
                     Integer var174 = var339;
                     Map var173 = var314;
                     var173.put(var174, var175);
                     Map var315 = a;
                     int var176 = (int)var0[14];
                     var339 = var176;
                     int var177 = (int)var0[18];
                     Integer var180 = var177;
                     Integer var179 = var339;
                     Map var178 = var315;
                     var178.put(var179, var180);
                     Map var316 = a;
                     int var181 = (int)var0[86];
                     var339 = var181;
                     int var182 = (int)var0[74];
                     Integer var185 = var182;
                     Integer var184 = var339;
                     Map var183 = var316;
                     var183.put(var184, var185);

                     for (var280 < (int)var0[36]; var280++) {
                        Map var317 = a;
                        int var186 = (int)var0[2] + var280;
                        var339 = var186;
                        int var187 = (int)var0[104] + var280;
                        Integer var190 = var187;
                        Integer var189 = var339;
                        Map var188 = var317;
                        var188.put(var189, var190);
                     }

                     Map var318 = a;
                     int var192 = (int)var0[44];
                     var339 = var192;
                     int var193 = (int)var0[66];
                     Integer var196 = var193;
                     Integer var195 = var339;
                     Map var194 = var318;
                     var194.put(var195, var196);
                     Map var319 = a;
                     int var197 = (int)var0[3];
                     var339 = var197;
                     int var198 = (int)var0[103];
                     Integer var201 = var198;
                     Integer var200 = var339;
                     Map var199 = var319;
                     var199.put(var200, var201);
                     Map var320 = a;
                     int var202 = (int)var0[101];
                     var339 = var202;
                     int var203 = (int)var0[87];
                     Integer var206 = var203;
                     Integer var205 = var339;
                     Map var204 = var320;
                     var204.put(var205, var206);
                     Map var321 = a;
                     int var207 = (int)var0[79];
                     var339 = var207;
                     int var208 = (int)var0[68];
                     Integer var211 = var208;
                     Integer var210 = var339;
                     Map var209 = var321;
                     var209.put(var210, var211);
                     Map var322 = a;
                     int var212 = (int)var0[64];
                     var339 = var212;
                     int var213 = (int)var0[50];
                     Integer var216 = var213;
                     Integer var215 = var339;
                     Map var214 = var322;
                     var214.put(var215, var216);
                     Map var323 = a;
                     int var217 = (int)var0[77];
                     var339 = var217;
                     int var218 = (int)var0[92];
                     Integer var221 = var218;
                     Integer var220 = var339;
                     Map var219 = var323;
                     var219.put(var220, var221);
                     Map var324 = a;
                     int var222 = (int)var0[30];
                     var339 = var222;
                     int var223 = (int)var0[21];
                     Integer var226 = var223;
                     Integer var225 = var339;
                     Map var224 = var324;
                     var224.put(var225, var226);
                     Map var325 = a;
                     int var227 = (int)var0[37];
                     var339 = var227;
                     int var228 = (int)var0[16];
                     Integer var231 = var228;
                     Integer var230 = var339;
                     Map var229 = var325;
                     var229.put(var230, var231);
                     Map var326 = a;
                     int var232 = (int)var0[62];
                     var339 = var232;
                     int var233 = (int)var0[95];
                     Integer var236 = var233;
                     Integer var235 = var339;
                     Map var234 = var326;
                     var234.put(var235, var236);
                     Map var327 = a;
                     int var237 = (int)var0[97];
                     var339 = var237;
                     int var238 = (int)var0[70];
                     Integer var241 = var238;
                     Integer var240 = var339;
                     Map var239 = var327;
                     var239.put(var240, var241);
                     Map var328 = a;
                     int var242 = (int)var0[57];
                     var339 = var242;
                     int var243 = (int)var0[1];
                     Integer var246 = var243;
                     Integer var245 = var339;
                     Map var244 = var328;
                     var244.put(var245, var246);

                     for (var281 < (int)var0[25]; var281++) {
                        Map var329 = a;
                        int var247 = (int)var0[94] + var281;
                        var339 = var247;
                        int var248 = (int)var0[65] + var281;
                        Integer var251 = var248;
                        Integer var250 = var339;
                        Map var249 = var329;
                        var249.put(var250, var251);
                     }

                     Map var330 = a;
                     int var253 = (int)var0[56];
                     var339 = var253;
                     int var254 = (int)var0[81];
                     Integer var257 = var254;
                     Integer var256 = var339;
                     Map var255 = var330;
                     var255.put(var256, var257);
                     Map var331 = a;
                     int var258 = (int)var0[96];
                     var339 = var258;
                     int var259 = (int)var0[10];
                     Integer var262 = var259;
                     Integer var261 = var339;
                     Map var260 = var331;
                     var260.put(var261, var262);
                     Map var332 = a;
                     int var263 = (int)var0[5];
                     var339 = var263;
                     int var264 = (int)var0[51];
                     Integer var267 = var264;
                     Integer var266 = var339;
                     Map var265 = var332;
                     var265.put(var266, var267);
                     Map var333 = a;
                     int var268 = (int)var0[9];
                     var339 = var268;
                     int var269 = (int)var0[39];
                     Integer var272 = var269;
                     Integer var271 = var339;
                     Map var270 = var333;
                     var270.put(var271, var272);
                     Map var334 = a;
                     int var273 = (int)var0[22];
                     var339 = var273;
                     int var274 = (int)var0[60];
                     Integer var277 = var274;
                     Integer var276 = var339;
                     Map var275 = var334;
                     var275.put(var276, var277);
                     break;
                  }
                  break;
               default:
                  var282[var10001] = var393;
                  if (var3 < var6) {
                     continue label60;
                  }

                  var5 = "\u0099©hòrù(-hX Ö\u007fõ\u0005\u0080";
                  var6 = "\u0099©hòrù(-hX Ö\u007fõ\u0005\u0080".length();
                  var3 = 0;
            }

            int var336 = var3;
            var3 += 8;
            var7 = var5.substring(var336, var3).getBytes("ISO-8859-1");
            var282 = var0;
            var10001 = var4++;
            var389 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var391 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 36;
            yield var16;
         }
         case 2 -> {
            byte var17 = 42;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 44;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 37;
            yield var21;
         }
         case 7 -> {
            byte var22 = 50;
            yield var22;
         }
         case 8 -> {
            byte var23 = 60;
            yield var23;
         }
         case 9 -> {
            byte var24 = 47;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 21;
            yield var26;
         }
         case 12 -> {
            byte var27 = 10;
            yield var27;
         }
         case 13 -> {
            byte var28 = 30;
            yield var28;
         }
         case 14 -> {
            byte var29 = 61;
            yield var29;
         }
         case 15 -> {
            byte var30 = 24;
            yield var30;
         }
         case 16 -> {
            byte var31 = 55;
            yield var31;
         }
         case 17 -> {
            byte var32 = 33;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 35;
            yield var34;
         }
         case 20 -> {
            byte var35 = 25;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 51;
            yield var37;
         }
         case 23 -> {
            byte var38 = 29;
            yield var38;
         }
         case 24 -> {
            byte var39 = 58;
            yield var39;
         }
         case 25 -> {
            byte var40 = 23;
            yield var40;
         }
         case 26 -> {
            byte var41 = 16;
            yield var41;
         }
         case 27 -> {
            byte var42 = 8;
            yield var42;
         }
         case 28 -> {
            byte var43 = 1;
            yield var43;
         }
         case 29 -> {
            byte var44 = 31;
            yield var44;
         }
         case 30 -> {
            byte var45 = 56;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 54;
            yield var47;
         }
         case 33 -> {
            byte var48 = 28;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 27;
            yield var50;
         }
         case 36 -> {
            byte var51 = 48;
            yield var51;
         }
         case 37 -> {
            byte var52 = 32;
            yield var52;
         }
         case 38 -> {
            byte var53 = 6;
            yield var53;
         }
         case 39 -> {
            byte var54 = 41;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 9;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 43;
            yield var58;
         }
         case 44 -> {
            byte var59 = 40;
            yield var59;
         }
         case 45 -> {
            byte var60 = 62;
            yield var60;
         }
         case 46 -> {
            byte var61 = 4;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 53;
            yield var63;
         }
         case 49 -> {
            byte var64 = 19;
            yield var64;
         }
         case 50 -> {
            byte var65 = 0;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 13;
            yield var67;
         }
         case 53 -> {
            byte var68 = 39;
            yield var68;
         }
         case 54 -> {
            byte var69 = 20;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 26;
            yield var73;
         }
         case 59 -> {
            byte var74 = 17;
            yield var74;
         }
         case 60 -> {
            byte var75 = 11;
            yield var75;
         }
         case 61 -> {
            byte var76 = 45;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 22;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "i5\u0004\f{jb:\u0015C\u001chw1\u0015\b'";
      c[1] = int.class;
      d[1] = "java/lang/Integer";
      c[2] = "%qR\u0005`\r;yHJ\u0003\u0019?";
      c[3] = "c%\niihh*\u001b&\bfc!\u001f|";
      c[4] = "\u000e^a\u001f(:\u0018^dE;-\u000f\u0015gC79\u001eRpT|+/";
      c[5] = ";\u001a/*\u0001\u0007-\u001a*p\u0012\u0010:Q)v\u001e\u0004+\u0016>aU\u0014*";
      c[6] = "A\u0007aR\u0007hJ\bp\u001dde_\u0005\u007fvQgN\u0016cZFj";
      c[7] = boolean.class;
      d[7] = "java/lang/Boolean";
      c[8] = "s\t\u0017V\u001c\u0002x\u0005K&\u0018V&\t\u001da\b?{EJ\u001e\b\u0006>\u0019O\\f\u000e?\u0013\u0000\\[\u00053Op";
      c[9] = "v`\u0018W\u0018n-%\u000fM\"x(z\u0002ZCu4_\u0013B\")+g\u0010R^+&uA3\u001fs5~\u0018O\u001dw-\u007f~";
      c[10] = "}QO#l\u007fv]\u0013Sw$0rA7k/L\u0015\u0019i.,uPEllB";
      c[11] = "t*#N\u0004\u001f/o4T>\r *\u0002Pr\u000f#?8NBbw2>D_\u001eu?,\u0015>X)-+KBZ$?z*\u0004\u000668$V\u0006\u000b$iE";
      c[12] = "y\\b5._&\ngjJ[B\u000f,`r_{Jpe01";
      c[13] = "\u0015\u0014\\\u001c\u0000\u0017D\u000b\u000e\u0004a\u0017.L\u0019[\u0005\u0017@A\\[\u0004~\u0012\n\\\u0000\b\u0010\u001fO\\\u0001a";
      c[14] = "eE\u0013s%\u001b>\u0000\u0004i\u001f\u001e!Eu-{\u001d2X\t/v\u000fc9Osd\b=EM~vY\\\u0003\u0011lq\u0007 \u0001\u001c~ f";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(264591206836495L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(264591206836495L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(264591206836495L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 249;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 210;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 112;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 219;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 230;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 253;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 249;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 210;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 112;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cu_C0152",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
