package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.api.accessor.ClientChunkManagerAccessor;
import dev.zprestige.prestige.api.accessor.ClientChunkMapAccessor;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReferenceArray;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;

public class LoadedChunkIterator implements Iterator, MinecraftAccess {
   private final ClientChunkMapAccessor a;
   private final boolean c;
   private int d;
   private Chunk e;
   private static final long f = 597522706388L;
   private static final Object[] g = new Object[35];
   private static final String[] h = new String[35];

   public LoadedChunkIterator(boolean var1, long var2) {
      super();
      var2 = 597522706388L ^ var2;
      long var4 = var2 ^ 102295415931117L;
      long var6 = var2 ^ 111533757380120L;

      MinecraftClient var8 = b;
      ClientWorld var9 = var8.world;
      ClientChunkManagerAccessor var10003 = new ClientChunkManagerAccessor(var9.getChunkManager());
      Object[] var11 = new Object[]{var6};
      ClientChunkManagerAccessor var10 = var10003;
      this.a = new ClientChunkMapAccessor(var10.aReturningVoid(var11));
      this.d = 0;
      this.c = var1;
      Object[] var13 = new Object[]{var4};
      LoadedChunkIterator var12 = this;
      var12.aReturningChunk(var13);
   }

   private Chunk aReturningChunk(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 597522706388L ^ var2;
      long var4 = var2 ^ 90058569489070L;
      long var6 = var2 ^ 2953719688472L;
      int var10000 = Event.bReturningInt();
      Chunk var9 = this.e;
      int var8 = var10000;
      this.e = null;

      while (true) {
         var10000 = this.d;
         ClientChunkMapAccessor var10001 = this.a;
         Object[] var11 = new Object[]{var4};
         ClientChunkMapAccessor var10 = var10001;
         AtomicReferenceArray var12 = var10.aReturningVoid(var11);
         int var26 = var12.length();
         int var25 = var10000;
         if (var25 >= var26) {
            break;
         }

         var10001 = this.a;
         Object[] var14 = new Object[]{var4};
         ClientChunkMapAccessor var13 = var10001;
         AtomicReferenceArray var38 = var13.aReturningVoid(var14);
         int var16 = this.d++;
         AtomicReferenceArray var15 = var38;
         this.e = (Chunk)var15.get(var16);
         int var28 = var8;
         LoadedChunkIterator var27 = this;
         LoadedChunkIterator var22 = var27;
         LoadedChunkIterator var21 = var27;
         if (var28 == 0) {
            Chunk var29 = var21.e;
            if (var29 == null) {
               continue;
            }

            var22 = this;
         }

         int var31 = var8;
         boolean var30 = var22.c;
         boolean var24 = var30;
         boolean var23 = var30;
         if (var31 == 0) {
            boolean var32 = var23;
            if (!var32) {
               break;
            }

            Object[] var20 = new Object[]{this.e, var6};
            LoadedChunkIterator var19 = this;
            boolean var33 = var19.aReturningBoolean(var20);
            var24 = var33;
         }

         boolean var34 = var24;
         if (var34) {
            break;
         }
      }

      return var9;
   }

   private boolean aReturningBoolean(Object[] var1) {
      Chunk var2 = (Chunk)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 597522706388L ^ var3;
      Chunk var8 = var2;
      ChunkPos var9 = var8.getPos();
      int var6 = var9.x;
      int var62 = Event.bReturningInt();
      Chunk var10 = var2;
      ChunkPos var11 = var10.getPos();
      int var7 = var11.z;
      int var5 = var62;
      MinecraftClient var12 = b;
      ClientWorld var13 = var12.world;
      ClientChunkManager var63 = var13.getChunkManager();
      int var10001 = var6 + 1;
      int var16 = var7;
      int var15 = var10001;
      ClientChunkManager var14 = var63;
      byte var64 = ((byte)((var14.isChunkLoaded(var15, var16)) ? 1 : 0));
      int var47 = var5;
      byte var46 = var64;
      byte var38 = var46;
      byte var37 = var46;
      if (var47 == 0) {
         byte var48 = var37;
         if (var48 == 0) {
            return false;
         }

         MinecraftClient var18 = b;
         ClientWorld var19 = var18.world;
         ClientChunkManager var65 = var19.getChunkManager();
         var10001 = var6 - 1;
         int var22 = var7;
         int var21 = var10001;
         ClientChunkManager var20 = var65;
         byte var49 = ((byte)((var20.isChunkLoaded(var21, var22)) ? 1 : 0));
         var38 = var49;
      }

      int var51 = var5;
      byte var50 = var38;
      byte var40 = var50;
      byte var39 = var50;
      if (var51 == 0) {
         byte var52 = var39;
         if (var52 == 0) {
            return false;
         }

         MinecraftClient var25 = b;
         ClientWorld var26 = var25.world;
         ClientChunkManager var66 = var26.getChunkManager();
         int var29 = var7 + 1;
         int var28 = var6;
         ClientChunkManager var27 = var66;
         byte var53 = ((byte)((var27.isChunkLoaded(var28, var29)) ? 1 : 0));
         var40 = var53;
      }

      int var55 = var5;
      byte var54 = var40;
      byte var42 = var54;
      byte var41 = var54;
      if (var55 == 0) {
         byte var56 = var41;
         if (var56 == 0) {
            return false;
         }

         MinecraftClient var32 = b;
         ClientWorld var33 = var32.world;
         ClientChunkManager var67 = var33.getChunkManager();
         int var36 = var7 - 1;
         int var35 = var6;
         ClientChunkManager var34 = var67;
         byte var57 = ((byte)((var34.isChunkLoaded(var35, var36)) ? 1 : 0));
         var42 = var57;
      }

      int var59 = var5;
      byte var58 = var42;
      byte var44 = var58;
      byte var43 = var58;
      if (var59 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var44);
      } else {
         byte var60 = var43;
         if (var60 != 0) {
            var44 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var44);
         } else {
            return false;
         }
      }
   }

   @Override
   public boolean hasNext() {
      Chunk var2 = this.e;
      byte var1;
      if (var2 != null) {
         byte var3 = 1;
         var1 = var3;
      } else {
         var1 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var1);
   }

   public Chunk b(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 597522706388L ^ var2;
      long var4 = var2 ^ 74839601622355L;
      Object[] var7 = new Object[]{var4};
      LoadedChunkIterator var6 = this;
      return var6.aReturningChunk(var7);
   }

   @Override
   public Object next() {
      long var10001 = 67306569218351L ^ 124865936973246L;
      Object[] var6 = new Object[]{84282659267729L};
      LoadedChunkIterator var5 = this;
      return var5.bReturningVoid(var6);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = h[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = g[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 61;
            yield var15;
         }
         case 1 -> {
            byte var16 = 55;
            yield var16;
         }
         case 2 -> {
            byte var17 = 7;
            yield var17;
         }
         case 3 -> {
            byte var18 = 30;
            yield var18;
         }
         case 4 -> {
            byte var19 = 12;
            yield var19;
         }
         case 5 -> {
            byte var20 = 32;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 29;
            yield var22;
         }
         case 8 -> {
            byte var23 = 38;
            yield var23;
         }
         case 9 -> {
            byte var24 = 57;
            yield var24;
         }
         case 10 -> {
            byte var25 = 52;
            yield var25;
         }
         case 11 -> {
            byte var26 = 36;
            yield var26;
         }
         case 12 -> {
            byte var27 = 2;
            yield var27;
         }
         case 13 -> {
            byte var28 = 5;
            yield var28;
         }
         case 14 -> {
            byte var29 = 62;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 49;
            yield var31;
         }
         case 17 -> {
            byte var32 = 16;
            yield var32;
         }
         case 18 -> {
            byte var33 = 27;
            yield var33;
         }
         case 19 -> {
            byte var34 = 31;
            yield var34;
         }
         case 20 -> {
            byte var35 = 50;
            yield var35;
         }
         case 21 -> {
            byte var36 = 53;
            yield var36;
         }
         case 22 -> {
            byte var37 = 21;
            yield var37;
         }
         case 23 -> {
            byte var38 = 20;
            yield var38;
         }
         case 24 -> {
            byte var39 = 39;
            yield var39;
         }
         case 25 -> {
            byte var40 = 37;
            yield var40;
         }
         case 26 -> {
            byte var41 = 25;
            yield var41;
         }
         case 27 -> {
            byte var42 = 15;
            yield var42;
         }
         case 28 -> {
            byte var43 = 51;
            yield var43;
         }
         case 29 -> {
            byte var44 = 48;
            yield var44;
         }
         case 30 -> {
            byte var45 = 22;
            yield var45;
         }
         case 31 -> {
            byte var46 = 41;
            yield var46;
         }
         case 32 -> {
            byte var47 = 24;
            yield var47;
         }
         case 33 -> {
            byte var48 = 3;
            yield var48;
         }
         case 34 -> {
            byte var49 = 10;
            yield var49;
         }
         case 35 -> {
            byte var50 = 14;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 1;
            yield var53;
         }
         case 39 -> {
            byte var54 = 4;
            yield var54;
         }
         case 40 -> {
            byte var55 = 34;
            yield var55;
         }
         case 41 -> {
            byte var56 = 0;
            yield var56;
         }
         case 42 -> {
            byte var57 = 43;
            yield var57;
         }
         case 43 -> {
            byte var58 = 47;
            yield var58;
         }
         case 44 -> {
            byte var59 = 23;
            yield var59;
         }
         case 45 -> {
            byte var60 = 35;
            yield var60;
         }
         case 46 -> {
            byte var61 = 8;
            yield var61;
         }
         case 47 -> {
            byte var62 = 54;
            yield var62;
         }
         case 48 -> {
            byte var63 = 42;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 33;
            yield var65;
         }
         case 51 -> {
            byte var66 = 46;
            yield var66;
         }
         case 52 -> {
            byte var67 = 28;
            yield var67;
         }
         case 53 -> {
            byte var68 = 17;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 26;
            yield var71;
         }
         case 57 -> {
            byte var72 = 11;
            yield var72;
         }
         case 58 -> {
            byte var73 = 63;
            yield var73;
         }
         case 59 -> {
            byte var74 = 6;
            yield var74;
         }
         case 60 -> {
            byte var75 = 18;
            yield var75;
         }
         case 61 -> {
            byte var76 = 9;
            yield var76;
         }
         case 62 -> {
            byte var77 = 56;
            yield var77;
         }
         default -> 19;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            h[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      g[0] = "\u0007\tw\u0002\b6\u0011\trX\u001b!\u0006Bq^\u00175\u0017\u0005fI\\'\u0013";
      g[1] = "_~7\n/5*^<\u0005>zKP7\u000e: ?";
      g[2] = "\u000e\t\u0007Oov\u000e\t\u0010\u0013cy\u0014B\u0010\rcl\u00133AV;.";
      g[3] = "(<}\u0007\u001b\r]\u001cv\b\nB<\u0012}\u0003\u000e\u0018H";
      g[4] = boolean.class;
      h[4] = "java/lang/Boolean";
      g[5] = ".`Kvw,8`N,d;/+M*h/>lZ=#=\u000f";
      g[6] = int.class;
      h[6] = "java/lang/Integer";
      g[7] = "0KH\u0014iZ.CR[$@4IK\u00075J4^\u0010\u00143@7C][\u0006[5GW\u0016\u0015J<OL\u0010)L?kL\u0007&V";
      g[8] = "qK#\u0012;`zD2]ZnqO6\u0007";
      g[9] = "$Q\u00026re/^\u0013y\u0011h:S\u001c\u0012$j+@\u0000>3g";
      g[10] = "\u007f\u001c2~%ti\u001c7$6c~W4\":wo\u0010#5qG";
      g[11] = "M\u00186\u0007$888=\b5wY66\u00031--";
      g[12] = "g=d$JDg=sxFK}vsfF^z\u0007#;\u0017";
      g[13] = "\\\fQtkg\\\fF(ghFGF6g}A6\u0013i>";
      g[14] = "\u000bte:7I~Tn5&\u0006\u001fZe>\"\\k";
      g[15] = "v\u0002\b]o}`\u0002\r\u0007|jwI\u000e\u0001p~f\u000e\u0019\u0016;O";
      g[16] = "tJ\f9'H\u0001j\u000766\u0007`d\f=2]\u0014";
      g[17] = "0IFu+\u00050IQ)'\n*\u0002Q7'\u001f-s\u0004hwH=@S(53m\u001a\nj";
      g[18] = "$\u0003W\u0005[H$\u0003@YWG>H@GWR99\u0015\u0018\u0007";
      g[19] = "+\r\u000bE{'+\r\u001c\u0019w(1F\u001c\u0007w=67NR$}";
      g[20] = "K3\u0004=QJDv]\u0005Z;\u00103\flY\u0007\u001b'\u0006\u007f3\u0000\u00152\riQ\u0001\u0015r[\u0005";
      g[21] = "XRP\u001d,/\u0011L\u0011\u001b\\tc\n\u0003\u0018gx\rF\u0005\u0000<\u001e";
      g[22] = "\t\u0000k.\u00013\u001bLtgb+\u000f\u000eo8\u000e\u0019[H6eYN^\u001bjd\u0004 \u0012\u001dr?br\u000b\u001749\f>\r\u000fo_Y!\u001aBc=X!Z\u0014\u000f";
      g[23] = "\b,)\u001f\tY\u001f0/\u0016v\u0006\u0005< \u001a!Y]a|vJ\u0001\u0001j\"\u0018\u0006\u0007\u00191";
      g[24] = "yz:\t\u0004J$>{Fa\u001b):\u0003J\b\u0011\u007f m\u0006\u000e\t$F>\n\u0010\u0017{}9K\u0006\u0012D";
      g[25] = "\u001fNj\u0003Gr\u0015A*\u0019<qNFv\fk&\u0011\u001b-`\rxUEw\u0007Zb\u0017M";
      g[26] = "m\u0007c%gOz\u001be,\u0018\u0010`\u0017j OO8J7L$\u0017dAh\"h\u0011|\u001a";
      g[27] = "C<`\u0000\u0010\u0001Ly98\u001bpL( [\u001d\u001a\u0003z$ZrN\u001f<:W\u0018\u0001M8;8";
      g[28] = "r\u0013Tp.6}V\rH%G)\u0013\\!&{\"\u0007V2L~$\u0004\tv/*y\u0011\u0002H";
      g[29] = "XR&\u0019Hh\f\u000f3\u0012vn\fI(\u001a\u001a\\X\u000fpEJ\u000b\rH%\u0014\t:\u001aT#\u001dv";
      g[30] = "lQ\n.%j=[\r1OmSR\u0015}&noY\u0001w5\u0004n\u0004U3*:3@\u0014|O";
      g[31] = "\u000e3\b|\u0000\u0000\\)\f~l\u0010g'\u00151\u0005\u0013[,\u0001;\u0016y\r6\\m\u000f\u0012\u0005+\u0012`l";
      g[32] = "\u0007R\u00195\u00071PH[=b3[I\u0003<\u000e\u0001\f\u0004Xfb=DQ\u00128\u001f/\bN[[";
      g[33] = "nf`\u0005_23\"!J:h><6\u0006Z\fo3<A\\b#5$\u001a:";
      g[34] = " )h\u007fq\u0005/l1Gyt{)`.yHp=j=\u0013Mv>5yp\u0019++>G";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = g[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = h[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            g[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  g[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(592320316287047L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = h[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  g[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(592320316287047L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        g[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(592320316287047L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 230;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 115;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 206;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 194;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 205;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 245;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 230;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 115;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 206;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ap_C0034",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ap" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
