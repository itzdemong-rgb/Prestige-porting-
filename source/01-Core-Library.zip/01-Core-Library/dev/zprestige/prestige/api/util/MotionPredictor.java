package dev.zprestige.prestige.api.util;
import net.minecraft.block.BlockState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.Vec3d;

public class MotionPredictor implements MinecraftAccess {
   private final ElapsedTimer a;
   public Vec3d b;
   public Vec3d c;
   public Vec3d d;
   public Vec3d e;
   public final CollisionProbe f;
   public final MotionPredictionMode g;
   private static final long h = 36390223127766L;
   private static final Object[] i = new Object[32];
   private static final String[] j = new String[32];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;

   public MotionPredictor(Vec3d var1, Vec3d var2, MotionPredictionMode var3, long var4) {
      super();
      var4 = 36390223127766L ^ var4;
      long var6 = var4 ^ 121386424150213L;
      long var8 = var4 ^ 45740088391660L;
      long var10 = var4 ^ 43679926936234L;

      this.a = new ElapsedTimer(var6);
      this.b = var1;
      this.c = var2;
      this.e = var2;
      this.d = new Vec3d((Math.random() * 0.5 - 0.25) * 0.01, Math.random() * 0.25 * 0.01, (Math.random() * 0.5 - 0.25) * 0.01);
      this.g = var3;
      Object[] var13 = new Object[]{var10};
      MotionPredictor var12 = this;
      this.f = var12.aReturningbY_C0105(var13);
      ElapsedTimer var10000 = this.a;
      Object[] var15 = new Object[]{var8};
      ElapsedTimer var14 = var10000;
      var14.aReturningVoid(var15);
   }

   private CollisionProbe aReturningbY_C0105(Object[] var1) {
      long var2 = (Long)var1[0];
      MotionPredictionMode var4 = this.g;
      int var6 = var4.ordinal();

      long var10000 = 36390223127766L ^ var2;
      return switch (var6) {
         case 0 -> {
            HeadCollisionProbe var7 = new HeadCollisionProbe();
            yield var7;
         }
         case 1 -> new FeetCollisionProbe();
         default -> throw new MatchException(null, null);
      };
   }

   public void aReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      long var3 = (Long)var1[1];
      var3 = 36390223127766L ^ var3;
      long var5 = var3 ^ 130708139192015L;
      this.e = this.c;
      CollisionProbe var10000 = this.f;
      Object[] var10005 = new Object[]{null, null, var5};
      var10005[1] = var2;
      var10005[0] = this;
      Object[] var8 = var10005;
      CollisionProbe var7 = var10000;
      var7.aReturningVoid(var8);
   }

   public float aReturningFloat(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 36390223127766L ^ var2;
      long var5 = var2 ^ 79978194856661L;
      ElapsedTimer var10001 = this.a;
      Object[] var8 = new Object[]{var5};
      ElapsedTimer var7 = var10001;
      float var10 = var7.aReturningFloat(var8) / var4;
      float var9 = 1.0F;
      return Math.min(var9, var10);
   }

   public Vec3d aReturningVec3d(Object[] var1) {
      return this.e;
   }

   public Vec3d bReturningVec3d(Object[] var1) {
      return this.c;
   }

   public Vec3d cReturningVec3d(Object[] var1) {
      return this.d;
   }

   public ElapsedTimer aReturningfY_C0319(Object[] var1) {
      return this.a;
   }

   public MotionPredictionMode aReturningq_C0434(Object[] var1) {
      return this.g;
   }

    private static boolean aReturningBoolean(Object[] objectArray) {
        int n;
        block10: {
            block12: {
                block11: {
                    BlockState blockState = (BlockState)objectArray[0];
                    long l = (Long)objectArray[1];
                    l = 0x2118C252A4D6L ^ l;
                    int n2 = MotionPredictor.invokeBinding1(-7362192857268466475L, l);
                    try {
                        try {
                            try {
                                try {
                                    try {
                                        n = (((MotionPredictor.invokeBinding2(blockState, -7361677093268329347L, l)) ? 1 : 0));
                                        if (n2 != 0) break block10;
                                        if (n != 0) break block11;
                                    }
                                    catch (MatchException matchException) {
                                        throw MotionPredictor.invokeBinding3(matchException, -7361180031665345827L, l);
                                    }
                                    n = (((MotionPredictor.invokeBinding4(blockState, -7361557452846619388L, l)) ? 1 : 0));
                                    if (n2 != 0) break block10;
                                }
                                catch (MatchException matchException) {
                                    throw MotionPredictor.invokeBinding5(matchException, -7361180031665345827L, l);
                                }
                                if (n != 0) break block11;
                            }
                            catch (MatchException matchException) {
                                throw MotionPredictor.invokeBinding6(matchException, -7361180031665345827L, l);
                            }
                            n = (((MotionPredictor.invokeBinding8(MotionPredictor.invokeBinding7(blockState, -7361701333384954929L, l), -7361467627151970203L, l)) ? 1 : 0));
                            if (n2 != 0) break block10;
                        }
                        catch (MatchException matchException) {
                            throw MotionPredictor.invokeBinding9(matchException, -7361180031665345827L, l);
                        }
                        if (n != 0) break block12;
                    }
                    catch (MatchException matchException) {
                        throw MotionPredictor.invokeBinding10(matchException, -7361180031665345827L, l);
                    }
                }
                n = 1;
                break block10;
            }
            n = 0;
        }
        return n != 0;
    }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 39;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 38;
            yield var18;
         }
         case 4 -> {
            byte var19 = 0;
            yield var19;
         }
         case 5 -> {
            byte var20 = 37;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 34;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 13;
            yield var24;
         }
         case 10 -> {
            byte var25 = 44;
            yield var25;
         }
         case 11 -> {
            byte var26 = 28;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 58;
            yield var28;
         }
         case 14 -> {
            byte var29 = 1;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 18;
            yield var31;
         }
         case 17 -> {
            byte var32 = 12;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 25;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 51;
            yield var36;
         }
         case 22 -> {
            byte var37 = 50;
            yield var37;
         }
         case 23 -> {
            byte var38 = 57;
            yield var38;
         }
         case 24 -> {
            byte var39 = 41;
            yield var39;
         }
         case 25 -> {
            byte var40 = 63;
            yield var40;
         }
         case 26 -> {
            byte var41 = 49;
            yield var41;
         }
         case 27 -> {
            byte var42 = 22;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 9;
            yield var44;
         }
         case 30 -> {
            byte var45 = 7;
            yield var45;
         }
         case 31 -> {
            byte var46 = 43;
            yield var46;
         }
         case 32 -> {
            byte var47 = 40;
            yield var47;
         }
         case 33 -> {
            byte var48 = 56;
            yield var48;
         }
         case 34 -> {
            byte var49 = 11;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 61;
            yield var53;
         }
         case 39 -> {
            byte var54 = 8;
            yield var54;
         }
         case 40 -> {
            byte var55 = 55;
            yield var55;
         }
         case 41 -> {
            byte var56 = 30;
            yield var56;
         }
         case 42 -> {
            byte var57 = 59;
            yield var57;
         }
         case 43 -> {
            byte var58 = 23;
            yield var58;
         }
         case 44 -> {
            byte var59 = 3;
            yield var59;
         }
         case 45 -> {
            byte var60 = 29;
            yield var60;
         }
         case 46 -> {
            byte var61 = 15;
            yield var61;
         }
         case 47 -> {
            byte var62 = 62;
            yield var62;
         }
         case 48 -> {
            byte var63 = 10;
            yield var63;
         }
         case 49 -> {
            byte var64 = 16;
            yield var64;
         }
         case 50 -> {
            byte var65 = 36;
            yield var65;
         }
         case 51 -> {
            byte var66 = 35;
            yield var66;
         }
         case 52 -> {
            byte var67 = 31;
            yield var67;
         }
         case 53 -> {
            byte var68 = 2;
            yield var68;
         }
         case 54 -> {
            byte var69 = 26;
            yield var69;
         }
         case 55 -> {
            byte var70 = 5;
            yield var70;
         }
         case 56 -> {
            byte var71 = 6;
            yield var71;
         }
         case 57 -> {
            byte var72 = 19;
            yield var72;
         }
         case 58 -> {
            byte var73 = 27;
            yield var73;
         }
         case 59 -> {
            byte var74 = 45;
            yield var74;
         }
         case 60 -> {
            byte var75 = 53;
            yield var75;
         }
         case 61 -> {
            byte var76 = 47;
            yield var76;
         }
         case 62 -> {
            byte var77 = 4;
            yield var77;
         }
         default -> 42;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "\"\u00072Z\u0010\u001a4\u00077\u0000\u0003\r#L4\u0006\u000f\u00192\u000b#\u0011D\b\u001e";
      i[1] = "s-t/\n.\u0006\r\u007f \u001bag\u0003t+\u001f;\u0013";
      i[2] = "~\tsO&3h\tv\u00155$\u007fBu\u001390n\u0005b\u0004r!C";
      i[3] = "\u0005\u0019Y\u000b\u001bK\u0013\u0019\\Q\b\\\u0004R_W\u0004H\u0015\u0015H@O]8";
      i[4] = "\u0000\rv\u0017+\tu-}\u0018:F\u0014#v\u0013>\u001c`";
      i[5] = void.class;
      j[5] = "java/lang/Void";
      i[6] = "Z\u0006w\n0;Q\tfES6D\u000f";
      i[7] = double.class;
      j[7] = "java/lang/Double";
      i[8] = float.class;
      j[8] = "java/lang/Float";
      i[9] = "}^\u0017\u0017!}\b~\u001c\u001802ip\u0017\u00134h\u001d";
      i[10] = "M@\u007fQ4,M@h\r8#W\u000bh\u001386Pz9Iau";
      i[11] = "\n~?\u0007G\u007f\n~([Kp\u00105(EKe\u0017Dx\u001f\u001b&";
      i[12] = "3)?Rv@%):\beW2b9\u000eiC#%.\u0019\"Q\u0012";
      i[13] = int.class;
      j[13] = "java/lang/Integer";
      i[14] = "p\u0004jB'`{\u000b{\rDmn\u0006tfqo\u007f\u0015hJfb";
      i[15] = boolean.class;
      j[15] = "java/lang/Boolean";
      i[16] = "i7\"6?U\u001c\u0017)9.\u001a}\u0019\"2*@\t";
      i[17] = "\ntN`?R\u001ctK:,E\u000b?H< Q\u001ax_+kS";
      i[18] = "c\u0003\u0005Wudh\f\u0014\u0018\u0014jc\u0007\u0010B";
      i[19] = "5P%F^a4]*O7tgN;C[F0\fa\u001e\b\u00115L5\u0018\\ck]1O7";
      i[20] = "\u0012V\u0018\u0012\u0011vR\u0016\r\u0012|,\"\u001bV\u0010M,\u001eQ\\W\u001bF";
      i[21] = "^\u001e^Q^$Y\u0003C\r4 \u0003\u0001 P\n/\u0001\u000bE\n\u000b)\\g\u001eP^&\u000e\u0002DQX{bY\u001e\u0004W)\u0007\u0003\u001f\u0002\nE";
      i[22] = "}C\n#\u0002s)\\_ac DI\u00028\u0004v+CX0\u001eI\u007f^\u001b>Z+!^\u001f c";
      i[23] = "\u0003.U\u00177UP3K\u001dVM\u0012.N\u001d?Nhs\u001f\u0002g@T9\u0015E1*";
      i[24] = "#FE&3gsOVL`\r(JX+6b\"\u0010P1\t4\"BC-3`=\u0017\u0001L";
      i[25] = "'qq#)Qbbz|S]\u001dwq\"4\u000br}+*.4##|&?Qy\"z{S";
      i[26] = "s9\u001eg#\r6*\u00158Y\u0001I?\u001ef>W&5Dn$hr(\u0007``\n,(\u0003~Y";
      i[27] = "\u007fy0$\u00035/p#NP_w(-pI:lsp496$ut>\\-\u007f(0N";
      i[28] = "<),'P\n=$#.9\u001fn72\"U-9uh|\u0004zj%17FF9p5;9";
      i[29] = "=:\u007f`&[<7piONo$ae#|>e==s+k6bp0\u00178cf|O";
      i[30] = "[\u001bMj.r\\\u0006P6Di\u000e\u0004_2!\u0013[\u0012P<%n^]\fiD";
      i[31] = "qF75G\u007f/W3b,h#D9n@Zw\u0005f7\u001d\r'V:{S1t\u0003>w,";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1325151796132901L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1325151796132901L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1325151796132901L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 97;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 186;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 80;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 201;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 70;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 36;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 97;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 186;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 80;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bX_C0103",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = a(MethodHandles.lookup(), "$", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static boolean invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = a(MethodHandles.lookup(), "F", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = a(
                  MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = a(MethodHandles.lookup(), "F", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = a(
                  MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = a(
                  MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static FluidState invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = a(
                  MethodHandles.lookup(), "F", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/fluid/FluidState;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (FluidState)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = a(MethodHandles.lookup(), "F", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = a(
                  MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = a(
                  MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
