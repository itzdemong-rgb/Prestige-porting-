package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;

public final class MovementEvaluationUtil {
   private static final MinecraftClient a;
   private static final int b;
   private static final double c = 5.0;
   public static final PredictionResult d;
   private static final long e = 64296296389639L;
   private static final Object[] f = new Object[82];
   private static final String[] g = new String[82];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   private MovementEvaluationUtil() {
   }

   public static PredictionResult aReturningfX_C0317(Object[] var0) {
      PlayerEntity var1 = (PlayerEntity)var0[0];
      EnumSet var5 = (EnumSet)var0[1];
      float var4 = (Float)var0[2];
      long var2 = (Long)var0[3];
      var2 = 64296296389639L ^ var2;
      long var6 = var2 ^ 56944638229350L;
      long var8 = var2 ^ 63285559196502L;
      long var10 = var2 ^ 58185350754582L;
      long var12 = var2 ^ 69895823586459L;
      long var14 = var2 ^ 89366409843443L;
      int var16 = Event.cReturningInt();
      int var91 = var16;
      MinecraftClient var90 = a;
      MinecraftClient var80 = var90;
      MinecraftClient var79 = var90;
      if (var91 != 0) {
         MinecraftClient var22 = var79;
         ClientPlayerEntity var92 = var22.player;
         if (var92 == null) {
            return d;
         }

         MinecraftClient var93 = a;
         var80 = var93;
      }

      MinecraftClient var25 = var80;
      ClientWorld var94 = var25.world;
      if (var94 != null) {
         PlayerEntity var95 = var1;
         if (var95 != null) {
            PredictionResult var17;
            boolean var83;
            var17 = d;
            PredictionType var29 = PredictionType.CRYSTAL;
            EnumSet var28 = var5;
            boolean var10000 = var28.contains(var29);
            int var97 = var16;
            boolean var96 = var10000;
            var83 = var96;
            boolean var81 = var96;
            label100:
            if (var97 != 0) {
               boolean var98 = var81;
               if (var98) {
                  MinecraftClient var31 = a;
                  ClientWorld var32 = var31.world;
                  Iterable var33 = var32.getEntities();
                  Iterator var18 = var33.iterator();

                  while (true) {
                     Iterator var34 = var18;
                     boolean var99 = var34.hasNext();
                     if (!var99) {
                        break;
                     }

                     Iterator var35 = var18;
                     Entity var19 = (Entity)var35.next();
                     var10000 = var19 instanceof EndCrystalEntity;
                     int var101 = var16;
                     boolean var100 = var10000;
                     var83 = var100;
                     boolean var82 = var100;
                     if (var101 == 0) {
                        break label100;
                     }

                     boolean var102 = var82;
                     if (!var102) {
                        int var103 = var16;
                        if (var103 != 0) {
                           continue;
                        }
                     }

                     ExplosionDamageUtil var133 = Prestige.f;
                     MinecraftClient var38 = a;
                     ClientPlayerEntity var10001 = var38.player;
                     Entity var39 = var19;
                     BlockPos var40 = var39.getBlockPos();
                     Object[] var42 = new Object[]{var10001, var40.toCenterPos(), var12};
                     ExplosionDamageUtil var41 = var133;
                     float var20 = (float)var41.aReturningDouble(var42);
                     PredictionType var137 = PredictionType.CRYSTAL;
                     Object[] var10006 = new Object[]{null, null, null, null, var6};
                     var10006[3] = var4;
                     var10006[2] = var20;
                     var10006[1] = var137;
                     var10006[0] = var17;
                     Object[] var43 = var10006;
                     var17 = c(var43);
                     int var104 = var16;
                     if (var104 == 0) {
                        break;
                     }
                  }
               }

               PredictionType var45 = PredictionType.ANCHOR;
               EnumSet var44 = var5;
               var83 = var44.contains(var45);
            }

            boolean var89;
            label82: {
               label112: {
                  int var106 = var16;
                  boolean var105 = var83;
                  boolean var85 = var105;
                  boolean var84 = var105;
                  if (var106 != 0) {
                     boolean var107 = var84;
                     if (var107) {
                        Object[] var10004 = new Object[]{null, invokeBinding1(var1), var14};
                        var10004[0] = 5;
                        Object[] var47 = var10004;
                        List var124 = BlockUtil.aReturningList(var47);
                        List var48 = var124;
                        Iterator var127 = var48.iterator();

                        int var110;
                        do {
                           Iterator var49 = var127;
                           boolean var108 = var49.hasNext();
                           if (!var108) {
                              break;
                           }

                           Iterator var50 = var127;
                           BlockPos var129 = (BlockPos)var50.next();
                           ExplosionDamageUtil var134 = Prestige.f;
                           MinecraftClient var51 = a;
                           BlockPos var52 = var129;
                           Object[] var54 = new Object[]{var51.player, var52.toCenterPos(), var10};
                           ExplosionDamageUtil var53 = var134;
                           float var21 = (float)var53.kReturningVoid(var54);
                           PredictionType var138 = PredictionType.ANCHOR;
                           Object[] var143 = new Object[]{null, null, null, null, var6};
                           var143[3] = var4;
                           var143[2] = var21;
                           var143[1] = var138;
                           var143[0] = var17;
                           Object[] var55 = var143;
                           var17 = c(var55);
                           int var109 = var16;
                           if (var109 == 0) {
                              break label112;
                           }

                           var110 = var16;
                        } while (var110 != 0);
                     }

                     PredictionType var58 = PredictionType.OBSIDIAN;
                     EnumSet var57 = var5;
                     var85 = var57.contains(var58);
                  }

                  int var112 = var16;
                  boolean var111 = var85;
                  var89 = var111;
                  boolean var86 = var111;
                  if (var112 == 0) {
                     break label82;
                  }

                  boolean var113 = var86;
                  if (var113) {
                     MinecraftClient var60 = a;
                     ClientPlayerEntity var61 = var60.player;
                     var10000 = var61.isOnGround();
                     int var115 = var16;
                     boolean var114 = var10000;
                     var89 = var114;
                     boolean var87 = var114;
                     if (var115 == 0) {
                        break label82;
                     }

                     boolean var116 = var87;
                     boolean var88 = var116;
                     boolean var117 = var88;
                     if (!var117) {
                        Object[] var142 = new Object[]{null, invokeBinding2(var1), var14};
                        var142[0] = 5;
                        Object[] var64 = var142;
                        List var125 = BlockUtil.aReturningList(var64);
                        List var65 = var125;
                        Iterator var128 = var65.iterator();

                        int var120;
                        do {
                           Iterator var66 = var128;
                           boolean var118 = var66.hasNext();
                           if (!var118) {
                              break;
                           }

                           Iterator var67 = var128;
                           BlockPos var130 = (BlockPos)var67.next();
                           ExplosionDamageUtil var136 = Prestige.f;
                           MinecraftClient var68 = a;
                           ClientPlayerEntity var139 = var68.player;
                           BlockPos var69 = var130;
                           BlockPos var70 = var69.up();
                           Object[] var72 = new Object[]{var139, var70.toCenterPos(), var12};
                           ExplosionDamageUtil var71 = var136;
                           float var131 = (float)var71.aReturningDouble(var72);
                           PredictionType var140 = PredictionType.OBSIDIAN;
                           Object[] var144 = new Object[]{null, null, null, null, var6};
                           var144[3] = var4;
                           var144[2] = var131;
                           var144[1] = var140;
                           var144[0] = var17;
                           Object[] var73 = var144;
                           var17 = c(var73);
                           int var119 = var16;
                           if (var119 == 0) {
                              return var17;
                           }

                           var120 = var16;
                        } while (var120 != 0);
                     }
                  }
               }

               PredictionType var76 = PredictionType.MACE;
               EnumSet var75 = var5;
               var89 = var75.contains(var76);
            }

            boolean var121 = var89;
            if (var121) {
               Object[] var77 = new Object[]{var1, var8};
               float var126 = aReturningFloat(var77);
               float var146;
               int var122 = (var146 = var126 - 0.0F) == 0.0F ? 0 : (var146 < 0.0F ? -1 : 1);
               if (var122 > 0) {
                  PredictionType var141 = PredictionType.MACE;
                  Object[] var145 = new Object[]{null, null, null, null, var6};
                  var145[3] = var4;
                  var145[2] = var126;
                  var145[1] = var141;
                  var145[0] = var17;
                  Object[] var78 = var145;
                  var17 = c(var78);
               }
            }

            return var17;
         }
      }

      return d;
   }

   public static PredictionResult b(Object[] var0) {
      PlayerEntity var4 = (PlayerEntity)var0[0];
      EnumSet var3 = (EnumSet)var0[1];
      long var1 = (Long)var0[2];
      var1 = 64296296389639L ^ var1;
      long var5 = var1 ^ 119005175646106L;
      Object[] var10005 = new Object[]{null, null, null, var5};
      var10005[2] = 1.0F;
      var10005[1] = var3;
      var10005[0] = var4;
      Object[] var7 = var10005;
      return aReturningfX_C0317(var7);
   }

   public static float aReturningFloat(Object[] var0) {
      PlayerEntity var3 = (PlayerEntity)var0[0];
      long var1 = (Long)var0[1];
      var1 = 64296296389639L ^ var1;
      long var4 = var1 ^ 63464575927444L;
      int var6 = Event.bReturningInt();
      PlayerEntity var7 = var3;
      Object[] var8 = new Object[]{var7.getMainHandStack(), var4};
      byte var10000 = ((byte)((InventoryUtil.o(var8)) ? 1 : 0));
      int var37 = var6;
      byte var36 = var10000;
      int var21 = var36;
      byte var20 = var36;
      if (var37 == 0) {
         byte var38 = var20;
         if (var38 == 0) {
            return 0.0F;
         }

         PlayerEntity var10 = var3;
         double var56;
         int var39 = (var56 = var10.fallDistance - 1.5) == 0.0 ? 0 : (var56 < 0.0 ? -1 : 1);
         var21 = var39;
      }

      int var41 = var6;
      int var40 = var21;
      int var31 = var40;
      int var22 = var40;
      if (var41 == 0) {
         int var42 = var22;
         if (var42 <= 0) {
            return 0.0F;
         }

         PlayerEntity var13 = var3;
         double var55 = var13.getY();
         MinecraftClient var14 = a;
         ClientPlayerEntity var15 = var14.player;
         double var10001 = var15.getY();
         int var47 = var6;
         double var45 = var10001;
         double var43 = var55;
         double var32 = var43;
         double var34 = var45;
         double var23 = var43;
         double var25 = var45;
         if (var47 != 0) {
            return (float)(var32 + var34);
         }

         double var50 = var25;
         double var48 = var23;
         double var27 = var48;
         double var29 = var50;
         double var57;
         int var52 = (var57 = var27 - var29) == 0.0 ? 0 : (var57 < 0.0 ? -1 : 1);
         var31 = var52;
      }

      int var53 = var31;
      if (var53 <= 0) {
         return 0.0F;
      }

      PlayerEntity var19 = var3;
      double var59 = var19.fallDistance * 5.0;
      double var58 = 6.0;
      return (float)(var58 + var59);
   }

   private static boolean aReturningBoolean(Object[] var0) {
      PlayerEntity var2 = (PlayerEntity)var0[0];
      BlockPos var1 = (BlockPos)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 64296296389639L ^ var3;
      int var5 = Event.cReturningInt();
      BlockPos var6 = var1;
      double var10001 = var6.getX() + 0.5;
      BlockPos var7 = var1;
      double var10002 = var7.getY() + 0.5;
      BlockPos var8 = var1;
      double var14 = var8.getZ() + 0.5;
      double var12 = var10002;
      double var10 = var10001;
      PlayerEntity var9 = var2;
      double var24;
      int var23 = (var24 = var9.squaredDistanceTo(var10, var12, var14) - 25.0) == 0.0 ? 0 : (var24 < 0.0 ? -1 : 1);
      int var20 = var5;
      int var19 = var23;
      int var17 = var19;
      int var16 = var19;
      if (var20 != 0) {
         int var21 = var16;
         if (var21 >= 0) {
            return false;
         }

         var17 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var17);
   }

   private static PredictionResult c(Object[] var0) {
      PredictionResult var4 = (PredictionResult)var0[0];
      PredictionType var2 = (PredictionType)var0[1];
      float var3 = (Float)var0[2];
      float var1 = (Float)var0[3];
      long var5 = (Long)var0[4];
      long var10000 = 64296296389639L ^ var5;
      int var7 = Event.cReturningInt();
      int var15 = var7;
      float var14 = 0.0F;
      float var13 = var3;
      float var11 = var13;
      float var12 = var14;
      float var9 = var13;
      float var10 = var14;
      if (var15 != 0) {
         float var19;
         int var16 = (var19 = var9 - var10) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
         if (var16 <= 0) {
            return var4;
         }

         float var18 = var3 * var2.confidence;
         var12 = var1;
         var11 = var18;
      }

      float var8 = var11 * var12;
      float var20;
      int var17 = (var20 = var8 - var4.c) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
      return var17 <= 0 ? var4 : new PredictionResult(var2, var3, var8);
   }

   private static boolean lambda$evaluate$1(PlayerEntity var0, BlockPos var1) {
      long var10001 = 139068421595221L ^ 59277794899499L;
      int var6 = Event.cReturningInt();
      BlockPos var7 = var1;
      double var10000 = var7.getY();
      MinecraftClient var8 = a;
      ClientPlayerEntity var9 = var8.player;
      double var54;
      int var50 = (var54 = var10000 - var9.getY()) == 0.0 ? 0 : (var54 < 0.0 ? -1 : 1);
      int var34 = var6;
      int var33 = var50;
      int var25 = var33;
      int var24 = var33;
      if (var34 != 0) {
         int var35 = var24;
         if (var35 >= 0) {
            return false;
         }

         Object[] var11 = new Object[]{var0, var1, 83093863405182L};
         byte var36 = ((byte)((aReturningBoolean(var11)) ? 1 : 0));
         var25 = var36;
      }

      int var37 = var25;
      if (var37 != 0) {
         MinecraftClient var13 = a;
         BlockPos var15 = var1;
         ClientWorld var14 = var13.world;
         BlockState var16 = var14.getBlockState(var15);
         Block var51 = var16.getBlock();
         int var40 = var6;
         Block var39 = Blocks.OBSIDIAN;
         Block var38 = var51;
         Block var30 = var38;
         Block var31 = var39;
         Block var26 = var38;
         Block var27 = var39;
         if (var40 != 0) {
            Block var42 = var27;
            Block var41 = var26;
            Block var28 = var41;
            Block var29 = var42;
            Block var44 = var29;
            Block var43 = var28;
            if (var43 != var44) {
               return false;
            }

            MinecraftClient var19 = a;
            ClientWorld var52 = var19.world;
            BlockPos var20 = var1;
            BlockPos var22 = var20.up();
            ClientWorld var21 = var52;
            BlockState var23 = var21.getBlockState(var22);
            Block var53 = var23.getBlock();
            Block var46 = Blocks.AIR;
            Block var45 = var53;
            var30 = var45;
            var31 = var46;
         }

         Block var48 = var31;
         Block var47 = var30;
         if (var47 == var48) {
            return true;
         }
      }

      return false;
   }

   private static boolean lambda$evaluate$0(PlayerEntity var0, BlockPos var1) {
      long var10001 = 22721370134698L ^ 104698267045588L;
      int var6 = Event.bReturningInt();
      Object[] var7 = new Object[]{var0, var1, 83093863405182L};
      boolean var27 = aReturningBoolean(var7);
      if (var27) {
         MinecraftClient var8 = a;
         BlockPos var10 = var1;
         ClientWorld var9 = var8.world;
         BlockState var10000 = var9.getBlockState(var10);
         int var29 = var6;
         BlockState var28 = var10000;
         BlockState var23 = var28;
         BlockState var21 = var28;
         if (var29 == 0) {
            BlockState var30 = var21;
            BlockState var22 = var30;
            BlockState var12 = var22;
            Block var38 = var12.getBlock();
            Block var32 = Blocks.RESPAWN_ANCHOR;
            Block var31 = var38;
            if (var31 != var32) {
               return false;
            }

            MinecraftClient var14 = a;
            BlockPos var16 = var1;
            ClientWorld var15 = var14.world;
            BlockState var33 = var15.getBlockState(var16);
            var23 = var33;
         }

         IntProperty var19 = Properties.CHARGES;
         BlockState var18 = var23;
         Integer var20 = (Integer)var18.get((Property)var19);
         int var39 = var20;
         int var35 = var6;
         int var34 = var39;
         int var25 = var34;
         int var24 = var34;
         if (var35 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var25);
         }

         int var36 = var24;
         if (var36 != 0) {
            byte var40 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var40);
         }
      }

      return false;
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(113554170714721L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 1153117063867280850L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)16L,
            (byte)4096L,
            (byte)1048753L,
            (byte)268480988L,
            (byte)68731132976L,
            (byte)17595170041920L,
            (byte)4504363530731565L,
            (byte)1153117063867280850L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // long var0 = var8;
      b = (int)var0;
      a = MinecraftClient.getInstance();
      d = new PredictionResult(null, 0.0F, 0.0F);
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 22;
            yield var15;
         }
         case 1 -> {
            byte var16 = 8;
            yield var16;
         }
         case 2 -> {
            byte var17 = 62;
            yield var17;
         }
         case 3 -> {
            byte var18 = 50;
            yield var18;
         }
         case 4 -> {
            byte var19 = 3;
            yield var19;
         }
         case 5 -> {
            byte var20 = 32;
            yield var20;
         }
         case 6 -> {
            byte var21 = 4;
            yield var21;
         }
         case 7 -> {
            byte var22 = 37;
            yield var22;
         }
         case 8 -> {
            byte var23 = 47;
            yield var23;
         }
         case 9 -> {
            byte var24 = 41;
            yield var24;
         }
         case 10 -> {
            byte var25 = 28;
            yield var25;
         }
         case 11 -> {
            byte var26 = 35;
            yield var26;
         }
         case 12 -> {
            byte var27 = 10;
            yield var27;
         }
         case 13 -> {
            byte var28 = 18;
            yield var28;
         }
         case 14 -> {
            byte var29 = 2;
            yield var29;
         }
         case 15 -> {
            byte var30 = 48;
            yield var30;
         }
         case 16 -> {
            byte var31 = 16;
            yield var31;
         }
         case 17 -> {
            byte var32 = 6;
            yield var32;
         }
         case 18 -> {
            byte var33 = 63;
            yield var33;
         }
         case 19 -> {
            byte var34 = 5;
            yield var34;
         }
         case 20 -> {
            byte var35 = 17;
            yield var35;
         }
         case 21 -> {
            byte var36 = 0;
            yield var36;
         }
         case 22 -> {
            byte var37 = 53;
            yield var37;
         }
         case 23 -> {
            byte var38 = 51;
            yield var38;
         }
         case 24 -> {
            byte var39 = 58;
            yield var39;
         }
         case 25 -> {
            byte var40 = 20;
            yield var40;
         }
         case 26 -> {
            byte var41 = 25;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 61;
            yield var43;
         }
         case 29 -> {
            byte var44 = 27;
            yield var44;
         }
         case 30 -> {
            byte var45 = 14;
            yield var45;
         }
         case 31 -> {
            byte var46 = 55;
            yield var46;
         }
         case 32 -> {
            byte var47 = 56;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 49;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 11;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 15;
            yield var53;
         }
         case 39 -> {
            byte var54 = 40;
            yield var54;
         }
         case 40 -> {
            byte var55 = 31;
            yield var55;
         }
         case 41 -> {
            byte var56 = 12;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 59;
            yield var58;
         }
         case 44 -> {
            byte var59 = 57;
            yield var59;
         }
         case 45 -> {
            byte var60 = 29;
            yield var60;
         }
         case 46 -> {
            byte var61 = 9;
            yield var61;
         }
         case 47 -> {
            byte var62 = 24;
            yield var62;
         }
         case 48 -> {
            byte var63 = 54;
            yield var63;
         }
         case 49 -> {
            byte var64 = 7;
            yield var64;
         }
         case 50 -> {
            byte var65 = 19;
            yield var65;
         }
         case 51 -> {
            byte var66 = 23;
            yield var66;
         }
         case 52 -> {
            byte var67 = 42;
            yield var67;
         }
         case 53 -> {
            byte var68 = 43;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 60;
            yield var70;
         }
         case 56 -> {
            byte var71 = 52;
            yield var71;
         }
         case 57 -> {
            byte var72 = 26;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 36;
            yield var74;
         }
         case 60 -> {
            byte var75 = 44;
            yield var75;
         }
         case 61 -> {
            byte var76 = 38;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 1;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "\u0001)\t\no>\u0001)\u001eVc1\u001bb\u001eHc$\u001c\u0013O\u00171o";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = "R~\\:\n\u001eD~Y`\u0019\tS5Zf\u0015\u001dBrMq^\ba";
      f[3] = "q|!w!hzs08Beo~?Swg~m#\u007f`j";
      f[4] = "\u001e50T3Q\b55\u000e F\u001f~6\b,R\u000e9!\u001fg@?";
      f[5] = "iU\u0012PE6iU\u0005\fI9s\u001e\u0005\u0012I,toWH\u001dh";
      f[6] = double.class;
      g[6] = "java/lang/Double";
      f[7] = "\u0015\u0014\u0004j(O`4\u000fe9\u0000\u0001:\u0004n=Zu";
      f[8] = "\u0018\t\\OJ;\u000e\tY\u0015Y,\u0019BZ\u0013U8\b\u0005M\u0004\u001e-$";
      f[9] = "\t\"\u001cI:||\u0002\u0017F+3\u001d\f\u001cM/ii";
      f[10] = boolean.class;
      g[10] = "java/lang/Boolean";
      f[11] = "\r\t)4Fo\r\t>hJ`\u0017B>vJu\u00103o(\u001f0";
      f[12] = "3a\r~\u007f\u00183a\u001a\"s\u0017)*\u001a<s\u0002.[Kb&I";
      f[13] = "0;\u0004<950;\u0013`5:*p\u0013~5/-\u0001B$ll";
      f[14] = "\u0019wX\u007f^+\u0019wO#R$\u0003<O=R1\u0004M\u001f`\u0003";
      f[15] = "~t\u00172(\u007f~t\u0000n$pd?\u0000p$ecNU/}";
      f[16] = "\u0005A(A:y\u0005A?\u001d6v\u001f\n?\u00036c\u0018{k[a";
      f[17] = "\u001aG8xAt\u0004O\"7*o\u0005K\u001d|\u001b";
      f[18] = "[I,9X\nPF=v9\u0004[M9,";
      f[19] = "HVuwW\u001bCYd80\u0003GEbt\u0015\u0012";
      f[20] = "9d\u0017\u000eAa'l\rA&`6w\u0000\u001b\u0000f";
      f[21] = "\u001c\u0013M\u001fTj\n\u0013HEG}\u001dXKCKi\f\u001f\\T\u0000{\u0000";
      f[22] = "2XkY\u000fUGx`V\u001e\u001a&vk]\u001a@R";
      f[23] = "f\"?Qx\u000ep\":\u000bk\u0019gi9\rg\rv..\u001a,\u001fn";
      f[24] = "eKF\u001dqR\u0010kM\u0012`\u001dqeF\u0019dG\u0005";
      f[25] = "z$O\u000fggd,U@\u0005{c1";
      f[26] = "vy:\u0015\u0019kvy-I\u0015dl2-W\u0015qkC\u007f\tM5";
      f[27] = "_i`JnF_iw\u0016bIE\"w\bb\\BS&P0";
      f[28] = "Mzmd_>8ZfkNqYTm`J+-";
      f[29] = "(*b\u000fg7]\ni\u0000vx<\u0004b\u000br\"H";
      f[30] = float.class;
      g[30] = "java/lang/Float";
      f[31] = "%u\rl9%3u\b6*2$>\u000b0&&5y\u001c'm6-y\u001e,7{\u0011b\u001e17<&u";
      f[32] = "#2\u001f5\u000b\nV\u0012\u0014:\u001aE7\u001c\u001f1\u001e\u001fC";
      f[33] = "\nCMFA$\u001cCH\u001cR3\u000b\bK\u001a^'\u001aO\\\r\u00157\u0001";
      f[34] = "r1d\b.S\u0007\u0011o\u0007?\u001cf\u001fd\f;F\u0012";
      f[35] = "k{aNLyk{v\u0012@vq0v\f@cvA$W\u0018)";
      f[36] = "\u0016wxr\u0018.\u0016wo.\u0014!\f<o0\u00144\u000bM>kC~";
      f[37] = "t\u0002~\\76\u007f\ro\u0013Z5s\u0013iOx8r\u0006";
      f[38] = "<X9p\u001b)7W(?|+\"\\(tG";
      f[39] = "63\u001388\u000f63\u0004d4\u0000,x\u0004z4\u0015+\tU!aW";
      f[40] = "jh{H\u0019ejhl\u0014\u0015jp#l\n\u0015\u007fwR=QA4";
      f[41] = "*m;\u000f\u0010~lmm\u0014*-\u0013k0\u0005G#t`o[\u001bD,7x\u0010\u001b?uczR*";
      f[42] = "\u000e\u0006xlB\u0000A\t:+{\u0004RK'p\u00176\u0006\u000ey*GaGS:t\u001b]\u000f]v,{\u0019A\f~&K\u001cPJ6\u0017";
      f[43] = "\u0013MS\u001a\\8Y\f\u000f\u001b!c(K\u000f\u0019\u0018rUHXE_\t";
      f[44] = "Yfc\u0000!A\u0018%=^M^\u0007s7\u000b\u001a\t^#o_M\u0000\u0018w8X?A\u001b{h";
      f[45] = "\"cj\u0003\u001ft5hv{\u001bd7yc\u0017)0s#:G~0q&=\u0000\u00033&zz{";
      f[46] = "m0sR!y\"?1\u0015\u0018}1},NtOf?v\u0011$\u0018l\u007f%B'j-|)\u0012\u0018";
      f[47] = "#l)1\u0015jb/woyu}y}:.!'-$ly+b}ri\u000bjaq\"";
      f[48] = "\u0011tzWPLP7$\t<SOa.\\k\u0004\u00165p\f<\rPe!\u000fNLSiq";
      f[49] = ".jN\u001clX3w\u0000JR]2`FH.[4\rQM=Z#mV\\*^N";
      f[50] = "\u000f\rWc?\u0004EL\u000bbB^4\u000b\u000b`{NI\b\\<<5";
      f[51] = "V\t_<\n\u000e\\T\u0011k`\rQN\u0003e\f?\u0006\u000eS8Ph\u0003\t\u0011xQ\u0013Z]\u0013:`";
      f[52] = "*E81E)qCg2,>vG8l@\f\"\u0006e2,je[bb^1c\u0004a\u000b";
      f[53] = "%)D\u0003{\u00114pL\u001e\u0014K)0^\u0007xy~p\u0003Y).-6P\u0018uS:=L`";
      f[54] = "\u00144YR02\u0006 RWJk\u000b%v\u0006.w\u0000Y\u0011Uu3\u0016$\u0012\u0002)tm";
      f[55] = "'*_Y%m ;H]Hk'6L?#h-\u007fAV:f'(0";
      f[56] = "\n>NJ\rZQ8\u0011IdFZ-J\u001c3\u0011\u0004z\u0012p\u000e\u0013\u0007~D\u0016\u0004NI)";
      f[57] = ">\u001f>>\u0004Pb\u0013j<hUh\u001de`\u0004g8_96h\f;Ygn\u001aSo^o\u0007T\u000e=\u0003lu\u000bZ:\u000b\u0005;V\bg\bwd\u0002\u000foa99PRl\u0013fmWZ\u0005";
      f[58] = "\u001clz+\r \u001614|g#\u001b+&r\u000b\u0011Ll},WFJi~w\u000e4\u0015=y\u007fg";
      f[59] = "\u000bM)QiG\f\\>U\u0004G\u000fZ\u0000Zt[f\u001e}E~\u0016\u001dG)G<'";
      f[60] = "g\fW\n(%;\u0000\u0003\bD 1\u000e\fT(\u0012bJP\fD\"\"L\u0005\u0003+ym\r\b3";
      f[61] = "<aj|=\\-eh|\r^;%d}alfb>\"\rR,7|{pE'+\u0004+<\u0004-`ed3FjY";
      f[62] = "`Y/\u0004At&Yy\u001f{'Y_$\u000e\u0016)>T{PJN=\u0001!\u0002\u00107!\u0007!Z{";
      f[63] = "Jj=n\u001dFNy1bxKG}(b\u0019F[\u001b?n\u001f\u0019Qr&`\u0015N $oy\u0002\u0011[};{@ ";
      f[64] = "\r:\u0013:'p\u001b5\u00004Mwk3H) w\f8\u0017w|\u0010To\u0000<|k\r;\u0002~M";
      f[65] = "[N5\u00005'UR9\u001a\u000e8KE?\u0015r>M((\u0010a?ZH/\u0001v;7";
      f[66] = ")F\u0019FfCuJMD\nF\u007fDB\u0018ft(\u0003\u0019F:#.\u0006\u001a\u001dcQqR\u001d\u0015\n";
      f[67] = "1H\u000e\nL\u000b&C\u0012rH\u001b$R\u0007\u001ezO`\b^J-Ob\rY\tPL5Q\u001er";
      f[68] = "GPozcx\u0001P9aY+~\u000b4\u007f6?\u0013\f'b?BD[>p$/CH#yY";
      f[69] = "\t\u0006A\u0012I5O\u0006\u0017\tsf0\u0000J\u0018\u001ehW\u000b\u0015FB\u000f\r\u001d\u001b\u001d\td\u0001WO\u0016s";
      f[70] = "q=5#Srw/:y4\"\u001c(jpY,{#5.\u0005K qh}]9\u007f%ou4";
      f[71] = "\u001f\u0012Z)cm\u0002\u0002^8\u0001<p\u0017\u001c)l2\u0017\u001cCw0U\u0010\u0017T{?1\r\n\u001a-\u0001";
      f[72] = "\u0019\u0002k\u007f\u0013\u0005B\u00044|z\u0019I\u0011o)-N\u0016L4E\u0010OF\u001a;\"\u0001KD\u001a";
      f[73] = "h^sDe[\u007fUo<aK}DzPS\u001f9\u001c-\u0000\u0004O{Je]yXpV\u001d";
      f[74] = "\u0006=4/7\u0004\u00116(W3\u0014\u0013'=;\u0001EQzggV\u0018\u0015?+6(\u0015R?+W";
      f[75] = "g*\u000bW6\fp!\u0017/2\u001cr0\u0002C\u0000H6j[\u0014WH4o\\T*Kc3\u001b/";
      f[76] = "#\u0013\u001d$\u001cQ\u007f\u001fI&p_y\u0000Bq'\u000f T\u0019\u001dL\u000f \u000fOo\u0013['\u0007";
      f[77] = "[~n\r\u00142MqcU+c@-w\b|7\u001ay#[+v\u001c9#\u001dW3@!+";
      f[78] = "A$-S3\rG6\"\tTW,1r\u00009SK:-^e4\u0010hp\r=FO<w\u0005T";
      f[79] = "+\r\u0000L(B:\t\u0002L\u0018@,I\u000eMtrx\u0005W\u0013\"%-S\u001eV#[#O\u0012L\u0018";
      f[80] = "\u001fh\u001bk'_Jv\by_P{a\u0004gcYBg\u0016h9";
      f[81] = "?PpDk\u001cyP&_QM\u0006V{N<Aa]$\u0010`&;K*K+M7\u0001~@Q";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1282668889000839L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1282668889000839L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1282668889000839L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 68;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 82;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 121;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 100;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 73;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 241;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 68;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 82;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 121;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fW_C0315",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fW" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(PlayerEntity var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Lnet/minecraft/entity/player/PlayerEntity;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/fW_C0315",
                     "lambda$evaluate$0",
                     "(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/math/BlockPos;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PlayerEntity)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(PlayerEntity var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Lnet/minecraft/entity/player/PlayerEntity;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/fW_C0315",
                     "lambda$evaluate$1",
                     "(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/math/BlockPos;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PlayerEntity)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
