package dev.zprestige.prestige.api.util;

import net.minecraft.item.ItemStack;

public class NamedItemStack {
   public String a;
   public ItemStack b;

   public NamedItemStack() {
   }
}
