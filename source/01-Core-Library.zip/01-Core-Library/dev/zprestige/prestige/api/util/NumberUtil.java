package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Vector4f;

public final class NumberUtil {
   private static final long a = 51970967402162L;
   private static final String b;
   private static final long[] c;
   private static final Integer[] d;
   private static final Map e;
   private static final Object[] f = new Object[23];
   private static final String[] g = new String[23];

   private NumberUtil(long var1) {
      super();
      long var10000 = 51970967402162L ^ var1;

      throw new UnsupportedOperationException(b);
   }

   public static Map aReturningMap(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 51970967402162L ^ var1;
      short var10002 = 18697;
      long var10003 = 4016305590630036125L ^ var1;
      return new BoundedLruCache(16, 0.75F, true, var3);
   }

   public static float aReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 51970967402162L ^ var2;
      float var4 = var1 * 4.0F;
      return Math.round(var4) * 0.25F;
   }

   public static Vector4f aReturningVector4f(Object[] var0) {
      Vector4f var1 = (Vector4f)var0[0];
      long var2 = (Long)var0[1];
      var2 = 51970967402162L ^ var2;
      long var4 = var2 ^ 71122775503774L;
      Vector4f var6 = var1;
      float var10002 = var6.x;
      Object[] var10005 = new Object[]{null, var4};
      var10005[0] = var10002;
      Object[] var7 = var10005;
      var10002 = aReturningFloat(var7);
      Vector4f var8 = var1;
      float var10003 = var8.y;
      Object[] var10006 = new Object[]{null, var4};
      var10006[0] = var10003;
      Object[] var9 = var10006;
      var10003 = aReturningFloat(var9);
      Vector4f var10 = var1;
      float var10004 = var10.z;
      Object[] var10007 = new Object[]{null, var4};
      var10007[0] = var10004;
      Object[] var11 = var10007;
      var10004 = aReturningFloat(var11);
      Vector4f var12 = var1;
      float var18 = var12.w;
      Object[] var10008 = new Object[]{null, var4};
      var10008[0] = var18;
      Object[] var13 = var10008;
      return new Vector4f(var10002, var10003, var10004, aReturningFloat(var13));
   }

   public static int aReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 51970967402162L ^ var2;
      short var10001 = 30784;
      long var10002 = 3118207340592083361L ^ var2;
      return var1 >>> 24;
   }

   public static int bReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 51970967402162L ^ var2;
      short var10001 = 25224;
      long var10002 = 3006125340870377102L ^ var2;
      int var10000 = var1 >> 16;
      var10001 = 1602;
      var10002 = 2589569677345659456L ^ var2;
      return var10000 & 0xFF;
   }

   public static int cReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 51970967402162L ^ var1;
      short var10001 = 11290;
      long var10002 = 4478061949310622979L ^ var1;
      int var10000 = var3 >> 8;
      var10001 = 3635;
      var10002 = 5519357961101705000L ^ var1;
      return var10000 & 0xFF;
   }

   public static int dReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 51970967402162L ^ var2;
      short var10001 = 3635;
      long var10002 = 5519390179750657652L ^ var2;
      return var1 & 0xFF;
   }

   public static float bReturningFloat(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 51970967402162L ^ var1;
      long var4 = var1 ^ 59276892123653L;
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var3;
      Object[] var6 = var10003;
      Object[] var7 = new Object[]{aReturningInt(var6)};
      return fReturningFloat(var7);
   }

   public static float cReturningFloat(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 51970967402162L ^ var2;
      long var4 = var2 ^ 3437956480996L;
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var1;
      Object[] var6 = var10003;
      Object[] var7 = new Object[]{bReturningInt(var6)};
      return fReturningFloat(var7);
   }

   public static float dReturningFloat(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 51970967402162L ^ var2;
      long var4 = var2 ^ 58839509836070L;
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var1;
      Object[] var6 = var10003;
      Object[] var7 = new Object[]{cReturningInt(var6)};
      return fReturningFloat(var7);
   }

   public static float eReturningFloat(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 51970967402162L ^ var1;
      long var4 = var1 ^ 54063532005464L;
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var3;
      Object[] var6 = var10003;
      Object[] var7 = new Object[]{dReturningInt(var6)};
      return fReturningFloat(var7);
   }

   private static float fReturningFloat(Object[] var0) {
      int var1 = (Integer)var0[0];
      return var1 / 255.0F;
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(70209006134102L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var15 = var13.doFinal(
         "\u0018h´0\u0094\bw\u001dÁv½×[\u0003¦j{\u001b,\u0014WÇY\u009eb\u0012%Â¼|æH\u0091²çc¹wù\u0093¥~\u0085\u0087\u0095Ä5à\u0015Éqä!f\u0019Z"
            .getBytes("ISO-8859-1")
      );
      String var22 = a(var15).intern();
      int var10001 = -1;
      b = var22;
      e = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(70209006134102L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[6];
      String var4 = "ÚrÞ\u0090¦_Ön^\u001c«¡Þo»Õ/uâð[\u0084Â\u009dõ>}\u0018\u0095}Ë\u007f";
      int var5 = "ÚrÞ\u0090¦_Ön^\u001c«¡Þo»Õ/uâð[\u0084Â\u009dõ>}\u0018\u0095}Ë\u007f".length();
      label29:
      while (true) {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var18 = var6;
         var10001 = var3++;
         long var24 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         // while (true) {
            long var8 = var24;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var29 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var27) {
               case 0:
                  var18[var10001] = var29;
                  if (var2 >= var5) {
                     c = var6;
                     d = new Integer[6];
                     break;
                  }
                  break;
               default:
                  var18[var10001] = var29;
                  if (var2 < var5) {
                     continue label29;
                  }

                  var4 = "ç\u009c+¹æÒ\u000f\u0010\u0096+',¾ßÊt";
                  var5 = "ç\u009c+¹æÒ\u000f\u0010\u0096+',¾ßÊt".length();
                  var2 = 0;
            }

            int var21 = var2;
            var2 += 8;
            var7 = var4.substring(var21, var2).getBytes("ISO-8859-1");
            var18 = var6;
            var10001 = var3++;
            var24 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var27 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21045;
      if (d[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])e.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/f5", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         d[var3] = var15;
      }

      return d[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f5",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 36;
            yield var15;
         }
         case 1 -> {
            byte var16 = 41;
            yield var16;
         }
         case 2 -> {
            byte var17 = 58;
            yield var17;
         }
         case 3 -> {
            byte var18 = 1;
            yield var18;
         }
         case 4 -> {
            byte var19 = 60;
            yield var19;
         }
         case 5 -> {
            byte var20 = 28;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 31;
            yield var22;
         }
         case 8 -> {
            byte var23 = 47;
            yield var23;
         }
         case 9 -> {
            byte var24 = 3;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 46;
            yield var26;
         }
         case 12 -> {
            byte var27 = 22;
            yield var27;
         }
         case 13 -> {
            byte var28 = 38;
            yield var28;
         }
         case 14 -> {
            byte var29 = 5;
            yield var29;
         }
         case 15 -> {
            byte var30 = 54;
            yield var30;
         }
         case 16 -> {
            byte var31 = 50;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 37;
            yield var33;
         }
         case 19 -> {
            byte var34 = 49;
            yield var34;
         }
         case 20 -> {
            byte var35 = 39;
            yield var35;
         }
         case 21 -> {
            byte var36 = 33;
            yield var36;
         }
         case 22 -> {
            byte var37 = 16;
            yield var37;
         }
         case 23 -> {
            byte var38 = 23;
            yield var38;
         }
         case 24 -> {
            byte var39 = 10;
            yield var39;
         }
         case 25 -> {
            byte var40 = 11;
            yield var40;
         }
         case 26 -> {
            byte var41 = 12;
            yield var41;
         }
         case 27 -> {
            byte var42 = 24;
            yield var42;
         }
         case 28 -> {
            byte var43 = 57;
            yield var43;
         }
         case 29 -> {
            byte var44 = 29;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 27;
            yield var46;
         }
         case 32 -> {
            byte var47 = 13;
            yield var47;
         }
         case 33 -> {
            byte var48 = 32;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 44;
            yield var50;
         }
         case 36 -> {
            byte var51 = 25;
            yield var51;
         }
         case 37 -> {
            byte var52 = 9;
            yield var52;
         }
         case 38 -> {
            byte var53 = 8;
            yield var53;
         }
         case 39 -> {
            byte var54 = 20;
            yield var54;
         }
         case 40 -> {
            byte var55 = 21;
            yield var55;
         }
         case 41 -> {
            byte var56 = 0;
            yield var56;
         }
         case 42 -> {
            byte var57 = 14;
            yield var57;
         }
         case 43 -> {
            byte var58 = 15;
            yield var58;
         }
         case 44 -> {
            byte var59 = 7;
            yield var59;
         }
         case 45 -> {
            byte var60 = 17;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 52;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 42;
            yield var65;
         }
         case 51 -> {
            byte var66 = 45;
            yield var66;
         }
         case 52 -> {
            byte var67 = 40;
            yield var67;
         }
         case 53 -> {
            byte var68 = 4;
            yield var68;
         }
         case 54 -> {
            byte var69 = 55;
            yield var69;
         }
         case 55 -> {
            byte var70 = 6;
            yield var70;
         }
         case 56 -> {
            byte var71 = 26;
            yield var71;
         }
         case 57 -> {
            byte var72 = 35;
            yield var72;
         }
         case 58 -> {
            byte var73 = 2;
            yield var73;
         }
         case 59 -> {
            byte var74 = 19;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 18;
            yield var76;
         }
         case 62 -> {
            byte var77 = 61;
            yield var77;
         }
         default -> 62;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "}|\u0000]c8vs\u0011\u0012\u00005cu";
      f[1] = float.class;
      g[1] = "java/lang/Float";
      f[2] = int.class;
      g[2] = "java/lang/Integer";
      f[3] = "'eHZM?%{\u0001\"B3<x]@A";
      f[4] = "\u0010(\n%\u0019\u001f\u0006(\u000f\u007f\n\b\u0011c\fy\u0006\u001c\u0000$\u001bnM\tA";
      f[5] = "^2W2c\n+\u0012\\=rEJ\u001cW6v\u001f>";
      f[6] = "\"(\u000e\u0013\\5W\b\u0005\u001cMz6\u0006\u000e\u0017I B";
      f[7] = "a<4Fr%\u0014\u001c?Icju\u00124Bg0\u0001";
      f[8] = "\u001a\u001aRir\to:YfcF\u000e4Rmg\u001cz";
      f[9] = "@\b%\\p>5(.SaqT&%Xe+ ";
      f[10] = "G\n\rAx^2*\u0006Ni\u0011S$\rEmK'";
      f[11] = "?\u001d\u000e\u0011\u000b44\u0012\u001f^j:?\u0019\u001b\u0004";
      f[12] = "\u001eJO\u0003`T\u0015TL\u0006\fC$\u0004J]gACB\u0012Uw*UT\u0016S<TI\u000bQl";
      f[13] = "*@jw\u0007s!^irkf\u0010\u000eo)\u0000fwH7!\u0010\r)OqzZo{I7rk";
      f[14] = "FM6O\bH\u0002E0[aW|Xb\u0018^\u0018\u0002D=_";
      f[15] = "hxLN\u001drox\u000e3_\u007f\u007f}Y3Tw?$\u0005MH(x\u001b\fMZz3y^K\u001cr\u0002";
      f[16] = "\u0018{6\u0002(,\\s0\u0016A>\"nbU~|\\r=\u0012";
      f[17] = "wY*.,;|G)+@+M\u0017/p+.*Qwx;E<Gs~p; \u00184A";
      f[18] = "F\u0012bl,8M\fai@,|\\g2+-\u001b\u001a?:;FE\u001dyaq$\u0017\u001b?i@";
      f[19] = "c\u0013 \fbT'\u001b&\u0018\u000bEY\u0006t[4\u0004'\u001a+\u001c";
      f[20] = "G\u001e\u001eI\\zL\u0000\u001dL0m}P\u001b\u0017[o\u001a\u0016C\u001fK\u0004D\u0011\u0005D\u0001f\u0016\u0017CL0";
      f[21] = "Cu7QqQHk4T\u001dCy;2\u000fvD\u001e}j\u0007f/@z,\\,M\u0012|jT\u001d";
      f[22] = "4)R8v^p!T,\u001fN\u000e<\u0006o \u000ep Y(";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(834773622758378L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(834773622758378L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(834773622758378L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 223;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 88;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 246;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 101;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 163;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 102;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 223;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 88;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 246;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f5",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
