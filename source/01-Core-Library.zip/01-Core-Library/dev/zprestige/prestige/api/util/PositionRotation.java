package dev.zprestige.prestige.api.util;

import net.minecraft.util.math.Vec3d;

public class PositionRotation {
   public Vec3d a;
   public float b;
   public float c;

   public PositionRotation(Vec3d var1, float var2, float var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
