package dev.zprestige.prestige.api.util;

import net.minecraft.util.math.Vec3d;

public final class PositionSegment {
   public Vec3d a;
   public Vec3d b;
   public boolean c;

   public PositionSegment(Vec3d var1, Vec3d var2, boolean var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
