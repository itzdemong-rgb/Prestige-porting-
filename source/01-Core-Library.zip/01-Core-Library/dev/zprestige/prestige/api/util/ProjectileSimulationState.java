package dev.zprestige.prestige.api.util;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.util.math.Vec3d;

public class ProjectileSimulationState {
   public Vec3d a;
   public Vec3d b;
   public float c;
   public int d;
   public double e;
   public float f;
   private static final long g = 95784666506660L;
   private static final Object[] h = new Object[7];
   private static final String[] i = new String[7];

   public ProjectileSimulationState(Vec3d var1, Vec3d var2, int var3, long var4) {
      super();
      long var10000 = 95784666506660L ^ var4;

      this.a = var1;
      this.b = var2;
      this.c = 0.0F;
      this.d = var3;
      this.e = Math.random() * Math.PI * 2.0;
      this.f = (float)Math.random();
   }

   public void aReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 95784666506660L ^ var3;
      Vec3d var10001 = this.a;
      double var6 = var2;
      Vec3d var5 = this.b;
      Vec3d var9 = var5.multiply(var6);
      Vec3d var8 = var10001;
      this.a = var8.add(var9);
      this.c += var2;
   }

   static {
      aReturningVoid();
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 26;
            yield var15;
         }
         case 1 -> {
            byte var16 = 8;
            yield var16;
         }
         case 2 -> {
            byte var17 = 53;
            yield var17;
         }
         case 3 -> {
            byte var18 = 49;
            yield var18;
         }
         case 4 -> {
            byte var19 = 3;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 40;
            yield var21;
         }
         case 7 -> {
            byte var22 = 27;
            yield var22;
         }
         case 8 -> {
            byte var23 = 9;
            yield var23;
         }
         case 9 -> {
            byte var24 = 33;
            yield var24;
         }
         case 10 -> {
            byte var25 = 11;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 22;
            yield var27;
         }
         case 13 -> {
            byte var28 = 24;
            yield var28;
         }
         case 14 -> {
            byte var29 = 0;
            yield var29;
         }
         case 15 -> {
            byte var30 = 46;
            yield var30;
         }
         case 16 -> {
            byte var31 = 5;
            yield var31;
         }
         case 17 -> {
            byte var32 = 42;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 45;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 1;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 17;
            yield var38;
         }
         case 24 -> {
            byte var39 = 58;
            yield var39;
         }
         case 25 -> {
            byte var40 = 51;
            yield var40;
         }
         case 26 -> {
            byte var41 = 39;
            yield var41;
         }
         case 27 -> {
            byte var42 = 57;
            yield var42;
         }
         case 28 -> {
            byte var43 = 16;
            yield var43;
         }
         case 29 -> {
            byte var44 = 32;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 29;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 54;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 47;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 38;
            yield var52;
         }
         case 38 -> {
            byte var53 = 28;
            yield var53;
         }
         case 39 -> {
            byte var54 = 41;
            yield var54;
         }
         case 40 -> {
            byte var55 = 37;
            yield var55;
         }
         case 41 -> {
            byte var56 = 36;
            yield var56;
         }
         case 42 -> {
            byte var57 = 19;
            yield var57;
         }
         case 43 -> {
            byte var58 = 18;
            yield var58;
         }
         case 44 -> {
            byte var59 = 44;
            yield var59;
         }
         case 45 -> {
            byte var60 = 63;
            yield var60;
         }
         case 46 -> {
            byte var61 = 35;
            yield var61;
         }
         case 47 -> {
            byte var62 = 6;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 7;
            yield var64;
         }
         case 50 -> {
            byte var65 = 20;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 31;
            yield var67;
         }
         case 53 -> {
            byte var68 = 2;
            yield var68;
         }
         case 54 -> {
            byte var69 = 30;
            yield var69;
         }
         case 55 -> {
            byte var70 = 10;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 23;
            yield var73;
         }
         case 59 -> {
            byte var74 = 52;
            yield var74;
         }
         case 60 -> {
            byte var75 = 61;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 55;
            yield var77;
         }
         default -> 50;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "51#\u0002\u0018\u0006514^\u0014\t/z4@\u0014\u001c(\u000be\u0018F";
      h[1] = double.class;
      i[1] = "java/lang/Double";
      h[2] = "\u0005\u0019\u001cuo7\u000e\u0016\r:\f:\u001b\u0010";
      h[3] = "\u007fH R$DtG1\u001dEJ\u007fL5G";
      h[4] = "n!I\u00070O-!^e+\u0018(;S\t\u0019Llb\u0005et\u000f)9J_7\u000f>[\u000e\u001f3\u0017*aM\u001f$u";
      h[5] = "\u001c\u0011KA\u0012X_\u0011\\#\t\u000fZ\u000bQO;[\u001eQ\u000f#\u0011\u001fA\u0000I\\\u0011\u0005Ck\fY\u0011\u0000XQOY\u0006b";
      h[6] = "N_\u0004>z\u001e\b\u0001\u0000!@\u001a\u001eW\u00176%`\nL\u001c:?\u001f\nV\u001eQ";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(226210543392330L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(226210543392330L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(226210543392330L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 109;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 118;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 162;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 121;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 250;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 88;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 109;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 118;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 162;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f_",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
