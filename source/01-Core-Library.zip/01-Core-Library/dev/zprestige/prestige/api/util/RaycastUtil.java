package dev.zprestige.prestige.api.util;

import com.mojang.authlib.GameProfile;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class RaycastUtil implements MinecraftAccess {
   private static final long a = 18541427887931L;
   private static final Object[] c = new Object[40];
   private static final String[] d = new String[40];

   public static Vec3d aReturningVec3d(Object[] var0) {
      Entity var1 = (Entity)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 18541427887931L ^ var2;
      Entity var4 = var1;
      return var4.getEntityPos();
   }

   public static Vec3d bReturningVec3d(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 18541427887931L ^ var1;
      long var3 = var1 ^ 70515024388741L;
      MinecraftClient var5 = b;
      Object[] var6 = new Object[]{var5.player, var3};
      return aReturningVec3d(var6);
   }

   public static String aReturningString(Object[] var0) {
      GameProfile var1 = (GameProfile)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 18541427887931L ^ var2;
      GameProfile var4 = var1;
      return var4.name();
   }

   public static Vec3d cReturningVec3d(Object[] var0) {
      Entity var1 = (Entity)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 18541427887931L ^ var2;
      Entity var4 = var1;
      Entity var5 = var1;
      Entity var6 = var1;
      return new Vec3d(var4.lastX, var5.lastY, var6.lastZ);
   }

   public static boolean aReturningBoolean(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 18541427887931L ^ var1;
      long var3 = var1 ^ 72982511433417L;
      MinecraftClient var5 = b;
      Object[] var6 = new Object[]{var5.player, var3};
      return bReturningBoolean(var6);
   }

   public static boolean bReturningBoolean(Object[] var0) {
      PlayerEntity var3 = (PlayerEntity)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 18541427887931L ^ var1;
      PlayerEntity var4 = var3;
      return var4.isGliding();
   }

   public static double aReturningDouble(Object[] var0) {
      PlayerEntity var1 = (PlayerEntity)var0[0];
      long var2 = (Long)var0[1];
      var2 = 18541427887931L ^ var2;
      long var4 = var2 ^ 45288786374431L;
      Object[] var9 = new Object[]{var1, var4};
      Vec3d var6 = aReturningVec3d(var9);
      double var13 = -256.0;
      Vec3d var10 = var6;
      Vec3d var7 = var10.add(var11, var13, var15);
      MinecraftClient var17 = b;
      ClientWorld var10000 = var17.world;
      RaycastContext var19 = new RaycastContext(var6, var7, ShapeType.OUTLINE, FluidHandling.NONE, var1);
      ClientWorld var18 = var10000;
      BlockHitResult var8 = var18.raycast(var19);
      BlockHitResult var20 = var8;
      Type var27 = var20.getType();
      Type var25 = Type.BLOCK;
      Type var24 = var27;
      if (var24 == var25) {
         PlayerEntity var21 = var1;
         double var28 = var21.getY();
         BlockHitResult var22 = var8;
         Vec3d var23 = var22.getPos();
         return var28 - var23.y;
      } else {
         return 256.0;
      }
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 63;
            yield var15;
         }
         case 1 -> {
            byte var16 = 28;
            yield var16;
         }
         case 2 -> {
            byte var17 = 38;
            yield var17;
         }
         case 3 -> {
            byte var18 = 31;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 39;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 20;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 49;
            yield var27;
         }
         case 13 -> {
            byte var28 = 59;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 8;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 42;
            yield var33;
         }
         case 19 -> {
            byte var34 = 25;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 32;
            yield var36;
         }
         case 22 -> {
            byte var37 = 62;
            yield var37;
         }
         case 23 -> {
            byte var38 = 54;
            yield var38;
         }
         case 24 -> {
            byte var39 = 34;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 58;
            yield var41;
         }
         case 27 -> {
            byte var42 = 55;
            yield var42;
         }
         case 28 -> {
            byte var43 = 23;
            yield var43;
         }
         case 29 -> {
            byte var44 = 11;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 41;
            yield var46;
         }
         case 32 -> {
            byte var47 = 56;
            yield var47;
         }
         case 33 -> {
            byte var48 = 18;
            yield var48;
         }
         case 34 -> {
            byte var49 = 1;
            yield var49;
         }
         case 35 -> {
            byte var50 = 17;
            yield var50;
         }
         case 36 -> {
            byte var51 = 60;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 26;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 7;
            yield var55;
         }
         case 41 -> {
            byte var56 = 35;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 43;
            yield var58;
         }
         case 44 -> {
            byte var59 = 27;
            yield var59;
         }
         case 45 -> {
            byte var60 = 61;
            yield var60;
         }
         case 46 -> {
            byte var61 = 24;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 2;
            yield var63;
         }
         case 49 -> {
            byte var64 = 53;
            yield var64;
         }
         case 50 -> {
            byte var65 = 13;
            yield var65;
         }
         case 51 -> {
            byte var66 = 5;
            yield var66;
         }
         case 52 -> {
            byte var67 = 16;
            yield var67;
         }
         case 53 -> {
            byte var68 = 0;
            yield var68;
         }
         case 54 -> {
            byte var69 = 52;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 47;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 40;
            yield var73;
         }
         case 59 -> {
            byte var74 = 21;
            yield var74;
         }
         case 60 -> {
            byte var75 = 3;
            yield var75;
         }
         case 61 -> {
            byte var76 = 10;
            yield var76;
         }
         case 62 -> {
            byte var77 = 29;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "oV\u0007+w#oV\u0010w{,u\u001d\u0010i{9rlB7#}";
      c[1] = double.class;
      d[1] = "java/lang/Double";
      c[2] = "$33\u001de'$3$Ai(>x$_i=9\tu\u00001j):&@{\u0011xbw";
      c[3] = "2\u0006W*O\"$\u0006Rp\\53MQvP!\"\nFa\u001b1e";
      c[4] = "y?e#;X\f\u001fn,*\u0017m\u0011e'.M\u0019";
      c[5] = "2\u001bZts{2\u001bM(\u007ft(PM6\u007fa/!\u001cn-";
      c[6] = "\tc `\u001f}\tc7<\u0013r\u0013(7\"\u0013g\u0014YgwD!";
      c[7] = ">+Ak~=>+V7r2$`V)r'#\u0011\u0004s&c";
      c[8] = "\u00014\u0005r{)\u00014\u0012.w&\u001b\u007f\u00120w3\u001c\u000eGo.";
      c[9] = "5\u0000\u007fbS65\u0000h>_9/Kh _,(:8u\u000bf";
      c[10] = "jx>_\u0018ejx)\u0003\u0014jp3)\u001d\u0014\u007fwBy@E";
      c[11] = "#GM%+;(H\\jH6=ES\u0001}4,VO-j9";
      c[12] = "G&q$\u0010>G&fx\u001c1]mff\u001c$Z\u001c63Hn\r ik\u000e$vp<<M";
      c[13] = "=.XHN\u0003=.O\u0014B\f'eO\nB\u0019 \u0014\u001f_\u0016Sw(@\u0007P\u0019\fy\u0018T";
      c[14] = "\u001bG\u001fO\u001c\u001c\u0012I\u001c\u0006_\u0012\r\\\u001a\r\u0018\u0011Vo\u0013\f\u0014#\nG\u0014\b\u001d\u0016";
      c[15] = "Qo0jh\u0019Z`!%\u0015\u0001Ig(l";
      c[16] = "B\u00122Z3S729U\"\u001cV<2^&F\"";
      c[17] = boolean.class;
      d[17] = "java/lang/Boolean";
      c[18] = "\u001e\u0010[(MP\u001e\u0010LtA_\u0004[LjAJ\u0003*\u00182\u0016";
      c[19] = "A\u0018TULcJ\u0017E\u001a-mA\u001cA@";
      c[20] = "\u0017)\u0000\u001ci.]y\u0002X\u0016|L~\u000f\bA+\u0016(Qd,(Fk\u0014XfxD/";
      c[21] = "Q(}?H\u0006\u0017)`b2^k(~g\fY\u00138w!\f7P `?]Q\u0007}z'2";
      c[22] = "{~\u001fQ\\\u0011,#\u0005I3\u0019!q\u0001^dN{!\\2\n\u001d\u007fz\u0004R\u000b\u0019>$";
      c[23] = "2\u0005\u0003A\u0019$mT\fY\"xc\u0012\tYNJ7QV\u000e\u0019\u001d4T\u0002F]!~\u0004\u0000\u0002\"";
      c[24] = "\u0003\rn6eWE\fsk\u001f\f9\rmn!\bA\u001dd(!fS\u001c{1 \t^\nb>\u001f";
      c[25] = "xyq0h~+!$%X{(d*24I\u007f#qlh\u001e|ru39~}v4mX";
      c[26] = "P\u0001+!a_\u0000\u001f|'\u001a\u0005\u0000\u0001zyv7TB%\" `S\u0000\"q&XSF#{\u001a\\\u0006\u0017e%#\u0003W\u0018}\u001e";
      c[27] = "y~\u001c/\u0017<b#\tB\u0000,`$\u0002.2~'}Usez~>\u0006-\u0003-#$\u001eB";
      c[28] = "\f:+?C\u0003Rk17)\u0002Rj22~U\r7i^\u0014\u0010\u00028-aD\u000eU>";
      c[29] = "7@'~H6gCg*23oXrE[.wVn%Y+y\f\u001f";
      c[30] = "pq\u0001g*#k,\u0014\n6?x/\u0014]ff,wx32as*\u001826 -";
      c[31] = "\u0015\rkkUI\u000eP~\u0006IU\u001dS~Q\u001a\u0005N\u0006\u0012?M\u000b\u0016Vr>IJH";
      c[32] = "\t\\Df\u0003NV\rK~8\u0012XKN~T \f\b\u0011)\u0004w\u000eUTzW\u0011Y\bNb8";
      c[33] = "#<q`\u0000t}mkhju}lhm=\"#;0\u0001\u0001fl;`f\u000egw9";
      c[34] = "kX#&T#-Y>{.{Q\u0002u>W|m^%'\u0012\u0012a\u0003?<@.=S&y.";
      c[35] = "\u007ffJY\u0011-d;_4\r1w8_c]h!b3\r\to|=S\f\r.\"";
      c[36] = "24Ql\u0011\u0014al\u0004y!\u0011b)\nnM#1lP9!\u001et'\u000e6N\u0013b>\u0001\t";
      c[37] = "P\u0005\u007fC8g\u0007Xe[Wd\u0006\u001beG;VR_>\u0019W8\u0001XcA79\u0005\u0019= nkT\u0001d@oo\u0015_\u0005\u0019=>\r\u0006e\u00189\u007fSg>B-b\u0004\u0001i\u001f7zk";
      c[38] = "'Qe\u0004a\u0000jUq\f\u001d\u000ev[~\u0018JY(\u000b'E\u001dPpIj\b}\u001dt]b";
      c[39] = "@0w4/[\u001a=&%VZ\u00107z6\u0001\rJf.Zg^\u00184g5=SI%";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1401058730737580L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1401058730737580L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1401058730737580L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 223;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 226;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 222;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 252;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 221;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 194;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 223;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 226;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 222;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c3",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
