package dev.zprestige.prestige.api.util;
import dev.zprestige.prestige.client.management.FrameTimer;


import dev.zprestige.prestige.api.rotation.Rotation;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class RotationUtil implements MinecraftAccess {
   private static final long a = 85340804468109L;
   private static final Object[] c = new Object[99];
   private static final String[] d = new String[99];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;
   private static volatile MethodHandle bindingCache93;
   private static volatile MethodHandle bindingCache94;
   private static volatile MethodHandle bindingCache95;
   private static volatile MethodHandle bindingCache96;
   private static volatile MethodHandle bindingCache97;
   private static volatile MethodHandle bindingCache98;
   private static volatile MethodHandle bindingCache99;
   private static volatile MethodHandle bindingCache100;
   private static volatile MethodHandle bindingCache101;
   private static volatile MethodHandle bindingCache102;
   private static volatile MethodHandle bindingCache103;
   private static volatile MethodHandle bindingCache104;
   private static volatile MethodHandle bindingCache105;
   private static volatile MethodHandle bindingCache106;
   private static volatile MethodHandle bindingCache107;
   private static volatile MethodHandle bindingCache108;
   private static volatile MethodHandle bindingCache109;
   private static volatile MethodHandle bindingCache110;
   private static volatile MethodHandle bindingCache111;
   private static volatile MethodHandle bindingCache112;
   private static volatile MethodHandle bindingCache113;
   private static volatile MethodHandle bindingCache114;
   private static volatile MethodHandle bindingCache115;
   private static volatile MethodHandle bindingCache116;
   private static volatile MethodHandle bindingCache117;
   private static volatile MethodHandle bindingCache118;
   private static volatile MethodHandle bindingCache119;
   private static volatile MethodHandle bindingCache120;
   private static volatile MethodHandle bindingCache121;

    public static boolean aReturningBoolean(final Object[] array) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[17];
      recoveryLocals[0]=array;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((dev.zprestige.prestige.api.rotation.Rotation)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.Float)recoveryStack[1]); }
                  recoveryAt=10; { recoveryStack[1]=((java.lang.Float)recoveryStack[1]).floatValue(); }
                  recoveryAt=11; { recoveryLocals[5]=recoveryStack[1];  }
                  recoveryAt=12; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=13; { recoveryStack[2]=2; }
                  recoveryAt=14; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Float)recoveryStack[1]); }
                  recoveryAt=16; { recoveryStack[1]=((java.lang.Float)recoveryStack[1]).floatValue(); }
                  recoveryAt=18; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=19; { recoveryStack[2]=3; }
                  recoveryAt=20; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=21; { recoveryStack[1]=((java.lang.Float)recoveryStack[1]); }
                  recoveryAt=22; { recoveryStack[1]=((java.lang.Float)recoveryStack[1]).floatValue(); }
                  recoveryAt=24; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=25; { recoveryStack[2]=4; }
                  recoveryAt=26; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=27; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=28; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=29; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=31; { recoveryStack[0]=85340804468109L; }
                  recoveryAt=32; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=33; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=34; { recoveryLocals[3]=recoveryStack[0];  }
                  recoveryAt=35; { recoveryStack[0]=recoveryLocals[3];  }
                  recoveryAt=36; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=37; { recoveryStack[2]=26224559754606L; }
                  recoveryAt=38; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=39; { recoveryLocals[7]=recoveryStack[1];  }
                  recoveryAt=43; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=44; { recoveryStack[1]=Float.intBitsToFloat(1084227584); }
                  recoveryAt=45; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])*dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=46; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=49; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=50; { recoveryStack[1]=0; }
                  recoveryAt=51; { recoveryStack[1]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])]; }
                  recoveryAt=52; { recoveryStack[2]=-3095846432769455158L; }
                  recoveryAt=53; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=54; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding1(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=55; { recoveryLocals[11]=recoveryStack[0];  }
                  recoveryAt=56; { recoveryStack[0]=-3094203553801221966L; }
                  recoveryAt=57; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=58; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding2(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=61; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=62; { recoveryStack[2]=0; }
                  recoveryAt=63; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=64; { recoveryStack[3]=-3095153273172746508L; }
                  recoveryAt=65; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=66; { recoveryStack[1]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding3(((java.lang.Object)recoveryStack[1]),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=67; { recoveryLocals[12]=recoveryStack[1];  }
                  recoveryAt=70; { recoveryStack[1]=dev.zprestige.prestige.api.util.RotationUtil.b; }
                  recoveryAt=71; { recoveryStack[2]=-3096197928717223667L; }
                  recoveryAt=72; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=73; { recoveryStack[1]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding4(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=74; { recoveryStack[2]=-3091833706720799929L; }
                  recoveryAt=75; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=76; { recoveryStack[1]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding5(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=77; { recoveryLocals[13]=recoveryStack[1];  }
                  recoveryAt=78; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=81; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.b; }
                  recoveryAt=82; { recoveryStack[1]=-3096197928717223667L; }
                  recoveryAt=83; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=84; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding6(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=85; { recoveryStack[1]=-3093811867216812989L; }
                  recoveryAt=86; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=87; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding7(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=88; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=91; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=92; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=93; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])-dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=94; { recoveryLocals[15]=recoveryStack[0];  }
                  recoveryAt=97; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=98; { recoveryStack[1]=recoveryLocals[14];  }
                  recoveryAt=99; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])-dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=100; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=103; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=104; { recoveryStack[1]=recoveryLocals[13];  }
                  recoveryAt=105; { recoveryStack[2]=recoveryLocals[9];  }
                  recoveryAt=106; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])==0){recoveryPc=142; continue recoveryFlow;} recoveryPc=107; continue recoveryFlow; }
               }
               case 107 -> {
                  recoveryAt=107; { float recoveryA=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]), recoveryB=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]);recoveryStack[0]=Float.isNaN(recoveryA)||Float.isNaN(recoveryB)?-1:recoveryA>recoveryB?1:recoveryA==recoveryB?0:-1; }
                  recoveryAt=108; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=0){recoveryPc=130; continue recoveryFlow;} recoveryPc=110; continue recoveryFlow; }
               }
               case 110 -> {
                  recoveryAt=110; { recoveryPc=120; continue recoveryFlow; }
               }
               case 113 -> {
                  recoveryAt=113; { recoveryStack[1]=-3094130009568881960L; }
                  recoveryAt=114; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=115; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding8(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=116; { throw (Throwable)recoveryStack[0]; }
               }
               case 120 -> {
                  recoveryAt=120; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=121; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=122; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=123; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=125; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=126; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=147; continue recoveryFlow;} recoveryPc=130; continue recoveryFlow; }
               }
               case 130 -> {
                  recoveryAt=130; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=131; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=133; { recoveryPc=142; continue recoveryFlow; }
               }
               case 136 -> {
                  recoveryAt=136; { recoveryStack[1]=-3094130009568881960L; }
                  recoveryAt=137; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=138; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding9(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=139; { throw (Throwable)recoveryStack[0]; }
               }
               case 142 -> {
                  recoveryAt=142; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])-dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=143; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryPc=147; continue recoveryFlow;
               }
               case 147 -> {
                  recoveryAt=147; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(dev.zprestige.prestige.api.rotation.Rotation.class); recoveryStack[0]=new Object(); }
                  recoveryAt=148; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=149; { recoveryStack[2]=recoveryLocals[13];  }
                  recoveryAt=150; { recoveryStack[3]=recoveryLocals[14];  }
                  recoveryAt=151; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new dev.zprestige.prestige.api.rotation.Rotation(dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[3])); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=152; { recoveryStack[1]=recoveryLocals[7];  }
                  recoveryAt=153; { recoveryStack[2]=2; }
                  recoveryAt=154; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=155; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=156; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=158; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=159; { recoveryStack[4]=1; }
                  recoveryAt=160; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=161; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=162; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=163; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=164; { recoveryStack[3]=0; }
                  recoveryAt=165; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=166; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=167; { recoveryStack[1]=-3091888678682789625L; }
                  recoveryAt=168; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=169; { dev.zprestige.prestige.api.util.RotationUtil.invokeBinding10(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=172; { recoveryStack[0]=recoveryLocals[15];  }
                  recoveryAt=173; { recoveryStack[1]=-3093316623006623029L; }
                  recoveryAt=174; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=175; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding11(dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=176; { recoveryStack[1]=Float.intBitsToFloat(1056964608); }
                  recoveryAt=177; { float recoveryA=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]), recoveryB=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]);recoveryStack[0]=Float.isNaN(recoveryA)||Float.isNaN(recoveryB)?1:recoveryA>recoveryB?1:recoveryA==recoveryB?0:-1; }
                  recoveryAt=178; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=179; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=208; continue recoveryFlow;} recoveryPc=181; continue recoveryFlow; }
               }
               case 181 -> {
                  recoveryAt=181; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=0){recoveryPc=227; continue recoveryFlow;} recoveryPc=183; continue recoveryFlow; }
               }
               case 183 -> {
                  recoveryAt=183; { recoveryPc=192; continue recoveryFlow; }
               }
               case 186 -> {
                  recoveryAt=186; { recoveryStack[1]=-3094130009568881960L; }
                  recoveryAt=187; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=188; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding12(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=189; { throw (Throwable)recoveryStack[0]; }
               }
               case 192 -> {
                  recoveryAt=192; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=193; { recoveryStack[1]=-3093316623006623029L; }
                  recoveryAt=194; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=195; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding13(dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=196; { recoveryStack[1]=Float.intBitsToFloat(1056964608); }
                  recoveryAt=197; { float recoveryA=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]), recoveryB=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]);recoveryStack[0]=Float.isNaN(recoveryA)||Float.isNaN(recoveryB)?1:recoveryA>recoveryB?1:recoveryA==recoveryB?0:-1; }
                  recoveryAt=199; { recoveryPc=208; continue recoveryFlow; }
               }
               case 202 -> {
                  recoveryAt=202; { recoveryStack[1]=-3094130009568881960L; }
                  recoveryAt=203; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=204; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding14(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=205; { throw (Throwable)recoveryStack[0]; }
               }
               case 208 -> {
                  recoveryAt=208; { recoveryStack[1]=recoveryLocals[9];  }
                  recoveryAt=209; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=224; continue recoveryFlow;} recoveryPc=210; continue recoveryFlow; }
               }
               case 210 -> {
                  recoveryAt=210; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])>=0){recoveryPc=227; continue recoveryFlow;} recoveryPc=212; continue recoveryFlow; }
               }
               case 212 -> {
                  recoveryAt=212; { recoveryPc=221; continue recoveryFlow; }
               }
               case 215 -> {
                  recoveryAt=215; { recoveryStack[1]=-3094130009568881960L; }
                  recoveryAt=216; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=217; { recoveryStack[0]=dev.zprestige.prestige.api.util.RotationUtil.invokeBinding15(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=218; { throw (Throwable)recoveryStack[0]; }
               }
               case 221 -> {
                  recoveryAt=221; { recoveryStack[0]=1; }
                  recoveryPc=224; continue recoveryFlow;
               }
               case 224 -> {
                  recoveryAt=224; { recoveryPc=230; continue recoveryFlow; }
               }
               case 227 -> {
                  recoveryAt=227; { recoveryStack[0]=0; }
                  recoveryPc=230; continue recoveryFlow;
               }
               case 230 -> {
                  recoveryAt=230; { return ((dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0]) & 1) != 0); }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=101 && recoveryAt<109 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=113; continue recoveryFlow;}
            if(recoveryAt>=124 && recoveryAt<132 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=136; continue recoveryFlow;}
            if(recoveryAt>=144 && recoveryAt<182 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=186; continue recoveryFlow;}
            if(recoveryAt>=180 && recoveryAt<198 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=202; continue recoveryFlow;}
            if(recoveryAt>=206 && recoveryAt<211 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=215; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

    public static boolean bReturningBoolean(Object[] objectArray) {
        float f;
        block8: {
            block7: {
                int n;
                long l;
                block6: {
                    Rotation dx_C02102 = (Rotation)objectArray[0];
                    l = (Long)objectArray[1];
                    l = 0x4D9DF455CD8DL ^ l;
                    n = RotationUtil.invokeBinding16(-1943268375310010280L, l);
                    try {
                        try {
                            float f10 = RotationUtil.invokeBinding20(RotationUtil.invokeBinding18(RotationUtil.invokeBinding17(b, -1941516984801867509L, l), -1940530913558469823L, l) - RotationUtil.invokeBinding19(dx_C02102, new Object[0], -1941305530662192180L, l), -1939903420406420787L, l) - 10.0f;
                            f = f10 == 0.0f ? 0 : (f10 < 0.0f ? -1 : 1);
                            if (n != 0) break block6;
                            if (f >= 0) break block7;
                        }
                        catch (MatchException matchException) {
                            throw RotationUtil.invokeBinding21(matchException, -1942966977878793506L, l);
                        }
                        float f11 = RotationUtil.invokeBinding25(RotationUtil.invokeBinding23(RotationUtil.invokeBinding22(b, -1941516984801867509L, l), -1939131098326215611L, l) - RotationUtil.invokeBinding24(dx_C02102, new Object[0], -1941739138539868430L, l), -1939903420406420787L, l) - 10.0f;
                        f = f11 == 0.0f ? 0 : (f11 < 0.0f ? -1 : 1);
                    }
                    catch (MatchException matchException) {
                        throw RotationUtil.invokeBinding26(matchException, -1942966977878793506L, l);
                    }
                }
                try {
                    if (n != 0) break block8;
                    if (f >= 0) break block7;
                }
                catch (MatchException matchException) {
                    throw RotationUtil.invokeBinding27(matchException, -1942966977878793506L, l);
                }
                f = 1;
                break block8;
            }
            f = 0;
        }
        return dev.prestige.recovery.SourceSupport.asBoolean(f);
    }

   public static boolean cReturningBoolean(Object[] var0) {
      Rotation var4 = (Rotation)var0[0];
      float var3 = (Float)var0[1];
      float var2 = (Float)var0[2];
      float var1 = (Float)var0[3];
      long var5 = (Long)var0[4];
      var5 = 85340804468109L ^ var5;
      long var7 = var5 ^ 11653556975148L;
      long var9 = var5 ^ 136489913355026L;
      long var11 = var5 ^ 133614979045277L;
      int var10000 = Event.cReturningInt();
      MinecraftClient var16 = b;
      ClientPlayerEntity var17 = var16.player;
      float var10001 = var17.getYaw();
      Object[] var19 = new Object[0];
      Rotation var18 = var4;
      float var10002 = var18.aReturningFloat(var19) + var2;
      FrameTimer var10003 = Prestige.h;
      Object[] var21 = new Object[0];
      FrameTimer var20 = var10003;
      float var87 = var20.aReturningFloat(var21) * (1.1F - var3) * 7.0F / var1;
      Object[] var10008 = new Object[]{null, null, var11};
      var10008[1] = 1.0F;
      var10008[0] = 0.5F;
      Object[] var22 = var10008;
      float var88 = var87 * RandomUtil.aReturningFloat(var22);
      Object[] var10006 = new Object[]{null, null, null, var7};
      var10006[2] = var88;
      var10006[1] = var10002;
      var10006[0] = var10001;
      Object[] var23 = var10006;
      float var14 = cReturningFloat(var23);
      MinecraftClient var24 = b;
      ClientPlayerEntity var25 = var24.player;
      var10001 = var25.getPitch();
      Object[] var27 = new Object[0];
      Rotation var26 = var4;
      var10002 = var26.bReturningFloat(var27) + var2 / 2.0F;
      var10003 = Prestige.h;
      Object[] var29 = new Object[0];
      FrameTimer var28 = var10003;
      float var90 = var28.aReturningFloat(var29) * (1.1F - var3) * 7.0F / var1;
      var10008 = new Object[]{null, null, var11};
      var10008[1] = 1.0F;
      var10008[0] = 0.5F;
      Object[] var30 = var10008;
      float var91 = var90 * RandomUtil.aReturningFloat(var30);
      var10006 = new Object[]{null, null, null, var7};
      var10006[2] = var91;
      var10006[1] = var10002;
      var10006[0] = var10001;
      Object[] var31 = var10006;
      float var15 = cReturningFloat(var31);
      int var13 = var10000;
      Object[] var32 = new Object[]{new Rotation(var14, var15), var9};
      aReturningVoid(var32);
      MinecraftClient var33 = b;
      ClientPlayerEntity var34 = var33.player;
      float var80 = var34.getYaw() - 5.0F;
      Object[] var36 = new Object[0];
      Rotation var35 = var4;
      float var94;
      var10000 = (var94 = var80 - var35.aReturningFloat(var36)) == 0.0F ? 0 : (var94 < 0.0F ? -1 : 1);
      int var64 = var13;
      int var63 = var10000;
      int var55 = var63;
      int var54 = var63;
      if (var64 != 0) {
         int var65 = var54;
         if (var65 >= 0) {
            return false;
         }

         MinecraftClient var38 = b;
         ClientPlayerEntity var39 = var38.player;
         float var82 = var39.getYaw() + 5.0F;
         Object[] var41 = new Object[0];
         Rotation var40 = var4;
         float var95;
         int var66 = (var95 = var82 - var40.aReturningFloat(var41)) == 0.0F ? 0 : (var95 < 0.0F ? -1 : 1);
         var55 = var66;
      }

      int var68 = var13;
      int var67 = var55;
      int var57 = var67;
      int var56 = var67;
      if (var68 != 0) {
         int var69 = var56;
         if (var69 <= 0) {
            return false;
         }

         MinecraftClient var44 = b;
         ClientPlayerEntity var45 = var44.player;
         float var83 = var45.getPitch() - 5.0F;
         Object[] var47 = new Object[0];
         Rotation var46 = var4;
         float var96;
         int var70 = (var96 = var83 - var46.bReturningFloat(var47)) == 0.0F ? 0 : (var96 < 0.0F ? -1 : 1);
         var57 = var70;
      }

      int var72 = var13;
      int var71 = var57;
      int var59 = var71;
      int var58 = var71;
      if (var72 != 0) {
         int var73 = var58;
         if (var73 >= 0) {
            return false;
         }

         MinecraftClient var50 = b;
         ClientPlayerEntity var51 = var50.player;
         float var84 = var51.getPitch() + 5.0F;
         Object[] var53 = new Object[0];
         Rotation var52 = var4;
         float var97;
         int var74 = (var97 = var84 - var52.bReturningFloat(var53)) == 0.0F ? 0 : (var97 < 0.0F ? -1 : 1);
         var59 = var74;
      }

      int var76 = var13;
      int var75 = var59;
      int var61 = var75;
      int var60 = var75;
      if (var76 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var61);
      } else {
         int var77 = var60;
         if (var77 > 0) {
            byte var98 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var98);
         } else {
            return false;
         }
      }
   }

   public static boolean dReturningBoolean(Object[] var0) {
      Rotation var5 = (Rotation)var0[0];
      float var1 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var2 = (Float)var0[3];
      long var3 = (Long)var0[4];
      var3 = 85340804468109L ^ var3;
      long var7 = var3 ^ 55632324797635L;
      long var9 = var3 ^ 74915741407741L;
      long var11 = var3 ^ 72035455092082L;
      MinecraftClient var15 = b;
      ClientPlayerEntity var16 = var15.player;
      float var10000 = var16.getPitch();
      Object[] var18 = new Object[0];
      Rotation var17 = var5;
      float var10001 = var17.bReturningFloat(var18) + var6 / 2.0F;
      FrameTimer var10002 = Prestige.h;
      Object[] var20 = new Object[0];
      FrameTimer var19 = var10002;
      float var53 = var19.aReturningFloat(var20) * (1.1F - var1) * 7.0F / var2;
      Object[] var10007 = new Object[]{null, null, var11};
      var10007[1] = 1.0F;
      var10007[0] = 0.5F;
      Object[] var21 = var10007;
      float var54 = var53 * RandomUtil.aReturningFloat(var21);
      Object[] var10005 = new Object[]{null, null, null, var7};
      var10005[2] = var54;
      var10005[1] = var10001;
      var10005[0] = var10000;
      Object[] var22 = var10005;
      float var14 = cReturningFloat(var22);
      int var49 = Event.cReturningInt();
      MinecraftClient var23 = b;
      ClientPlayerEntity var24 = var23.player;
      Object[] var25 = new Object[]{new Rotation(var24.getYaw(), var14), var9};
      aReturningVoid(var25);
      int var13 = var49;
      MinecraftClient var26 = b;
      ClientPlayerEntity var27 = var26.player;
      var10000 = var27.getPitch() - 1.0F;
      Object[] var29 = new Object[0];
      Rotation var28 = var5;
      float var55;
      int var51 = (var55 = var10000 - var28.bReturningFloat(var29)) == 0.0F ? 0 : (var55 < 0.0F ? -1 : 1);
      int var41 = var13;
      int var40 = var51;
      int var36 = var40;
      int var35 = var40;
      if (var41 != 0) {
         int var42 = var35;
         if (var42 >= 0) {
            return false;
         }

         MinecraftClient var31 = b;
         ClientPlayerEntity var32 = var31.player;
         var10000 = var32.getPitch() + 1.0F;
         Object[] var34 = new Object[0];
         Rotation var33 = var5;
         float var56;
         int var43 = (var56 = var10000 - var33.bReturningFloat(var34)) == 0.0F ? 0 : (var56 < 0.0F ? -1 : 1);
         var36 = var43;
      }

      int var45 = var13;
      int var44 = var36;
      int var38 = var44;
      int var37 = var44;
      if (var45 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var38);
      } else {
         int var46 = var37;
         if (var46 > 0) {
            byte var57 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var57);
         } else {
            return false;
         }
      }
   }

    public static boolean eReturningBoolean(Object[] objectArray) {
        float f;
        block8: {
            block7: {
                int n;
                long l;
                block6: {
                    Rotation dx_C02102 = (Rotation)objectArray[0];
                    float f10 = ((Float)objectArray[1]).floatValue();
                    float f11 = ((Float)objectArray[2]).floatValue();
                    float f12 = ((Float)objectArray[3]).floatValue();
                    l = (Long)objectArray[4];
                    long l2 = l = 0x4D9DF455CD8DL ^ l;
                    long l3 = l2 ^ 0x581D8466B669L;
                    long l4 = l2 ^ 0x2EA7C2B40B57L;
                    long l5 = l2 ^ 0x2B016325D7D8L;
                    int n2 = RotationUtil.invokeBinding28(5996005504043241099L, l);
                    Object[] objectArray2 = new Object[3];
                    objectArray2[2] = l5;
                    objectArray2[1] = Float.valueOf(1.0f);
                    objectArray2[0] = Float.valueOf(0.5f);
                    Object[] objectArray3 = new Object[4];
                    objectArray3[3] = l3;
                    objectArray3[2] = Float.valueOf(RotationUtil.invokeBinding33(RotationUtil.invokeBinding32(5995566187251486158L, l), new Object[0], 5992688875341106978L, l) * (1.1f - f10) * 7.0f / f12 * RotationUtil.invokeBinding34(objectArray2, 5995266354061763347L, l));
                    objectArray3[1] = Float.valueOf(RotationUtil.invokeBinding31(dx_C02102, new Object[0], 5994398221667421683L, l) + f11 / 2.0f);
                    objectArray3[0] = Float.valueOf(RotationUtil.invokeBinding30(RotationUtil.invokeBinding29(b, 5994608988579692340L, l), 5993905046020314494L, l));
                    float f13 = RotationUtil.invokeBinding35(objectArray3, 5996303733514661576L, l);
                    Object[] objectArray4 = new Object[2];
                    objectArray4[1] = l4;
                    objectArray4[0] = new Rotation(f13, RotationUtil.invokeBinding37(RotationUtil.invokeBinding36(b, 5994608988579692340L, l), 5992508803189498490L, l));
                    RotationUtil.invokeBinding38(objectArray4, 5993832465765695294L, l);
                    n = n2;
                    try {
                        try {
                            float f14 = RotationUtil.invokeBinding40(RotationUtil.invokeBinding39(b, 5994608988579692340L, l), 5993905046020314494L, l) - 5.0f - RotationUtil.invokeBinding41(dx_C02102, new Object[0], 5994398221667421683L, l);
                            f = f14 == 0.0f ? 0 : (f14 < 0.0f ? -1 : 1);
                            if (n == 0) break block6;
                            if (f >= 0) break block7;
                        }
                        catch (MatchException matchException) {
                            throw RotationUtil.invokeBinding42(matchException, 5996059498595276001L, l);
                        }
                        float f15 = RotationUtil.invokeBinding44(RotationUtil.invokeBinding43(b, 5994608988579692340L, l), 5993905046020314494L, l) + 5.0f - RotationUtil.invokeBinding45(dx_C02102, new Object[0], 5994398221667421683L, l);
                        f = f15 == 0.0f ? 0 : (f15 > 0.0f ? 1 : -1);
                    }
                    catch (MatchException matchException) {
                        throw RotationUtil.invokeBinding46(matchException, 5996059498595276001L, l);
                    }
                }
                try {
                    if (n == 0) break block8;
                    if (f <= 0) break block7;
                }
                catch (MatchException matchException) {
                    throw RotationUtil.invokeBinding47(matchException, 5996059498595276001L, l);
                }
                f = 1;
                break block8;
            }
            f = 0;
        }
        return dev.prestige.recovery.SourceSupport.asBoolean(f);
    }

   public static boolean fReturningBoolean(Object[] var0) {
      Rotation var3 = (Rotation)var0[0];
      Rotation var4 = (Rotation)var0[1];
      float var5 = (Float)var0[2];
      long var1 = (Long)var0[3];
      long var10000 = 85340804468109L ^ var1;
      Object[] var11 = new Object[0];
      Rotation var10 = var4;
      float var12 = var10.aReturningFloat(var11);
      float var32 = Math.abs(var12);
      Object[] var14 = new Object[0];
      Rotation var13 = var3;
      float var15 = var13.aReturningFloat(var14);
      float var16 = var32 - Math.abs(var15);
      float var7 = Math.abs(var16);
      int var33 = Event.cReturningInt();
      Object[] var18 = new Object[0];
      Rotation var17 = var4;
      float var10001 = var17.bReturningFloat(var18);
      Object[] var20 = new Object[0];
      Rotation var19 = var3;
      float var21 = var19.bReturningFloat(var20);
      float var22 = var10001 - Math.abs(var21);
      float var8 = Math.abs(var22);
      double var23 = var7 * var7 + var8 * var8;
      float var9 = (float)Math.sqrt(var23);
      int var6 = var33;
      float var35;
      int var34 = (var35 = var9 - var5) == 0.0F ? 0 : (var35 < 0.0F ? -1 : 1);
      int var29 = var6;
      int var28 = var34;
      int var26 = var28;
      int var25 = var28;
      if (var29 != 0) {
         int var30 = var25;
         if (var30 > 0) {
            return false;
         }

         var26 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var26);
   }

   public static float aReturningFloat(Object[] var0) {
      Rotation var3 = (Rotation)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 85340804468109L ^ var1;
      Object[] var7 = new Object[0];
      Rotation var6 = var3;
      float var8 = var6.aReturningFloat(var7);
      float var21 = Math.abs(var8);
      MinecraftClient var9 = b;
      ClientPlayerEntity var10 = var9.player;
      float var11 = var10.getYaw();
      float var12 = var21 - Math.abs(var11);
      float var4 = Math.abs(var12);
      Object[] var14 = new Object[0];
      Rotation var13 = var3;
      float var22 = var13.bReturningFloat(var14);
      MinecraftClient var15 = b;
      ClientPlayerEntity var16 = var15.player;
      float var17 = var16.getPitch();
      float var18 = var22 - Math.abs(var17);
      float var5 = Math.abs(var18);
      double var19 = var4 * var4 + var5 * var5;
      return (float)Math.sqrt(var19);
   }

   public static BlockHitResult aReturningBlockHitResult(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      long var2 = (Long)var0[1];
      var2 = 85340804468109L ^ var2;
      long var4 = var2 ^ 15035435572954L;
      return invokeBinding60(
         invokeBinding48(b, -8043495440762549094L, var2),
         invokeBinding50(invokeBinding49(b, -8044833059165488034L, var2), -8052209336239757245L, var2),
         invokeBinding56(
            invokeBinding53(
               invokeBinding52(new Object[]{invokeBinding51(b, -8044833059165488034L, var2), var4}, -8044056018747221090L, var2),
               6.0,
               -8045724546287261721L,
               var2
            ),
            invokeBinding55(invokeBinding54(b, -8044833059165488034L, var2), -8052209336239757245L, var2),
            -8045909538107899105L,
            var2
         ),
         var1,
         invokeBinding57(-8045186346252201913L, var2),
         invokeBinding59(invokeBinding58(b, -8043495440762549094L, var2), var1, -8044975792456352062L, var2),
         -8051360488473677815L,
         var2
      );
   }

   public static BlockHitResult bReturningBlockHitResult(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      PlayerEntity var4 = (PlayerEntity)var0[1];
      long var1 = (Long)var0[2];
      var1 = 85340804468109L ^ var1;
      long var5 = var1 ^ 69148580995865L;
      return invokeBinding70(
         invokeBinding61(b, 3286766587332227417L, var1),
         invokeBinding62(var4, 3279142030361455324L, var1),
         invokeBinding66(
            invokeBinding64(invokeBinding63(new Object[]{var4, var5}, 3287336240569525853L, var1), 6.0, 3284508861858880036L, var1),
            invokeBinding65(var4, 3279142030361455324L, var1),
            3284281536869203676L,
            var1
         ),
         var3,
         invokeBinding67(3286205973319921028L, var1),
         invokeBinding69(invokeBinding68(b, 3286766587332227417L, var1), var3, 3285853577072149249L, var1),
         3278867937913048522L,
         var1
      );
   }

   public static BlockHitResult cReturningBlockHitResult(Object[] var0) {
      BlockPos var1 = (BlockPos)var0[0];
      Rotation var2 = (Rotation)var0[1];
      long var3 = (Long)var0[2];
      var3 = 85340804468109L ^ var3;
      long var5 = var3 ^ 33359593381984L;
      return invokeBinding82(
         invokeBinding71(b, -836319000939353951L, var3),
         invokeBinding73(invokeBinding72(b, -837654982464808859L, var3), -829856905410245512L, var3),
         invokeBinding78(
            invokeBinding75(invokeBinding74(new Object[]{var2, var5}, -828723717600314620L, var3), 6.0, -834054436263410724L, var3),
            invokeBinding77(invokeBinding76(b, -837654982464808859L, var3), -829856905410245512L, var3),
            -834256472436070620L,
            var3
         ),
         var1,
         invokeBinding79(-836879620353100676L, var3),
         invokeBinding81(invokeBinding80(b, -836319000939353951L, var3), var1, -837230911807038727L, var3),
         -830670568634231758L,
         var3
      );
   }

   public static BlockHitResult dReturningBlockHitResult(Object[] var0) {
      BlockPos var3 = (BlockPos)var0[0];
      Rotation var4 = (Rotation)var0[1];
      long var1 = (Long)var0[2];
      var1 = 85340804468109L ^ var1;
      long var5 = var1 ^ 44620048804238L;
      return invokeBinding94(
         invokeBinding83(b, -177053741117628081L, var1),
         invokeBinding85(invokeBinding84(b, -176137396712681077L, var1), -173961116169271914L, var1),
         invokeBinding90(
            invokeBinding87(invokeBinding86(new Object[]{var4, var5}, -175078635355245846L, var1), 6.0, -179333460145452494L, var1),
            invokeBinding89(invokeBinding88(b, -176137396712681077L, var1), -173961116169271914L, var1),
            -179555835419119926L,
            var1
         ),
         var3,
         invokeBinding91(-176492882293097070L, var1),
         invokeBinding93(invokeBinding92(b, -177053741117628081L, var1), var3, -175719377929383145L, var1),
         -173692844900262436L,
         var1
      );
   }

   public static HitResult aReturningHitResult(Object[] var0) {
      Rotation var1 = (Rotation)var0[0];
      long var2 = (Long)var0[1];
      var2 = 85340804468109L ^ var2;
      long var4 = var2 ^ 48025551182821L;
      MinecraftClient var6 = b;
      ClientWorld var10000 = var6.world;
      MinecraftClient var7 = b;
      ClientPlayerEntity var8 = var7.player;
      Vec3d var10003 = var8.getEyePos();
      Object[] var9 = new Object[]{var1, var4};
      Vec3d var10004 = aReturningVec3d(var9);
      double var11 = 6.0;
      Vec3d var10 = var10004;
      var10004 = var10.multiply(var11);
      MinecraftClient var13 = b;
      ClientPlayerEntity var14 = var13.player;
      Vec3d var16 = var14.getEyePos();
      Vec3d var15 = var10004;
      var10004 = var15.add(var16);
      MinecraftClient var17 = b;
      RaycastContext var19 = new RaycastContext(var10003, var10004, ShapeType.OUTLINE, FluidHandling.NONE, var17.player);
      ClientWorld var18 = var10000;
      return var18.raycast(var19);
   }

   public static HitResult bReturningHitResult(Object[] var0) {
      Rotation var3 = (Rotation)var0[0];
      float var4 = (Float)var0[1];
      long var1 = (Long)var0[2];
      var1 = 85340804468109L ^ var1;
      long var5 = var1 ^ 105685681301087L;
      MinecraftClient var7 = b;
      ClientWorld var10000 = var7.world;
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      Vec3d var10003 = var9.getEyePos();
      Object[] var10 = new Object[]{var3, var5};
      Vec3d var10004 = aReturningVec3d(var10);
      double var12 = var4;
      Vec3d var11 = var10004;
      var10004 = var11.multiply(var12);
      MinecraftClient var14 = b;
      ClientPlayerEntity var15 = var14.player;
      Vec3d var17 = var15.getEyePos();
      Vec3d var16 = var10004;
      var10004 = var16.add(var17);
      MinecraftClient var18 = b;
      RaycastContext var20 = new RaycastContext(var10003, var10004, ShapeType.OUTLINE, FluidHandling.NONE, var18.player);
      ClientWorld var19 = var10000;
      return var19.raycast(var20);
   }

   public static Vec3d aReturningVec3d(Object[] var0) {
      Rotation var3 = (Rotation)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 85340804468109L ^ var1;
      float var4 = (float) (Math.PI / 180.0);
      float var5 = (float) Math.PI;
      Object[] var11 = new Object[0];
      Rotation var10 = var3;
      double var12 = -var10.aReturningFloat(var11) * var4 - var5;
      float var6 = MathHelper.cos(var12);
      Object[] var15 = new Object[0];
      Rotation var14 = var3;
      double var16 = -var14.aReturningFloat(var15) * var4 - var5;
      float var7 = MathHelper.sin(var16);
      Object[] var19 = new Object[0];
      Rotation var18 = var3;
      double var20 = -var18.bReturningFloat(var19) * var4;
      float var8 = -MathHelper.cos(var20);
      Object[] var23 = new Object[0];
      Rotation var22 = var3;
      double var24 = -var22.bReturningFloat(var23) * var4;
      float var9 = MathHelper.sin(var24);
      Vec3d var26 = new Vec3d(var7 * var8, var9, var6 * var8);
      return var26.normalize();
   }

   private static Vec3d bReturningVec3d(Object[] var0) {
      PlayerEntity var1 = (PlayerEntity)var0[0];
      long var2 = (Long)var0[1];
      var2 = 85340804468109L ^ var2;
      float var4 = (float) (Math.PI / 180.0);
      float var5 = (float) Math.PI;
      float var6 = invokeBinding96(-invokeBinding95(var1, -9004522427781993271L, var2) * var4 - var5, -9001539979640098660L, var2);
      float var7 = invokeBinding98(-invokeBinding97(var1, -9004522427781993271L, var2) * var4 - var5, -9004827956992515230L, var2);
      float var8 = -invokeBinding100(-invokeBinding99(var1, -9000638529496624075L, var2) * var4, -9001539979640098660L, var2);
      float var9 = invokeBinding102(-invokeBinding101(var1, -9000638529496624075L, var2) * var4, -9004827956992515230L, var2);
      return invokeBinding103(new Vec3d(var7 * var8, var9, var6 * var8), -9004135192559727088L, var2);
   }

   public static void aReturningVoid(Object[] var0) {
      Rotation var3 = (Rotation)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 85340804468109L ^ var1;
      MinecraftClient var4 = b;
      ClientPlayerEntity var14 = var4.player;
      Object[] var6 = new Object[0];
      Rotation var5 = var3;
      float var8 = var5.aReturningFloat(var6);
      ClientPlayerEntity var7 = var14;
      var7.setYaw(var8);
      MinecraftClient var9 = b;
      ClientPlayerEntity var15 = var9.player;
      Object[] var11 = new Object[0];
      Rotation var10 = var3;
      float var13 = var10.bReturningFloat(var11);
      ClientPlayerEntity var12 = var15;
      var12.setPitch(var13);
   }

   public static void bReturningVoid(Object[] var0) {
      float var1 = (Float)var0[0];
      float var2 = (Float)var0[1];
      long var3 = (Long)var0[2];
      var3 = 85340804468109L ^ var3;
      long var5 = var3 ^ 105836742269102L;
      invokeBinding104(new Object[]{new Rotation(var1, var2), var5}, 60534966638062791L, var3);
   }

   public static Rotation aReturningdx_C0210(Object[] var0) {
      Vec3d var3 = (Vec3d)var0[0];
      long var1 = (Long)var0[1];
      var1 = 85340804468109L ^ var1;
      long var4 = var1 ^ 84682412615613L;
      Vec3d var6 = var3;
      float var10000 = (float)var6.x;
      Vec3d var7 = var3;
      float var10001 = (float)var7.y;
      Vec3d var8 = var3;
      float var10002 = (float)var8.z;
      Object[] var10005 = new Object[]{null, null, null, var4};
      var10005[2] = var10002;
      var10005[1] = var10001;
      var10005[0] = var10000;
      Object[] var9 = var10005;
      return bReturningdx_C0210(var9);
   }

   public static Rotation bReturningdx_C0210(Object[] var0) {
      float var1 = (Float)var0[0];
      float var5 = (Float)var0[1];
      float var4 = (Float)var0[2];
      long var2 = (Long)var0[3];
      var2 = 85340804468109L ^ var2;
      long var6 = var2 ^ 47804197587333L;
      MinecraftClient var20 = b;
      ClientPlayerEntity var21 = var20.player;
      Vec3d var8 = var21.getEyePos();
      double var10000 = var1;
      Vec3d var22 = var8;
      double var9 = var10000 - var22.x;
      var10000 = var5;
      Vec3d var23 = var8;
      double var11 = var10000 - var23.y;
      var10000 = var4;
      Vec3d var24 = var8;
      double var13 = var10000 - var24.z;
      double var25 = var9 * var9 + var13 * var13;
      double var15 = Math.sqrt(var25);
      double var29 = var9;
      double var27 = var13;
      double var31 = Math.atan2(var27, var29);
      float var17 = (float)Math.toDegrees(var31) - 90.0F;
      double var35 = var15;
      double var33 = var11;
      double var37 = Math.atan2(var33, var35);
      float var18 = (float)(-Math.toDegrees(var37));
      float[] var48 = new float[2];
      MinecraftClient var39 = b;
      ClientPlayerEntity var40 = var39.player;
      var48[0] = var40.getYaw();
      MinecraftClient var41 = b;
      ClientPlayerEntity var42 = var41.player;
      var48[1] = var42.getPitch();
      float[] var19 = var48;
      float var10002 = var19[0];
      float var10003 = var17 - var19[0];
      Object[] var10006 = new Object[]{null, var6};
      var10006[0] = var10003;
      Object[] var43 = var10006;
      var10002 += bReturningFloat(var43);
      var10003 = var19[1];
      float var10004 = var18 - var19[1];
      Object[] var10007 = new Object[]{null, var6};
      var10007[0] = var10004;
      Object[] var44 = var10007;
      return new Rotation(var10002, var10003 + bReturningFloat(var44));
   }

   public static Rotation cReturningdx_C0210(Object[] var0) {
      Rotation var5 = (Rotation)var0[0];
      Vec3d var3 = (Vec3d)var0[1];
      float var4 = (Float)var0[2];
      long var1 = (Long)var0[3];
      var1 = 85340804468109L ^ var1;
      long var6 = var1 ^ 97702700070346L;
      Object[] var9 = new Object[0];
      Rotation var8 = var5;
      float var10000 = var8.aReturningFloat(var9);
      Object[] var11 = new Object[0];
      Rotation var10 = var5;
      float var10001 = var10.bReturningFloat(var11);
      Vec3d var12 = var3;
      float var10002 = (float)var12.x;
      Vec3d var13 = var3;
      float var10003 = (float)var13.y;
      Vec3d var14 = var3;
      float var10004 = (float)var14.z;
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var6};
      var10008[5] = var4;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var10000;
      Object[] var15 = var10008;
      return eReturningdx_C0210(var15);
   }

   public static Rotation dReturningdx_C0210(Object[] var0) {
      Rotation var4 = (Rotation)var0[0];
      Vec3d var1 = (Vec3d)var0[1];
      long var2 = (Long)var0[2];
      var2 = 85340804468109L ^ var2;
      long var5 = var2 ^ 97244893539749L;
      MinecraftClient var14 = b;
      ClientPlayerEntity var15 = var14.player;
      Vec3d var10000 = var15.getEyePos();
      Vec3d var17 = var1;
      Vec3d var16 = var10000;
      double var7 = var16.distanceTo(var17);
      double var20 = 1.0;
      double var18 = var7;
      double var42 = 0.18 / Math.max(var18, var20);
      double var26 = 0.15;
      double var24 = 0.005;
      double var22 = var42;
      float var9 = (float)MathHelper.clamp(var22, var24, var26);
      float var43 = -var9;
      Object[] var10004 = new Object[]{null, null, var5};
      var10004[1] = var9;
      var10004[0] = var43;
      Object[] var28 = var10004;
      float var10 = RandomUtil.aReturningFloat(var28);
      float var44 = -var9;
      var10004 = new Object[]{null, null, var5};
      var10004[1] = var9;
      var10004[0] = var44;
      Object[] var29 = var10004;
      float var11 = RandomUtil.aReturningFloat(var29);
      Object[] var31 = new Object[0];
      Rotation var30 = var4;
      float var45 = var30.bReturningFloat(var31) + var11;
      float var34 = 89.9F;
      float var33 = -89.9F;
      float var32 = var45;
      float var12 = MathHelper.clamp(var32, var33, var34);
      Object[] var36 = new Object[0];
      Rotation var35 = var4;
      Rotation var13 = new Rotation(var35.aReturningFloat(var36) + var10, var12);
      Object[] var38 = new Object[0];
      Rotation var37 = var4;
      Object[] var40 = new Object[]{var37.aReturningBoolean(var38)};
      Rotation var39 = var13;
      var39.cReturningVoid(var40);
      return var13;
   }

   public static Rotation eReturningdx_C0210(Object[] var0) {
      float var1;
      float var7;
      float var8;
      long var9;
      float var22;
      float var23;
      int var57;
      label15: {
         var7 = (Float)var0[0];
         var8 = (Float)var0[1];
         float var3 = (Float)var0[2];
         float var2 = (Float)var0[3];
         float var6 = (Float)var0[4];
         var1 = (Float)var0[5];
         long var4 = (Long)var0[6];
         var4 = 85340804468109L ^ var4;
         var9 = var4 ^ 133622284967767L;
         int var10000 = Event.cReturningInt();
         MinecraftClient var27 = b;
         ClientPlayerEntity var28 = var27.player;
         Vec3d var12 = var28.getEyePos();
         double var10001 = var3;
         Vec3d var29 = var12;
         double var13 = var10001 - var29.x;
         var10001 = var2;
         Vec3d var30 = var12;
         double var15 = var10001 - var30.y;
         var10001 = var6;
         Vec3d var31 = var12;
         double var17 = var10001 - var31.z;
         double var32 = var13 * var13 + var17 * var17;
         double var19 = Math.sqrt(var32);
         double var36 = var13;
         double var34 = var17;
         double var38 = Math.atan2(var34, var36);
         float var21 = (float)Math.toDegrees(var38) - 90.0F;
         int var11 = var10000;
         double var42 = var19;
         double var40 = var15;
         double var44 = Math.atan2(var40, var42);
         var22 = (float)(-Math.toDegrees(var44));
         float var64 = var21 - var7;
         Object[] var10003 = new Object[]{null, var9};
         var10003[0] = var64;
         Object[] var46 = var10003;
         var23 = bReturningFloat(var46);
         float var47 = var23;
         float var69;
         var10000 = (var69 = Math.abs(var47) - var1) == 0.0F ? 0 : (var69 < 0.0F ? -1 : 1);
         int var59 = var11;
         int var58 = var10000;
         int var56 = var58;
         int var55 = var58;
         if (var59 != 0) {
            int var60 = var55;
            if (var60 <= 0) {
               var57 = 0;
               break label15;
            }

            var56 = 1;
         }

         int var61 = var56;
         var57 = var61;
      }

      int var24 = var57;
      float var68 = -var1;
      float var51 = var1;
      float var50 = var68;
      float var49 = var23;
      var23 = MathHelper.clamp(var49, var50, var51);
      float var25 = var7 + var23;
      float var10004 = var22 - var8;
      Object[] var10007 = new Object[]{null, var9};
      var10007[0] = var10004;
      Object[] var52 = var10007;
      Rotation var26 = new Rotation(var25, var8 + bReturningFloat(var52));
      Object[] var54 = new Object[]{Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var24))};
      Rotation var53 = var26;
      var53.cReturningVoid(var54);
      return var26;
   }

   public static Rotation fReturningdx_C0210(Object[] var0) {
      Entity var1 = (Entity)var0[0];
      Vec3d var2 = (Vec3d)var0[1];
      long var3 = (Long)var0[2];
      var3 = 85340804468109L ^ var3;
      long var5 = var3 ^ 42696530847003L;
      float var10001 = (float)invokeBinding105(var2, -2927958551525732160L, var3);
      float var10002 = (float)invokeBinding106(var2, -2935752184007244266L, var3);
      float var10003 = (float)invokeBinding107(var2, -2934627465529376020L, var3);
      Object[] var10006 = new Object[]{null, null, null, null, var5};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var1;
      return invokeBinding108(var10006, -2927593221673779866L, var3);
   }

   public static Rotation g(Object[] var0) {
      Entity var5 = (Entity)var0[0];
      float var4 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var3 = (Float)var0[3];
      long var1 = (Long)var0[4];
      var1 = 85340804468109L ^ var1;
      long var7 = var1 ^ 44149460428861L;
      Vec3d var9 = invokeBinding109(var5, -12591293243483836L, var1);
      double var10 = var4 - invokeBinding110(var9, -14735117412599722L, var1);
      double var12 = var6 - invokeBinding111(var9, -12253259964879232L, var1);
      double var14 = var3 - invokeBinding112(var9, -13387006468134278L, var1);
      double var16 = invokeBinding113(var10 * var10 + var14 * var14, -15299876076163320L, var1);
      float var18 = (float)invokeBinding115(invokeBinding114(var14, var10, -12657672472721932L, var1), -13196298021900963L, var1) - 90.0F;
      float var19 = (float)(-invokeBinding117(invokeBinding116(var12, var16, -12657672472721932L, var1), -13196298021900963L, var1));
      float[] var20 = new float[]{invokeBinding118(var5, -11393994244521047L, var1), invokeBinding119(var5, -13286551991197621L, var1)};
      float var10002 = var20[0];
      float var10003 = var18 - var20[0];
      Object[] var10006 = new Object[]{null, var7};
      var10006[0] = var10003;
      var10002 += invokeBinding120(var10006, -12037118842673312L, var1);
      var10003 = var20[1];
      float var10004 = var19 - var20[1];
      Object[] var10007 = new Object[]{null, var7};
      var10007[0] = var10004;
      return new Rotation(var10002, var10003 + invokeBinding121(var10007, -12037118842673312L, var1));
   }

   public static float bReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 85340804468109L ^ var2;
      int var17 = Event.cReturningInt();
      float var5 = var1 % 360.0F;
      int var4 = var17;
      float var19;
      int var18 = (var19 = var5 - 180.0F) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
      int var11 = var4;
      int var10 = var18;
      int var8 = var10;
      int var6 = var10;
      if (var11 != 0) {
         int var12 = var6;
         if (var12 >= 0) {
            var5 -= 360.0F;
         }

         int var14 = var4;
         float var13 = var5;
         float var9 = var13;
         float var7 = var13;
         if (var14 == 0) {
            return var9;
         }

         float var20;
         int var15 = (var20 = var7 - -180.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
         var8 = var15;
      }

      int var16 = var8;
      if (var16 < 0) {
         var5 += 360.0F;
      }

      return var5;
   }

   public static float cReturningFloat(Object[] var0) {
      float var5 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var4 = (Float)var0[2];
      long var2 = (Long)var0[3];
      var2 = 85340804468109L ^ var2;
      long var6 = var2 ^ 97292391824224L;
      float var8 = var5;
      float var10001 = var8 - var1;
      Object[] var10007 = new Object[]{null, null, null, var6};
      var10007[2] = 1.0F;
      var10007[1] = 0.0F;
      var10007[0] = var4;
      Object[] var9 = var10007;
      return var8 - var10001 * dReturningFloat(var9);
   }

   private static float dReturningFloat(Object[] var0) {
      float var5 = (Float)var0[0];
      float var4 = (Float)var0[1];
      float var1 = (Float)var0[2];
      long var2 = (Long)var0[3];
      long var10000 = 85340804468109L ^ var2;
      int var6 = Event.cReturningInt();
      int var17 = var6;
      float var16 = var4;
      float var15 = var5;
      float var13 = var15;
      float var14 = var16;
      float var11 = var15;
      float var12 = var16;
      if (var17 != 0) {
         float var19;
         int var18 = (var19 = var11 - var12) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
         if (var18 < 0) {
            return var4;
         }

         var14 = var1;
         var13 = var5;
      }

      float var10 = var14;
      float var9 = var13;
      return Math.min(var9, var10);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 2;
            yield var15;
         }
         case 1 -> {
            byte var16 = 3;
            yield var16;
         }
         case 2 -> {
            byte var17 = 49;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 4;
            yield var19;
         }
         case 5 -> {
            byte var20 = 14;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 50;
            yield var22;
         }
         case 8 -> {
            byte var23 = 41;
            yield var23;
         }
         case 9 -> {
            byte var24 = 15;
            yield var24;
         }
         case 10 -> {
            byte var25 = 32;
            yield var25;
         }
         case 11 -> {
            byte var26 = 35;
            yield var26;
         }
         case 12 -> {
            byte var27 = 46;
            yield var27;
         }
         case 13 -> {
            byte var28 = 31;
            yield var28;
         }
         case 14 -> {
            byte var29 = 21;
            yield var29;
         }
         case 15 -> {
            byte var30 = 0;
            yield var30;
         }
         case 16 -> {
            byte var31 = 37;
            yield var31;
         }
         case 17 -> {
            byte var32 = 57;
            yield var32;
         }
         case 18 -> {
            byte var33 = 48;
            yield var33;
         }
         case 19 -> {
            byte var34 = 55;
            yield var34;
         }
         case 20 -> {
            byte var35 = 33;
            yield var35;
         }
         case 21 -> {
            byte var36 = 38;
            yield var36;
         }
         case 22 -> {
            byte var37 = 60;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 63;
            yield var39;
         }
         case 25 -> {
            byte var40 = 19;
            yield var40;
         }
         case 26 -> {
            byte var41 = 47;
            yield var41;
         }
         case 27 -> {
            byte var42 = 13;
            yield var42;
         }
         case 28 -> {
            byte var43 = 30;
            yield var43;
         }
         case 29 -> {
            byte var44 = 52;
            yield var44;
         }
         case 30 -> {
            byte var45 = 43;
            yield var45;
         }
         case 31 -> {
            byte var46 = 53;
            yield var46;
         }
         case 32 -> {
            byte var47 = 20;
            yield var47;
         }
         case 33 -> {
            byte var48 = 17;
            yield var48;
         }
         case 34 -> {
            byte var49 = 27;
            yield var49;
         }
         case 35 -> {
            byte var50 = 36;
            yield var50;
         }
         case 36 -> {
            byte var51 = 5;
            yield var51;
         }
         case 37 -> {
            byte var52 = 22;
            yield var52;
         }
         case 38 -> {
            byte var53 = 25;
            yield var53;
         }
         case 39 -> {
            byte var54 = 23;
            yield var54;
         }
         case 40 -> {
            byte var55 = 7;
            yield var55;
         }
         case 41 -> {
            byte var56 = 24;
            yield var56;
         }
         case 42 -> {
            byte var57 = 34;
            yield var57;
         }
         case 43 -> {
            byte var58 = 12;
            yield var58;
         }
         case 44 -> {
            byte var59 = 62;
            yield var59;
         }
         case 45 -> {
            byte var60 = 42;
            yield var60;
         }
         case 46 -> {
            byte var61 = 18;
            yield var61;
         }
         case 47 -> {
            byte var62 = 59;
            yield var62;
         }
         case 48 -> {
            byte var63 = 10;
            yield var63;
         }
         case 49 -> {
            byte var64 = 29;
            yield var64;
         }
         case 50 -> {
            byte var65 = 44;
            yield var65;
         }
         case 51 -> {
            byte var66 = 58;
            yield var66;
         }
         case 52 -> {
            byte var67 = 39;
            yield var67;
         }
         case 53 -> {
            byte var68 = 28;
            yield var68;
         }
         case 54 -> {
            byte var69 = 26;
            yield var69;
         }
         case 55 -> {
            byte var70 = 56;
            yield var70;
         }
         case 56 -> {
            byte var71 = 6;
            yield var71;
         }
         case 57 -> {
            byte var72 = 16;
            yield var72;
         }
         case 58 -> {
            byte var73 = 9;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 40;
            yield var75;
         }
         case 61 -> {
            byte var76 = 51;
            yield var76;
         }
         case 62 -> {
            byte var77 = 11;
            yield var77;
         }
         default -> 54;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "tH\u001e3y\u0015tH\tou\u001an\u0003\tqu\u000firX)'";
      c[1] = double.class;
      d[1] = "java/lang/Double";
      c[2] = "\u000b/+Tt\r\u000b/<\bx\u0002\u0011d<\u0016x\u0017\u0016\u0015nH S";
      c[3] = "\u0018\u000eh:cT\u0013\u0001yu\u0000Y\u0006\u0007";
      c[4] = float.class;
      d[4] = "java/lang/Float";
      c[5] = "G`'Z[eQ`\"\u0000HrF+!\u0006DfWl6\u0011\u000fqa";
      c[6] = "GF@V\u0006Z2fKY\u0017\u0015Sh@R\u0013O'";
      c[7] = "9bTh\u0014+LB_g\u0005d-LTl\u0001>Y";
      c[8] = void.class;
      d[8] = "java/lang/Void";
      c[9] = "_N6`>b_N!<2mE\u0005!\"2xBtuze";
      c[10] = "\u0010Wf\u0013=!ewm\u001c,n\u0004yf\u0017(4p";
      c[11] = "\u0015\u000fs\u00021\u0006\u0015\u000fd^=\t\u000fDd@=\u001c\b51\u001fd";
      c[12] = "Fs\u001bmn:Fs\f1b5\\8\f/b [I\\z6j";
      c[13] = "\u0010tdaA8\u0010ts=M7\n?s#M\"\rN#v\u001ad";
      c[14] = "O'azVXO'v&ZWUlv8ZBR\u001d&e\u000b";
      c[15] = "\u0015-S]\u0007H\u0015-D\u0001\u000bG\u000ffD\u001f\u000bR\b\u0017\u0014J_\u0018_+K\u0012\u0019R${\u001eEZ";
      c[16] = "\u0010>M oD\u0010>Z|cK\nuZbc^\r\u0004\n77\u0014Z8Uoq^!i\r<";
      c[17] = "8\u0015i! >3\u001axnC3&\u0017w\u0005v17\u0004k)a<";
      c[18] = "='z&0u+'\u007f|#b<l|z/v-+kmdd\u001c";
      c[19] = int.class;
      d[19] = "java/lang/Integer";
      c[20] = "{\u001c~?FBm\u001c{eUUzWxcYAk\u0010ot\u0012Vg";
      c[21] = "v\u0007\u0012\u0010\u0016\u001e\u0003'\u0019\u001f\u0007Qb)\u0012\u0014\u0003\u000b\u0016";
      c[22] = "mMcPm\u0006\u0018mh_|IyccTx\u0013\r";
      c[23] = "r@\"+\u001cp\u0007`)$\r?fn\"/\te\u0012";
      c[24] = "X\u0002NF9^-\"EI(\u0011L,NB,K8";
      c[25] = "a[\u0016!W\u0003a[\u0001}[\f{\u0010\u0001c[\u0019|aQ:\tX";
      c[26] = "\u0016n\u0000wdmcN\u000bxu\"\u0002@\u0000sqxv";
      c[27] = "P$D\u0014<CP$SH0LJoSV0YM\u001e\u0002\tb\u0012";
      c[28] = "9lB\u001f]Y9lUCQV#'U]QC$V\u0004\u0007\u0005";
      c[29] = "\n\u00070g m\n\u0007';,b\u0010L'%,w\u0017=v\u007fu4";
      c[30] = "q/c|l9q/t `6kdt>`#l\u0015%g8";
      c[31] = "l,I\u001d\t\u000f\u0019\fB\u0012\u0018@x\u0002I\u0019\u001c\u001a\f";
      c[32] = "\u0017wh.\u000bjbWc!\u001a%\u0003Yh*\u001e\u007fw";
      c[33] = "io.\u0012z`io9Nvos$9PvztUk\n\">";
      c[34] = "\u0006U;6X#su09Il\u0012{;2M6f";
      c[35] = ",_.4,\\:_+n?K-\u0014(h3_<S?\u007fxH;";
      c[36] = "zQ\u00065Gv\u000fq\r:V9n\u007f\u00061Rc\u001a";
      c[37] = "\u00028\u0004Ul^\u00148\u0001\u000f\u007fI\u0003s\u0002\ts]\u00124\u0015\u001e8M\n4\u0017\u0015b\u00006/\u0017\bbG\u00018";
      c[38] = "\u0018\u0010`\u001dU\u0014m0k\u0012D[\f>`\u0019@\u0001x";
      c[39] = "@L|\u0007\"_VLy]1HA\u0007z[=\\P@mLvKM";
      c[40] = "{j6Z\u0012H\u000eJ=U\u0003\u0007oD6^\u0007]\u001b";
      c[41] = "lS\u0017jx@\u0019s\u001cei\u000fx}\u0017nmU\f";
      c[42] = boolean.class;
      d[42] = "java/lang/Boolean";
      c[43] = "]k0pl%Vd!?\r+]o%e";
      c[44] = "+jK3/ w`F0^x\u0010k\u001b95}.r\u0017m`\u0011..\u0000%oimu\u0001a^";
      c[45] = "\u000f0Vb\b\u0012\t4Qmt\u0018\\&4&\u0018A_:^dE@EV\rsH\u0017Y<O.I\r5oX#\u001e\u0011_-\u0005\"\u0004}";
      c[46] = "\u001dc\u001a9ugAi\u0017:\u0004?&bJ3o:\u0018{Fg:VMwT<{8\u001dh*";
      c[47] = "\u0011A7]!\u0016VE9W^HBFi\u00012z\u0014\u00045[b-\u0014\u0000w\n'\u0010O]`\u000b^";
      c[48] = "!Fn~.\r'B5mP\u0018,Q>t<*x\u0010e-j}xAby<\u0017:\u001cccPF{S2jm\u001d&D3\u0013";
      c[49] = "\u0000,\u0018,e8\u0006(\u001f#\u00192[,zj#)V3G1~>WJAkg;Cw\u001a6p::q@/u.\u0007*\u001d8tW";
      c[50] = "^42\u001e@_\f!s\u001d<W\f8\"APeX{}\u001a\u00012\n*<LC\\Z5BMRL\u000b;,\u001dM2\u0003x-]M\n\u0005-!O<P\u000f%rT\f[\r5;&_^]}y]_W[#B\u0017UY[\u007f ZRH\u0001D";
      c[51] = "XH[pX\u001f\u001fLUz'A\u000bO\u0005,Ks]\rYv\u001a$]\t\u001b'^\u0019\u0006T\f&'";
      c[52] = "pyE0^>,sH3/`Kx\u0015:Dcua\u0019n\u0011\u000f&m\n6B3%a\u000f;/";
      c[53] = "\r\u0004\u00149X`Q\u000e\u0019:);6\u0005D3B=\b\u001cHg\u0017Q[\u0010[?DmX\u001c^2)";
      c[54] = "hV,zL\biG-{pWcEpd\u001ce5\u0002-<I2eWni\u000f\\5H\u0010";
      c[55] = "A\u001e`\r\u0013uG\u001ag\u0002oa\u0002\u0002~pVvG\u0012n\u001a\u0014+F\b\u0002I\u0003&\u0011\u0014h\u000b^'\u000bx";
      c[56] = "w\u0011F4\u0005Nq\u0015A;yH'\f$rC_!\u000e\u0019)\u001eH w\u001fs\u0007M4JD.\u0010LM";
      c[57] = "C\u001e;\u0017uBA\u00015\\\u0018HK\u001eoBO\u001f\u0015N6\u001f\u0018OGC2C|MXMy";
      c[58] = "E,iGM\u0011C(2T3\u0004H;9M_6\u001czb\u0017\u000ba\u001c+e@_\u000b^vdZ3XI{3FY\u001a\u0014z)*\n\r\u0019-5@HP\u00187Y\u0013_]O+3Q\u0002\\UG";
      c[59] = "L\u001d'_|b^\u0019{\\\u0007rGKxNP%\u001d\u001a,\"m'\u001d[g\\\u007f#AX";
      c[60] = "{\u0004j\u001fXo}\u0001?\u0007<b\u001c\u00031\u0005Wg\"\u001a=Q\u0002\u000b'B/\fE6|\u001f8\r<";
      c[61] = "(%.V$=)4/W\u0018b#6rHtPut.\u0012%\u0007uplCa:.-{B\u0018";
      c[62] = "\u0000\r\u000brE}G\t\u0005x:#S\nU.V\u0011\u0005M\bv\u0003FU\u0018K#E(\u0005\u00075";
      c[63] = "\\Xy|\">\fG\u0007x<=SZP/fm\r6>za:[\\|'` ";
      c[64] = "lg-,\u0007t<xS(\u0019wce\u0004\u007fC'>\tj*Dpkc(wEj";
      c[65] = "f\u0012Qsi!`\u0016\n`\u00174k\u0005\u0001y{\u0006?DZ!+Q?\u0015]t{;}H\\n\u0017j<\u0007\rg*1a\u0010\f\u001e";
      c[66] = "(YE\u0014\f(&@U_v|xFHB!+'\u001b\u0013.Ibi\u0013PC\u001bw(\u0010";
      c[67] = "jL(fbli@-k\u000f9\u0007Y7jd<9@;>1P{E1lf1<Fm7\u000f";
      c[68] = "\u0012\u001dm\u0019W\u001c\u0014\u00196\n)\t\u001f\n=\u0013E;KKfJ\u0012lIL#\u0018PQ\u0012\u00114\u0019)WH\b1\r\u0014\f\u0015\u001f0t\u0012V\f\u001a$II\u000b\u001b\u001b]O\u0013\u0012\u001e\u000f`\u0014N\u0005\u001fv";
      c[69] = "*#6{rGv);x\u0003\u001c\u0011\"fqh\u001a/;j%=v*cxxzKq>oy\u0003";
      c[70] = "^7\u000eJ\u0010$_&\u000fK,{U$RT@I\u0003f\u000e\u000e\u0010\u001e\u0003bL_U#X?[^,";
      c[71] = "j\u000fZfR>p\u0019\u0005i+9\u0012\u0017A;T=v\u0011DnL";
      c[72] = "\u0012qQ\u0013RL\u0015|LL-OybY\u001b\u0011K\u001ceX\u001cK%";
      c[73] = "PO\u0014:){\fE\u00199X!kND03&UWHdfJP\u000fZ9!w\u000bRM8X";
      c[74] = "D3&\u0005|\u0006\u00189+\u0006\r]\u007f2v\u000ff[A+z[37\u0014'h\u0000rYD8\u0016";
      c[75] = "V)tU\u00156\u00066\nZ\u0007$] fhS`\u0007v\nT\u0004&W8d\u0004\u001bX";
      c[76] = "\u000f\u0016}\u0017x\u000fS\u001cp\u0014\tW4\u0007q\u00015PZ\r \u0004u>_P4DgPU\u00011\u0004\t";
      c[77] = "\u0015\u007f7H|\u001f\u0012r*\u0017\u0003\u001d~l?@?\u0018\u001bk>Gev";
      c[78] = ";!Jj\u0018\u001c|%D`gBh&\u00146\u000bp>dHlX'>`\n=\u001e\u001ae=\u001d<g\u0019;!\r`\u001fZ` IQ";
      c[79] = "!J\u001aT\u001d\u0002q\u0015M\u0012\u007f\u0001uPDO\u00133#\u0012\u0018\u0015Cd#\u0016ZD\u0006YxKME\u007f";
      c[80] = "\u0014u\u001ds\twDjcw\u0017t\u001bw4 M$G\u001bZuJs\u0013q\u0018(Ki";
      c[81] = "\u0014\u0016m\u001fQn\u001a\u000f}T+:D\t`I|m\u001a^8%\u0015/\u001b_{\u001eR+\u0015U";
      c[82] = "pe\u0013;Rf :D}0e$\u007fM \\Wr=\u0011z\r\u0000r9S+I=)dD*0";
      c[83] = "l{\u000b-uE0q\u0006.\u0004\u0018Wz['o\u0018icWs:tl;E.}I7fR/\u0004";
      c[84] = "\tW\u000e}Xb\n[\u000bp57dB\u0011q^2Z[\u001d%\u000b^_\u0003\u000fxLc\u0004^\u0018y5";
      c[85] = "qgp1\u0005\u0002wcw>y\u0011,M\u007f#\u0003\u0000&z\u0012u\u0015Q!mx7HP;\u0001+ E\u0007'ki}D\u001dK";
      c[86] = "76j\u0002l\u0004g)\u0014\r~\u0016<?x?*Rfb\u0014\u0003}\u00146'zSbje4(\u0002\u007f\u0000'i)\u0018\u0013";
      c[87] = "U\r{bS2\u0007\u0018:a/:\u0007\u0001k=C\bZF1b/=V\u0012p+\u0017;\u0003\u001ebZL3VD0!L:P\u001a\u000b";
      c[88] = "\f 6z%c\t` hHwvg)\u007f#rH~%+v\u001eM&7v1#\u0016{ wH";
      c[89] = "\u000e(\u0002x:KI,\frE\u0015]/\\$)'\u000bm\u0000~{p\u000biB/<MP4U.EN\u000e(Er=\rU)\u0001C";
      c[90] = "&\u001dx\u0018p~8\u0003{\u0015M (\u0011dN!\u0012|U;\u0016M'+\f4[},)\u001c})";
      c[91] = "\u0003Bq{0\u0004\u0000Ntv]SnWnw6TPNb#c8P\u0012ukl@\u0013It/]";
      c[92] = "-v`\u0002@3})7D\"0yl>\u0019N\u0002/+cA\u001bU\u007f~ \u0014];/a^";
      c[93] = "\fF\u0017e\u0013D\nB\u0010joBJI\u0013\"o\u0012Z\u001c\u001ft\u0005P\u0007\u001d\u0005\u0018VG\nJ\u0019r\u0014\u001a\u000bPu!\u0003\u0017\\L\u001fc^\u0016F ";
      c[94] = "\u001a$M.\u0010r\u0019(H#}$w1R\"\u0016\"I(^vCNLpL+\u0004s\u0017-[*}";
      c[95] = "bqWqv\u0013>{Zr\u0007OYp\u0007{lNgi\u000b/9\"4e\u0018wj\u001e7i\u001dz\u0007";
      c[96] = "\u001eH~V?PL]?UCXLDn\t/j\u0018\u00071Ry=\u0011_u\u0002*\rJUq\u0015C\fHS4U!AOBnn";
      c[97] = "|\u001a\u0011\u0006rI,\u0005o\t`[w\u0013\u0003;4\u001f.Eo\u0007cY}\u000b\u0001W|'|\u001a\u0011\u0006rI,\u0005o";
      c[98] = "Cg(D v\u0013xVK2dHn:yf \u00120V\u00173$Be<Un%X\t=@!rWgm__";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(3076161758601674L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(3076161758601674L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(3076161758601674L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 241;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 80;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 213;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 197;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 85;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 84;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 241;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 80;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 213;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dB_C0167",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static float invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static float invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ClientPlayerEntity invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding11(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding13(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding16(long var0, long var2) {
         MethodHandle var8 = bindingCache16;
         MethodHandle var7 = bindingCache16;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache16 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientPlayerEntity invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding20(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding22(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding24(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding25(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding28(long var0, long var2) {
         MethodHandle var8 = bindingCache28;
         MethodHandle var7 = bindingCache28;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache28 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientPlayerEntity invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding31(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static FrameTimer invokeBinding32(long var0, long var2) {
         MethodHandle var8 = bindingCache32;
         MethodHandle var7 = bindingCache32;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache32 = a(MethodHandles.lookup(), "Õ", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/ds_C0200;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (FrameTimer)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static float invokeBinding33(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache33;
         MethodHandle var9 = bindingCache33;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache33 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding35(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding41(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache41;
         MethodHandle var9 = bindingCache41;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache41 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding45(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache45;
         MethodHandle var9 = bindingCache45;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache45 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding46(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache46;
         MethodHandle var8 = bindingCache46;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache46 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientWorld invokeBinding48(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding50(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache50;
         MethodHandle var8 = bindingCache50;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache50 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding51(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache51;
         MethodHandle var8 = bindingCache51;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache51 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding52(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache52;
         MethodHandle var8 = bindingCache52;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache52 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding53(Object var0, double var1, long var3, long var5) {
         MethodHandle var11 = bindingCache53;
         MethodHandle var10 = bindingCache53;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache53 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;DJJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var8.invokeExact((Object)var0, (double)var1, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static ClientPlayerEntity invokeBinding54(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache54;
         MethodHandle var8 = bindingCache54;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache54 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding55(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache55;
         MethodHandle var8 = bindingCache55;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache55 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding56(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache56;
         MethodHandle var9 = bindingCache56;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache56 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static VoxelShape invokeBinding57(long var0, long var2) {
         MethodHandle var8 = bindingCache57;
         MethodHandle var7 = bindingCache57;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache57 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)Lnet/minecraft/util/shape/VoxelShape;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (VoxelShape)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientWorld invokeBinding58(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache58;
         MethodHandle var8 = bindingCache58;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache58 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BlockState invokeBinding59(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache59;
         MethodHandle var9 = bindingCache59;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache59 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/block/BlockState;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BlockState)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BlockHitResult invokeBinding60(Object var0, Object var1, Object var2, Object var3, Object var4, Object var5, long var6, long var8) {
         MethodHandle var14 = bindingCache60;
         MethodHandle var13 = bindingCache60;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache60 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/BlockHitResult;",
                     MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (BlockHitResult)var11.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (Object)var4, (Object)var5, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static ClientWorld invokeBinding61(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache61;
         MethodHandle var8 = bindingCache61;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache61 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding62(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache62;
         MethodHandle var8 = bindingCache62;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache62 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding63(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache63;
         MethodHandle var8 = bindingCache63;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache63 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding64(Object var0, double var1, long var3, long var5) {
         MethodHandle var11 = bindingCache64;
         MethodHandle var10 = bindingCache64;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache64 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;DJJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var8.invokeExact((Object)var0, (double)var1, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Vec3d invokeBinding65(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache65;
         MethodHandle var8 = bindingCache65;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache65 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding66(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache66;
         MethodHandle var9 = bindingCache66;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache66 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static VoxelShape invokeBinding67(long var0, long var2) {
         MethodHandle var8 = bindingCache67;
         MethodHandle var7 = bindingCache67;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache67 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)Lnet/minecraft/util/shape/VoxelShape;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (VoxelShape)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientWorld invokeBinding68(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache68;
         MethodHandle var8 = bindingCache68;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache68 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BlockState invokeBinding69(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache69;
         MethodHandle var9 = bindingCache69;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache69 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/block/BlockState;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BlockState)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BlockHitResult invokeBinding70(Object var0, Object var1, Object var2, Object var3, Object var4, Object var5, long var6, long var8) {
         MethodHandle var14 = bindingCache70;
         MethodHandle var13 = bindingCache70;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache70 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/BlockHitResult;",
                     MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (BlockHitResult)var11.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (Object)var4, (Object)var5, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static ClientWorld invokeBinding71(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache71;
         MethodHandle var8 = bindingCache71;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache71 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding72(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache72;
         MethodHandle var8 = bindingCache72;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache72 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding73(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache73;
         MethodHandle var8 = bindingCache73;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache73 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding74(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache74;
         MethodHandle var8 = bindingCache74;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache74 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding75(Object var0, double var1, long var3, long var5) {
         MethodHandle var11 = bindingCache75;
         MethodHandle var10 = bindingCache75;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache75 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;DJJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var8.invokeExact((Object)var0, (double)var1, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static ClientPlayerEntity invokeBinding76(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache76;
         MethodHandle var8 = bindingCache76;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache76 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding78(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache78;
         MethodHandle var9 = bindingCache78;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache78 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static VoxelShape invokeBinding79(long var0, long var2) {
         MethodHandle var8 = bindingCache79;
         MethodHandle var7 = bindingCache79;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache79 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)Lnet/minecraft/util/shape/VoxelShape;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (VoxelShape)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientWorld invokeBinding80(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache80;
         MethodHandle var8 = bindingCache80;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache80 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BlockState invokeBinding81(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache81;
         MethodHandle var9 = bindingCache81;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache81 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/block/BlockState;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BlockState)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BlockHitResult invokeBinding82(Object var0, Object var1, Object var2, Object var3, Object var4, Object var5, long var6, long var8) {
         MethodHandle var14 = bindingCache82;
         MethodHandle var13 = bindingCache82;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache82 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/BlockHitResult;",
                     MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (BlockHitResult)var11.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (Object)var4, (Object)var5, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static ClientWorld invokeBinding83(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache83;
         MethodHandle var8 = bindingCache83;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache83 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding84(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache84;
         MethodHandle var8 = bindingCache84;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache84 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding85(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache85;
         MethodHandle var8 = bindingCache85;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache85 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding86(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache86;
         MethodHandle var8 = bindingCache86;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache86 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding87(Object var0, double var1, long var3, long var5) {
         MethodHandle var11 = bindingCache87;
         MethodHandle var10 = bindingCache87;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache87 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;DJJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var8.invokeExact((Object)var0, (double)var1, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static ClientPlayerEntity invokeBinding88(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache88;
         MethodHandle var8 = bindingCache88;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache88 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding89(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache89;
         MethodHandle var8 = bindingCache89;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache89 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding90(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache90;
         MethodHandle var9 = bindingCache90;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache90 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static VoxelShape invokeBinding91(long var0, long var2) {
         MethodHandle var8 = bindingCache91;
         MethodHandle var7 = bindingCache91;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache91 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(JJ)Lnet/minecraft/util/shape/VoxelShape;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (VoxelShape)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientWorld invokeBinding92(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache92;
         MethodHandle var8 = bindingCache92;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache92 = a(
                  MethodHandles.lookup(),
                  "ñ",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BlockState invokeBinding93(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache93;
         MethodHandle var9 = bindingCache93;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache93 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/block/BlockState;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BlockState)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BlockHitResult invokeBinding94(Object var0, Object var1, Object var2, Object var3, Object var4, Object var5, long var6, long var8) {
         MethodHandle var14 = bindingCache94;
         MethodHandle var13 = bindingCache94;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache94 = a(
                  MethodHandles.lookup(),
                  "U",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/BlockHitResult;",
                     MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (BlockHitResult)var11.invokeExact((Object)var0, (Object)var1, (Object)var2, (Object)var3, (Object)var4, (Object)var5, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static float invokeBinding95(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache95;
         MethodHandle var8 = bindingCache95;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache95 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding96(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache96;
         MethodHandle var9 = bindingCache96;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache96 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding97(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache97;
         MethodHandle var8 = bindingCache97;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache97 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding98(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache98;
         MethodHandle var9 = bindingCache98;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache98 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding99(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache99;
         MethodHandle var8 = bindingCache99;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache99 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding100(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache100;
         MethodHandle var9 = bindingCache100;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache100 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding101(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache101;
         MethodHandle var8 = bindingCache101;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache101 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding102(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache102;
         MethodHandle var9 = bindingCache102;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache102 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Vec3d invokeBinding103(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache103;
         MethodHandle var8 = bindingCache103;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache103 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding104(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache104;
         MethodHandle var8 = bindingCache104;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache104 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding105(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache105;
         MethodHandle var8 = bindingCache105;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache105 = a(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding106(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache106;
         MethodHandle var8 = bindingCache106;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache106 = a(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding107(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache107;
         MethodHandle var8 = bindingCache107;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache107 = a(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Rotation invokeBinding108(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache108;
         MethodHandle var8 = bindingCache108;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache108 = a(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/dx_C0210;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Rotation)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding109(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache109;
         MethodHandle var8 = bindingCache109;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache109 = a(
                  MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding110(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache110;
         MethodHandle var8 = bindingCache110;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache110 = a(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding111(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache111;
         MethodHandle var8 = bindingCache111;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache111 = a(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding112(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache112;
         MethodHandle var8 = bindingCache112;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache112 = a(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding113(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache113;
         MethodHandle var9 = bindingCache113;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache113 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding114(double var0, double var2, long var4, long var6) {
         MethodHandle var12 = bindingCache114;
         MethodHandle var11 = bindingCache114;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache114 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DDJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var9.invokeExact((double)var0, (double)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static double invokeBinding115(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache115;
         MethodHandle var9 = bindingCache115;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache115 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding116(double var0, double var2, long var4, long var6) {
         MethodHandle var12 = bindingCache116;
         MethodHandle var11 = bindingCache116;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache116 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DDJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var9.invokeExact((double)var0, (double)var2, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static double invokeBinding117(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache117;
         MethodHandle var9 = bindingCache117;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache117 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(DJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding118(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache118;
         MethodHandle var8 = bindingCache118;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache118 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding119(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache119;
         MethodHandle var8 = bindingCache119;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache119 = a(MethodHandles.lookup(), "U", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding120(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache120;
         MethodHandle var8 = bindingCache120;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache120 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding121(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache121;
         MethodHandle var8 = bindingCache121;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache121 = a(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
