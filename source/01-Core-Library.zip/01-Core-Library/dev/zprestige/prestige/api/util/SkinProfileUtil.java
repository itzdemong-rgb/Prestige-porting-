package dev.zprestige.prestige.api.util;

import com.mojang.authlib.GameProfile;

import java.util.UUID;

public final class SkinProfileUtil {

    public static UUID aReturningUUID(Object[] args) {
        return null;
    }

    public static GameProfile aReturningGameProfile(Object[] args) {
        UUID id = (UUID) args[0];
        return new GameProfile(id, "");
    }

    private SkinProfileUtil() {
    }
}
