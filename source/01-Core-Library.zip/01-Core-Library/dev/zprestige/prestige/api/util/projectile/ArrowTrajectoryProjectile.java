package dev.zprestige.prestige.api.util.projectile;
import dev.zprestige.prestige.api.util.RaycastUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class ArrowTrajectoryProjectile extends PersistentProjectileEntity {
   public boolean a = dev.prestige.recovery.SourceSupport.asBoolean(0);
   public boolean b = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private static final long c = 118281783769369L;
   private static final Object[] d = new Object[88];
   private static final String[] e = new String[88];

   public ArrowTrajectoryProjectile(EntityType var1, LivingEntity var2, World var3, ItemStack var4) {
      super(var1, var2, var3, var4, var4);
   }

   public void tick() {
      int var5;
      Vec3d var6;
      ArrowTrajectoryProjectile var183;
      long var10001 = 83213992211283L ^ 66052463927614L;
      int var10000 = Event.bReturningInt();
      ArrowTrajectoryProjectile var27 = this;
      var6 = var27.getVelocity();
      var5 = var10000;
      int var205 = var5;
      ArrowTrajectoryProjectile var204 = this;
      var183 = var204;
      ArrowTrajectoryProjectile var180 = var204;
      label147:
      if (var205 == 0) {
         ArrowTrajectoryProjectile var28 = var180;
         float var271;
         int var206 = (var271 = var28.lastPitch - 0.0F) == 0.0F ? 0 : (var271 < 0.0F ? -1 : 1);
         if (!((var206) != 0)) {
            int var208 = var5;
            ArrowTrajectoryProjectile var207 = this;
            var183 = var207;
            ArrowTrajectoryProjectile var181 = var207;
            if (var208 != 0) {
               break label147;
            }

            ArrowTrajectoryProjectile var209 = var181;
            ArrowTrajectoryProjectile var182 = var209;
            ArrowTrajectoryProjectile var31 = var182;
            float var272;
            int var210 = (var272 = var31.lastYaw - 0.0F) == 0.0F ? 0 : (var272 < 0.0F ? -1 : 1);
            if (!((var210) != 0)) {
               Vec3d var33 = var6;
               Vec3d var34 = var6;
               double var37 = var34.z;
               double var35 = var33.x;
               float var40 = (float)(MathHelper.atan2(var35, var37) * 180.0F / (float)Math.PI);
               ArrowTrajectoryProjectile var39 = this;
               var39.setYaw(var40);
               Vec3d var41 = var6;
               double var268 = var41.y;
               Vec3d var42 = var6;
               double var45 = var42.horizontalLength();
               double var43 = var268;
               float var48 = (float)(MathHelper.atan2(var43, var45) * 180.0F / (float)Math.PI);
               ArrowTrajectoryProjectile var47 = this;
               var47.setPitch(var48);
               ArrowTrajectoryProjectile var49 = this;
               float var51 = var49.getYaw();
               ArrowTrajectoryProjectile var50 = this;
               var50.lastYaw = var51;
               ArrowTrajectoryProjectile var52 = this;
               float var54 = var52.getPitch();
               ArrowTrajectoryProjectile var53 = this;
               var53.lastPitch = var54;
            }
         }

         var183 = this;
      }

      World var8;
      BlockState var9;
      int var188;
      ArrowTrajectoryProjectile var56 = var183;
      BlockPos var7 = var56.getBlockPos();
      ArrowTrajectoryProjectile var57 = this;
      var8 = var57.getEntityWorld();
      BlockPos var59 = var7;
      World var58 = var8;
      var9 = var58.getBlockState(var59);
      BlockState var60 = var9;
      byte var261 = ((byte)((var60.isAir()) ? 1 : 0));
      int var212 = var5;
      byte var211 = var261;
      var188 = var211;
      byte var184 = var211;
      label140:
      if (var212 == 0) {
         byte var213 = var184;
         if (var213 == 0) {
            BlockPos var64 = var7;
            World var63 = var8;
            BlockState var62 = var9;
            VoxelShape var10 = var62.getCollisionShape((BlockView)var63, var64);
            VoxelShape var65 = var10;
            var261 = ((byte)((var65.isEmpty()) ? 1 : 0));
            int var215 = var5;
            byte var214 = var261;
            var188 = var214;
            byte var185 = var214;
            if (var215 != 0) {
               break label140;
            }

            byte var216 = var185;
            if (var216 == 0) {
               VoxelShape var67 = var10;
               List var68 = var67.getBoundingBoxes();
               Iterator var11 = var68.iterator();

               int var224;
               do {
                  Iterator var69 = var11;
                  boolean var217 = var69.hasNext();
                  if (!var217) {
                     break;
                  }

                  label131: {
                     Iterator var70 = var11;
                     Box var12 = (Box)var70.next();
                     int var218 = var5;
                     if (var218 == 0) {
                        BlockPos var72 = var7;
                        Box var71 = var12;
                        Box var263 = var71.offset(var72);
                        Object[] var73 = new Object[]{this, 131657085751917L};
                        Vec3d var75 = RaycastUtil.aReturningVec3d(var73);
                        Box var74 = var263;
                        var261 = ((byte)((var74.contains(var75)) ? 1 : 0));
                        int var220 = var5;
                        byte var219 = var261;
                        var188 = var219;
                        byte var186 = var219;
                        if (var220 != 0) {
                           break label140;
                        }

                        byte var221 = var186;
                        byte var187 = var221;
                        byte var222 = var187;
                        if (var222 == 0) {
                           break label131;
                        }

                        ArrowTrajectoryProjectile var78 = this;
                        var78.setOnGround(true);
                     }

                     int var223 = var5;
                     if (var223 == 0) {
                        break;
                     }
                  }

                  var224 = var5;
               } while (var224 == 0);
            }
         }

         ArrowTrajectoryProjectile var82 = this;
         var188 = var82.shake;
      }

      label116: {
         label152: {
            ArrowTrajectoryProjectile var197;
            label153: {
               boolean var196;
               label154: {
                  label112: {
                     ArrowTrajectoryProjectile var194;
                     label155: {
                        int var226 = var5;
                        int var225 = var188;
                        int var191 = var225;
                        int var189 = var225;
                        if (var226 == 0) {
                           int var227 = var189;
                           if (var227 > 0) {
                              ArrowTrajectoryProjectile var84 = this;
                              int var86 = var84.shake - 1;
                              ArrowTrajectoryProjectile var85 = this;
                              var85.shake = var86;
                           }

                           int var229 = var5;
                           ArrowTrajectoryProjectile var228 = this;
                           var194 = var228;
                           ArrowTrajectoryProjectile var190 = var228;
                           if (var229 != 0) {
                              break label155;
                           }

                           ArrowTrajectoryProjectile var88 = var190;
                           byte var230 = ((byte)((var88.isTouchingWaterOrRain()) ? 1 : 0));
                           var191 = var230;
                        }

                        int var231 = var191;
                        if (var231 == 0) {
                           Block var91 = Blocks.POWDER_SNOW;
                           BlockState var90 = var9;
                           boolean var265 = var90.isOf(var91);
                           int var233 = var5;
                           boolean var232 = var265;
                           var196 = var232;
                           boolean var192 = var232;
                           if (var233 != 0) {
                              break label154;
                           }

                           boolean var234 = var192;
                           boolean var193 = var234;
                           boolean var235 = var193;
                           if (!var235) {
                              break label112;
                           }
                        }

                        var194 = this;
                     }

                     ArrowTrajectoryProjectile var94 = var194;
                     var94.extinguish();
                  }

                  int var237 = var5;
                  ArrowTrajectoryProjectile var236 = this;
                  var197 = var236;
                  ArrowTrajectoryProjectile var195 = var236;
                  if (var237 != 0) {
                     break label153;
                  }

                  ArrowTrajectoryProjectile var95 = var195;
                  boolean var238 = var95.isOnGround();
                  var196 = var238;
               }

               boolean var239 = var196;
               if (var239) {
                  this.b = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  int var240 = var5;
                  if (var240 == 0) {
                     break label152;
                  }
               }

               ArrowTrajectoryProjectile var98 = this;
               var98.inGroundTime = 0;
               ArrowTrajectoryProjectile var241 = this;
               var197 = var241;
            }

            Vec3d var256;
            Vec3d var258;
            label90: {
               Object[] var101 = new Object[]{var197, 131657085751917L};
               var256 = RaycastUtil.aReturningVec3d(var101);
               Vec3d var103 = var6;
               Vec3d var102 = var256;
               var258 = var102.add(var103);
               RaycastContext var105 = new RaycastContext(var256, var258, ShapeType.COLLIDER, FluidHandling.NONE, this);
               World var104 = var8;
               BlockHitResult var259 = var104.raycast(var105);
               int var243 = var5;
               BlockHitResult var242 = var259;
               BlockHitResult var199 = var242;
               BlockHitResult var198 = var242;
               if (var243 == 0) {
                  BlockHitResult var106 = var198;
                  Type var266 = ((HitResult)var106).getType();
                  Type var245 = Type.MISS;
                  Type var244 = var266;
                  if (var244 == var245) {
                     break label90;
                  }

                  BlockHitResult var246 = var259;
                  var199 = var246;
               }

               BlockHitResult var109 = var199;
               var258 = ((HitResult)var109).getPos();
            }

            Vec3d var112 = var258;
            Vec3d var111 = var256;
            ArrowTrajectoryProjectile var110 = this;
            EntityHitResult var13 = var110.getEntityCollision(var111, var112);
            int var247 = var5;
            if (var247 != 0) {
               break label116;
            }

            EntityHitResult var248 = var13;
            if (var248 != null) {
               EntityHitResult var115 = var13;
               ArrowTrajectoryProjectile var114 = this;
               var114.onCollision((HitResult)var115);
               ArrowTrajectoryProjectile var116 = this;
               var116.velocityDirty = dev.prestige.recovery.SourceSupport.asBoolean(1);
            }
         }

         ArrowTrajectoryProjectile var119 = this;
         var6 = var119.getVelocity();
      }

      ArrowTrajectoryProjectile var203;
      label157: {
         Vec3d var120 = var6;
         double var257 = var120.x;
         Vec3d var121 = var6;
         double var260 = var121.y;
         Vec3d var122 = var6;
         double var14 = var122.z;
         ArrowTrajectoryProjectile var123 = this;
         double var16 = var123.getX() + var257;
         ArrowTrajectoryProjectile var124 = this;
         double var18 = var124.getY() + var260;
         ArrowTrajectoryProjectile var125 = this;
         double var20 = var125.getZ() + var14;
         Vec3d var126 = var6;
         double var22 = var126.horizontalLength();
         double var129 = var14;
         double var127 = var257;
         float var132 = (float)(MathHelper.atan2(var127, var129) * 180.0F / (float)Math.PI);
         ArrowTrajectoryProjectile var131 = this;
         var131.setYaw(var132);
         double var135 = var22;
         double var133 = var260;
         float var138 = (float)(MathHelper.atan2(var133, var135) * 180.0F / (float)Math.PI);
         ArrowTrajectoryProjectile var137 = this;
         var137.setPitch(var138);
         ArrowTrajectoryProjectile var139 = this;
         float var269 = var139.lastPitch;
         ArrowTrajectoryProjectile var140 = this;
         float var142 = var140.getPitch();
         float var141 = var269;
         float var144 = updateRotation(var141, var142);
         ArrowTrajectoryProjectile var143 = this;
         var143.setPitch(var144);
         ArrowTrajectoryProjectile var145 = this;
         float var270 = var145.lastYaw;
         ArrowTrajectoryProjectile var146 = this;
         float var148 = var146.getYaw();
         float var147 = var270;
         float var150 = updateRotation(var147, var148);
         ArrowTrajectoryProjectile var149 = this;
         var149.setYaw(var150);
         float var24 = 0.99F;
         ArrowTrajectoryProjectile var151 = this;
         boolean var267 = var151.isTouchingWater();
         int var250 = var5;
         boolean var249 = var267;
         boolean var202 = var249;
         boolean var200 = var249;
         if (var250 == 0) {
            boolean var251 = var200;
            if (var251) {
               ArrowTrajectoryProjectile var153 = this;
               var24 = var153.getDragInWater();
            }

            double var155 = var24;
            Vec3d var154 = var6;
            Vec3d var158 = var154.multiply(var155);
            ArrowTrajectoryProjectile var157 = this;
            var157.setVelocity(var158);
            int var253 = var5;
            ArrowTrajectoryProjectile var252 = this;
            var203 = var252;
            ArrowTrajectoryProjectile var201 = var252;
            if (var253 != 0) {
               break label157;
            }

            ArrowTrajectoryProjectile var159 = var201;
            boolean var254 = var159.hasNoGravity();
            var202 = var254;
         }

         boolean var255 = var202;
         if (!var255) {
            ArrowTrajectoryProjectile var161 = this;
            Vec3d var26 = var161.getVelocity();
            Vec3d var162 = var26;
            Vec3d var163 = var26;
            double var10002 = var163.y - 0.05F;
            Vec3d var164 = var26;
            double var170 = var164.z;
            double var168 = var10002;
            double var166 = var162.x;
            ArrowTrajectoryProjectile var165 = this;
            var165.setVelocity(var166, var168, var170);
         }

         double var177 = var20;
         double var175 = var18;
         double var173 = var16;
         ArrowTrajectoryProjectile var172 = this;
         var172.setPosition(var173, var175, var177);
         var203 = this;
      }

      ArrowTrajectoryProjectile var179 = var203;
      var179.tickBlockCollision();
   }

   public void setVelocity(double var1, double var3, double var5, float var7, float var8) {
      Vec3d var12 = new Vec3d(var1, var3, var5);
      Vec3d var10000 = var12.normalize();
      double var14 = var7;
      Vec3d var13 = var10000;
      Vec3d var11 = var13.multiply(var14);
      Vec3d var17 = var11;
      ArrowTrajectoryProjectile var16 = this;
      var16.setVelocity(var17);
      Vec3d var18 = var11;
      Vec3d var19 = var11;
      double var22 = var19.z;
      double var20 = var18.x;
      float var25 = (float)(MathHelper.atan2(var20, var22) * 180.0F / (float)Math.PI);
      ArrowTrajectoryProjectile var24 = this;
      var24.setYaw(var25);
      Vec3d var26 = var11;
      double var10001 = var26.y;
      Vec3d var27 = var11;
      double var30 = var27.horizontalLength();
      double var28 = var10001;
      float var33 = (float)(MathHelper.atan2(var28, var30) * 180.0F / (float)Math.PI);
      ArrowTrajectoryProjectile var32 = this;
      var32.setPitch(var33);
      ArrowTrajectoryProjectile var34 = this;
      float var36 = var34.getYaw();
      ArrowTrajectoryProjectile var35 = this;
      var35.lastYaw = var36;
      ArrowTrajectoryProjectile var37 = this;
      float var39 = var37.getPitch();
      ArrowTrajectoryProjectile var38 = this;
      var38.lastPitch = var39;
   }

   protected void onEntityHit(EntityHitResult var1) {
      this.b = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   protected void onBlockHit(BlockHitResult var1) {
      this.b = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   protected ItemStack asItemStack() {
      return null;
   }

   protected ItemStack getDefaultItemStack() {
      return null;
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = e[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = d[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 58;
            yield var15;
         }
         case 1 -> {
            byte var16 = 18;
            yield var16;
         }
         case 2 -> {
            byte var17 = 53;
            yield var17;
         }
         case 3 -> {
            byte var18 = 9;
            yield var18;
         }
         case 4 -> {
            byte var19 = 44;
            yield var19;
         }
         case 5 -> {
            byte var20 = 12;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 34;
            yield var22;
         }
         case 8 -> {
            byte var23 = 56;
            yield var23;
         }
         case 9 -> {
            byte var24 = 35;
            yield var24;
         }
         case 10 -> {
            byte var25 = 40;
            yield var25;
         }
         case 11 -> {
            byte var26 = 21;
            yield var26;
         }
         case 12 -> {
            byte var27 = 6;
            yield var27;
         }
         case 13 -> {
            byte var28 = 15;
            yield var28;
         }
         case 14 -> {
            byte var29 = 63;
            yield var29;
         }
         case 15 -> {
            byte var30 = 13;
            yield var30;
         }
         case 16 -> {
            byte var31 = 51;
            yield var31;
         }
         case 17 -> {
            byte var32 = 0;
            yield var32;
         }
         case 18 -> {
            byte var33 = 4;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 62;
            yield var35;
         }
         case 21 -> {
            byte var36 = 7;
            yield var36;
         }
         case 22 -> {
            byte var37 = 27;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 5;
            yield var39;
         }
         case 25 -> {
            byte var40 = 55;
            yield var40;
         }
         case 26 -> {
            byte var41 = 28;
            yield var41;
         }
         case 27 -> {
            byte var42 = 38;
            yield var42;
         }
         case 28 -> {
            byte var43 = 37;
            yield var43;
         }
         case 29 -> {
            byte var44 = 25;
            yield var44;
         }
         case 30 -> {
            byte var45 = 24;
            yield var45;
         }
         case 31 -> {
            byte var46 = 16;
            yield var46;
         }
         case 32 -> {
            byte var47 = 39;
            yield var47;
         }
         case 33 -> {
            byte var48 = 22;
            yield var48;
         }
         case 34 -> {
            byte var49 = 8;
            yield var49;
         }
         case 35 -> {
            byte var50 = 54;
            yield var50;
         }
         case 36 -> {
            byte var51 = 61;
            yield var51;
         }
         case 37 -> {
            byte var52 = 59;
            yield var52;
         }
         case 38 -> {
            byte var53 = 42;
            yield var53;
         }
         case 39 -> {
            byte var54 = 1;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 47;
            yield var56;
         }
         case 42 -> {
            byte var57 = 29;
            yield var57;
         }
         case 43 -> {
            byte var58 = 26;
            yield var58;
         }
         case 44 -> {
            byte var59 = 60;
            yield var59;
         }
         case 45 -> {
            byte var60 = 17;
            yield var60;
         }
         case 46 -> {
            byte var61 = 20;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 30;
            yield var64;
         }
         case 50 -> {
            byte var65 = 14;
            yield var65;
         }
         case 51 -> {
            byte var66 = 46;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 11;
            yield var69;
         }
         case 55 -> {
            byte var70 = 41;
            yield var70;
         }
         case 56 -> {
            byte var71 = 36;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 48;
            yield var73;
         }
         case 59 -> {
            byte var74 = 50;
            yield var74;
         }
         case 60 -> {
            byte var75 = 43;
            yield var75;
         }
         case 61 -> {
            byte var76 = 52;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 19;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            e[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      d[0] = "~~\u0005vY\th~\u0000,J\u001e\u007f5\u0003*F\nnr\u0014=\r\u001eO";
      d[1] = "|(m;-}|(zg!rfczy!ga\u0012+!s";
      d[2] = void.class;
      e[2] = "java/lang/Void";
      d[3] = boolean.class;
      e[3] = "java/lang/Boolean";
      d[4] = float.class;
      e[4] = "java/lang/Float";
      d[5] = "gV\u001a>`>y^\u0000q\u0002\"~C";
      d[6] = "0qd\tB1.y~F%0?bs\u001c\u00036";
      d[7] = "v;Y\u0012TFv;NNXIlpNPX\\k\u0001\u001f\n\f";
      d[8] = "(`oTv@(`x\bzO2+x\u0016zZ5Z)I\"";
      d[9] = "G#)sg\u0017L,8<\u0006\u0019G'<f";
      d[10] = "\bt\u001fowh\bt\b3{g\u0012?\b-{r\u0015NYr)9";
      d[11] = ")9\u0017\u0002\u0001A)9\u0000^\rN3r\u0000@\r[4\u0003P\u0015Y\u0011c?\u000fM\u001f[\u0018nW\u001e";
      d[12] = double.class;
      e[12] = "java/lang/Double";
      d[13] = int.class;
      e[13] = "java/lang/Integer";
      d[14] = "\u007f0b4&%\u007f0uh**e{uv*?b\n$,s|";
      d[15] = "\u0017}bUd\u0015\u0017}u\th\u001a\r6u\u0017h\u000f\nG'B;N";
      d[16] = "]\u001f\u0016\u007f1)]\u001f\u0001#=&GT\u0001==3@%Pbd";
      d[17] = "Ys.T\"\u0016Ys9\b.\u0019C89\u0016.\fDIhIv[Tz;\t< \u0005\"j";
      d[18] = "I|6iU\u0005Bs'&6\bW~(M\u0003\nFm4a\u0014\u0007";
      d[19] = "+\u001f\u0017D<h+\u001f\u0000\u00180g1T\u0000\u00060r6%QXe7";
      d[20] = "__9=!#__.a-,E\u0014.\u007f-9Be\u007f!xr";
      d[21] = "VBe\u001dhZ@B`G{MW\tcAwYFNtV<Kw";
      d[22] = "_mXd\u0018z_mO8\u0014uE&O&\u0014`BW\u001dsF$";
      d[23] = "j,\u0018dE>j,\u000f8I1pg\u000f&I$w\u0016_s\u001ea";
      d[24] = "9_XV\\j9_O\nPe#\u0014O\u0014Pp$e\u001fA\u0004:sY@\u0019Bp\b\t\u0015N\u0001";
      d[25] = "9Z\b]P0/Z\r\u0007C'8\u0011\u000e\u0001O3)V\u0019\u0016\u0004#n";
      d[26] = "Al\u0001|4c4L\ns%,UB\u0001x!v!";
      d[27] = "2\u0016\u001c\b\u0015Y2\u0016\u000bT\u0019V(]\u000bJ\u0019C/,[\u001fM\t";
      d[28] = "~%TSQ\t~%C\u000f]\u0006dnC\u0011]\u0013c\u001f\u0013D\nU";
      d[29] = "\u0006;A~NA\u0006;V\"BN\u001cpV<B[\u001b\u0001\u0006e\u0010\u001a";
      d[30] = "I\u001eSqui^R\u001eA/<\\N\b-\u001dh\u0010\u0011^pJh\u0018N\f$4,KG\u0003Api\\\u0012\u0000:!0P^o";
      d[31] = "!\u000b5k\u001a\f6Gx[KU%_e\f\u001b\bs\u00067[\u001fR,\u000195L\u000bv\u000b";
      d[32] = "v\u0018}1\u001fZaT0\u0001E\u000fcH&mwY!\u0014|= YvV|<\u001d\u001bfC!\u0001";
      d[33] = "|N9&5e(K?~S>;]'r/8=0a|5`!S0f, G";
      d[34] = "\u0007`E\u0000E%W;\u0006\u0004&+W#Y\\J\u0019\u0003g\b\u0003&uD;\u0004]\u001c!A=\\;";
      d[35] = "z\u0001'\u0016'Q>]iB\u0017E*\u001ayL{w~Y&\u001b+ ~^yHr^:\rpG\u0017";
      d[36] = "Mc0\u007fa@\u001cy)?\u0007E\u001ct*@9D\u0003m&/uJAbV";
      d[37] = "C\u0006\u0015\u001a\nmTJX*P8VVNFbo\u0016\u000b\u0010\u00175j\u001bRRSX1\u0015\u000bT*";
      d[38] = "\u0002~rfxa\u00152?V\"4\u0017.):\u0010cU\u007fpnGb\u00020skz \u0012%.V|0\u0015ssk> \u0000.Nm.'Vss/>2\u000bN";
      d[39] = "'\fz\u0013.g0@7#t22\\!OFer\f|\u0013\u0011e(X|\u0013\u007f6q\u0002v#";
      d[40] = "\u001c\u0015S-\u00141XX_w-.B\tQ&zy\u0018X\u0005J\u00121E\u0003\f;V|IY";
      d[41] = "!HRCr*6\u0004\u001fs(\u007f4\u0018\t\u001f\u001a)vDSNM)!\u0006SNpk1\u0013\u000es";
      d[42] = "\b>\u0015s#\r\u001frXCyX\u001dnN/K\b_2\u0017C&\r\u001d2F8wT\u0011~)";
      d[43] = "\nP\u0013RG^N\u0003\u001a]\"NR\u0005\u0017]u\u0019\bUI1\u0012KU\u0018\t\f_[V\u0010";
      d[44] = "Rkp\tO\r\u00168y\u0006*\u001d\n>t\u0006}JPn)j\u001a\u0018\r#jWW\b\u000e+";
      d[45] = "J[*S}i]\u0017gc'<_\u000bq\u000f\u0015k\u001f[-[BkE\u000f,S,8\u001cU&cxi_Wy\u0018)0S\u001b\u0016";
      d[46] = "|\u0002@\u007fo\u001dkN\rO5HiR\u001b#\u0007\u0018*\bEOjCq\bL!9\u001a+\u0002|";
      d[47] = "\u000f;aNi\u001b\u0018w,~8B\u000bo1)i\u001eY5]O;D^63\u0002-\u0018\u0017";
      d[48] = "w tI9\u001d|/?W\tD+,dJev|n>\u00171!,hd\\gE?3zM\t\u001ew4\u007fTdEymy-4\u001e:kgFdEyo\u0004";
      d[49] = "mBC=\r:{\u0010N5c-j\u0003C+\u000f\u001f>G\u001brcq?\u001f@)\u001d5l\u0016OLY.cE\u0013\"\nw9O#";
      d[50] = "GY\u000b\u0002SrP\u0015F2\t'R\tP^;w\u0011X\u00062V,JS\u0007\\\u0005u\u0010Y7";
      d[51] = "\bC(9;OL\u001ffm\u000b[XXvcgi\f\u001b)40>_Y'xnSVB-v\u000b";
      d[52] = "O\u0001!j\u0000:D\u000ejt0c\u0013\r1i\\QDOk7\r\u0006D\u001754\u0000h\u0017No>0";
      d[53] = "\u001fk|TS?\b'1d\u0005\u0007\u001d'?\u001f\u000fv\u001989_ll\n$;\u0007\u001dh\u0015\"{d";
      d[54] = "=6\u001di\u0003B15OrmA0&\u0015u:\u0015n{N(mB0q\u0017k\u0011_50@";
      d[55] = "%\b(I\u0013\u000f2DeyIZ0Xs\u0015{\fr\u0004)F,\f%F)D\u0011N5Sty\u0016\u000f0\u0004{\u0002GV<H\u0014";
      d[56] = "ke\u0018\u0006M\u0005|)U6\u001c\\o1HaO\f2o$\r\u001bC?h\u0019O\u000bVb";
      d[57] = "\n(\u0001\u0015QnUw\\^ dd\"\bC\u00183\no\u001e\u001fQ\u000e";
      d[58] = "IK\u0001\u001c2.^\u0007L,h{\\\u001bZ@Z(\u0019G\u0005\u001d\r,\u0018\u0007\u0001Cv}A\u000bM,";
      d[59] = "c+T9!\u0017j0^7D\u0014h;\u0001)\u0013C2m^E.\u00078*\u0000('\u001c2$";
      d[60] = "0\u001b\u0004)\u0019n'WI\u0019C;%K_uqie\u001b\b\u0019\u001b1g\u0016\bh_m)B8#\u001e*eDCrG&)+";
      d[61] = "l\u000b\u0017El\\(X\u001eJ\tG8O\u0017Aeul\u000bM\u0017\t\u001bmS\u0014Cw_>Z\u001b&";
      d[62] = "J6`L0G\u000eeiCU\\\u001er`H9nH1:\u0011j9Cef_/\u0004\u000eueWU";
      d[63] = "*u#:\u0001q=9n\nP(.!s]\u0000q{y\u001f1W7~x\"sG\"#";
      d[64] = "A2.x(mV~cHr8Tbu$@o\u00139+w\u0017eCdb2*(SgjH";
      d[65] = "sf;'S\u0002d*v\u0017\tWf6`{;\u0001$j:)l\u0001s(:*QCc=g\u0017V\u0002fjhl\u0007[j&\u0007";
      d[66] = "\\\u0014\u0000o\u0012+\u0018G\t`w;\u0004A\u0004` l^\u0011X\fG>\u0003\\\u001a1\n.\u0000T";
      d[67] = "\u000b\\\b~H\u0019Z\t\u001a:3D\bD\u0015`_vU\u0003O?3\u001eT\\\u000e~^EZ\u0005\b\u0007\u0002Q\u0015\\E;\t^^Bu";
      d[68] = "W{*P:]@7g``\bB+q\fR_\u0005p/P\u0005UU-f\u001a8\u0018E.n`";
      d[69] = "\u001ct\u0001\u0000\u0011o\u000b8L0K:\t$Z\\yhI\u007f\u00010\u0017o\u0015'XNS<\u001c(=\t\u00167\u0016!CME>\u0019DR[\u0010jKz\u0000SG:u";
      d[70] = "\u001d\u000b=,lY\nGp\u001c6\f\b[fp\u0004\\D\u0002=\u001cc\n\u0012K{!.\u001a\u0011C\u0001,8\u0007\u0004A<a(\u0004\f;1w5\u0011\u000e\u0006|g6\u0019t\u00019`o\u000e\u000fP`l#a";
      d[71] = "qN~\u007fM\u000ef\u00023O\u0017[d\u001e%#%\u000f(As\u007fr\u000f \u001e!*\fKs\u0017.O";
      d[72] = "W2h\t\u0016g\u0006(qIpd\u0002.H[\u0000xkohRJ4\u0005<1\b@\u0004";
      d[73] = "u9\u001f7[\u000bc8D\u007fe^{,\u001b\"2\t%|B~e_b!\u0006p^IczN";
      d[74] = "F\u0005\nn|\bQIG^&]SUQ2\u0014\u000f\u0014\f\u0006eC^KHO%{\u000f\u001eZ\u000b^";
      d[75] = "k\"m9\u0010\u0002;y.=s\f;aqe\u001f>o$(:sS0y+2\u001d\u0000i#!\u0002";
      d[76] = "4Z0\u0003]m$\u0000;Z::U\u0003kQT\"d\u0010(VFSlZ:^_-(\t3Q:";
      d[77] = "k\u0003vw\u000b\u001d:Vd3p@h\u001bki\u001cr<X42J%d\u0017i0\u000f\u001d<\u001fw3pGw]mn\u000eGk^q\u000e";
      d[78] = "G\u00103\u0012aYN\u001b*\u0006\u001f]I\n5\u0011so\u001dKnJ.8\u0014\u001d3\u0006e\u0005Y\r0\u000e\u001f\bO\u0010%\f\"E_\u0013-v/SB\u0006/KbCA\u000eU";
      d[79] = "W\u001cC\u001cY{@P\u000e,\b\"SH\u0013{Y~\u0001\u0010\u007f\u001d\u000b$\u0006\u0011\u0011P\u001dxO";
      d[80] = "p\u0000\u0011\u0016;YgL\\&a\fePJJS^%\u000b\u0013&?\bg\r\u0010\u001b}\u0018rP-";
      d[81] = "~[Z%W+:\bS*20*\u001fZ!^\u0002~[\u0003w2l\u007f\u0003Y#L(,\nVF\u000bm'\u0000_8O>.\u000f:";
      d[82] = "C:\u0000(kPTvM\u00181\u0005Vj[t\u0003Q\u001a:\u0004 TXAlLbi\u0015QoD\u0018d\u0003LzF%)\u0013Or<(?\u000eZp\u0001e/\rR\n\u0006 (TEqWy$\u0018*";
      d[83] = "\u0015jWDDX\u0002&\u001at\u001e\r\u0000:\f\u0018,ZGaQM{P\u0017<\u001b\u000eF\u001d\u0007?\u0013t";
      d[84] = ")'\rW\u0000mmt\u0004Xev}c\rS\tD)'W\re#{y\u001dNXnkz\u00154\\+p|\bJ\u0018xysm";
      d[85] = "<*8B*O+furp\u001a)zc\u001eBJj&<r/\u00111 4\u001c|Hk*\u0004";
      d[86] = "\rm|{\u0019\u001d\u0006b7e)DQalxEv\u0006\"<\"\u0013!Q|6y[]Lyw.)\u001bZy6/GH\u0003#<\u001f";
      d[87] = "G\u0005&\u000fw\u000fQW+\u0007\u0019\u0018@D&\u0019u*\u001c\tx~&LIC?\u0013}B\u0010EF\u0014$\u001d\\V4\u0002v\u0010T8";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = d[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(e[var4]);
            d[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = d[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            d[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  d[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(679832915260055L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = d[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  d[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(679832915260055L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        d[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(679832915260055L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 165;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 118;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 237;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 239;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 99;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 83;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 165;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 118;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 237;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gU_C0365",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
