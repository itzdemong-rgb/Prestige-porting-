package dev.zprestige.prestige.api.util.projectile;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class PearlFollowProjectile extends PersistentProjectileEntity {
   public boolean a;
   private static final long b = 126980712881448L;
   private static final Object[] c = new Object[54];
   private static final String[] d = new String[54];
   private static volatile MethodHandle bindingCache1;

   public PearlFollowProjectile(World var1, LivingEntity var2, ItemStack var3, long var4) {
      super(EntityType.ARROW, var2, var1, var3, var3);
      long var10000 = 126980712881448L ^ var4;

   }

   public void tick() {
      int var10000 = Event.cReturningInt();
      Predicate var15 = invokeBinding1(this);
      PearlFollowProjectile var14 = this;
      HitResult var4 = ProjectileUtil.getCollision((Entity)var14, var15);
      int var3 = var10000;
      int var64 = var3;
      if (var64 != 0) {
         HitResult var16 = var4;
         Type var75 = var16.getType();
         Type var66 = Type.MISS;
         Type var65 = var75;
         if (var65 != var66) {
            HitResult var19 = var4;
            PearlFollowProjectile var18 = this;
            var18.onCollision(var19);
            return;
         }

         PearlFollowProjectile var21 = this;
         var21.tickBlockCollision();
      }

      int var68 = var3;
      PearlFollowProjectile var67 = this;
      PearlFollowProjectile var60 = var67;
      PearlFollowProjectile var59 = var67;
      if (var68 != 0) {
         boolean var69 = var59.a;
         if (var69) {
            return;
         }

         var60 = this;
      }

      PearlFollowProjectile var24 = var60;
      Vec3d var5 = var24.getVelocity();
      PearlFollowProjectile var25 = this;
      double var76 = var25.getX();
      Vec3d var26 = var5;
      double var6 = var76 + var26.x;
      PearlFollowProjectile var27 = this;
      double var77 = var27.getY();
      Vec3d var28 = var5;
      double var8 = var77 + var28.y;
      PearlFollowProjectile var29 = this;
      double var78 = var29.getZ();
      Vec3d var30 = var5;
      double var10 = var78 + var30.z;
      PearlFollowProjectile var31 = this;
      var31.updateRotation();
      PearlFollowProjectile var32 = this;
      boolean var70 = var32.isTouchingWater();
      float var61;
      if (var70) {
         float var71 = 0.8F;
         var61 = var71;
      } else {
         var61 = 0.99F;
      }

      float var12 = var61;
      double var35 = var12;
      Vec3d var34 = var5;
      Vec3d var38 = var34.multiply(var35);
      PearlFollowProjectile var37 = this;
      var37.setVelocity(var38);
      int var73 = var3;
      PearlFollowProjectile var72 = this;
      PearlFollowProjectile var63 = var72;
      PearlFollowProjectile var62 = var72;
      if (var73 != 0) {
         PearlFollowProjectile var39 = var62;
         boolean var74 = var39.hasNoGravity();
         if (!var74) {
            PearlFollowProjectile var41 = this;
            Vec3d var13 = var41.getVelocity();
            Vec3d var42 = var13;
            Vec3d var43 = var13;
            double var10002 = var43.y - 0.03;
            Vec3d var44 = var13;
            double var50 = var44.z;
            double var48 = var10002;
            double var46 = var42.x;
            PearlFollowProjectile var45 = this;
            var45.setVelocity(var46, var48, var50);
         }

         var63 = this;
      }

      double var57 = var10;
      double var55 = var8;
      double var53 = var6;
      PearlFollowProjectile var52 = var63;
      var52.setPosition(var53, var55, var57);
   }

   protected void onBlockHit(BlockHitResult var1) {
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
      BlockHitResult var4 = var1;
      Vec3d var6 = var4.getPos();
      PearlFollowProjectile var5 = this;
      var5.setPosition(var6);
   }

   protected void onEntityHit(EntityHitResult var1) {
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
      EntityHitResult var4 = var1;
      Vec3d var6 = var4.getPos();
      PearlFollowProjectile var5 = this;
      var5.setPosition(var6);
   }

   protected ItemStack asItemStack() {
      return null;
   }

   protected ItemStack getDefaultItemStack() {
      return null;
   }

   public void setVelocity(double var1, double var3, double var5, float var7, float var8) {
      Vec3d var12 = new Vec3d(var1, var3, var5);
      Vec3d var10000 = var12.normalize();
      double var14 = var7;
      Vec3d var13 = var10000;
      Vec3d var11 = var13.multiply(var14);
      Vec3d var17 = var11;
      PearlFollowProjectile var16 = this;
      var16.setVelocity(var17);
      Vec3d var18 = var11;
      Vec3d var19 = var11;
      double var22 = var19.z;
      double var20 = var18.x;
      float var25 = (float)(MathHelper.atan2(var20, var22) * 180.0F / (float)Math.PI);
      PearlFollowProjectile var24 = this;
      var24.setYaw(var25);
      Vec3d var26 = var11;
      double var10001 = var26.y;
      Vec3d var27 = var11;
      double var30 = var27.horizontalLength();
      double var28 = var10001;
      float var33 = (float)(MathHelper.atan2(var28, var30) * 180.0F / (float)Math.PI);
      PearlFollowProjectile var32 = this;
      var32.setPitch(var33);
      PearlFollowProjectile var34 = this;
      float var36 = var34.getYaw();
      PearlFollowProjectile var35 = this;
      var35.lastYaw = var36;
      PearlFollowProjectile var37 = this;
      float var39 = var37.getPitch();
      PearlFollowProjectile var38 = this;
      var38.lastPitch = var39;
   }

   private static boolean lambda$tick$0(PearlFollowProjectile var0, Entity var1) {
      Entity var5 = var1;
      PearlFollowProjectile var4 = var0;
      return var4.canHit(var5);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 8;
            yield var15;
         }
         case 1 -> {
            byte var16 = 6;
            yield var16;
         }
         case 2 -> {
            byte var17 = 30;
            yield var17;
         }
         case 3 -> {
            byte var18 = 33;
            yield var18;
         }
         case 4 -> {
            byte var19 = 62;
            yield var19;
         }
         case 5 -> {
            byte var20 = 51;
            yield var20;
         }
         case 6 -> {
            byte var21 = 24;
            yield var21;
         }
         case 7 -> {
            byte var22 = 22;
            yield var22;
         }
         case 8 -> {
            byte var23 = 28;
            yield var23;
         }
         case 9 -> {
            byte var24 = 47;
            yield var24;
         }
         case 10 -> {
            byte var25 = 52;
            yield var25;
         }
         case 11 -> {
            byte var26 = 36;
            yield var26;
         }
         case 12 -> {
            byte var27 = 5;
            yield var27;
         }
         case 13 -> {
            byte var28 = 13;
            yield var28;
         }
         case 14 -> {
            byte var29 = 34;
            yield var29;
         }
         case 15 -> {
            byte var30 = 12;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 42;
            yield var32;
         }
         case 18 -> {
            byte var33 = 56;
            yield var33;
         }
         case 19 -> {
            byte var34 = 57;
            yield var34;
         }
         case 20 -> {
            byte var35 = 26;
            yield var35;
         }
         case 21 -> {
            byte var36 = 11;
            yield var36;
         }
         case 22 -> {
            byte var37 = 29;
            yield var37;
         }
         case 23 -> {
            byte var38 = 14;
            yield var38;
         }
         case 24 -> {
            byte var39 = 7;
            yield var39;
         }
         case 25 -> {
            byte var40 = 59;
            yield var40;
         }
         case 26 -> {
            byte var41 = 54;
            yield var41;
         }
         case 27 -> {
            byte var42 = 63;
            yield var42;
         }
         case 28 -> {
            byte var43 = 46;
            yield var43;
         }
         case 29 -> {
            byte var44 = 27;
            yield var44;
         }
         case 30 -> {
            byte var45 = 1;
            yield var45;
         }
         case 31 -> {
            byte var46 = 48;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 32;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 19;
            yield var51;
         }
         case 37 -> {
            byte var52 = 17;
            yield var52;
         }
         case 38 -> {
            byte var53 = 0;
            yield var53;
         }
         case 39 -> {
            byte var54 = 16;
            yield var54;
         }
         case 40 -> {
            byte var55 = 35;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 38;
            yield var57;
         }
         case 43 -> {
            byte var58 = 55;
            yield var58;
         }
         case 44 -> {
            byte var59 = 31;
            yield var59;
         }
         case 45 -> {
            byte var60 = 18;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 10;
            yield var62;
         }
         case 48 -> {
            byte var63 = 9;
            yield var63;
         }
         case 49 -> {
            byte var64 = 2;
            yield var64;
         }
         case 50 -> {
            byte var65 = 58;
            yield var65;
         }
         case 51 -> {
            byte var66 = 53;
            yield var66;
         }
         case 52 -> {
            byte var67 = 20;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 4;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 3;
            yield var71;
         }
         case 57 -> {
            byte var72 = 15;
            yield var72;
         }
         case 58 -> {
            byte var73 = 50;
            yield var73;
         }
         case 59 -> {
            byte var74 = 37;
            yield var74;
         }
         case 60 -> {
            byte var75 = 40;
            yield var75;
         }
         case 61 -> {
            byte var76 = 39;
            yield var76;
         }
         case 62 -> {
            byte var77 = 60;
            yield var77;
         }
         default -> 61;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "\u000497\u001c1U\u00049 @=Z\u001er ^=O\u0019\u0003r\u0000e\u0005";
      c[1] = "^k/\tREHk*SAR_ )UMFNg>B\u0006Ri";
      c[2] = float.class;
      d[2] = "java/lang/Float";
      c[3] = void.class;
      d[3] = "java/lang/Void";
      c[4] = "El<9\u0005NEl+e\tA_'+{\tTXVz#[";
      c[5] = double.class;
      d[5] = "java/lang/Double";
      c[6] = "\u000bW]dYM\u000bWJ8UB\u0011\u001cJ&UW\u0016m\u001a\u007f\u0007\u0016";
      c[7] = "\u0017#7M\u0001\t\u0017# \u0011\r\u0006\rh \u000f\r\u0013\n\u0019qPUD\u001a*\"\u0010\u001f?Krs";
      c[8] = "\b'0\u0006\u0012p\b''Z\u001e\u007f\u0012l'D\u001ej\u0015\u001dv\u001bF";
      c[9] = "E$\u0015rb+E$\u0002.n$_o\u00020n1X\u001ePj8w";
      c[10] = "\u0013\u0000mJ[6\u0013\u0000z\u0016W9\tKz\bW,\u000e:(V\u000fh";
      c[11] = "/ObB(M1Gx\r`M+M`JiVk~fFbQ&O`F";
      c[12] = "/\u001f3\u0018K?9\u001f6BX(.T5DT<?\u0013\"S\u001f.\u000e";
      c[13] = int.class;
      d[13] = "java/lang/Integer";
      c[14] = boolean.class;
      d[14] = "java/lang/Boolean";
      c[15] = "?4#4t-4;2{\u0017 !6=\u0010\"\"0%!<5/";
      c[16] = "?\u001adUZt?\u001as\tV{%Qs\u0017Vn\" #B\u0001(";
      c[17] = "S*E+^dS*RwRkIaRiR~N\u0010\u0002<\u0005;";
      c[18] = "\u0003]}\u001b4$\bRlTU*\u0003Yh\u000e";
      c[19] = "j|\u000e\u0015;y9,YNJ/6p\f\u0013\u001dxl&S\u007fw 1w\u0019G$pf,";
      c[20] = "iY3Te]0M?Y\nF=LcAftk\u000b>\u00196#jBj@rCm\u000e>F\n\u0019>^`\u001ek\u0012>\u000fl&";
      c[21] = "w$6bS?phbd+: *?cG\btne5+e??9|Kbsk?\u0004";
      c[22] = "z6\rw\u00005t8\u0000fel)%\u001cy\t^xhM/Z\t{7Co\u0003r9;\u001f{e9z7La\u001d{!$L\u001eXl=b\u001f`\u000e14;|";
      c[23] = "`t+\u001c\u001fZg8\u007f\u001ag_7z\"\u001d\u000bma9xDX:a~\"\b\u0019B?l.\u001bg";
      c[24] = "0$e$yj>l/9C?\u0000g|!zj`i. 2T";
      c[25] = "Lw]ji\"\u00131\u0014Rl<Fo@\u0005<d\u00111,5~,\u0013`Sj8e";
      c[26] = "\u000fJEJ~iV^IG\u0011r[_\u0015_}@\u000b\u001cD\t\u0011~\u000f\u001aH\\xiP\u001d\u00188";
      c[27] = "\u00158:\u001fJk\u0012tn\u00192eN'7\u0015e2\u0014wky\tsO8-\u0001WaC+";
      c[28] = "\u0014K\u0007t#s\u001c\t\u0010(Z,\u0012\n\fw6\u001eFIS fIE\u0004\u0005v\")BHQpZ";
      c[29] = "d\u001cj\u0005EF=\bf\b*]0\t:\u0010FogKkI\u00108g\u001b4\u0014\u0012Yl\u001be\u0018*";
      c[30] = "\u001eE\u0001 2\u0003GQ\r-]\u0018JPQ51*\u001e\u001c\u0001je}\u001cTQ #\u0005BF]3]F_LC,%\u0018M@PRf\u0005G^O*8\u0017KM1h3\u0013D\u0014Pc3BH,";
      c[31] = "\u0002vG7A{[bK:.l;uO{UxKz\u0014<J\u0005Q'I>Su^|\u000e!.";
      c[32] = "\u0007lJ,-L^xF!BWSy\u001a9.e\u0004>Ad{2\u0005}\u001a,<J[o\u0016?B";
      c[33] = "\u0019<\u0018K)\u0016@(\u0014FF\rM)H^*?\u001dj\u0014\u0001F\u0001\u0019l\u0015]/\u0016FkE9";
      c[34] = "7:g\fL@n.k\u0001#[c/7\u0019Oi5mkC\u001c>7/j\u001dB]~=&\u0018#\u0004`=4FB\u000f`l8~";
      c[35] = "Z\u0003%1{\u0012\u0003\u0017)<\u0014\u0002\u0002\u0007q/CQRZ/C-\u0010^\tt d\u0002\u0012\f";
      c[36] = "\\x%\u0007);\u0005l)\nF \bmu\u0012*\u0012\\!*DwE_c|\u0013>%X/(\u0015F\u007f\u000b\u007fvM't\u000b.zu";
      c[37] = "\u0001h+oEH\u0006$\u007fi=FZw&ej\u0011\u0000'x\t\u0006P[h<qXBW{";
      c[38] = "?\u0011rR;38]&TC=d\u000e\u007fX\u0014j>^\"4x+e\u0011eL&9i\u0002";
      c[39] = "^AqW8\u0017\u001b\u0014|F\t\n\u000f\u0002x^e8[C#\u00058oY\u0006xKw\u0017\u0007\u0014tX\tT\u001a\u001ejGq\n\b\u0012y92\u0017\u0002\ffAl\u0005\u000e\u001f\u0018";
      c[40] = "%\u0001\u0003{a\"|\u0015\u000fv\u000e9q\u0014Snb\u000b\"Q\u000f1?\\&\u0006]j6=-\u0006\ff\u000e";
      c[41] = "\n\u0004\u0011BwIS\u0010\u001dO\u0018R^\u0011AWt`\bS\u001d\r$7\n\u0011\u001cSyTC\u0003PV\u0018";
      c[42] = "iUb.H80An#'#=@2;K\u0011o\u0000bl'{5Ei?Y-hL0\\\u001d(>_j=\u0016(oSR";
      c[43] = "}|Y\u0002(\u0003$hU\u000fG\u0013%x\r\u001c\u0010C|-Up~\u0001yv\b\u00137\u00135s";
      c[44] = "\u0012\n`\u001es,K\u001el\u0013\u001c7F\u001f0\u000bp\u0005\u0011XkU#R\u0010\u001b0\u001eb*N\t<\r\u001c";
      c[45] = "$lY\u0006>\"}xU\u000bQ9py\t\u0013=\u000b&;UIo\\$yT\u00170?mk\u0018\u0012Qfsk\nL0ms:\u0006t";
      c[46] = "iE@\u0010\u0006u|\u001aO\u00108on^A\u001aT]:\u001d\u001eM\u0004\n9PH\u001b@j>\u001c\u001c\u001d8";
      c[47] = "1\u001e\n\u001e&RgC\u0003GEIa\u0007\u0013B){5DL\u0015~,1\u001a\u0015O4\u0014bJB\u0014E";
      c[48] = "&Gu\u001d0%\u007fSy\u0010_>rR%\b3\f\"\u001e|S_`gN7\u0011'>uB$od#\u007f\\;\u0017:1sOET';mP=\n57~.\u007f\u000118'Ot\u0001`4\u001f";
      c[49] = "'c\u0015R\u0011 ~w\u0019_~;svEG\u0012\t$1\u001e\u0019N^%rER\u0000&{`IA~";
      c[50] = "uhW?bi,|[2\rr!}\u0007*a@v?Vp=\u0017soX<kl1c\u0004(\r~u8Z)di*?\nM";
      c[51] = "\r\u0002S+\u007f\u007fT\u0016_&\u0010dY\u0017\u0003>|V\r[\\h \u0001\u000e\u0019\n?ha\tU^9\u0010";
      c[52] = "\u001fh\\S&d\u0018$\bU^aHfUR2S\u001c\"\u000f\f^?]zGK&aOvT5dvL|MUc:\u0018z5";
      c[53] = "|\u001a\u001d{\u001d\u0015%\u000e\u0011vr\u000e(\u000fMn\u001e<~M\u00114Ok|\u000f\u0010j\u0013\b5\u001d\\or";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1306311426103777L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1306311426103777L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1306311426103777L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 119;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 71;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 165;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 210;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 228;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 70;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 119;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 71;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 165;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gS_C0361",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(PearlFollowProjectile var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gS_C0361;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/gS_C0361",
                     "lambda$tick$0",
                     "(Ldev/zprestige/prestige/gS_C0361;Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PearlFollowProjectile)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
