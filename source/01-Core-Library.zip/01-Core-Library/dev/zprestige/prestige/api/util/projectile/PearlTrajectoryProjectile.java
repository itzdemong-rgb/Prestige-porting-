package dev.zprestige.prestige.api.util.projectile;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class PearlTrajectoryProjectile extends PersistentProjectileEntity {
   public boolean a;
   private static final long b = 47750968570653L;
   private static final Object[] c = new Object[49];
   private static final String[] d = new String[49];
   private static volatile MethodHandle bindingCache1;

   public PearlTrajectoryProjectile(World var1, LivingEntity var2, ItemStack var3, long var4) {
      super(EntityType.ARROW, var2, var1, var3, var3);
      long var10000 = 47750968570653L ^ var4;

   }

   public void tick() {
      int var10000 = Event.bReturningInt();
      Predicate var15 = invokeBinding1(this);
      PearlTrajectoryProjectile var14 = this;
      HitResult var4 = ProjectileUtil.getCollision((Entity)var14, var15);
      int var3 = var10000;
      int var60 = var3;
      if (var60 == 0) {
         HitResult var16 = var4;
         Type var68 = var16.getType();
         Type var62 = Type.MISS;
         Type var61 = var68;
         if (var61 != var62) {
            HitResult var19 = var4;
            PearlTrajectoryProjectile var18 = this;
            var18.onCollision(var19);
         }

         PearlTrajectoryProjectile var21 = this;
         var21.tickBlockCollision();
      }

      PearlTrajectoryProjectile var22 = this;
      Vec3d var5 = var22.getVelocity();
      PearlTrajectoryProjectile var23 = this;
      double var69 = var23.getX();
      Vec3d var24 = var5;
      double var6 = var69 + var24.x;
      PearlTrajectoryProjectile var25 = this;
      double var70 = var25.getY();
      Vec3d var26 = var5;
      double var8 = var70 + var26.y;
      PearlTrajectoryProjectile var27 = this;
      double var71 = var27.getZ();
      Vec3d var28 = var5;
      double var10 = var71 + var28.z;
      PearlTrajectoryProjectile var29 = this;
      var29.updateRotation();
      PearlTrajectoryProjectile var30 = this;
      boolean var63 = var30.isTouchingWater();
      float var57;
      if (var63) {
         float var64 = 0.8F;
         var57 = var64;
      } else {
         var57 = 0.99F;
      }

      float var12 = var57;
      double var33 = var12;
      Vec3d var32 = var5;
      Vec3d var36 = var32.multiply(var33);
      PearlTrajectoryProjectile var35 = this;
      var35.setVelocity(var36);
      int var66 = var3;
      PearlTrajectoryProjectile var65 = this;
      PearlTrajectoryProjectile var59 = var65;
      PearlTrajectoryProjectile var58 = var65;
      if (var66 == 0) {
         PearlTrajectoryProjectile var37 = var58;
         boolean var67 = var37.hasNoGravity();
         if (!var67) {
            PearlTrajectoryProjectile var39 = this;
            Vec3d var13 = var39.getVelocity();
            Vec3d var40 = var13;
            Vec3d var41 = var13;
            double var10002 = var41.y - 0.03;
            Vec3d var42 = var13;
            double var48 = var42.z;
            double var46 = var10002;
            double var44 = var40.x;
            PearlTrajectoryProjectile var43 = this;
            var43.setVelocity(var44, var46, var48);
         }

         var59 = this;
      }

      double var55 = var10;
      double var53 = var8;
      double var51 = var6;
      PearlTrajectoryProjectile var50 = var59;
      var50.setPosition(var51, var53, var55);
   }

   protected void onBlockHit(BlockHitResult var1) {
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   protected void onEntityHit(EntityHitResult var1) {
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   protected ItemStack asItemStack() {
      return null;
   }

   protected ItemStack getDefaultItemStack() {
      return null;
   }

   public void setVelocity(double var1, double var3, double var5, float var7, float var8) {
      Vec3d var12 = new Vec3d(var1, var3, var5);
      Vec3d var10000 = var12.normalize();
      double var14 = var7;
      Vec3d var13 = var10000;
      Vec3d var11 = var13.multiply(var14);
      Vec3d var17 = var11;
      PearlTrajectoryProjectile var16 = this;
      var16.setVelocity(var17);
      Vec3d var18 = var11;
      Vec3d var19 = var11;
      double var22 = var19.z;
      double var20 = var18.x;
      float var25 = (float)(MathHelper.atan2(var20, var22) * 180.0F / (float)Math.PI);
      PearlTrajectoryProjectile var24 = this;
      var24.setYaw(var25);
      Vec3d var26 = var11;
      double var10001 = var26.y;
      Vec3d var27 = var11;
      double var30 = var27.horizontalLength();
      double var28 = var10001;
      float var33 = (float)(MathHelper.atan2(var28, var30) * 180.0F / (float)Math.PI);
      PearlTrajectoryProjectile var32 = this;
      var32.setPitch(var33);
      PearlTrajectoryProjectile var34 = this;
      float var36 = var34.getYaw();
      PearlTrajectoryProjectile var35 = this;
      var35.lastYaw = var36;
      PearlTrajectoryProjectile var37 = this;
      float var39 = var37.getPitch();
      PearlTrajectoryProjectile var38 = this;
      var38.lastPitch = var39;
   }

   private static boolean lambda$tick$0(PearlTrajectoryProjectile var0, Entity var1) {
      Entity var5 = var1;
      PearlTrajectoryProjectile var4 = var0;
      return var4.canHit(var5);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 28;
            yield var15;
         }
         case 1 -> {
            byte var16 = 6;
            yield var16;
         }
         case 2 -> {
            byte var17 = 29;
            yield var17;
         }
         case 3 -> {
            byte var18 = 1;
            yield var18;
         }
         case 4 -> {
            byte var19 = 24;
            yield var19;
         }
         case 5 -> {
            byte var20 = 8;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 48;
            yield var22;
         }
         case 8 -> {
            byte var23 = 3;
            yield var23;
         }
         case 9 -> {
            byte var24 = 34;
            yield var24;
         }
         case 10 -> {
            byte var25 = 45;
            yield var25;
         }
         case 11 -> {
            byte var26 = 9;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 17;
            yield var28;
         }
         case 14 -> {
            byte var29 = 4;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 25;
            yield var31;
         }
         case 17 -> {
            byte var32 = 18;
            yield var32;
         }
         case 18 -> {
            byte var33 = 58;
            yield var33;
         }
         case 19 -> {
            byte var34 = 30;
            yield var34;
         }
         case 20 -> {
            byte var35 = 39;
            yield var35;
         }
         case 21 -> {
            byte var36 = 19;
            yield var36;
         }
         case 22 -> {
            byte var37 = 61;
            yield var37;
         }
         case 23 -> {
            byte var38 = 56;
            yield var38;
         }
         case 24 -> {
            byte var39 = 62;
            yield var39;
         }
         case 25 -> {
            byte var40 = 53;
            yield var40;
         }
         case 26 -> {
            byte var41 = 51;
            yield var41;
         }
         case 27 -> {
            byte var42 = 26;
            yield var42;
         }
         case 28 -> {
            byte var43 = 54;
            yield var43;
         }
         case 29 -> {
            byte var44 = 16;
            yield var44;
         }
         case 30 -> {
            byte var45 = 0;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 27;
            yield var47;
         }
         case 33 -> {
            byte var48 = 2;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 11;
            yield var50;
         }
         case 36 -> {
            byte var51 = 5;
            yield var51;
         }
         case 37 -> {
            byte var52 = 42;
            yield var52;
         }
         case 38 -> {
            byte var53 = 10;
            yield var53;
         }
         case 39 -> {
            byte var54 = 31;
            yield var54;
         }
         case 40 -> {
            byte var55 = 57;
            yield var55;
         }
         case 41 -> {
            byte var56 = 55;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 7;
            yield var58;
         }
         case 44 -> {
            byte var59 = 60;
            yield var59;
         }
         case 45 -> {
            byte var60 = 15;
            yield var60;
         }
         case 46 -> {
            byte var61 = 32;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 36;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 35;
            yield var66;
         }
         case 52 -> {
            byte var67 = 14;
            yield var67;
         }
         case 53 -> {
            byte var68 = 49;
            yield var68;
         }
         case 54 -> {
            byte var69 = 52;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 23;
            yield var72;
         }
         case 58 -> {
            byte var73 = 40;
            yield var73;
         }
         case 59 -> {
            byte var74 = 41;
            yield var74;
         }
         case 60 -> {
            byte var75 = 50;
            yield var75;
         }
         case 61 -> {
            byte var76 = 46;
            yield var76;
         }
         case 62 -> {
            byte var77 = 22;
            yield var77;
         }
         default -> 33;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "s\ts\"h9s\td~d6iBd`d#n36><i";
      c[1] = "JhV!!,\\hS{2;K#P}>/ZdGju;z";
      c[2] = boolean.class;
      d[2] = "java/lang/Boolean";
      c[3] = double.class;
      d[3] = "java/lang/Double";
      c[4] = "\u0007.^*\u001bf\u0007.Iv\u0017i\u001deIh\u0017|\u001a\u0014\u00180E";
      c[5] = "kOE:\u0015\n}O@`\u0006\u001dj\u0004Cf\n\t{CTqA\u001bJ";
      c[6] = int.class;
      d[6] = "java/lang/Integer";
      c[7] = "c]\u000b|lKc]\u001c `Dy\u0016\u001c>`Q~gMa8\u0006nT\u001e!r}?\fO";
      c[8] = void.class;
      d[8] = "java/lang/Void";
      c[9] = "\u0006N\u00046.q\u0006N\u0013j\"~\u001c\u0005\u0013t\"k\u001btA.t-";
      c[10] = "Ho\u0012h\u001c^Ho\u00054\u0010QR$\u0005*\u0010DUUWtH\u0000";
      c[11] = "m\u001ao\bB?s\u0012uG\n?i\u0018m\u0000\u0003$)+k\f\b#d\u001am\f";
      c[12] = "\u0019hHf'\r\u0019h_:+\u0002\u0003#_$+\u0017\u0004R\u000e{s";
      c[13] = "\u001b0s|u#\u0010?b3\u0016.\u00052mX#,\u0014!qt4!";
      c[14] = float.class;
      d[14] = "java/lang/Float";
      c[15] = "^\u0003y58.^\u0003ni4!DHnw44C9>.fu";
      c[16] = "\u000ff\u0014\u001aX\"\u0004i\u0005U9,\u000fb\u0001\u000f";
      c[17] = "tmLR@t1jNQ{~ /^\f\u0017Ltc\u0001ZK\u001bw#G\u0019\u0003y}mB\u0010{";
      c[18] = "z\u0002M\u001b}07B_F\f F\u0007MW`p?P]I3J";
      c[19] = "[\u0016j\u0016\u001d4\u001e\u0011h\u0015&>\u000fTxHJ\fY\u0016$\u0012\u001b[\u000b\u0014}D\u001a&^T~\u0016&";
      c[20] = "lr{S\u0010-nav\u0010`~1nyE7)k8&)\\a6ym\u0014^r;:";
      c[21] = "\u0019~x\u0004\u0006\u0014\u00130}\r~\u0013Nra\u0011\u0012!\u001a6;G~LSws\u000e\u001cF\u001drzv";
      c[22] = "o\u0000N\u001d\f\u000b!T^\u0003eW<\u0016L\u0019\tem[\u001dOZ2n\u0004\u0010\u0003\u0018\u0003aSP\u0007e\u0002i\u0011\u0014A\u0015Y;\u0004H~UJ8TTDX\u0003-Q,";
      c[23] = "m$ThP\u000e(#Vkk\u00049fF6\u00076o$\u001alUa=&C:W\u001chf@hk\\1!W#T\u0019o~DQ";
      c[24] = "N@|\u000e9*D\u000ey\u0007A-\u0019Le\u001b-\u001fO\u000f?B~HN]>\u001a-*\r\u0000y\u0007A";
      c[25] = "}C\rsZQ8D\u000fpa[)\u0001\u001f-\ri~CNwQ>{\u0013C7\u001c\u000ftD\u00033a\u0007:\u0018Gw\u0003W>\u001d\u000eJ";
      c[26] = ")^*1Q^!P+\u0001UX&_9V\u0005\u0000q\u0001Uc^F{Q2kPG";
      c[27] = "\u0003QgcV3FVe`m9W\u0013u=\u0001\u000b\u0000T.c]\\\u0000\u0002.<\u0001>C_i!m";
      c[28] = "3}`2\tMvzb12Gg?rl^u7s+72\u0018gxtgP[:?i\u000b\bO1%~iK\u0012v8\u00121_\u0019l/pr\u0002^qC/n\tSx|j0V@\n";
      c[29] = "X\u0019(yl?RW-p\u00143\u0003\u00045gCdYTi\u000b.0Y\u000f=imm\u001e\u0012";
      c[30] = "4\u000es\bxvq\tq\u000bC|`LaV/N2\f1\u0001C)uY?Iy$<L:1~|6As\u000e;\"iR\u0001";
      c[31] = "2\",.*|w%.-\u0011vf`>p}D1'e..\u00131qeq}qr,\"l\u0011";
      c[32] = "r\u001c\u001aY\u0010x7\u001b\u0018Z+y*O\f\f|)s\u001aT`B+.IT\u001d\u0017k-\u001b";
      c[33] = "8dq\u0005$z}cs\u0006\u001fpl&c[sB8j<\r.\u0015;*zNgw1d\u007fG\u001f(darN m:>a<";
      c[34] = "tJoBnn1MmAUo,\u0019y\u0017\u0002<|D'{<=(\u001f!\u0006i}+M";
      c[35] = "\u001dT3\\\u001a*XS1_! I\u0016!\u0002M\u0012\u001fT}X\u001eEMV$\u000e\u001d8\u0018\u0016'\\!xAQ0\u0017\u001e=\u001f\u000e#e";
      c[36] = "?\u0012q:\u0011oz\u0015s9*ekPcdFW=\u0012?>\u0016\u0000o\u0010fh\u0016}:Pe:*";
      c[37] = "\u0003_v}\u0003+FXt~8!W\u001dd#T\u0013\u0004X8|\tD\u0007\u0004?5J{BZ`&8";
      c[38] = "\u0010\u0010>B?]U\u0017<A\u0004WDR,\u001che\u0014\u0011pC\u0004\u000bWKtFf[SN={";
      c[39] = "/ 822Bj':1\tH{b*lez,%q10-,sqmeOo.6p\t";
      c[40] = "p\fM3~\u000ezBH:\u0006\u0002+\u0011P-QUqA\u000eA<\u0001q\u001aX#\u007f\\6\u0007";
      c[41] = "kld2\u0004\u0014a\"a;|\u00180qy,+Oj!$@F\u001bjzq\"\u0005F-g";
      c[42] = ":5JY;?3.^AP\">3S_<\u0010jr\b\u0004aGi\"\b^<%*\u007fOCP}>tUT2>c3H8j*h)_Z)w/43";
      c[43] = "MM\u0002E\u0017\u0018\bJ\u0000F,\u0012\u0019\u000f\u0010\u001b@ NMAB\u0016wI\u0016K\r^H\fH\u0014\u001e,";
      c[44] = "#o\u001fsi\u0006fh\u001dpR\u0000\u001a`V5(\u0007f=Upki+j\u00120<\u0015viWsR";
      c[45] = "3S\\T\bBvT^W3Hg\u0011N\n_z3]\u001eU\u000b-0\u0000\u0015\u000b_Os]R\u00163\u0017gVH\u0001QT:\u0011Um\t@1\u000bB\u000fJ\u001dv\u0016.PV\u0016{\u001f\u0011\u0015\bIhm";
      c[46] = "f)Grm\u0004#.EqV\u000e2kU,:<b(\u0004zVR!r\rv4\u0002%wDK";
      c[47] = "\\\r9\rc\u0019QD,\b\u001bF\u0001\t0TwtUJo\u0003 #P\u00046Ik\u001eR\u0017;\n\u001b";
      c[48] = "BX\u001fXUnH\u0016\u001aQ-i\u0015T\u0006MA[A\u0010\\\u0013-6\u0015\u0013\u0000FOuHT\u001d*\u0017|\u0001Z\u001eH\u001d2\u0004Sf";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1151639599775574L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1151639599775574L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1151639599775574L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 181;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 107;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 36;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 208;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 226;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 170;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 181;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 107;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 36;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gT_C0363",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(PearlTrajectoryProjectile var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gT_C0363;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/gT_C0363",
                     "lambda$tick$0",
                     "(Ldev/zprestige/prestige/gT_C0363;Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PearlTrajectoryProjectile)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
