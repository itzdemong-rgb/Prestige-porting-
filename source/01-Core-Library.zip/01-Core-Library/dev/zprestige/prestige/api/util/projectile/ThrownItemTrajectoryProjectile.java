package dev.zprestige.prestige.api.util.projectile;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class ThrownItemTrajectoryProjectile extends PersistentProjectileEntity {
   public boolean a;
   private static final long b = 23835908012573L;
   private static final Object[] c = new Object[49];
   private static final String[] d = new String[49];
   private static volatile MethodHandle bindingCache1;

   public ThrownItemTrajectoryProjectile(World var1, LivingEntity var2, ItemStack var3, long var4) {
      super(EntityType.ARROW, var2, var1, var3, var3);
      long var10000 = 23835908012573L ^ var4;

   }

   public void tick() {
      int var10000 = Event.bReturningInt();
      Predicate var15 = invokeBinding1(this);
      ThrownItemTrajectoryProjectile var14 = this;
      HitResult var4 = ProjectileUtil.getCollision((Entity)var14, var15);
      int var3 = var10000;
      int var60 = var3;
      if (var60 == 0) {
         HitResult var16 = var4;
         Type var68 = var16.getType();
         Type var62 = Type.MISS;
         Type var61 = var68;
         if (var61 != var62) {
            HitResult var19 = var4;
            ThrownItemTrajectoryProjectile var18 = this;
            var18.onCollision(var19);
         }

         ThrownItemTrajectoryProjectile var21 = this;
         var21.tickBlockCollision();
      }

      ThrownItemTrajectoryProjectile var22 = this;
      Vec3d var5 = var22.getVelocity();
      ThrownItemTrajectoryProjectile var23 = this;
      double var69 = var23.getX();
      Vec3d var24 = var5;
      double var6 = var69 + var24.x;
      ThrownItemTrajectoryProjectile var25 = this;
      double var70 = var25.getY();
      Vec3d var26 = var5;
      double var8 = var70 + var26.y;
      ThrownItemTrajectoryProjectile var27 = this;
      double var71 = var27.getZ();
      Vec3d var28 = var5;
      double var10 = var71 + var28.z;
      ThrownItemTrajectoryProjectile var29 = this;
      var29.updateRotation();
      ThrownItemTrajectoryProjectile var30 = this;
      boolean var63 = var30.isTouchingWater();
      float var57;
      if (var63) {
         float var64 = 0.8F;
         var57 = var64;
      } else {
         var57 = 0.99F;
      }

      float var12 = var57;
      double var33 = var12;
      Vec3d var32 = var5;
      Vec3d var36 = var32.multiply(var33);
      ThrownItemTrajectoryProjectile var35 = this;
      var35.setVelocity(var36);
      int var66 = var3;
      ThrownItemTrajectoryProjectile var65 = this;
      ThrownItemTrajectoryProjectile var59 = var65;
      ThrownItemTrajectoryProjectile var58 = var65;
      if (var66 == 0) {
         ThrownItemTrajectoryProjectile var37 = var58;
         boolean var67 = var37.hasNoGravity();
         if (!var67) {
            ThrownItemTrajectoryProjectile var39 = this;
            Vec3d var13 = var39.getVelocity();
            Vec3d var40 = var13;
            Vec3d var41 = var13;
            double var10002 = var41.y - 0.03;
            Vec3d var42 = var13;
            double var48 = var42.z;
            double var46 = var10002;
            double var44 = var40.x;
            ThrownItemTrajectoryProjectile var43 = this;
            var43.setVelocity(var44, var46, var48);
         }

         var59 = this;
      }

      double var55 = var10;
      double var53 = var8;
      double var51 = var6;
      ThrownItemTrajectoryProjectile var50 = var59;
      var50.setPosition(var51, var53, var55);
   }

   protected void onBlockHit(BlockHitResult var1) {
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   protected ItemStack asItemStack() {
      return null;
   }

   protected ItemStack getDefaultItemStack() {
      return null;
   }

   protected void onEntityHit(EntityHitResult var1) {
      this.a = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   public void setVelocity(double var1, double var3, double var5, float var7, float var8) {
      Vec3d var12 = new Vec3d(var1, var3, var5);
      Vec3d var10000 = var12.normalize();
      double var14 = var7;
      Vec3d var13 = var10000;
      Vec3d var11 = var13.multiply(var14);
      Vec3d var17 = var11;
      ThrownItemTrajectoryProjectile var16 = this;
      var16.setVelocity(var17);
      Vec3d var18 = var11;
      Vec3d var19 = var11;
      double var22 = var19.z;
      double var20 = var18.x;
      float var25 = (float)(MathHelper.atan2(var20, var22) * 180.0F / (float)Math.PI);
      ThrownItemTrajectoryProjectile var24 = this;
      var24.setYaw(var25);
      Vec3d var26 = var11;
      double var10001 = var26.y;
      Vec3d var27 = var11;
      double var30 = var27.horizontalLength();
      double var28 = var10001;
      float var33 = (float)(MathHelper.atan2(var28, var30) * 180.0F / (float)Math.PI);
      ThrownItemTrajectoryProjectile var32 = this;
      var32.setPitch(var33);
      ThrownItemTrajectoryProjectile var34 = this;
      float var36 = var34.getYaw();
      ThrownItemTrajectoryProjectile var35 = this;
      var35.lastYaw = var36;
      ThrownItemTrajectoryProjectile var37 = this;
      float var39 = var37.getPitch();
      ThrownItemTrajectoryProjectile var38 = this;
      var38.lastPitch = var39;
   }

   private static boolean lambda$tick$0(ThrownItemTrajectoryProjectile var0, Entity var1) {
      Entity var5 = var1;
      ThrownItemTrajectoryProjectile var4 = var0;
      return var4.canHit(var5);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 35;
            yield var15;
         }
         case 1 -> {
            byte var16 = 20;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 17;
            yield var18;
         }
         case 4 -> {
            byte var19 = 49;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 63;
            yield var22;
         }
         case 8 -> {
            byte var23 = 14;
            yield var23;
         }
         case 9 -> {
            byte var24 = 0;
            yield var24;
         }
         case 10 -> {
            byte var25 = 27;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 5;
            yield var27;
         }
         case 13 -> {
            byte var28 = 55;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 46;
            yield var30;
         }
         case 16 -> {
            byte var31 = 10;
            yield var31;
         }
         case 17 -> {
            byte var32 = 6;
            yield var32;
         }
         case 18 -> {
            byte var33 = 51;
            yield var33;
         }
         case 19 -> {
            byte var34 = 34;
            yield var34;
         }
         case 20 -> {
            byte var35 = 7;
            yield var35;
         }
         case 21 -> {
            byte var36 = 59;
            yield var36;
         }
         case 22 -> {
            byte var37 = 18;
            yield var37;
         }
         case 23 -> {
            byte var38 = 4;
            yield var38;
         }
         case 24 -> {
            byte var39 = 25;
            yield var39;
         }
         case 25 -> {
            byte var40 = 62;
            yield var40;
         }
         case 26 -> {
            byte var41 = 47;
            yield var41;
         }
         case 27 -> {
            byte var42 = 24;
            yield var42;
         }
         case 28 -> {
            byte var43 = 43;
            yield var43;
         }
         case 29 -> {
            byte var44 = 50;
            yield var44;
         }
         case 30 -> {
            byte var45 = 29;
            yield var45;
         }
         case 31 -> {
            byte var46 = 28;
            yield var46;
         }
         case 32 -> {
            byte var47 = 53;
            yield var47;
         }
         case 33 -> {
            byte var48 = 42;
            yield var48;
         }
         case 34 -> {
            byte var49 = 44;
            yield var49;
         }
         case 35 -> {
            byte var50 = 58;
            yield var50;
         }
         case 36 -> {
            byte var51 = 61;
            yield var51;
         }
         case 37 -> {
            byte var52 = 38;
            yield var52;
         }
         case 38 -> {
            byte var53 = 56;
            yield var53;
         }
         case 39 -> {
            byte var54 = 22;
            yield var54;
         }
         case 40 -> {
            byte var55 = 41;
            yield var55;
         }
         case 41 -> {
            byte var56 = 3;
            yield var56;
         }
         case 42 -> {
            byte var57 = 31;
            yield var57;
         }
         case 43 -> {
            byte var58 = 33;
            yield var58;
         }
         case 44 -> {
            byte var59 = 9;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 19;
            yield var61;
         }
         case 47 -> {
            byte var62 = 30;
            yield var62;
         }
         case 48 -> {
            byte var63 = 37;
            yield var63;
         }
         case 49 -> {
            byte var64 = 8;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 60;
            yield var67;
         }
         case 53 -> {
            byte var68 = 48;
            yield var68;
         }
         case 54 -> {
            byte var69 = 13;
            yield var69;
         }
         case 55 -> {
            byte var70 = 40;
            yield var70;
         }
         case 56 -> {
            byte var71 = 23;
            yield var71;
         }
         case 57 -> {
            byte var72 = 15;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 36;
            yield var74;
         }
         case 60 -> {
            byte var75 = 54;
            yield var75;
         }
         case 61 -> {
            byte var76 = 52;
            yield var76;
         }
         case 62 -> {
            byte var77 = 57;
            yield var77;
         }
         default -> 45;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "\r)zqd*\r)m-h%\u0017bm3h0\u0010\u0013<k:";
      c[1] = double.class;
      d[1] = "java/lang/Double";
      c[2] = "fPv\u0003\twfPa_\u0005x|\u001baA\u0005m{j1\u0018W,";
      c[3] = "\u000b\u007f0\u0004/F\u001d\u007f5^<Q\n46X0E\u001bs!O{Q9";
      c[4] = float.class;
      d[4] = "java/lang/Float";
      c[5] = void.class;
      d[5] = "java/lang/Void";
      c[6] = "=VV\u0015\u0018\u000b=VAI\u0014\u0004'\u001dAW\u0014\u0011 l\u0013\tL[";
      c[7] = boolean.class;
      d[7] = "java/lang/Boolean";
      c[8] = "\u0016\u001d{+@F\u0000\u001d~qSQ\u0017V}w_E\u0006\u0011j`\u0014W7";
      c[9] = int.class;
      d[9] = "java/lang/Integer";
      c[10] = "`0\u000bV\u007f}k?\u001a\u0019\u001cp~2\u0015r)ro!\t^>\u007f";
      c[11] = "\u0019\r\b0KA\u0019\r\u001flGN\u0003F\u001frG[\u00047N-\u001f\f\u0014\u0004\u001dmUwE\\L";
      c[12] = "Q^\u001f'\u0013\u0019Q^\b{\u001f\u0016K\u0015\be\u001f\u0003LdZ?IE";
      c[13] = "\u000f\"*T}[\u000f\"=\bqT\u0015i=\u0016qA\u0012\u0018oH)\u0005";
      c[14] = ">\\}T\u0013\u0004 Tg\u001b[\u0004:^\u007f\\R\u001fzmyPY\u00187\\\u007fP";
      c[15] = "\u001bfu|g\u0018\u001bfb k\u0017\u0001-b>k\u0002\u0006\\3a3";
      c[16] = "U r3 _^/c|AQU$g&";
      c[17] = "\u0011\tj\u0003CU\u0016\u0004~P%HF\u0019rYIz\u0011^)\u0004\u001c-\u0012\t)YZJI\u0002\"C%";
      c[18] = "\u0004\\C|Mb\u0003QW/+\u007fSL[&GM\u0003\u000f\u0007y+'\u0007\u0001\u0003'Zc[\\\u0005A";
      c[19] = "j-b[\u0006\fl2hQh\u0001Wt7\u0001T\t&$oWVk";
      c[20] = "l2\".\\*k?6}:;Va8vZ+69(\u007fERi<?sC21,6l:";
      c[21] = "\u000fQks1}YP,)]~^\ft|\n)\u0004Z+\u0010m D\u0002|};!\u0003X";
      c[22] = "D\u0007R69\u0004RQ\u0002Nd\u0000^WZ\"VT\u001a\r\fNg]MO\u0005'q\u000b\u001d7";
      c[23] = "O#=J\r.@|'_2\"\u0012;-B^\u0010Cv|\u0014\rGN{?B\n \u0010&#B2.\u001354AQx\u0005x?%[<O')ZQ#O(M";
      c[24] = "\u0012F\\~\u007f\b\u0015KH-\u0019\u0015EVD$u'\u0012\u0014\u0015}#p\u0013QU?)A\u0016NOy\u0019";
      c[25] = "E]?\u000bc~S\u000bos>z_\r7\u001f\f,\u001cWnL[.OV7\f<uD]-s";
      c[26] = "\u0014'g\u0018L\u001c\u0013*sK*\u0001C7\u007fBF3\u0017{/\u001d\u0012d\u0017'$BU\u0003L,/X*]BpxZM\u0006I{b%\u0013\b\u0015,`BH\u0003\u001e6\u001f\u001eQ\u0015R{.\u001bN\u000f\u0014K";
      c[27] = "\u0016\u007ff\u0002\"I\u0012\"m\u001e]\u001eK\u007fr\u0015\nN\u0013(,ya\u001dZii@e@Qu";
      c[28] = "\u0004>\u00151H=\u0012hEI\u001e5\u000fj\u0016\u001eIo_6zp\u001co\u0005q\u001d+\u0017d\u001f";
      c[29] = "kZRVQ5lWF\u00057(<JJ\f[\u001al\t\u001bZ7ph\u0007\u0012\rF44Z\u0014k";
      c[30] = ";\u001e\u0005\u0001_o<\u0013\u0011R9rl\u000e\u001d[U@8BB\r\t\u0017gB\u0012D\u0001~q\u0014B<";
      c[31] = "\"~!5Vy4(qM\u0000q)*\"\u001aW+ytNt\u0002+#1)/\t 9";
      c[32] = "\u000b<\u0019PHu\u001djI(\u001e}\u0000h\u001a\u007fI'P5v\u0011\u001c'\ns\u0011J\u0017,\u0010";
      c[33] = "$#^3\u0004\u0018}!Lo{\u0005p<Ln\u00177$}\u00175J`$,\u0017n\u0004\u0007\u007f'\u001ct{Yq{Kv\u001c\u0002zpQ\tB\f&'Sn\u0019\u0007-=,";
      c[34] = "\u0005lV'0H\u0002aBtVUR|N}:g\u0004>\u0012'k0\u0005q\u001f`f\u000e\u000ek^$V";
      c[35] = "^>74*%Y3#gL8\t./n \n_ls4r]^#~s|cU9?7Lf\u001f#39}c\u00009u\t";
      c[36] = "\u000e\u0001e{}\u001e\t\fq(\u001b\u0003Y\u0011}!w1\u000eV&\u007f+f\r\u0001&!d\u0001V\n-;\u001b";
      c[37] = "\u0005&!\u0003yl\u0002+5P\u001fqR69YsC\u0002z`\u0002\u001f-Sq>AxvXz$>&x\u0004-&Y}s\u000f7Y\u0007s/X5>\\x$BJbEnh\u000f{gZt.?";
      c[38] = "T\u0015:E\u0014?S\u0018.\u0016r\"\u0003\u0005\"\u001f\u001e\u0010TGsEBG_E0\u001fJ \u0001\u0018,\u001frzWHz\u001e\u0003>\u000b\u0015|x";
      c[39] = "QCWIQXVNC\u001a7E\u0006SO\u0013[wT\u0013\u001fD7I\u0010\u001fO\u0010HC\u000f\u001f@t\f[\u001aS\u001fE\tD\u0000\u0015/";
      c[40] = "!fpN=\u000b+ypAY\u0011%a I5#q\"\u007f\u001ebtx-;M5\u0019.,|\u0017Y";
      c[41] = "n?LH\u001bsi2X\u001b}e5>P\u0019*5lk\buGze)\u0004KL`$m";
      c[42] = "&+\u0019o,.!&\r<J3q;\u00015&\u0001&|ZkuV%+Z551~ Q/J";
      c[43] = "\ny8\u001b\u001bu\rt,H}h]i A\u0011Z\u000b+|\u001bB\r\ndq\\M3\u0001~0\u0018}6Kd<\u0016L3T~z&";
      c[44] = "t^*9mdb\bzA0`n\u000e\"-\u00024*T|Ala)\t:&7j\"\u0013E'ebjV,132\u0012";
      c[45] = "J0-L'&M=9\u001fA;\u001d 5\u0016-\tIlj@p^\u0016l:\ty7\u0000:jqz%\u0001 e@\u007f:\u001bfU";
      c[46] = "0#f\u0018\u0011\u00187.rKw\u000ek\"zI ];\u007f$%M\u0011;5.\u001bF\u000bzq";
      c[47] = "\u0011\u007fn1.7\u0016rzbH*Fovk$\u0018\u0015**4yO\u0010hgpx~\u0015w}6H";
      c[48] = "x\u0002P ^~\u007f\u000fDs8c/\u0012HzTQyP\u0014 \u0004\u0006x\u001f\u0019g\b8s\u0005X#8";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1181031737969080L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1181031737969080L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1181031737969080L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 83;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 120;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 109;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 206;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 251;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 186;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 83;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 120;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 109;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gV_C0367",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gV" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(ThrownItemTrajectoryProjectile var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gV_C0367;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/gV_C0367",
                     "lambda$tick$0",
                     "(Ldev/zprestige/prestige/gV_C0367;Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((ThrownItemTrajectoryProjectile)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
