package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.renderlib.GlProgram;
import dev.zprestige.prestige.renderlib.ManagedGlFramebuffer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.RenderPassSequence;
import dev.zprestige.prestige.renderlib.RenderState;
import dev.zprestige.prestige.renderlib.ShaderCompiler;
import dev.zprestige.prestige.renderlib.ShaderPrograms;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.renderlib.VertexFormats;
import dev.zprestige.prestige.renderlib.state.AlphaBlendState;
import dev.zprestige.prestige.renderlib.state.CapabilityState;
import dev.zprestige.prestige.renderlib.state.DepthFunctionState;
import dev.zprestige.prestige.renderlib.state.FramebufferState;
import dev.zprestige.prestige.renderlib.state.ProgramState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.RLUniforms;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;

public class BlurManager implements MinecraftAccess {
   private static final GlProgram a;
   private ManagedGlFramebuffer c;
   private ManagedGlTexture d;
   private int e;
   private int f;
   private boolean g;
   private DrawPipeline h;
   private RenderPassSequence i;
   private int j;
   private float k;
   private float l;
   private static final long m = 28786120819740L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long[] q;
   private static final Integer[] r;
   private static final Map s;
   private static final Object[] t = new Object[63];
   private static final String[] u = new String[63];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public BlurManager(long var1) {
      super();
      var1 = 28786120819740L ^ var1;
      long var3 = var1 ^ 10408996845866L;
      long var5 = var1 ^ 87288968463082L;

      Object[] var7 = new Object[]{var3};
      this.c = ManagedGlFramebuffer.aReturningbR_C0091(var7);
      short var10001 = 25241;
      long var10002 = 6054372802806600745L ^ var1;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = 3553;
      Object[] var8 = var10004;
      this.d = ManagedGlTexture.aReturningbT_C0095(var8);
      this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
      var10001 = 17483;
      var10002 = 8821695720051962595L ^ var1;
      this.j = 5;
      this.k = 15.0F;
      this.l = 0.3F;
   }

   private void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 28786120819740L ^ var2;
      long var4 = var2 ^ 102916770487239L;
      long var6 = var2 ^ 93365759961449L;
      long var8 = var2 ^ 91427558122916L;
      long var10 = var2 ^ 119090383280825L;
      long var12 = var2 ^ 18710062752353L;
      long var14 = var2 ^ 71303959074225L;
      long var16 = var2 ^ 45498584221715L;
      long var18 = var2 ^ 83254294073977L;
      int var20 = Event.bReturningInt();
      MinecraftClient var23 = b;
      Window var10000 = var23.getWindow();
      int var74 = var20;
      Window var73 = var10000;
      Window var61 = var73;
      Window var60 = var73;
      if (var74 == 0) {
         Window var75 = var60;
         if (var75 == null) {
            return;
         }

         MinecraftClient var25 = b;
         var61 = var25.getWindow();
      }

      Window var26 = var61;
      int var21 = var26.getFramebufferWidth();
      MinecraftClient var27 = b;
      Window var28 = var27.getWindow();
      int var22 = var28.getFramebufferHeight();
      int var77 = var20;
      int var76 = var21;
      int var63 = var76;
      int var62 = var76;
      if (var77 == 0) {
         int var78 = var62;
         if (var78 <= 0) {
            return;
         }

         var63 = var22;
      }

      int var80 = var20;
      int var79 = var63;
      int var65 = var79;
      int var64 = var79;
      if (var80 == 0) {
         int var81 = var64;
         if (var81 <= 0) {
            return;
         }

         var65 = (((this.g) ? 1 : 0));
      }

      BlurManager var72;
      label68: {
         int var83 = var20;
         int var82 = var65;
         int var69 = var82;
         int var66 = var82;
         if (var83 == 0) {
            int var84 = var66;
            if (var84 == 0) {
               this.e = var21;
               this.f = var22;
               ManagedGlTexture var99 = this.d;
               short var10001 = 1844;
               long var10002 = 5620820619200026823L ^ var2;
               int var116 = this.e;
               int var10003 = this.f;
               Object[] var10006 = new Object[]{null, null, null, var4};
               var10006[2] = var10003;
               var10006[1] = var116;
               var10006[0] = 32856;
               Object[] var33 = var10006;
               ManagedGlTexture var32 = var99;
               var32.cReturningVoid(var33);
               ManagedGlTexture var100 = this.d;
               var10001 = 3161;
               var10002 = 6599180353182258108L ^ var2;
               Object[] var10004 = new Object[]{null, var10};
               var10004[0] = 9729;
               Object[] var35 = var10004;
               ManagedGlTexture var34 = var100;
               var34.bReturningVoid(var35);
               ManagedGlTexture var101 = this.d;
               var10001 = 20469;
               var10002 = 197712769966051331L ^ var2;
               var10004 = new Object[]{null, var18};
               var10004[0] = 33071;
               Object[] var37 = var10004;
               ManagedGlTexture var36 = var101;
               var36.eReturningVoid(var37);
               ManagedGlFramebuffer var102 = this.c;
               var10001 = 28541;
               var10002 = 641659643249143965L ^ var2;
               Object[] var10005 = new Object[]{null, this.d, var16};
               var10005[0] = 36064;
               Object[] var39 = var10005;
               ManagedGlFramebuffer var38 = var102;
               var38.bReturningVoid(var39);
               ManagedGlFramebuffer var103 = this.c;
               Object[] var10007 = new Object[]{null, null, null, null, var6};
               var10007[3] = 0.0F;
               var10007[2] = 0.0F;
               var10007[1] = 0.0F;
               var10007[0] = 0.0F;
               Object[] var41 = var10007;
               ManagedGlFramebuffer var40 = var103;
               var40.eReturningVoid(var41);
               VertexFormat var124 = VertexFormats.b;
               short var130 = 16383;
               long var133 = 6966723216378257418L ^ var2;
               RenderState[] recoveryRenderStates = new RenderState[]{new FramebufferState(this.c.a), new ProgramState(ShaderPrograms.a), null, null, null, null};
               short var10011 = 13319;
               long var10012 = 2268070361433205736L ^ var2;
               recoveryRenderStates[2] = new CapabilityState(2884, false);
               recoveryRenderStates[3] = new AlphaBlendState(true, true);
               var10011 = 18293;
               var10012 = 1572749014331725954L ^ var2;
               short var138 = 2732;
               long var10013 = 3873761298680960327L ^ var2;
               recoveryRenderStates[4] = new DepthFunctionState(519, 515);
               var10011 = 18131;
               var10012 = 8886953704716933438L ^ var2;
               recoveryRenderStates[5] = new CapabilityState(2929, false);
               this.h = new DrawPipeline(var124, 4, false, recoveryRenderStates, var14);
               RenderPassSequence var111 = new RenderPassSequence();
               Object[] var43 = new Object[]{a, invokeBinding1(this), invokeBinding2(), var12};
               RenderPassSequence var42 = var111;
               this.i = var42.bReturningVoid(var43);
               this.g = dev.prestige.recovery.SourceSupport.asBoolean(1);
               int var85 = var20;
               if (var85 == 0) {
                  return;
               }
            }

            int var87 = var20;
            BlurManager var86 = this;
            var72 = var86;
            BlurManager var67 = var86;
            if (var87 != 0) {
               break label68;
            }

            BlurManager var88 = var67;
            BlurManager var68 = var88;
            int var89 = var68.e;
            var69 = var89;
         }

         int var91 = var21;
         int var90 = var69;
         if (var90 == var91) {
            int var93 = var20;
            BlurManager var92 = this;
            var72 = var92;
            BlurManager var70 = var92;
            if (var93 != 0) {
               break label68;
            }

            BlurManager var94 = var70;
            BlurManager var71 = var94;
            int var96 = var22;
            int var95 = var71.f;
            if (var95 == var96) {
               return;
            }
         }

         this.e = var21;
         this.f = var22;
         ManagedGlTexture var112 = this.d;
         int var120 = this.e;
         int var125 = this.f;
         Object[] var132 = new Object[]{null, null, var8};
         var132[1] = var125;
         var132[0] = var120;
         Object[] var50 = var132;
         ManagedGlTexture var49 = var112;
         this.d = var49.cReturningbT_C0095(var50);
         ManagedGlTexture var104 = this.d;
         short var113 = 28511;
         long var121 = 1909489354570313907L ^ var2;
         Object[] var127 = new Object[]{null, var10};
         var127[0] = 9729;
         Object[] var52 = var127;
         ManagedGlTexture var51 = var104;
         var51.bReturningVoid(var52);
         ManagedGlTexture var105 = this.d;
         short var114 = 20191;
         long var122 = 4619329406189113649L ^ var2;
         var127 = new Object[]{null, var18};
         var127[0] = 33071;
         Object[] var54 = var127;
         ManagedGlTexture var53 = var105;
         var53.eReturningVoid(var54);
         ManagedGlFramebuffer var106 = this.c;
         short var115 = 26737;
         long var123 = 4368694021419317143L ^ var2;
         Object[] var129 = new Object[]{null, this.d, var16};
         var129[0] = 36064;
         Object[] var56 = var129;
         ManagedGlFramebuffer var55 = var106;
         var55.bReturningVoid(var56);
         BlurManager var97 = this;
         var72 = var97;
      }

      ManagedGlFramebuffer var107 = var72.c;
      Object[] var134 = new Object[]{null, null, null, null, var6};
      var134[3] = 0.0F;
      var134[2] = 0.0F;
      var134[1] = 0.0F;
      var134[0] = 0.0F;
      Object[] var59 = var134;
      ManagedGlFramebuffer var58 = var107;
      var58.eReturningVoid(var59);
   }

   public DrawPipeline aReturningdn_C0192(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 28786120819740L ^ var2;
      long var4 = var2 ^ 93598337400512L;
      Object[] var7 = new Object[]{var4};
      BlurManager var6 = this;
      var6.aReturningVoid(var7);
      return this.h;
   }

   public void bReturningVoid(Object[] var1) {
      int var5 = (Integer)var1[0];
      float var2 = (Float)var1[1];
      float var6 = (Float)var1[2];
      long var3 = (Long)var1[3];
      var3 = 28786120819740L ^ var3;
      long var7 = var3 ^ 20671458155116L;
      long var9 = var3 ^ 115273896064738L;
      long var11 = var3 ^ 101192929572633L;
      int var10000 = Event.cReturningInt();
      Object[] var18 = new Object[]{var11};
      BlurManager var17 = this;
      var17.aReturningVoid(var18);
      int var13 = var10000;
      int var50 = var13;
      BlurManager var49 = this;
      BlurManager var42 = var49;
      BlurManager var41 = var49;
      if (var50 != 0) {
         RenderPassSequence var51 = var41.i;
         if (var51 == null) {
            return;
         }

         this.j = var5;
         this.k = var2;
         var42 = this;
      }

      var42.l = var6;
      short var62 = 25640;
      long var10001 = 901250090305898695L ^ var3;
      byte var14 = ((byte)((GL30.glGetBoolean(2884)) ? 1 : 0));
      var62 = 11623;
      var10001 = 6379049562645430656L ^ var3;
      byte var15 = ((byte)((GL30.glGetBoolean(3042)) ? 1 : 0));
      var62 = 17773;
      var10001 = 623080203970767232L ^ var3;
      byte var16 = ((byte)((GL30.glGetBoolean(2929)) ? 1 : 0));
      var62 = 25640;
      var10001 = 901250090305898695L ^ var3;
      GL30.glDisable(2884);
      var62 = 29418;
      var10001 = 4190578341391785489L ^ var3;
      GL30.glEnable(3042);
      var62 = 8165;
      var10001 = 7549679763819770631L ^ var3;
      var62 = 770;
      short var80 = 21588;
      long var10002 = 5049565937298143393L ^ var3;
      GL30.glBlendFunc(770, 771);
      var62 = 17773;
      var10001 = 623080203970767232L ^ var3;
      GL30.glDisable(2929);
      RenderPassSequence var70 = this.i;
      Object[] var30 = new Object[]{var9};
      RenderPassSequence var29 = var70;
      var29.aReturningVoid(var30);
      int var53 = var13;
      byte var52 = var16;
      byte var44 = var52;
      byte var43 = var52;
      if (var53 != 0) {
         byte var54 = var43;
         if (var54 != 0) {
            var62 = 17773;
            var10001 = 623080203970767232L ^ var3;
            GL30.glEnable(2929);
         }

         var44 = var14;
      }

      int var56 = var13;
      byte var55 = var44;
      byte var46 = var55;
      byte var45 = var55;
      if (var56 != 0) {
         byte var57 = var45;
         if (var57 != 0) {
            var62 = 25640;
            var10001 = 901250090305898695L ^ var3;
            GL30.glEnable(2884);
         }

         var46 = var15;
      }

      label37: {
         int var59 = var13;
         byte var58 = var46;
         short var48 = var58;
         byte var47 = var58;
         if (var59 != 0) {
            byte var60 = var47;
            if (var60 != 0) {
               break label37;
            }

            var62 = 29418;
            var10001 = 4190578341391785489L ^ var3;
            var48 = 3042;
         }

         short var38 = var48;
         GL30.glDisable(var38);
      }

      ManagedGlFramebuffer var74 = this.c;
      Object[] var10007 = new Object[]{null, null, null, null, var7};
      var10007[3] = 0.0F;
      var10007[2] = 0.0F;
      var10007[1] = 0.0F;
      var10007[0] = 0.0F;
      Object[] var40 = var10007;
      ManagedGlFramebuffer var39 = var74;
      var39.eReturningVoid(var40);
   }

   private void lambda$initOrResize$0(RenderPass var1) {
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var6 = this.d.a;
      GL30.glBindTexture(3553, var6);
      GL30.glTexParameteri(3553, 33085, 4);
      GL30.glTexParameteri(3553, 10241, 9985);
      GL30.glGenerateMipmap(3553);
      GL30.glTexParameteri(3553, 10242, 33071);
      GL30.glTexParameteri(3553, 10243, 33071);
      GlProgram var39 = a;
      Object[] var21 = new Object[0];
      GlProgram var20 = var39;
      int var22 = var20.aReturningInt(var21);
      RLUniforms var40 = RLUniforms.aReturningVoid(var22);
      byte var10002 = 0;
      String var24 = "texSampler";
      RLUniforms var23 = var40;
      RLUniforms var41 = var23.aReturningVoid(var24, 0);
      int var28 = this.j;
      String var27 = "quality";
      RLUniforms var26 = var41;
      RLUniforms var42 = var26.aReturningVoid(var27, var28);
      float var31 = this.k;
      String var30 = "radius";
      RLUniforms var29 = var42;
      RLUniforms var43 = var29.aReturningVoid(var30, var31);
      float var34 = this.l;
      String var33 = "fill";
      RLUniforms var32 = var43;
      RLUniforms var44 = var32.aReturningVoid(var33, var34);
      float var45 = 1.0F / this.e;
      float var38 = 1.0F / this.f;
      float var37 = var45;
      String var36 = "oneTexel";
      RLUniforms var35 = var44;
      var35.aReturningVoid(var36, var37, var38);
   }

   static {

      {

      long var10001 = 53680217646709L ^ 43429752938678L;
      aReturningVoid();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(53680217646709L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[7];
      String var15 = "\u0098\u0092\u0086b\u00831(\u009c\u0095\u001dÅAK=ô\u008b\u0018¨Ï¾?÷E\u0082®|v\u009aÛ\u007f\u0014\u001bòß°t\u0089Î.'B\u0018\u0004ú\bMÑ&i\u0010z\u001c¼\u0013ß\u0091»´\u0090\u008fÚ\u0003À\u0094Ò\u009f\u0010'V¯\u0097\u0087p ÃVØ\u0014\u000fÆ,1ã(Î?\nUñ·wópÝz\u0010\u0082äÚ¾\u00adj¨¿²\u000eäýD$\u0003'Î7\u0086Ìu\u0099U8ÚQ\u007f\f";
      int var17 = "\u0098\u0092\u0086b\u00831(\u009c\u0095\u001dÅAK=ô\u008b\u0018¨Ï¾?÷E\u0082®|v\u009aÛ\u007f\u0014\u001bòß°t\u0089Î.'B\u0018\u0004ú\bMÑ&i\u0010z\u001c¼\u0013ß\u0091»´\u0090\u008fÚ\u0003À\u0094Ò\u009f\u0010'V¯\u0097\u0087p ÃVØ\u0014\u000fÆ,1ã(Î?\nUñ·wópÝz\u0010\u0082äÚ¾\u00adj¨¿²\u000eäýD$\u0003'Î7\u0086Ìu\u0099U8ÚQ\u007f\f"
         .length();
      char var14 = 16;
      int var27 = -1;

      label54:
      while (true) {
         String var28 = var15.substring(++var27, var27 + var14);
         // while (true) {
            byte[] var19 = var11.doFinal(var28.getBytes("ISO-8859-1"));
            String var40 = a(var19).intern();
            switch (var32) {
               case 0:
                  var18[var16++] = var40;
                  if ((var27 += var14) >= var17) {
                     n = var18;
                     o = new String[7];
                     s = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(53680217646709L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[27];
                     String var4 = "«^È`3\u0006\u0016gÃ±²\u008e\tÅÊÅ{séHæq\u0086Ç¥òc\u0089À\u009dÜ\u0092Þ47$\u0005\u0095¯Õ\u00199{DÖù\u0095Íñæ¸ïv\u0013ª\u0005®µ\u0087º\u0089ÇQ\tï1}Gøg\u0016)~ÛàáÑ,@\n\u008d×Þ\u0082Û\u0085N\n/vFhÆÛ\u0001¹Åç\u0016òá\u0094/9õ\\zzÒã\u008c\u0011rÐ2\f1Âªé\u0089e(\u0088,Ñ}\u001a\u0081d2H\u0004\u007f\u0086¼{\u0019/18$³>\tæ>Õ{s÷\u0010ïí\\\u00adï\u0004¶\u008e\u0084 Vü\u0097¨£@\u0018AP\u0082Æpg\u001c\u001a½Û¶ëg\u0083\u0083þ\u009d\u0011#¼(\u0094~YÊ Ý\u0006Øè¢";
                     int var5 = "«^È`3\u0006\u0016gÃ±²\u008e\tÅÊÅ{séHæq\u0086Ç¥òc\u0089À\u009dÜ\u0092Þ47$\u0005\u0095¯Õ\u00199{DÖù\u0095Íñæ¸ïv\u0013ª\u0005®µ\u0087º\u0089ÇQ\tï1}Gøg\u0016)~ÛàáÑ,@\n\u008d×Þ\u0082Û\u0085N\n/vFhÆÛ\u0001¹Åç\u0016òá\u0094/9õ\\zzÒã\u008c\u0011rÐ2\f1Âªé\u0089e(\u0088,Ñ}\u001a\u0081d2H\u0004\u007f\u0086¼{\u0019/18$³>\tæ>Õ{s÷\u0010ïí\\\u00adï\u0004¶\u008e\u0084 Vü\u0097¨£@\u0018AP\u0082Æpg\u001c\u001a½Û¶ëg\u0083\u0083þ\u009d\u0011#¼(\u0094~YÊ Ý\u0006Øè¢"
                        .length();
                     label36:
                     while (true) {
                        int var36 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var36, var2).getBytes("ISO-8859-1");
                        long[] var31 = var6;
                        int var37 = var3++;
                        long var44 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var44;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var49 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var47) {
                              case 0:
                                 var31[var37] = var49;
                                 if (var2 >= var5) {
                                    q = var6;
                                    r = new Integer[27];
                                    Object[] var10005 = new Object[]{null, null, null, 26034492851907L};
                                    var10005[2] = false;
                                    var10005[1] = "shaders/storage_outline.frag";
                                    var10005[0] = "shaders/post.vert";
                                    Object[] var24 = var10005;
                                    a = ShaderCompiler.aReturningfM_C0295(var24);
                                    break;
                                 }
                                 break;
                              default:
                                 var31[var37] = var49;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "w\u0018äd\u0098:w¡\u0007JïB\"¼>×";
                                 var5 = "w\u0018äd\u0098:w¡\u0007JïB\"¼>×".length();
                                 var2 = 0;
                           }

                           int var38 = var2;
                           var2 += 8;
                           var7 = var4.substring(var38, var2).getBytes("ISO-8859-1");
                           var31 = var6;
                           var37 = var3++;
                           var44 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var47 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var27);
                  break;
               default:
                  var18[var16++] = var40;
                  if ((var27 += var14) < var17) {
                     var14 = var15.charAt(var27);
                     continue label54;
                  }

                  var15 = "!\u009a\u0012Û.Cþ\u0081\u0090_fXì\u001bCË0ø2rÇb\u0092Q\"ý/{\u0004-\u0006*ÇJ\u009b\u007fð\u0001U\u001b=ckÐ\u0093\u001aÈàÁV5 ¦oë\u001aÃ¬å\r\u0099\u0084øQ,";
                  var17 = "!\u009a\u0012Û.Cþ\u0081\u0090_fXì\u001bCË0ø2rÇb\u0092Q\"ý/{\u0004-\u0006*ÇJ\u009b\u007fð\u0001U\u001b=ckÐ\u0093\u001aÈàÁV5 ¦oë\u001aÃ¬å\r\u0099\u0084øQ,"
                     .length();
                  var14 = 16;
                  var27 = -1;
            }

            var28 = var15.substring(++var27, var27 + var14);
            var32 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2395;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fS", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fS_C0307",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6199;
      if (r[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = q[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])s.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fS", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         r[var3] = var15;
      }

      return r[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fS_C0307",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = u[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = t[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 47;
            yield var15;
         }
         case 1 -> {
            byte var16 = 43;
            yield var16;
         }
         case 2 -> {
            byte var17 = 54;
            yield var17;
         }
         case 3 -> {
            byte var18 = 52;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 14;
            yield var20;
         }
         case 6 -> {
            byte var21 = 28;
            yield var21;
         }
         case 7 -> {
            byte var22 = 29;
            yield var22;
         }
         case 8 -> {
            byte var23 = 60;
            yield var23;
         }
         case 9 -> {
            byte var24 = 62;
            yield var24;
         }
         case 10 -> {
            byte var25 = 15;
            yield var25;
         }
         case 11 -> {
            byte var26 = 33;
            yield var26;
         }
         case 12 -> {
            byte var27 = 10;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 8;
            yield var30;
         }
         case 16 -> {
            byte var31 = 42;
            yield var31;
         }
         case 17 -> {
            byte var32 = 23;
            yield var32;
         }
         case 18 -> {
            byte var33 = 19;
            yield var33;
         }
         case 19 -> {
            byte var34 = 2;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 12;
            yield var36;
         }
         case 22 -> {
            byte var37 = 39;
            yield var37;
         }
         case 23 -> {
            byte var38 = 4;
            yield var38;
         }
         case 24 -> {
            byte var39 = 32;
            yield var39;
         }
         case 25 -> {
            byte var40 = 45;
            yield var40;
         }
         case 26 -> {
            byte var41 = 57;
            yield var41;
         }
         case 27 -> {
            byte var42 = 25;
            yield var42;
         }
         case 28 -> {
            byte var43 = 18;
            yield var43;
         }
         case 29 -> {
            byte var44 = 46;
            yield var44;
         }
         case 30 -> {
            byte var45 = 24;
            yield var45;
         }
         case 31 -> {
            byte var46 = 58;
            yield var46;
         }
         case 32 -> {
            byte var47 = 9;
            yield var47;
         }
         case 33 -> {
            byte var48 = 6;
            yield var48;
         }
         case 34 -> {
            byte var49 = 36;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 38;
            yield var51;
         }
         case 37 -> {
            byte var52 = 22;
            yield var52;
         }
         case 38 -> {
            byte var53 = 1;
            yield var53;
         }
         case 39 -> {
            byte var54 = 20;
            yield var54;
         }
         case 40 -> {
            byte var55 = 11;
            yield var55;
         }
         case 41 -> {
            byte var56 = 48;
            yield var56;
         }
         case 42 -> {
            byte var57 = 56;
            yield var57;
         }
         case 43 -> {
            byte var58 = 16;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 44;
            yield var60;
         }
         case 46 -> {
            byte var61 = 35;
            yield var61;
         }
         case 47 -> {
            byte var62 = 31;
            yield var62;
         }
         case 48 -> {
            byte var63 = 27;
            yield var63;
         }
         case 49 -> {
            byte var64 = 50;
            yield var64;
         }
         case 50 -> {
            byte var65 = 13;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 5;
            yield var67;
         }
         case 53 -> {
            byte var68 = 34;
            yield var68;
         }
         case 54 -> {
            byte var69 = 26;
            yield var69;
         }
         case 55 -> {
            byte var70 = 17;
            yield var70;
         }
         case 56 -> {
            byte var71 = 49;
            yield var71;
         }
         case 57 -> {
            byte var72 = 7;
            yield var72;
         }
         case 58 -> {
            byte var73 = 0;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 40;
            yield var75;
         }
         case 61 -> {
            byte var76 = 55;
            yield var76;
         }
         case 62 -> {
            byte var77 = 3;
            yield var77;
         }
         default -> 53;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            u[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      t[0] = "\u001c\\\f\u0012W5\n\\\tHD\"\u001d\u0017\nNH6\fP\u001dY\u0003#4";
      t[1] = "6\u001a8{O/C:3t^`\"48\u007fZ:V";
      t[2] = "3Fc-6y%Ffw%n2\req)z#Jrfbo\u001a";
      t[3] = "@cxmu;Evsmv<J\u007fx/7\u000bc\"/";
      t[4] = int.class;
      u[4] = "java/lang/Integer";
      t[5] = void.class;
      u[5] = "java/lang/Void";
      t[6] = "B[[vLCT[^,_TC\u0010]*S@RWJ=\u0018T_";
      t[7] = "=\u0006eE,66\tt\nQ.%\u000e}C";
      t[8] = float.class;
      u[8] = "java/lang/Float";
      t[9] = "Ki\u0000c6oN|\u000bc5hAu\u0000!t_h*T";
      t[10] = "*bFh\u000b2_BMg\u001a}>LFl\u001e'J";
      t[11] = "g\u000b\u0012T\u001asq\u000b\u0017\u000e\tdf@\u0014\b\u0005pw\u0007\u0003\u001fNbF";
      t[12] = "7\u0011w\u0012 #7\u0011`N,,-Z`P,9*+2\fy{";
      t[13] = "aO\u001bD\u001fxwO\u001e\u001e\fo`\u0004\u001d\u0018\u0000{qC\n\u000fKjQ";
      t[14] = "\u0014\u00159H\bLa52G\u0019\u0003\u0000;9L\u001dYt";
      t[15] = "N\u000e?W\u0011g;.4X\u0000(Z ?S\u0004r.";
      t[16] = "F;\fc 2P;\t93%Gp\n??1V7\u001d(t p";
      t[17] = "~\u0001.q*8\u000b!%~;wj/.u?-\u001e";
      t[18] = "{0bYB3\u000e\u0010iVS|o\u001eb]W&\u001b";
      t[19] = "\n\u0015ss\u0007G\u007f5x|\u0016\b\u001e;sw\u0012Rj";
      t[20] = "l\u0018:73qz\u0018?m fmS<k,r|\u0014+|gb<";
      t[21] = "l\u001b<x_l\u0019;7wN#x5<|Jy\f";
      t[22] = "9o\u001b<!@9o\f`-O#$\f~-Z$U\\#|";
      t[23] = "y?q\u007fyq\f\u001fzph>m\u0011q{ld\u0019";
      t[24] = ",\u0015tZUe:\u0015q\u0000Fr-^r\u0006Jf<\u0019e\u0011\u0001s\u001b";
      t[25] = ")v=JA*\"y,\u0005\"'7t#n\u0017%&g?B\u0000(";
      t[26] = "\u000e6*(}I{\u0016!'l\u0006\u001a\u0018*,h\\n";
      t[27] = "\u0006\u000b*|axs+!sp7\u0012%*xtmf";
      t[28] = boolean.class;
      u[28] = "java/lang/Boolean";
      t[29] = "g'^:mt\u0012\u0007U5|;s\t^>xa\u0007";
      t[30] = "!\u001a<\u001dreT:7\u0012c*54<\u0019gpA";
      t[31] = "J*(r\b2A%9=i<J.=g";
      t[32] = "k,9c}.2$+<\u0003<5\f4:n)8?4\u0019b+4*!\\8ka1;d;:) Yg\u007f5>s6l?+iC";
      t[33] = "&\"\u0019]\u0012E\u007f*\u000b\u0002lWx\u0011\u0014\u00124Qf$\u001c\u000f\u0010Uf,yYT\bn/AZ\u0005@\u007fMBZ\\J~uA\u000b\u0014[\u001cvAR\u001eZ$u\u0010\u001a\u000f8'1\u001f\r\\W,q\u0001Zl";
      t[34] = "-\u001eFY,GtXW\u0005\u0013G\u0012]\u0006\u0005aO*^WMp-";
      t[35] = "ad\u0011R\u0002(ah\u001dY{.PgNXD6mj\u0011]\u0000Gad\u0011R\u0002(ah\u001dY{";
      t[36] = "\u000b[@\u000bKh@R\u0001W4fVLP\tXT\u0007\f\u0000_48\u0003\u0000B\f\f;RHSn";
      t[37] = "N8ZKXA\u00170H\u0014&S\u0010\u001a\\\u001dLX\u0019W\u0001L\u0016N\u0016o\u0002\u001d^_tlF\u0012I\f\u001bg\u0006\f\u001e<";
      t[38] = "n\u000eZ\\Kx%\u0007\u001b\u00004v3\u0019J^XDbX\u0012\u00074(fUX[\f+7\u001dI9";
      t[39] = "1\u0016Y~Z\"1\u001aUu#&\u0000\u0015\u0006t\u001c<=\u0018YqXM1\u0016Y~Z\"1\u001aUu#";
      t[40] = "I~a-\b\n\u00108pq7\u000bv=!qE\u0002N>p9T`";
      t[41] = "\u001e0/weJ\u001e<#|\u001cO/3p}#T\u0012>/xg%\u0014+'v,J\u001fk9!\u001c";
      t[42] = "\u001f\u001a)j:\u0001\u0010[t+UP\u007fNu\u007fjHBC*z.9DV\"teVO\u0016<#U";
      t[43] = "W\u000buP+3U\u0018t[\u0011!kN|Psp\tMv\u0003lHV\u000el\u0005tq\bBn\u0019\u0011u\u0016\tr\u0004(+Z\u000bna-0\bB,\u001a/#\tI\u0016";
      t[44] = "\u0015\t!l\u0007\u0005\u0015\u0005-g~\u0007$\n~fA\u001b\u0019\u0007!c\u0005j\u001f\u0012)mN\u0005\u0014R7:~";
      t[45] = "\t ,3E<W98I\u0016\u0007Sw!v\u000e:^($2\u007f>X%7$\u0014kR8'I";
      t[46] = "Sf\u000ecP8\nn\u001c<.*\rC\n1H)'t\b7.~Q9\u001c>\u0016}\u0000q\r\\\u0015}Y{\fd\u0016,\u0011jngR#\u00069\u0001l\u0012=Q\t";
      t[47] = "T\u0005(P\u001f\u0005\u000b\u0006pVe\u0002W\u0016)K\t0\u0000Pw\u001c^g\n\u00019I\u001a\fA\bx\u0015e";
      t[48] = "lQZ\u001e\u0005\u00189[G\u000eh\u001aUZ\b\bW\u0002hWW\r\u0013sn\u0006\t\u001e\nKmWA\u000fh";
      t[49] = "\u0014pT@B\u0005MxF\u001f<\u0017JSU\u0004U\u0012Jr4D\u0004H\\}\fGU\u0000M\u001f\u000f\u0003Z\u0017\u001ep\u0004CD@.";
      t[50] = "!TO0[\u0003-QI3;RKH\u00059\u0004JvEZ<@;!TO0[\u0003-QI3;";
      t[51] = "\u0017&\u0018m\u0011\u0016N.\n2o\u0004I\u0006\u0015.%\fJ-\u0015;\tk\u0016qH \rS\u0015 \u00001o\b\u00152\u0002iQ\u0019\u0016#FR";
      t[52] = "!_5\u001bc.#L4\u0010Y<\u001d\u001a<\u001b;m\u007f\u00196H$U Z,N<l~\u0016.RYieDg\u0010\"kvEl*";
      t[53] = "n0Xf0~l#Ym\nlRs\u0003gxgjpR/i\u0005n0Xf0~l#Ym\n";
      t[54] = "O\u001aR7M4G\u001eR%?f\"D\u0013+\u0000~\u001fIL.D\u000f\u0019\\D \u000f`\u0012\u001cZw?";
      t[55] = "n\u0005Yy4\u001el\u0016Xr\u000e\fR@Pyl]0CZ*seiE\n:l]j\u0014B+\u000eY*\u001e\u000bru[9\u001f\u0000H";
      t[56] = "\u0002/^)dY\u0006n\u0003q\u0002YX\u001fXmcHQ\n^a~KF;3*:\u0006N4\u000b)kN_V\bmdY\f9\u0003-z\u000e<";
      t[57] = "\u00175\r|u\b\u001b0\u000b\u007f\u0015]})Gu*A@$\u0018pn0F1\u0010~%_Mq\u000e)\u0015";
      t[58] = "SVX\u001c\u0019\u001a_S^\u001fyH9J\u0012\u0015FS\u0004GM\u0010\u0002\"\u0002RE\u001eIM\t\u0012[Iy";
      t[59] = "\n?s{%\u007f\u0002;siW.ga2gh5Zlmb,D\n?s{%\u007f\u0002;siW";
      t[60] = "\u001e!<82\rG).gL\u001f@\u0004=a ,I> z6\u001d$ud7>\u0012\u001cv5\u007f/p\u001fvlu.H\u001c'$dLKX(37#@\u00186d\u0007";
      t[61] = "&\t0h&e&\u0005<c_a\u0017\nob`{*\u00070g$\n,\u00128ioe'R&>_";
      t[62] = "9DBE4z6\u0005\u001f\u0004[+Y\u0014Q_f25\u0018NS<B9\nD\t+.5\u0015HS[";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = t[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(u[var4]);
            t[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = t[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            t[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  t[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(2209839577784440L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = t[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  t[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(2209839577784440L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        t[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(2209839577784440L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 104;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 76;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 100;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 240;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 199;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 83;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 104;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 76;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 100;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fS_C0307",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Consumer invokeBinding1(BlurManager var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fS_C0307;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/fS_C0307", "lambda$initOrResize$0", "(Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((BlurManager)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static IntSupplier invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("()Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dj_C0184", "a", "()I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
