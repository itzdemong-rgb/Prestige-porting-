package dev.zprestige.prestige.client.management;
import java.util.Collections;
import java.util.IdentityHashMap;


import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.ConfigLoadStatistics;
import dev.zprestige.prestige.client.ui.hud.HudElement;
import dev.zprestige.prestige.api.annotation.NativeMarker;
import dev.zprestige.prestige.client.management.NotificationManager;
import dev.zprestige.prestige.api.setting.SettingDefinition;
import dev.zprestige.prestige.api.setting.SettingValueCodec;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.management.ConfigSettingEntry;
import dev.zprestige.prestige.client.ui.hud.HudAlignment;
import dev.zprestige.prestige.client.ui.hud.HudCorner;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;

public class ConfigManager {
   private static final Gson a;
   private static final int b;
   private static final int c;
   private String d;
   private String e;
   private static final long f = 94490381836703L;
   private static final String[] g;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final long m;
   private static final Object[] n = new Object[201];
   private static final String[] o = new String[201];
   private static volatile MethodHandle bindingCache1;

   
   
   @NativeMarker
   public String aReturningString() {
      long var10001 = 101704930532512L ^ 65554981970222L;
      var10001 = 101704930532512L ^ 42382175330247L;
      var10001 = 101704930532512L ^ 137171412613782L;
      var10001 = 101704930532512L ^ 114203152127535L;
      var10001 = 101704930532512L ^ 6431848072067L;
      var10001 = 101704930532512L ^ 117806532348804L;
      ConfigLoadStatistics var16 = new ConfigLoadStatistics("save");
      int var10000 = Event.cReturningInt();
      JsonObject var17 = new JsonObject();
      int var15 = var10000;

      String var252;
      label226: {
         String var185;
         label225: {
            try {
               label230: {
                  label222: {
                     int var190 = var15;
                     if (var190 != 0) {
                        ModuleManager var191 = Prestige.d;
                        if (var191 != null) {
                           break label222;
                        }

                        Object[] var28 = new Object[]{"Config", "module manager is not ready", null};
                        ConfigLoadStatistics var27 = var16;
                        var27.recoveryAccess_call_bReturningVoid(var28);
                     }

                     int var192 = var15;
                     if (var192 != 0) {
                        break label230;
                     }
                  }

                  HashSet var18 = new HashSet();
                  String var31 = "Menu";
                  HashSet var30 = var18;
                  var30.add(var31);
                  JsonObject var19 = new JsonObject();
                  ModuleManager var266 = Prestige.d;
                  Object[] var33 = new Object[0];
                  ModuleManager var32 = var266;
                  ArrayList var34 = var32.aReturningMenuSettings(var33).a;
                  Iterator var20 = var34.iterator();

                  label213: {
                     int var195;
                     do {
                        Iterator var35 = var20;
                        boolean var193 = var35.hasNext();
                        if (!var193) {
                           break;
                        }

                        Iterator var36 = var20;
                        SettingDefinition var21 = (SettingDefinition)var36.next();
                        Object[] var38 = new Object[]{var19, var21, "Menu", var16, 113383699938702L};
                        ConfigManager var37 = this;
                        var37.gReturningVoid(var38);
                        int var194 = var15;
                        if (var194 == 0) {
                           break label213;
                        }

                        var195 = var15;
                     } while (var195 != 0);

                     JsonObject var42 = var19;
                     String var41 = "Menu";
                     JsonObject var40 = var17;
                     var40.add(var41, (JsonElement)var42);
                  }

                  ModuleManager var43 = Prestige.d;
                  List var44 = var43.aReturningVoid();
                  var20 = var44.iterator();

                  int var215;
                  label202:
                  do {
                     String var22;
                     int var208;
                     Module var255;
                     do {
                        boolean var175;
                        while (true) {
                           Iterator var45 = var20;
                           boolean var196 = var45.hasNext();
                           if (!var196) {
                              break label202;
                           }

                           label170: {
                              Iterator var46 = var20;
                              var255 = (Module)var46.next();
                              Module var47 = var255;
                              var22 = var47.bReturningString();
                              int var197 = var15;
                              if (var197 != 0) {
                                 int var199 = var15;
                                 String var198 = var22;
                                 var185 = var198;
                                 String var171 = var198;
                                 if (var199 == 0) {
                                    break label225;
                                 }

                                 String var200 = var171;
                                 String var172 = var200;
                                 String var201 = var172;
                                 if (var201 != null) {
                                    String var50 = var22;
                                    boolean var267 = var50.isBlank();
                                    int var203 = var15;
                                    boolean var202 = var267;
                                    var175 = var202;
                                    boolean var173 = var202;
                                    if (var203 == 0) {
                                       break;
                                    }

                                    boolean var204 = var173;
                                    boolean var174 = var204;
                                    boolean var205 = var174;
                                    if (!var205) {
                                       break label170;
                                    }
                                 }

                                 Object[] var54 = new Object[]{"Unnamed module", "module has no config name", null};
                                 ConfigLoadStatistics var53 = var16;
                                 var53.recoveryAccess_call_bReturningVoid(var54);
                              }

                              int var206 = var15;
                              if (var206 != 0) {
                                 continue;
                              }
                           }

                           String var57 = var22;
                           HashSet var56 = var18;
                           var175 = var56.add(var57);
                           break;
                        }

                        boolean var207 = var175;
                        if (var207) {
                           break;
                        }

                        Object[] var59 = new Object[]{var22, "duplicate config section name", null};
                        ConfigLoadStatistics var58 = var16;
                        var58.recoveryAccess_call_bReturningVoid(var59);
                        var208 = var15;
                     } while (var208 != 0);

                     JsonObject var23 = new JsonObject();
                     Object[] var62 = new Object[0];
                     Module var61 = var255;
                     List var63 = var61.aReturningList(var62);
                     Iterator var24 = var63.iterator();

                     label189: {
                        int var211;
                        do {
                           Iterator var64 = var24;
                           boolean var209 = var64.hasNext();
                           if (!var209) {
                              break;
                           }

                           Iterator var65 = var24;
                           SettingDefinition var25 = (SettingDefinition)var65.next();
                           Object[] var67 = new Object[]{var23, var25, var22, var16, 113383699938702L};
                           ConfigManager var66 = this;
                           var66.gReturningVoid(var67);
                           int var210 = var15;
                           if (var210 == 0) {
                              break label189;
                           }

                           var211 = var15;
                        } while (var211 != 0);

                        ArrayList var69 = var255.a;
                        var24 = var69.iterator();
                     }

                     label199: {
                        int var214;
                        do {
                           Iterator var70 = var24;
                           boolean var212 = var70.hasNext();
                           if (!var212) {
                              break;
                           }

                           Iterator var71 = var24;
                           SettingDefinition var260 = (SettingDefinition)var71.next();
                           Object[] var73 = new Object[]{var23, var260, var22, var16, 113383699938702L};
                           ConfigManager var72 = this;
                           var72.gReturningVoid(var73);
                           int var213 = var15;
                           if (var213 == 0) {
                              break label199;
                           }

                           var214 = var15;
                        } while (var214 != 0);

                        JsonObject var77 = var23;
                        String var76 = var22;
                        JsonObject var75 = var17;
                        var75.add(var76, (JsonElement)var77);
                     }

                     var215 = var15;
                  } while (var215 != 0);

                  int var217 = var15;
                  HudEditorScreen var216 = Prestige.l;
                  HudEditorScreen var177 = var216;
                  HudEditorScreen var176 = var216;
                  if (var217 != 0) {
                     HudEditorScreen var218 = var176;
                     if (var218 == null) {
                        Object[] var80 = new Object[]{"HUD", "HUD editor is not ready", null};
                        ConfigLoadStatistics var79 = var16;
                        var79.recoveryAccess_call_bReturningVoid(var80);
                        int var219 = var15;
                        if (var219 != 0) {
                           break label230;
                        }
                     }

                     HudEditorScreen var220 = Prestige.l;
                     var177 = var220;
                  }

                  Object[] var84 = new Object[0];
                  HudEditorScreen var83 = var177;
                  HudElement[] var254 = var83.aReturningArrayOfb1(var84);
                  int var256 = var254.length;
                  int var239;
                  do {
                     int var222 = var256;
                     int var221 = var257;
                     if (var221 >= var222) {
                        break;
                     }

                     label239: {
                        boolean var182;
                        HudElement var258;
                        String var259;
                        label145: {
                           label144: {
                              var258 = var254[var257];
                              Object[] var86 = new Object[0];
                              HudElement var85 = var258;
                              var259 = var85.aReturningString(var86);
                              int var223 = var15;
                              if (var223 != 0) {
                                 int var225 = var15;
                                 String var224 = var259;
                                 var185 = var224;
                                 String var178 = var224;
                                 if (var225 == 0) {
                                    break label225;
                                 }

                                 String var226 = var178;
                                 String var179 = var226;
                                 String var227 = var179;
                                 if (var227 != null) {
                                    String var89 = var259;
                                    boolean var268 = var89.isBlank();
                                    int var229 = var15;
                                    boolean var228 = var268;
                                    var182 = var228;
                                    boolean var180 = var228;
                                    if (var229 == 0) {
                                       break label145;
                                    }

                                    boolean var230 = var180;
                                    boolean var181 = var230;
                                    boolean var231 = var181;
                                    if (!var231) {
                                       break label144;
                                    }
                                 }

                                 Object[] var93 = new Object[]{"HUD", "component has no config name", null};
                                 ConfigLoadStatistics var92 = var16;
                                 var92.recoveryAccess_call_bReturningVoid(var93);
                              }

                              int var232 = var15;
                              if (var232 != 0) {
                                 break label239;
                              }
                           }

                           String var96 = var259;
                           HashSet var95 = var18;
                           boolean var233 = var95.add(var96);
                           var182 = var233;
                        }

                        boolean var234 = var182;
                        if (!var234) {
                           Object[] var99 = new Object[]{"HUD > " + var259, "duplicate config section name", null};
                           ConfigLoadStatistics var98 = var16;
                           var98.recoveryAccess_call_bReturningVoid(var99);
                           int var235 = var15;
                           if (var235 != 0) {
                              break label239;
                           }
                        }

                        try {
                           JsonObject var261;
                           label131: {
                              var261 = new JsonObject();
                              Object[] var102 = new Object[]{65274779863695L};
                              HudElement var101 = var258;
                              boolean var103 = var101.eReturningBoolean(var102);
                              Boolean var106 = var103;
                              String var105 = "Enabled";
                              JsonObject var104 = var261;
                              var104.addProperty(var105, var106);
                              Object[] var108 = new Object[0];
                              HudElement var107 = var258;
                              float var109 = var107.aReturningFloat(var108);
                              Float var112 = var109;
                              String var111 = "X";
                              JsonObject var110 = var261;
                              var110.addProperty(var111, var112);
                              Object[] var114 = new Object[0];
                              HudElement var113 = var258;
                              float var115 = var113.bReturningFloat(var114);
                              Float var118 = var115;
                              String var117 = "Y";
                              JsonObject var116 = var261;
                              var116.addProperty(var117, var118);
                              int var236 = var15;
                              if (var236 != 0) {
                                 Object[] var120 = new Object[0];
                                 HudElement var119 = var258;
                                 boolean var237 = var119.bReturningBoolean(var120);
                                 if (var237) {
                                    Object[] var123 = new Object[]{3};
                                    ConfigLoadStatistics var122 = var16;
                                    var122.recoveryAccess_call_cReturningVoid(var123);
                                    int var238 = var15;
                                    if (var238 != 0) {
                                       break label131;
                                    }
                                 }

                                 HudAlignment var125 = var258.i;
                                 String var128 = var125.name();
                                 String var127 = "RuleX";
                                 JsonObject var126 = var261;
                                 var126.addProperty(var127, var128);
                                 HudAlignment var129 = var258.j;
                                 String var132 = var129.name();
                                 String var131 = "RuleY";
                                 JsonObject var130 = var261;
                                 var130.addProperty(var131, var132);
                                 float var133 = var258.k;
                                 Float var136 = var133;
                                 String var135 = "OffX";
                                 JsonObject var134 = var261;
                                 var134.addProperty(var135, var136);
                                 float var137 = var258.l;
                                 Float var140 = var137;
                                 String var139 = "OffY";
                                 JsonObject var138 = var261;
                                 var138.addProperty(var139, var140);
                              }

                              Object[] var143 = new Object[]{7};
                              ConfigLoadStatistics var142 = var16;
                              var142.recoveryAccess_call_cReturningVoid(var143);
                           }

                           JsonObject var146 = var261;
                           String var145 = var259;
                           JsonObject var144 = var17;
                           var144.add(var145, (JsonElement)var146);
                        } catch (Throwable var250) {
                           Object[] var147 = new Object[]{var250, 98241173823267L};
                           jReturningVoid(var147);
                           String var277 = "HUD > " + var259;
                           Object[] var148 = new Object[]{var250, 134191299740519L};
                           Object[] var150 = new Object[]{var277, dReturningString(var148), var250};
                           ConfigLoadStatistics var149 = var16;
                           var149.recoveryAccess_call_bReturningVoid(var150);
                        }
                     }

                     var257++;
                     var239 = var15;
                  } while (var239 != 0);
            } catch (Throwable var251) {
               Object[] var151 = new Object[]{var251, 98241173823267L};
               jReturningVoid(var151);
               Object[] var152 = new Object[]{var251, 134191299740519L};
               Object[] var154 = new Object[]{"Config", "unexpected save failure: " + dReturningString(var152), var251};
               ConfigLoadStatistics var153 = var16;
               var153.recoveryAccess_call_bReturningVoid(var154);
            }

            try {
               JsonObject var155 = var17;
               var185 = var155.toString();
            } catch (Throwable var249) {
               Object[] var156 = new Object[]{var249, 98241173823267L};
               jReturningVoid(var156);
               Object[] var157 = new Object[]{var249, 134191299740519L};
               Object[] var159 = new Object[]{"Config", "could not serialize snapshot: " + dReturningString(var157), var249};
               ConfigLoadStatistics var158 = var16;
               var158.recoveryAccess_call_bReturningVoid(var159);
               short var269 = 1536;
               var10001 = 4799553705138519063L;
               var252 = "{}";
               break label226;
            }
         }

         try {
            var252 = var185;
         } catch (Throwable var248) {
            Object[] var262 = new Object[]{var248, 98241173823267L};
            jReturningVoid(var262);
            Object[] var263 = new Object[]{var248, 134191299740519L};
            Object[] var265 = new Object[]{"Config", "could not serialize snapshot: " + dReturningString(var263), var248};
            ConfigLoadStatistics var264 = var16;
            var264.recoveryAccess_call_bReturningVoid(var265);
            short var270 = 1536;
            var10001 = 4799553705138519063L;
            var252 = "{}";
         }
      }

      label112: {
         Object[] var161 = new Object[]{61181788346148L};
         ConfigLoadStatistics var160 = var16;
         boolean var240 = var160.recoveryAccess_call_aReturningBoolean(var161);
         if (var240) {
            int var242 = var15;
            String var241 = this.d;
            String var189 = var241;
            String var187 = var241;
            if (var242 != 0) {
               String var243 = var187;
               String var188 = var243;
               String var244 = var188;
               if (var244 != null) {
                  Object[] var165 = new Object[]{"Config", "save was aborted; the previous complete snapshot was kept", null};
                  ConfigLoadStatistics var164 = var16;
                  var164.recoveryRecordSetting(var165);
                  var252 = this.d;
                  int var245 = var15;
                  if (var245 != 0) {
                     break label112;
                  }
               }

               Object[] var167 = new Object[]{"Config", "save was aborted; no complete fallback snapshot exists", null};
               ConfigLoadStatistics var166 = var16;
               var166.recoveryAccess_call_bReturningVoid(var167);
               short var271 = 13105;
               var10001 = 6567507445281966453L;
               String var246 = "{}";
               var189 = var246;
            }

            var252 = var189;
            int var247 = var15;
            if (var247 != 0) {
               break label112;
            }
         }

         this.d = var252;
      }

      Object[] var170 = new Object[]{var16, 35466549388854L};
      iReturningVoid(var170);
      return var252;
   }

   @NativeMarker
   public void a(String var1) {
      Object var140;

      boolean var143;
      dev.zprestige.prestige.client.management.ConfigLoadStatistics var144;

      long var10001 = 129391891872817L ^ 98440477220040L;
      var10001 = 129391891872817L ^ 26328909535451L;
      var10001 = 129391891872817L ^ 67958990228257L;
      var10001 = 129391891872817L ^ 17204514963286L;
      var10001 = 129391891872817L ^ 94488589736455L;
      var10001 = 129391891872817L ^ 27345544376158L;
      var10001 = 129391891872817L ^ 49443319898898L;
      var10001 = 129391891872817L ^ 46294944303512L;
      var10001 = 129391891872817L ^ 36090652378054L;
      var10001 = 129391891872817L ^ 74393808156799L;
      int var10000 = Event.bReturningInt();
      ConfigLoadStatistics var25 = new ConfigLoadStatistics("load");
      int var24 = var10000;
      boolean var124 = false ;

      label288: {
         label310: {
            label311: {
               label285: {
                  try {
                     var124 = true;
                     Object[] var37 = new Object[]{var1, var25, 105228921058729L};
                     JsonObject var26 = this.aReturningJsonObject(var37);
                     if (var24 != 0) {
                        var124 = false;
                        return;
                     }

                     if (var26 == null) {
                        var124 = false;
                        break label311;
                     }

                     if (Prestige.d == null) {
                        Object[] var43 = new Object[]{"Config", "module manager is not ready", null};
                        var25.recoveryAccess_call_bReturningVoid(var43);
                        var124 = false;
                        break label310;
                     }

                     HashSet var27 = new HashSet();
                     String var48 = "Menu";
                     var27.add(var48);
                     ArrayList var28 = new ArrayList();
                     IdentityHashMap var49 = new IdentityHashMap();
                     Set var29 = Collections.newSetFromMap(var49);
                     Object[] var51 = new Object[]{var26, var29, var25, 120330030224239L};
                     this.aReturningVoid(var51);
                     Object[] var53 = new Object[]{var26, var25, 48557028368633L};
                     this.bReturningVoid(var53);
                     ModuleManager var54 = Prestige.d;
                     List var55 = var54.aReturningVoid();
                     Iterator var30 = var55.iterator();

                     label276: {
                        while (true) {
                           if (var30.hasNext()) {
                              Module var31 = (Module)var30.next();
                              String var32 = var31.bReturningString();
                              var140 = var32;
                              if (var24 != 0) {
                                 break;
                              }

                              if (var24 == 0) {
                                 if (var32 == null) {
                                    continue;
                                 }

                                 var140 = var32;
                              }

                              Object var61 = var140;
                              boolean var141 = ((String)var61).isBlank();
                              if (var24 == 0) {
                                 if (var141 && var24 == 0) {
                                    continue;
                                 }

                                 var141 = var27.add(var32);
                              }

                              if (!var141) {
                                 Object[] var67 = new Object[]{var32, "duplicate module config name; section was skipped", null};
                                 var25.recoveryAccess_call_bReturningVoid(var67);
                                 if (var24 == 0) {
                                    continue;
                                 }
                              }

                              Object[] var70 = new Object[]{var26, var31, var32, var29, var28, var25, 79579481421584L};
                              this.cReturningVoid(var70);
                              if (var24 == 0) {
                                 continue;
                              }
                           }

                           label261: {
                              label297: {
                                 HudEditorScreen var142 = Prestige.l;
                                 if (var24 == 0) {
                                    if (Prestige.l == null) {
                                       Object[] var73 = new Object[]{"HUD", "HUD editor is not ready; HUD layout was skipped", null};
                                       var25.recoveryRecordSetting(var73);
                                       if (var24 == 0) {
                                          break label297;
                                       }
                                    }

                                    var142 = Prestige.l;
                                 }

                                 Object[] var77 = new Object[0];
                                 HudEditorScreen var76 = var142;

                                 for (HudElement var33 : var76.aReturningArrayOfb1(var77)) {
                                    Object[] var79 = new Object[0];
                                    String var34 = var33.aReturningString(var79);
                                    if (var24 != 0) {
                                       break label261;
                                    }

                                    label299: {
                                       label249: {
                                          label248: {
                                             if (var24 == 0) {
                                                if (var34 != null) {
                                                   var143 = var34.isBlank();
                                                   if (var24 != 0) {
                                                      break label249;
                                                   }

                                                   if (!var143) {
                                                      break label248;
                                                   }
                                                }

                                                Object[] var86 = new Object[]{"HUD", "component has no config name", null};
                                                var25.recoveryAccess_call_bReturningVoid(var86);
                                             }

                                             if (var24 == 0) {
                                                break label299;
                                             }
                                          }

                                          var143 = var27.add(var34);
                                       }

                                       if (!var143) {
                                          Object[] var92 = new Object[]{"HUD > " + var34, "duplicate config section name; section was skipped", null};
                                          var25.recoveryAccess_call_bReturningVoid(var92);
                                          if (var24 == 0) {
                                             break label299;
                                          }
                                       }

                                       Object[] var95 = new Object[]{var26, var33, var34, var25, 93997091766263L};
                                       this.eReturningVoid(var95);
                                    }

                                    if (var24 != 0) {
                                       break;
                                    }
                                 }
                              }

                              Object[] var98 = new Object[]{var26, var27, "", "module or HUD section", var25, 59404988859470L};
                              this.hReturningVoid(var98);
                           }

                           var30 = var28.iterator();
                           if (!var30.hasNext()) {
                              break label276;
                           }

                           var140 = var30.next();
                           break;
                        }

                        while (true) {
                           ConfigSettingEntry var129 = (ConfigSettingEntry)var140;
                           JsonElement var154 = var129.recoveryAccess_read_aq();
                           Module var10002 = var129.recoveryAccess_read_ao();
                           String var10003 = var129.recoveryAccess_read_ap();
                           boolean var10004 = var129.recoveryAccess_read_ar();
                           Object[] var10008 = new Object[]{null, null, null, null, var25, 108148493690090L};
                           var10008[3] = var10004;
                           var10008[2] = var10003;
                           var10008[1] = var10002;
                           var10008[0] = var154;
                           Object[] var103 = var10008;
                           this.dReturningVoid(var103);
                           if (var24 != 0) {
                              var124 = false;
                              return;
                           }

                           if (var24 != 0 || !var30.hasNext()) {
                              break;
                           }

                           var140 = var30.next();
                        }
                     }

                     var144 = var25;
                     if (var24 != 0) {
                        var124 = false;
                        break label285;
                     }

                     if (var25.recoveryAccess_read_c() == 0) {
                        Object[] var107 = new Object[]{"Config", "no recognized config sections were found", null};
                        var25.recoveryAccess_call_bReturningVoid(var107);
                        var124 = false;
                     } else {
                        var124 = false;
                  } catch (Throwable var125) {
                     Object[] var112 = new Object[]{var125, 98241173823267L};
                     jReturningVoid(var112);
                     Object[] var113 = new Object[]{var125, 134191299740519L};
                     Object[] var115 = new Object[]{"Config", "unexpected load failure: " + dReturningString(var113), var125};
                     var25.recoveryAccess_call_bReturningVoid(var115);
                     var124 = false;
                     break label288;
                  } finally {
                     if (var124) {
                        Object[] var120 = new Object[0];
                        this.e = var25.recoveryAccess_call_aReturningString(var120);
                        Object[] var121 = new Object[]{var25, 35466549388854L};
                        iReturningVoid(var121);
                     }
                  }

                  Object[] var110 = new Object[0];
                  this.e = var25.recoveryAccess_call_aReturningString(var110);
                  var144 = var25;
               }

               Object[] var111 = new Object[]{var144, 35466549388854L};
               iReturningVoid(var111);
               return;
            }

            Object[] var40 = new Object[0];
            this.e = var25.recoveryAccess_call_aReturningString(var40);
            Object[] var41 = new Object[]{var25, 35466549388854L};
            iReturningVoid(var41);
            return;
         }

         Object[] var45 = new Object[0];
         this.e = var25.recoveryAccess_call_aReturningString(var45);
         Object[] var46 = new Object[]{var25, 35466549388854L};
         iReturningVoid(var46);
         return;
      }

      Object[] var117 = new Object[0];
      this.e = var25.recoveryAccess_call_aReturningString(var117);
      Object[] var118 = new Object[]{var25, 35466549388854L};
      iReturningVoid(var118);
   }

   @NativeMarker
   public String bReturningString() {
      String var1 = this.e;
      this.e = null;
      return var1;
   }

   
   
   private void aReturningVoid(Object[] var1) {
      JsonObject var5 = (JsonObject)var1[0];
      Set var2 = (Set)var1[1];
      ConfigLoadStatistics var6 = (ConfigLoadStatistics)var1[2];
      long var3 = (Long)var1[3];
      var3 = 94490381836703L ^ var3;
      long var7 = var3 ^ 27312319800213L;
      long var9 = var3 ^ 81761612384936L;
      long var11 = var3 ^ 139546865151185L;
      long var13 = var3 ^ 73165268136343L;
      long var15 = var3 ^ 121334956418367L;
      long var17 = var3 ^ 107585899687379L;
      HashSet var20 = new HashSet();
      short var10001 = 8814;
      long var10002 = 2509153872139659914L ^ var3;
      String var33 = "Menu";
      HashSet var32 = var20;
      var32.add(var33);
      int var10000 = Event.cReturningInt();
      ModuleManager var34 = Prestige.d;
      List var35 = var34.aReturningVoid();
      Iterator var21 = var35.iterator();
      int var19 = var10000;

      while (true) {
         Iterator var36 = var21;
         boolean var113 = var36.hasNext();
         if (!var113) {
            break;
         }

         Iterator var37 = var21;
         Module var22 = (Module)var37.next();
         Module var38 = var22;
         String var23 = var38.bReturningString();
         int var115 = var19;
         String var114 = var23;
         String var94 = var114;
         String var93 = var114;
         if (var115 != 0) {
            String var116 = var93;
            if (var116 == null) {
               continue;
            }

            var94 = var23;
         }

         String var40 = var94;
         short var160 = ((short)((var40.isBlank()) ? 1 : 0));
         int var118 = var19;
         boolean var117 = dev.prestige.recovery.SourceSupport.asBoolean(var160);
         boolean var96 = var117;
         boolean var95 = var117;
         if (var118 != 0) {
            boolean var119 = var95;
            if (var119) {
               continue;
            }

            String var43 = var23;
            HashSet var42 = var20;
            var96 = var42.add(var43);
         }

         boolean var120 = var96;
         if (!var120) {
            int var121 = var19;
            if (var121 != 0) {
               continue;
            }
         }

         String var46 = var23;
         JsonObject var45 = var5;
         JsonElement var24 = var45.get(var46);
         int var123 = var19;
         JsonElement var122 = var24;
         JsonElement var98 = var122;
         JsonElement var97 = var122;
         if (var123 != 0) {
            JsonElement var124 = var97;
            if (var124 == null) {
               continue;
            }

            var98 = var24;
         }

         int var126 = var19;
         JsonElement var125 = var98;
         JsonElement var100 = var125;
         JsonElement var99 = var125;
         if (var126 != 0) {
            JsonElement var48 = var99;
            boolean var127 = var48.isJsonObject();
            if (!var127) {
               int var128 = var19;
               if (var128 != 0) {
                  continue;
               }
            }

            var100 = var24;
         }

         JsonElement var51 = var100;
         JsonObject var25 = var51.getAsJsonObject();
         var10001 = 19981;
         var10002 = 8189256613348165311L ^ var3;
         String var53 = "Enabled";
         JsonObject var52 = var25;
         var160 = ((short)((var52.has(var53)) ? 1 : 0));
         int var130 = var19;
         boolean var129 = ((((int)(var160) & 1) != 0));
         boolean var102 = var129;
         boolean var101 = var129;
         if (var130 != 0) {
            boolean var131 = var101;
            if (!var131) {
               int var132 = var19;
               if (var132 != 0) {
                  continue;
               }
            }

            try {
               short var172 = 19981;
               long var10003 = 8189256613348165311L ^ var3;
               String var57 = "Enabled";
               JsonObject var56 = var25;
               Object[] var59 = new Object[]{var56.get(var57), var11};
               ConfigManager var58 = this;
               Object[] var60 = new Object[]{var58.aReturningString(var59), var7};
               var102 = SettingValueCodec.aReturningBoolean(var60);
            } catch (Throwable var152) {
               Object[] var61 = new Object[]{var152, var17};
               jReturningVoid(var61);
               continue;
            }
         }

         boolean var26;
         try {
            var26 = var102;
         } catch (Throwable var151) {
            Object[] var155 = new Object[]{var151, var17};
            jReturningVoid(var155);
            continue;
         }

         int var134 = var19;
         boolean var133 = var26;
         boolean var105 = var133;
         boolean var104 = var133;
         if (var134 != 0) {
            boolean var135 = var104;
            if (var135) {
               int var136 = var19;
               if (var136 != 0) {
                  continue;
               }
            }

            try {
               Module var64 = var22;
               var105 = var64.aReturningBoolean();
            } catch (Throwable var150) {
               Object[] var65 = new Object[]{var150, var17};
               jReturningVoid(var65);
               short var173 = 11175;
               long var179 = 5100044732397658987L ^ var3;
               String var166 = var23 + " > Enabled";
               Object[] var66 = new Object[]{var150, var13};
               String var174 = dReturningString(var66);
               short var180 = 3115;
               long var10004 = 4485560208654894298L ^ var3;
               Object[] var68 = new Object[]{var166, "could not inspect current module state: " + var174, var150};
               ConfigLoadStatistics var67 = var6;
               var67.recoveryAccess_call_bReturningVoid(var68);
               continue;
            }
         }

         boolean var27;
         try {
            var27 = var105;
         } catch (Throwable var149) {
            Object[] var156 = new Object[]{var149, var17};
            jReturningVoid(var156);
            short var175 = 11175;
            long var181 = 5100044732397658987L ^ var3;
            String var167 = var23 + " > Enabled";
            Object[] var157 = new Object[]{var149, var13};
            String var176 = dReturningString(var157);
            short var182 = 3115;
            long var184 = 4485560208654894298L ^ var3;
            Object[] var159 = new Object[]{var167, "could not inspect current module state: " + var176, var149};
            ConfigLoadStatistics var158 = var6;
            var158.recoveryAccess_call_bReturningVoid(var159);
            continue;
         }

         int var138 = var19;
         boolean var137 = var27;
         boolean var107 = var137;
         if (var138 != 0) {
            boolean var139 = var107;
            if (!var139) {
               int var140 = var19;
               if (var140 != 0) {
                  continue;
               }
            }

            Module var72 = var22;
            Set var71 = var2;
            boolean var108 = var71.add(var72);
         }

         var10001 = 11175;
         var10002 = 5100044732397658987L ^ var3;
         String var28 = var23 + " > Enabled";

         try {
            label142: {
               Object[] var74 = new Object[]{var9};
               Module var73 = var22;
               var73.aReturningVoid(var74);
               Module var75 = var22;
               var160 = ((short)((var75.aReturningBoolean()) ? 1 : 0));
               int var142 = var19;
               boolean var141 = ((((int)(var160) & 1) != 0));
               boolean var110 = var141;
               boolean var109 = var141;
               if (var142 != 0) {
                  boolean var143 = var109;
                  if (var143) {
                     Object[] var78 = new Object[]{var9};
                     Module var77 = var22;
                     var77.aReturningVoid(var78);
                  }

                  Module var80 = var22;
                  var110 = var80.aReturningBoolean();
               }

               boolean var144 = var110;
               if (!var144) {
                  Object[] var82 = new Object[]{1};
                  ConfigLoadStatistics var81 = var6;
                  var81.recoveryAccess_call_cReturningVoid(var82);
                  int var145 = var19;
                  if (var145 != 0) {
                     break label142;
                  }
               }

               short var178 = 29656;
               long var183 = 2590600535203347240L ^ var3;
               Object[] var85 = new Object[]{var28, "module changed its own state while being disabled", null};
               ConfigLoadStatistics var84 = var6;
               var84.recoveryRecordSetting(var85);
         } catch (Throwable var153) {
            Object[] var87 = new Object[]{var153, var17};
            jReturningVoid(var87);
            Object[] var10006 = new Object[]{null, null, var153, var15};
            var10006[1] = true;
            var10006[0] = var22;
            Object[] var89 = var10006;
            ConfigManager var88 = this;
            boolean var30 = var88.aReturningBoolean(var89);
            boolean var146 = var30;
            String var112;
            if (var146) {
               var160 = 9312;
               long var170 = 5623452789476863199L ^ var3;
               String var147 = "disable lifecycle failed; previous state was restored";
               var112 = var147;
            } else {
               var160 = 30257;
               long var169 = 3950511240656027338L ^ var3;
               var112 = "disable lifecycle failed; state may be inconsistent";
            }

            String var31 = var112;
            Object[] var92 = new Object[]{var28, var31, var153};
            ConfigLoadStatistics var91 = var6;
            var91.recoveryAccess_call_bReturningVoid(var92);
         }

         int var148 = var19;
         if (var148 == 0) {
            break;
         }
      }
   }

   private void bReturningVoid(Object[] var1) {
      JsonObject var5 = (JsonObject)var1[0];
      ConfigLoadStatistics var2 = (ConfigLoadStatistics)var1[1];
      long var3 = (Long)var1[2];
      var3 = 94490381836703L ^ var3;
      long var6 = var3 ^ 75798581707470L;
      long var8 = var3 ^ 52879471471978L;
      long var10 = var3 ^ 87817527739688L;
      int var12 = Event.cReturningInt();
      int var39 = var12;
      JsonObject var38 = var5;
      JsonObject var37 = var38;
      JsonObject var36 = var38;
      if (var39 != 0) {
         short var10001 = 8814;
         long var10002 = 2509084976364280092L ^ var3;
         String var18 = "Menu";
         JsonObject var17 = var36;
         boolean var40 = var17.has(var18);
         if (!var40) {
            return;
         }

         var2.recoveryAccess_postIncrement_c();
         short var47 = 8814;
         long var10003 = 2509084976364280092L ^ var3;
         String var22 = "Menu";
         JsonObject var21 = var5;
         JsonElement var46 = var21.get(var22);
         short var48 = 8814;
         var10003 = 2509084976364280092L ^ var3;
         Object[] var24 = new Object[]{var46, "Menu", var2, var6};
         ConfigManager var23 = this;
         var37 = var23.bReturningJsonObject(var24);
      }

      JsonObject var13 = var37;
      JsonObject var41 = var13;
      if (var41 != null) {
         HashSet var14 = new HashSet();
         ModuleManager var10000 = Prestige.d;
         Object[] var27 = new Object[0];
         ModuleManager var26 = var10000;
         ArrayList var28 = var26.aReturningMenuSettings(var27).a;
         Iterator var15 = var28.iterator();

         while (true) {
            Iterator var29 = var15;
            boolean var42 = var29.hasNext();
            if (var42) {
               Iterator var30 = var15;
               SettingDefinition var16 = (SettingDefinition)var30.next();
               short var50 = 8814;
               long var10004 = 2509084976364280092L ^ var3;
               Object[] var32 = new Object[]{var13, var16, "Menu", var14, var2, var8};
               ConfigManager var31 = this;
               var31.fReturningVoid(var32);
               int var43 = var12;
               if (var43 == 0) {
                  break;
               }

               int var44 = var12;
               if (var44 != 0) {
                  continue;
               }
            }

            short var51 = 8814;
            long var52 = 2509084976364280092L ^ var3;
            short var53 = 1490;
            long var10005 = 4413847314103107231L ^ var3;
            Object[] var35 = new Object[]{var13, var14, "Menu", "setting", var2, var10};
            ConfigManager var34 = this;
            var34.hReturningVoid(var35);
            break;
         }
      }
   }

   
   private void cReturningVoid(Object[] var1) {
      JsonObject var4 = (JsonObject)var1[0];
      Module var9 = (Module)var1[1];
      String var2 = (String)var1[2];
      Set var6 = (Set)var1[3];
      List var3 = (List)var1[4];
      ConfigLoadStatistics var5 = (ConfigLoadStatistics)var1[5];
      long var7 = (Long)var1[6];
      var7 = 94490381836703L ^ var7;
      long var10 = var7 ^ 35979500737831L;
      long var12 = var7 ^ 92766676269699L;
      long var14 = var7 ^ 47929794368193L;
      int var16 = Event.bReturningInt();
      int var74 = var16;
      JsonObject var73 = var4;
      JsonObject var65 = var73;
      JsonObject var64 = var73;
      if (var74 == 0) {
         String var23 = var2;
         JsonObject var22 = var64;
         boolean var75 = var22.has(var23);
         if (!var75) {
            return;
         }

         var5.recoveryAccess_postIncrement_c();
         String var27 = var2;
         JsonObject var26 = var4;
         Object[] var29 = new Object[]{var26.get(var27), var2, var5, var10};
         ConfigManager var28 = this;
         var65 = var28.bReturningJsonObject(var29);
      }

      JsonObject var17 = var65;
      JsonObject var76 = var17;
      if (var76 != null) {
         HashSet var18 = new HashSet();
         byte var19 = 0;
         Object[] var32 = new Object[0];
         Module var31 = var9;
         List var33 = var31.aReturningList(var32);
         Iterator var20 = var33.iterator();

         label85: {
            boolean var68;
            while (true) {
               Iterator var34 = var20;
               boolean var77 = var34.hasNext();
               if (var77) {
                  Iterator var35 = var20;
                  SettingDefinition var21 = (SettingDefinition)var35.next();
                  int var78 = var16;
                  if (var78 == 0) {
                     short var10000 = 19981;
                     long var10001 = 8189286368983081664L ^ var7;
                     SettingDefinition var36 = var21;
                     String var38 = var36.aReturningString();
                     String var37 = "Enabled";
                     boolean var100 = var37.equals(var38);
                     int var80 = var16;
                     boolean var79 = var100;
                     var68 = var79;
                     boolean var66 = var79;
                     if (var80 != 0) {
                        break;
                     }

                     boolean var81 = var66;
                     boolean var67 = var81;
                     boolean var82 = var67;
                     if (var82) {
                        var19 = 1;
                        short var101 = 19981;
                        long var10002 = 8189286368983081664L ^ var7;
                        String var42 = "Enabled";
                        HashSet var41 = var18;
                        var41.add(var42);
                        int var83 = var16;
                        if (var83 == 0) {
                           continue;
                        }
                     }

                     Object[] var44 = new Object[]{var17, var21, var2, var18, var5, var12};
                     ConfigManager var43 = this;
                     var43.fReturningVoid(var44);
                     int var84 = var16;
                     if (var84 == 0) {
                        continue;
                     }
                  } else {
                     int var99 = var16;
                     if (var99 == 0) {
                        continue;
                     }
                  }
               }

               ArrayList var45 = var9.a;
               var20 = var45.iterator();
               Iterator var46 = var20;
               var68 = var46.hasNext();
               break;
            }

            while (true) {
               boolean var85 = var68;
               if (!var85) {
                  break;
               }

               Iterator var47 = var20;
               SettingDefinition var97 = (SettingDefinition)var47.next();
               Object[] var49 = new Object[]{var17, var97, var2, var18, var5, var12};
               ConfigManager var48 = this;
               var48.fReturningVoid(var49);
               int var86 = var16;
               if (var86 != 0) {
                  break label85;
               }

               int var87 = var16;
               if (var87 != 0) {
                  break;
               }

               Iterator var98 = var20;
               var68 = var98.hasNext();
            }

            short var10004 = 25549;
            long var10005 = 7737514012812103493L ^ var7;
            Object[] var52 = new Object[]{var17, var18, var2, "setting", var5, var14};
            ConfigManager var51 = this;
            var51.hReturningVoid(var52);
         }

         int var89 = var16;
         byte var88 = var19;
         byte var70 = var88;
         byte var69 = var88;
         if (var89 == 0) {
            byte var90 = var69;
            if (var90 == 0) {
               return;
            }

            short var102 = 19981;
            long var103 = 8189286368983081664L ^ var7;
            String var55 = "Enabled";
            JsonObject var54 = var17;
            byte var91 = ((byte)((var54.has(var55)) ? 1 : 0));
            var70 = var91;
         }

         int var93 = var16;
         byte var92 = var70;
         byte var71 = var92;
         if (var93 == 0) {
            byte var94 = var71;
            if (var94 != 0) {
               short var10006 = 19981;
               long var10007 = 8189286368983081664L ^ var7;
               String var59 = "Enabled";
               JsonObject var58 = var17;
               JsonElement var104 = var58.get(var59);
               Module var61 = var9;
               Set var60 = var6;
               ConfigSettingEntry var63 = new ConfigSettingEntry(var9, var2, var104, var60.contains(var61));
               List var62 = var3;
               boolean var95 = var62.add(var63);
            }
         }
      }
   }

   private void dReturningVoid(Object[] var1) {
      JsonElement var6 = (JsonElement)var1[0];
      Module var8 = (Module)var1[1];
      String var2 = (String)var1[2];
      boolean var5 = (Boolean)var1[3];
      ConfigLoadStatistics var7 = (ConfigLoadStatistics)var1[4];
      long var3 = (Long)var1[5];
      var3 = 94490381836703L ^ var3;
      long var9 = var3 ^ 26370715882512L;
      long var11 = var3 ^ 76348813311277L;
      long var13 = var3 ^ 100054480416591L;
      long var15 = var3 ^ 125095308303188L;
      long var17 = var3 ^ 107162432983738L;
      long var19 = var3 ^ 85383176554002L;
      long var21 = var3 ^ 122000818100822L;
      int var10000 = Event.bReturningInt();
      short var10002 = 11175;
      long var10003 = 5100028084096308462L ^ var3;
      String var24 = var2 + " > Enabled";
      int var23 = var10000;
      short var89 = ((short)((var5) ? 1 : 0));
      if (var23 != 0) {
         boolean var25;
         boolean var26;
         label94: {
            try {
               var25 = dev.prestige.recovery.SourceSupport.asBoolean(var89);
               var26 = var8.aReturningBoolean();
               var89 = ((short)((var25) ? 1 : 0));
               if (var23 != 0) {
                  break label94;
               }

               if (var25 == var26) {
                  Object[] var38 = new Object[]{1};
                  var7.recoveryAccess_call_cReturningVoid(var38);
                  return;
            } catch (Throwable var72) {
               Object[] var74 = new Object[]{var72, var21};
               jReturningVoid(var74);
               Object[] var79 = new Object[]{var72, var19};
               Object[] var84 = new Object[]{var24, dReturningString(var79), var72};
               var7.recoveryAccess_call_bReturningVoid(var84);
               return;
            }

            try {
               var89 = ((short)((var25) ? 1 : 0));
            } catch (Throwable var70) {
               Object[] var75 = new Object[]{var70, var21};
               jReturningVoid(var75);
               Object[] var80 = new Object[]{var70, var19};
               Object[] var85 = new Object[]{var24, dReturningString(var80), var70};
               var7.recoveryAccess_call_bReturningVoid(var85);
               return;
            }
         }

         label77: {
            try {
               if (var23 != 0) {
                  break label77;
               }

               if (((var89) != 0)) {
                  Object[] var41 = new Object[]{var13};
                  var89 = ((short)((var8.bReturningBoolean(var41)) ? 1 : 0));
                  if (var23 != 0) {
                     break label77;
                  }

                  if (!((var89) != 0)) {
                     var10002 = 21350;
                     var10003 = 5290758810744745025L ^ var3;
                     Object[] var45 = new Object[]{var24, "activation is blocked for downloaded configs; settings were still loaded", null};
                     var7.recoveryRecordSetting(var45);
                     return;
                  }
            } catch (Throwable var69) {
               Object[] var76 = new Object[]{var69, var21};
               jReturningVoid(var76);
               Object[] var81 = new Object[]{var69, var19};
               Object[] var86 = new Object[]{var24, dReturningString(var81), var69};
               var7.recoveryAccess_call_bReturningVoid(var86);
               return;
            }

            try {
               var89 = ((short)((var26) ? 1 : 0));
            } catch (Throwable var68) {
               Object[] var77 = new Object[]{var68, var21};
               jReturningVoid(var77);
               Object[] var82 = new Object[]{var68, var19};
               Object[] var87 = new Object[]{var24, dReturningString(var82), var68};
               var7.recoveryAccess_call_bReturningVoid(var87);
               return;
            }
         }

         try {
            boolean var27 = ((((int)(var89) & 1) != 0));

            try {
               label61: {
                  Object[] var47 = new Object[]{var11};
                  var8.aReturningVoid(var47);
                  if (var23 == 0) {
                     if (var8.aReturningBoolean() != var25) {
                        break label61;
                     }

                     Object[] var51 = new Object[]{1};
                     var7.recoveryAccess_call_cReturningVoid(var51);
                  }

                  if (var23 == 0) {
                     return;
                  }
               }

               var10002 = 21060;
               var10003 = 5180417376436153645L ^ var3;
               Object[] var54 = new Object[]{var24, "module changed its own state during activation", null};
               var7.recoveryRecordSetting(var54);
            } catch (Throwable var66) {
               Object[] var56 = new Object[]{var66, var21};
               jReturningVoid(var56);
               Object[] var10006 = new Object[]{null, null, var66, var17};
               var10006[1] = var27;
               var10006[0] = var8;
               Object[] var58 = var10006;
               boolean var29 = this.aReturningBoolean(var58);
               String var92;
               if (var29) {
                  var89 = 434;
                  long var94 = 8246899722682285794L ^ var3;
                  var92 = "module lifecycle failed; previous state was restored";
               } else {
                  var89 = 6006;
                  long var10001 = 4268770314586269741L ^ var3;
                  var92 = "module lifecycle failed; state may be inconsistent";
               }

               String var30 = var92;
               Object[] var61 = new Object[]{var24, var30, var66};
               var7.recoveryAccess_call_bReturningVoid(var61);
         } catch (Throwable var67) {
            Object[] var78 = new Object[]{var67, var21};
            jReturningVoid(var78);
            Object[] var83 = new Object[]{var67, var19};
            Object[] var88 = new Object[]{var24, dReturningString(var83), var67};
            var7.recoveryAccess_call_bReturningVoid(var88);
         }
      } else if (!var5) {
         label83:
         try {
            Object[] var33 = new Object[]{var6, var15};
            Object[] var34 = new Object[]{this.aReturningString(var33), var9};
            var89 = ((short)((SettingValueCodec.aReturningBoolean(var34)) ? 1 : 0));
            break label83;
         } catch (Throwable var71) {
            Object[] var62 = new Object[]{var71, var21};
            jReturningVoid(var62);
            Object[] var63 = new Object[]{var71, var19};
            Object[] var65 = new Object[]{var24, dReturningString(var63), var71};
            var7.recoveryAccess_call_bReturningVoid(var65);
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      Module var3 = (Module)var1[0];
      boolean var2 = (Boolean)var1[1];
      Throwable var6 = (Throwable)var1[2];
      long var4 = (Long)var1[3];
      var4 = 94490381836703L ^ var4;
      long var7 = var4 ^ 125304135863816L;
      long var9 = var4 ^ 99451914447219L;
      int var11 = Event.cReturningInt();

      try {
         Module var13 = var3;
         boolean var10000 = var13.aReturningBoolean();
         int var33 = var11;
         boolean var32 = var2;
         boolean var31 = var10000;
         boolean var26 = var31;
         boolean var27 = var32;
         boolean var23 = var31;
         boolean var24 = var32;
         if (var33 != 0) {
            boolean var35 = var24;
            boolean var34 = var23;
            if (var34 != var35) {
               Object[] var16 = new Object[]{var7};
               Module var15 = var3;
               var15.aReturningVoid(var16);
            }

            Module var18 = var3;
            var10000 = var18.aReturningBoolean();
            int var37 = var11;
            boolean var36 = var10000;
            boolean var28 = var36;
            boolean var25 = var36;
            if (var37 == 0) {
               return var28;
            }

            boolean var39 = var2;
            boolean var38 = var25;
            var26 = var38;
            var27 = var39;
         }

         boolean var41 = var27;
         boolean var40 = var26;
         return var40 == var41;
      } catch (Throwable var43) {
         Object[] var20 = new Object[]{var43, var9};
         jReturningVoid(var20);
         Throwable var21 = var6;
         var21.addSuppressed(var43);
         return false;
      }
   }

   
   
   private void eReturningVoid(Object[] var1) {
      JsonObject var7 = (JsonObject)var1[0];
      HudElement var6 = (HudElement)var1[1];
      String var2 = (String)var1[2];
      ConfigLoadStatistics var3 = (ConfigLoadStatistics)var1[3];
      long var4 = (Long)var1[4];
      var4 = 94490381836703L ^ var4;
      long var8 = var4 ^ 36124012056333L;
      long var10 = var4 ^ 115544692177687L;
      long var12 = var4 ^ 77958666846281L;
      long var14 = var4 ^ 13841804800781L;
      long var16 = var4 ^ 47918057421025L;
      long var18 = var4 ^ 59968139368998L;
      long var20 = var4 ^ 10301006335235L;
      long var22 = var4 ^ 67778017451456L;
      long var24 = var4 ^ 53521447347914L;
      long var26 = var4 ^ 98357749576971L;
      long var28 = var4 ^ 134720208215311L;
      long var30 = var4 ^ 15385232889611L;
      long var32 = var4 ^ 79951174611900L;
      long var34 = var4 ^ 98769897242955L;
      long var36 = var4 ^ 65768279921895L;
      int var38 = Event.cReturningInt();
      int var218 = var38;
      if (var218 != 0) {
         String var51 = var2;
         JsonObject var50 = var7;
         boolean var219 = var50.has(var51);
         if (!var219) {
            return;
         }

         var3.recoveryAccess_postIncrement_c();
      }

      short var10001 = 13823;
      long var10002 = 3689778060981965242L ^ var4;
      String var39 = "HUD > " + var2;
      String var55 = var2;
      JsonObject var54 = var7;
      Object[] var57 = new Object[]{var54.get(var55), var39, var3, var22};
      ConfigManager var56 = this;
      JsonObject var40 = var56.bReturningJsonObject(var57);
      JsonObject var220 = var40;
      if (var220 != null) {
         boolean var201;
         label172: {
            boolean var200;
            label171: {
               label178: {
                  short var10000 = 147;
                  long var290 = 5519676479340389585L ^ var4;
                  short var10003 = 17315;
                  long var10004 = 2991866119402842065L ^ var4;
                  short var350 = 23766;
                  long var10005 = 7465238051290806404L ^ var4;
                  short var353 = 2907;
                  long var10006 = 5795074970675293973L ^ var4;
                  short var356 = 10134;
                  long var10007 = 7067988776297759697L ^ var4;
                  short var359 = 18004;
                  long var10008 = 4469195555366429298L ^ var4;
                  String var66 = "OffY";
                  String var65 = "OffX";
                  String var64 = "RuleY";
                  String var63 = "RuleX";
                  String var62 = "Anchor";
                  String var61 = "Y";
                  String var60 = "X";
                  String var59 = "Enabled";
                  Set var41 = Set.of(var59, var60, var61, var62, var63, var64, var65, var66);
                  short var351 = 25549;
                  var10005 = 7737525979353892770L ^ var4;
                  Object[] var68 = new Object[]{var40, var41, var39, "setting", var3, var18};
                  ConfigManager var67 = this;
                  var67.hReturningVoid(var68);
                  var10001 = 28063;
                  var10002 = 364983240336656801L ^ var4;
                  String var70 = "RuleX";
                  JsonObject var69 = var40;
                  boolean var285 = var69.has(var70);
                  int var222 = var38;
                  boolean var221 = var285;
                  boolean var194 = var221;
                  boolean var193 = var221;
                  if (var222 != 0) {
                     boolean var223 = var193;
                     if (!var223) {
                        break label178;
                     }

                     var10001 = 18615;
                     var10002 = 1400520412917329121L ^ var4;
                     String var73 = "RuleY";
                     JsonObject var72 = var40;
                     boolean var224 = var72.has(var73);
                     var194 = var224;
                  }

                  int var226 = var38;
                  boolean var225 = var194;
                  boolean var196 = var225;
                  boolean var195 = var225;
                  if (var226 != 0) {
                     boolean var227 = var195;
                     if (!var227) {
                        break label178;
                     }

                     var10001 = 26010;
                     var10002 = 2248995120048783794L ^ var4;
                     String var77 = "OffX";
                     JsonObject var76 = var40;
                     boolean var228 = var76.has(var77);
                     var196 = var228;
                  }

                  int var230 = var38;
                  boolean var229 = var196;
                  boolean var198 = var229;
                  boolean var197 = var229;
                  if (var230 != 0) {
                     boolean var231 = var197;
                     if (!var231) {
                        break label178;
                     }

                     var10001 = 27218;
                     var10002 = 7215046331195117098L ^ var4;
                     String var81 = "OffY";
                     JsonObject var80 = var40;
                     boolean var232 = var80.has(var81);
                     var198 = var232;
                  }

                  int var234 = var38;
                  boolean var233 = var198;
                  var200 = var233;
                  boolean var199 = var233;
                  if (var234 == 0) {
                     break label171;
                  }

                  boolean var235 = var199;
                  if (var235) {
                     var200 = true;
                     break label171;
                  }
               }

               var201 = false;
               break label172;
            }

            boolean var236 = var200;
            var201 = var236;
         }

         boolean var212;
         label151: {
            label179: {
               boolean var42 = var201;
               String var85 = "X";
               JsonObject var84 = var40;
               boolean var43 = var84.has(var85);
               String var87 = "Y";
               JsonObject var86 = var40;
               boolean var44 = var86.has(var87);
               int var238 = var38;
               boolean var237 = var42;
               boolean var205 = var237;
               boolean var202 = var237;
               if (var238 != 0) {
                  boolean var239 = var202;
                  if (var239) {
                        short var322 = 28063;
                        long var341 = 364983240336656801L ^ var4;
                        String var90 = "RuleX";
                        JsonObject var89 = var40;
                        Object[] var92 = new Object[]{var89.get(var90), var12};
                        ConfigManager var91 = this;
                        String var286 = var91.aReturningString(var92);
                        long var94 = var32;
                        String var93 = var286;
                        HudAlignment var272 = HudAlignment.valueOf(var93, var94);
                        short var323 = 18615;
                        var341 = 1400520412917329121L ^ var4;
                        String var97 = "RuleY";
                        JsonObject var96 = var40;
                        Object[] var99 = new Object[]{var96.get(var97), var12};
                        ConfigManager var98 = this;
                        var286 = var98.aReturningString(var99);
                        long var101 = var32;
                        String var100 = var286;
                        HudAlignment var274 = HudAlignment.valueOf(var100, var101);
                        short var324 = 26010;
                        var341 = 2248995120048783794L ^ var4;
                        String var104 = "OffX";
                        JsonObject var103 = var40;
                        Object[] var106 = new Object[]{var103.get(var104), var12};
                        ConfigManager var105 = this;
                        Object[] var107 = new Object[]{var105.aReturningString(var106), var14};
                        float var47 = SettingValueCodec.aReturningFloat(var107);
                        short var325 = 27218;
                        var341 = 7215046331195117098L ^ var4;
                        String var109 = "OffY";
                        JsonObject var108 = var40;
                        Object[] var111 = new Object[]{var108.get(var109), var12};
                        ConfigManager var110 = this;
                        Object[] var112 = new Object[]{var110.aReturningString(var111), var14};
                        float var48 = SettingValueCodec.aReturningFloat(var112);
                        Object[] var360 = new Object[]{null, null, null, null, var16};
                        var360[3] = var48;
                        var360[2] = var47;
                        var360[1] = var274;
                        var360[0] = var272;
                        Object[] var114 = var360;
                        HudElement var113 = var6;
                        var113.fReturningVoid(var114);
                        Object[] var116 = new Object[]{4};
                        ConfigLoadStatistics var115 = var3;
                        var115.recoveryAccess_call_cReturningVoid(var116);
                        break label179;
                     } catch (IllegalArgumentException var269) {
                        short var320 = 28276;
                        long var339 = 6598824352818809357L ^ var4;
                        String var302 = var39 + " > Position";
                        short var321 = 9318;
                        var339 = 5224675831658545227L ^ var4;
                        Object[] var118 = new Object[]{var302, "unknown positioning rule; position was skipped", null};
                        ConfigLoadStatistics var117 = var3;
                        var117.recoveryAccess_call_bReturningVoid(var118);
                        break label179;
                     } catch (Throwable var270) {
                        Object[] var119 = new Object[]{var270, var34};
                        jReturningVoid(var119);
                        short var313 = 851;
                        long var332 = 1976407019586430828L ^ var4;
                        String var295 = var39 + " > Position";
                        Object[] var120 = new Object[]{var270, var28};
                        Object[] var122 = new Object[]{var295, dReturningString(var120), var270};
                        ConfigLoadStatistics var121 = var3;
                        var121.recoveryAccess_call_bReturningVoid(var122);
                        int var240 = var38;
                        if (var240 != 0) {
                           break label179;
                        }
                     }
                  }

                  boolean var241 = var43;
                  var205 = var241;
               }

               int var243 = var38;
               boolean var242 = var205;
               boolean var207 = var242;
               boolean var206 = var242;
               if (var243 != 0) {
                  boolean var245 = var44;
                  boolean var244 = var206;
                  if (var244 != var245) {
                     short var314 = 851;
                     long var333 = 1976407019586430828L ^ var4;
                     String var296 = var39 + " > Position";
                     short var315 = 3606;
                     var333 = 2583748675896650339L ^ var4;
                     Object[] var126 = new Object[]{var296, "X and Y must both be present; position was skipped", null};
                     ConfigLoadStatistics var125 = var3;
                     var125.recoveryAccess_call_bReturningVoid(var126);
                     int var246 = var38;
                     if (var246 != 0) {
                        break label179;
                     }
                  }

                  boolean var247 = var43;
                  var207 = var247;
               }

               int var249 = var38;
               boolean var248 = var207;
               var212 = var248;
               boolean var208 = var248;
               if (var249 == 0) {
                  break label151;
               }

               boolean var250 = var208;
               if (var250) {
                     label133: {
                        String var131 = "X";
                        JsonObject var130 = var40;
                        Object[] var133 = new Object[]{var130.get(var131), var12};
                        ConfigManager var132 = this;
                        Object[] var134 = new Object[]{var132.aReturningString(var133), var14};
                        float var45 = SettingValueCodec.aReturningFloat(var134);
                        String var136 = "Y";
                        JsonObject var135 = var40;
                        Object[] var138 = new Object[]{var135.get(var136), var12};
                        ConfigManager var137 = this;
                        Object[] var139 = new Object[]{var137.aReturningString(var138), var14};
                        float var46 = SettingValueCodec.aReturningFloat(var139);
                        int var251 = var38;
                        if (var251 != 0) {
                           label130: {
                              try {
                                 var10001 = 4694;
                                 var10002 = 8774426324840265234L ^ var4;
                                 String var141 = "Anchor";
                                 JsonObject var140 = var40;
                                 boolean var252 = var140.has(var141);
                                 if (!var252) {
                                    break label130;
                                 }

                                 try {
                                    short var338 = 4694;
                                    long var352 = 8774426324840265234L ^ var4;
                                    String var144 = "Anchor";
                                    JsonObject var143 = var40;
                                    Object[] var146 = new Object[]{var143.get(var144), var12};
                                    ConfigManager var145 = this;
                                    String var300 = var145.aReturningString(var146);
                                    long var148 = var26;
                                    String var147 = var300;
                                    HudCorner var301 = HudCorner.valueOf(var147, var148);
                                    Object[] var357 = new Object[]{null, null, null, var30};
                                    var357[2] = var46;
                                    var357[1] = var45;
                                    var357[0] = var301;
                                    Object[] var151 = var357;
                                    HudElement var150 = var6;
                                    var150.gReturningVoid(var151);
                                    Object[] var153 = new Object[]{3};
                                    ConfigLoadStatistics var152 = var3;
                                    var152.recoveryAccess_call_cReturningVoid(var153);
                                    break label133;
                                 } catch (IllegalArgumentException var266) {
                                 }
                              } catch (JsonParseException var267) {
                                 throw (Throwable)var267;
                              }

                              short var318 = 1228;
                              long var336 = 4361765418067599500L ^ var4;
                              String var299 = var39 + " > Anchor";
                              short var319 = 5072;
                              var336 = 5934047928036734898L ^ var4;
                              Object[] var156 = new Object[]{var299, "unknown anchor; position was skipped", null};
                              ConfigLoadStatistics var155 = var3;
                              var155.recoveryAccess_call_bReturningVoid(var156);
                              int var253 = var38;
                              if (var253 != 0) {
                                 break label133;
                              }
                           }

                           Object[] var355 = new Object[]{null, null, var10};
                           var355[1] = var46;
                           var355[0] = var45;
                           Object[] var158 = var355;
                           HudElement var157 = var6;
                           var157.aReturningVoid(var158);
                        }

                        Object[] var161 = new Object[]{2};
                        ConfigLoadStatistics var160 = var3;
                        var160.recoveryAccess_call_cReturningVoid(var161);
                  } catch (Throwable var268) {
                     Object[] var162 = new Object[]{var268, var34};
                     jReturningVoid(var162);
                     short var316 = 851;
                     long var335 = 1976407019586430828L ^ var4;
                     String var297 = var39 + " > Position";
                     Object[] var163 = new Object[]{var268, var28};
                     Object[] var165 = new Object[]{var297, dReturningString(var163), var268};
                     ConfigLoadStatistics var164 = var3;
                     var164.recoveryAccess_call_bReturningVoid(var165);
                  }
               }
            }

            var10001 = 19981;
            var10002 = 8189283059100838439L ^ var4;
            String var167 = "Enabled";
            JsonObject var166 = var40;
            var212 = var166.has(var167);
         }

         int var255 = var38;
         boolean var254 = var212;
         boolean var214 = var254;
         boolean var213 = var254;
         if (var255 != 0) {
            boolean var256 = var213;
            if (!var256) {
               return;
            }

            try {
               short var328 = 19981;
               long var346 = 8189283059100838439L ^ var4;
               String var170 = "Enabled";
               JsonObject var169 = var40;
               Object[] var172 = new Object[]{var169.get(var170), var12};
               ConfigManager var171 = this;
               Object[] var173 = new Object[]{var171.aReturningString(var172), var8};
               var214 = SettingValueCodec.aReturningBoolean(var173);
            } catch (Throwable var265) {
               Object[] var189 = new Object[]{var265, var34};
               jReturningVoid(var189);
               short var327 = 11175;
               long var345 = 5099983136689524723L ^ var4;
               String var304 = var39 + " > Enabled";
               Object[] var190 = new Object[]{var265, var28};
               Object[] var192 = new Object[]{var304, dReturningString(var190), var265};
               ConfigLoadStatistics var191 = var3;
               var191.recoveryAccess_call_bReturningVoid(var192);
               return;
            }
         }

         try {
            boolean var273 = var214;
            int var257 = var38;
            if (var257 == 0) {
               return;
            }

            Object[] var175 = new Object[]{var36};
            HudElement var174 = var6;
            boolean var259 = var174.eReturningBoolean(var175);
            boolean var258 = var273;
            if (var258 != var259) {
               Object[] var178 = new Object[]{var36};
               HudElement var177 = var6;
               boolean var275 = var177.eReturningBoolean(var178);

               try {
                  Object[] var180 = new Object[]{var20};
                  HudElement var179 = var6;
                  var179.jReturningVoid(var180);
               } catch (Throwable var263) {
                  Object[] var181 = new Object[]{var263, var34};
                  jReturningVoid(var181);
                  Object[] var358 = new Object[]{null, null, var263, var24};
                  var358[1] = var275;
                  var358[0] = var6;
                  Object[] var183 = var358;
                  ConfigManager var182 = this;
                  boolean var276 = var182.bReturningBoolean(var183);
                  boolean var260 = var276;
                  String var216;
                  if (var260) {
                     short var289 = 23052;
                     long var307 = 5033776194944499295L ^ var4;
                     String var261 = "HUD lifecycle failed; previous state was restored";
                     var216 = var261;
                  } else {
                     short var288 = 3586;
                     long var306 = 5706274633514068565L ^ var4;
                     var216 = "HUD lifecycle failed; state may be inconsistent";
                  }

                  String var49 = var216;
                  short var330 = 28787;
                  long var348 = 6732992079001965570L ^ var4;
                  Object[] var186 = new Object[]{var39 + " > Enabled", var49, var263};
                  ConfigLoadStatistics var185 = var3;
                  var185.recoveryAccess_call_bReturningVoid(var186);
                  return;
               }
         } catch (Throwable var264) {
            Object[] var277 = new Object[]{var264, var34};
            jReturningVoid(var277);
            short var329 = 11175;
            long var347 = 5099983136689524723L ^ var4;
            String var305 = var39 + " > Enabled";
            Object[] var279 = new Object[]{var264, var28};
            Object[] var283 = new Object[]{var305, dReturningString(var279), var264};
            ConfigLoadStatistics var281 = var3;
            var281.recoveryAccess_call_bReturningVoid(var283);
            return;
         }

         try {
            Object[] var188 = new Object[]{1};
            ConfigLoadStatistics var187 = var3;
            var187.recoveryAccess_call_cReturningVoid(var188);
         } catch (Throwable var262) {
            Object[] var278 = new Object[]{var262, var34};
            jReturningVoid(var278);
            short var331 = 11175;
            long var349 = 5099983136689524723L ^ var4;
            String var308 = var39 + " > Enabled";
            Object[] var280 = new Object[]{var262, var28};
            Object[] var284 = new Object[]{var308, dReturningString(var280), var262};
            ConfigLoadStatistics var282 = var3;
            var282.recoveryAccess_call_bReturningVoid(var284);
         }
      }
   }

   private boolean bReturningBoolean(Object[] var1) {
      HudElement var2 = (HudElement)var1[0];
      boolean var6 = (Boolean)var1[1];
      Throwable var3 = (Throwable)var1[2];
      long var4 = (Long)var1[3];
      var4 = 94490381836703L ^ var4;
      long var7 = var4 ^ 118761427126870L;
      long var9 = var4 ^ 103963735741362L;
      long var11 = var4 ^ 66561387546142L;
      int var13 = Event.bReturningInt();

      try {
         Object[] var16 = new Object[]{var9};
         HudElement var15 = var2;
         boolean var10000 = var15.eReturningBoolean(var16);
         int var37 = var13;
         boolean var36 = var6;
         boolean var35 = var10000;
         boolean var30 = var35;
         boolean var31 = var36;
         boolean var27 = var35;
         boolean var28 = var36;
         if (var37 == 0) {
            boolean var39 = var28;
            boolean var38 = var27;
            if (var38 != var39) {
               Object[] var19 = new Object[]{var7};
               HudElement var18 = var2;
               var18.jReturningVoid(var19);
            }

            Object[] var22 = new Object[]{var9};
            HudElement var21 = var2;
            var10000 = var21.eReturningBoolean(var22);
            int var41 = var13;
            boolean var40 = var10000;
            boolean var32 = var40;
            boolean var29 = var40;
            if (var41 != 0) {
               return var32;
            }

            boolean var43 = var6;
            boolean var42 = var29;
            var30 = var42;
            var31 = var43;
         }

         boolean var45 = var31;
         boolean var44 = var30;
         return var44 == var45;
      } catch (Throwable var47) {
         Object[] var24 = new Object[]{var47, var11};
         jReturningVoid(var24);
         Throwable var25 = var3;
         var25.addSuppressed(var47);
         return false;
      }
   }

   private void fReturningVoid(Object[] var1) {
      JsonObject var2 = (JsonObject)var1[0];
      SettingDefinition var4 = (SettingDefinition)var1[1];
      String var6 = (String)var1[2];
      Set var5 = (Set)var1[3];
      ConfigLoadStatistics var3 = (ConfigLoadStatistics)var1[4];
      long var7 = (Long)var1[5];
      var7 = 94490381836703L ^ var7;
      long var9 = var7 ^ 99318605534130L;
      long var11 = var7 ^ 112381018590964L;
      long var13 = var7 ^ 100783897019443L;
      long var15 = var7 ^ 76312579740336L;
      int var17 = Event.cReturningInt();
      int var60 = var17;
      if (var60 != 0) {
         SettingDefinition var61 = var4;
         label54:
         if (var61 != null) {
            SettingDefinition var22 = var4;
            String var10000 = var22.aReturningString();
            int var63 = var17;
            String var62 = var10000;
            String var54 = var62;
            String var52 = var62;
            if (var63 != 0) {
               String var64 = var52;
               String var53 = var64;
               String var65 = var53;
               if (var65 == null) {
                  break label54;
               }

               SettingDefinition var25 = var4;
               String var66 = var25.aReturningString();
               var54 = var66;
            }

            int var68 = var17;
            String var67 = var54;
            String var56 = var67;
            String var55 = var67;
            if (var68 != 0) {
               String var27 = var55;
               boolean var69 = var27.isBlank();
               if (var69) {
                  break label54;
               }

               SettingDefinition var32 = var4;
               var56 = var32.aReturningString();
            }

            String var18 = var56;
            String var34 = var18;
            Set var33 = var5;
            boolean var76 = var33.add(var34);
            int var71 = var17;
            boolean var70 = var76;
            boolean var58 = var70;
            boolean var57 = var70;
            if (var71 != 0) {
               boolean var72 = var57;
               if (!var72) {
                  short var79 = 31459;
                  long var10004 = 1271867108790111554L ^ var7;
                  String var10001 = var6 + " > " + var18;
                  short var77 = 20319;
                  long var80 = 5734655179014453466L ^ var7;
                  Object[] var37 = new Object[]{var10001, "duplicate registered setting name", null};
                  ConfigLoadStatistics var36 = var3;
                  var36.recoveryAccess_call_bReturningVoid(var37);
                  return;
               }

               String var40 = var18;
               JsonObject var39 = var2;
               var58 = var39.has(var40);
            }

            boolean var73 = var58;
            if (!var73) {
               return;
            }

            short var10002 = 31459;
            long var10003 = 1271867108790111554L ^ var7;
            String var19 = var6 + " > " + var18;

            try {
               String var42 = var18;
               JsonObject var41 = var2;
               Object[] var44 = new Object[]{var41.get(var42), var9};
               ConfigManager var43 = this;
               Object[] var45 = new Object[]{var4, var43.aReturningString(var44), var13};
               SettingValueCodec.aReturningVoid(var45);
               Object[] var47 = new Object[]{1};
               ConfigLoadStatistics var46 = var3;
               var46.recoveryAccess_call_cReturningVoid(var47);
            } catch (Throwable var74) {
               Object[] var48 = new Object[]{var74, var15};
               jReturningVoid(var48);
               Object[] var49 = new Object[]{var74, var11};
               Object[] var51 = new Object[]{var19, dReturningString(var49), var74};
               ConfigLoadStatistics var50 = var3;
               var50.recoveryAccess_call_bReturningVoid(var51);
            }

            return;
         }

         short var78 = 6223;
         long var81 = 1078619784356556777L ^ var7;
         Object[] var30 = new Object[]{var6, "an unnamed setting was skipped", null};
         ConfigLoadStatistics var29 = var3;
         var29.recoveryRecordSetting(var30);
      }
   }

   
   
   private void gReturningVoid(Object[] var1) {
      JsonObject var2 = (JsonObject)var1[0];
      SettingDefinition var5 = (SettingDefinition)var1[1];
      String var4 = (String)var1[2];
      ConfigLoadStatistics var3 = (ConfigLoadStatistics)var1[3];
      long var6 = (Long)var1[4];
      var6 = 94490381836703L ^ var6;
      long var8 = var6 ^ 24116354550720L;
      long var10 = var6 ^ 80146946875254L;
      long var12 = var6 ^ 118433669186354L;
      int var14 = Event.bReturningInt();
      int var58 = var14;
      if (var58 == 0) {
         SettingDefinition var59 = var5;
         label54:
         if (var59 != null) {
            SettingDefinition var18 = var5;
            String var10000 = var18.aReturningString();
            int var61 = var14;
            String var60 = var10000;
            String var50 = var60;
            String var48 = var60;
            if (var61 == 0) {
               String var62 = var48;
               String var49 = var62;
               String var63 = var49;
               if (var63 == null) {
                  break label54;
               }

               SettingDefinition var21 = var5;
               String var64 = var21.aReturningString();
               var50 = var64;
            }

            int var66 = var14;
            String var65 = var50;
            String var52 = var65;
            String var51 = var65;
            if (var66 == 0) {
               String var23 = var51;
               boolean var67 = var23.isBlank();
               if (var67) {
                  break label54;
               }

               SettingDefinition var28 = var5;
               String var10001 = var28.aReturningString();
               short var10002 = 31459;
               long var10003 = 1271909229183966400L ^ var6;
               var52 = var4 + " > " + var10001;
            }

            String var15 = var52;
            SettingDefinition var29 = var5;
            String var79 = var29.aReturningString();
            int var70 = var14;
            String var69 = var79;
            JsonObject var68 = var2;
            JsonObject var55 = var68;
            String var56 = var69;
            JsonObject var53 = var68;
            String var54 = var69;
            if (var70 == 0) {
               String var31 = var54;
               JsonObject var30 = var53;
               boolean var71 = var30.has(var31);
               if (var71) {
                  short var80 = 1638;
                  long var82 = 1563746678836519012L ^ var6;
                  Object[] var34 = new Object[]{var15, "duplicate registered setting name", null};
                  ConfigLoadStatistics var33 = var3;
                  var33.recoveryAccess_call_bReturningVoid(var34);
                  return;
               }

               try {
                  SettingDefinition var36 = var5;
                  var56 = var36.aReturningString();
                  var55 = var2;
               } catch (Throwable var73) {
                  Object[] var44 = new Object[]{var73, var12};
                  jReturningVoid(var44);
                  Object[] var45 = new Object[]{var73, var10};
                  Object[] var47 = new Object[]{var15, dReturningString(var45), var73};
                  ConfigLoadStatistics var46 = var3;
                  var46.recoveryAccess_call_bReturningVoid(var47);
                  return;
               }
            }

            try {
               Object[] var38 = new Object[]{var5, var8};
               ConfigManager var37 = this;
               String var41 = var37.bReturningString(var38);
               String var40 = var56;
               JsonObject var39 = var55;
               var39.addProperty(var40, var41);
               Object[] var43 = new Object[]{1};
               ConfigLoadStatistics var42 = var3;
               var42.recoveryAccess_call_cReturningVoid(var43);
            } catch (Throwable var72) {
               Object[] var75 = new Object[]{var72, var12};
               jReturningVoid(var75);
               Object[] var76 = new Object[]{var72, var10};
               Object[] var78 = new Object[]{var15, dReturningString(var76), var72};
               ConfigLoadStatistics var77 = var3;
               var77.recoveryAccess_call_bReturningVoid(var78);
            }

            return;
         }

         short var81 = 12340;
         long var83 = 6495684978616358517L ^ var6;
         Object[] var26 = new Object[]{var4, "an unnamed setting was skipped", null};
         ConfigLoadStatistics var25 = var3;
         var25.recoveryRecordSetting(var26);
      }
   }

   private JsonObject aReturningJsonObject(Object[] param1) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[36];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.String)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[1]); }
                  recoveryAt=10; { recoveryLocals[5]=recoveryStack[1];  }
                  recoveryAt=11; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=12; { recoveryStack[2]=2; }
                  recoveryAt=13; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=14; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=16; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=18; { recoveryStack[0]=94490381836703L; }
                  recoveryAt=19; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=20; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=21; { recoveryLocals[2]=recoveryStack[0];  }
                  recoveryAt=22; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=23; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=24; { recoveryStack[2]=79042800196025L; }
                  recoveryAt=25; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=26; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=28; { recoveryStack[0]=dev.zprestige.prestige.api.eventbus.Event.bReturningInt(); }
                  recoveryAt=29; { recoveryLocals[8]=recoveryStack[0];  }
                  recoveryAt=32; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=33; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=127; continue recoveryFlow;} recoveryPc=35; continue recoveryFlow; }
               }
               case 35 -> {
                  recoveryAt=35; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=36; { if(recoveryStack[0]==null){recoveryPc=76; continue recoveryFlow;} recoveryPc=38; continue recoveryFlow; }
               }
               case 38 -> {
                  recoveryAt=38; { recoveryPc=47; continue recoveryFlow; }
               }
               case 41 -> {
                  recoveryAt=41; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=42; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=43; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=44; { throw (Throwable)recoveryStack[0]; }
               }
               case 47 -> {
                  recoveryAt=47; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=48; { recoveryLocals[11]=recoveryStack[0];  }
                  recoveryAt=49; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=50; { recoveryStack[0]=((java.lang.String)recoveryStack[0]); }
                  recoveryAt=51; { recoveryStack[0]=((java.lang.String)recoveryStack[0]).isBlank(); }
                  recoveryAt=52; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=53; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=139; continue recoveryFlow;} recoveryPc=55; continue recoveryFlow; }
               }
               case 55 -> {
                  recoveryAt=55; { recoveryPc=64; continue recoveryFlow; }
               }
               case 58 -> {
                  recoveryAt=58; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=59; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=60; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=61; { throw (Throwable)recoveryStack[0]; }
               }
               case 64 -> {
                  recoveryAt=64; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=132; continue recoveryFlow;} recoveryPc=66; continue recoveryFlow; }
               }
               case 66 -> {
                  recoveryAt=66; { recoveryPc=76; continue recoveryFlow; }
               }
               case 69 -> {
                  recoveryAt=69; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=70; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=71; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=72; { throw (Throwable)recoveryStack[0]; }
               }
               case 76 -> {
                  recoveryAt=76; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=77; { recoveryStack[1]=22211; }
                  recoveryAt=78; { recoveryStack[2]=4006525968402348269L; }
                  recoveryAt=79; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=80; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=83; { recoveryStack[1]="Config"; }
                  recoveryAt=84; { recoveryStack[2]=15313; }
                  recoveryAt=85; { recoveryStack[3]=7983255476186486251L; }
                  recoveryAt=86; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=87; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=90; { recoveryStack[2]="downloaded config was empty"; }
                  recoveryAt=91; { recoveryStack[3]=null; }
                  recoveryAt=92; { recoveryStack[4]=3; }
                  recoveryAt=93; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=94; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=95; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=96; { recoveryStack[6]=2; }
                  recoveryAt=97; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=98; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=99; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=100; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=101; { recoveryStack[5]=1; }
                  recoveryAt=102; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=103; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=104; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=105; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=106; { recoveryStack[4]=0; }
                  recoveryAt=107; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=108; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=109; { recoveryLocals[15]=recoveryStack[1];  }
                  recoveryAt=110; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=111; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=112; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]); }
                  recoveryAt=113; { recoveryStack[1]=recoveryLocals[15];  }
                  recoveryAt=114; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=115; { ((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]).recoveryAccess_call_bReturningVoid(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=117; { recoveryPc=127; continue recoveryFlow; }
               }
               case 120 -> {
                  recoveryAt=120; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=121; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=122; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=123; { throw (Throwable)recoveryStack[0]; }
               }
               case 127 -> {
                  recoveryAt=127; { recoveryStack[0]=null; }
                  recoveryAt=128; { return ((com.google.gson.JsonObject)recoveryStack[0]); }
               }
               case 132 -> {
                  recoveryAt=132; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=133; { recoveryLocals[17]=recoveryStack[0];  }
                  recoveryAt=134; { recoveryStack[0]=recoveryLocals[17];  }
                  recoveryAt=135; { recoveryStack[0]=((java.lang.String)recoveryStack[0]); }
                  recoveryAt=136; { recoveryStack[0]=((java.lang.String)recoveryStack[0]).length(); }
                  recoveryPc=139; continue recoveryFlow;
               }
               case 139 -> {
                  recoveryAt=139; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=140; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=250; continue recoveryFlow;} recoveryPc=142; continue recoveryFlow; }
               }
               case 142 -> {
                  recoveryAt=142; { recoveryStack[1]=87; }
                  recoveryAt=143; { recoveryStack[2]=6653486653180950666L; }
                  recoveryAt=144; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=145; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=148; { recoveryStack[1]=100000; }
                  recoveryAt=149; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=214; continue recoveryFlow;} recoveryPc=151; continue recoveryFlow; }
               }
               case 151 -> {
                  recoveryAt=151; { recoveryPc=161; continue recoveryFlow; }
               }
               case 154 -> {
                  recoveryAt=154; { recoveryLocals[18]=recoveryStack[0];  }
                  recoveryAt=155; { recoveryStack[0]=recoveryLocals[18];  }
                  recoveryAt=156; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=157; { throw (Throwable)recoveryStack[0]; }
               }
               case 161 -> {
                  recoveryAt=161; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=162; { recoveryStack[1]=22211; }
                  recoveryAt=163; { recoveryStack[2]=4006525968402348269L; }
                  recoveryAt=164; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=165; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=168; { recoveryStack[1]="Config"; }
                  recoveryAt=169; { recoveryStack[2]=17032; }
                  recoveryAt=170; { recoveryStack[3]=7703587012866305210L; }
                  recoveryAt=171; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=172; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=175; { recoveryStack[2]="downloaded config is too large"; }
                  recoveryAt=176; { recoveryStack[3]=null; }
                  recoveryAt=177; { recoveryStack[4]=3; }
                  recoveryAt=178; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=179; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=180; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=181; { recoveryStack[6]=2; }
                  recoveryAt=182; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=183; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=184; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=185; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=186; { recoveryStack[5]=1; }
                  recoveryAt=187; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=188; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=189; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=190; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=191; { recoveryStack[4]=0; }
                  recoveryAt=192; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=193; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=194; { recoveryLocals[20]=recoveryStack[1];  }
                  recoveryAt=195; { recoveryLocals[19]=recoveryStack[0];  }
                  recoveryAt=196; { recoveryStack[0]=recoveryLocals[19];  }
                  recoveryAt=197; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]); }
                  recoveryAt=198; { recoveryStack[1]=recoveryLocals[20];  }
                  recoveryAt=199; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=200; { ((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]).recoveryAccess_call_bReturningVoid(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=203; { recoveryStack[0]=null; }
                  recoveryAt=204; { return ((com.google.gson.JsonObject)recoveryStack[0]); }
               }
               case 207 -> {
                  recoveryAt=207; { recoveryLocals[21]=recoveryStack[0];  }
                  recoveryAt=208; { recoveryStack[0]=recoveryLocals[21];  }
                  recoveryAt=209; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=210; { throw (Throwable)recoveryStack[0]; }
               }
               case 214 -> {
                  recoveryAt=214; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=215; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=216; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=321; continue recoveryFlow;} recoveryPc=217; continue recoveryFlow; }
               }
               case 217 -> {
                  recoveryAt=217; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=218; { recoveryStack[2]=recoveryLocals[6];  }
                  recoveryAt=219; { recoveryStack[3]=2; }
                  recoveryAt=220; { recoveryStack[3]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]; }
                  recoveryAt=221; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=222; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=224; { recoveryStack[4]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=225; { recoveryStack[5]=1; }
                  recoveryAt=226; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=227; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=228; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=229; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=230; { recoveryStack[4]=0; }
                  recoveryAt=231; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=232; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=233; { recoveryLocals[23]=recoveryStack[1];  }
                  recoveryAt=234; { recoveryLocals[22]=recoveryStack[0];  }
                  recoveryAt=235; { recoveryStack[0]=recoveryLocals[22];  }
                  recoveryAt=236; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigManager)recoveryStack[0]); }
                  recoveryAt=237; { recoveryStack[1]=recoveryLocals[23];  }
                  recoveryAt=238; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=239; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigManager)recoveryStack[0]).cReturningBoolean(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=241; { recoveryPc=250; continue recoveryFlow; }
               }
               case 244 -> {
                  recoveryAt=244; { recoveryLocals[24]=recoveryStack[0];  }
                  recoveryAt=245; { recoveryStack[0]=recoveryLocals[24];  }
                  recoveryAt=246; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=247; { throw (Throwable)recoveryStack[0]; }
               }
               case 250 -> {
                  recoveryAt=250; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=306; continue recoveryFlow;} recoveryPc=253; continue recoveryFlow; }
               }
               case 253 -> {
                  recoveryAt=253; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=254; { recoveryStack[1]=22211; }
                  recoveryAt=255; { recoveryStack[2]=4006525968402348269L; }
                  recoveryAt=256; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=257; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=260; { recoveryStack[1]="Config"; }
                  recoveryAt=261; { recoveryStack[2]=14114; }
                  recoveryAt=262; { recoveryStack[3]=3492743774673508669L; }
                  recoveryAt=263; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=264; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=267; { recoveryStack[2]="downloaded config is nested too deeply"; }
                  recoveryAt=268; { recoveryStack[3]=null; }
                  recoveryAt=269; { recoveryStack[4]=3; }
                  recoveryAt=270; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=271; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=272; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=273; { recoveryStack[6]=2; }
                  recoveryAt=274; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=275; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=276; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=277; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=278; { recoveryStack[5]=1; }
                  recoveryAt=279; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=280; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=281; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=282; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=283; { recoveryStack[4]=0; }
                  recoveryAt=284; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=285; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=286; { recoveryLocals[26]=recoveryStack[1];  }
                  recoveryAt=287; { recoveryLocals[25]=recoveryStack[0];  }
                  recoveryAt=288; { recoveryStack[0]=recoveryLocals[25];  }
                  recoveryAt=289; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]); }
                  recoveryAt=290; { recoveryStack[1]=recoveryLocals[26];  }
                  recoveryAt=291; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=292; { ((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]).recoveryAccess_call_bReturningVoid(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=295; { recoveryStack[0]=null; }
                  recoveryAt=296; { return ((com.google.gson.JsonObject)recoveryStack[0]); }
               }
               case 299 -> {
                  recoveryAt=299; { recoveryLocals[27]=recoveryStack[0];  }
                  recoveryAt=300; { recoveryStack[0]=recoveryLocals[27];  }
                  recoveryAt=301; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=302; { throw (Throwable)recoveryStack[0]; }
               }
               case 306 -> {
                  recoveryAt=306; { recoveryStack[0]=dev.zprestige.prestige.client.management.ConfigManager.a; }
                  recoveryAt=307; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=308; { recoveryStack[2]=com.google.gson.JsonObject.class; }
                  recoveryAt=309; { recoveryLocals[30]=recoveryStack[2];  }
                  recoveryAt=310; { recoveryLocals[29]=recoveryStack[1];  }
                  recoveryAt=311; { recoveryLocals[28]=recoveryStack[0];  }
                  recoveryAt=312; { recoveryStack[0]=recoveryLocals[28];  }
                  recoveryAt=313; { recoveryStack[0]=((com.google.gson.Gson)recoveryStack[0]); }
                  recoveryAt=314; { recoveryStack[1]=recoveryLocals[29];  }
                  recoveryAt=315; { recoveryStack[1]=((java.lang.String)recoveryStack[1]); }
                  recoveryAt=316; { recoveryStack[2]=recoveryLocals[30];  }
                  recoveryAt=317; { recoveryStack[2]=((java.lang.Class)recoveryStack[2]); }
                  recoveryAt=318; { recoveryStack[0]=((com.google.gson.Gson)recoveryStack[0]).fromJson(((java.lang.String)recoveryStack[1]),((java.lang.Class)recoveryStack[2])); }
                  recoveryPc=321; continue recoveryFlow;
               }
               case 321 -> {
                  recoveryAt=321; { recoveryStack[0]=((com.google.gson.JsonObject)recoveryStack[0]); }
                  recoveryAt=322; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=325; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=326; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=327; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=391; continue recoveryFlow;} recoveryPc=328; continue recoveryFlow; }
               }
               case 328 -> {
                  recoveryAt=328; { if(recoveryStack[0]!=null){recoveryPc=388; continue recoveryFlow;} recoveryPc=330; continue recoveryFlow; }
               }
               case 330 -> {
                  recoveryAt=330; { recoveryPc=340; continue recoveryFlow; }
               }
               case 333 -> {
                  recoveryAt=333; { recoveryLocals[31]=recoveryStack[0];  }
                  recoveryAt=334; { recoveryStack[0]=recoveryLocals[31];  }
                  recoveryAt=335; { recoveryStack[0]=((java.lang.Throwable)recoveryStack[0]); }
                  recoveryAt=336; { throw (Throwable)recoveryStack[0]; }
               }
               case 340 -> {
                  recoveryAt=340; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=341; { recoveryStack[1]=22211; }
                  recoveryAt=342; { recoveryStack[2]=4006525968402348269L; }
                  recoveryAt=343; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=344; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=347; { recoveryStack[1]="Config"; }
                  recoveryAt=348; { recoveryStack[2]=20485; }
                  recoveryAt=349; { recoveryStack[3]=4984050936463654461L; }
                  recoveryAt=350; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=351; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=354; { recoveryStack[2]="downloaded config contained JSON null"; }
                  recoveryAt=355; { recoveryStack[3]=null; }
                  recoveryAt=356; { recoveryStack[4]=3; }
                  recoveryAt=357; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=358; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=359; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=360; { recoveryStack[6]=2; }
                  recoveryAt=361; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=362; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=363; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=364; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=365; { recoveryStack[5]=1; }
                  recoveryAt=366; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=367; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=368; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=369; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=370; { recoveryStack[4]=0; }
                  recoveryAt=371; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=372; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=373; { recoveryLocals[33]=recoveryStack[1];  }
                  recoveryAt=374; { recoveryLocals[32]=recoveryStack[0];  }
                  recoveryAt=375; { recoveryStack[0]=recoveryLocals[32];  }
                  recoveryAt=376; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]); }
                  recoveryAt=377; { recoveryStack[1]=recoveryLocals[33];  }
                  recoveryAt=378; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=379; { ((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]).recoveryAccess_call_bReturningVoid(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=382; { recoveryStack[0]=null; }
                  recoveryAt=384; { return ((com.google.gson.JsonObject)recoveryStack[0]); }
               }
               case 388 -> {
                  recoveryAt=388; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryPc=391; continue recoveryFlow;
               }
               case 391 -> {
                  recoveryAt=391; { return ((com.google.gson.JsonObject)recoveryStack[0]); }
               }
               case 395 -> {
                  recoveryAt=395; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=398; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=399; { recoveryStack[1]=22211; }
                  recoveryAt=400; { recoveryStack[2]=4006525968402348269L; }
                  recoveryAt=401; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=402; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=405; { recoveryStack[1]="Config"; }
                  recoveryAt=406; { recoveryStack[2]=10758; }
                  recoveryAt=407; { recoveryStack[3]=1535824071157941251L; }
                  recoveryAt=408; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=409; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]); }
                  recoveryAt=412; { recoveryStack[2]="downloaded config is not valid JSON"; }
                  recoveryAt=413; { recoveryStack[3]=recoveryLocals[9];  }
                  recoveryAt=414; { recoveryStack[4]=3; }
                  recoveryAt=415; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=416; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=417; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=418; { recoveryStack[6]=2; }
                  recoveryAt=419; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=420; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=421; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=422; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=423; { recoveryStack[5]=1; }
                  recoveryAt=424; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=425; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=426; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=427; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=428; { recoveryStack[4]=0; }
                  recoveryAt=429; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=430; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=431; { recoveryLocals[35]=recoveryStack[1];  }
                  recoveryAt=432; { recoveryLocals[34]=recoveryStack[0];  }
                  recoveryAt=433; { recoveryStack[0]=recoveryLocals[34];  }
                  recoveryAt=434; { recoveryStack[0]=((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]); }
                  recoveryAt=435; { recoveryStack[1]=recoveryLocals[35];  }
                  recoveryAt=436; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=437; { ((dev.zprestige.prestige.client.management.ConfigLoadStatistics)recoveryStack[0]).recoveryAccess_call_bReturningVoid(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=440; { recoveryStack[0]=null; }
                  recoveryAt=441; { return ((com.google.gson.JsonObject)recoveryStack[0]); }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=323 && recoveryAt<329 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=333; continue recoveryFlow;}
            if(recoveryAt>=248 && recoveryAt<297 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=299; continue recoveryFlow;}
            if(recoveryAt>=211 && recoveryAt<240 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=244; continue recoveryFlow;}
            if(recoveryAt>=141 && recoveryAt<205 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=207; continue recoveryFlow;}
            if(recoveryAt>=137 && recoveryAt<150 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=154; continue recoveryFlow;}
            if(recoveryAt>=62 && recoveryAt<116 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=120; continue recoveryFlow;}
            if(recoveryAt>=45 && recoveryAt<65 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=69; continue recoveryFlow;}
            if(recoveryAt>=34 && recoveryAt<54 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=58; continue recoveryFlow;}
            if(recoveryAt>=30 && recoveryAt<37 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=41; continue recoveryFlow;}
            if(recoveryAt>=303 && recoveryAt<383 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=395; continue recoveryFlow;}
            if(recoveryAt>=303 && recoveryAt<383 && recoveryFailure instanceof java.lang.IllegalStateException){recoveryStack[0]=recoveryFailure; recoveryPc=395; continue recoveryFlow;}
            if(recoveryAt>=385 && recoveryAt<389 && recoveryFailure instanceof com.google.gson.JsonParseException){recoveryStack[0]=recoveryFailure; recoveryPc=395; continue recoveryFlow;}
            if(recoveryAt>=385 && recoveryAt<389 && recoveryFailure instanceof java.lang.IllegalStateException){recoveryStack[0]=recoveryFailure; recoveryPc=395; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   private boolean cReturningBoolean(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 94490381836703L ^ var2;
      int var10000 = Event.bReturningInt();
      char var7 = 0;
      byte var8 = 0;
      int var5 = var10000;
      char var46;
      while (true) {
         String var11 = var4;
         int var48 = var11.length();
         int var47 = var9;
         if (var47 < var48) {
            int var13 = var9;
            String var12 = var4;
            char var10 = var12.charAt(var13);
            int var50 = var5;
            char var49 = var7;
            var46 = var49;
            char var14 = var49;
            if (var50 != 0) {
               break;
            }

            label115: {
               label134: {
                  int var52 = var5;
                  char var51 = var14;
                  char var27 = var51;
                  char var15 = var51;
                  if (var52 == 0) {
                     char var53 = var15;
                     char var16 = var53;
                     char var54 = var16;
                     if (var54 != 0) {
                        int var56 = var5;
                        byte var55 = var8;
                        char var19 = (char)var55;
                        byte var17 = var55;
                        if (var56 == 0) {
                           byte var57 = var17;
                           byte var18 = var57;
                           byte var58 = var18;
                           if (var58 != 0) {
                              var8 = 0;
                              int var59 = var5;
                              if (var59 == 0) {
                                 break label134;
                              }
                           }

                           char var60 = var10;
                           var19 = var60;
                        }

                        char var26;
                        label127: {
                           short var10001 = 17281;
                           long var10002 = 5233024450822669172L ^ var2;
                           int var63 = var5;
                           byte var62 = 92;
                           char var61 = var19;
                           char var24 = var61;
                           byte var25 = var62;
                           char var20 = var61;
                           byte var21 = var62;
                           if (var63 == 0) {
                              byte var65 = var21;
                              char var64 = var20;
                              if (var64 == var65) {
                                 var8 = 1;
                                 int var66 = var5;
                                 if (var66 == 0) {
                                    break label134;
                                 }
                              }

                              int var68 = var5;
                              char var67 = var10;
                              var26 = var67;
                              char var22 = var67;
                              if (var68 != 0) {
                                 break label127;
                              }

                              char var69 = var22;
                              char var23 = var69;
                              var10001 = 5979;
                              var10002 = 8274834780316555180L ^ var2;
                              byte var71 = 34;
                              char var70 = var23;
                              var24 = var70;
                              var25 = var71;
                           }

                           byte var73 = var25;
                           char var72 = var24;
                           if (var72 != var73) {
                              break label134;
                           }

                           var26 = 0;
                        }

                        var7 = var26;
                        int var74 = var5;
                        if (var74 == 0) {
                           break label134;
                        }
                     }

                     char var75 = var10;
                     var27 = var75;
                  }

                  short var113 = 25971;
                  long var120 = 1497357301060871557L ^ var2;
                  int var78 = var5;
                  byte var77 = 34;
                  char var76 = var27;
                  char var30 = var76;
                  byte var31 = var77;
                  char var28 = var76;
                  byte var29 = var77;
                  if (var78 == 0) {
                     byte var80 = var29;
                     char var79 = var28;
                     if (var79 == var80) {
                        var7 = 1;
                        int var81 = var5;
                        if (var81 == 0) {
                           break label134;
                        }
                     }

                     var113 = 31440;
                     var120 = 6583668653453392431L ^ var2;
                     byte var83 = 123;
                     char var82 = var10;
                     var30 = var82;
                     var31 = var83;
                  }

                  int var86 = var5;
                  byte var85 = var31;
                  char var84 = var30;
                  int var38 = var84;
                  byte var39 = var85;
                  char var32 = var84;
                  byte var33 = var85;
                  if (var86 == 0) {
                     byte var88 = var33;
                     char var87 = var32;
                     label80:
                     if (var87 != var88) {
                        var113 = 15768;
                        var120 = 2319129735710965094L ^ var2;
                        int var91 = var5;
                        byte var90 = 91;
                        char var89 = var10;
                        char var40 = var89;
                        byte var41 = var90;
                        char var34 = var89;
                        byte var35 = var90;
                        if (var91 == 0) {
                           byte var93 = var35;
                           char var92 = var34;
                           char var36 = var92;
                           byte var37 = var93;
                           byte var95 = var37;
                           char var94 = var36;
                           if (var94 == var95) {
                              break label80;
                           }

                           var113 = 5959;
                           var120 = 3797236244219516859L ^ var2;
                           var41 = 125;
                           var40 = var10;
                        }

                        label69: {
                           int var103 = var5;
                           byte var102 = var41;
                           char var101 = var40;
                           char var44 = var101;
                           byte var45 = var102;
                           char var42 = var101;
                           byte var43 = var102;
                           if (var103 == 0) {
                              byte var105 = var43;
                              char var104 = var42;
                              if (var104 == var105) {
                                 break label69;
                              }

                              var113 = 30962;
                              var120 = 6431849289167058952L ^ var2;
                              byte var107 = 93;
                              char var106 = var10;
                              var44 = var106;
                              var45 = var107;
                           }

                           byte var109 = var45;
                           char var108 = var44;
                           if (var108 != var109) {
                              break label134;
                           }
                        }

                        var6--;
                        break label134;
                     }

                     var6++;
                     int var96 = var5;
                     if (var96 != 0) {
                        break label115;
                     }

                     var113 = 21035;
                     var120 = 4280744964360999647L ^ var2;
                     byte var98 = 64;
                     int var97 = var6;
                     var38 = var97;
                     var39 = var98;
                  }

                  byte var100 = var39;
                  int var99 = var38;
                  if (var99 > var100) {
                     return true;
                  }
               }

               var9++;
            }

            int var110 = var5;
            if (var110 == 0) {
               continue;
            }
         }

         var46 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var46);
   }

   private JsonObject bReturningJsonObject(Object[] var1) {
      JsonElement var5 = (JsonElement)var1[0];
      String var2 = (String)var1[1];
      ConfigLoadStatistics var6 = (ConfigLoadStatistics)var1[2];
      long var3 = (Long)var1[3];
      var3 = 94490381836703L ^ var3;
      int var7 = Event.cReturningInt();
      int var26 = var7;
      if (var26 != 0) {
         JsonElement var27 = var5;
         label26:
         if (var27 != null) {
            JsonElement var25;
            label40: {
               JsonElement var9 = var5;
               boolean var10000 = var9.isJsonNull();
               int var29 = var7;
               boolean var28 = var10000;
               boolean var24 = var28;
               boolean var21 = var28;
               if (var29 != 0) {
                  boolean var30 = var21;
                  boolean var22 = var30;
                  boolean var31 = var22;
                  if (var31) {
                     break label26;
                  }

                  int var33 = var7;
                  JsonElement var32 = var5;
                  var25 = var32;
                  JsonElement var23 = var32;
                  if (var33 == 0) {
                     break label40;
                  }

                  JsonElement var15 = var23;
                  boolean var34 = var15.isJsonObject();
                  var24 = var34;
               }

               boolean var35 = var24;
               if (!var35) {
                  short var10002 = 11824;
                  long var10003 = 6483257025268037130L ^ var3;
                  Object[] var18 = new Object[]{var2, "section must be a JSON object", null};
                  ConfigLoadStatistics var17 = var6;
                  var17.recoveryAccess_call_bReturningVoid(var18);
                  return null;
               }

               var25 = var5;
            }

            JsonElement var20 = var25;
            return var20.getAsJsonObject();
         }

         short var37 = 289;
         long var38 = 1693499423099656468L ^ var3;
         Object[] var13 = new Object[]{var2, "section is null", null};
         ConfigLoadStatistics var12 = var6;
         var12.recoveryAccess_call_bReturningVoid(var13);
      }

      return null;
   }

   private String aReturningString(Object[] var1) {
      long var30;
      label34: {
         JsonElement var2 = (JsonElement)var1[0];
         var30 = (Long)var1[1];
         var30 = 94490381836703L ^ var30;
         int var5 = Event.bReturningInt();
         int var21 = var5;
         JsonElement var20 = var2;
         JsonElement var15 = var20;
         JsonElement var14 = var20;
         if (var21 == 0) {
            JsonElement var22 = var14;
            if (var22 == null) {
               break label34;
            }

            var15 = var2;
         }

         JsonElement var19;
         label35: {
            JsonElement var7 = var15;
            boolean var10000 = var7.isJsonNull();
            int var24 = var5;
            boolean var23 = var10000;
            boolean var18 = var23;
            boolean var16 = var23;
            if (var24 == 0) {
               boolean var25 = var16;
               if (var25) {
                  break label34;
               }

               int var27 = var5;
               JsonElement var26 = var2;
               var19 = var26;
               JsonElement var17 = var26;
               if (var27 != 0) {
                  break label35;
               }

               JsonElement var10 = var17;
               boolean var28 = var10.isJsonPrimitive();
               var18 = var28;
            }

            boolean var29 = var18;
            if (!var29) {
               short var10002 = 7849;
               long var10003 = 5056144232913427231L ^ var30;
               throw new IllegalArgumentException("expected a single value");
            }

            var19 = var2;
         }

         JsonElement var13 = var19;
         return var13.getAsString();
      }

      short var31 = 5415;
      long var32 = 7661991732781142156L ^ var30;
      throw new IllegalArgumentException("value is null");
   }

   private void hReturningVoid(Object[] var1) {
      JsonObject var8 = (JsonObject)var1[0];
      Set var3 = (Set)var1[1];
      String var4 = (String)var1[2];
      String var2 = (String)var1[3];
      ConfigLoadStatistics var7 = (ConfigLoadStatistics)var1[4];
      long var5 = (Long)var1[5];
      var5 = 94490381836703L ^ var5;
      int var10000 = Event.cReturningInt();
      JsonObject var13 = var8;
      Set var14 = var13.entrySet();
      Iterator var10 = var14.iterator();
      int var9 = var10000;

      while (true) {
         Iterator var15 = var10;
         boolean var34 = var15.hasNext();
         if (!var34) {
            break;
         }

         String var33;
         label33: {
            Entry var11;
            String var32;
            label41: {
               Iterator var16 = var10;
               var11 = (Entry)var16.next();
               Entry var17 = var11;
               Object var19 = var17.getKey();
               Set var18 = var3;
               boolean var46 = var18.contains(var19);
               int var36 = var9;
               boolean var35 = var46;
               boolean var31 = var35;
               boolean var29 = var35;
               if (var36 != 0) {
                  boolean var37 = var29;
                  if (var37) {
                     int var38 = var9;
                     if (var38 != 0) {
                        continue;
                     }
                  }

                  int var40 = var9;
                  String var39 = var4;
                  var32 = var39;
                  String var30 = var39;
                  if (var40 == 0) {
                     break label41;
                  }

                  String var22 = var30;
                  boolean var41 = var22.isEmpty();
                  var31 = var41;
               }

               boolean var42 = var31;
               if (var42) {
                  Entry var24 = var11;
                  String var43 = (String)var24.getKey();
                  var33 = var43;
                  break label33;
               }

               var32 = var4;
            }

            Entry var26 = var11;
            String var10001 = (String)var26.getKey();
            short var10002 = 16125;
            long var10003 = 8490440275112648975L ^ var5;
            var33 = var32 + " > " + var10001;
         }

         String var12 = var33;
         short var47 = 30268;
         long var10004 = 3326579138410260968L ^ var5;
         Object[] var28 = new Object[]{var12, var2 + " is not available in this version; skipped", null};
         ConfigLoadStatistics var27 = var7;
         var27.recoveryRecordSetting(var28);
         int var44 = var9;
         if (var44 == 0) {
            break;
         }
      }
   }

   private String bReturningString(Object[] var1) {
      SettingDefinition var4 = (SettingDefinition)var1[0];
      long var2 = (Long)var1[1];
      var2 = 94490381836703L ^ var2;
      long var5 = var2 ^ 55019659930656L;
      int var7 = Event.bReturningInt();
      int var10000 = (((var4 instanceof ColorSetting) ? 1 : 0));
      int var70 = var7;
      boolean var69 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var56 = var69;
      boolean var53 = var69;
      if (var70 == 0) {
         boolean var71 = var53;
         if (var71) {
            ColorSetting var102 = (ColorSetting)var4;
            ColorSetting var15 = var102;
            Color var103 = (Color)var15.aReturningObject();
            int var73 = var7;
            Color var72 = var103;
            Color var55 = var72;
            Color var54 = var72;
            if (var73 == 0) {
               Color var74 = var54;
               if (var74 == null) {
                  short var113 = 22714;
                  long var115 = 590419385826006177L ^ var2;
                  throw new IllegalStateException("color is null");
               }

               var55 = var103;
            }

            Color var18 = var55;
            var10000 = var18.getRed();
            Color var19 = var103;
            int var10001 = var19.getGreen();
            Color var20 = var103;
            int var112 = var20.getBlue();
            Color var21 = var103;
            return var10000 + "." + var10001 + "." + var112 + "." + var21.getAlpha();
         }

         var56 = var4 instanceof BindSetting;
      }

      int var76 = var7;
      boolean var75 = var56;
      boolean var60 = var75;
      boolean var57 = var75;
      if (var76 == 0) {
         boolean var77 = var57;
         if (var77) {
            BindSetting var101 = (BindSetting)var4;
            BindSetting var23 = var101;
            var10000 = (int)var23.aReturningObject();
            int var79 = var7;
            Object var78 = var10000;
            Object var59 = var78;
            Object var58 = var78;
            if (var79 == 0) {
               Object var80 = var58;
               if (var80 == null) {
                  short var111 = 4435;
                  long var114 = 4896277346198232363L ^ var2;
                  throw new IllegalStateException("bind is null");
               }

               BindSetting var26 = var101;
               var59 = var26.aReturningObject();
            }

            Object var27 = var59;
            String var109 = String.valueOf(var27);
            BindSetting var28 = var101;
            return var109 + "." + var28.bReturningVoid();
         }

         var60 = var4 instanceof MultiModeSetting;
      }

      Object var66;
      label94: {
         int var82 = var7;
         boolean var81 = var60;
         boolean var65 = var81;
         boolean var61 = var81;
         if (var82 == 0) {
            boolean var83 = var61;
            if (var83) {
               MultiModeSetting var100 = (MultiModeSetting)var4;
               StringBuilder var9 = new StringBuilder();
               MultiModeSetting var30 = var100;
               String[] var10 = var30.aReturningArrayOfString();
               int var11 = var10.length;
               String var63;
               while (true) {
                  int var85 = var11;
                  int var84 = var12;
                  if (var84 < var85) {
                     String var13 = var10[var12];
                     int var87 = var7;
                     String var86 = var13;
                     var63 = var86;
                     String var62 = var86;
                     if (var87 != 0) {
                        break;
                     }

                     label74: {
                        String var31 = var62;
                        boolean var88 = var31.isEmpty();
                        if (var88) {
                           int var89 = var7;
                           if (var89 == 0) {
                              break label74;
                           }
                        }

                        String var35 = var13;
                        StringBuilder var34 = var9;
                        StringBuilder var105 = var34.append(var35);
                        String var37 = ".";
                        StringBuilder var36 = var105;
                        StringBuilder var106 = var36.append(var37);
                        Object[] var39 = new Object[]{var13, var5};
                        MultiModeSetting var38 = var100;
                        boolean var41 = var38.aReturningBoolean(var39);
                        StringBuilder var40 = var106;
                        StringBuilder var107 = var40.append(var41);
                        String var43 = "&";
                        StringBuilder var42 = var107;
                        var42.append(var43);
                     }

                     var12++;
                     int var90 = var7;
                     if (var90 == 0) {
                        continue;
                     }
                  }

                  StringBuilder var45 = var9;
                  var63 = var45.toString();
                  break;
               }

               return var63;
            }

            int var92 = var7;
            SettingDefinition var91 = var4;
            var66 = var91;
            SettingDefinition var64 = var91;
            if (var92 != 0) {
               break label94;
            }

            boolean var93 = var64 instanceof MinMaxSetting;
            var65 = var93;
         }

         boolean var94 = var65;
         if (var94) {
            MinMaxSetting var8 = (MinMaxSetting)var4;
            MinMaxSetting var47 = var8;
            float var104 = var47.aReturningVoid();
            MinMaxSetting var48 = var8;
            return var104 + "|" + var48.bReturningVoid();
         }

         SettingDefinition var49 = var4;
         var66 = var49.aReturningObject();
      }

      Object var99 = var66;
      int var96 = var7;
      Object var95 = var99;
      Object var68 = var95;
      Object var67 = var95;
      if (var96 == 0) {
         Object var97 = var67;
         if (var97 == null) {
            short var10002 = 10759;
            long var10003 = 6873986216400102927L ^ var2;
            throw new IllegalStateException("value is null");
         }

         var68 = var99;
      }

      Object var52 = var68;
      return var52.toString();
   }

   private static void iReturningVoid(Object[] var0) {
      long var4;
      int var8;
      ConfigLoadStatistics var36;
      label66: {
         ConfigLoadStatistics var1 = (ConfigLoadStatistics)var0[0];
         long var2 = (Long)var0[1];
         var2 = 94490381836703L ^ var2;
         var4 = var2 ^ 49377040373898L;
         long var6 = var2 ^ 72658170794125L;
         var8 = Event.bReturningInt();
         short var10000 = 17866;
         long var10001 = 6495413597203216432L ^ var2;
         String var12 = var1.recoveryAccess_read_a();
         String var11 = "load";
         boolean var64 = var11.equals(var12);
         int var43 = var8;
         boolean var42 = var64;
         boolean var33 = var42;
         boolean var30 = var42;
         if (var43 == 0) {
            boolean var44 = var30;
            if (var44) {
               return;
            }

            int var46 = var8;
            ConfigLoadStatistics var45 = var1;
            var36 = var45;
            ConfigLoadStatistics var31 = var45;
            if (var46 != 0) {
               break label66;
            }

            ConfigLoadStatistics var47 = var31;
            ConfigLoadStatistics var32 = var47;
            Object[] var16 = new Object[]{var6};
            ConfigLoadStatistics var15 = var32;
            boolean var48 = var15.recoveryAccess_call_aReturningBoolean(var16);
            var33 = var48;
         }

         boolean var49 = var33;
         if (!var49) {
            int var51 = var8;
            ConfigLoadStatistics var50 = var1;
            var36 = var50;
            ConfigLoadStatistics var34 = var50;
            if (var51 != 0) {
               break label66;
            }

            ConfigLoadStatistics var52 = var34;
            ConfigLoadStatistics var35 = var52;
            int var53 = var35.recoveryAccess_read_e();
            if (var53 == 0) {
               return;
            }
         }

         var36 = var1;
      }

      Runnable var9 = invokeBinding1(var36);

      try {
         label68: {
            MinecraftClient var10 = MinecraftClient.getInstance();
            int var55 = var8;
            MinecraftClient var54 = var10;
            MinecraftClient var38 = var54;
            MinecraftClient var37 = var54;
            if (var55 == 0) {
               MinecraftClient var56 = var37;
               if (var56 == null) {
                  break label68;
               }

               var38 = var10;
            }

            int var58 = var8;
            MinecraftClient var57 = var38;
            MinecraftClient var40 = var57;
            MinecraftClient var39 = var57;
            if (var58 == 0) {
               MinecraftClient var22 = var39;
               boolean var59 = var22.isOnThread();
               if (var59) {
                  break label68;
               }

               MinecraftClient var60 = var10;
               var40 = var60;
            }

            Runnable var26 = var9;
            MinecraftClient var25 = var40;
            var25.execute(var26);
            int var61 = var8;
            if (var61 == 0) {
               return;
            }
         }

         Runnable var27 = var9;
         var27.run();
      } catch (Throwable var62) {
         Object[] var29 = new Object[]{var62, var4};
         jReturningVoid(var29);
      }
   }

   public static String cReturningString(Object[] var0) {
      int var3 = (Integer)var0[0];
      int var2 = (Integer)var0[1];
      int var1 = (Integer)var0[2];
      String var4 = (String)var0[3];
      long var5 = (Long)var0[4];
      var5 = 94490381836703L ^ var5;
      String var7 = var4;
      int var8 = var1;
      int var9 = var2;
      short var10001 = 32529;
      long var10002 = 7470149110385388225L ^ var5;
      short var10003 = 20771;
      long var10004 = 5460927522850571514L ^ var5;
      return var3 + " errors, " + var9 + " skipped, " + var8 + " " + var7;
   }

   private static String dReturningString(Object[] var0) {
      Throwable var1 = (Throwable)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 94490381836703L ^ var2;
      int var25 = Event.cReturningInt();
      Throwable var6 = var1;
      String var5 = var6.getMessage();
      int var4 = var25;
      int var18 = var4;
      String var17 = var5;
      String var15 = var17;
      String var12 = var17;
      if (var18 != 0) {
         String var19 = var12;
         label23:
         if (var19 != null) {
            int var21 = var4;
            String var20 = var5;
            String var16 = var20;
            String var13 = var20;
            if (var21 != 0) {
               String var22 = var13;
               String var14 = var22;
               String var9 = var14;
               boolean var23 = var9.isBlank();
               if (var23) {
                  break label23;
               }

               var16 = var5;
            }

            return var16;
         }

         Class var11 = var1.getClass();
         String var24 = var11.getSimpleName();
         var15 = var24;
      }

      return var15;
   }

   private static void jReturningVoid(Object[] var0) {
      Throwable var1 = (Throwable)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 94490381836703L ^ var2;
      int var4 = Event.cReturningInt();
      boolean var21 = var1 instanceof ThreadDeath;
      int var14 = var4;
      boolean var13 = var21;
      boolean var10 = var13;
      boolean var9 = var13;
      if (var14 != 0) {
         boolean var15 = var9;
         if (var15) {
            ThreadDeath var20 = (ThreadDeath)var1;
            throw var20;
         }

         var10 = var1 instanceof VirtualMachineError;
      }

      int var17 = var4;
      boolean var16 = var10;
      boolean var12 = var16;
      boolean var11 = var16;
      if (var17 != 0) {
         boolean var18 = var11;
         if (var18) {
            VirtualMachineError var5 = (VirtualMachineError)var1;
            throw var5;
         }

         var12 = var1 instanceof InterruptedException;
      }

      boolean var19 = var12;
      if (var19) {
         Thread var8 = Thread.currentThread();
         var8.interrupt();
      }
   }

   private static void lambda$publishReport$0(ConfigLoadStatistics var0) {
      long var10001 = 22492542838979L ^ 129040550116247L;
      var10001 = 22492542838979L ^ 110783140259533L;
      int var7 = Event.bReturningInt();
      NotificationManager var66 = Prestige.v;
      if (var66 != null) {
         int var68 = var7;
         String var67 = "load";
         String var21 = var67;
         String var20 = var67;
         String var22;
         if (var68 == 0) {
            String var11 = var0.recoveryAccess_read_a();
            String var10 = var20;
            boolean var69 = var10.equals(var11);
            if (var69) {
               String var70 = "loaded";
               var22 = var70;
            } else {
               var22 = "saved";
            }
         } else {
            String var71 = var21;
            var22 = var71;
         }

         NotificationManager var60;
         String var61;
         String var62;
         long var63;
         NotificationType var65;
         label28: {
            String var8 = var22;
            NotificationManager var10000 = Prestige.v;
            String var109 = "Config " + var8;
            int var10002 = var0.recoveryAccess_read_d();
            int var10003 = var0.recoveryAccess_read_e();
            int var10004 = var0.recoveryAccess_read_b();
            Object[] var10008 = new Object[]{null, null, null, var8, 123923794382350L};
            var10008[2] = var10004;
            var10008[1] = var10003;
            var10008[0] = var10002;
            Object[] var14 = var10008;
            String var110 = cReturningString(var14);
            int var78 = var7;
            int var77 = var0.recoveryAccess_read_d();
            long var75 = m;
            String var74 = var110;
            String var73 = var109;
            NotificationManager var72 = var10000;
            NotificationManager var44 = var72;
            String var45 = var73;
            String var46 = var74;
            long var47 = var75;
            int var49 = var77;
            NotificationManager var23 = var72;
            String var24 = var73;
            String var25 = var74;
            long var26 = var75;
            int var28 = var77;
            if (var78 == 0) {
               int var84 = var28;
               long var82 = var26;
               String var81 = var25;
               String var80 = var24;
               NotificationManager var79 = var23;
               NotificationManager var39 = var79;
               String var40 = var80;
               String var41 = var81;
               long var42 = var82;
               NotificationManager var29 = var79;
               String var30 = var80;
               String var31 = var81;
               long var32 = var82;
               if (var84 > 0) {
                  long var88 = var32;
                  String var87 = var31;
                  String var86 = var30;
                  NotificationManager var85 = var29;
                  NotificationManager var34 = var85;
                  String var35 = var86;
                  String var36 = var87;
                  long var37 = var88;
                  NotificationType var95 = NotificationType.ERROR;
                  long var93 = var37;
                  String var92 = var36;
                  String var91 = var35;
                  NotificationManager var90 = var34;
                  var60 = var90;
                  var61 = var91;
                  var62 = var92;
                  var63 = var93;
                  var65 = var95;
                  break label28;
               }

               var49 = var0.recoveryAccess_read_e();
               var47 = var42;
               var46 = var41;
               var45 = var40;
               var44 = var39;
            }

            int var101 = var49;
            long var99 = var47;
            String var98 = var46;
            String var97 = var45;
            NotificationManager var96 = var44;
            NotificationManager var55 = var96;
            String var56 = var97;
            String var57 = var98;
            long var58 = var99;
            NotificationManager var50 = var96;
            String var51 = var97;
            String var52 = var98;
            long var53 = var99;
            if (var101 > 0) {
               NotificationType var107 = NotificationType.WARNING;
               long var105 = var53;
               String var104 = var52;
               String var103 = var51;
               NotificationManager var102 = var50;
               var60 = var102;
               var61 = var103;
               var62 = var104;
               var63 = var105;
               var65 = var107;
            } else {
               var65 = NotificationType.SUCCESS;
               var63 = var58;
               var62 = var57;
               var61 = var56;
               var60 = var55;
            }
         }

         Object[] var10007 = new Object[]{null, null, null, var65, 106826240627540L};
         var10007[2] = var63;
         var10007[1] = var62;
         var10007[0] = var61;
         Object[] var19 = var10007;
         NotificationManager var18 = var60;
         var18.aReturningVoid(var19);
      }
   }

   static {

      {

      c();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(54128590364168L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[88];
      String var22 = "\u000bÓØ\u0093\u0010?xÂ\n\u0081%û·\u0085=¿C£\\\u009bç§ kìÓ`³\f±\u007fùtÄRwO\u0010\u0002\u009c2DD|§\u0092Ê\u0090\u0010\u00131\u0006\u0014½M¢¼»\u0011@¦ÂµÎ¿0\u0097\u009f]u\u0014\u007f\u00195 ï\u009aö3iÝ\r\u000fK£_°5À«Üû\u0099{\u0010\u0000ADëÃ\u009aIéÁ³Ô\u0081\u0081\u001eHü\u0082¾ãP\u009c¤Â\u0098\u0085OJF)X,õ\u001a\u0013 0\u008b3 ÌZþ>\u0002Êh¾ù±\u00160£/\u008bANg\u0018ÂðÅ+\u0018¡DVlÂþ\u0099êT¥êc\u0083$Ôß\u0015\u001câ\\[C\u0080x<jÒ+VZ}}³þâIZ .(ÔwcöÙÅÔ\u0002Á.\u0004Çª!\u0093tó% TÖá¿^\u000fÐ\u009f6\f\u001dP~¯×M§SUy#\u0089\u0080Ï\u008b\u001c\u0003\u0082ÇíD\u0087\u0094w-ö\u008c\u008c\u008fÈ\u000b\u0093^Å\u0097\u0016á\u0002\u0007à\n\u0003\u001e\u000fÊÛ¦ú)\u0015\u000f\u0002ç_æ\u0091cT\u0081Òr4®Qk´¬\u0019æ<º\u0090\u0092\u001bW\u0083\n\t¿\u009aó¡X\u0007am¨\u0087¢\u0002\u0097ÆpN\"E£ï²µ^§\u0005Úv&{Q\u009fK-oþ¨\u0012\b+\u008e;@µ·bq¼\u0006\u00840ïI8ît\u0088\u0099\u0092\u0005u¼¦ÞK«îÀ§\u001eá&-nÁ\u0083+9\u0081\u0085³\u0094$\u008d||~j\u0087\u0082[Q8ßH/VXÁ \u0096³=\u008aza+Q°\u0013\u0080o1þ\u0084\u008d\u0096{ãÁÀC$Ã\u0088-Ä\u001aÐ¬ ~ßxÕ\u0099\u0093Ï\u008f`e\u0000\u0015D4c\u0097?¦\u000fTØ\u000e\u0089\u0093Àö\b\u0095\u0090f\u0094\u0003C\b\u0099ÜHþ9\u008d\u008c-p\u008c\u0014\u0019\u0010ô\u0088\u0017§5nJq\u008d\u0083¶\u000b\u0098D<J¼í>¶¶\tÉK\u0013\u009f\u0090\u009e\u0083®(øÆ¬\u0011:P\u009eõÏ¦\u0010<\u0081\u009f±V#l(\u0001fóDùñÂJ\u0001Î\u0099Ñ8[S\u0090ûNÅ\bNrz@º¦p2d \u008e:\u00991Ê\u0012Û\u000bm\u00ad^\u0085|\u0095\u0002\u008a\u0098CÂ=T[øFËçZ~¹\u00807D\u0093f¤ÙU|þ0ÿÖó,\u0081Ñaôh#\u00866¶@\u0013e\u001f^/\u0097\u0097E\u0083\u009c\u0091g\u0093\u0086$ÙØK' \u0005\u0013\u0092iP,\u0087Þ\u0010~\u0013î»U8q!\u0018\u008f\u008eNJ\tï¯ß3v\u0090Z\u0015\u0017\u00adn\\q2c.ü \u0098\"\u009d4i|G\u00132«ø &\u001cG\u0011ëÑî\u009d\u0018%Î\u009fâ Bß±\u0016@¡\u00142.\rzÂ\u0091åëÎ¼º\u0095Þ\u0083&0\u0000ø0Ù\u000b¿5Â\u0085l[¥óKnJbn=pEñbÄ\u00ad?)\u0000¢5ÓLBûEõá+ý\u008a1\u0017^7\u0002\u007fXE<Ù\u009e°\rý1þ»VM\"\u0001\u009a\u009b\u0091¦\u0082\u0015¾\u0097\u009aóoø÷\u001e\u0097J\u0080%cëx\u008fp \u0092Eí¹ËÉÞ\u0016h\u000b*\u0084 oÜÕI\rÂßeÉa\u0014\u0095þ\u0099çd\u0010 èÓª»ÑÓHão\u0083ÑZ®û\u009a«\n¶è \u001e'tÇ\u009f}\u00ad\u009b»Ør:\u001cç!\u0000AÊþ\u0099K[M\u009fu\u0007\u0003ÄFmây\u0010+´a·ä¶KÅíZtì\u0007\u0087nZ@¬\u001bÑÀ¥áì\u00036ã\u0094\u0014ô\u0084\u0084H\u0004¤£\u001bÿÁÚÉxi\r`æ¿\u008a¦¨\u0017å\u0093öõ¾Íº²ë\u0096P\b]«vCúxUã<®,;\u001fáz3¦Í\u00101J«\u0003Î?WN¼eá~\u0001+vX\u0010zÊþ¤iÔ\u0012gÇÚ\f·ûõåÞ\u0018fk»\u001d\u009b)}GDÀR\u0095\u0018a\u0088*á!\u0019(Æå\u0086¤8áT\u0013uî,\u0088$]\u0005\u0099\u009c{ô\u0098\u009dï\u0099°µ \u0080µbðo%Õ>¤M\u001fQ;lÓ*hÈ¯\u009bL<8\u0098¶¢\u008aó»\u0099|OÎÎ\u0004@ü\n¯Jd\u0082V1\u0019ê<9\t9+¹½s¸\u001d\u0088BY®Hû':\u000e\u0088D-t7\u0002V\nA!å\u0098+WÔE,.\u001a\u00843°Lg\u0014º¤NxFskÄe?\u0010\u0010nn\u0014y\t#¥Ñ\u008d\u0014ü\u008674° Ð)\u0081Ä@JõÓ\u0003\u008eÕ¢ýÈû¤³:¾(¦bÇñ?j32árñf0 :ÁlpA\u0003\u0001\u008a\u0007É¬\u0017X\n:rÃ\u0011Wvô\u0091e\u0012k(\u007f¤,\u00849§y0C\u0016\u0086Ôì¡-\u00adÊ\u000b\u0099\u0084NHIr®\u009aÖ§uã\u0094\u0006Ø-;\u0015Ó³\u0012ßJîUîoãL\nÝ£yâb\u001b8Ñ\u001c\u0091\u007f\u0003C\u000eéâDÀî´äS\u001d>8\u0086áõê>-Ö\u008c\u0099´\u0098í\u0019\u0088¬â9ß¤iÃH\u0003\u001c\u0083\u0011\u0001ëú÷£zÖM\u008a\tb\u0085'£Liw\u008bA§#ë\u0002ÑäwIÍx(b5ý¼\u00adk\u001f3p(PZP\u009d\u001at+k\u008bÇ8/\\!Ï\u0016ÖJµÍ\u0000ö\u007fîÕ9?¿XS\u0011k\u009c\r\u0002\u0087\fJÜÜ\u0091\u0095\u001ehoaÀ\"ÑÍ+©¦[\u0002\u0000\u009d%Â\u0004Óú]ø®:3\u0000$[\u000f1\u008e\u008e0\u0010cê\u0081L+ØÈÖ^|nZc!\u001d¯\u0015L\u0012ÿ¬¤ÖÎÁxÝ^\u0095ð]¬ÄzQW\u000bÛ\u0000¨\u0003\u0010ßÍ¼å/íø=X\u008bÐª2Ì\u008bO(X¯ñuM\u0012«*hé#kðé+Ó\u0018>\"ì\u001e1¡jðõfgZNxÝ°J5|  \u000fy\u0010åÝ\u0013\r0K[çø¾Qr\toÁñ oüÁ\u0018\u0017\u0093ýBXM9Õ|©*êØzlDï-m\u0016\nÝ½^¤üÎÖ\u0010³½\u0015Äm\u0084Î\u008enÆ8Ñ\u008cÕ;ñ8Î*\\\u0095ó@À{8ØÖ§¶Q°\u0098ð*â\u0097\u0001\u0086\u008a\n\bÑÛ\u0005¥ôà¬ÿ4\\ëë\u0084\u0080jøÜä\u0000ÇN÷UõÃm9]ªçO8Oª$!¾õò«¥í\u0089õ\u0003Æ\u0019\u0081¿\u0089\u008b3\u0096\u00019µ½G^\u0081eR¨Ô\u009f¶c!©\b}ün@î+Ú¸þ1\u008f|+£\u009d\u0094öË`¤¢Ô4s5³\u0000,¾KÝ\u001dF*ë\u0011ú\u0082§\u001b¿\u0091\u000bd|çtL§àÏÊTý\u0082\u0017Kïh\u009cÈSÉ3Ùüý\u0015ÐÐj\u0090å³ì7\u00adp\u0087=\u0006\u0082é\u0086=\u0010w&øºã\u0002wÑÜOo¼´\u0080\fh]¸Ã¶0·ô\u0080Y\u00983ú\u00ad`Ñ\u000fø\u009c}L#&¤¢uÕ\u0011¬\u009c0\t\u00068\u0093ùÚÇJ*Ü\fB\u0086ÒìH8rÕ\u0080\u008c\u0012\u0095Þ{-+\t\u0001\u0095{d/\u00149&\u0086ª¥é\u0081Açæ\"Â\u0013ú¼Ý¶öõ-s\"æLæ\u001eV\u0087\u009al½\u009e\u0007\n-É\u001eÍÝyàÖC·½\u009e\u0010$=Î\u0013áR{bâ¦ë0\u0017ì®Á\u00185¾ÀwY*³\u0082)»Á¾\u009f±ó\u0017\u0090ÐìÈ\u0014\u0093à¾\u0010À+«?ñwHâv%ÿw¹\u0002à§XMå\u0010[uÛ§Öbq\u0018dðs¢Ô6%£ø\u001b\u0085\u0004Ìf3.üÖ\u001e\u0082\\LM\u0019[\u0084ì×g#\u0005¥<vX!FøõÑ\u0083»Ó¹Þ|æcÈ%\u009dZ\u0001!\u001c}\u0085¥ã|O\u0091ÑÖP#\u0007\u0081n\u009c]-¤\u0013´¬º\u0010\u000f´*¿\u0098\u00868V\u008fË³þ\u008b-\u0092\u0088\u0010\u0007¼Z;éìÐË\u009fÞ\u0083ÅK·\u0083\u008b\u0010\u001bë\u001eéÖ\u0098ve&Õ[Y·\u001b\u008f\u008b\u0010øv|Ë\u009c\u0098áLfis^\nìS\u0006\u0010¡Ïµ¦aS\u0014CÀ\u001c\u0080Ì\u0092\u009e¥?\u00188\u008f\u0081ß|ÚTÍ\u008bz^¯\u0095©h\u0015\u0088Ø¬ëqÿ«tHî\"ãóè7ª«å0[JÅ\u0087\u001f\\~î~»ØÂðA\u0094¢L=Ú\u001cx«Øñ¯¿³\u0090eì¥NÇjI&Ü6Kh±C\u0091NYÚ4`43f%\u0094Ï³Ä:6\u0006r\u0004\u001a ¿\u0086T\u001bn\"MÈù\u009f\u0005k4îï\u0087Î3W\u001aæ\u009eùGT\u0013c U«¨\u0095\u0010ÀglÛ×óÀz\u00119k¡ºà\b58\u009dy@^\u0084·rÛÄÕz\u0017èþ(h6v'fqz\r\u0016´°·\u0003\u008cp\u0092ð\u008a]¾cýEj{F\u0018´\u0010\u008cìÁ8±~ )ÊÏ!ß0\u0095\u001cÙ\b\rwQäýGÙÈÙÁÆ\u0019\u0096ìËË¨\u0018A\u009cF\u0088Ê\u0093¥3Ú)*\u008b\u0017|9Õh\u001fQS\u009d4\u001c\u0095ÿ\u0011\u0010÷^\u0080=-\u0011_/\nøëX\u000e=a\u0014@RpW\u009eZ\tÏóú×/z,Çét\u008a¡~ìÃ\u0010\u009fÉ\u0080R}õj\u0087\u0086,\u0095\u0017AÎ¸nÝFëy³\u0082&\u0083\u008e.ó\u0014\u0003æ\u0011\u001cØ\nÞ\u008aì \b \u009b `\u0013\u0082<þ\u008eO\u0018¨\u008bk4üÂ\u008dªì*\u008dVùìx%5Õ2aº<é\u009cXÁ§d\u001aG{\nâ\nÆÈ\u0082³iòu2B\u0010çk\u008dn\u0081{k\u0084=1ñ¹½\u007f\u001d³öãºNÚ\tdSe¶æþ$=E´Æ^\u008bû)\u009c\u0002\u0088Z?Ö<ñ\u0010\u001e4k¢\u0088;³\u000bl\u0088 \u009eau\u009e:\u00105ÄN\u0013ß¥\u000f\u00115'KÛwW¸\u008aPK\u0083\bR-í\u0080¥*6\u007fUE\u001c#\u00836\u001d°[\u009d\u00ad5s«¬ü¯w\u0089Ì4\u0095¢¾òÛî\u0005(úZtâ÷\u008aE{\u0015\u0097äÑ\u0097}$¡\u0095\u0010»ÄºØ1NjÌ=Ãþ\u008d¨)Vþø\u008a²yå\\\u0018\u009c,õzê\\ÅÇ¸\u008eÎU±Q#Ãt]=\nkYY¯(8$ò\u0006I½§Ú¢áVó\u008dù\n¯M¤\u0099ð\u0099\u0017ÝßÐ\u0019\u0016-%\u001e§\u0099æ¼\nI%\u0017Î \u0010\"¡<\u0082Ô/×Ñ©yq4¦ý&\u0000X\u0004¦\u0006¬ ª\u001eÐÔÊCu\u0011·HP½æP;\u008aÃ\u0087\u008b\u0007\u008aäW¾\u0095\u0090\r¬\u0084üö\u008d\u0084\u009eÓ\u0091øJu\n\u0012\u0005\u0095\bHì~He\u0088\u0082\u0081\u001aMÏ\u0091U?\u000eè\u0014Vã¶0\u001eÚ\u0085\u009dÎÅ*\u001b\u0092B0\u001dH\u0091\u0085\u008f^_\u0010z:\u001cc¨±Î^\fÁ\u001dc¹\\ÖM0\u00ad6\u009c\fí>w\\:¡F\u0004óÜ+i?!\u0098|v\u009c\u0091lËò!üª:\u000b \u0011#T\u0018Yqø\u0099õq\u001c\f:öù= ÊÄó\b\u001f\u0085Ú½à¶må:\u009d\u001dêÜ\u008a·«1\u009axQ:±5\u008c\u0014ñ\u001e\u0093X\u0004[5{\u009cÊ\u0091\n\u001cÄc]¢#Ã\u0099\u0018\u0014\u0083B^íVxTEã ¬N\t m\u0002óÛñpçÄ6\u0016»\u0012\u0012äiÜW\u009cZ\u0010¹s'\u001eÎâ\u0012cbÕ\u001eSDó»Z·À\u0003a\u0016Ì\u00adç¼hYÄ e5p\u0085·\\P\u0010ÐåÆúà\u0088èº>1\u001f\u0007\u0004)ïWHÑLÃ\u0002üªî\u0092FÞyH\u008báB\u0016\u0017íw³úÇ\u009d\u009c\u001còêïàç\u0000¾.\teþOÎ¡å\t%j\u008cu\u0088}V\u009db#\u0089n\u009e\u008d!åêËB\u008f:\u009d¶O\n¦öHÈ)À\u0010(\u0094\u0007IÙÈêï+ §Mm{·0`&Väm°g.\u0010A\u001c\u0098?zUÝÇ,ÇÚ¥\u009fVÿr\"\u0004ÚÁ\u0015ê¦Ì\tU\u0095\u0007³¼Î\u008f¦o\u0007À:ö`Î+Ú*µ§òKr· |êù¼Õ`úd7Ñ<M\u00987½2³7\u008aä<9íQ?ç\u007fö¬å\u009c\u000be7\u0012B\u0089¾\u0010\u00ad©¯\u0019\u00107¶À\f\u0081º\u0082Ùï\u0012T ¯}¢t'\u0098i\u009d9*¹\f\u0091>)«qÿ¶=ªíxssç_e\u0016ýG\u009c\u0010îÿEP\u0097ºÀ\u001cÄ ^L\u001fÿ\u000e\u008dX\u001a\u0016Á¥p1k³ÊOq¬]{\u009c-î\u008aí\u009a\u009eëà¸>o\u001e\u0091q¹\u0095\u001f\u000fÞ'Æ;\u0081Øú\u0001\u001f\u0089\u0013\u009doØ\u0006QDd\u0014<¸»ü\u007f\u0080a¡Û®3±)dñü\u00ad\u0084Ï\u009b/¥\u0007OPýÚq\"1ë\u001d§\u0011u|\u0010ç/;9sL»\u007fì}\u0003ö·¡²\u00960ópü\u000b\u001f\u009eú\u0097È+\u0004Ñÿ\u000fQÑûWÙ\u001eÏ\u0097Z\u009fþ+Þ\u0086µ\u0099²W\u001b4dý>ºº\u001c¾PÅ\u009dg.2G\u0010,ia\u008c\u0096!\u0083í\u009a\u008f,v\u0095òÔ\u009e8¼\u000b_\u0005\u001eÜ^\u0098'Õy\u0092 Æå\u0090$n=_Z @i§V rÄ~\u008e\u009e\u001aoÎ\u008b\u0097\u0005¸\u001dÁ{a\u000b\u0089Y\u000fRx£{dçå(-\u0018<y@Ö]^\u0088×\u001f\fò;¤\u00948\u0010óöÓW3.Í(\u0010;\u0082@ÉiÁ´`;k\u008e·\u0012\u001c4\u007f\u0010\u0096ñ\u0000X¯·\u001f{\")\u00813×§¡#\u0018¡F\u0015`\u008bî\u0095'ð.\u0094\u001eÍXòDö\u009a`¶JR}/\u0010 ;A\u001c©(Í\u0016]EæÎï\u0095\u001eÛ \u0016;QÖóÙ\u0094{1+ùÊ+Õ[3\f°\u008e@\u00058ª\u0090½î&h\u0081éÍex§\u0006×\u0098¨Yfâórfé\tµÔÿAà\u0080ª'5îï´å¤mdgò\u0091<2\u0004¦\u0088\u0096Wô\u0000'`\u000fr\u0015\u0012\u001e\u0095H61Tß\u001d\n*·w\u0096¥¢aqÎìè\u0014\u001f\u001aÙm¡gÏ'Ã\u0095Û\u008c\u0097\u000bò\u0096\u001a[aï¼þ\u0098Oµ\u0011W×Ý#\u007fC$\u0086\u008dDYyïn;¦½ôZv\u009fù\u0081õH2\u0010\u008a\u0084ï©í4¤ÅÕÙQÐCÏ»\u0091";
      int var24 = "\u000bÓØ\u0093\u0010?xÂ\n\u0081%û·\u0085=¿C£\\\u009bç§ kìÓ`³\f±\u007fùtÄRwO\u0010\u0002\u009c2DD|§\u0092Ê\u0090\u0010\u00131\u0006\u0014½M¢¼»\u0011@¦ÂµÎ¿0\u0097\u009f]u\u0014\u007f\u00195 ï\u009aö3iÝ\r\u000fK£_°5À«Üû\u0099{\u0010\u0000ADëÃ\u009aIéÁ³Ô\u0081\u0081\u001eHü\u0082¾ãP\u009c¤Â\u0098\u0085OJF)X,õ\u001a\u0013 0\u008b3 ÌZþ>\u0002Êh¾ù±\u00160£/\u008bANg\u0018ÂðÅ+\u0018¡DVlÂþ\u0099êT¥êc\u0083$Ôß\u0015\u001câ\\[C\u0080x<jÒ+VZ}}³þâIZ .(ÔwcöÙÅÔ\u0002Á.\u0004Çª!\u0093tó% TÖá¿^\u000fÐ\u009f6\f\u001dP~¯×M§SUy#\u0089\u0080Ï\u008b\u001c\u0003\u0082ÇíD\u0087\u0094w-ö\u008c\u008c\u008fÈ\u000b\u0093^Å\u0097\u0016á\u0002\u0007à\n\u0003\u001e\u000fÊÛ¦ú)\u0015\u000f\u0002ç_æ\u0091cT\u0081Òr4®Qk´¬\u0019æ<º\u0090\u0092\u001bW\u0083\n\t¿\u009aó¡X\u0007am¨\u0087¢\u0002\u0097ÆpN\"E£ï²µ^§\u0005Úv&{Q\u009fK-oþ¨\u0012\b+\u008e;@µ·bq¼\u0006\u00840ïI8ît\u0088\u0099\u0092\u0005u¼¦ÞK«îÀ§\u001eá&-nÁ\u0083+9\u0081\u0085³\u0094$\u008d||~j\u0087\u0082[Q8ßH/VXÁ \u0096³=\u008aza+Q°\u0013\u0080o1þ\u0084\u008d\u0096{ãÁÀC$Ã\u0088-Ä\u001aÐ¬ ~ßxÕ\u0099\u0093Ï\u008f`e\u0000\u0015D4c\u0097?¦\u000fTØ\u000e\u0089\u0093Àö\b\u0095\u0090f\u0094\u0003C\b\u0099ÜHþ9\u008d\u008c-p\u008c\u0014\u0019\u0010ô\u0088\u0017§5nJq\u008d\u0083¶\u000b\u0098D<J¼í>¶¶\tÉK\u0013\u009f\u0090\u009e\u0083®(øÆ¬\u0011:P\u009eõÏ¦\u0010<\u0081\u009f±V#l(\u0001fóDùñÂJ\u0001Î\u0099Ñ8[S\u0090ûNÅ\bNrz@º¦p2d \u008e:\u00991Ê\u0012Û\u000bm\u00ad^\u0085|\u0095\u0002\u008a\u0098CÂ=T[øFËçZ~¹\u00807D\u0093f¤ÙU|þ0ÿÖó,\u0081Ñaôh#\u00866¶@\u0013e\u001f^/\u0097\u0097E\u0083\u009c\u0091g\u0093\u0086$ÙØK' \u0005\u0013\u0092iP,\u0087Þ\u0010~\u0013î»U8q!\u0018\u008f\u008eNJ\tï¯ß3v\u0090Z\u0015\u0017\u00adn\\q2c.ü \u0098\"\u009d4i|G\u00132«ø &\u001cG\u0011ëÑî\u009d\u0018%Î\u009fâ Bß±\u0016@¡\u00142.\rzÂ\u0091åëÎ¼º\u0095Þ\u0083&0\u0000ø0Ù\u000b¿5Â\u0085l[¥óKnJbn=pEñbÄ\u00ad?)\u0000¢5ÓLBûEõá+ý\u008a1\u0017^7\u0002\u007fXE<Ù\u009e°\rý1þ»VM\"\u0001\u009a\u009b\u0091¦\u0082\u0015¾\u0097\u009aóoø÷\u001e\u0097J\u0080%cëx\u008fp \u0092Eí¹ËÉÞ\u0016h\u000b*\u0084 oÜÕI\rÂßeÉa\u0014\u0095þ\u0099çd\u0010 èÓª»ÑÓHão\u0083ÑZ®û\u009a«\n¶è \u001e'tÇ\u009f}\u00ad\u009b»Ør:\u001cç!\u0000AÊþ\u0099K[M\u009fu\u0007\u0003ÄFmây\u0010+´a·ä¶KÅíZtì\u0007\u0087nZ@¬\u001bÑÀ¥áì\u00036ã\u0094\u0014ô\u0084\u0084H\u0004¤£\u001bÿÁÚÉxi\r`æ¿\u008a¦¨\u0017å\u0093öõ¾Íº²ë\u0096P\b]«vCúxUã<®,;\u001fáz3¦Í\u00101J«\u0003Î?WN¼eá~\u0001+vX\u0010zÊþ¤iÔ\u0012gÇÚ\f·ûõåÞ\u0018fk»\u001d\u009b)}GDÀR\u0095\u0018a\u0088*á!\u0019(Æå\u0086¤8áT\u0013uî,\u0088$]\u0005\u0099\u009c{ô\u0098\u009dï\u0099°µ \u0080µbðo%Õ>¤M\u001fQ;lÓ*hÈ¯\u009bL<8\u0098¶¢\u008aó»\u0099|OÎÎ\u0004@ü\n¯Jd\u0082V1\u0019ê<9\t9+¹½s¸\u001d\u0088BY®Hû':\u000e\u0088D-t7\u0002V\nA!å\u0098+WÔE,.\u001a\u00843°Lg\u0014º¤NxFskÄe?\u0010\u0010nn\u0014y\t#¥Ñ\u008d\u0014ü\u008674° Ð)\u0081Ä@JõÓ\u0003\u008eÕ¢ýÈû¤³:¾(¦bÇñ?j32árñf0 :ÁlpA\u0003\u0001\u008a\u0007É¬\u0017X\n:rÃ\u0011Wvô\u0091e\u0012k(\u007f¤,\u00849§y0C\u0016\u0086Ôì¡-\u00adÊ\u000b\u0099\u0084NHIr®\u009aÖ§uã\u0094\u0006Ø-;\u0015Ó³\u0012ßJîUîoãL\nÝ£yâb\u001b8Ñ\u001c\u0091\u007f\u0003C\u000eéâDÀî´äS\u001d>8\u0086áõê>-Ö\u008c\u0099´\u0098í\u0019\u0088¬â9ß¤iÃH\u0003\u001c\u0083\u0011\u0001ëú÷£zÖM\u008a\tb\u0085'£Liw\u008bA§#ë\u0002ÑäwIÍx(b5ý¼\u00adk\u001f3p(PZP\u009d\u001at+k\u008bÇ8/\\!Ï\u0016ÖJµÍ\u0000ö\u007fîÕ9?¿XS\u0011k\u009c\r\u0002\u0087\fJÜÜ\u0091\u0095\u001ehoaÀ\"ÑÍ+©¦[\u0002\u0000\u009d%Â\u0004Óú]ø®:3\u0000$[\u000f1\u008e\u008e0\u0010cê\u0081L+ØÈÖ^|nZc!\u001d¯\u0015L\u0012ÿ¬¤ÖÎÁxÝ^\u0095ð]¬ÄzQW\u000bÛ\u0000¨\u0003\u0010ßÍ¼å/íø=X\u008bÐª2Ì\u008bO(X¯ñuM\u0012«*hé#kðé+Ó\u0018>\"ì\u001e1¡jðõfgZNxÝ°J5|  \u000fy\u0010åÝ\u0013\r0K[çø¾Qr\toÁñ oüÁ\u0018\u0017\u0093ýBXM9Õ|©*êØzlDï-m\u0016\nÝ½^¤üÎÖ\u0010³½\u0015Äm\u0084Î\u008enÆ8Ñ\u008cÕ;ñ8Î*\\\u0095ó@À{8ØÖ§¶Q°\u0098ð*â\u0097\u0001\u0086\u008a\n\bÑÛ\u0005¥ôà¬ÿ4\\ëë\u0084\u0080jøÜä\u0000ÇN÷UõÃm9]ªçO8Oª$!¾õò«¥í\u0089õ\u0003Æ\u0019\u0081¿\u0089\u008b3\u0096\u00019µ½G^\u0081eR¨Ô\u009f¶c!©\b}ün@î+Ú¸þ1\u008f|+£\u009d\u0094öË`¤¢Ô4s5³\u0000,¾KÝ\u001dF*ë\u0011ú\u0082§\u001b¿\u0091\u000bd|çtL§àÏÊTý\u0082\u0017Kïh\u009cÈSÉ3Ùüý\u0015ÐÐj\u0090å³ì7\u00adp\u0087=\u0006\u0082é\u0086=\u0010w&øºã\u0002wÑÜOo¼´\u0080\fh]¸Ã¶0·ô\u0080Y\u00983ú\u00ad`Ñ\u000fø\u009c}L#&¤¢uÕ\u0011¬\u009c0\t\u00068\u0093ùÚÇJ*Ü\fB\u0086ÒìH8rÕ\u0080\u008c\u0012\u0095Þ{-+\t\u0001\u0095{d/\u00149&\u0086ª¥é\u0081Açæ\"Â\u0013ú¼Ý¶öõ-s\"æLæ\u001eV\u0087\u009al½\u009e\u0007\n-É\u001eÍÝyàÖC·½\u009e\u0010$=Î\u0013áR{bâ¦ë0\u0017ì®Á\u00185¾ÀwY*³\u0082)»Á¾\u009f±ó\u0017\u0090ÐìÈ\u0014\u0093à¾\u0010À+«?ñwHâv%ÿw¹\u0002à§XMå\u0010[uÛ§Öbq\u0018dðs¢Ô6%£ø\u001b\u0085\u0004Ìf3.üÖ\u001e\u0082\\LM\u0019[\u0084ì×g#\u0005¥<vX!FøõÑ\u0083»Ó¹Þ|æcÈ%\u009dZ\u0001!\u001c}\u0085¥ã|O\u0091ÑÖP#\u0007\u0081n\u009c]-¤\u0013´¬º\u0010\u000f´*¿\u0098\u00868V\u008fË³þ\u008b-\u0092\u0088\u0010\u0007¼Z;éìÐË\u009fÞ\u0083ÅK·\u0083\u008b\u0010\u001bë\u001eéÖ\u0098ve&Õ[Y·\u001b\u008f\u008b\u0010øv|Ë\u009c\u0098áLfis^\nìS\u0006\u0010¡Ïµ¦aS\u0014CÀ\u001c\u0080Ì\u0092\u009e¥?\u00188\u008f\u0081ß|ÚTÍ\u008bz^¯\u0095©h\u0015\u0088Ø¬ëqÿ«tHî\"ãóè7ª«å0[JÅ\u0087\u001f\\~î~»ØÂðA\u0094¢L=Ú\u001cx«Øñ¯¿³\u0090eì¥NÇjI&Ü6Kh±C\u0091NYÚ4`43f%\u0094Ï³Ä:6\u0006r\u0004\u001a ¿\u0086T\u001bn\"MÈù\u009f\u0005k4îï\u0087Î3W\u001aæ\u009eùGT\u0013c U«¨\u0095\u0010ÀglÛ×óÀz\u00119k¡ºà\b58\u009dy@^\u0084·rÛÄÕz\u0017èþ(h6v'fqz\r\u0016´°·\u0003\u008cp\u0092ð\u008a]¾cýEj{F\u0018´\u0010\u008cìÁ8±~ )ÊÏ!ß0\u0095\u001cÙ\b\rwQäýGÙÈÙÁÆ\u0019\u0096ìËË¨\u0018A\u009cF\u0088Ê\u0093¥3Ú)*\u008b\u0017|9Õh\u001fQS\u009d4\u001c\u0095ÿ\u0011\u0010÷^\u0080=-\u0011_/\nøëX\u000e=a\u0014@RpW\u009eZ\tÏóú×/z,Çét\u008a¡~ìÃ\u0010\u009fÉ\u0080R}õj\u0087\u0086,\u0095\u0017AÎ¸nÝFëy³\u0082&\u0083\u008e.ó\u0014\u0003æ\u0011\u001cØ\nÞ\u008aì \b \u009b `\u0013\u0082<þ\u008eO\u0018¨\u008bk4üÂ\u008dªì*\u008dVùìx%5Õ2aº<é\u009cXÁ§d\u001aG{\nâ\nÆÈ\u0082³iòu2B\u0010çk\u008dn\u0081{k\u0084=1ñ¹½\u007f\u001d³öãºNÚ\tdSe¶æþ$=E´Æ^\u008bû)\u009c\u0002\u0088Z?Ö<ñ\u0010\u001e4k¢\u0088;³\u000bl\u0088 \u009eau\u009e:\u00105ÄN\u0013ß¥\u000f\u00115'KÛwW¸\u008aPK\u0083\bR-í\u0080¥*6\u007fUE\u001c#\u00836\u001d°[\u009d\u00ad5s«¬ü¯w\u0089Ì4\u0095¢¾òÛî\u0005(úZtâ÷\u008aE{\u0015\u0097äÑ\u0097}$¡\u0095\u0010»ÄºØ1NjÌ=Ãþ\u008d¨)Vþø\u008a²yå\\\u0018\u009c,õzê\\ÅÇ¸\u008eÎU±Q#Ãt]=\nkYY¯(8$ò\u0006I½§Ú¢áVó\u008dù\n¯M¤\u0099ð\u0099\u0017ÝßÐ\u0019\u0016-%\u001e§\u0099æ¼\nI%\u0017Î \u0010\"¡<\u0082Ô/×Ñ©yq4¦ý&\u0000X\u0004¦\u0006¬ ª\u001eÐÔÊCu\u0011·HP½æP;\u008aÃ\u0087\u008b\u0007\u008aäW¾\u0095\u0090\r¬\u0084üö\u008d\u0084\u009eÓ\u0091øJu\n\u0012\u0005\u0095\bHì~He\u0088\u0082\u0081\u001aMÏ\u0091U?\u000eè\u0014Vã¶0\u001eÚ\u0085\u009dÎÅ*\u001b\u0092B0\u001dH\u0091\u0085\u008f^_\u0010z:\u001cc¨±Î^\fÁ\u001dc¹\\ÖM0\u00ad6\u009c\fí>w\\:¡F\u0004óÜ+i?!\u0098|v\u009c\u0091lËò!üª:\u000b \u0011#T\u0018Yqø\u0099õq\u001c\f:öù= ÊÄó\b\u001f\u0085Ú½à¶må:\u009d\u001dêÜ\u008a·«1\u009axQ:±5\u008c\u0014ñ\u001e\u0093X\u0004[5{\u009cÊ\u0091\n\u001cÄc]¢#Ã\u0099\u0018\u0014\u0083B^íVxTEã ¬N\t m\u0002óÛñpçÄ6\u0016»\u0012\u0012äiÜW\u009cZ\u0010¹s'\u001eÎâ\u0012cbÕ\u001eSDó»Z·À\u0003a\u0016Ì\u00adç¼hYÄ e5p\u0085·\\P\u0010ÐåÆúà\u0088èº>1\u001f\u0007\u0004)ïWHÑLÃ\u0002üªî\u0092FÞyH\u008báB\u0016\u0017íw³úÇ\u009d\u009c\u001còêïàç\u0000¾.\teþOÎ¡å\t%j\u008cu\u0088}V\u009db#\u0089n\u009e\u008d!åêËB\u008f:\u009d¶O\n¦öHÈ)À\u0010(\u0094\u0007IÙÈêï+ §Mm{·0`&Väm°g.\u0010A\u001c\u0098?zUÝÇ,ÇÚ¥\u009fVÿr\"\u0004ÚÁ\u0015ê¦Ì\tU\u0095\u0007³¼Î\u008f¦o\u0007À:ö`Î+Ú*µ§òKr· |êù¼Õ`úd7Ñ<M\u00987½2³7\u008aä<9íQ?ç\u007fö¬å\u009c\u000be7\u0012B\u0089¾\u0010\u00ad©¯\u0019\u00107¶À\f\u0081º\u0082Ùï\u0012T ¯}¢t'\u0098i\u009d9*¹\f\u0091>)«qÿ¶=ªíxssç_e\u0016ýG\u009c\u0010îÿEP\u0097ºÀ\u001cÄ ^L\u001fÿ\u000e\u008dX\u001a\u0016Á¥p1k³ÊOq¬]{\u009c-î\u008aí\u009a\u009eëà¸>o\u001e\u0091q¹\u0095\u001f\u000fÞ'Æ;\u0081Øú\u0001\u001f\u0089\u0013\u009doØ\u0006QDd\u0014<¸»ü\u007f\u0080a¡Û®3±)dñü\u00ad\u0084Ï\u009b/¥\u0007OPýÚq\"1ë\u001d§\u0011u|\u0010ç/;9sL»\u007fì}\u0003ö·¡²\u00960ópü\u000b\u001f\u009eú\u0097È+\u0004Ñÿ\u000fQÑûWÙ\u001eÏ\u0097Z\u009fþ+Þ\u0086µ\u0099²W\u001b4dý>ºº\u001c¾PÅ\u009dg.2G\u0010,ia\u008c\u0096!\u0083í\u009a\u008f,v\u0095òÔ\u009e8¼\u000b_\u0005\u001eÜ^\u0098'Õy\u0092 Æå\u0090$n=_Z @i§V rÄ~\u008e\u009e\u001aoÎ\u008b\u0097\u0005¸\u001dÁ{a\u000b\u0089Y\u000fRx£{dçå(-\u0018<y@Ö]^\u0088×\u001f\fò;¤\u00948\u0010óöÓW3.Í(\u0010;\u0082@ÉiÁ´`;k\u008e·\u0012\u001c4\u007f\u0010\u0096ñ\u0000X¯·\u001f{\")\u00813×§¡#\u0018¡F\u0015`\u008bî\u0095'ð.\u0094\u001eÍXòDö\u009a`¶JR}/\u0010 ;A\u001c©(Í\u0016]EæÎï\u0095\u001eÛ \u0016;QÖóÙ\u0094{1+ùÊ+Õ[3\f°\u008e@\u00058ª\u0090½î&h\u0081éÍex§\u0006×\u0098¨Yfâórfé\tµÔÿAà\u0080ª'5îï´å¤mdgò\u0091<2\u0004¦\u0088\u0096Wô\u0000'`\u000fr\u0015\u0012\u001e\u0095H61Tß\u001d\n*·w\u0096¥¢aqÎìè\u0014\u001f\u001aÙm¡gÏ'Ã\u0095Û\u008c\u0097\u000bò\u0096\u001a[aï¼þ\u0098Oµ\u0011W×Ý#\u007fC$\u0086\u008dDYyïn;¦½ôZv\u009fù\u0081õH2\u0010\u008a\u0084ï©í4¤ÅÕÙQÐCÏ»\u0091"
         .length();
      char var21 = '0';
      int var29 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var29, var29 + var21);
         int var10001 = -1;

         while (true) {
            byte[] var26 = var18.doFinal(var30.getBytes("ISO-8859-1"));
            String var44 = a(var26).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var44;
                  if ((var29 += var21) >= var24) {
                     g = var25;
                     h = new String[88];
                     l = new HashMap(13);
                     Cipher var5;
                     var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(54128590364168L << var6 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[12];
                     String var9 = "aÒ\u000eoÉ%a\u0081\u0087ic¢;F\u0017\u0013üehxIÚ\u0015²\u009f|\u0013#zr+¯\u0087?\u0088sY\u0081\u0082ö/ÉÉÇû¨é\u0003ÿ:XäãsÚL\tr\f{\u008b3¼ü$Ê\u0018éÐE×aÄ5\u0093\u0011Y-qÓ";
                     int var10 = "aÒ\u000eoÉ%a\u0081\u0087ic¢;F\u0017\u0013üehxIÚ\u0015²\u009f|\u0013#zr+¯\u0087?\u0088sY\u0081\u0082ö/ÉÉÇû¨é\u0003ÿ:XäãsÚL\tr\f{\u008b3¼ü$Ê\u0018éÐE×aÄ5\u0093\u0011Y-qÓ"
                        .length();
                     label46:
                     while (true) {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
                        long[] var33 = var11;
                        var10001 = var8++;
                        long var48 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        // while (true) {
                           long var13 = var48;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var56 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var33[var10001] = var56;
                                 if (var7 >= var10) {
                                    j = var11;
                                    k = new Integer[12];
                                    b = 100000;
                                    c = 64;
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(54128590364168L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long var41 = 8381281038517829196L;
                                    byte[] var4 = var0.doFinal(
                                       new byte[]{
                                          (byte)116L,
                                          (byte)29776L,
                                          (byte)7622730L,
                                          (byte)1951419058L,
                                          (byte)499563279063L,
                                          (byte)127888199440274L,
                                          (byte)32739379056710270L,
                                          (byte)8381281038517829196L
                                       }
                                    );
                                    long var51 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    // m = var51;
                                    a = new Gson();
                                    break;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var56;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = "MBA°HoZ\tÅ¡Î\u009fÍ\u009e\u0083s";
                                 var10 = "MBA°HoZ\tÅ¡Î\u009fÍ\u009e\u0083s".length();
                                 var7 = 0;
                           }

                           int var40 = var7;
                           var7 += 8;
                           var12 = var9.substring(var40, var7).getBytes("ISO-8859-1");
                           var33 = var11;
                           var10001 = var8++;
                           var48 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var29);
                  break;
               default:
                  var25[var23++] = var44;
                  if ((var29 += var21) < var24) {
                     var21 = var22.charAt(var29);
                     continue label64;
                  }

                  var22 = "Sá\u0086j!'fGæûÖ$è³5¹\tIz\\Ðüð7#yá~Q@/\\@à{é¿èuàp\u0085=¬\u008eJî\u0099\"÷\u0018]\u0012+îÁ\u0010\n\u001eÉbãìû\u009c'ÉÀâS\u009b\u000bN";
                  var24 = "Sá\u0086j!'fGæûÖ$è³5¹\tIz\\Ðüð7#yá~Q@/\\@à{é¿èuàp\u0085=¬\u008eJî\u0099\"÷\u0018]\u0012+îÁ\u0010\n\u001eÉbãìû\u009c'ÉÀâS\u009b\u000bN"
                     .length();
                  var21 = '8';
                  var29 = -1;
            }

            var30 = var22.substring(++var29, var29 + var21);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31238;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/at", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = g[var5].getBytes("ISO-8859-1");
         h[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/at_C0042",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/at" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27885;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])l.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               l.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/at", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/at_C0042",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/at" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = o[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = n[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 26;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 30;
            yield var20;
         }
         case 6 -> {
            byte var21 = 47;
            yield var21;
         }
         case 7 -> {
            byte var22 = 15;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 48;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 57;
            yield var26;
         }
         case 12 -> {
            byte var27 = 36;
            yield var27;
         }
         case 13 -> {
            byte var28 = 2;
            yield var28;
         }
         case 14 -> {
            byte var29 = 52;
            yield var29;
         }
         case 15 -> {
            byte var30 = 31;
            yield var30;
         }
         case 16 -> {
            byte var31 = 3;
            yield var31;
         }
         case 17 -> {
            byte var32 = 27;
            yield var32;
         }
         case 18 -> {
            byte var33 = 58;
            yield var33;
         }
         case 19 -> {
            byte var34 = 14;
            yield var34;
         }
         case 20 -> {
            byte var35 = 28;
            yield var35;
         }
         case 21 -> {
            byte var36 = 16;
            yield var36;
         }
         case 22 -> {
            byte var37 = 43;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 37;
            yield var39;
         }
         case 25 -> {
            byte var40 = 24;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 40;
            yield var42;
         }
         case 28 -> {
            byte var43 = 1;
            yield var43;
         }
         case 29 -> {
            byte var44 = 21;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 10;
            yield var46;
         }
         case 32 -> {
            byte var47 = 7;
            yield var47;
         }
         case 33 -> {
            byte var48 = 13;
            yield var48;
         }
         case 34 -> {
            byte var49 = 0;
            yield var49;
         }
         case 35 -> {
            byte var50 = 9;
            yield var50;
         }
         case 36 -> {
            byte var51 = 42;
            yield var51;
         }
         case 37 -> {
            byte var52 = 18;
            yield var52;
         }
         case 38 -> {
            byte var53 = 23;
            yield var53;
         }
         case 39 -> {
            byte var54 = 44;
            yield var54;
         }
         case 40 -> {
            byte var55 = 12;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 22;
            yield var58;
         }
         case 44 -> {
            byte var59 = 5;
            yield var59;
         }
         case 45 -> {
            byte var60 = 46;
            yield var60;
         }
         case 46 -> {
            byte var61 = 51;
            yield var61;
         }
         case 47 -> {
            byte var62 = 19;
            yield var62;
         }
         case 48 -> {
            byte var63 = 34;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 41;
            yield var66;
         }
         case 52 -> {
            byte var67 = 39;
            yield var67;
         }
         case 53 -> {
            byte var68 = 8;
            yield var68;
         }
         case 54 -> {
            byte var69 = 11;
            yield var69;
         }
         case 55 -> {
            byte var70 = 38;
            yield var70;
         }
         case 56 -> {
            byte var71 = 20;
            yield var71;
         }
         case 57 -> {
            byte var72 = 17;
            yield var72;
         }
         case 58 -> {
            byte var73 = 29;
            yield var73;
         }
         case 59 -> {
            byte var74 = 25;
            yield var74;
         }
         case 60 -> {
            byte var75 = 35;
            yield var75;
         }
         case 61 -> {
            byte var76 = 6;
            yield var76;
         }
         case 62 -> {
            byte var77 = 55;
            yield var77;
         }
         default -> 56;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            o[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      n[0] = "9S\th\u001f./S\f2\f98\u0018\u000f4\u0000-)_\u0018#K?)";
      n[1] = "e6<?ZR\u0010\u001670K\u001dq\u0018<;OG\u0005";
      n[2] = void.class;
      o[2] = "java/lang/Void";
      n[3] = "V[5/:e@[0u)rW\u00103s%fFW$dnw\u0003";
      n[4] = "\nfo\tW`\u007fFd\u0006F/\u001eHo\rBuj";
      n[5] = "\u001a:{\u000f,ho\u001ap\u0000='\u000e\u0014{\u000b9}z";
      n[6] = "M4z\u000euVF;kA\bNU<b\b";
      n[7] = "7C\u001c\u0012HC!C\u0019H[T6\b\u001aNW@'O\rY\u001c@";
      n[8] = long.class;
      o[8] = "java/lang/Long";
      n[9] = "{\u0018[P\u0002Jm\u0018^\n\u0011]zS]\f\u001dIk\u0014J\u001bVN";
      n[10] = "qT\u00015yO\u0004t\n:h\u0000ez\u00011lZ\u0011";
      n[11] = boolean.class;
      o[11] = "java/lang/Boolean";
      n[12] = "\t\n\u00154\u0006+\u0017\u0002\u000f{{;\u0017";
      n[13] = "U\u001bk}o+^\u0014z2\u000e%U\u001f~h";
      n[14] = "Zw\u0017=t#/W\u001c2elNY\u00179a6:";
      n[15] = "7vjl,b;~k'ej'vil\u0001~;wH !h7m";
      n[16] = "5&\u00129\u000bF9.\u0013rBN%&\u00119&Z9':{\tD3'\u000b";
      n[17] = "nVg2nPxVbh}Go\u001danqS~Zvy:AO";
      n[18] = int.class;
      o[18] = "java/lang/Integer";
      n[19] = "R+\u0018\u000bcwD+\u001dQp`S`\u001eW|tB'\t@7fC";
      n[20] = "fy\u0013\\r\u0015\u0013Y\u0018ScZrW\u0013Xg\u0000\u0006";
      n[21] = "\fB;Q\u0001.yb0^\u0010a\u0018l;U\u0014;l";
      n[22] = "3\u001b$Cy\u0001F;/LhN'5$Gl\u0014S";
      n[23] = "oo+\u0018\u0000F\u001aO \u0017\u0011\t{A+\u001c\u0015S\u000f";
      n[24] = "+|\r\bW,^\\\u0006\u0007Fc?R\r\fB9K";
      n[25] = "\u0006\u0002[;1Ns\"P4 \u0001\u0012,[?$[f";
      n[26] = "5<\f1\u0012\u000e@\u001c\u0007>\u0003A!\u0012\f5\u0007\u001bU";
      n[27] = "9tm9S,/thc@;8?keL/)x|r\u0007:k";
      n[28] = "\u001dC\u0017\f\u001e|hc\u001c\u0003\u000f3\tm\u0017\b\u000bi}";
      n[29] = float.class;
      o[29] = "java/lang/Float";
      n[30] = "Zhh\u000f\u0002aQgy@xeBfi\u000fNaU";
      n[31] = "m\u0002|+{\u0013\u0018\"w$j\\y,|/n\u0006\r";
      n[32] = "th\u0005lTW\u0001H\u000ecE\u0018`F\u0005hAB\u0014";
      n[33] = "SsNz\u0019i&SEu\b&G]N~\f|3";
      n[34] = "Z\u0010860%L\u0010=l#2[[>j/&J\u001c)}d1x";
      n[35] = "]y!$d3(Y*+u|IW! q&=";
      n[36] = char.class;
      o[36] = "java/lang/Character";
      n[37] = "\\?d0\u0011<W0u\u007f|<W-a";
      n[38] = "\u000f~%%?\u001f\u0003v$nv\u0017\u001f~&%\u001f\u0003\u0003\u007f";
      n[39] = "\u0012P5\u001c_\u000egp>\u0013NA\u0006~5\u0018J\u001br";
      n[40] = "\u000ec\u00104uh\u0018c\u0015nf\u007f\u000f(\u0016hjk\u001eo\u0001\u007f!|;";
      n[41] = "\u000b8\u0005\u001c\u0001)~\u0018\u000e\u0013\u0010f\u001f\u0016\u0005\u0018\u0014<k";
      n[42] = "\u001doZ!EOhOQ.T\u0000\tAZ%PZ}";
      n[43] = "\nS}q`\u0015\u007fsv~qZ\u001e}}uu\u0000j";
      n[44] = "!'[3%k?/A|Gw82";
      n[45] = "@(&\u0015_x^ <Z8yO;1\u0000\u001e\u007f";
      n[46] = "!\u0002\u0015g,J7\u0002\u0010=?] I\u0013;3I1\u000e\u0004,xY\u0002";
      n[47] = ")bn<.@?bkf=W()h`1C9n\u007fwzS!n}| \u001e\u001du}a Y*b";
      n[48] = "E$Xo\bpN+I uh],@idiF)JkT";
      n[49] = "A\u0018\u0016eDhW\u0018\u0013?W\u007f@S\u00109[kQ\u0014\u0007.\u0010|i";
      n[50] = "\u0014v|[v\u000b\u0002vy\u0001e\u001c\u0015=z\u0007i\b\u0004zm\u0010\"\u001f>";
      n[51] = "\u0000\t^H\r\u007fu)UG\u001c0\u0014'^L\u0018j`";
      n[52] = "d6kS\u0005*y#3qD'a%";
      n[53] = "\u0016XD]\u0010!cxOR\u0001n\u001e`\\U\b'v";
      n[54] = "n\u001bj\u0015#ax\u001boO0voPlI<b~\u0017{^wuM";
      n[55] = "\u0007l\u0012\u0005ZQ\u0019d\bJ5V\u001fl\u001d(\u001dW\u0019";
      n[56] = "7\u0015;?+,B500:c#;;;>9W";
      n[57] = "U:A,\u001c\u007fC:Dv\u000fhTqGp\u0003|E6PgHj\u0002";
      n[58] = "\u00012zI\u0018,t\u0012qF\tc\u0015\u001czM\r9a";
      n[59] = "0P?ZJ\u00160P(\u0006F\u0019*\u001b(\u0018F\f-jxE\u0017";
      n[60] = "F#[]xnM,J\u0012\u0004wB,L^:g";
      n[61] = "KzGJY[>ZLEH\u0014_TGNLN+";
      n[62] = " E\u0001\u0012f\"Ue\n\u001dwm4k\u0001\u0016s7@";
      n[63] = "`M\"|xD~E83\u001bPz\b\u0011s\"Cs";
      n[64] = "89K<m_36Zs\u0017[ =\\9";
      n[65] = "k\u0003C\u001e\u001cT\u001e#H\u0011\r\u001b\u007f-C\u001a\tA\u000b";
      n[66] = "\u0019+\u001d\u0006@\u0006l\u000b\u0016\tQI\r\u0005\u001d\u0002U\u0013y";
      n[67] = "dnUt;_zfO;VEbcFvaCaaP";
      n[68] = "6\u000fl,\fw(\u0007vcoc,";
      n[69] = "\u0015d'\f>O\u0003d\"V-X\u0014/!P!L\u0005h6GjX)";
      n[70] = "b\nD&Br\u0017*O)S=v$D\"Wg\u0002";
      n[71] = "Z\u0011\rPij{-\u001bPl0h:\f\u001bo6d.\u001d\\x!/?X\u000e";
      n[72] = "s2y\u0010:\u0005\u0006\u0012r\u001f+Jg\u001cy\u0014/\u0010\u0013";
      n[73] = "1\u0017Cx:tD7Hw+;%9C|/aQ";
      n[74] = "C^\u0005\u0005W!6~\u000e\nFnWp\u0005\u0001B4#";
      n[75] = "3pS\t:2FPX\u0006+}'^S\r/'S";
      n[76] = "\u0007m1{\u000b/rM:t\u001a`\u0013C1\u007f\u001e:g";
      n[77] = "Gf-8e\r2F&7tBSH-<p\u0018'";
      n[78] = "7/B\u0006\u0012\u0018B\u000fI\t\u0003W#\u0001B\u0002\u0007\rW";
      n[79] = "\u0005I\u000eD\u0017'\u000eF\u001f\u000b{$\u0000D\u001dDW";
      n[80] = "J@J\u001a\u0011 AO[Uq9MCY\t";
      n[81] = "EGcVxe0ghYi*QicRmp%";
      n[82] = "`\u00124Q\u0000m\u00152?^\u0011\"t<4U\u0015x\u0000";
      n[83] = "\u0004\u0013DC\u001e\fq3OL\u000fC\u0010=DG\u000b\u0019d";
      n[84] = "6~.\u007f37C^%p\"x\"P.{&\"V";
      n[85] = "Y\u0013\u0015p9V,3\u001e\u007f(\u0019M=\u0015t,C9";
      n[86] = "!57\u000bL\u0002*:&D$\u0002$55";
      n[87] = "]9\u0012E~8K9\u0017\u001fm/\\r\u0014\u0019a;M5\u0003\u000e*+v";
      n[88] = "\u001f5n\u0012aMj\u0015e\u001dp\u0002\u000b\u001bn\u0016tX\u007f";
      n[89] = "W\bDe%A\"(Oj4\u000eC&Da0T7";
      n[90] = "\u001b9J\u00171\u0010\u001dfQ\u0006LB!eQ\u001f=PL&H\u001d=\u0011!`N\u001a3O\u001b6V\u00022+";
      n[91] = "B4G\u0005\u0018 \u001e4\u0005\n\u0003\u001f\u0014i\u0000'\u000fn{5\u0018\u0007Ya\u0017|\u001fZ^\u001f";
      n[92] = "3\u0016>b*]>\u0010*lSZA\u0010lv!VpB/s0AA";
      n[93] = "C7yjx\u0003F1s<\u0007\tF\"\u001aj`\u001fU* <x\u0007TNp.=ZM~+7u\u0000*wth|\u001f\u0013p'o<`";
      n[94] = "\u0014%j?Z\u0019\u0017>>+e\nk2(8\u000e\u001dQv)n\u0001c";
      n[95] = "~GiB!G}\\=V\u001eT\u0001\u0014(SoFlW1Qo\u0007\u0001\u0014kT$S<W3Oq@\u0001";
      n[96] = "m\u0006o4\u0006MkYt%{\u001cWZt<\n\r:\u0019m>\nLW\\j4\nK&\u00064~\u0016v";
      n[97] = "`'?\u0012RR\"=F\u0015n\\,!w\u0017\u001eA>'}|\rM8v-\f\u0010_>|F";
      n[98] = "F'@gN'C!J11-C2{!V<B$_*1xH!\\?\u000b.P9][\b&\u00163\u001fa\t:\u0016&\u0019[\b*\u0011%\\b\u000fy\u0016e#";
      n[99] = "{viIL. o!\u0013+q|r\u001a\bievh\u0014\u0019IszrS\u001aR}-q0\u001fTw{\u000e";
      n[100] = "W\u001cA\u000fk.\u0001J\u0017\\'U\u0001I\rjv9nO\u0017Hd(\u0007N\r\rpU";
      n[101] = "H`\u00068Y1\u0013yNb>`YZGeXYXyYcB`\\u<=XsS%Mg\u00069O\u0018";
      n[102] = "0]s=>\u0015\"F/~D\u0005O\u001bsv9\u000b6_h9:G";
      n[103] = "\u0000#\u0013\u0001>oV;\u000b\u0000Z8E9\u0005\u001a!U\r \u000fE$9D'RBZjZ6\u001dC+0\u0004|\u0001~";
      n[104] = "\u001a\b\u001f\\'q\u0017K\\\u0006KrO\u0012K7wsY\bB\r!kA\t&";
      n[105] = ";,{+8\u001ey6\u0002/\u0004J}6s>i\td4s\u007f\u0004Ob3}!>\u0019z+|E";
      n[106] = "\nk^R1\u000e\r>Y\t,rR-W\u00149\u000eT+:\u0010=\u0000\n)A\fi\u0003\u000eQ";
      n[107] = "w6`\u0011G~-ri\u0004&9 (y\u001ba)Ipc\tY#s&{\u0011XGt1:\u001aC67v9\u0015&y3(c\u0017\u001f#w!vv";
      n[108] = "+wZhN\u0017}|N<#\u0018gwX>_\u001ea\u001a\\:Q@ca@nRD\u001b";
      n[109] = "wTW72p5CC6U'\f\u0007E1$5aD\\3$t\f\u0007Su.15\u0000\u0000rnN";
      n[110] = "nu77\u001dOh*,&`\u001dT),?\u0011\u000f9j5=\u0011NT):{\u001b\u000bm.i|[t";
      n[111] = "\u0017\u0013J\u0018\u0017b\u0000\u001e\tNn;fM\u0001\fW-\u000fD\u001b\u0006\tR";
      n[112] = " >Mi\r=&aVxpi\u001abVa\u0001}w!Oc\u0001<\u001ab@%\u000by#e\u0013\"K\u0006";
      n[113] = "\f7EfCn\u000e![%>`\u00045PrR\t@*BkZ3\u00162Zj>y\u00065OiY{\u0010+\f\u0014";
      n[114] = "\u0004\u000bZQD>R\u0000N\u0005);S\u0000^\u0007H6Of\u0013\nJkJ\nZ\r\u0017l4YD\u001cXmE\u0003\u001aVDP";
      n[115] = ":\f\u0013\u0016AYx\u0016j\u0019}\r|\u0016\u001b\u0003\u0010Ne\u0014\u001bB}\rjR\u0011\u0007D\n9UQx";
      n[116] = "4l!T\u001bIvvXS'\u001drv)AJ^kt)\u0000'\u001bl~)\u0007VA245:";
      n[117] = "J@\u0000O\u001dI\u0011EWV\u000f$\u0016\u0010\u0017U\u0003H$D[\u0005Y\u0018sB\rG\u0015\u0019\u0002\u0018S\r\t$";
      n[118] = "\n%\u0013:Pz_*\u001a=[\u001dRs\u00049JgNm\u0004T\ts\rn\u0007m\u000e \n.x";
      n[119] = "p\u000f$5xp2\u0015]7D$6\u0015, )g/\u0017,aD$ Q&$}#sVf[";
      n[120] = "\u001d%\u0018D\u007f.KsN\u00173UKpT4u8I{(\u0010i-[`A\u0011shO\u001d";
      n[121] = "P\u001fgCdf\u000b\u001a0Zv\u000b\u0004RaR`w\u0004\"5\u0007$kSSr\\{qP\"5W#p\u0016\u001b2\u0004$0i";
      n[122] = "x\u0000C\u0007Fd:\u001a:\u0005z0>\u001aK\u0012\u0017s'\u0018KSz5!\u001fE\r@c9\u0007Di";
      n[123] = "I\r\"JW#\u000b\u0017[Nkw\u000f\u0017*_\u00064\u0016\u0015*\u001ekq\u0011\u001f*\u0019\u001a+OU6$";
      n[124] = "\\\u001cDjiF\u001e\u0006=oU\u0012\u001a\u0006L\u007f8Q\u0003\u0004L>U\u0014\u0004\u000eL9$NZDP\u0004";
      n[125] = "r{?kn`$p+?\u0003i,\u0016v0`5<z?7=2B'#78p.n$j?\u000esr$o}b:uyh\u0003?&u|*ov!({T2j!-98{m|*Gegmyh+,`0~\u0016v0`5<z?7=2B'#78p.n$j?\u000er{?kn`$p+?\u0003";
      n[126] = "7\u000fd\u00015imFxYT~\\U~B+h5Td\u0007?\u0015";
      n[127] = "Z*J~b8_,@(\u001d2_?q8z#^)U3\u001dgT,V&'1L4WB$9Aj\u0016!'0L0VB$5\r(V{#f\nh)";
      n[128] = "=\u0006l\u001cX\u000b=\u0001pE!\u0013QBr\u0004P\u0002<\u0001k\u0006PCQBd@Z\u0006hE7G\u001ay";
      n[129] = "\u000f\u0010|\u000bku\u0012\u0002z\u0001\u0000l\u0000\u000eAGx}\u0016\u000faAmil\u0001h\\1n\u001c\u001czZ;\u0005U\f$A\u007f<R_#\u0001\u0000";
      n[130] = "$Lh\u0013\u000b\nfV\u0011\u001d7^bV`\u0006Z\u001d{T`G7^t\u0012j\u0002\u000eY'\u0015*}";
      n[131] = "1\u001c\u0000;\u001c\u00051\u001b\u001cbe\u001c]X\u001e#\u0014\f0\u001b\u0007!\u0014M]X\bg\u001e\bd_[`^w";
      n[132] = "YE!A:$[\u0014yOG<;\u0010eZ6.VS|X6o;JgR~*RC}X U";
      n[133] = "9VQF1\u0007~\r\u000e\\2vz\u0015\u000e&2\u0018>\u0013\u0017\u001f5K9Sh";
      n[134] = "\u00010NMG8\u00017R\u0014>#mtPUO1\u00007IWOpmqOPA.W'WH@J";
      n[135] = "yz\u000f?[\u001ce.\f;#\u0007nl;kS\u001b\u0007(\u001btRZvrE>Ng";
      n[136] = "\u001c?ya\u0010i\u001en!omq~j=z\u001cc\u0013)$x\u001c\"~l#r\u001c%\u000f6}8\u0000\u0018";
      n[137] = "Iu[.$gKcEmY|^T_&8fV\u000f\u001f;&\u007f]5I#>~9";
      n[138] = "\u0001<\tV kC&pU\u001c?G&\u0001Cq|^$\u0001\u0002\u001c?Qb\u000bG%8\u0002eK8";
      n[139] = "Yt\u0015Dy;\u001e3\u0005\u0005F)Zl\u001f:= F\u000bF\u001f98D1\u0010\u0007!9 rGG'!]`\u001e\bzG\u0011o\u0019C8+XhDDF";
      n[140] = "Y\u0015,\u001f\u0019h\u0002\fdE~9H/mB\u0018\u001fY\u000f{N\u0002X\f\u000bdTC)VU.H~";
      n[141] = "=X9eB|fAq?%#:\\J$~0-Ae0%p0_|;\u001f&(G}_";
      n[142] = "bs9;\\\u0003 i@?`W$i1.\r\u0014=k1o`W2-;*YPa*{U";
      n[143] = "&:b<d}p\"z=\u0000,z4g\n|Gq;e<}.p! (\u0000?y9e1c<wm~C";
      n[144] = "V]qy=\u001cS[{/B\u0016SHJ?%\u0007R^n4BCX[m!x\u0015@ClE~\u0018@[v\u007f(\u0000XZ\u0012|,AD[+{\u007fF\u0004$";
      n[145] = "\u001c\u0006ZWeKU\u0001\u0007P\u001b[J9E\u0016zABb\u0005\u000bdXIXS\u0013|Y-";
      n[146] = "Lc[vd|\bb\ry\u001a/]t7,~%\nf[eyx\r\u0018\b{h7\fiR%\"+1";
      n[147] = "8\u0011\u0005D\u001c\u001dn\t\u001dExYm\u0012\u0007V?I\u0004G\u001eXCYh\u000e\u0019\u0005D'8\u0011\u0005D\u001c\u001dn\t\u001dEx";
      n[148] = "\u001f\u0005PeM\f\u001dT\bk0\u0014}P\u0014~A\u0006\u0010\u0013\r|AG}P\u0002:K\u0002DWQ=\u000b}";
      n[149] = "mKyM/$/Q\u0000H\u0013p+QqX~32Sq\u0019\u0013u4T\u007fG)#,L~#";
      n[150] = "\fY#\u0016'`\n\u00068\u0007Z96\u00058\u001e+ [F!\u001c+a6\u0005.Z!$\u000f\u0002}]a[";
      n[151] = "d\u0003!\u007f@\u0002&\u0019Xs|V\"\u0019)j\u0011\u0015;\u001b)+|V4]#nEQgZc\u0011";
      n[152] = "_\u0002s@\u000e\u0007\u001d\u0018\nG2S\u0019\u0018{U_\u0010\u0000\u001a{\u00142S\u000f\\qQ\u000bT\\[1.";
      n[153] = "\u0015;D<e\u0012\u00026\u0007j\u001cHde\u000f(%]\rl\u0015\"{\"";
      n[154] = "wB\u0018#\u00045!\u0014NpHN!\u0017TU\u00106.\u0013(w\u001261\u0007Av\bs%z";
      n[155] = "H\u0010FP<S\u0018@\tXr-\u0017\u0014HioQ?\u0003PWGD\ty\u000eX~\u0014\f\u001c\b\tcT\ty\u0007_z\u0012\u001c\u0017QTnFq";
      n[156] = "<w\u0007d\u0007vxvQky-=a\u0011f\u0005+;\f\u0015b\u000bu9w\t6\bqA";
      n[157] = "dqc/z\t&k\u001a.F]\"kk:+\u001e;ik{F]4/a>\u007fZg(!A";
      n[158] = "u}\nqJ #e\u0012p.~$|\u001arN\u001a\"|\rqSs#fHe.";
      n[159] = "*` \u0003<\u001b8{|@F\u0011U&-D:\u0015<rvA\"\u0010";
      n[160] = "(mdJ,v49gNTk;pjsei5;h\u001f,nh<\u0016";
      n[161] = "cZ\u007ffL0e\u0005dw1bY\u0006dn@p4E}l@1Y\\ff\bt0U|lV\u000b";
      n[162] = "Z|\u0005@:yZ{\u0019\u0019Cb68\u001bX2p[{\u0002Z216>\u0005P26Gd[\u001a.\u000b";
      n[163] = "\ru>\u0013l\r\u000b*%\u0002\u0011\\7)%\u001b`MZj<\u0019`\f7s'\u0013(I^z=\u0019v6";
      n[164] = "^.\u0010\u0010\u000bq\u001c9\u0004\u0011l%%}\u0002\u0016\u001d4H>\u001b\u0014\u001du%{\u001c\u001e\u001drT!BT\u0001O";
      n[165] = "='|\u0012Adk?d\u0013%?z\rf\u0015Y/\u0001\u007fe\u001fTcp%;UH^";
      n[166] = "\u001e4 \u001f\u0001M\u0018k;\u000e|\u0018$h;\u0017\r\rI+\"\u0015\rL$h-S\u0007\t\u001do~TGv";
      n[167] = "-R~EnEoH\u0007@R\u0011kHvP?RrJv\u0011R\u0011}\f|Tk\u0016.\u000b<+";
      n[168] = "kY}O\\s7W.X\"$\r\u001as_])7LkG\\M";
      n[169] = "csy\u001b Z!i\u0000\u001f\u001c\u000e%iq\u000eqM<kqO\u001c^$p<\n\u007f[\"zju";
      n[170] = "q*\u001b=?\u0013'2\u0003<[H6\u0007\u0000+=JMr\u00020*\u0014<(\\z6)";
      n[171] = "l&r\u001fv%q4t\u0015\u001d:b(QCf.f;y.!2p+p\u0014w*h*\u0014";
      n[172] = "c~#Lez!dZKY.%d+Y4m<f+\u0018Y~$}f]:{\"w0\"";
      n[173] = "\u0019\u0001.@rhL\u000e'Gy\u000fKL?T\u007fi\\m%T\u007ffL1|\u001eya@V)\u0011pfK1";
      n[174] = "@aM\u0019c\u0012\u0002{4\u001e_F\u0006{E\f2\u0005\u001fyEM_C\u0019~K\u0013e\u0015\u0001fJw";
      n[175] = "}M-l\u0005~t\u0011\u007fk\t@:Cxv\u0018\u0007**\u007fq\u0007y;Cvk\r'D\u0013{:\u00120z\u001a'h\u0015<D";
      n[176] = "j\n\u0014JtNlU\u000f[\t\u0018PV\u000fBx\u000e=\u0015\u0016@xOPP\u0011JxH!\nO\u0000du";
      n[177] = "\u0017/l=\u0001ZMfpe`L|uv~\u001f[\u0015tl;\u000b&";
      n[178] = "l0\u0002\u001fPYa6\u0016\u0011)^\u001e6\u0010\bXLsu\t\nX\r\u001e0\u000e\u0000X\nojPJD7";
      n[179] = "u&\u0012\u001a\nft:\u0012\u000f\f\\2-O\n[\u001b\"D\u0014\u0011D-q5NO\u000e1L}IN[`v|UNNfL";
      n[180] = ":\\\u0001%x27\u001fB\u007f\u0014)oGE#S9\u0006\u001f_1k3<IG)jW;^\u0006\"q&x\u0019\u0005-\u0014ky\u001aS\"qf:Y\tN";
      n[181] = "K\u0007L\u0019$$\u001f\\I\u0001!M\u001bm\b\u001d><\t\u0000K\u0004<<Hm\b\t)2\u000f\t\u0001\u0019+'Jm";
      n[182] = "3:i0K_6<cf4S7?\n0SC%'0fK[$C`t\u000e\u0006=s;mF\\Z";
      n[183] = "0\t07e\u0003k\u0010xm\u0002R!3qjdu'\u0015n\r=U(\u00007|g\u000bb\u001c\n";
      n[184] = "PT57$FPS)n]]<\u0010+/,OQS2-,\u000e<\u0010=k&K\u0005\u0017nlf4";
      n[185] = ",\u000evW{'>W9\n\u001d58O\u0012Wx\"1^\u000f_x7U\u000f.Ib>oY6QcZ";
      n[186] = "\u0019%&}\u0018 O.2)u'E$^s\u0011-\u001262:\u0016p\u0015Ha$\u0007?\u00149;zM#)";
      n[187] = "]\nn 80X\fdvG3]\b\r  ,K\u00177v84Js2z5\"\t\u0002h$\u007f>4";
      n[188] = "2D\u0012\u0007\\iiAE\u001eN\u0004n\u0014\u0005\u001dBh\\@D@\u001c\u00042D\u0012\u0007\\iiAE\u001eN\u0004";
      n[189] = "\"f=h3\u007f~hn\u007fM(D(0dv?(a79qA";
      n[190] = "Eg5/&?@a?yY KE*i8:C\u001ejt&#H$<l>\",";
      n[191] = "q-p45}c6,wO\u007f\u000e-}7$,t.fc0";
      n[192] = "\u001c(+\r/N^??\fH\u001ag~&\u000e7\u0014](>\u00166p";
      n[193] = "g:\bq+H#!Grg17]@t!@%0\u0003m#@d]@beJ!dG1b\n^";
      n[194] = "t\u0005WszXq\u0003]%\u0005V{\u0000N>^Va|\u0004\"}\u0004p\u0012R)iP\u001d";
      n[195] = "!\u0004z/D(#\u0012dl9&)\u0006o;UOn\u0018p,\u0004>4F:09?+\u0006p ^==\u00183]";
      n[196] = "v{9V\u007fX -o\u00053# .u#k^\"Cb\u000fw\\2*c\u00152HO";
      n[197] = "\u0002[\u001co5\u001c@L\bnRKy\b\u000ei#Y\u0014K\u0017k#\u0018yL\r\u007f9\\C\b\f)6\"";
      n[198] = "e(,_i+'?8^\u000e|\u001e} Q\u007f(o'~\u001bc\u0015";
      n[199] = "\u0016)8\u000ew$T3A\u000eKpP30\u001b&3I10ZKpFw:\u001frw\u0015pz`";
      n[200] = "XTnZ?^\u001b]|\u001a/<\u000bm?\u00012M\\\u001ce_xQa";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = n[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = n[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            n[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  n[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(974858629180252L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = n[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  n[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(974858629180252L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        n[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(974858629180252L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 233;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 98;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 74;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 204;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 220;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 233;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 98;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 74;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/at_C0042",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/at" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(ConfigLoadStatistics var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/au_C0044;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/at_C0042", "lambda$publishReport$0", "(Ldev/zprestige/prestige/au_C0044;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((ConfigLoadStatistics)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
