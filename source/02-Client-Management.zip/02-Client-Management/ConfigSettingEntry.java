package dev.zprestige.prestige.client.management;

import com.google.gson.JsonElement;
import dev.zprestige.prestige.api.module.Module;

public record ConfigSettingEntry(Module ao, String ap, JsonElement aq, boolean ar) {

    public final com.google.gson.JsonElement recoveryAccess_read_aq() { return this.aq; }

    public final dev.zprestige.prestige.api.module.Module recoveryAccess_read_ao() { return this.ao; }

    public final java.lang.String recoveryAccess_read_ap() { return this.ap; }

    public final boolean recoveryAccess_read_ar() { return this.ar; }
}
