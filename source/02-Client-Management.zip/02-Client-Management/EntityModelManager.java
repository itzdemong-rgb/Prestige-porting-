package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.util.ConcurrentIdentitySet;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderCallback;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.RenderEvents;
import dev.zprestige.prestige.renderlib.effects.EffectType;

import java.util.Iterator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.world.World;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.entity.EntityType;

public class EntityModelManager implements MinecraftAccess {
   private static FramebufferEffect a;
   public static final Map c = new ConcurrentHashMap();
   public static ConcurrentIdentitySet d = new ConcurrentIdentitySet(new EntityType[0], 79598140109844L);
   public static boolean e = dev.prestige.recovery.SourceSupport.asBoolean(0);
   public static boolean f = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private static final Map g = new ConcurrentHashMap();
   private static final Class h = Void.class;
   private static final long i = 115684937350440L;
   private static final Object[] j = new Object[64];
   private static final String[] k = new String[64];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public static void aReturningVoid(Object[] var0) {
      EffectType var3 = (EffectType)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 115684937350440L ^ var1;
      int var4 = Event.bReturningInt();
      int var20 = var4;
      EffectType var19 = var3;
      EffectType var14 = var19;
      EffectType var13 = var19;
      if (var20 == 0) {
         EffectType var21 = var13;
         if (var21 == null) {
            return;
         }

         var14 = var3;
      }

      int var23 = var4;
      EffectType var22 = var14;
      EffectType var16 = var22;
      EffectType var15 = var22;
      if (var23 == 0) {
         EffectType var25 = EffectType.NONE;
         EffectType var24 = var15;
         if (var24 == var25) {
            return;
         }

         EffectType var26 = var3;
         var16 = var26;
      }

      Object[] var9 = new Object[0];
      EffectType var8 = var16;
      FramebufferEffect var31 = var8.aReturningc_(var9);
      int var28 = var4;
      FramebufferEffect var27 = var31;
      FramebufferEffect var18 = var27;
      FramebufferEffect var17 = var27;
      if (var28 == 0) {
         FramebufferEffect var29 = var17;
         if (var29 == null) {
            return;
         }

         Object[] var12 = new Object[0];
         EffectType var11 = var3;
         FramebufferEffect var30 = var11.aReturningc_(var12);
         var18 = var30;
      }

      a = var18;
   }

   public static FramebufferEffect aReturningc_(Object[] var0) {
      return a;
   }

   public static boolean aReturningBoolean(Object[] var0) {
      EntityModel var4 = (EntityModel)var0[0];
      ConcurrentIdentitySet var3 = (ConcurrentIdentitySet)var0[1];
      long var1 = (Long)var0[2];
      var1 = 115684937350440L ^ var1;
      long var5 = var1 ^ 85408531169200L;
      long var7 = var1 ^ 72974059266077L;
      int var10000 = Event.bReturningInt();
      Class var10 = var4.getClass();
      Map var20 = c;
      Boolean var11 = (Boolean)var20.get(var10);
      int var9 = var10000;
      Boolean var72 = var11;
      if (var9 == 0) {
         if (var11 == null) {
            Object[] var25 = new Object[]{var7};
            byte var73 = ((byte)((var3.fReturningBoolean(var25)) ? 1 : 0));
            if (var9 == 0) {
               if (var73 == 0) {
                  MinecraftClient var27 = b;
                  if (var27.world != null) {
                     Iterator var12 = var3.iterator();

                     Object var14;
                     byte var15;
                     label182: {
                        while (var12.hasNext()) {
                           EntityType var13 = (EntityType)var12.next();
                           EntityType var74 = var13;
                           if (var9 != 0) {
                              return dev.prestige.recovery.SourceSupport.asBoolean(0);
                           }

                           label175: {
                              if (var9 == 0) {
                                 if (var13 == EntityType.PLAYER) {
                                    MinecraftClient var35 = b;
                                    var14 = var35.player;
                                    var15 = 0;
                                    if (var14 == null) {
                                       continue;
                                    }
                                    break label175;
                                 }

                                 var74 = var13;
                              }

                              MinecraftClient var37 = b;
                              Object var40 = null;
                              ClientWorld var39 = var37.world;
                              EntityType var38 = var74;
                              var14 = var38.create((World)var39, (SpawnReason)var40);
                              if (var14 == null) {
                                 continue;
                              }

                              var15 = 1;
                           }

                           boolean var65 = false ;

                           try {
                              label176: {
                                 var65 = true;
                                 MinecraftClient var42 = b;
                                 EntityRenderManager var43 = var42.getEntityRenderDispatcher();
                                 EntityRenderer var16 = var43.getRenderer((Entity)var14);
                                 Object[] var45 = new Object[]{var16, var5};
                                 Class var17 = aReturningClass(var45);
                                 Class var75 = var17;
                                 if (var9 == 0) {
                                    if (var17 == null) {
                                       var65 = false;
                                       break label176;
                                    }

                                    var75 = var17;
                                 }

                                 if (var9 == 0) {
                                    if (var75 != var10) {
                                       var65 = false;
                                       break label176;
                                    }

                                    Map var76 = c;
                                    Boolean var51 = true;
                                    Map var49 = var76;
                                    var49.put(var10, var51);
                                 }

                                 var65 = false;
                                 break label182;
                              }
                           } finally {
                              if (var65) {
                                 if (var15 != 0) {
                                    ((Entity)var14).discard();
                                 }
                              }
                           }

                           if (var15 != 0) {
                              ((Entity)var14).discard();
                           }

                           if (var9 != 0) {
                              break;
                           }
                        }

                        Map var78 = c;
                        Boolean var63 = false;
                        Map var61 = var78;
                        var61.put(var10, var63);
                        return dev.prestige.recovery.SourceSupport.asBoolean(0);
                     }

                     var73 = var15;
                     if (var9 == 0) {
                        if (var15 != 0) {
                           ((Entity)var14).discard();
                        }

                        var73 = 1;
                     }

                     return dev.prestige.recovery.SourceSupport.asBoolean(var73);
                  }
               }

               var73 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var73);
         }

         var72 = var11;
      }

      Boolean var23 = var72;
      return var23;
   }

   private static Class aReturningClass(Object[] var0) {
      EntityRenderer var3 = (EntityRenderer)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 115684937350440L ^ var1;
      int var98 = Event.bReturningInt();
      Class var5 = var3.getClass();
      int var4 = var98;
      Class var15 = var5;
      Map var14 = g;
      Class var6 = (Class)var14.get(var15);
      int var64 = var4;
      Class var63 = var6;
      Class var38 = var63;
      Class var37 = var63;
      if (var64 == 0) {
         Class var65 = var37;
         if (var65 == null) {
            Class var7;
            label84: {
               var7 = null;
               int var70 = var4;
               EntityRenderer var69 = var3;
               EntityRenderer var41 = var69;
               EntityRenderer var40 = var69;
               if (var70 == 0) {
                  boolean var71 = var40 instanceof LivingEntityRenderer;
                  if (!var71) {
                     Class var21 = var5;
                     Field[] var9 = var21.getDeclaredFields();
                     int var10 = var9.length;
                     while (true) {
                        int var74 = var10;
                        int var73 = var11;
                        if (var73 >= var74) {
                           break label84;
                        }

                        Field var12 = var9[var11];
                        int var75 = var4;
                        if (var75 == 0) {
                           int var77 = var4;
                           Class<EntityModel> var76 = EntityModel.class;
                           Class<EntityModel> var62 = var76;
                           Class<EntityModel> var42 = var76;
                           if (var77 != 0) {
                              return var62;
                           }

                           Class<EntityModel> var78 = var42;
                           Class<EntityModel> var43 = var78;
                           Field var23 = var12;
                           Class var25 = var23.getType();
                           Class<EntityModel> var24 = var43;
                           boolean var79 = var24.isAssignableFrom(var25);
                           label74:
                           if (var79) {
                              Field var27 = var12;
                              var27.setAccessible(true);

                              try {
                                 EntityRenderer var30 = var3;
                                 Field var29 = var12;
                                 EntityModel var13 = (EntityModel)var29.get(var30);
                                 int var81 = var4;
                                 EntityModel var80 = var13;
                                 EntityModel var45 = var80;
                                 EntityModel var44 = var80;
                                 if (var81 == 0) {
                                    EntityModel var82 = var44;
                                    if (var82 == null) {
                                       break label74;
                                    }

                                    var45 = var13;
                                 }

                                 var7 = var45.getClass();
                              } catch (IllegalAccessException var97) {
                                 break label74;
                              }

                              int var83 = var4;
                              if (var83 == 0) {
                                 break label84;
                              }
                           }

                           var11++;
                        }

                        int var84 = var4;
                        if (var84 != 0) {
                           break label84;
                        }
                     }
                  }

                  EntityRenderer var72 = var3;
                  var41 = var72;
               }

               LivingEntityRenderer var8 = (LivingEntityRenderer)var41;
               LivingEntityRenderer var20 = var8;
               var7 = var20.getModel().getClass();
            }

            Map var59;
            Class var60;
            Class var61;
            label52: {
               int var88 = var4;
               Class var87 = var7;
               Class var86 = var5;
               Map var85 = g;
               Map var54 = var85;
               Class var55 = var86;
               Class var56 = var87;
               Map var47 = var85;
               Class var48 = var86;
               Class var49 = var87;
               if (var88 == 0) {
                  Class var91 = var49;
                  Class var90 = var48;
                  Map var89 = var47;
                  Map var57 = var89;
                  Class var58 = var90;
                  Map var50 = var89;
                  Class var51 = var90;
                  if (var91 != null) {
                     var61 = var7;
                     var60 = var58;
                     var59 = var57;
                     break label52;
                  }

                  Class var93 = var51;
                  Map var92 = var50;
                  Map var52 = var92;
                  Class var53 = var93;
                  var56 = h;
                  var55 = var53;
                  var54 = var52;
               }

               Class var96 = var56;
               Class var95 = var55;
               Map var94 = var54;
               var59 = var94;
               var60 = var95;
               var61 = var96;
            }

            Class var36 = var61;
            Class var35 = var60;
            Map var34 = var59;
            var34.put(var35, var36);
            return var7;
         }

         var38 = var6;
      }

      Class var67 = h;
      Class var66 = var38;
      Class var39;
      if (var66 == var67) {
         Object var68 = null;
         var39 = (Class)var68;
      } else {
         var39 = var6;
      }

      return var39;
   }

   public static boolean bReturningBoolean(Object[] var0) {
      EntityModel var3 = (EntityModel)var0[0];
      long var1 = (Long)var0[1];
      var1 = 115684937350440L ^ var1;
      long var4 = var1 ^ 89348022917078L;
      long var6 = var1 ^ 104117873838203L;
      int var10000 = Event.cReturningInt();
      Class var9 = var3.getClass();
      int var8 = var10000;
      Map var19 = c;
      Boolean var10 = (Boolean)var19.get(var9);
      Boolean var71 = var10;
      if (var8 != 0) {
         if (var10 == null) {
            ConcurrentIdentitySet var72 = d;
            Object[] var24 = new Object[]{var6};
            ConcurrentIdentitySet var23 = var72;
            byte var73 = ((byte)((var23.fReturningBoolean(var24)) ? 1 : 0));
            if (var8 != 0) {
               if (var73 == 0) {
                  MinecraftClient var26 = b;
                  if (var26.world != null) {
                     ConcurrentIdentitySet var29 = d;
                     Iterator var11 = var29.iterator();

                     Object var13;
                     byte var14;
                     label182: {
                        while (var11.hasNext()) {
                           EntityType var12 = (EntityType)var11.next();
                           EntityType var74 = var12;
                           if (var8 == 0) {
                              return dev.prestige.recovery.SourceSupport.asBoolean(0);
                           }

                           label175: {
                              if (var8 != 0) {
                                 if (var12 == EntityType.PLAYER) {
                                    MinecraftClient var34 = b;
                                    var13 = var34.player;
                                    var14 = 0;
                                    if (var13 == null) {
                                       continue;
                                    }
                                    break label175;
                                 }

                                 var74 = var12;
                              }

                              MinecraftClient var36 = b;
                              Object var39 = null;
                              ClientWorld var38 = var36.world;
                              EntityType var37 = var74;
                              var13 = var37.create((World)var38, (SpawnReason)var39);
                              if (var13 == null) {
                                 continue;
                              }

                              var14 = 1;
                           }

                           boolean var64 = false ;

                           try {
                              label176: {
                                 var64 = true;
                                 MinecraftClient var41 = b;
                                 EntityRenderManager var42 = var41.getEntityRenderDispatcher();
                                 EntityRenderer var15 = var42.getRenderer((Entity)var13);
                                 Object[] var44 = new Object[]{var15, var4};
                                 Class var16 = aReturningClass(var44);
                                 Class var75 = var16;
                                 if (var8 != 0) {
                                    if (var16 == null) {
                                       var64 = false;
                                       break label176;
                                    }

                                    var75 = var16;
                                 }

                                 if (var8 != 0) {
                                    if (var75 != var9) {
                                       var64 = false;
                                       break label176;
                                    }

                                    Map var76 = c;
                                    Boolean var50 = true;
                                    Map var48 = var76;
                                    var48.put(var9, var50);
                                 }

                                 var64 = false;
                                 break label182;
                              }
                           } finally {
                              if (var64) {
                                 if (var14 != 0) {
                                    ((Entity)var13).discard();
                                 }
                              }
                           }

                           if (var14 != 0) {
                              ((Entity)var13).discard();
                           }

                           if (var8 == 0) {
                              break;
                           }
                        }

                        Map var78 = c;
                        Boolean var62 = false;
                        Map var60 = var78;
                        var60.put(var9, var62);
                        return dev.prestige.recovery.SourceSupport.asBoolean(0);
                     }

                     var73 = var14;
                     if (var8 != 0) {
                        if (var14 != 0) {
                           ((Entity)var13).discard();
                        }

                        var73 = 1;
                     }

                     return dev.prestige.recovery.SourceSupport.asBoolean(var73);
                  }
               }

               var73 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var73);
         }

         var71 = var10;
      }

      Boolean var22 = var71;
      return var22;
   }

   public static boolean cReturningBoolean(Object[] var0) {
      EntityModel var3 = (EntityModel)var0[0];
      long var1 = (Long)var0[1];
      var1 = 115684937350440L ^ var1;
      long var4 = var1 ^ 36619179160843L;
      Object[] var6 = new Object[]{var3, d, var4};
      return aReturningBoolean(var6);
   }

   private static void lambda$static$1(MeshBufferManager var0, RenderContext var1) {
      long var10001 = 84946152270716L ^ 14265350050089L;
      FramebufferEffect var10 = a;
      if (var10 != null) {
         boolean var11 = e;
         if (var11) {
            FramebufferEffect var10000 = a;
            Object[] var9 = new Object[]{var0, var1, 72273430346325L};
            FramebufferEffect var8 = var10000;
            var8.aReturningVoid(var9);
            return;
         }
      }
   }

   private static void lambda$static$0(MeshBufferManager var0, RenderContext var1) {
      long var10001 = 99747541961940L ^ 89016525657852L;
      FramebufferEffect var10 = a;
      if (var10 != null) {
         boolean var11 = e;
         if (var11) {
            FramebufferEffect var10000 = a;
            Object[] var9 = new Object[]{var0, var1, 11328222288424L};
            FramebufferEffect var8 = var10000;
            var8.bReturningVoid(var9);
            return;
         }
      }
   }

   static {
      long var10001 = 108378421683702L ^ 47232620351970L;
      aReturningVoid();
      EffectType var10000 = EffectType.NORMAL;
      Object[] var5 = new Object[0];
      EffectType var4 = var10000;
      a = var4.aReturningc_(var5);
      net.fabricmc.fabric.api.event.Event var10 = RenderEvents.c;
      RenderCallback var7 = invokeBinding1();
      net.fabricmc.fabric.api.event.Event var6 = var10;
      var6.register(var7);
      net.fabricmc.fabric.api.event.Event var11 = RenderEvents.b;
      RenderCallback var9 = invokeBinding2();
      net.fabricmc.fabric.api.event.Event var8 = var11;
      var8.register(var9);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = k[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = j[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 59;
            yield var15;
         }
         case 1 -> {
            byte var16 = 47;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 41;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 22;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 53;
            yield var23;
         }
         case 9 -> {
            byte var24 = 24;
            yield var24;
         }
         case 10 -> {
            byte var25 = 49;
            yield var25;
         }
         case 11 -> {
            byte var26 = 25;
            yield var26;
         }
         case 12 -> {
            byte var27 = 43;
            yield var27;
         }
         case 13 -> {
            byte var28 = 9;
            yield var28;
         }
         case 14 -> {
            byte var29 = 7;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 55;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 23;
            yield var33;
         }
         case 19 -> {
            byte var34 = 6;
            yield var34;
         }
         case 20 -> {
            byte var35 = 60;
            yield var35;
         }
         case 21 -> {
            byte var36 = 48;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 16;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 62;
            yield var40;
         }
         case 26 -> {
            byte var41 = 31;
            yield var41;
         }
         case 27 -> {
            byte var42 = 13;
            yield var42;
         }
         case 28 -> {
            byte var43 = 14;
            yield var43;
         }
         case 29 -> {
            byte var44 = 17;
            yield var44;
         }
         case 30 -> {
            byte var45 = 27;
            yield var45;
         }
         case 31 -> {
            byte var46 = 58;
            yield var46;
         }
         case 32 -> {
            byte var47 = 18;
            yield var47;
         }
         case 33 -> {
            byte var48 = 28;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 5;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 1;
            yield var52;
         }
         case 38 -> {
            byte var53 = 51;
            yield var53;
         }
         case 39 -> {
            byte var54 = 56;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 3;
            yield var56;
         }
         case 42 -> {
            byte var57 = 19;
            yield var57;
         }
         case 43 -> {
            byte var58 = 29;
            yield var58;
         }
         case 44 -> {
            byte var59 = 44;
            yield var59;
         }
         case 45 -> {
            byte var60 = 21;
            yield var60;
         }
         case 46 -> {
            byte var61 = 26;
            yield var61;
         }
         case 47 -> {
            byte var62 = 10;
            yield var62;
         }
         case 48 -> {
            byte var63 = 11;
            yield var63;
         }
         case 49 -> {
            byte var64 = 46;
            yield var64;
         }
         case 50 -> {
            byte var65 = 8;
            yield var65;
         }
         case 51 -> {
            byte var66 = 12;
            yield var66;
         }
         case 52 -> {
            byte var67 = 37;
            yield var67;
         }
         case 53 -> {
            byte var68 = 40;
            yield var68;
         }
         case 54 -> {
            byte var69 = 4;
            yield var69;
         }
         case 55 -> {
            byte var70 = 54;
            yield var70;
         }
         case 56 -> {
            byte var71 = 35;
            yield var71;
         }
         case 57 -> {
            byte var72 = 15;
            yield var72;
         }
         case 58 -> {
            byte var73 = 42;
            yield var73;
         }
         case 59 -> {
            byte var74 = 33;
            yield var74;
         }
         case 60 -> {
            byte var75 = 34;
            yield var75;
         }
         case 61 -> {
            byte var76 = 32;
            yield var76;
         }
         case 62 -> {
            byte var77 = 39;
            yield var77;
         }
         default -> 0;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            k[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      j[0] = "F\u001a/?S\u0005P\u001a*e@\u0012GQ)cL\u0006V\u0016>t\u0007\u0016}";
      j[1] = "\u00177ds\u001ewb\u0017o|\u000f8\u0003\u0019dw\u000bbw";
      j[2] = void.class;
      k[2] = "java/lang/Void";
      j[3] = "R[#nmrD[&4~eS\u0010%2rqBW2%9cr";
      j[4] = "W\u000f\u001aB7t\\\u0000\u000b\r\\`^\u000b\u001cWpwS";
      j[5] = "w\u0002\u001bMfS\u0002\"\u0010Bw\u001cc,\u001bIsF\u0017";
      j[6] = boolean.class;
      k[6] = "java/lang/Boolean";
      j[7] = "*7L\u001dC.!8]R\u001f'&:_\u001f\u0019l\u0006?_\u0010\t";
      j[8] = "s(B`;=e(G:(*rcD<$>c$S+o,R";
      j[9] = int.class;
      k[9] = "java/lang/Integer";
      j[10] = "opKl3\u0012d\u007fZ#^\u0012dbN";
      j[11] = "\"hi\u00055[<`sJVO8";
      j[12] = "drl\u001eH<o}}Q)2dvy\u000b";
      j[13] = "\u0007~[\u0006Kor^P\tZ .WW\u000bXm(\u001cw\u000eXb8\t";
      j[14] = "+HQ\u0012ik+HFNed1\u0003FPeq6r\u001c\u000e6";
      j[15] = "z\u0014#gsYz\u00144;\u007fV`_4%\u007fCg.bq-";
      j[16] = "=N\u0010{PTHn\u001btA\u001b)`\u0010\u007fEA]";
      j[17] = "I4%|\\tB;430wL96|\u001c";
      j[18] = "X\u0001@6$>X\u0001Wj(1BJWt($E;\u0005*p`";
      j[19] = "bM\u001e|%SbM\t )\\x\u0006\t>)I\u007fwRkp";
      j[20] = "\u0012`\u0011\u0016G6\u0012`\u0006JK9\b+\u0006TK,\u000fZ]\u0001\u001d";
      j[21] = "\u0002g1e_t\u0002g&9S{\u0018,&'Sn\u001f]vz\u0002";
      j[22] = "jJs\u0014\u000b\u001cjJdH\u0007\u0013p\u0001dV\u0007\u0006wp1\t^";
      j[23] = "\u0001z!u\r\u0018\u0001z6)\u0001\u0017\u001b167\u0001\u0002\u001c@diYH";
      j[24] = " ^KDPU ^\\\u0018\\Z:\u0015\\\u0006\\O=d\u000eS\u000e\u000b";
      j[25] = "\u0016c2t.b\u0016c%(\"m\f(%6\"x\u000bYump;";
      j[26] = "@\u0015!ber^\u001d;-\u0002sO\u00066w$u";
      j[27] = "\u0017O^\u0002EN\u0017OI^IA\r\u0004I@IT\nu\u001d\u0018\u001e";
      j[28] = "w<*[Iwa</\u0001Z`vw,\u0007Vtg0;\u0010\u001ddD";
      j[29] = "\u0014A]H\u000e(aaVG\u001fg\u0000o]L\u001b=t";
      j[30] = "\u0003M. \u0004{vm%/\u00154\u0017c.$\u0011nc";
      j[31] = "G\u0010Ho0+Q\u0010M5#<F[N3/(W\u001cY$d6";
      j[32] = "0\r&G\u001f\u0014E--H\u000e[$#&C\n\u0001P";
      j[33] = "\u0017\u0004TO:(\u001b\u0013I\u00021*W\u0007A\u0003. \u001aOA\u00115g\u001c\u0017E\u000f(g<\u0017E\u000f(";
      j[34] = "\u0016f,FL<\u001d;#:KS\u00111<SI/\u0015i$G\"j\u0019=$\u000bH,\u0006z&:";
      j[35] = "*zG7jVo)\u001af\u001bF\u0010/M.tElp\r;\"/+$\u00059qStd\u0010o\u001b";
      j[36] = "L\u000fd&\u001e^HYbd$\u0005r\r2`X\u001fKB2?Jo";
      j[37] = "l\u0007Fh5hm\u0018E+Q*n\fX;\u0016:\u0007THoo+}\u000e[*/Tl\u0007Fh5hm\u0018E+Q";
      j[38] = "o-\u0010[#k;=\u001d\u0007Yb\u000b(]\u00160`w,\u0005\u000e$\u000bi+\u0000\u00167dbv\u000fj";
      j[39] = "\bCC>\u00037\u0000\u0006H;83\u000eC\u0013>T\u0001X\u0006Of\u0002VZRN=\t<\u001cM\t?8";
      j[40] = "X?@!iX\\`O`\u0002T\u001c\u0014]dcZ\u00014L{o{\u001d:C\u001f=W\u0001cMr9\b\u000e\"&#o\fY\"\\y|I\u0019]";
      j[41] = "\u0000\u0013\u0003)\u000f\u001b\u0007\u001bEt}\u0019\u0001\n]+\u0011+WG\u0000w}\u0017\u0010FZw\u001c\u001fUM_L\u0010@\u0003K\f=D\u0019\u001d\u001a=";
      j[42] = " \u0018\\\u000b\rP!\u0007_Hi\u0006,\u0010[X\u0000\n\u0015\u001e[H\u0004lw\u001a\u0006\u000b\u0016\u0016-\tCKi";
      j[43] = "lFZ\rLyh\u0010\\Ov#RD\fK\n8k\u000b\f\u0014\u0018H";
      j[44] = "v O.tKta\u0017?\u000eY&d,#v[K'\u001240]&#M;q6";
      j[45] = "l\u0000:Ej\u000f:@mU\u0001\u0003>\u0007\u0000\u0004n\u000b8\u0017xOoTb{0[f\u0007?\u0003{Z9]S";
      j[46] = "'\u0006)tHk#\u001ep1x7+\u001cm\u000bH>!\u0007}s\u0003?~]\u0011";
      j[47] = "\u0017p\u0015)v\u0006\u0013/\u001ah\u001d\u0004En?zv\u000fAh\u001e{S\nEv\u001fl\u001dZ\u0016/Nt~\u0007\u0018hC\u0017";
      j[48] = "\u001dA<\u00023?\u0011Pt\bB>\u0011S!\u0015\u0015iO\u0004yy k\u0015\u0007|\u00063?\u001eG";
      j[49] = "9x1\u0019B\faq,\u00180\u0003'q+\u0001L\u0005!\u001c0\u0002\b\u001dk&4\u001aQX[";
      j[50] = "+\u0010B\b\u0006$s\u0019_\tt$I\u0011\u0013\u0005\u001d!5\u0015K\u001d\tJu\u0019\u001bG\u000b0/\n^\u0007t";
      j[51] = "[\u0014M\nP)\f\u000bS\b6.U\u0016L\u0006a~\fJ\u0017jY/Q\u001bN\u0003\u000e0O\u0019";
      j[52] = "BpH[[aFh\u0011\u001ek;Ja6I\u001b'#&\u001d\u001dU$Y|\u000eX\u0015[";
      j[53] = "W1xU8S[ 0_IYW2aI%k\u0003s?\u0017IP_pd\\.WW69.";
      j[54] = "\u0000+#\u000b5=\u0002j{\u001aO;PoU\u001c$-Fh}\u001d+-=/qNq?Gub\u000b1@\u0004~!\u0013~*Baf\u0011O";
      j[55] = "\u001f,RK\r9\u0013=\u001aA|8\u0013>O\\+oLc\u00140\u00123\f+O\u000b\u001f-\u0017,";
      j[56] = "\u00018Bge]\neM\u001ba2\u0006oRr`N\u00027Jf\u000b\u000b\u000ecJ*aM\u0011$H\u001b";
      j[57] = "N ;cfE\u0019?%a\u0000IL3>dl{\u001c\u007fn8\u0000CZ4a;~\u001cN~.\u0003`RP0??n]\\s^h|\u001cFt?`9\u0017CO";
      j[58] = ".Bf9)gk\u0011;hXw\u0014Im$1uhM5<%\u001e(Aef'drR &X";
      j[59] = "U\fF\u0002P M\f\u0005\u000b47^]\u0019IH I2H]S&_J\u0003\\\f|3\u000b\u0015\u000fP|YM\nHRM";
      j[60] = " }\u0016a\u000e*v=Aqe1bz, \n.tjTk\u000bq.\u0006\u001c\u007f\u0002\"s~W~]x\u001f6Cw\u000e%g}B(TI";
      j[61] = ")lyDL\u0001l?$\u0015=\u0011\u0013grYT\u0013oc*A@x,`%\u001bV\u0015(?*Z=";
      j[62] = "\u000bsiRje\t21C\u0010w[7V\u001e\u007f\u007f]'.U~ \u0007KfAwsZ3-@()6";
      j[63] = "\u001f8.%\tX\u000bs0~0T\u001b}('\\fJ9sp0X\u0006`3,YW\t=r@";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = j[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = j[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            j[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  j[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(859525102569465L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = j[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  j[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(859525102569465L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        j[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(859525102569465L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 75;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 217;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 234;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 90;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 68;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 81;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 75;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 217;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 234;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/aD_C0009",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/aD" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static RenderCallback invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("()Ldev/zprestige/prestige/dm_C0190;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/aD_C0009",
                     "lambda$static$0",
                     "(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (RenderCallback)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static RenderCallback invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("()Ldev/zprestige/prestige/dm_C0190;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/aD_C0009",
                     "lambda$static$1",
                     "(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (RenderCallback)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
