package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.accessor.KeyBindingAccessor;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.AttackTargetUpdateEvent;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;

import dev.zprestige.prestige.api.accessor.MouseAccessor;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import org.lwjgl.glfw.GLFW;

public class KeybindManager implements MinecraftAccess {
   private final HashMap a;
   private boolean c;
   private boolean d;
   public static int e;
   public static int f;
   private static final long g = 105169953416565L;
   private static final long h;
   private static final Object[] i = new Object[60];
   private static final String[] j = new String[60];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;

   public KeybindManager(long var1) {
      super();
      var1 = 105169953416565L ^ var1;
      long var3 = var1 ^ 56274114666835L;

      this.a = new HashMap();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   public boolean aReturningBoolean(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 105169953416565L ^ var3;
      HashMap var8 = this.a;
      int var5 = var2;
      Integer var7 = var5;
      HashMap var6 = var8;
      return var6.containsKey(var7);
   }

    public void aReturningVoid(Object[] objectArray) {
      dev.zprestige.prestige.client.management.KeybindManager cJ_C01292;
      dev.zprestige.prestige.client.management.KeybindManager cJ_C01293;

        block24: {
            long l;
            long l2;
            int n;
            block29: {
                Object object;
                block30: {
                    int n2;
                    block31: {
                        block32: {
                            boolean bl;
                            int n3;
                            block25: {
                                block26: {
                                    int n4;
                                    block27: {
                                        block28: {
                                            block23: {
                                                n = (Integer)objectArray[0];
                                                l2 = (Long)objectArray[1];
                                                long l3 = l2 = 0x5FA6C9B6E575L ^ l2;
                                                l = l3 ^ 0x121B0D76B8FDL;
                                                long l4 = l3 ^ 0x6614E8DA61BDL;
                                                n3 = KeybindManager.invokeBinding1(7466197708234740299L, l2);
                                                try {
                                                    if (KeybindManager.invokeBinding2(b, 7465940600734407551L, l2) != null) {
                                                        return;
                                                    }
                                                }
                                                catch (MatchException matchException) {
                                                    throw KeybindManager.invokeBinding3(matchException, 7465030481135002771L, l2);
                                                }
                                                try {
                                                    try {
                                                        Object[] objectArray2 = new Object[2];
                                                        objectArray2[1] = l4;
                                                        objectArray2[0] = n;
                                                        bl = KeybindManager.invokeBinding4(this, objectArray2, 7466452641620040537L, l2);
                                                        if (n3 == 0) break block23;
                                                        if (bl) break block24;
                                                    }
                                                    catch (MatchException matchException) {
                                                        throw KeybindManager.invokeBinding5(matchException, 7465030481135002771L, l2);
                                                    }
                                                    bl = this.d;
                                                }
                                                catch (MatchException matchException) {
                                                    throw KeybindManager.invokeBinding6(matchException, 7465030481135002771L, l2);
                                                }
                                            }
                                            try {
                                                try {
                                                    try {
                                                        try {
                                                            if (n3 == 0) break block25;
                                                            if (bl) break block26;
                                                        }
                                                        catch (MatchException matchException) {
                                                            throw KeybindManager.invokeBinding7(matchException, 7465030481135002771L, l2);
                                                        }
                                                        cJ_C01292 = this;
                                                        n4 = n;
                                                        if (n3 == 0) break block27;
                                                    }
                                                    catch (MatchException matchException) {
                                                        throw KeybindManager.invokeBinding8(matchException, 7465030481135002771L, l2);
                                                    }
                                                    if (n4 != f) break block28;
                                                }
                                                catch (MatchException matchException) {
                                                    throw KeybindManager.invokeBinding9(matchException, 7465030481135002771L, l2);
                                                }
                                                n4 = 1;
                                                break block27;
                                            }
                                            catch (MatchException matchException) {
                                                throw KeybindManager.invokeBinding10(matchException, 7465030481135002771L, l2);
                                            }
                                        }
                                        n4 = 0;
                                    }
                                    cJ_C01292.d = ((((int)(n4) & 1) != 0));
                                }
                                try {
                                    object = this;
                                    if (n3 == 0) break block29;
                                    bl = ((KeybindManager)object).c;
                                }
                                catch (MatchException matchException) {
                                    throw KeybindManager.invokeBinding11(matchException, 7465030481135002771L, l2);
                                }
                            }
                            try {
                                try {
                                    try {
                                        if (bl) break block30;
                                        cJ_C01293 = this;
                                        n2 = n;
                                        if (n3 == 0) break block31;
                                    }
                                    catch (MatchException matchException) {
                                        throw KeybindManager.invokeBinding12(matchException, 7465030481135002771L, l2);
                                    }
                                    if (n2 != e) break block32;
                                }
                                catch (MatchException matchException) {
                                    throw KeybindManager.invokeBinding13(matchException, 7465030481135002771L, l2);
                                }
                                n2 = 1;
                                break block31;
                            }
                            catch (MatchException matchException) {
                                throw KeybindManager.invokeBinding14(matchException, 7465030481135002771L, l2);
                            }
                        }
                        n2 = 0;
                    }
                    cJ_C01293.c = ((((int)(n2) & 1) != 0));
                }
                object = KeybindManager.invokeBinding17(this.a, KeybindManager.invokeBinding15(n, 7464816502895773740L, l2), KeybindManager.invokeBinding16(1, 7464816502895773740L, l2), 7465426544014665780L, l2);
            }
            Object[] objectArray3 = new Object[5];
            objectArray3[4] = l;
            objectArray3[3] = 0;
            objectArray3[2] = 1;
            objectArray3[1] = n;
            objectArray3[0] = KeybindManager.invokeBinding20(KeybindManager.invokeBinding19(b, 7466704992133029070L, l2), 7464757636333974895L, l2);
            KeybindManager.invokeBinding21(new MouseAccessor(KeybindManager.invokeBinding18(b, 7466486880622695340L, l2)), objectArray3, 7466900755510800508L, l2);
        }
    }

   private void bReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 105169953416565L ^ var3;
      long var5 = var3 ^ 29578791094731L;
      long var7 = var3 ^ 121948029505675L;
      int var9 = Event.cReturningInt();
      Object[] var10004 = new Object[]{null, var7};
      var10004[0] = var2;
      Object[] var11 = var10004;
      KeybindManager var10 = this;
      byte var10000 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
      int var28 = var9;
      byte var27 = var10000;
      int var22 = var27;
      byte var21 = var27;
      if (var28 != 0) {
         byte var29 = var21;
         if (var29 != 0) {
            MinecraftClient var13 = b;
            MouseAccessor var38 = new MouseAccessor(var13.mouse);
            MinecraftClient var14 = b;
            Window var15 = var14.getWindow();
            long var10001 = var15.getHandle();
            Object[] var10007 = new Object[]{null, null, null, null, var5};
            var10007[3] = 0;
            var10007[2] = 0;
            var10007[1] = var2;
            var10007[0] = var10001;
            Object[] var17 = var10007;
            MouseAccessor var16 = var38;
            var16.aReturningVoid(var17);
            HashMap var39 = this.a;
            int var18 = var2;
            Integer var20 = var18;
            HashMap var19 = var39;
            var19.remove(var20);
         }

         var22 = var2;
      }

      int var32 = var9;
      int var31 = e;
      int var30 = var22;
      int var25 = var30;
      int var26 = var31;
      int var23 = var30;
      int var24 = var31;
      if (var32 != 0) {
         int var34 = var24;
         int var33 = var23;
         if (var33 == var34) {
            this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
         }

         var26 = f;
         var25 = var2;
      }

      int var36 = var26;
      int var35 = var25;
      if (var35 == var36) {
         this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
      }
   }

   private void cReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 105169953416565L ^ var2;
      long var5 = var2 ^ 54493511726017L;
      long var7 = var2 ^ 825558861375L;
      int var9 = Event.bReturningInt();
      Object[] var10004 = new Object[]{null, var7};
      var10004[0] = var4;
      Object[] var12 = var10004;
      KeybindManager var11 = this;
      byte var10000 = ((byte)((var11.aReturningBoolean(var12)) ? 1 : 0));
      int var31 = var9;
      byte var30 = var10000;
      int var29 = var30;
      byte var28 = var30;
      if (var31 == 0) {
         byte var32 = var28;
         if (var32 == 0) {
            return;
         }

         HashMap var38 = this.a;
         int var14 = var4;
         Integer var16 = var14;
         HashMap var15 = var38;
         Integer var17 = (Integer)var15.get(var16);
         int var33 = var17;
         var29 = var33;
      }

      label21: {
         int var10 = var29;
         int var34 = var9;
         if (var34 == 0) {
            int var35 = var10;
            if (var35 <= 0) {
               break label21;
            }

            HashMap var39 = this.a;
            int var20 = var4;
            Integer var10001 = var20;
            int var21 = var10 - 1;
            Integer var24 = var21;
            Integer var23 = var10001;
            HashMap var22 = var39;
            var22.replace(var23, var24);
         }

         int var36 = var9;
         if (var36 == 0) {
            return;
         }
      }

      var10004 = new Object[]{null, var5};
      var10004[0] = var4;
      Object[] var27 = var10004;
      KeybindManager var26 = this;
      var26.bReturningVoid(var27);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 111089371140342L ^ 72625462272801L;
      var10001 = 111089371140342L ^ 48534829086101L;
      int var8 = Event.cReturningInt();
      int var20 = var8;
      if (var20 != 0) {
         MinecraftClient var9 = b;
         boolean var21 = var9.isWindowFocused();
         if (!var21) {
            int var25 = e;
            Object[] var28 = new Object[]{null, 42899951596503L};
            var28[0] = var25;
            Object[] var12 = var28;
            KeybindManager var11 = this;
            var11.bReturningVoid(var12);
            int var26 = f;
            var28 = new Object[]{null, 42899951596503L};
            var28[0] = var26;
            Object[] var14 = var28;
            KeybindManager var13 = this;
            var13.bReturningVoid(var14);
            this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
            return;
         }

         int var23 = e;
         Object[] var10004 = new Object[]{null, 80459362887011L};
         var10004[0] = var23;
         Object[] var17 = var10004;
         KeybindManager var16 = this;
         var16.cReturningVoid(var17);
         int var24 = f;
         var10004 = new Object[]{null, 80459362887011L};
         var10004[0] = var24;
         Object[] var19 = var10004;
         KeybindManager var18 = this;
         var18.cReturningVoid(var19);
      }
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 114895702627992L ^ 8876381835363L;
      var10001 = 114895702627992L ^ 24012734182413L;
      var10001 = 114895702627992L ^ 138764565778609L;
      int var10 = Event.bReturningInt();
      int var36 = var10;
      byte var35 = ((byte)((this.d) ? 1 : 0));
      int var28 = var35;
      byte var27 = var35;
      if (var36 == 0) {
         byte var37 = var27;
         if (var37 == 0) {
            return;
         }

         MinecraftClient var13 = b;
         GameOptions var14 = var13.options;
         KeyBindingAccessor var10000 = new KeyBindingAccessor(var14.useKey);
         Object[] var16 = new Object[]{106023618381563L};
         KeyBindingAccessor var15 = var10000;
         Key var17 = var15.aReturningVoid(var16);
         int var38 = var17.getCode();
         var28 = var38;
      }

      KeybindManager var33;
      int var34;
      label36: {
         int var11 = var28;
         Object[] var10004 = new Object[]{null, 138168493351573L};
         var10004[0] = var11;
         Object[] var20 = var10004;
         KeybindManager var19 = this;
         boolean var49 = var19.bReturningBoolean(var20);
         int var40 = var10;
         boolean var39 = var49;
         boolean var32 = var39;
         boolean var29 = var39;
         if (var40 == 0) {
            boolean var41 = var29;
            if (!var41) {
               this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
               return;
            }

            Object[] var24 = new Object[0];
            ItemUseEvent var23 = var1;
            var23.aReturningVoid(var24);
            int var44 = var10;
            int var43 = f;
            KeybindManager var42 = this;
            var33 = var42;
            var34 = var43;
            KeybindManager var30 = var42;
            int var31 = var43;
            if (var44 != 0) {
               break label36;
            }

            var10004 = new Object[]{null, 24513948157481L};
            var10004[0] = var31;
            Object[] var26 = var10004;
            KeybindManager var25 = var30;
            boolean var45 = var25.aReturningBoolean(var26);
            var32 = var45;
         }

         boolean var46 = var32;
         if (var46) {
            return;
         }

         byte var48 = 0;
         KeybindManager var47 = this;
         var33 = var47;
         var34 = var48;
      }

      var33.d = dev.prestige.recovery.SourceSupport.asBoolean(var34);
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 52058353999886L ^ 87090321565429L;
      var10001 = 52058353999886L ^ 91195514913435L;
      var10001 = 52058353999886L ^ 62755354617383L;
      int var10 = Event.cReturningInt();
      int var36 = var10;
      byte var35 = ((byte)((this.c) ? 1 : 0));
      int var28 = var35;
      byte var27 = var35;
      if (var36 != 0) {
         byte var37 = var27;
         if (var37 == 0) {
            return;
         }

         MinecraftClient var13 = b;
         GameOptions var14 = var13.options;
         KeyBindingAccessor var10000 = new KeyBindingAccessor(var14.attackKey);
         Object[] var16 = new Object[]{106023618381563L};
         KeyBindingAccessor var15 = var10000;
         Key var17 = var15.aReturningVoid(var16);
         int var38 = var17.getCode();
         var28 = var38;
      }

      KeybindManager var33;
      int var34;
      label36: {
         int var11 = var28;
         Object[] var10004 = new Object[]{null, 138168493351573L};
         var10004[0] = var11;
         Object[] var20 = var10004;
         KeybindManager var19 = this;
         boolean var49 = var19.bReturningBoolean(var20);
         int var40 = var10;
         boolean var39 = var49;
         boolean var32 = var39;
         boolean var29 = var39;
         if (var40 != 0) {
            boolean var41 = var29;
            if (!var41) {
               this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
               return;
            }

            Object[] var24 = new Object[0];
            AttackInputEvent var23 = var1;
            var23.aReturningVoid(var24);
            int var44 = var10;
            int var43 = e;
            KeybindManager var42 = this;
            var33 = var42;
            var34 = var43;
            KeybindManager var30 = var42;
            int var31 = var43;
            if (var44 == 0) {
               break label36;
            }

            var10004 = new Object[]{null, 24513948157481L};
            var10004[0] = var31;
            Object[] var26 = var10004;
            KeybindManager var25 = var30;
            boolean var45 = var25.aReturningBoolean(var26);
            var32 = var45;
         }

         boolean var46 = var32;
         if (var46) {
            return;
         }

         byte var48 = 0;
         KeybindManager var47 = this;
         var33 = var47;
         var34 = var48;
      }

      var33.c = dev.prestige.recovery.SourceSupport.asBoolean(var34);
   }

   @EventListener
   public void a(AttackTargetUpdateEvent var1) {
      long var10001 = 83907915179269L ^ 48644152026110L;
      var10001 = 83907915179269L ^ 54947908241296L;
      var10001 = 83907915179269L ^ 99075438830380L;
      int var10 = Event.cReturningInt();
      int var36 = var10;
      byte var35 = ((byte)((this.c) ? 1 : 0));
      int var28 = var35;
      byte var27 = var35;
      if (var36 != 0) {
         byte var37 = var27;
         if (var37 == 0) {
            return;
         }

         MinecraftClient var13 = b;
         GameOptions var14 = var13.options;
         KeyBindingAccessor var10000 = new KeyBindingAccessor(var14.attackKey);
         Object[] var16 = new Object[]{106023618381563L};
         KeyBindingAccessor var15 = var10000;
         Key var17 = var15.aReturningVoid(var16);
         int var38 = var17.getCode();
         var28 = var38;
      }

      KeybindManager var33;
      int var34;
      label36: {
         int var11 = var28;
         Object[] var10004 = new Object[]{null, 138168493351573L};
         var10004[0] = var11;
         Object[] var20 = var10004;
         KeybindManager var19 = this;
         boolean var49 = var19.bReturningBoolean(var20);
         int var40 = var10;
         boolean var39 = var49;
         boolean var32 = var39;
         boolean var29 = var39;
         if (var40 != 0) {
            boolean var41 = var29;
            if (!var41) {
               this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
               return;
            }

            Object[] var24 = new Object[0];
            AttackTargetUpdateEvent var23 = var1;
            var23.aReturningVoid(var24);
            int var44 = var10;
            int var43 = e;
            KeybindManager var42 = this;
            var33 = var42;
            var34 = var43;
            KeybindManager var30 = var42;
            int var31 = var43;
            if (var44 == 0) {
               break label36;
            }

            var10004 = new Object[]{null, 24513948157481L};
            var10004[0] = var31;
            Object[] var26 = var10004;
            KeybindManager var25 = var30;
            boolean var45 = var25.aReturningBoolean(var26);
            var32 = var45;
         }

         boolean var46 = var32;
         if (var46) {
            return;
         }

         byte var48 = 0;
         KeybindManager var47 = this;
         var33 = var47;
         var34 = var48;
      }

      var33.c = dev.prestige.recovery.SourceSupport.asBoolean(var34);
   }

   private boolean bReturningBoolean(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 105169953416565L ^ var3;
      int var5 = Event.bReturningInt();
      int var36 = var5;
      int var35 = var2;
      int var23 = var35;
      int var22 = var35;
      if (var36 == 0) {
         int var37 = var22;
         if (var37 < 0) {
            return true;
         }

         var23 = var2;
      }

      int var10001 = (int)h;
      int var40 = var5;
      int var39 = var10001;
      int var38 = var23;
      int var31 = var38;
      int var32 = var39;
      int var24 = var38;
      int var25 = var39;
      if (var40 == 0) {
         int var42 = var25;
         int var41 = var24;
         if (var41 <= var42) {
            MinecraftClient var9 = b;
            Window var10 = var9.getWindow();
            var10000 = var10.getHandle();
            int var13 = var2;
            long var11 = var10000;
            int var60 = GLFW.glfwGetMouseButton(var11, var13);
            int var44 = var5;
            int var43 = var60;
            int var28 = var43;
            int var26 = var43;
            int var29;
            if (var44 == 0) {
               int var45 = var26;
               int var27 = var45;
               byte var47 = 1;
               int var46 = var27;
               if (var46 != var47) {
                  byte var48 = 1;
                  var29 = var48;
               } else {
                  var29 = 0;
               }
            } else {
               int var49 = var28;
               var29 = var49;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var29);
         }

         MinecraftClient var17 = b;
         Window var18 = var17.getWindow();
         var10000 = var18.getHandle();
         int var21 = var2;
         long var19 = var10000;
         int var58 = GLFW.glfwGetKey(var19, var21);
         int var51 = var5;
         int var50 = var58;
         int var33 = var50;
         int var30 = var50;
         if (var51 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var33);
         }

         byte var53 = 1;
         int var52 = var30;
         var31 = var52;
         var32 = var53;
      }

      int var55 = var32;
      int var54 = var31;
      return var54 != var55;
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(71121335002696L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 9141185141337918091L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)126L,
            (byte)32476L,
            (byte)8313859L,
            (byte)2128348020L,
            (byte)544857093175L,
            (byte)139483415852934L,
            (byte)35707754458351242L,
            (byte)9141185141337918091L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // h = var8;
      e = 0;
      f = 1;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 13;
            yield var15;
         }
         case 1 -> {
            byte var16 = 28;
            yield var16;
         }
         case 2 -> {
            byte var17 = 36;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 7;
            yield var19;
         }
         case 5 -> {
            byte var20 = 20;
            yield var20;
         }
         case 6 -> {
            byte var21 = 35;
            yield var21;
         }
         case 7 -> {
            byte var22 = 57;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 37;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 60;
            yield var27;
         }
         case 13 -> {
            byte var28 = 34;
            yield var28;
         }
         case 14 -> {
            byte var29 = 23;
            yield var29;
         }
         case 15 -> {
            byte var30 = 24;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 50;
            yield var32;
         }
         case 18 -> {
            byte var33 = 22;
            yield var33;
         }
         case 19 -> {
            byte var34 = 18;
            yield var34;
         }
         case 20 -> {
            byte var35 = 61;
            yield var35;
         }
         case 21 -> {
            byte var36 = 25;
            yield var36;
         }
         case 22 -> {
            byte var37 = 30;
            yield var37;
         }
         case 23 -> {
            byte var38 = 21;
            yield var38;
         }
         case 24 -> {
            byte var39 = 3;
            yield var39;
         }
         case 25 -> {
            byte var40 = 62;
            yield var40;
         }
         case 26 -> {
            byte var41 = 52;
            yield var41;
         }
         case 27 -> {
            byte var42 = 5;
            yield var42;
         }
         case 28 -> {
            byte var43 = 12;
            yield var43;
         }
         case 29 -> {
            byte var44 = 17;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 6;
            yield var46;
         }
         case 32 -> {
            byte var47 = 9;
            yield var47;
         }
         case 33 -> {
            byte var48 = 54;
            yield var48;
         }
         case 34 -> {
            byte var49 = 46;
            yield var49;
         }
         case 35 -> {
            byte var50 = 26;
            yield var50;
         }
         case 36 -> {
            byte var51 = 51;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 39;
            yield var53;
         }
         case 39 -> {
            byte var54 = 58;
            yield var54;
         }
         case 40 -> {
            byte var55 = 59;
            yield var55;
         }
         case 41 -> {
            byte var56 = 42;
            yield var56;
         }
         case 42 -> {
            byte var57 = 47;
            yield var57;
         }
         case 43 -> {
            byte var58 = 16;
            yield var58;
         }
         case 44 -> {
            byte var59 = 33;
            yield var59;
         }
         case 45 -> {
            byte var60 = 4;
            yield var60;
         }
         case 46 -> {
            byte var61 = 11;
            yield var61;
         }
         case 47 -> {
            byte var62 = 0;
            yield var62;
         }
         case 48 -> {
            byte var63 = 40;
            yield var63;
         }
         case 49 -> {
            byte var64 = 41;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 56;
            yield var66;
         }
         case 52 -> {
            byte var67 = 19;
            yield var67;
         }
         case 53 -> {
            byte var68 = 44;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 38;
            yield var70;
         }
         case 56 -> {
            byte var71 = 15;
            yield var71;
         }
         case 57 -> {
            byte var72 = 27;
            yield var72;
         }
         case 58 -> {
            byte var73 = 1;
            yield var73;
         }
         case 59 -> {
            byte var74 = 10;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 14;
            yield var76;
         }
         case 62 -> {
            byte var77 = 31;
            yield var77;
         }
         default -> 55;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "\u0005_e4b9\u0005_rhn6\u001f\u0014rvn#\u0018e\"+?";
      i[1] = "[\u000f\\\"/y[\u000fK~#vADK`#cF5\u001b=w";
      i[2] = "rQ\u0017w:\u0013dQ\u0012-)\u0004s\u001a\u0011+%\u0010b]\u0006<n/";
      i[3] = "4j0\u0010:VAJ;\u001f+\u0019 D0\u0014/CT";
      i[4] = "zK\u0005cv/zK\u0012?z `\u0000\u0012!z5gqB{,s0M\u001d,h5K\u001dA{";
      i[5] = "0bwNK{&br\u0014Xl1)q\u0012Tx nf\u0005\u001fh\u001e";
      i[6] = "K/9W#\b@ (\u0018@\u0005U-'su\u0007D>;_b\n";
      i[7] = "\u0012\r&G\u0015\u001fg--H\u0004P\u0006#&C\u0000\nr";
      i[8] = boolean.class;
      j[8] = "java/lang/Boolean";
      i[9] = int.class;
      j[9] = "java/lang/Integer";
      i[10] = "t&>/\u0002;b&;u\u0011,um8s\u001d8d*/dV*U";
      i[11] = "12$K\u000fYD\u0012/D\u001e\u0016%\u001c$O\u001aLQ";
      i[12] = "6Nz*POCnq%A\u0000\"`z.EZV";
      i[13] = void.class;
      j[13] = "java/lang/Void";
      i[14] = "v>'v_>v>0*S1lu04S$k\u0004`h\u0006";
      i[15] = "c\u0007=\u0011VMc\u0007*MZByL*SZW~=x\u000f\u000f\u0015";
      i[16] = long.class;
      j[16] = "java/lang/Long";
      i[17] = "\u00186J+z5\u001d#A+q.\u00113\u0003BZ\u0004 ";
      i[18] = "\u0004#V*\u0017\u0000\u000f,Gep\u0002\u001a'G.K";
      i[19] = ")\u00198SD\u001b)\u0019/\u000fH\u00143R/\u0011H\u00014#xN\u001e";
      i[20] = "z[on\u0003 z[x2\u000f/`\u0010x,\u000f:ga(q\\";
      i[21] = "~1L\t\f\u001ch1IS\u001f\u000b\u007fzJU\u0013\u001fn=]BX#";
      i[22] = "<\u0003Q\u0010YnI#Z\u001fH!(-Q\u0014L{\\";
      i[23] = "2[AOd{,S[\u0000\u0002o+RzO:";
      i[24] = "WSm]dN\\\\|\u0012\u0005@WWxH";
      i[25] = "d\u001fs\u0014,\u000b\u0011?x\u001b=Dp1s\u00109\u001e\u0004";
      i[26] = "+yBH_(=yG\u0012L?*2D\u0014@+;uS\u0003\u000b;#uQ\bQv\u001fnQ\u0015Q1(y";
      i[27] = "\u0002[m}Ki\u0014[h'X~\u0003\u0010k!Tj\u0012W|6\u001f{*";
      i[28] = "^N\u001ay\u0006\u001d+n\u0011v\u0017RJ`\u001a}\u0013\b>";
      i[29] = "&#\u001d]p7S\u0003\u0016Rax2\r\u001dYe\"F";
      i[30] = "\u001ecDk\u000b\u0017Ai\u0011bz\u0016!9\u0004*\u0016\u0013\u001ex\u0015bJ|";
      i[31] = "YA#!\u007f%\b]; \u0001.bS+kxx[_=*bDS]-r?y\u0005\u00009y\u0001";
      i[32] = "gY(\u001af69['}2/dF'*eq4\u001fK\u0011l3u\u001e2\f6-s";
      i[33] = "^\u00037\"y(\u000e\u0004dq\t,\\@\t.2-JM53g>O<iug8@\u0000t t=1";
      i[34] = "@\u0006A;\u001cc\u0014Q\\(%j\u0016KB6IXB\u000b\u001em%1\u0003\rN>\u001ap\u0012E\u0012Q";
      i[35] = "QhRUk\u001eQhRM\u000bJ^?KafYy<E.aC\u0001/\u000bPd\u0015V!4\u0010s\u001fV>\u000bQbW\nQ\nV1IUnKGy\u0015:";
      i[36] = "\u0010wrEV@O}'L'@/-2\u0004KD\u0010l#L\u0017+";
      i[37] = "n4+t?P>3x'OPfmiq.]zHxiO[:enisFovk\u0018q\u0001=dh{s@o7\u0015";
      i[38] = "U}|x~8\u000b\u007fs\u001f!-Gfxs\u0013y\u00068.\u001fzz\u0007ib|x;U:\u001f";
      i[39] = "_zo#0\u001c\u000bqe<M\u001fRg_5)\u0003Y\u001b?$w\u0012[$~5?N4";
      i[40] = "JN0*cQ\u0014L?M7HIQ?\u001a`\u0016\u001e\u0004S!)\u0011[^<}%\u0015\u0019";
      i[41] = "y\r(j-F(\u00110kSNB\u001f  *\u001b{\u00136a0'|Fe4.D~\u00077gS";
      i[42] = "\u0018j\u0015c|fG`@j\rd'mTct1\u001eaB\"n\r\u0016cRz30@>Fq\r";
      i[43] = "Hy}WPs\u0018~.\u0004 bJ>'RKu'&xU[i\u001b;-F^\u0018G}-@Q$Z(>E x\u001c(8J\u001ceI;=;";
      i[44] = "?lG\u001em!9+C\u0003\r6^4S\u000e6c\"%\u001a\u000fm";
      i[45] = "z\u0013<SA'$\u001134\u001e2h\b8X,e.Vo\u000f{6q\u000eo\u000eF lQ$4";
      i[46] = "[6\u0007\ta>\ng\u001c\u000f\u0006&5m\u0015\u000f\u007fs\fa\u0003NeO\u0004c\u0013\u00168rR>\u0007\u001d\u0006";
      i[47] = " l\u0000BY\u001d1u\u0005;[\u00126zWl\fCk ;R\b\u0015)xCJUM&";
      i[48] = "&\t\u0000\u0005Oyr\u0002\n\u001a2e$\f\u0013\u0017uuMV\u0016@^tr\u0017\u0007\b\u0002\u001b&\t\u0000\u0005Oyr\u0002\n\u001a2";
      i[49] = "Cf\u0018@>WU{G\u000b\u0004\u000fG\u007f\u001e\u0017h=\u0016?OH\u0004\u0000L8\u0000Oz\u0005\u001ao\u000ep";
      i[50] = "#y\u001f\u0017\u0012us~LDbd!#F\u0005\u000f\u001e,}O\u0000\u0013\"1(\\\u0005b~w(Z\n^c\";_{";
      i[51] = "(U%}\u0000\u0000vW*\u001aT\u0019+J*M\u0003Fw\u0016FaHC?B(pQF";
      i[52] = "`\u0014\u0011\u001de\u0014 GEE\u0000AY\u0015U\u0003y\u0014`\u0019CBc(bGO\u00129D6\u0010R\u0001\u0000";
      i[53] = "\n<\u0007hwk[ \u001fi\tc1q\u0018&kf^/\u001d82\n\r#\t;eeS&\u0017b\t";
      i[54] = "ss6d\u0013\u0012\"o.em\u0019Ha>.\u0014Oqm(o\u000esv8{:\u0010\u0010ty)im";
      i[55] = "r.MP2O#2UQLEI<E\u001a5\u0012p0S[/.x2C\u0003r\u0013.oW\bL";
      i[56] = "7[\u001e\u0007\tA&B\u001b~\u000bN!MI)\\\u001et\u0015%\u0017XI>O]\u000f\u0005\u00111";
      i[57] = ")U{Re^)U{J\u0005\n&\u0002bfh\u0019\u0007\u000b`Rh/?\u0010aNce(\n&W:\u001b-\\qY\u0005[:VqF:\u001a+\u001e-);\u001dx\u0000r\u0016z\f0\\\u001d";
      i[58] = "\rA%D\u0010Z\u001c\b$\u001f/OlR=\u0004V\u001aU^+EL&]\\;\u001d\u0011\u001b\u000b\u0001/\u0016/";
      i[59] = "N\u0004-_iq\u001e\u0003~\f\u0019b\\G\u0013S\"tZJ/Nwg_;s\bwaP\u0007n]dd![(]bk\u001dF}Ng\u001a";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1736221069440967L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1736221069440967L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1736221069440967L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 217;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 90;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 211;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 76;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 72;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 99;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 217;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 90;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 211;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cJ_C0129",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cJ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = a(MethodHandles.lookup(), "c", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Screen invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = a(
                  MethodHandles.lookup(),
                  "Ù",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/gui/screen/Screen;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Screen)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = a(MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = a(
                  MethodHandles.lookup(), "c", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Integer invokeBinding15(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = a(MethodHandles.lookup(), "c", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Integer invokeBinding16(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = a(MethodHandles.lookup(), "c", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding17(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache17;
         MethodHandle var10 = bindingCache17;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache17 = a(
                  MethodHandles.lookup(),
                  "H",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static Mouse invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = a(
                  MethodHandles.lookup(), "Ù", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/Mouse;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Mouse)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Window invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = a(
                  MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static long invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = a(MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;JJ)J", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (long)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding21(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache21;
         MethodHandle var9 = bindingCache21;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache21 = a(
                  MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
