package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.client.ui.gui.MenuState;

import dev.zprestige.prestige.api.events.KeyInputEvent;
import dev.zprestige.prestige.api.events.MouseButtonEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.events.ScreenBackgroundTintEvent;
import dev.zprestige.prestige.api.util.KeyCodeMap;
import dev.zprestige.prestige.client.ui.ClickGuiScreen;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.ui.MenuSettings;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;

public class MenuController implements MinecraftAccess {
   private static Double a;
   private static final Map c;
   private long d;
   private static final long e = 81108578549404L;
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[85];
   private static final String[] j = new String[85];

   public MenuController(long var1) {
      super();
      var1 = 81108578549404L ^ var1;
      long var3 = var1 ^ 34200402540034L;

      short var10001 = 5757;
      long var10002 = 145621484522138392L ^ var1;
      this.d = 0L;
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(KeyInputEvent var1) {
      int var10;
      label122: {
         long var10001 = 56340664044349L ^ 15326296080219L;
         var10001 = 56340664044349L ^ 72436964488037L;
         var10001 = 56340664044349L ^ 73984847604459L;
         var10 = Event.cReturningInt();
         Object[] var15 = new Object[0];
         KeyInputEvent var14 = var1;
         int var10000 = var14.dReturningInt(var15);
         int var115 = var10;
         int var114 = var10000;
         int var91 = var114;
         int var90 = var114;
         if (var115 != 0) {
            int var116 = var90;
            if (var116 != 0) {
               break label122;
            }

            Object[] var18 = new Object[0];
            KeyInputEvent var17 = var1;
            int var117 = var17.aReturningInt(var18);
            var91 = var117;
         }

         ModuleManager var180 = Prestige.d;
         Object[] var21 = new Object[0];
         ModuleManager var20 = var180;
         MenuSettings var181 = var20.aReturningMenuSettings(var21);
         Object[] var23 = new Object[0];
         MenuSettings var22 = var181;
         BindSetting var24 = var22.cReturningVoid(var23);
         Integer var25 = (Integer)var24.aReturningObject();
         int var182 = var25;
         Object[] var10004 = new Object[]{null, 69053329355878L};
         var10004[0] = var182;
         Object[] var26 = var10004;
         int var119 = KeyCodeMap.aReturningInt(var26);
         int var118 = var91;
         if (var118 == var119) {
            ClickGuiScreen var28 = Prestige.k;
            MinecraftClient var27 = b;
            var27.setScreen(var28);
            ClickGuiScreen var171 = Prestige.k;
            Object[] var30 = new Object[0];
            ClickGuiScreen var29 = var171;
            var29.aReturningVoid(var30);
         }
      }

      ModuleManager var32 = Prestige.d;
      List var33 = var32.aReturningVoid();
      Iterator var11 = var33.iterator();

      while (true) {
         Iterator var34 = var11;
         boolean var120 = var34.hasNext();
         if (!var120) {
            break;
         }

         label112: {
            Module var12;
            int var13;
            label126: {
               Iterator var35 = var11;
               var12 = (Module)var35.next();
               Object[] var37 = new Object[]{123644152586710L};
               Module var36 = var12;
               int var172 = var36.bReturningInt(var37);
               Object[] var10003 = new Object[]{null, 69053329355878L};
               var10003[0] = var172;
               Object[] var38 = var10003;
               var13 = KeyCodeMap.aReturningInt(var38);
               Object[] var40 = new Object[0];
               Module var39 = var12;
               BindSetting var41 = var39.bReturningBindSetting(var40);
               byte var173 = ((byte)((var41.bReturningVoid()) ? 1 : 0));
               int var122 = var10;
               byte var121 = var173;
               byte var93 = var121;
               byte var92 = var121;
               if (var122 != 0) {
                  byte var123 = var92;
                  if (var123 == 0) {
                     break label126;
                  }

                  Module var43 = var12;
                  byte var124 = ((byte)((var43.aReturningBoolean()) ? 1 : 0));
                  var93 = var124;
               }

               int var126 = var10;
               byte var125 = var93;
               int var95 = var125;
               byte var94 = var125;
               if (var126 != 0) {
                  byte var127 = var94;
                  if (var127 != 0) {
                     MinecraftClient var46 = b;
                     Screen var128 = var46.currentScreen;
                     if (var128 != null) {
                        Object[] var49 = new Object[]{126290808879192L};
                        Module var48 = var12;
                        var48.aReturningVoid(var49);
                        int var129 = var10;
                        if (var129 != 0) {
                           continue;
                        }
                     }
                  }

                  Object[] var52 = new Object[0];
                  KeyInputEvent var51 = var1;
                  var95 = var51.dReturningInt(var52);
               }

               int var131 = var10;
               int var130 = var95;
               int var100 = var130;
               int var96 = var130;
               if (var131 != 0) {
                  int var132 = var96;
                  if (var132 == 0) {
                     Module var54 = var12;
                     var173 = ((byte)((var54.aReturningBoolean()) ? 1 : 0));
                     int var134 = var10;
                     byte var133 = var173;
                     int var99 = var133;
                     byte var97 = var133;
                     if (var134 != 0) {
                        byte var135 = var97;
                        byte var98 = var135;
                        byte var136 = var98;
                        if (var136 == 0) {
                           break label112;
                        }

                        var99 = var13;
                     }

                     Object[] var58 = new Object[0];
                     KeyInputEvent var57 = var1;
                     int var138 = var57.aReturningInt(var58);
                     int var137 = var99;
                     if (var137 != var138) {
                        break label112;
                     }

                     Object[] var60 = new Object[]{126290808879192L};
                     Module var59 = var12;
                     var59.aReturningVoid(var60);
                     int var139 = var10;
                     if (var139 != 0) {
                        break label112;
                     }
                  }

                  Object[] var63 = new Object[0];
                  KeyInputEvent var62 = var1;
                  int var140 = var62.dReturningInt(var63);
                  var100 = var140;
               }

               byte var142 = 1;
               int var141 = var100;
               if (var141 != var142) {
                  break label112;
               }

               MinecraftClient var65 = b;
               Screen var143 = var65.currentScreen;
               if (var143 != null) {
                  break label112;
               }

               Module var67 = var12;
               var173 = ((byte)((var67.aReturningBoolean()) ? 1 : 0));
               int var145 = var10;
               byte var144 = var173;
               int var103 = var144;
               byte var101 = var144;
               if (var145 != 0) {
                  byte var146 = var101;
                  byte var102 = var146;
                  byte var147 = var102;
                  if (var147 != 0) {
                     break label112;
                  }

                  var103 = var13;
               }

               Object[] var71 = new Object[0];
               KeyInputEvent var70 = var1;
               int var149 = var70.aReturningInt(var71);
               int var148 = var103;
               if (var148 != var149) {
                  break label112;
               }

               Object[] var73 = new Object[]{126290808879192L};
               Module var72 = var12;
               var72.aReturningVoid(var73);
               int var150 = var10;
               if (var150 != 0) {
                  break label112;
               }
            }

            MinecraftClient var75 = b;
            Screen var151 = var75.currentScreen;
            label82:
            if (var151 == null) {
               Object[] var78 = new Object[]{123644152586710L};
               Module var77 = var12;
               int var176 = var77.bReturningInt(var78);
               int var154 = var10;
               // int var152 = var176;
               int var108 = var152;
               byte var109 = var153;
               int var104 = var152;
               byte var105 = var153;
               if (var154 != 0) {
                  byte var156 = var105;
                  int var155 = var104;
                  int var106 = var155;
                  byte var107 = var156;
                  byte var158 = var107;
                  int var157 = var106;
                  if (var157 == var158) {
                     break label82;
                  }

                  Object[] var82 = new Object[0];
                  KeyInputEvent var81 = var1;
                  var176 = var81.dReturningInt(var82);
                  byte var160 = 1;
                  int var159 = var176;
                  var108 = var159;
                  var109 = var160;
               }

               int var163 = var10;
               byte var162 = var109;
               int var161 = var108;
               int var112 = var161;
               int var113 = var162;
               int var110 = var161;
               byte var111 = var162;
               if (var163 != 0) {
                  byte var165 = var111;
                  int var164 = var110;
                  if (var164 != var165) {
                     break label82;
                  }

                  Object[] var86 = new Object[0];
                  KeyInputEvent var85 = var1;
                  int var167 = var85.aReturningInt(var86);
                  int var166 = var13;
                  var112 = var166;
                  var113 = var167;
               }

               int var169 = var113;
               int var168 = var112;
               if (var168 == var169) {
                  Object[] var89 = new Object[]{126290808879192L};
                  Module var88 = var12;
                  var88.aReturningVoid(var89);
               }
            }
         }

         int var170 = var10;
         if (var170 == 0) {
            break;
         }
      }
   }

   @EventListener
   public void a(Render2DEvent var1) {
      int var4 = Event.cReturningInt();
      MinecraftClient var7 = b;
      Screen var24 = var7.currentScreen;
      if (var24 == null) {
         label28: {
            label32: {
               long var5 = System.currentTimeMillis();
               long var34;
               int var10000 = (var34 = var5 - this.d - 30L) == 0L ? 0 : (var34 < 0L ? -1 : 1);
               int var26 = var4;
               int var25 = var10000;
               int var23 = var25;
               int var22 = var25;
               if (var26 != 0) {
                  int var27 = var22;
                  if (var27 < 0) {
                     break label28;
                  }

                  this.d = var5;
                  int var28 = var4;
                  if (var28 == 0) {
                     break label32;
                  }

                  byte var29 = ((byte)((MenuState.isOpen()) ? 1 : 0));
                  var23 = var29;
               }

               int var30 = var23;
               if (var30 == 0) {
                  break label28;
               }

               ClickGuiScreen var12 = Prestige.k;
               MinecraftClient var11 = b;
               var11.setScreen(var12);
            }

            ClickGuiScreen var32 = Prestige.k;
            Object[] var15 = new Object[0];
            ClickGuiScreen var14 = var32;
            var14.aReturningVoid(var15);
         }

         Double var31 = a;
         if (var31 != null) {
            MinecraftClient var16 = b;
            Window var33 = var16.getWindow();
            Double var17 = a;
            double var18 = var17;
            int var21 = (int)Math.round(var18);
            Window var20 = var33;
            var20.setScaleFactor(var21);
            a = null;
         }
      }
   }

   @EventListener
   public boolean a(ScreenBackgroundTintEvent var1) {
      return MenuState.isOpen();
   }

   @EventListener
   public void a(MouseButtonEvent var1) {
      long var10001 = 55436333501168L ^ 71155129676456L;
      var10001 = 55436333501168L ^ 72702576323366L;
      var10001 = 55436333501168L ^ 39723613244633L;
      int var10 = Event.bReturningInt();
      KeybindManager var10000 = Prestige.q;
      Object[] var14 = new Object[0];
      MouseButtonEvent var13 = var1;
      int var143 = var13.aReturningInt(var14);
      Object[] var10004 = new Object[]{null, 24513948157481L};
      var10004[0] = var143;
      Object[] var16 = var10004;
      KeybindManager var15 = var10000;
      boolean var92 = var15.aReturningBoolean(var16);
      if (!var92) {
         ModuleManager var18 = Prestige.d;
         List var19 = var18.aReturningVoid();
         Iterator var11 = var19.iterator();

         while (true) {
            Iterator var20 = var11;
            boolean var93 = var20.hasNext();
            if (!var93) {
               break;
            }

            label111: {
               Iterator var21 = var11;
               Module var12 = (Module)var21.next();
               Object[] var23 = new Object[]{123644152586710L};
               Module var22 = var12;
               int var136 = var22.bReturningInt(var23);
               int var95 = var10;
               int var94 = var136;
               int var76 = var94;
               int var75 = var94;
               if (var95 == 0) {
                  // int var96 = var75;
                  if (var96 == var97) {
                     break label111;
                  }

                  Map var137 = c;
                  Object[] var26 = new Object[]{123644152586710L};
                  Module var25 = var12;
                  int var27 = var25.bReturningInt(var26);
                  Integer var29 = var27;
                  Map var28 = var137;
                  byte var98 = ((byte)((var28.containsKey(var29)) ? 1 : 0));
                  var76 = var98;
               }

               int var100 = var10;
               int var99 = var76;
               int var78 = var99;
               int var77 = var99;
               if (var100 == 0) {
                  int var101 = var77;
                  if (var101 == 0) {
                     break label111;
                  }

                  Map var138 = c;
                  Object[] var33 = new Object[]{123644152586710L};
                  Module var32 = var12;
                  int var34 = var32.bReturningInt(var33);
                  Integer var36 = var34;
                  Map var35 = var138;
                  Integer var37 = (Integer)var35.get(var36);
                  int var102 = var37;
                  var78 = var102;
               }

               int var104 = var10;
               int var103 = var78;
               int var80 = var103;
               int var79 = var103;
               if (var104 == 0) {
                  Object[] var40 = new Object[0];
                  MouseButtonEvent var39 = var1;
                  int var106 = var39.aReturningInt(var40);
                  int var105 = var79;
                  if (var105 != var106) {
                     break label111;
                  }

                  Object[] var43 = new Object[0];
                  Module var42 = var12;
                  BindSetting var44 = var42.bReturningBindSetting(var43);
                  byte var107 = ((byte)((var44.bReturningVoid()) ? 1 : 0));
                  var80 = var107;
               }

               label118: {
                  int var109 = var10;
                  int var108 = var80;
                  int var82 = var108;
                  int var81 = var108;
                  if (var109 == 0) {
                     int var110 = var81;
                     if (var110 == 0) {
                        break label118;
                     }

                     Object[] var48 = new Object[0];
                     MouseButtonEvent var47 = var1;
                     int var111 = var47.dReturningInt(var48);
                     var82 = var111;
                  }

                  int var86;
                  int var113 = var10;
                  int var112 = var82;
                  var86 = var112;
                  int var83 = var112;
                  label80:
                  if (var113 == 0) {
                     byte var115 = 1;
                     int var114 = var83;
                     if (var114 == var115) {
                        MinecraftClient var51 = b;
                        Screen var116 = var51.currentScreen;
                        if (var116 == null) {
                           Module var53 = var12;
                           byte var139 = ((byte)((var53.aReturningBoolean()) ? 1 : 0));
                           int var118 = var10;
                           byte var117 = var139;
                           var86 = var117;
                           byte var84 = var117;
                           if (var118 != 0) {
                              break label80;
                           }

                           byte var119 = var84;
                           byte var85 = var119;
                           byte var120 = var85;
                           if (var120 == 0) {
                              Object[] var57 = new Object[]{126290808879192L};
                              Module var56 = var12;
                              var56.aReturningVoid(var57);
                              int var121 = var10;
                              if (var121 == 0) {
                                 break label111;
                              }
                           }
                        }
                     }

                     Object[] var60 = new Object[0];
                     MouseButtonEvent var59 = var1;
                     int var122 = var59.dReturningInt(var60);
                     var86 = var122;
                  }

                  Module var91;
                  label114: {
                     int var124 = var10;
                     int var123 = var86;
                     int var90 = var123;
                     int var87 = var123;
                     if (var124 == 0) {
                        int var125 = var87;
                        if (var125 != 0) {
                           break label111;
                        }

                        int var127 = var10;
                        Module var126 = var12;
                        var91 = var126;
                        Module var88 = var126;
                        if (var127 != 0) {
                           break label114;
                        }

                        Module var128 = var88;
                        Module var89 = var128;
                        Module var64 = var89;
                        byte var129 = ((byte)((var64.aReturningBoolean()) ? 1 : 0));
                        var90 = var129;
                     }

                     int var130 = var90;
                     if (var130 == 0) {
                        break label111;
                     }

                     var91 = var12;
                  }

                  Object[] var67 = new Object[]{126290808879192L};
                  Module var66 = var91;
                  var66.aReturningVoid(var67);
                  int var131 = var10;
                  if (var131 == 0) {
                     break label111;
                  }
               }

               MinecraftClient var68 = b;
               Screen var132 = var68.currentScreen;
               if (var132 != null) {
                  continue;
               }

               Object[] var72 = new Object[0];
               MouseButtonEvent var71 = var1;
               int var140 = var71.dReturningInt(var72);
               byte var134 = 1;
               int var133 = var140;
               if (var133 == var134) {
                  Object[] var74 = new Object[]{126290808879192L};
                  Module var73 = var12;
                  var73.aReturningVoid(var74);
               }
            }

            int var135 = var10;
            if (var135 != 0) {
               break;
            }
         }
      }
   }

   static {

      {

      aReturningVoid();
      Cipher var12;
      Cipher var10000 = var12 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var13 = 1; var13 < 8; var13++) {
         var10003[var13] = (byte)(101731317177898L << var13 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var11 = new long[5];
      String var16 = "®÷³\u0088\u008fdu)¤dµÓ\u0099\"£ã;Êc¾Ùç:x";
      int var17 = "®÷³\u0088\u008fdu)¤dµÓ\u0099\"£ã;Êc¾Ùç:x".length();
      label41:
      while (true) {
         int var10001 = var14;
         var14 += 8;
         byte[] var18 = var16.substring(var10001, var14).getBytes("ISO-8859-1");
         long[] var45 = var11;
         var10001 = var15++;
         long var53 = (var18[0] & 255L) << 56
            | (var18[1] & 255L) << 48
            | (var18[2] & 255L) << 40
            | (var18[3] & 255L) << 32
            | (var18[4] & 255L) << 24
            | (var18[5] & 255L) << 16
            | (var18[6] & 255L) << 8
            | var18[7] & 255L;
         // while (true) {
            long var19 = var53;
            byte[] var21 = var12.doFinal(
               new byte[]{
                  (byte)(var19 >>> 56),
                  (byte)(var19 >>> 48),
                  (byte)(var19 >>> 40),
                  (byte)(var19 >>> 32),
                  (byte)(var19 >>> 24),
                  (byte)(var19 >>> 16),
                  (byte)(var19 >>> 8),
                  (byte)var19
               }
            );
            long var62 = (var21[0] & 255L) << 56
               | (var21[1] & 255L) << 48
               | (var21[2] & 255L) << 40
               | (var21[3] & 255L) << 32
               | (var21[4] & 255L) << 24
               | (var21[5] & 255L) << 16
               | (var21[6] & 255L) << 8
               | var21[7] & 255L;
            switch (var57) {
               case 0:
                  var45[var10001] = var62;
                  if (var14 >= var17) {
                     h = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(101731317177898L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     String var4 = "®û\u0082y\b~\u0000Ä>Û\u008e·9\u0001÷>";
                     int var5 = "®û\u0082y\b~\u0000Ä>Û\u008e·9\u0001÷>".length();
                     do {
                        int var50 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var50, var2).getBytes("ISO-8859-1");
                        var50 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        var62 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var50] = var62;
                     } while (var2 < var5);

                     f = var6;
                     g = new Long[2];
                     a = null;
                     int var24 = (int)var11[2];
                     Integer var47 = var24;
                     Integer var52 = 0;
                     int var26 = (int)var11[1];
                     Integer var56 = var26;
                     Integer var61 = 1;
                     int var28 = (int)var11[3];
                     Integer var64 = var28;
                     Integer var10005 = 2;
                     int var30 = (int)var11[0];
                     Integer var10006 = var30;
                     Integer var10007 = 3;
                     int var32 = (int)var11[4];
                     Integer var10008 = var32;
                     Integer var43 = 4;
                     Integer var42 = var10008;
                     Integer var41 = var10007;
                     Integer var40 = var10006;
                     Integer var39 = var10005;
                     Integer var38 = var64;
                     Integer var37 = var61;
                     Integer var36 = var56;
                     Integer var35 = var52;
                     Integer var34 = var47;
                     c = Map.of(var34, var35, var36, var37, var38, var39, var40, var41, var42, var43);
                     break;
                  }
                  break;
               default:
                  var45[var10001] = var62;
                  if (var14 < var17) {
                     continue label41;
                  }

                  var16 = "X\"RÒ\u0095Y[V\u008b:v±°làK";
                  var17 = "X\"RÒ\u0095Y[V\u008b:v±°làK".length();
                  var14 = 0;
            }

            int var49 = var14;
            var14 += 8;
            var18 = var16.substring(var49, var14).getBytes("ISO-8859-1");
            var45 = var11;
            var10001 = var15++;
            var53 = (var18[0] & 255L) << 56
               | (var18[1] & 255L) << 48
               | (var18[2] & 255L) << 40
               | (var18[3] & 255L) << 32
               | (var18[4] & 255L) << 24
               | (var18[5] & 255L) << 16
               | (var18[6] & 255L) << 8
               | var18[7] & 255L;
            var57 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 4043;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ct", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ct_C0150",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ct" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 47;
            yield var15;
         }
         case 1 -> {
            byte var16 = 48;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 34;
            yield var18;
         }
         case 4 -> {
            byte var19 = 22;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 13;
            yield var21;
         }
         case 7 -> {
            byte var22 = 15;
            yield var22;
         }
         case 8 -> {
            byte var23 = 44;
            yield var23;
         }
         case 9 -> {
            byte var24 = 12;
            yield var24;
         }
         case 10 -> {
            byte var25 = 58;
            yield var25;
         }
         case 11 -> {
            byte var26 = 28;
            yield var26;
         }
         case 12 -> {
            byte var27 = 41;
            yield var27;
         }
         case 13 -> {
            byte var28 = 32;
            yield var28;
         }
         case 14 -> {
            byte var29 = 39;
            yield var29;
         }
         case 15 -> {
            byte var30 = 42;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 60;
            yield var32;
         }
         case 18 -> {
            byte var33 = 51;
            yield var33;
         }
         case 19 -> {
            byte var34 = 52;
            yield var34;
         }
         case 20 -> {
            byte var35 = 45;
            yield var35;
         }
         case 21 -> {
            byte var36 = 55;
            yield var36;
         }
         case 22 -> {
            byte var37 = 46;
            yield var37;
         }
         case 23 -> {
            byte var38 = 36;
            yield var38;
         }
         case 24 -> {
            byte var39 = 24;
            yield var39;
         }
         case 25 -> {
            byte var40 = 37;
            yield var40;
         }
         case 26 -> {
            byte var41 = 16;
            yield var41;
         }
         case 27 -> {
            byte var42 = 31;
            yield var42;
         }
         case 28 -> {
            byte var43 = 4;
            yield var43;
         }
         case 29 -> {
            byte var44 = 62;
            yield var44;
         }
         case 30 -> {
            byte var45 = 29;
            yield var45;
         }
         case 31 -> {
            byte var46 = 17;
            yield var46;
         }
         case 32 -> {
            byte var47 = 61;
            yield var47;
         }
         case 33 -> {
            byte var48 = 59;
            yield var48;
         }
         case 34 -> {
            byte var49 = 26;
            yield var49;
         }
         case 35 -> {
            byte var50 = 23;
            yield var50;
         }
         case 36 -> {
            byte var51 = 54;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 33;
            yield var53;
         }
         case 39 -> {
            byte var54 = 5;
            yield var54;
         }
         case 40 -> {
            byte var55 = 7;
            yield var55;
         }
         case 41 -> {
            byte var56 = 11;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 3;
            yield var58;
         }
         case 44 -> {
            byte var59 = 1;
            yield var59;
         }
         case 45 -> {
            byte var60 = 20;
            yield var60;
         }
         case 46 -> {
            byte var61 = 35;
            yield var61;
         }
         case 47 -> {
            byte var62 = 8;
            yield var62;
         }
         case 48 -> {
            byte var63 = 10;
            yield var63;
         }
         case 49 -> {
            byte var64 = 0;
            yield var64;
         }
         case 50 -> {
            byte var65 = 38;
            yield var65;
         }
         case 51 -> {
            byte var66 = 49;
            yield var66;
         }
         case 52 -> {
            byte var67 = 2;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 25;
            yield var69;
         }
         case 55 -> {
            byte var70 = 63;
            yield var70;
         }
         case 56 -> {
            byte var71 = 56;
            yield var71;
         }
         case 57 -> {
            byte var72 = 53;
            yield var72;
         }
         case 58 -> {
            byte var73 = 43;
            yield var73;
         }
         case 59 -> {
            byte var74 = 50;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 6;
            yield var76;
         }
         case 62 -> {
            byte var77 = 14;
            yield var77;
         }
         default -> 21;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "W%oc)_\\*~,N]I!~gu";
      i[1] = int.class;
      j[1] = "java/lang/Integer";
      i[2] = "W\u0001>4\u000b3A\u0001;n\u0018$VJ8h\u00140G\r/\u007f_'b";
      i[3] = "!Ft4GkTf\u007f;V$5ht0R~A";
      i[4] = "wY<\u0005)\u0005aY9_:\u0012v\u0012:Y6\u0006gU-N}\u0011T";
      i[5] = "\u0004aQF\u0019k\u0012aT\u001c\n|\u0005*W\u001a\u0006h\u0014m@\rMz%";
      i[6] = "\u0016\u001cSAvo\u0000\u001cV\u001bex\u0017WU\u001dil\u0006\u0010B\n\"}\u0010";
      i[7] = "qw6}\tJ\u0004W=r\u0018\u0005eY6y\u001c_\u0011";
      i[8] = "408S\u0019a40/\u000f\u0015n.{/\u0011\u0015{)\n\u007fLD";
      i[9] = "m`$\u0012+pm`3N'\u007fw+3P'jpZd\u000fq";
      i[10] = "\u0006L\u0010SU!\u0018D\n\u001c7=\u001fY";
      i[11] = "\u0016\u001cE+\u0018N\b\u0014_d\u007fO\u0019\u000fR>YI";
      i[12] = "e\ft;IP\u0010,\u007f4X\u001fq\"t?\\E\u0005";
      i[13] = void.class;
      j[13] = "java/lang/Void";
      i[14] = boolean.class;
      j[14] = "java/lang/Boolean";
      i[15] = "v\u0002\u007f=Wlh\ner4xl";
      i[16] = "*\t\u0010BJ?!\u0006\u0001\r+1*\r\u0005W";
      i[17] = "dJa FV\u0011jj/W\u0019pda$SC\u0004";
      i[18] = "#U\u0011\u0013\rU5U\u0014I\u001eB\"\u001e\u0017O\u0012V3Y\u0000XYF\u0000";
      i[19] = "\nbBb%N\u001cbG86Y\u000b)D>:M\u001anS)q]\u0002nQ\"+\u0010>uQ?+W\tb";
      i[20] = "u\u001cd3\u00025c\u001cai\u0011\"tWbo\u001d6e\u0010uxV&[";
      i[21] = "7o\u0018jYYBO\u0013eH\u0016#A\u0018nLLW";
      i[22] = "UE(\u0015ToCE-OGxT\u000e.IKlEI9^\u0000|E";
      i[23] = "kHQ\u0017&a`G@XEluJO3pndYS\u001fgc";
      i[24] = "V\u001dHR50#=C]$\u007fB3HV %6";
      i[25] = ")\u0006#4\\~?\u0006&nOi(M%hC}9\n2\u007f\bl\u0001";
      i[26] = "bh>19\u0004\u0017H5>(KvF>5,\u0011\u0002";
      i[27] = "MDU\u0005,\u0019FKDJF\u001aRGO\u0001";
      i[28] = double.class;
      j[28] = "java/lang/Double";
      i[29] = "~8>*\u0001\u0015u7/eb\u0018`1";
      i[30] = long.class;
      j[30] = "java/lang/Long";
      i[31] = "\u0002n-%1\u000e\ta<jL\u001b\u001b{>)";
      i[32] = "{x7(\u0012Fmx2r\u0001Qz31t\rEkt&cFQF";
      i[33] = "Ul~\nJ\f Lu\u0005[CAB~\u000e_\u00195";
      i[34] = "[\u0015#?YMM\u0015&eJZZ^%cFNK\u00192t\rs^\u0004<gF";
      i[35] = "SQU/\u001f1SQBs\u0013>I\u001aBm\u0013+Nk\u00101Fi";
      i[36] = "XqlY\b\u0018Nqi\u0003\u001b\u000fY:j\u0005\u0017\u001bH}}\u0012\\\t\u000b";
      i[37] = "QGR4o\u001d$gY;~REiR0z\b1";
      i[38] = "\u001f\u0015jXHt\t\u0015o\u0002[c\u001e^l\u0004Ww\u000f\u0019{\u0013\u001caH";
      i[39] = "T7^Q\u0016Q!\u0017U^\u0007\u001e@\u0019^U\u0003D4";
      i[40] = "S\u0000/w:\u000f& $x+@G./s/\u001a3";
      i[41] = "W\u001fZ\u0006\r\u0011A\u001f_\\\u001e\u0006VT\\Z\u0012\u0012G\u0013KMY\u0005u";
      i[42] = "?o\u001e\f\u0006\u0003JO\u0015\u0003\u0017L+A\u001e\b\u0013\u0016_";
      i[43] = "P}Z\u001a\u0015XF}_@\u0006OQ6\\F\n[@qKQAKA";
      i[44] = ")*Z'4`\\\nQ(%/=\u0004Z#!uI";
      i[45] = "DYlG\n*\u001dNwOz\u007f\u007fXjW\u001d)\u0003\u001cv^z";
      i[46] = "\u007f4:\u0016&Wz8k\u0004\u001eSf>z\u0005xDG%e\u0005[Y\u007f a\u0013\u001e[g;;S|Wkt=h";
      i[47] = "=\u001cTo*\u0003\u007f\u001f^n\u0010\tbOB\u007fG^<\u001f\u001b\u0013.We\u001bZpm\\q\u001c";
      i[48] = "S2\u0015\b\u0003g@n\u0016\u00113d?7I\u0011^a[3\u0005\u001f_";
      i[49] = "`e\u000fS\u0013.c9]Hj~#mE^\u0016x%\u0000\u0000I\u0018g3aQ[\u0005#_";
      i[50] = "\u000b4.\u000e}M\u000fx \u000f\u001b@nx>\u0013*MR=/\u001ct)_:<\u0019gP\r=e\u0013\u001b";
      i[51] = ",)j\bf:u>q\u0000\u0016n\u0017(l\u0018q9klp\u0011\u0016";
      i[52] = "\\\n<D\n'\u0002K0Yu5;\u0000 LM;E@n\u000b\u0018W";
      i[53] = "d\u0001wMj\u000b=\u0015oN[\u0005j\u0017i@:\bv2xX[\u00041\u001e|\u0019j\fp\u001dx)j\u0011uIyW*_2\u001c\u0015";
      i[54] = "H`\u0010,ucJ|\u001c`\u0010ety\u0019!!hH<\b.\u007f\f\bd\u000b6,pLx\u0002Q";
      i[55] = "[nf\u007fRU\u0001fdGZO\u0018\u00010#FDd#95\\\u0015\u0018g%<;";
      i[56] = "?DhZqN!Bd\u0019\u001eVC\u0016?\bw\u000fr\u001e~\u000bs?";
      i[57] = "1\\=\u0018,\u001e3\u001b{\u0014MLZ\u0018$U)\\k\u001bx\u00072%";
      i[58] = "VR&\u0015\u0016@\u000fF>\u0016'BQ\".MHL\u000f\u0013&\fKH?Hx\u001eN\u0015\u000e@9\u001dJ%U\u001e+\u0018\u0017\u0014]_(\u001c'O\u0003M-A\u0016GBN)qM\u0019PKt@EXSOD\u001b\u001bJV\u0012u\u0013ZIR\".MHL\u000f\u0013&\fKH?Hx\u001eN\u0015\u000e@9\u001dJ%U\u001e+\u0018\u0017\u0014]_(\u001c'O\u0003M-A\u0016GBN)qNU]Fu\u0014\u0017AEED";
      i[59] = "Zq>@62X6xLW`1w\"Mfm\r23B8\tHp&@kb\u000bmzXW";
      i[60] = "`\u0011\fa\u0015M1\u0003\u0011%yJ2\u001f\u0002\u0019\u0013\u00100\u0006N(\u001bQ3\u0002~";
      i[61] = "r~]fhD+jEeYNvr?heNr>\u000e`$Mv\u000eU>6H+?]\u007f5L\u001b";
      i[62] = "^Rkc#G\u001e^olRW#CimcZ\u001f\u0006xb=>_^{znB\u001bBr\u001d";
      i[63] = "krT[b;w1\u000f\u0005\u00195\u00067\n\u001b(8:r\u001b\u0014v\\75\u0012Su\"w{U\u0006\u0019";
      i[64] = ".\u00000]<N=\\3D\fBB\u000b&HqOy\ta\u000e}";
      i[65] = "-\u0003Q\u0015sa,\u0007\u0013\u001a\u0019iC\u0010K\u0014 oy\u0015\u0010\u0006|\u0000,\u001bCAv:)@Q\u001d\u0019";
      i[66] = "o\u0017\u007fL0(|K|U\u0000\"\u0003\u0017h\u001dm#8\u0010sO?";
      i[67] = "':U*o)v(Hn\u0003(q?a?s4\u0018uX*;$f5\u0016mnH";
      i[68] = "lFSx.<.EYy\u0014=?\u0004Acx\u000fhB\u001f4/X5\u0005\u001d9h&4\u0012M}\u0014";
      i[69] = "5\\huZ\fo\u0013`~']\f_po\u0016S0\u001aa`H7pBbx\u001bK4^k\u001f";
      i[70] = "e\u0001k\u0001z\u0004?\ti9m\u0011>M9~}x&P&^/\u0004bL/9,Ie\b=EvAg0";
      i[71] = "K\u001e\u00185*\u001d\u0011Q\u0010>WLr\u001d\u0000/fBNX\u0011 8&I^^\"oC\u0011\u0007\u00043W";
      i[72] = "x^C?HK$\u0006Hy!\u0019}\u001aOfL+s\u0003Xo!\u0017c\u0005\u001ex\\Oj[\u001c\u0002";
      i[73] = "[}vq\u0016\u0002]'6gs\u0007#1m}B\u000f\u001ft|r\u001ck_,\u007fjO\u0017\u001b0v\r";
      i[74] = "#M08\u0006K!Q<tcH\u001fT95R@#\u0011(:\f$cI+\"_X'U\"E";
      i[75] = "F\u0018\nu0mI\u0012W|]{B\u001fS}]c\\\u0000\u000ek ;U^\f\u0011>}ZY\u000es2q\u0015_5";
      i[76] = "\u0018tg\u0001p\u0018[i;\u0019L\u0018asc\f}\u0017]6r\u0003#sZ0=\u0001t\u0016\u0002ig\u0010L";
      i[77] = "U@\u0014X:U\u0017C\u001eY\u0000T\u0006\u0002\u0006ClfRC^\u001b\u0000\u000f[\u0018_XcLP\fX$1\u000e\t\u0004\u001a]c\tP\u000ef";
      i[78] = "\\\u0005;gX@Z_{q=@$I k\fM\u0018\f1dR)XT2|\u0001U\u001cH;\u001b";
      i[79] = ")\u0005\u001bc4\u007fsJ\u0013hI-\u0010\u0006\u0003yx ,C\u0012v&D!D\u0001s5=sCXyI";
      i[80] = "uJC#!6/\u0005K(\\dL\u0005D1da2E\nv1\r";
      i[81] = "k1(\u0017\u000eAxm+\u000e>X\u0007<}@\u000eZ` >\u001bP";
      i[82] = "N!\u0014Ww\u0006O6D\u0013\u000b\u001dD H\rg/\u0010a\u0019[4xU<Z\r7\u0004\u0011 Sj:GK&T\u0013h@\u0012,(";
      i[83] = "7eZ\u0019\u0000lo<\u0000\b8c\fj\u001b\u001c\u0000er*U[U\t";
      i[84] = "k\u0002\u00190&hl\u0019KbM:\u000b\u0005A-|77@P\"\"S:GC'1*h@\u001a-M";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1129720057203074L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1129720057203074L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1129720057203074L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 81;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 205;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 197;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 104;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 65;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 81;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 205;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 197;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ct_C0150",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ct" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
