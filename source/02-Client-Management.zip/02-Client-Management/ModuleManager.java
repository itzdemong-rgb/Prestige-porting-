package dev.zprestige.prestige.client.management;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.annotation.NativeMarker;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.ui.MenuSettings;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

public class ModuleManager implements MinecraftAccess {
   private final MenuSettings a;
   private List c;
   private final ConcurrentLinkedQueue d;
   private final ConcurrentLinkedQueue e;
   public static boolean f = dev.prestige.recovery.SourceSupport.asBoolean(1);
   private static final long g = 55859218155451L;
   private static final Object[] h = new Object[42];
   private static final String[] i = new String[42];

   public ModuleManager(long var1) {
      super();
      var1 = 55859218155451L ^ var1;
      long var3 = var1 ^ 58197406535040L;

      this.a = new MenuSettings();
      this.c = new ArrayList();
      this.d = new ConcurrentLinkedQueue();
      this.e = new ConcurrentLinkedQueue();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   
   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 47938049510065L ^ 2029695770574L;
      var10001 = 47938049510065L ^ 53677159601107L;
      int var8 = Event.cReturningInt();
      int var46 = var8;
      MinecraftClient var45 = b;
      MinecraftClient var33 = var45;
      MinecraftClient var32 = var45;
      if (var46 != 0) {
         MinecraftClient var10 = var32;
         ClientWorld var47 = var10.world;
         if (var47 == null) {
            return;
         }

         MinecraftClient var48 = b;
         var33 = var48;
      }

      MinecraftClient var13 = var33;
      ClientPlayerEntity var49 = var13.player;
      if (var49 != null) {
         while (true) {
            ConcurrentLinkedQueue var15 = this.d;
            boolean var50 = var15.isEmpty();
            Module var9;
            Module var40;
            if (!var50) {
               ConcurrentLinkedQueue var16 = this.d;
               var9 = (Module)var16.poll();
               int var52 = var8;
               Module var51 = var9;
               var40 = var51;
               Module var34 = var51;
               if (var52 != 0) {
                  label92: {
                     int var54 = var8;
                     Module var53 = var34;
                     Module var37 = var53;
                     Module var35 = var53;
                     if (var54 != 0) {
                        Module var55 = var35;
                        Module var36 = var55;
                        Module var56 = var36;
                        if (var56 == null) {
                           break label92;
                        }

                        var37 = var9;
                     }

                     int var58 = var8;
                     Module var57 = var37;
                     Module var39 = var57;
                     Module var38 = var57;
                     if (var58 != 0) {
                        Module var19 = var38;
                        boolean var59 = var19.aReturningBoolean();
                        if (!var59) {
                           break label92;
                        }

                        Module var60 = var9;
                        var39 = var60;
                     }

                     Object[] var23 = new Object[]{46462438348159L};
                     Module var22 = var39;
                     var22.dReturningVoid(var23);
                  }

                  int var61 = var8;
                  if (var61 != 0) {
                     continue;
                  }

                  ConcurrentLinkedQueue var24 = this.e;
                  boolean var62 = var24.isEmpty();
                  if (var62) {
                     break;
                  }

                  ConcurrentLinkedQueue var25 = this.e;
                  var9 = (Module)var25.poll();
                  var40 = var9;
               }
            } else {
               ConcurrentLinkedQueue var71 = this.e;
               boolean var78 = var71.isEmpty();
               if (var78) {
                  break;
               }

               ConcurrentLinkedQueue var73 = this.e;
               var9 = (Module)var73.poll();
               var40 = var9;
            }

            while (true) {
               label78: {
                  int var64 = var8;
                  Module var63 = var40;
                  Module var42 = var63;
                  Module var41 = var63;
                  if (var64 != 0) {
                     Module var65 = var41;
                     if (var65 == null) {
                        int var82 = var8;
                        if (var82 == 0) {
                           return;
                        }
                        break label78;
                     }

                     var42 = var9;
                  }

                  int var67 = var8;
                  Module var66 = var42;
                  Module var44 = var66;
                  Module var43 = var66;
                  if (var67 != 0) {
                     Module var27 = var43;
                     boolean var68 = var27.aReturningBoolean();
                     if (!var68) {
                        Module var69 = var9;
                        var44 = var69;
                        Object[] var31 = new Object[]{29999313607010L};
                        Module var30 = var44;
                        var30.eReturningVoid(var31);
                        int var70 = var8;
                        if (var70 == 0) {
                           return;
                        }
                     } else {
                        int var80 = var8;
                        if (var80 == 0) {
                           return;
                        }
                     }
                  } else {
                     Object[] var76 = new Object[]{29999313607010L};
                     Module var75 = var44;
                     var75.eReturningVoid(var76);
                     int var81 = var8;
                     if (var81 == 0) {
                        return;
                     }
                  }
               }

               ConcurrentLinkedQueue var72 = this.e;
               boolean var79 = var72.isEmpty();
               if (var79) {
                  return;
               }

               ConcurrentLinkedQueue var74 = this.e;
               var9 = (Module)var74.poll();
               var40 = var9;
            }
         }
      }
   }

   public void aReturningVoid(Object[] var1) {
      Module var4 = (Module)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 55859218155451L ^ var2;
      int var5 = Event.cReturningInt();
      Module var7 = var4;
      ConcurrentLinkedQueue var6 = this.d;
      boolean var17 = var6.contains(var7);
      int var14 = var5;
      boolean var13 = var17;
      boolean var11 = var13;
      if (var14 != 0) {
         boolean var15 = var11;
         if (!var15) {
            Module var10 = var4;
            ConcurrentLinkedQueue var9 = this.d;
            boolean var16 = var9.offer(var10);
         }
      }
   }

   public void bReturningVoid(Object[] var1) {
      Module var2 = (Module)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 55859218155451L ^ var3;
      int var5 = Event.bReturningInt();
      Module var7 = var2;
      ConcurrentLinkedQueue var6 = this.e;
      boolean var17 = var6.contains(var7);
      int var14 = var5;
      boolean var13 = var17;
      boolean var11 = var13;
      if (var14 == 0) {
         boolean var15 = var11;
         if (!var15) {
            Module var10 = var2;
            ConcurrentLinkedQueue var9 = this.e;
            boolean var16 = var9.offer(var10);
         }
      }
   }

   @NativeMarker
   public List a() {
      return this.c;
   }

   @NativeMarker
   public void a(List var1) {
      this.c = var1;
   }

   public MenuSettings aReturningMenuSettings(Object[] var1) {
      return this.a;
   }

   @NativeMarker
   public void a(Color var1) {
      MenuSettings var10000 = this.a;
      Object[] var5 = new Object[0];
      MenuSettings var4 = var10000;
      ColorSetting var8 = var4.bReturningColorSetting(var5);
      Color var7 = var1;
      ColorSetting var6 = var8;
      var6.aReturningVoid(var7);
   }

   @NativeMarker
   public void a(int var1) {
      MenuSettings var10000 = this.a;
      Object[] var5 = new Object[0];
      MenuSettings var4 = var10000;
      BindSetting var9 = var4.cReturningVoid(var5);
      int var6 = var1;
      Integer var8 = var6;
      BindSetting var7 = var9;
      var7.aReturningVoid(var8);
   }

   static {
      b();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 23;
            yield var15;
         }
         case 1 -> {
            byte var16 = 53;
            yield var16;
         }
         case 2 -> {
            byte var17 = 29;
            yield var17;
         }
         case 3 -> {
            byte var18 = 7;
            yield var18;
         }
         case 4 -> {
            byte var19 = 12;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 32;
            yield var22;
         }
         case 8 -> {
            byte var23 = 62;
            yield var23;
         }
         case 9 -> {
            byte var24 = 0;
            yield var24;
         }
         case 10 -> {
            byte var25 = 36;
            yield var25;
         }
         case 11 -> {
            byte var26 = 4;
            yield var26;
         }
         case 12 -> {
            byte var27 = 28;
            yield var27;
         }
         case 13 -> {
            byte var28 = 40;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 59;
            yield var30;
         }
         case 16 -> {
            byte var31 = 51;
            yield var31;
         }
         case 17 -> {
            byte var32 = 55;
            yield var32;
         }
         case 18 -> {
            byte var33 = 6;
            yield var33;
         }
         case 19 -> {
            byte var34 = 31;
            yield var34;
         }
         case 20 -> {
            byte var35 = 43;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 21;
            yield var37;
         }
         case 23 -> {
            byte var38 = 9;
            yield var38;
         }
         case 24 -> {
            byte var39 = 22;
            yield var39;
         }
         case 25 -> {
            byte var40 = 47;
            yield var40;
         }
         case 26 -> {
            byte var41 = 5;
            yield var41;
         }
         case 27 -> {
            byte var42 = 20;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 42;
            yield var44;
         }
         case 30 -> {
            byte var45 = 15;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 27;
            yield var47;
         }
         case 33 -> {
            byte var48 = 11;
            yield var48;
         }
         case 34 -> {
            byte var49 = 10;
            yield var49;
         }
         case 35 -> {
            byte var50 = 1;
            yield var50;
         }
         case 36 -> {
            byte var51 = 38;
            yield var51;
         }
         case 37 -> {
            byte var52 = 24;
            yield var52;
         }
         case 38 -> {
            byte var53 = 26;
            yield var53;
         }
         case 39 -> {
            byte var54 = 3;
            yield var54;
         }
         case 40 -> {
            byte var55 = 44;
            yield var55;
         }
         case 41 -> {
            byte var56 = 35;
            yield var56;
         }
         case 42 -> {
            byte var57 = 49;
            yield var57;
         }
         case 43 -> {
            byte var58 = 33;
            yield var58;
         }
         case 44 -> {
            byte var59 = 25;
            yield var59;
         }
         case 45 -> {
            byte var60 = 58;
            yield var60;
         }
         case 46 -> {
            byte var61 = 17;
            yield var61;
         }
         case 47 -> {
            byte var62 = 57;
            yield var62;
         }
         case 48 -> {
            byte var63 = 16;
            yield var63;
         }
         case 49 -> {
            byte var64 = 50;
            yield var64;
         }
         case 50 -> {
            byte var65 = 30;
            yield var65;
         }
         case 51 -> {
            byte var66 = 41;
            yield var66;
         }
         case 52 -> {
            byte var67 = 34;
            yield var67;
         }
         case 53 -> {
            byte var68 = 8;
            yield var68;
         }
         case 54 -> {
            byte var69 = 63;
            yield var69;
         }
         case 55 -> {
            byte var70 = 37;
            yield var70;
         }
         case 56 -> {
            byte var71 = 39;
            yield var71;
         }
         case 57 -> {
            byte var72 = 19;
            yield var72;
         }
         case 58 -> {
            byte var73 = 18;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 14;
            yield var76;
         }
         case 62 -> {
            byte var77 = 60;
            yield var77;
         }
         default -> 2;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      h[0] = "m.\u001c>wv{.\u0019ddale\u001abhu}\"\ru#bX";
      h[1] = "/AD('vZaO'69;oD,2cO";
      h[2] = void.class;
      i[2] = "java/lang/Void";
      h[3] = ". }(\u001d!8 xr\u000e6/k{t\u0002\">,lcI0\u000f";
      h[4] = int.class;
      i[4] = "java/lang/Integer";
      h[5] = boolean.class;
      i[5] = "java/lang/Boolean";
      h[6] = "y\u0012|sehy\u0012k/igcYk1ird(;l8";
      h[7] = "$HQC(X$HF\u001f$W>\u0003F\u0001$B9r\u0013^}";
      h[8] = "bp9|&Y|x#3kCfr:ozIfea^gBkd=omB|]&scIl@:x}I";
      h[9] = "\u000er\u001b\u00165'\u0005}\nYT)\u000ev\u000e\u0003";
      h[10] = "\u0016U\u001bTzE\u0016U\f\bvJ\f\u001e\f\u0016v_\u000boXN!";
      h[11] = "3uu\u0003@\u0015FU~\fQZ'[u\u0007U\u0000S";
      h[12] = "R\u0002f*&\\D\u0002cp5KSI`v9_B\u000ewarOq";
      h[13] = "'l\u0019r\u0013W,c\b=pZ9n\u0007VEX(}\u001bzRU";
      h[14] = "&dK\f\u001cV0dNV\u000fA'/MP\u0003U6hZGHE.hXL\u0012\b\u0012sXQ\u0012O%d";
      h[15] = "\u0002\u001d|au*\u0014\u001dy;f=\u0003Vz=j)\u0012\u0011m*!8*";
      h[16] = "f?!u?\u0018\u0013\u001f*z.Wr\u0011!q*\r\u0006";
      h[17] = "gk^L4uqk[\u0016'bf X\u0010+vwgO\u0007``0";
      h[18] = "\u0007H|/]Frhw L\t\u0013f|+HSg";
      h[19] = "\u001b>\u007f!}\u0004\r>z{n\u0013\u001auy}b\u0007\u000b2nj)\u00106";
      h[20] = "\n\t[7o1\u001c\t^m|&\u000bB]kp2\u001a\u0005J|;%(";
      h[21] = "J+0d*6A$!+M4T/!`v";
      h[22] = "\u0011+Gl\u0013Id\u000bLc\u0002\u0006\u0005\u0005Gh\u0006\\q";
      h[23] = "}cX&pwkc]|c`|(^zotmoIm$c^";
      h[24] = "h\u0004-.\n\u00058H804\u0015o\\\">s\u0005\u0006\u00035i\t\u0015y\\%nYkh\u0004-.\n\u00058H804";
      h[25] = ".?\u001c\n?p-/HFRzt\"Z\u00133whD\u0018\nc!n.\u0016\u0002or\u0013x\u001d\u0019htp5B\u0006>\u0011";
      h[26] = "\u000e>\u0017j3I]5\u0017w\u000eG4g\u001f+3SK8\u000f,c-";
      h[27] = "~D\u001cz\bdl\u000f\u0017`1i\u0015\u0013\u0001:W\u007f-\u001a\u000bkM\u0003y\u0012BjV3nG\u0016\u007f1";
      h[28] = "C\u0007\u001b&v\"OT\u001eH\"SG\u0013\u001b.3kN\u0019J4OjG\u0015B#>\"\u0015\u0013\u0015H";
      h[29] = "N'`\r6\u0002M74A[\u0004\u001d27\u0007[]\u0003mj\u00001S\u000ba9}gX\u0010f?\u001e*\u0007\u000f0Z";
      h[30] = "\u001c/QvD\f\u000edZl}\u0000wxL6\u001b\u0017OqFg\u0001k\u0018-\br\r\n\u0010lDj}";
      h[31] = "\u0016o1\u0001V\\Ed1\u001ckS,69@VFSi)G\u00068";
      h[32] = "tMveygx\u001es\u000b)\u0016\"\u0018*1%uoG5g@";
      h[33] = "ZlB\u0007aO_y@\u0001\u0010\u0010\u0007j@VGGX7\u001b:-\u0013\u001a<\u001aVr\u0006Z>";
      h[34] = "bTF#[$aD\u0012o6=8K\u0018S\b5n\u001f\u00019\u0006=bL|";
      h[35] = ":\u0007\nu98?\u0012\bsHgg\u0001\b$\u001f09VPHw4h\bQ4w4mP";
      h[36] = "{p0C~{lk3\u001e\u001b\"\u0016''\u0016+6|)/\u001axK/w+Ap:g%-\u0016\u001b";
      h[37] = "\u00124\t\u0014?9\u001eg\fzjH\u0016 \t\u001czp\u001f*X\u0006\u0006q\u0016&P\u0011w9D \u0007z";
      h[38] = "ik\u00159sU8>\u001d!\rP\u0000iN{h[bg\u001c#s";
      h[39] = "+\u0017\f<\u001dl%ET'|gB\u001bNf\u001arz\u0012D7\u0000\u000e{\u001bH?\u0017\u007f3INh|";
      h[40] = "b\nq\n)\u0014a\u001a%FD\u0014$<.\u00028\u0004_Mp\u0019~\u0010<\u0000/\u0006(u";
      h[41] = "C7\u0001\n)U\u001e?D\u0011EUsk\u0003\u001c/BI!\u0000@)<BfR\u001b;\u0006\be\u000e\u001dE";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(703180891559000L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(703180891559000L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(703180891559000L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 83;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 100;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 234;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 113;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 253;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 99;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 83;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 100;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 234;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cG_C0123",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
