package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.accessor.MouseAccessor;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.client.ui.MouseClickState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;

public class MouseInputManager implements MinecraftAccess {
   private MouseClickState a = null;
   private static final long c = 137850054924495L;
   private static final Object[] d = new Object[38];
   private static final String[] e = new String[38];

   public boolean aReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 137850054924495L ^ var2;
      long var4 = var2 ^ 65994195771684L;
      int var6 = Event.cReturningInt();
      MouseClickState var56 = this.a;
      if (var56 == null) {
         return false;
      }

      int var51;
      long var10000 = System.currentTimeMillis();
      MouseClickState var10001 = this.a;
      Object[] var8 = new Object[0];
      MouseClickState var7 = var10001;
      float var73 = (float)(var10000 - var7.aReturningLong(var8));
      var10001 = this.a;
      Object[] var10 = new Object[0];
      MouseClickState var9 = var10001;
      float var98;
      int var74 = (var98 = var73 - var9.aReturningFloat(var10)) == 0.0F ? 0 : (var98 < 0.0F ? -1 : 1);
      int var58 = var6;
      int var57 = var74;
      var51 = var57;
      int var47 = var57;
      label41:
      if (var58 != 0) {
         int var59 = var47;
         int var48 = var59;
         int var60 = var48;
         if (var60 > 0) {
            MouseClickState var75 = this.a;
            Object[] var14 = new Object[0];
            MouseClickState var13 = var75;
            byte var76 = ((byte)((var13.aReturningBoolean(var14)) ? 1 : 0));
            int var62 = var6;
            byte var61 = var76;
            var51 = var61;
            byte var49 = var61;
            if (var62 == 0) {
               break label41;
            }

            byte var63 = var49;
            byte var50 = var63;
            byte var64 = var50;
            if (var64 == 0) {
               MinecraftClient var17 = b;
               MouseAccessor var77 = new MouseAccessor(var17.mouse);
               MinecraftClient var18 = b;
               Window var19 = var18.getWindow();
               long var86 = var19.getHandle();
               MouseClickState var10002 = this.a;
               Object[] var21 = new Object[0];
               MouseClickState var20 = var10002;
               int var93 = var20.aReturningInt(var21);
               Object[] var10007 = new Object[]{null, null, null, null, var4};
               var10007[3] = 0;
               var10007[2] = 1;
               var10007[1] = var93;
               var10007[0] = var86;
               Object[] var23 = var10007;
               MouseAccessor var22 = var77;
               var22.aReturningVoid(var23);
               MouseClickState var78 = this.a;
               Object[] var25 = new Object[]{true};
               MouseClickState var24 = var78;
               var24.aReturningVoid(var25);
            }
         }

         var10000 = System.currentTimeMillis();
         var10001 = this.a;
         Object[] var28 = new Object[0];
         MouseClickState var27 = var10001;
         float var80 = (float)(var10000 - var27.aReturningLong(var28));
         var10001 = this.a;
         Object[] var30 = new Object[0];
         MouseClickState var29 = var10001;
         float var99;
         var51 = (var99 = var80 - var29.aReturningFloat(var30)) == 0.0F ? 0 : (var99 < 0.0F ? -1 : 1);
      }

      int var66 = var6;
      int var65 = var51;
      int var55 = var65;
      int var52 = var65;
      if (var66 != 0) {
         int var67 = var52;
         if (var67 > 0) {
            var10000 = System.currentTimeMillis();
            var10001 = this.a;
            Object[] var33 = new Object[0];
            MouseClickState var32 = var10001;
            float var82 = (float)(var10000 - var32.aReturningLong(var33));
            var10001 = this.a;
            Object[] var35 = new Object[0];
            MouseClickState var34 = var10001;
            float var91 = var34.aReturningFloat(var35);
            MouseClickState var94 = this.a;
            Object[] var37 = new Object[0];
            MouseClickState var36 = var94;
            float var100;
            int var83 = (var100 = var82 - (var91 + var36.bReturningFloat(var37))) == 0.0F ? 0 : (var100 < 0.0F ? -1 : 1);
            int var69 = var6;
            int var68 = var83;
            var55 = var68;
            int var53 = var68;
            if (var69 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var55);
            }

            int var70 = var53;
            int var54 = var70;
            int var71 = var54;
            if (var71 > 0) {
               MinecraftClient var40 = b;
               MouseAccessor var84 = new MouseAccessor(var40.mouse);
               MinecraftClient var41 = b;
               Window var42 = var41.getWindow();
               long var92 = var42.getHandle();
               var94 = this.a;
               Object[] var44 = new Object[0];
               MouseClickState var43 = var94;
               int var96 = var43.aReturningInt(var44);
               Object[] var97 = new Object[]{null, null, null, null, var4};
               var97[3] = 0;
               var97[2] = 0;
               var97[1] = var96;
               var97[0] = var92;
               Object[] var46 = var97;
               MouseAccessor var45 = var84;
               var45.aReturningVoid(var46);
               this.a = null;
            }
         }

         var55 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var55);
   }

   public void aReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      float var3 = (Float)var1[1];
      long var4 = (Long)var1[2];
      var4 = 137850054924495L ^ var4;
      long var6 = var4 ^ 75911249375258L;
      long var10004 = System.currentTimeMillis();
      Object[] var10010 = new Object[]{null, null, var6};
      var10010[1] = 15.0F;
      var10010[0] = 5.0F;
      Object[] var8 = var10010;
      float var10006 = RandomUtil.aReturningFloat(var8);
      Object[] var10011 = new Object[]{null, null, var6};
      var10011[1] = 55.0F;
      var10011[0] = 35.0F;
      Object[] var9 = var10011;
      float var10007 = RandomUtil.aReturningFloat(var9);
      var10010 = new Object[]{null, null, var6};
      var10010[1] = var10007;
      var10010[0] = var10006;
      Object[] var10 = var10010;
      this.a = new MouseClickState(var2, var10004, var3, RandomUtil.aReturningFloat(var10), false);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = e[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = d[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 57;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 48;
            yield var19;
         }
         case 5 -> {
            byte var20 = 22;
            yield var20;
         }
         case 6 -> {
            byte var21 = 47;
            yield var21;
         }
         case 7 -> {
            byte var22 = 60;
            yield var22;
         }
         case 8 -> {
            byte var23 = 42;
            yield var23;
         }
         case 9 -> {
            byte var24 = 27;
            yield var24;
         }
         case 10 -> {
            byte var25 = 40;
            yield var25;
         }
         case 11 -> {
            byte var26 = 1;
            yield var26;
         }
         case 12 -> {
            byte var27 = 4;
            yield var27;
         }
         case 13 -> {
            byte var28 = 10;
            yield var28;
         }
         case 14 -> {
            byte var29 = 35;
            yield var29;
         }
         case 15 -> {
            byte var30 = 31;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 21;
            yield var32;
         }
         case 18 -> {
            byte var33 = 34;
            yield var33;
         }
         case 19 -> {
            byte var34 = 25;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 9;
            yield var36;
         }
         case 22 -> {
            byte var37 = 53;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 36;
            yield var39;
         }
         case 25 -> {
            byte var40 = 30;
            yield var40;
         }
         case 26 -> {
            byte var41 = 15;
            yield var41;
         }
         case 27 -> {
            byte var42 = 0;
            yield var42;
         }
         case 28 -> {
            byte var43 = 56;
            yield var43;
         }
         case 29 -> {
            byte var44 = 20;
            yield var44;
         }
         case 30 -> {
            byte var45 = 33;
            yield var45;
         }
         case 31 -> {
            byte var46 = 23;
            yield var46;
         }
         case 32 -> {
            byte var47 = 58;
            yield var47;
         }
         case 33 -> {
            byte var48 = 41;
            yield var48;
         }
         case 34 -> {
            byte var49 = 13;
            yield var49;
         }
         case 35 -> {
            byte var50 = 11;
            yield var50;
         }
         case 36 -> {
            byte var51 = 63;
            yield var51;
         }
         case 37 -> {
            byte var52 = 43;
            yield var52;
         }
         case 38 -> {
            byte var53 = 18;
            yield var53;
         }
         case 39 -> {
            byte var54 = 28;
            yield var54;
         }
         case 40 -> {
            byte var55 = 49;
            yield var55;
         }
         case 41 -> {
            byte var56 = 54;
            yield var56;
         }
         case 42 -> {
            byte var57 = 38;
            yield var57;
         }
         case 43 -> {
            byte var58 = 16;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 6;
            yield var60;
         }
         case 46 -> {
            byte var61 = 32;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 51;
            yield var63;
         }
         case 49 -> {
            byte var64 = 14;
            yield var64;
         }
         case 50 -> {
            byte var65 = 37;
            yield var65;
         }
         case 51 -> {
            byte var66 = 19;
            yield var66;
         }
         case 52 -> {
            byte var67 = 29;
            yield var67;
         }
         case 53 -> {
            byte var68 = 17;
            yield var68;
         }
         case 54 -> {
            byte var69 = 2;
            yield var69;
         }
         case 55 -> {
            byte var70 = 7;
            yield var70;
         }
         case 56 -> {
            byte var71 = 26;
            yield var71;
         }
         case 57 -> {
            byte var72 = 46;
            yield var72;
         }
         case 58 -> {
            byte var73 = 52;
            yield var73;
         }
         case 59 -> {
            byte var74 = 5;
            yield var74;
         }
         case 60 -> {
            byte var75 = 62;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 50;
            yield var77;
         }
         default -> 39;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            e[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      d[0] = "\u001e\u0017#\u00161x\b\u0017&L\"o\u001f\\%J.{\u000e\u001b2]ei\u000b";
      d[1] = "/>Sq{gZ\u001eX~j(;\u0010SunrO";
      d[2] = boolean.class;
      e[2] = "java/lang/Boolean";
      d[3] = "Z\u001a\\\u0003S\u000f/:W\fB@N4\\\u0007F\u001a:";
      d[4] = void.class;
      e[4] = "java/lang/Void";
      d[5] = "T@xvQ]T@o*]RN\u000bo4]GIz=h\b\u0005";
      d[6] = long.class;
      e[6] = "java/lang/Long";
      d[7] = "\\0\tv9zW?\u00189DoE%\u001az";
      d[8] = "-fE@\u0017CXFNO\u0006\f9HED\u0002VM";
      d[9] = int.class;
      e[9] = "java/lang/Integer";
      d[10] = "0\u00185O+t&\u00180\u00158c1S3\u00134w \u0014$\u0004\u007fe\u0011";
      d[11] = "\u0019R\u0014tXIlr\u001f{I\u0006\r|\u0014pM\\y";
      d[12] = float.class;
      e[12] = "java/lang/Float";
      d[13] = "O\u0003Bn2<:#Ia#s[-Bj')/";
      d[14] = "XZ,\u0014y\u0007XZ;Hu\bB\u0011;Vu\u001dE`k\u000b$";
      d[15] = "YcMXe1YcZ\u0004i>C(Z\u001ai+DY\nG:";
      d[16] = "\u001cn\u0016\u0010e\u0005\nn\u0013Jv\u0012\u001d%\u0010Lz\u0006\fb\u0007[1\u0014\n";
      d[17] = "Q.$K\u000bFZ!5\u0004hKO,:o]I^?&CJD";
      d[18] = "\r#vh\u0004\u000ex\u0003}g\u0015A\u0019\rvl\u0011\u001bm";
      d[19] = "Y\n?\u0012_aO\n:HLvXA9N@bI\u0006.Y\u000b^";
      d[20] = "AMu:404m~5%\u007fUcu>!%!";
      d[21] = ">2N`\n\u0005(2K:\u0019\u0012?yH<\u0015\u0006.>_+^\u00113";
      d[22] = "L0\u0006)e\u001c9\u0010\r&tSX\u001e\u0006-p\t,";
      d[23] = "iq\u0004/EKb~\u0015`$Eiu\u0011:";
      d[24] = "Dy\u000b\u0011KQ_:Xi]iI0\f\u0006Z\u0002W!N\u00134PIpWVO\u0010X:Hi";
      d[25] = "s\u001bTO\u0019.hX\u00077\u000f\u0016~RSX\b}`C\u0011Mf-![\rL^l*GU7";
      d[26] = "n\u001a\r\u001c\u001b6iXD\frc?[V\u0015\u001eQn\u001b\u0007Jr:lWI\u0013B7=GFr";
      d[27] = "\u0013\u0018R\u0017>(L[\r\u0006[}SZ\u0016\u001b=jrA\t\u001b\u001ewJD\r\r[*\u0010P\u0013\u0017k'A@\u001cv";
      d[28] = "IYO\u0005NkR\u001a\u001c}XSD\u0010H\u0012_8Z\u0001\n\u00071mO\u000b\u000eD\r4P\u0011\u0003}";
      d[29] = "xq\u0018h!\u0000||\u0016!X\u0006G~\u000f2%T{'\u0010((m";
      d[30] = "|6cS9#gu0+/\u001bq\u007fdD(pon&QF+eg;\u0012w\"u69+";
      d[31] = "1\u000ee@M**M68[\u0012<GbW\\y\"V B2.lO&Y\u0002#=_)8";
      d[32] = "QY\u0001Q\u00009[\u0004\u001a\bjgY\u0005\u000f\u0004=0\u0007RZh\u0003w\u0001\u0017\u0015\u0014Q7B\u0017";
      d[33] = "<J;Wz_g\u0012>A\u0003VVG<KrQ:P-W}?=A#HmS*P?G\u0003";
      d[34] = "a=\u001f\u0006'(z~L~2\u0010lt\u0018\u00116{reZ\u0004X xlGGi)h=E~";
      d[35] = ">#>y\u007fX(+ax\u0007\u0000R)w!h\u000797fc}iiv~\u007f|Q(}b'\u0007";
      d[36] = "M\u0011\u001bxAWGL\u0000!+\u0002I\\\u0011&G0\u001e\u001aOq\u0010g\u0018\u001dJ/BW\u001f_\u0003?+";
      d[37] = "\u0004\nw\u000blY\u0003\u0003o\u000b\u0010\bi\u001fsI\u007f\u000f\u0002\u0001b\u000bjaY\u000bk\u0016)PP\u001b:\u0014\u0010";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = d[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(e[var4]);
            d[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = d[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            d[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  d[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1632440577195834L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = d[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  d[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1632440577195834L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        d[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1632440577195834L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 237;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 73;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 204;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 170;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 228;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 97;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 237;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 73;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 204;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ar_C0038",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ar" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
