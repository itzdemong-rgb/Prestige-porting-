package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.MovementPhaseEvent;
import dev.zprestige.prestige.api.events.MovementResetEvent;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderCallback;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.RenderEvents;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.fabric.api.event.Event;

public class MovementPhaseTracker {
   private boolean a;
   private static final long b = 93490574526338L;
   private static final Object[] c = new Object[40];
   private static final String[] d = new String[40];
   private static volatile MethodHandle bindingCache1;

   public MovementPhaseTracker(long var1) {
      super();
      var1 = 93490574526338L ^ var1;
      long var3 = var1 ^ 34011278957054L;

      this.a = dev.prestige.recovery.SourceSupport.asBoolean(0);
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
      Event var10 = RenderEvents.a;
      RenderCallback var8 = invokeBinding1(this);
      Event var7 = var10;
      var7.register(var8);
   }

   @EventListener
   public void a(MovementResetEvent var1) {
      long var10001 = 21931603116008L ^ 139480131569251L;
      int var10000 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      ModuleManager var10 = Prestige.d;
      List var11 = var10.aReturningVoid();
      Iterator var7 = var11.iterator();
      int var6 = var10000;

      int var58;
      do {
         Iterator var12 = var7;
         boolean var42 = var12.hasNext();
         if (!var42) {
            break;
         }

         Module var8;
         boolean var9;
         boolean var36;
         Iterator var13 = var7;
         var8 = (Module)var13.next();
         Module var14 = var8;
         var9 = var14.aReturningBoolean();
         int var44 = var6;
         boolean var43 = var9;
         var36 = var43;
         boolean var33 = var43;
         label46:
         if (var44 == 0) {
            boolean var45 = var33;
            if (var45) {
               Object[] var17 = new Object[0];
               Module var16 = var8;
               boolean var59 = var16.cReturningBoolean(var17);
               int var47 = var6;
               boolean var46 = var59;
               var36 = var46;
               boolean var34 = var46;
               if (var47 != 0) {
                  break label46;
               }

               boolean var48 = var34;
               boolean var35 = var48;
               boolean var49 = var35;
               if (!var49) {
                  Object[] var21 = new Object[]{120024586762635L};
                  Module var20 = var8;
                  var20.bReturningVoid(var21);
               }
            }

            var36 = var9;
         }

         Module var41;
         label39: {
            label38: {
               int var51 = var6;
               boolean var50 = var36;
               boolean var40 = var50;
               boolean var37 = var50;
               if (var51 == 0) {
                  boolean var52 = var37;
                  if (var52) {
                     break label38;
                  }

                  int var54 = var6;
                  Module var53 = var8;
                  var41 = var53;
                  Module var38 = var53;
                  if (var54 != 0) {
                     break label39;
                  }

                  Module var55 = var38;
                  Module var39 = var55;
                  Object[] var26 = new Object[0];
                  Module var25 = var39;
                  boolean var56 = var25.cReturningBoolean(var26);
                  var40 = var56;
               }

               boolean var57 = var40;
               if (var57) {
                  Object[] var29 = new Object[]{120024586762635L};
                  Module var28 = var8;
                  var28.bReturningVoid(var29);
               }
            }

            var41 = var8;
         }

         Object[] var32 = new Object[]{var9};
         Module var31 = var41;
         var31.iReturningVoid(var32);
         var58 = var6;
      } while (var58 == 0);
   }

   @EventListener
   public void a(MovementPhaseEvent var1) {
      boolean var6 = this.a;
      if (var6) {
         Object[] var5 = new Object[0];
         MovementPhaseEvent var4 = var1;
         var4.aReturningVoid(var5);
      }
   }

   private void lambda$new$0(MeshBufferManager var1, RenderContext var2) {
      long var10001 = 74996989186054L ^ 91745650839617L;
      HudEditorScreen var9 = Prestige.l;
      Object[] var8 = new Object[]{var1, var2, 25583678111815L};
      HudEditorScreen var7 = var9;
      this.a = var7.bReturningBoolean(var8);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 34;
            yield var15;
         }
         case 1 -> {
            byte var16 = 51;
            yield var16;
         }
         case 2 -> {
            byte var17 = 11;
            yield var17;
         }
         case 3 -> {
            byte var18 = 29;
            yield var18;
         }
         case 4 -> {
            byte var19 = 48;
            yield var19;
         }
         case 5 -> {
            byte var20 = 38;
            yield var20;
         }
         case 6 -> {
            byte var21 = 32;
            yield var21;
         }
         case 7 -> {
            byte var22 = 7;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 56;
            yield var25;
         }
         case 11 -> {
            byte var26 = 47;
            yield var26;
         }
         case 12 -> {
            byte var27 = 20;
            yield var27;
         }
         case 13 -> {
            byte var28 = 21;
            yield var28;
         }
         case 14 -> {
            byte var29 = 60;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 28;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 26;
            yield var34;
         }
         case 20 -> {
            byte var35 = 54;
            yield var35;
         }
         case 21 -> {
            byte var36 = 5;
            yield var36;
         }
         case 22 -> {
            byte var37 = 13;
            yield var37;
         }
         case 23 -> {
            byte var38 = 49;
            yield var38;
         }
         case 24 -> {
            byte var39 = 61;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 23;
            yield var41;
         }
         case 27 -> {
            byte var42 = 53;
            yield var42;
         }
         case 28 -> {
            byte var43 = 22;
            yield var43;
         }
         case 29 -> {
            byte var44 = 59;
            yield var44;
         }
         case 30 -> {
            byte var45 = 9;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 35;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 10;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 14;
            yield var52;
         }
         case 38 -> {
            byte var53 = 12;
            yield var53;
         }
         case 39 -> {
            byte var54 = 3;
            yield var54;
         }
         case 40 -> {
            byte var55 = 46;
            yield var55;
         }
         case 41 -> {
            byte var56 = 44;
            yield var56;
         }
         case 42 -> {
            byte var57 = 16;
            yield var57;
         }
         case 43 -> {
            byte var58 = 41;
            yield var58;
         }
         case 44 -> {
            byte var59 = 58;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 31;
            yield var61;
         }
         case 47 -> {
            byte var62 = 50;
            yield var62;
         }
         case 48 -> {
            byte var63 = 30;
            yield var63;
         }
         case 49 -> {
            byte var64 = 6;
            yield var64;
         }
         case 50 -> {
            byte var65 = 37;
            yield var65;
         }
         case 51 -> {
            byte var66 = 0;
            yield var66;
         }
         case 52 -> {
            byte var67 = 33;
            yield var67;
         }
         case 53 -> {
            byte var68 = 45;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 8;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 52;
            yield var72;
         }
         case 58 -> {
            byte var73 = 55;
            yield var73;
         }
         case 59 -> {
            byte var74 = 57;
            yield var74;
         }
         case 60 -> {
            byte var75 = 18;
            yield var75;
         }
         case 61 -> {
            byte var76 = 42;
            yield var76;
         }
         case 62 -> {
            byte var77 = 15;
            yield var77;
         }
         default -> 2;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "SLJt~\u001dELO.m\nR\u0007L(a\u001eC@[?*\no";
      c[1] = "\u0011p\u0017\u0006\u0011\"dP\u001c\t\u0000m\u0005^\u0017\u0002\u00047q";
      c[2] = boolean.class;
      d[2] = "java/lang/Boolean";
      c[3] = "qp5\u0001F\u007fgp0[Uhp;3]Y|a|$J\u0012ly|&AH!Eg&\\Hfrp";
      c[4] = "ORL]YMCEQ\u0010RO\u000fQY\u0011MEB\u0019Y\u0003V\u0002DA]\u001dK\u0002dA]\u001dK";
      c[5] = "_=q/,XT2``MV_9d:";
      c[6] = void.class;
      d[6] = "java/lang/Void";
      c[7] = "/:pxQ\u00119:u\"B\u0006.qv$N\u0012?6a3\u0005\u0003\u0007";
      c[8] = "'e3\u0005#\fRE8\n2C3K3\u00016\u0019G";
      c[9] = "\u00023:53\u001f\u00143?o \b\u0003x<i,\u001c\u0012?+~g\f\f";
      c[10] = "(KF\ta&#DWF\u0002+6IX-7)'ZD\u0001 $";
      c[11] = "hEV\u0003Di~ESYW~i\u000eP_[jxIGH\u0010xI";
      c[12] = "\u0004YON*0qyDA;\u007f\u0010wOJ?%d";
      c[13] = "FQX?V\u0007PQ]eE\u0010G\u001a^cI\u0004V]It\u0002\u0013s";
      c[14] = "/NnvZ9ZneyKv;`nrO,O";
      c[15] = int.class;
      d[15] = "java/lang/Integer";
      c[16] = "-F\u001e}0\u001e3N\u00042R\u00024S";
      c[17] = "DW\u0003\u0018\u000f\u0013Z_\u0019Wh\u0012KD\u0014\rN\u0014";
      c[18] = "&[$l\u0010VS{/c\u0001\u00192u$h\u0005CF";
      c[19] = ")2E\\\u0000l?2@\u0006\u0013{(yC\u0000\u001fo9>T\u0017TR,#Z\u0004\u001f";
      c[20] = "q\u0015\u001c\u0018r1g\u0015\u0019Ba&p^\u001aDm2a\u0019\rS&\"R";
      c[21] = "e;\u0015JRj\u0010\u001b\u001eEC%q\u0015\u0015NG\u007f\u0005";
      c[22] = "fjJ\u0013\u001a\u00044:\u0015\u0004$\u000eWjM\u0006N\u00074<\u0010\f\u0018enu\u001d\u0012^\f'dL\u000f$";
      c[23] = "'u \u0016\u0006p'vsA8`\u0018n2\u0014Qp|n+JW\n";
      c[24] = "d/.j\u0013eds1 }|rr&q\u0001zt\u001f7wM&t\u007f:b\u000fa\u000e";
      c[25] = "[p\u0001SU]\u001b`YTmIe/\u000bH\\D\u001bu\u000bL\u000f Z~\u001a\u0006\t^\u0000~\u001eUm";
      c[26] = "n;Pzyu<k\u000fmG}_l\u001ci?n6%\r8\"\u0014";
      c[27] = "K'@M=iM8\u0000*=WOz\u0013@54\u0019'\u0019\u0016WnP*\u0007P>'A{\u001a*";
      c[28] = "\r;2BITU+\"^\"\t7(5\rE\u0007\t.*M";
      c[29] = "%*\u00057:rwzZ \u0004r\u0014*\u0002\"nqw|_(8\u0013(%X4?nj#R5\u0004";
      c[30] = "\u000e*Hm8\u001f\tvBn]\u001abtO6'A\u001f6I<&z";
      c[31] = "#p\u0016\f\tWu{JA`\\N!J\f\u0012[6!\u0016\u0013X5";
      c[32] = "\u001b~\u0019~\u000eF\u0016k[9t@\u001daUEH\u001a\u0002wH~\u001a\u001e\u001d\u007f)";
      c[33] = "R=2\\|Y\u000bvgV\u0013J\u0005)7Do]\u0012Fj\u0003aV\t}8\u0007~^hz7_i\u000b\u001581Uh0";
      c[34] = "9\u0004\u001c\u0017Hya\u0014\f\u000b#,\u0003\u0010G\u000bQ)aFLW\u001c";
      c[35] = "+,_u{k+/\f\"Ex\u00140\f\u007f/swfQuy\u0011(?Vi~lj9\\hE";
      c[36] = "[_\u001c\u0005\u0015d\u0003O\f\u0019~7a\u001b\u001d\u0005\u00079\b^\rN\u0018";
      c[37] = "[KKFtO\t\u001b\u0014QJDjKLS L\t\u001d\u0011Yv.VD\u0016EqS\u0014B\u001cDJ";
      c[38] = "c\u0005`\u000bG7&\u0015+\u0014#7^\n*\u001eI<=\\w\u0014\u001f^b\u0005p\b\u0018# \u0003z\t#";
      c[39] = "z`|\f$\u0014wu>K^\u0014xt\nZ.\b\u00116=]&\u000ex\u007f,\f;t";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(420318172170951L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(420318172170951L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(420318172170951L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 239;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 201;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 163;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 194;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 210;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 81;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 239;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 201;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 163;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cj_C0130",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cj" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static RenderCallback invokeBinding1(MovementPhaseTracker var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/cj_C0130;)Ldev/zprestige/prestige/dm_C0190;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/cj_C0130",
                     "lambda$new$0",
                     "(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (RenderCallback)var2.invokeExact((MovementPhaseTracker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
