package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.io.IOException;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class MsdfFontManager {
   private static volatile MsdfFontManager a;
   private final Map b = new HashMap();
   private MsdfFont c;
   private static final long d = 60909580293874L;
   private static final String[] e;
   private static final String[] f;
   private static final Map g = new HashMap(13);
   private static final Object[] h = new Object[22];
   private static final String[] i = new String[22];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;

   public MsdfFont aReturningcx_C0158(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 60909580293874L ^ var2;
      long var4 = var2 ^ 56137817912331L;
      int var10000 = Event.bReturningInt();
      MsdfFont var7 = this.c;
      int var6 = var10000;
      int var14 = var6;
      MsdfFont var13 = var7;
      MsdfFont var12 = var13;
      MsdfFont var11 = var13;
      if (var14 == 0) {
         MsdfFont var15 = var11;
         if (var15 == null) {
            short var10001 = 1047;
            long var10002 = 2706503045996526327L ^ var2;
            Object[] var10 = new Object[]{"inter", var4};
            MsdfFontManager var9 = this;
            var7 = var9.bReturningcx_C0158(var10);
            this.c = var7;
         }

         var12 = var7;
      }

      return var12;
   }

   public MsdfFont bReturningcx_C0158(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 60909580293874L ^ var2;
      Map var8 = this.b;
      Function var7 = invokeBinding1(var4);
      String var6 = var4;
      Map var5 = var8;
      return (MsdfFont)var5.computeIfAbsent(var6, var7);
   }

   public void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 60909580293874L ^ var2;
      invokeBinding4(invokeBinding2(this.b, 132517915998439642L, var2), invokeBinding3(), 132339858171294807L, var2);
      invokeBinding5(this.b, 132433425819737067L, var2);
      this.c = null;
   }

   public void bReturningVoid(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 60909580293874L ^ var2;
      int var10000 = invokeBinding6(7556334256608447404L, var2);
      MsdfFont var6 = (MsdfFont)invokeBinding7(this.b, var4, 7555682805700428463L, var2);
      int var5 = var10000;

      MsdfFont var9;
      label21: {
         try {
            int var11 = var5;
            MsdfFont var10 = var6;
            var9 = var10;
            MsdfFont var7 = var10;
            if (var11 == 0) {
               break label21;
            }

            MsdfFont var12 = var7;
            if (var12 == null) {
               return;
            }
         } catch (RuntimeException var13) {
            throw invokeBinding8(var13, 7556061656998936821L, var2);
         }

         var9 = var6;
      }

      invokeBinding9(var9, 7556213827427844645L, var2);
   }

   private static MsdfFont lambda$getFont$0(String var0, String var1) {
      long var10001 = 114115618279286L ^ 43533188212555L;

      try {
         return new MsdfFont(var0, 70773559273533L);
      } catch (IOException var9) {
         throw new RuntimeException("Failed to load MSDF font: " + var0, var9);
      }
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(119628621605587L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      String var6 = "È\u0097*ÆÄÐ®Ô^Íè\u008dW\b\u0083Ìÿ3)©\u009eð\u0092\u0000ó\u009cÝ\u0094»\u0002R\u0010\u0086\u008en\u0086ÁçS\"l\u0017à\u001f«Æ\u0093l\u0010\u0010<\u0086\u0018^k¥µÈG\u0003ÿ\u009f£`\u009d";
      int var8 = "È\u0097*ÆÄÐ®Ô^Íè\u008dW\b\u0083Ìÿ3)©\u009eð\u0092\u0000ó\u009cÝ\u0094»\u0002R\u0010\u0086\u008en\u0086ÁçS\"l\u0017à\u001f«Æ\u0093l\u0010\u0010<\u0086\u0018^k¥µÈG\u0003ÿ\u009f£`\u009d"
         .length();
      char var5 = '0';
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = a(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            e = var9;
            f = new String[2];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12652;
      if (f[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])g.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cz", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = e[var5].getBytes("ISO-8859-1");
         f[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return f[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cz_C0162",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cz" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 25;
            yield var15;
         }
         case 1 -> {
            byte var16 = 59;
            yield var16;
         }
         case 2 -> {
            byte var17 = 58;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 37;
            yield var20;
         }
         case 6 -> {
            byte var21 = 50;
            yield var21;
         }
         case 7 -> {
            byte var22 = 24;
            yield var22;
         }
         case 8 -> {
            byte var23 = 53;
            yield var23;
         }
         case 9 -> {
            byte var24 = 54;
            yield var24;
         }
         case 10 -> {
            byte var25 = 10;
            yield var25;
         }
         case 11 -> {
            byte var26 = 4;
            yield var26;
         }
         case 12 -> {
            byte var27 = 52;
            yield var27;
         }
         case 13 -> {
            byte var28 = 33;
            yield var28;
         }
         case 14 -> {
            byte var29 = 1;
            yield var29;
         }
         case 15 -> {
            byte var30 = 30;
            yield var30;
         }
         case 16 -> {
            byte var31 = 47;
            yield var31;
         }
         case 17 -> {
            byte var32 = 8;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 40;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 35;
            yield var36;
         }
         case 22 -> {
            byte var37 = 57;
            yield var37;
         }
         case 23 -> {
            byte var38 = 49;
            yield var38;
         }
         case 24 -> {
            byte var39 = 36;
            yield var39;
         }
         case 25 -> {
            byte var40 = 9;
            yield var40;
         }
         case 26 -> {
            byte var41 = 38;
            yield var41;
         }
         case 27 -> {
            byte var42 = 20;
            yield var42;
         }
         case 28 -> {
            byte var43 = 44;
            yield var43;
         }
         case 29 -> {
            byte var44 = 26;
            yield var44;
         }
         case 30 -> {
            byte var45 = 46;
            yield var45;
         }
         case 31 -> {
            byte var46 = 27;
            yield var46;
         }
         case 32 -> {
            byte var47 = 22;
            yield var47;
         }
         case 33 -> {
            byte var48 = 55;
            yield var48;
         }
         case 34 -> {
            byte var49 = 42;
            yield var49;
         }
         case 35 -> {
            byte var50 = 32;
            yield var50;
         }
         case 36 -> {
            byte var51 = 19;
            yield var51;
         }
         case 37 -> {
            byte var52 = 39;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 31;
            yield var54;
         }
         case 40 -> {
            byte var55 = 48;
            yield var55;
         }
         case 41 -> {
            byte var56 = 28;
            yield var56;
         }
         case 42 -> {
            byte var57 = 7;
            yield var57;
         }
         case 43 -> {
            byte var58 = 14;
            yield var58;
         }
         case 44 -> {
            byte var59 = 5;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 45;
            yield var61;
         }
         case 47 -> {
            byte var62 = 21;
            yield var62;
         }
         case 48 -> {
            byte var63 = 3;
            yield var63;
         }
         case 49 -> {
            byte var64 = 51;
            yield var64;
         }
         case 50 -> {
            byte var65 = 16;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 11;
            yield var67;
         }
         case 53 -> {
            byte var68 = 23;
            yield var68;
         }
         case 54 -> {
            byte var69 = 12;
            yield var69;
         }
         case 55 -> {
            byte var70 = 43;
            yield var70;
         }
         case 56 -> {
            byte var71 = 29;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 18;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 13;
            yield var77;
         }
         default -> 15;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "TeL,\u001a\u001cJmVcy\bN";
      h[1] = "7l$\u0005#%<c5JB+7h1\u0010";
      h[2] = "b<w\u0003Z@t<rYIWcwq_ECr0fH\u000eS|";
      h[3] = "J.B8CyA!Sw?`N;]4\bPX,Q)\u0019|O!";
      h[4] = "z\u0000MQ$\u0010l\u0000H\u000b7\u0007{KK\r;\u0013j\f\\\u001ap\u0001[";
      h[5] = int.class;
      i[5] = "java/lang/Integer";
      h[6] = "l%Dt\u000b~z%A.\u0018imnB(\u0014}|)U?_mp";
      h[7] = void.class;
      i[7] = "java/lang/Void";
      h[8] = ".gC \u000f\u0006[GH/\u001eI:IC$\u001a\u0013N";
      h[9] = "\n7\u0000?s\u0019\u0014?\u001ap;\u0019\u000e5\u000272\u0002N\u0010\u00030>\u0018\t9\u0018";
      h[10] = "s;\u000f\f\u0001\\m3\u0015ClFu6\u001c\u000e[@v4";
      h[11] = "=,q~?m#$k1wm9.sv~vy\u000ehqbm:(u";
      h[12] = "\u000ei\r!\u001c3\u0019,N\u0010]7\u0002wJ}'+\u0004t[mA&\u0007}4aD>\bmRlG7g";
      h[13] = "\u0018j{:T5\u001c;\"o72#;bjV<L0c6TX";
      h[14] = "n\u0003b@O7+\u0006wH+:W]t]D/2\u001c4[[PkQaQY7o\ro\n+";
      h[15] = "\u0019`?F\u0005\u001b\u000e%|wU\u0015\u0015a{\u000bS3\u001ePl\fS\u0014\f\u0019w\u0014Z\u001d\r\u007fz\u0017SrNc<\u001d^N\u0010 6\u0018>\u0003\u0013}i\nX\u000e\u0010t\u0006";
      h[16] = "eJyct\u000e:\u001d;!E\u0001=\f\u000bt.\u000fZFws&Qg\u0012x&=og\u0019,}x\b&\u001a=$E";
      h[17] = "L.ja=r[k)Pm\u007fH>)P;tO7n7zw^nS";
      h[18] = "Tf\u0002\u0012Ww\u0011c\u0017\u001a3ym?]\fPqV\u007fP\u0014X\u0010W4\b\u000bR+\u00179\u0010\u00033";
      h[19] = "K\u0006}t5\u001d\\C>Ep\u001dF\u0002)>\u000eK\u001e@:to\u0014I\u0002xE";
      h[20] = "\u001f@\u001191\u001c\u001b\u001c\u001fbC\u0012#L\u00138#FD\r\u0010)z{";
      h[21] = "OsQ\u0018U\tK\"\bM6\u000ft\"HHW\u0000\u001b)I\u0014Ud";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(97531751523074L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(97531751523074L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(97531751523074L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 222;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 201;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 111;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 243;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 120;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 102;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 222;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 201;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 111;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cz_C0162",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cz" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1(String var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ljava/lang/String;)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cz_C0162",
                     "lambda$getFont$0",
                     "(Ljava/lang/String;Ljava/lang/String;)Ldev/zprestige/prestige/cx_C0158;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/String;)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var2.invokeExact((String)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Collection invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/Collection;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Collection)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Consumer invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("()Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/cx_C0158", "a", "()V"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/cx_C0158;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static void invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = b(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding6(long var0, long var2) {
         MethodHandle var8 = bindingCache6;
         MethodHandle var7 = bindingCache6;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache6 = b(MethodHandles.lookup(), "f", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Object invokeBinding7(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = b(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RuntimeException invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(
                  MethodHandles.lookup(), "f", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/RuntimeException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RuntimeException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = b(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
