package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.client.ui.ModuleToast;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;

public class NotificationManager implements MinecraftAccess {
   private final ArrayList a;
   private static long c;
   private static float d;
   private static final long e = 47610878775L;
   private static final Object[] f = new Object[40];
   private static final String[] g = new String[40];

   public NotificationManager(long var1) {
      super();
      var1 = 47610878775L ^ var1;
      long var3 = var1 ^ 8989748292185L;

      this.a = new ArrayList();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 110257684362790L ^ 85889093085502L;
      int var10000 = Event.bReturningInt();
      d = (float)(System.currentTimeMillis() - c) * 0.005F;
      int var6 = var10000;
      c = System.currentTimeMillis();
      ArrayList var19 = this.a;
      byte var60 = ((byte)((var19.isEmpty()) ? 1 : 0));
      int var48 = var6;
      byte var47 = var60;
      int var41 = var47;
      byte var40 = var47;
      if (var48 == 0) {
         byte var49 = var40;
         if (var49 != 0) {
            return;
         }

         MinecraftClient var21 = b;
         Window var22 = var21.getWindow();
         var41 = var22.getScaleFactor();
      }

      float var7 = var41;
      float var8 = 2.0F / var7;
      Matrix4f var61 = new Matrix4f();
      float var26 = 1.0F;
      float var25 = var8;
      float var24 = var8;
      Matrix4f var23 = var61;
      Matrix4f var9 = var23.scale(var24, var25, var26);
      MinecraftClient var27 = b;
      Window var28 = var27.getWindow();
      float var10 = var28.getFramebufferWidth() / 2.0F;
      MinecraftClient var29 = b;
      Window var30 = var29.getWindow();
      float var11 = var30.getFramebufferHeight() / 2.0F;
      float var12 = 150.0F;
      float var13 = 30.0F;
      float var14 = var10 - var12 - 10.0F;
      float var15 = var11 - 50.0F;
      ArrayList var31 = this.a;
      Iterator var16 = var31.iterator();

      while (true) {
         Iterator var32 = var16;
         boolean var50 = var32.hasNext();
         if (!var50) {
            break;
         }

         Iterator var33 = var16;
         ModuleToast var17 = (ModuleToast)var33.next();
         int var52 = var6;
         byte var51 = ((byte)((var17.recoveryAccess_read_h()) ? 1 : 0));
         int var43 = var51;
         byte var42 = var51;
         if (var52 == 0) {
            byte var53 = var42;
            if (var53 != 0) {
               Iterator var35 = var16;
               var35.remove();
               int var54 = var6;
               if (var54 == 0) {
                  continue;
               }
            }

            float var62;
            var43 = (var62 = var15 - var11 / 4.0F) == 0.0F ? 0 : (var62 < 0.0F ? -1 : 1);
         }

         int var46;
         label41: {
            int var56 = var6;
            int var55 = var43;
            int var45 = var55;
            int var44 = var55;
            if (var56 == 0) {
               int var57 = var44;
               if (var57 <= 0) {
                  var46 = 0;
                  break label41;
               }

               var45 = 1;
            }

            int var58 = var45;
            var46 = var58;
         }

         int var18 = var46;
         MeshBufferManager var10003 = var1.a;
         RenderContext var10004 = var1.b;
         Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, 46569306857240L};
         var10012[7] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var18));
         var10012[6] = var13;
         var10012[5] = var12;
         var10012[4] = var15;
         var10012[3] = var14;
         var10012[2] = var10004;
         var10012[1] = var10003;
         var10012[0] = var9;
         Object[] var39 = var10012;
         ModuleToast var38 = var17;
         var15 -= var38.aReturningFloat(var39);
         int var59 = var6;
         if (var59 != 0) {
            break;
         }
      }
   }

   public void aReturningVoid(Object[] var1) {
      String var8 = (String)var1[0];
      String var7 = (String)var1[1];
      long var5 = (Long)var1[2];
      NotificationType var2 = (NotificationType)var1[3];
      long var3 = (Long)var1[4];
      var3 = 47610878775L ^ var3;
      long var9 = var3 ^ 29163372964850L;
      int var10000 = Event.cReturningInt();
      ArrayList var14 = new ArrayList(this.a);
      Iterator var12 = var14.iterator();
      int var11 = var10000;

      while (true) {
         Iterator var15 = var12;
         boolean var36 = var15.hasNext();
         if (var36) {
            Iterator var16 = var12;
            ModuleToast var13 = (ModuleToast)var16.next();
            String var18 = var8;
            String var17 = var13.recoveryAccess_read_a();
            boolean var51 = var17.equals(var18);
            int var38 = var11;
            boolean var37 = var51;
            boolean var28 = var37;
            if (var38 == 0) {
               break;
            }

            label33: {
               ModuleToast var34;
               label43: {
                  int var40 = var11;
                  boolean var39 = var28;
                  boolean var33 = var39;
                  boolean var29 = var39;
                  if (var40 != 0) {
                     boolean var41 = var29;
                     boolean var30 = var41;
                     boolean var42 = var30;
                     if (!var42) {
                        break label33;
                     }

                     int var44 = var11;
                     ModuleToast var43 = var13;
                     var34 = var43;
                     ModuleToast var31 = var43;
                     if (var44 == 0) {
                        break label43;
                     }

                     ModuleToast var45 = var31;
                     ModuleToast var32 = var45;
                     String var23 = var7;
                     String var22 = var32.recoveryAccess_read_b();
                     boolean var46 = var22.equals(var23);
                     var33 = var46;
                  }

                  boolean var47 = var33;
                  if (!var47) {
                     break label33;
                  }

                  var13.g = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  ModuleToast var48 = var13;
                  var34 = var48;
               }

               var34.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
            }

            int var49 = var11;
            if (var49 != 0) {
               continue;
            }
         }

         ArrayList var52 = this.a;
         ModuleToast var27 = new ModuleToast(var8, var7, var5, var2, var9);
         ArrayList var26 = var52;
         boolean var35 = var26.add(var27);
         break;
      }
   }

   public boolean aReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 47610878775L ^ var2;
      int var4 = Event.cReturningInt();
      ArrayList var5 = this.a;
      byte var13 = ((byte)((var5.isEmpty()) ? 1 : 0));
      int var10 = var4;
      byte var9 = var13;
      byte var7 = var9;
      byte var6 = var9;
      if (var10 != 0) {
         byte var11 = var6;
         if (var11 != 0) {
            return false;
         }

         var7 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(47368291279353L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 6512230859453326334L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)90L,
            (byte)23136L,
            (byte)5922839L,
            (byte)1516246902L,
            (byte)388159207073L,
            (byte)99368757010701L,
            (byte)25438401794739555L,
            (byte)6512230859453326334L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // long var0 = var8;
      c = var0;
      d = 0.0F;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 42;
            yield var16;
         }
         case 2 -> {
            byte var17 = 38;
            yield var17;
         }
         case 3 -> {
            byte var18 = 4;
            yield var18;
         }
         case 4 -> {
            byte var19 = 18;
            yield var19;
         }
         case 5 -> {
            byte var20 = 22;
            yield var20;
         }
         case 6 -> {
            byte var21 = 6;
            yield var21;
         }
         case 7 -> {
            byte var22 = 27;
            yield var22;
         }
         case 8 -> {
            byte var23 = 37;
            yield var23;
         }
         case 9 -> {
            byte var24 = 19;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 20;
            yield var26;
         }
         case 12 -> {
            byte var27 = 50;
            yield var27;
         }
         case 13 -> {
            byte var28 = 60;
            yield var28;
         }
         case 14 -> {
            byte var29 = 40;
            yield var29;
         }
         case 15 -> {
            byte var30 = 26;
            yield var30;
         }
         case 16 -> {
            byte var31 = 59;
            yield var31;
         }
         case 17 -> {
            byte var32 = 56;
            yield var32;
         }
         case 18 -> {
            byte var33 = 9;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 21;
            yield var35;
         }
         case 21 -> {
            byte var36 = 54;
            yield var36;
         }
         case 22 -> {
            byte var37 = 55;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 33;
            yield var39;
         }
         case 25 -> {
            byte var40 = 32;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 23;
            yield var42;
         }
         case 28 -> {
            byte var43 = 30;
            yield var43;
         }
         case 29 -> {
            byte var44 = 17;
            yield var44;
         }
         case 30 -> {
            byte var45 = 35;
            yield var45;
         }
         case 31 -> {
            byte var46 = 36;
            yield var46;
         }
         case 32 -> {
            byte var47 = 11;
            yield var47;
         }
         case 33 -> {
            byte var48 = 62;
            yield var48;
         }
         case 34 -> {
            byte var49 = 0;
            yield var49;
         }
         case 35 -> {
            byte var50 = 53;
            yield var50;
         }
         case 36 -> {
            byte var51 = 34;
            yield var51;
         }
         case 37 -> {
            byte var52 = 10;
            yield var52;
         }
         case 38 -> {
            byte var53 = 1;
            yield var53;
         }
         case 39 -> {
            byte var54 = 13;
            yield var54;
         }
         case 40 -> {
            byte var55 = 8;
            yield var55;
         }
         case 41 -> {
            byte var56 = 3;
            yield var56;
         }
         case 42 -> {
            byte var57 = 47;
            yield var57;
         }
         case 43 -> {
            byte var58 = 61;
            yield var58;
         }
         case 44 -> {
            byte var59 = 63;
            yield var59;
         }
         case 45 -> {
            byte var60 = 15;
            yield var60;
         }
         case 46 -> {
            byte var61 = 16;
            yield var61;
         }
         case 47 -> {
            byte var62 = 31;
            yield var62;
         }
         case 48 -> {
            byte var63 = 5;
            yield var63;
         }
         case 49 -> {
            byte var64 = 14;
            yield var64;
         }
         case 50 -> {
            byte var65 = 52;
            yield var65;
         }
         case 51 -> {
            byte var66 = 24;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 46;
            yield var68;
         }
         case 54 -> {
            byte var69 = 28;
            yield var69;
         }
         case 55 -> {
            byte var70 = 58;
            yield var70;
         }
         case 56 -> {
            byte var71 = 51;
            yield var71;
         }
         case 57 -> {
            byte var72 = 39;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 29;
            yield var74;
         }
         case 60 -> {
            byte var75 = 2;
            yield var75;
         }
         case 61 -> {
            byte var76 = 43;
            yield var76;
         }
         case 62 -> {
            byte var77 = 12;
            yield var77;
         }
         default -> 41;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "P\u0006fS\u0002!F\u0006c\t\u00116QM`\u000f\u001d\"@\nw\u0018V0q";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = "@g7~\u0017\u0012@g \"\u001b\u001dZ, <\u001b\b]]r`NJ";
      f[3] = "*\u001c8\u00114\u000e4\u0014\"^[\t2\u001c7<s\b4";
      f[4] = "D\u0017Z\u0006\u001awZ\u001f@I}vK\u0004M\u0013[p";
      f[5] = "\u001e\u0011/!\u0019^\u0015\u001e>ndK\u0007\u0004<-";
      f[6] = long.class;
      g[6] = "java/lang/Long";
      f[7] = "HCKc\u000e-^CN9\u001d:I\bM?\u0011.XOZ(Z>c";
      f[8] = "\u0005+\u0003\u001dOp\u000e$\u0012R,}\u001b)\u001d9\u0019\u007f\n:\u0001\u0015\u000er";
      f[9] = "\u007f\u0003Ea,a}\u001d\f\u0002'zb\u0018Z{ ";
      f[10] = float.class;
      g[10] = "java/lang/Float";
      f[11] = "2':W\u0011s9(+\u0018p}2#/B";
      f[12] = boolean.class;
      g[12] = "java/lang/Boolean";
      f[13] = void.class;
      g[13] = "java/lang/Void";
      f[14] = "\u0012l\u0019\u0015#}\u0012l\u000eI/r\b'\u000eW/g\u000fV^\n~";
      f[15] = "+1Ge\u007f*=1B?l=*zA9`);=V.+9\u001f";
      f[16] = "(<\u00060'O]\u001c\r?6\u0000<\u0012\u000642ZH";
      f[17] = "9\u0019%T\u0005i2\u00164\u001bxq!\u0011=R";
      f[18] = "[0pg\u001f*M0u=\f=Z{v;\u0000)K<a,K9S<c'\u0011to'c:\u00113X0";
      f[19] = "M$NzA=[$K R*LoH&^>](_1\u0015/e";
      f[20] = "\nc%OKA\u007fC.@Z\u000e\u001eM%K^Tj";
      f[21] = "4Tpd\f\u0006 \u0006w_\b}b]~#\u0018\u000f*\u000btfb";
      f[22] = "yR\u000e6n;oR\u00057\u0001kk\u0010\u0007nz\u0006-\u001c\u001cugbc\u0011Q4\u00016m\u0011\u000fjfli\f\n\n";
      f[23] = "f;om?JfpynX\u001327\u007fd4!cw/2XO4+cy*\u0007b!&\u0003";
      f[24] = "N\u0011,=7c\nI'vS~\b\u0019=./x\u000et|\u007f>t\u000bI|&=dt";
      f[25] = " {~^6bfc-^D2famW\"%GzrW\u00018\u007f\u007fvADe%g}\u000089#**:";
      f[26] = "->1=x;ni4$\u001e/\u0010j04%\u007f/&!0\u007fF-*&d'ya;\">\u001e";
      f[27] = "\u0013nDG\u0007i\u0013%RD`0GbTN\f\u0002\u0016#\f\u0017`lA~HS\u0012$\u0017t\r)";
      f[28] = "+\u000f\u0011%\u000b#?]\u0016\u001e\u000eX}\u0006\u001fb\u001f*5P\u0015'e";
      f[29] = "gjMS^f#2F\u0018:s1c&\u0016Kh\"iBXF%c\u000f\u0016VF{=hLR[~]";
      f[30] = "20x\u0001 mgy8Q\u0018pg  \\\u00184n4\u007f[{d<*81'iqr.Rw;o5D\u000ezv7#'^(hpIzH$;4//\u0001dk\f";
      f[31] = "sCXX\u0018Zs\u001a[Hg\u0001%\u000bI3X\u0016:\u0004SW\u0016\u001bwE5";
      f[32] = "\u001d3wQ<\u0019\u001dxaR[@I?gX7r\u0018\u007f6\u0002[\u001cO#{E)T\u0019)>?";
      f[33] = "\tuq\u0014+\\M-z_OAH]\u007f\u00163Q3 e\u0012.@Tza\u000f+ ";
      f[34] = "N\b\u001dI^WNQ\u001eY!\u0010\u0018U\u0017\\LjD\\HB\u001b\r\u0004OI\u0018!";
      f[35] = "*\nKTcR;\u000f\u001e@\u001aJA\u0001KP~L|\u0006D\u0016|";
      f[36] = "\tq\u0014q\u000f~\fz\u0017uv+\r<\u0011-\u001a\u0019ZzOzMNY0\u0001$\u0011rY{\u0017'v";
      f[37] = "],\tE[h]u\nU$5\u000fo\"CT)f$\u001bRE5\u0001~\u001fO@U";
      f[38] = "QcQ;\u0018\u0001Vl\u00179tU=c\u001a$\u001aYGsQ-\f<\fb\u0012?N[Lq\u0013et";
      f[39] = "(\u0017uY-#{\u00059S\u001c&A\u0014{Zr*;\u00040SdO~\u001b6\u001av,.I(]\u001c";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(809651263928658L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(809651263928658L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(809651263928658L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 114;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 116;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 226;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 85;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 87;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 218;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 114;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 116;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 226;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cO_C0139",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cO" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

    public static float recoveryAccess_read_d() { return dev.zprestige.prestige.client.management.NotificationManager.d; }
}
