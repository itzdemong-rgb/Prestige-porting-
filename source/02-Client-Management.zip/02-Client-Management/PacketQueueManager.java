package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.QueuedAction;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.client.management.PacketQueueResult;
import java.util.Iterator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.slot.SlotActionType;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.util.PlayerInput;

public class PacketQueueManager implements MinecraftAccess {
   public static boolean a;
   private static final int c;
   private final ArrayDeque d;
   private final List e;
   private volatile boolean f;
   private volatile boolean g;
   private boolean h;
   private boolean i;
   private boolean j;
   private int k;
   private static final long l = 12107707230062L;
   private static final Object[] m = new Object[67];
   private static final String[] n = new String[67];
   private static volatile MethodHandle bindingCache1;

   public PacketQueueManager(long var1) {
      super();
      var1 = 12107707230062L ^ var1;
      long var3 = var1 ^ 22289351453846L;

      this.d = new ArrayDeque();
      this.e = new ArrayList();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   public PacketQueueResult aReturningp_C0432(Object[] var1) {
      int var2 = (Integer)var1[0];
      int var5 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      var3 = 12107707230062L ^ var3;
      long var6 = var3 ^ 86651009734376L;
      Object[] var10007 = new Object[]{null, null, null, null, var6};
      var10007[2] = var5;
      var10007[1] = var2;
      var10007[0] = null;
      Object[] var9 = var10007;
      PacketQueueManager var8 = this;
      return var8.dReturningp_C0432(var9);
   }

   public PacketQueueResult bReturningp_C0432(Object[] var1) {
      int var2 = (Integer)var1[0];
      int var4 = (Integer)var1[1];
      Runnable var3 = (Runnable)var1[2];
      long var5 = (Long)var1[3];
      var5 = 12107707230062L ^ var5;
      long var7 = var5 ^ 76646868954134L;
      Object[] var10007 = new Object[]{null, null, null, var3, var7};
      var10007[2] = var4;
      var10007[1] = var2;
      var10007[0] = null;
      Object[] var10 = var10007;
      PacketQueueManager var9 = this;
      return var9.dReturningp_C0432(var10);
   }

   public PacketQueueResult cReturningp_C0432(Object[] var1) {
      Object var6 = var1[0];
      int var2 = (Integer)var1[1];
      int var5 = (Integer)var1[2];
      long var3 = (Long)var1[3];
      var3 = 12107707230062L ^ var3;
      long var7 = var3 ^ 33121045155865L;
      Object[] var10007 = new Object[]{null, null, null, null, var7};
      var10007[2] = var5;
      var10007[1] = var2;
      var10007[0] = var6;
      Object[] var10 = var10007;
      PacketQueueManager var9 = this;
      return var9.dReturningp_C0432(var10);
   }

   public PacketQueueResult dReturningp_C0432(Object[] var1) {
      dev.zprestige.prestige.client.management.PacketQueueManager var40;

      Object var3 = var1[0];
      int var4 = (Integer)var1[1];
      int var7 = (Integer)var1[2];
      Runnable var2 = (Runnable)var1[3];
      long var5 = (Long)var1[4];
      var5 = 12107707230062L ^ var5;
      long var8 = var5 ^ 1026572556952L;
      long var10 = var5 ^ 139358720496768L;
      int var12 = Event.cReturningInt();
      if (!Prestige.w) {
         MinecraftClient var10000 = b;
         if (var12 != 0) {
            MinecraftClient var16 = b;
            if (var16.player == null) {
               return PacketQueueResult.REJECTED;
            }

            var10000 = b;
         }

         if (var12 != 0) {
            MinecraftClient var19 = var10000;
            if (var19.world == null) {
               return PacketQueueResult.REJECTED;
            }

            var10000 = b;
         }

         MinecraftClient var22 = var10000;
         if (var22.interactionManager != null) {
            boolean var39 = a;
            if (var12 != 0) {
               if (!a) {
                  Object[] var42 = new Object[]{null, null, SlotActionType.SWAP, var8};
                  var42[1] = var7;
                  var42[0] = var4;
                  Object[] var25 = var42;
                  InventoryUtil.eReturningBoolean(var25);
                  return PacketQueueResult.IMMEDIATE;
               }

               MinecraftClient var27 = b;
               var39 = var27.isOnThread();
            }

            label53: {
               label52: {
                  if (var12 != 0) {
                     if (!var39) {
                        break label52;
                     }

                     var40 = this;
                     if (var12 == 0) {
                        break label53;
                     }

                     Object[] var31 = new Object[]{var10};
                     var39 = this.dReturningBoolean(var31);
                  }

                  if (var39) {
                     Object[] var10005 = new Object[]{null, null, SlotActionType.SWAP, var8};
                     var10005[1] = var7;
                     var10005[0] = var4;
                     Object[] var33 = var10005;
                     InventoryUtil.eReturningBoolean(var33);
                     return PacketQueueResult.IMMEDIATE;
                  }
               }

               var40 = this;
            }

            synchronized (var40) {
               ArrayDeque var41 = this.d;
               QueuedAction var36 = new QueuedAction(var3, var4, var7, var2);
               ArrayDeque var35 = var41;
               var35.add(var36);
               this.k = 0;
            }

            return PacketQueueResult.QUEUED;
         }
      }

      return PacketQueueResult.REJECTED;
   }

   public int aReturningInt(Object[] var1) {
      Object var2 = var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 12107707230062L ^ var3;
      int var5 = Event.cReturningInt();
      if (var2 == null) {
         return 0;
      } else {
         synchronized (this) {
            ArrayDeque var11 = this.d;
            int var7 = var11.size();
            ArrayDeque var18 = this.d;
            Predicate var13 = invokeBinding1(var2);
            ArrayDeque var12 = var18;
            var12.removeIf(var13);
            ArrayDeque var14 = this.d;
            int var8 = var7 - var14.size();
            int var19 = var8;
            if (var5 != 0) {
               if (var8 > 0) {
                  ArrayDeque var16 = this.d;
                  byte var20 = ((byte)((var16.isEmpty()) ? 1 : 0));
                  if (var5 == 0) {
                     return var20;
                  }

                  if (var20 != 0) {
                     this.k = 0;
                     if (var5 == 0) {
                        return (((this.i) ? 1 : 0));
                     }

                     if (this.i) {
                        if (var5 == 0) {
                           return (((this.h) ? 1 : 0));
                        }

                        if (this.h) {
                           this.j = dev.prestige.recovery.SourceSupport.asBoolean(1);
                        }
                     }
                  }
               }

               var19 = var8;
            }

            return var19;
         }
      }
   }

   public boolean aReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 12107707230062L ^ var2;
      int var10 = Event.bReturningInt();
      PacketQueueManager var5 = this;
      synchronized (this){} 
      int var4 = var10;

      try {
         ArrayDeque var7 = this.d;
         int var11 = (((var7.isEmpty()) ? 1 : 0));
         if (var4 == 0) {
            var11 = var11 == 0 ? 1 : 0;
         }

         
         return dev.prestige.recovery.SourceSupport.asBoolean(var11);
      } finally {
         
      }
   }

   public boolean bReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 12107707230062L ^ var2;
      int var4 = Event.bReturningInt();
      byte var20 = ((byte)((Prestige.w) ? 1 : 0));
      if (var4 == 0) {
         if (!Prestige.w) {
            if (var4 != 0) {
               return a;
            }

            if (a) {
               int var5;
               synchronized (this) {
                  ArrayDeque var11 = this.d;
                  int var21 = (((var11.isEmpty()) ? 1 : 0));
                  if (var4 == 0) {
                     var21 = var21 == 0 ? 1 : 0;
                  }

                  var5 = var21;
               }

               int var22 = var5;
               if (var4 == 0) {
                  if (var5 != 0) {
                     PacketQueueManager var23 = this;
                     if (var4 == 0) {
                        if (!this.i) {
                           MinecraftClient var15 = b;
                           if (var15.player != null) {
                              MinecraftClient var17 = b;
                              ClientPlayerEntity var18 = var17.player;
                              this.h = var18.isSprinting();
                           }
                        }

                        var23 = this;
                     }

                     var23.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
                     if (var4 == 0) {
                        return dev.prestige.recovery.SourceSupport.asBoolean(var5);
                     }
                  }

                  var22 = (((this.i) ? 1 : 0));
               }

               if (var4 != 0) {
                  return dev.prestige.recovery.SourceSupport.asBoolean(var22);
               }

               if (var22 != 0) {
                  this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  this.h = dev.prestige.recovery.SourceSupport.asBoolean(0);
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var5);
            }
         }

         var20 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var20);
   }

   public boolean cReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 12107707230062L ^ var2;
      int var4 = Event.cReturningInt();
      int var11 = var4;
      byte var10 = ((byte)((Prestige.w) ? 1 : 0));
      byte var8 = var10;
      byte var5 = var10;
      if (var11 != 0) {
         byte var12 = var5;
         label23:
         if (var12 == 0) {
            int var14 = var4;
            byte var13 = ((byte)((this.j) ? 1 : 0));
            byte var9 = var13;
            byte var6 = var13;
            if (var14 != 0) {
               byte var15 = var6;
               byte var7 = var15;
               byte var16 = var7;
               if (var16 == 0) {
                  break label23;
               }

               this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
               var9 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var9);
         }

         var8 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   public void aReturningVoid(Object[] var1) {
      int var5;
      Object var40;
      label90: {
         Packet var4 = (Packet)var1[0];
         long var2 = (Long)var1[1];
         long var10000 = 12107707230062L ^ var2;
         var5 = Event.bReturningInt();
         boolean var135 = var4 instanceof ClientCommandC2SPacket;
         int var75 = var5;
         boolean var74 = var135;
         boolean var39 = var74;
         boolean var30 = var74;
         if (var75 == 0) {
            Object var37;
            label83: {
               boolean var76 = var30;
               label82:
               if (var76) {
                  ClientCommandC2SPacket var6 = (ClientCommandC2SPacket)var4;
                  ClientCommandC2SPacket var9 = var6;
                  Mode var136 = var9.getMode();
                  int var79 = var5;
                  Mode var78 = Mode.START_SPRINTING;
                  Mode var77 = var136;
                  Mode var35 = var77;
                  Mode var36 = var78;
                  Mode var31 = var77;
                  Mode var32 = var78;
                  if (var79 == 0) {
                     Mode var81 = var32;
                     Mode var80 = var31;
                     if (var80 == var81) {
                        this.f = dev.prestige.recovery.SourceSupport.asBoolean(1);
                        int var82 = var5;
                        if (var82 == 0) {
                           break label82;
                        }
                     }

                     int var84 = var5;
                     ClientCommandC2SPacket var83 = var6;
                     var37 = var83;
                     ClientCommandC2SPacket var33 = var83;
                     if (var84 != 0) {
                        break label83;
                     }

                     ClientCommandC2SPacket var85 = var33;
                     ClientCommandC2SPacket var34 = var85;
                     ClientCommandC2SPacket var13 = var34;
                     Mode var137 = var13.getMode();
                     Mode var87 = Mode.STOP_SPRINTING;
                     Mode var86 = var137;
                     var35 = var86;
                     var36 = var87;
                  }

                  Mode var89 = var36;
                  Mode var88 = var35;
                  if (var88 == var89) {
                     this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  }
               }

               var37 = var4;
            }

            int var91 = var5;
            Object var90 = var37;
            var40 = var90;
            Object var38 = var90;
            if (var91 != 0) {
               break label90;
            }

            boolean var92 = var38 instanceof PlayerInputC2SPacket;
            var39 = var92;
         }

         boolean var93 = var39;
         if (!var93) {
            return;
         }

         var40 = var4;
      }

      PacketQueueManager var72;
      byte var73;
      label65: {
         PacketQueueManager var69;
         byte var70;
         PlayerInputC2SPacket var134 = (PlayerInputC2SPacket)var40;
         PlayerInputC2SPacket var17 = var134;
         PlayerInput var7 = var17.input();
         PlayerInput var18 = var7;
         byte var10001 = ((byte)((var18.forward()) ? 1 : 0));
         int var96 = var5;
         byte var95 = var10001;
         PacketQueueManager var94 = this;
         var69 = var94;
         var70 = var95;
         PacketQueueManager var41 = var94;
         byte var42 = var95;
         label64:
         if (var96 == 0) {
            byte var98 = var42;
            PacketQueueManager var97 = var41;
            PacketQueueManager var68 = var97;
            PacketQueueManager var43 = var97;
            if (var98 == 0) {
               PacketQueueManager var99 = var43;
               PacketQueueManager var44 = var99;
               PlayerInput var20 = var7;
               var10001 = ((byte)((var20.backward()) ? 1 : 0));
               int var102 = var5;
               byte var101 = var10001;
               PacketQueueManager var100 = var44;
               var69 = var100;
               var70 = var101;
               PacketQueueManager var45 = var100;
               byte var46 = var101;
               if (var102 != 0) {
                  break label64;
               }

               byte var104 = var46;
               PacketQueueManager var103 = var45;
               PacketQueueManager var47 = var103;
               byte var48 = var104;
               byte var106 = var48;
               PacketQueueManager var105 = var47;
               var68 = var105;
               PacketQueueManager var49 = var105;
               if (var106 == 0) {
                  PacketQueueManager var107 = var49;
                  PacketQueueManager var50 = var107;
                  PlayerInput var23 = var7;
                  var10001 = ((byte)((var23.left()) ? 1 : 0));
                  int var110 = var5;
                  byte var109 = var10001;
                  PacketQueueManager var108 = var50;
                  var69 = var108;
                  var70 = var109;
                  PacketQueueManager var51 = var108;
                  byte var52 = var109;
                  if (var110 != 0) {
                     break label64;
                  }

                  byte var112 = var52;
                  PacketQueueManager var111 = var51;
                  PacketQueueManager var53 = var111;
                  byte var54 = var112;
                  byte var114 = var54;
                  PacketQueueManager var113 = var53;
                  var68 = var113;
                  PacketQueueManager var55 = var113;
                  if (var114 == 0) {
                     PacketQueueManager var115 = var55;
                     PacketQueueManager var56 = var115;
                     PlayerInput var26 = var7;
                     var10001 = ((byte)((var26.right()) ? 1 : 0));
                     int var118 = var5;
                     byte var117 = var10001;
                     PacketQueueManager var116 = var56;
                     var69 = var116;
                     var70 = var117;
                     PacketQueueManager var57 = var116;
                     byte var58 = var117;
                     if (var118 != 0) {
                        break label64;
                     }

                     byte var120 = var58;
                     PacketQueueManager var119 = var57;
                     PacketQueueManager var59 = var119;
                     byte var60 = var120;
                     byte var122 = var60;
                     PacketQueueManager var121 = var59;
                     var68 = var121;
                     PacketQueueManager var61 = var121;
                     if (var122 == 0) {
                        PacketQueueManager var123 = var61;
                        PacketQueueManager var62 = var123;
                        PlayerInput var29 = var7;
                        var10001 = ((byte)((var29.jump()) ? 1 : 0));
                        int var126 = var5;
                        byte var125 = var10001;
                        PacketQueueManager var124 = var62;
                        var69 = var124;
                        var70 = var125;
                        PacketQueueManager var63 = var124;
                        byte var64 = var125;
                        if (var126 != 0) {
                           break label64;
                        }

                        byte var128 = var64;
                        PacketQueueManager var127 = var63;
                        PacketQueueManager var65 = var127;
                        byte var66 = var128;
                        byte var130 = var66;
                        PacketQueueManager var129 = var65;
                        PacketQueueManager var71 = var129;
                        PacketQueueManager var67 = var129;
                        if (var130 == 0) {
                           var73 = 0;
                           var72 = var71;
                           break label65;
                        }

                        PacketQueueManager var131 = var67;
                        var68 = var131;
                     }
                  }
               }
            }

            var70 = 1;
            var69 = var68;
         }

         byte var133 = var70;
         PacketQueueManager var132 = var69;
         var72 = var132;
         var73 = var133;
      }

      var72.g = dev.prestige.recovery.SourceSupport.asBoolean(var73);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      synchronized (this) {
         ArrayDeque var6 = this.d;
         var6.clear();
         this.k = 0;
      }

      List var7 = this.e;
      var7.clear();
      this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.h = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
    public void a(TickEvent bD_C00632) {
      class RecoveryExecution {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[39];
      {
      recoveryLocals[0]=PacketQueueManager.this;
      recoveryLocals[1]=bD_C00632;
      }
      int recoveryPc=0, recoveryAt=0;
      boolean recoveryFinished;
      void run(Object recoveryMonitor){
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=11430288912473L; }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=132149365360161L; }
                  recoveryAt=3; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=5; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=6; { recoveryStack[2]=19744772063828L; }
                  recoveryAt=7; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=10; { recoveryStack[0]=dev.zprestige.prestige.api.eventbus.Event.bReturningInt(); }
                  recoveryAt=11; { recoveryLocals[8]=recoveryStack[0];  }
                  recoveryAt=14; { recoveryStack[0]=dev.zprestige.prestige.client.Prestige.w; }
                  recoveryAt=15; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=16; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=37; continue recoveryFlow;} recoveryPc=17; continue recoveryFlow; }
               }
               case 17 -> {
                  recoveryAt=17; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=26; continue recoveryFlow;} recoveryPc=18; continue recoveryFlow; }
               }
               case 18 -> {
                  recoveryAt=18; { recoveryPc=22; continue recoveryFlow; }
               }
               case 22 -> {
                  recoveryAt=22; { recoveryFinished=true;return; }
               }
               case 26 -> {
                  recoveryAt=26; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=27; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=28; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=102; continue recoveryFlow;} recoveryPc=29; continue recoveryFlow; }
               }
               case 29 -> {
                  recoveryAt=29; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).e; }
                  recoveryAt=30; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=31; { recoveryStack[0]=recoveryLocals[16];  }
                  recoveryAt=32; { recoveryStack[0]=((java.util.List)recoveryStack[0]); }
                  recoveryAt=33; { recoveryStack[0]=((java.util.List)recoveryStack[0]).isEmpty(); }
                  recoveryAt=34; { recoveryPc=37; continue recoveryFlow; }
               }
               case 37 -> {
                  recoveryAt=37; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=99; continue recoveryFlow;} recoveryPc=40; continue recoveryFlow; }
               }
               case 40 -> {
                  recoveryAt=40; { java.lang.invoke.MethodHandles.lookup().ensureInitialized(java.util.ArrayList.class); recoveryStack[0]=new Object(); }
                  recoveryAt=41; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=42; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=43; { recoveryStack[2]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[2]).e; }
                  recoveryAt=44; { Object recoveryMarker=recoveryStack[1]; Object recoveryConstructed=new java.util.ArrayList(((java.util.Collection)recoveryStack[2])); for(int recoveryIndex=0;recoveryIndex<recoveryStack.length;recoveryIndex++)if(recoveryStack[recoveryIndex]==recoveryMarker)recoveryStack[recoveryIndex]=recoveryConstructed; for(int recoveryIndex=0;recoveryIndex<recoveryLocals.length;recoveryIndex++)if(recoveryLocals[recoveryIndex]==recoveryMarker)recoveryLocals[recoveryIndex]=recoveryConstructed; }
                  recoveryAt=45; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=48; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=49; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).e; }
                  recoveryAt=50; { recoveryLocals[18]=recoveryStack[0];  }
                  recoveryAt=51; { recoveryStack[0]=recoveryLocals[18];  }
                  recoveryAt=52; { recoveryStack[0]=((java.util.List)recoveryStack[0]); }
                  recoveryAt=53; { ((java.util.List)recoveryStack[0]).clear(); }
                  recoveryAt=56; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=57; { recoveryLocals[19]=recoveryStack[0];  }
                  recoveryAt=58; { recoveryStack[0]=recoveryLocals[19];  }
                  recoveryAt=59; { recoveryStack[0]=((java.util.List)recoveryStack[0]); }
                  recoveryAt=60; { recoveryStack[0]=((java.util.List)recoveryStack[0]).iterator(); }
                  recoveryAt=61; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryPc=64; continue recoveryFlow;
               }
               case 64 -> {
                  recoveryAt=64; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=65; { recoveryLocals[20]=recoveryStack[0];  }
                  recoveryAt=66; { recoveryStack[0]=recoveryLocals[20];  }
                  recoveryAt=67; { recoveryStack[0]=((java.util.Iterator)recoveryStack[0]); }
                  recoveryAt=68; { recoveryStack[0]=((java.util.Iterator)recoveryStack[0]).hasNext(); }
                  recoveryAt=69; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=99; continue recoveryFlow;} recoveryPc=70; continue recoveryFlow; }
               }
               case 70 -> {
                  recoveryAt=70; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=71; { recoveryLocals[21]=recoveryStack[0];  }
                  recoveryAt=72; { recoveryStack[0]=recoveryLocals[21];  }
                  recoveryAt=73; { recoveryStack[0]=((java.util.Iterator)recoveryStack[0]); }
                  recoveryAt=74; { recoveryStack[0]=((java.util.Iterator)recoveryStack[0]).next(); }
                  recoveryAt=75; { recoveryStack[0]=((java.lang.Runnable)recoveryStack[0]); }
                  recoveryAt=76; { recoveryLocals[11]=recoveryStack[0];  }
                  recoveryAt=79; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=80; { recoveryLocals[22]=recoveryStack[0];  }
                  recoveryAt=81; { recoveryStack[0]=recoveryLocals[22];  }
                  recoveryAt=82; { recoveryStack[0]=((java.lang.Runnable)recoveryStack[0]); }
                  recoveryAt=83; { ((java.lang.Runnable)recoveryStack[0]).run(); }
                  recoveryAt=86; { recoveryPc=94; continue recoveryFlow; }
               }
               case 90 -> {
                  recoveryPc=94; continue recoveryFlow;
               }
               case 94 -> {
                  recoveryAt=94; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=95; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=64; continue recoveryFlow;} recoveryPc=99; continue recoveryFlow; }
               }
               case 99 -> {
                  recoveryAt=99; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryPc=102; continue recoveryFlow;
               }
               case 102 -> {
                  recoveryAt=102; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=103; { recoveryLocals[10]=recoveryStack[1];  }
                  recoveryAt=104; { Object recoveryLock=recoveryStack[0]; synchronized(recoveryLock){recoveryPc=107;run(recoveryLock);}if(recoveryFinished)return;continue recoveryFlow; }
               }
               case 107 -> {
                  recoveryAt=107; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=108; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).d; }
                  recoveryAt=109; { recoveryLocals[23]=recoveryStack[0];  }
                  recoveryAt=110; { recoveryStack[0]=recoveryLocals[23];  }
                  recoveryAt=111; { recoveryStack[0]=((java.util.ArrayDeque)recoveryStack[0]); }
                  recoveryAt=112; { recoveryStack[0]=((java.util.ArrayDeque)recoveryStack[0]).isEmpty(); }
                  recoveryAt=113; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=114; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=119; continue recoveryFlow;} recoveryPc=115; continue recoveryFlow; }
               }
               case 115 -> {
                  recoveryAt=115; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=122; continue recoveryFlow;} recoveryPc=116; continue recoveryFlow; }
               }
               case 116 -> {
                  recoveryAt=116; { recoveryStack[0]=1; }
                  recoveryPc=119; continue recoveryFlow;
               }
               case 119 -> {
                  recoveryAt=119; { recoveryPc=125; continue recoveryFlow; }
               }
               case 122 -> {
                  recoveryAt=122; { recoveryStack[0]=0; }
                  recoveryPc=125; continue recoveryFlow;
               }
               case 125 -> {
                  recoveryAt=125; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=128; { recoveryStack[0]=recoveryLocals[8];  }
                  recoveryAt=129; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=147; continue recoveryFlow;} recoveryPc=130; continue recoveryFlow; }
               }
               case 130 -> {
                  recoveryAt=130; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=131; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=143; continue recoveryFlow;} recoveryPc=132; continue recoveryFlow; }
               }
               case 132 -> {
                  recoveryAt=132; { recoveryPc=136; continue recoveryFlow; }
               }
               case 136 -> {
                  recoveryAt=136; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=137; { recoveryStack[1]=0; }
                  recoveryAt=138; { ((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).k=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]); }
                  recoveryAt=139; { recoveryPc=143; continue recoveryFlow; }
               }
               case 143 -> {
                  recoveryAt=143; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=144; { if(recoveryStack[0]!=recoveryMonitor)throw new IllegalMonitorStateException();recoveryPc=147;return; }
               }
               case 147 -> {
                  recoveryAt=147; { recoveryPc=159; continue recoveryFlow; }
               }
               case 150 -> {
                  recoveryAt=150; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=151; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=152; { if(recoveryStack[0]!=recoveryMonitor)throw new IllegalMonitorStateException();recoveryPc=154;return; }
               }
               case 154 -> {
                  recoveryAt=154; { recoveryStack[0]=recoveryLocals[13];  }
                  recoveryAt=155; { throw (Throwable)recoveryStack[0]; }
               }
               case 159 -> {
                  recoveryAt=159; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=160; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=187; continue recoveryFlow;} recoveryPc=161; continue recoveryFlow; }
               }
               case 161 -> {
                  recoveryAt=161; { recoveryStack[0]=dev.zprestige.prestige.client.management.PacketQueueManager.b; }
                  recoveryAt=162; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=163; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=179; continue recoveryFlow;} recoveryPc=164; continue recoveryFlow; }
               }
               case 164 -> {
                  recoveryAt=164; { recoveryPc=167; continue recoveryFlow; }
               }
               case 167 -> {
                  recoveryAt=167; { recoveryLocals[27]=recoveryStack[0];  }
                  recoveryAt=168; { recoveryStack[0]=recoveryLocals[27];  }
                  recoveryAt=169; { recoveryStack[0]=((net.minecraft.client.MinecraftClient)recoveryStack[0]); }
                  recoveryAt=170; { recoveryStack[0]=((net.minecraft.client.MinecraftClient)recoveryStack[0]).player; }
                  recoveryAt=171; { if(recoveryStack[0]==null){recoveryPc=187; continue recoveryFlow;} recoveryPc=172; continue recoveryFlow; }
               }
               case 172 -> {
                  recoveryAt=172; { recoveryPc=175; continue recoveryFlow; }
               }
               case 175 -> {
                  recoveryAt=175; { recoveryStack[0]=dev.zprestige.prestige.client.management.PacketQueueManager.b; }
                  recoveryAt=176; { recoveryPc=179; continue recoveryFlow; }
               }
               case 179 -> {
                  recoveryAt=179; { recoveryLocals[30]=recoveryStack[0];  }
                  recoveryAt=180; { recoveryStack[0]=recoveryLocals[30];  }
                  recoveryAt=181; { recoveryStack[0]=((net.minecraft.client.MinecraftClient)recoveryStack[0]); }
                  recoveryAt=182; { recoveryStack[0]=((net.minecraft.client.MinecraftClient)recoveryStack[0]).world; }
                  recoveryAt=183; { if(recoveryStack[0]!=null){recoveryPc=191; continue recoveryFlow;} recoveryPc=187; continue recoveryFlow; }
               }
               case 187 -> {
                  recoveryAt=187; { recoveryFinished=true;return; }
               }
               case 191 -> {
                  recoveryAt=191; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=192; { recoveryStack[1]=30306940711437L; }
                  recoveryAt=193; { recoveryStack[2]=1; }
                  recoveryAt=194; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=195; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=196; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=198; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=199; { recoveryStack[4]=0; }
                  recoveryAt=200; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=201; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=202; { recoveryLocals[33]=recoveryStack[1];  }
                  recoveryAt=203; { recoveryLocals[32]=recoveryStack[0];  }
                  recoveryAt=204; { recoveryStack[0]=recoveryLocals[32];  }
                  recoveryAt=205; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]); }
                  recoveryAt=206; { recoveryStack[1]=recoveryLocals[33];  }
                  recoveryAt=207; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=208; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).dReturningBoolean(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=209; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=210; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=260; continue recoveryFlow;} recoveryPc=211; continue recoveryFlow; }
               }
               case 211 -> {
                  recoveryAt=211; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=240; continue recoveryFlow;} recoveryPc=212; continue recoveryFlow; }
               }
               case 212 -> {
                  recoveryAt=212; { recoveryPc=216; continue recoveryFlow; }
               }
               case 216 -> {
                  recoveryAt=216; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=217; { recoveryStack[1]=125710365996664L; }
                  recoveryAt=218; { recoveryStack[2]=1; }
                  recoveryAt=219; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=220; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=221; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=223; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=224; { recoveryStack[4]=0; }
                  recoveryAt=225; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=226; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=227; { recoveryLocals[36]=recoveryStack[1];  }
                  recoveryAt=228; { recoveryLocals[35]=recoveryStack[0];  }
                  recoveryAt=229; { recoveryStack[0]=recoveryLocals[35];  }
                  recoveryAt=230; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]); }
                  recoveryAt=231; { recoveryStack[1]=recoveryLocals[36];  }
                  recoveryAt=232; { recoveryStack[1]=((java.lang.Object[])recoveryStack[1]); }
                  recoveryAt=233; { ((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).bReturningVoid(((java.lang.Object[])recoveryStack[1])); }
                  recoveryAt=236; { recoveryFinished=true;return; }
               }
               case 240 -> {
                  recoveryAt=240; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=241; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=242; { recoveryLocals[10]=recoveryStack[1];  }
                  recoveryAt=243; { Object recoveryLock=recoveryStack[0]; synchronized(recoveryLock){recoveryPc=246;run(recoveryLock);}if(recoveryFinished)return;continue recoveryFlow; }
               }
               case 246 -> {
                  recoveryAt=246; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=247; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=248; { recoveryStack[1]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[1]).k; }
                  recoveryAt=249; { recoveryStack[2]=1; }
                  recoveryAt=250; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])+dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]); }
                  recoveryAt=251; { ((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).k=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]); }
                  recoveryAt=254; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=255; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=256; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=282; continue recoveryFlow;} recoveryPc=257; continue recoveryFlow; }
               }
               case 257 -> {
                  recoveryAt=257; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).k; }
                  recoveryPc=260; continue recoveryFlow;
               }
               case 260 -> {
                  recoveryAt=260; { recoveryStack[1]=5; }
                  recoveryAt=261; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])){recoveryPc=279; continue recoveryFlow;} recoveryPc=264; continue recoveryFlow; }
               }
               case 264 -> {
                  recoveryAt=264; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=265; { recoveryStack[0]=((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).d; }
                  recoveryAt=266; { recoveryLocals[38]=recoveryStack[0];  }
                  recoveryAt=267; { recoveryStack[0]=recoveryLocals[38];  }
                  recoveryAt=268; { recoveryStack[0]=((java.util.ArrayDeque)recoveryStack[0]); }
                  recoveryAt=269; { ((java.util.ArrayDeque)recoveryStack[0]).clear(); }
                  recoveryAt=272; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=273; { recoveryStack[1]=0; }
                  recoveryAt=274; { ((dev.zprestige.prestige.client.management.PacketQueueManager)recoveryStack[0]).k=dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]); }
                  recoveryAt=275; { recoveryPc=279; continue recoveryFlow; }
               }
               case 279 -> {
                  recoveryAt=279; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryPc=282; continue recoveryFlow;
               }
               case 282 -> {
                  recoveryAt=282; { if(recoveryStack[0]!=recoveryMonitor)throw new IllegalMonitorStateException();recoveryPc=284;return; }
               }
               case 284 -> {
                  recoveryAt=284; { recoveryPc=296; continue recoveryFlow; }
               }
               case 287 -> {
                  recoveryAt=287; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=288; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=289; { if(recoveryStack[0]!=recoveryMonitor)throw new IllegalMonitorStateException();recoveryPc=291;return; }
               }
               case 291 -> {
                  recoveryAt=291; { recoveryStack[0]=recoveryLocals[14];  }
                  recoveryAt=292; { throw (Throwable)recoveryStack[0]; }
               }
               case 296 -> {
                  recoveryAt=296; { recoveryFinished=true;return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=77 && recoveryAt<84 && recoveryFailure instanceof java.lang.Throwable){recoveryStack[0]=recoveryFailure; recoveryPc=90; continue recoveryFlow;}
            if(recoveryAt>=105 && recoveryAt<145){recoveryStack[0]=recoveryFailure; recoveryPc=150; continue recoveryFlow;}
            if(recoveryAt>=148 && recoveryAt<153){recoveryStack[0]=recoveryFailure; recoveryPc=150; continue recoveryFlow;}
            if(recoveryAt>=244 && recoveryAt<283){recoveryStack[0]=recoveryFailure; recoveryPc=287; continue recoveryFlow;}
            if(recoveryAt>=285 && recoveryAt<290){recoveryStack[0]=recoveryFailure; recoveryPc=287; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
      }
      }
      new RecoveryExecution().run(null);
   }

   private void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12107707230062L ^ var2;
      long var4 = var2 ^ 31437805481219L;
      int var10000 = Event.cReturningInt();
      PacketQueueManager var8 = this;
      synchronized (this){} 
      int var6 = var10000;
      boolean var23 = false ;

      ArrayList var7;
      try {
         label105: {
            var23 = true;
            PacketQueueManager var29 = this;
            if (var6 != 0) {
               ArrayDeque var10 = this.d;
               if (!var10.isEmpty()) {
                  var7 = new ArrayList(this.d);
                  ArrayDeque var13 = this.d;
                  var13.clear();
                  this.k = 0;
                  
                  var23 = false;
                  break label105;
               }

               var29 = var8;
            }

            
            return;
         }
      } finally {
         if (var23) {
            
         }
      }

      Iterator var26 = var7.iterator();

      while (true) {
         if (var26.hasNext()) {
            QueuedAction var9 = (QueuedAction)var26.next();
            var10000 = var9.b;
            int var10001 = var9.c;
            Object[] var10005 = new Object[]{null, null, SlotActionType.SWAP, var4};
            var10005[1] = var10001;
            var10005[0] = var10000;
            Object[] var17 = var10005;
            InventoryUtil.eReturningBoolean(var17);
            if (var6 != 0) {
               if (var6 == 0) {
                  break;
               }

               if (var9.d != null) {
                  Runnable var21 = var9.d;
                  List var20 = this.e;
                  var20.add(var21);
               }
            }

            if (var6 != 0) {
               continue;
            }
         }

         PacketQueueManager var31 = this;
         if (var6 != 0) {
            if (!this.h) {
               break;
            }

            var31 = this;
         }

         var31.j = dev.prestige.recovery.SourceSupport.asBoolean(1);
         break;
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 12107707230062L ^ var2;
      int var4 = Event.bReturningInt();
      int var11 = var4;
      byte var10 = ((byte)((this.f) ? 1 : 0));
      byte var6 = var10;
      byte var5 = var10;
      if (var11 == 0) {
         byte var12 = var5;
         if (var12 != 0) {
            return false;
         }

         byte var13 = ((byte)((this.g) ? 1 : 0));
         var6 = var13;
      }

      int var15 = var4;
      byte var14 = var6;
      byte var8 = var14;
      byte var7 = var14;
      if (var15 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var8);
      } else {
         byte var16 = var7;
         if (var16 == 0) {
            var8 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var8);
         } else {
            return false;
         }
      }
   }

   private static boolean lambda$cancelQueued$0(Object var0, QueuedAction var1) {
      Object var4 = var0;
      Object var3 = var1.a;
      byte var2;
      if (var3 == var4) {
         byte var5 = 1;
         var2 = var5;
      } else {
         var2 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var2);
   }

   static {

      aReturningVoid();
      Cipher var4;
      Cipher var10000 = var4 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var5 = 1; var5 < 8; var5++) {
         var10003[var5] = (byte)(47290263815877L << var5 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 2304794790772210882L;
      byte[] var8 = var4.doFinal(
         new byte[]{
            (byte)31L,
            (byte)8188L,
            (byte)2096198L,
            (byte)536626854L,
            (byte)137376474784L,
            (byte)35168377544741L,
            (byte)9003104651453948L,
            (byte)2304794790772210882L
         }
      );
      long var10 = (var8[0] & 255L) << 56
         | (var8[1] & 255L) << 48
         | (var8[2] & 255L) << 40
         | (var8[3] & 255L) << 32
         | (var8[4] & 255L) << 24
         | (var8[5] & 255L) << 16
         | (var8[6] & 255L) << 8
         | var8[7] & 255L;
      // long var0 = var10;
      c = (int)var0;
      a = dev.prestige.recovery.SourceSupport.asBoolean(1);
   
      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 1;
            yield var15;
         }
         case 1 -> {
            byte var16 = 20;
            yield var16;
         }
         case 2 -> {
            byte var17 = 51;
            yield var17;
         }
         case 3 -> {
            byte var18 = 63;
            yield var18;
         }
         case 4 -> {
            byte var19 = 60;
            yield var19;
         }
         case 5 -> {
            byte var20 = 17;
            yield var20;
         }
         case 6 -> {
            byte var21 = 41;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 18;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 35;
            yield var25;
         }
         case 11 -> {
            byte var26 = 36;
            yield var26;
         }
         case 12 -> {
            byte var27 = 54;
            yield var27;
         }
         case 13 -> {
            byte var28 = 9;
            yield var28;
         }
         case 14 -> {
            byte var29 = 45;
            yield var29;
         }
         case 15 -> {
            byte var30 = 33;
            yield var30;
         }
         case 16 -> {
            byte var31 = 46;
            yield var31;
         }
         case 17 -> {
            byte var32 = 11;
            yield var32;
         }
         case 18 -> {
            byte var33 = 37;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 40;
            yield var35;
         }
         case 21 -> {
            byte var36 = 19;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 2;
            yield var38;
         }
         case 24 -> {
            byte var39 = 55;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 34;
            yield var41;
         }
         case 27 -> {
            byte var42 = 0;
            yield var42;
         }
         case 28 -> {
            byte var43 = 25;
            yield var43;
         }
         case 29 -> {
            byte var44 = 32;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 28;
            yield var46;
         }
         case 32 -> {
            byte var47 = 21;
            yield var47;
         }
         case 33 -> {
            byte var48 = 56;
            yield var48;
         }
         case 34 -> {
            byte var49 = 58;
            yield var49;
         }
         case 35 -> {
            byte var50 = 22;
            yield var50;
         }
         case 36 -> {
            byte var51 = 47;
            yield var51;
         }
         case 37 -> {
            byte var52 = 44;
            yield var52;
         }
         case 38 -> {
            byte var53 = 61;
            yield var53;
         }
         case 39 -> {
            byte var54 = 7;
            yield var54;
         }
         case 40 -> {
            byte var55 = 50;
            yield var55;
         }
         case 41 -> {
            byte var56 = 15;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 13;
            yield var58;
         }
         case 44 -> {
            byte var59 = 10;
            yield var59;
         }
         case 45 -> {
            byte var60 = 4;
            yield var60;
         }
         case 46 -> {
            byte var61 = 43;
            yield var61;
         }
         case 47 -> {
            byte var62 = 57;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 49;
            yield var64;
         }
         case 50 -> {
            byte var65 = 42;
            yield var65;
         }
         case 51 -> {
            byte var66 = 29;
            yield var66;
         }
         case 52 -> {
            byte var67 = 62;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 38;
            yield var69;
         }
         case 55 -> {
            byte var70 = 39;
            yield var70;
         }
         case 56 -> {
            byte var71 = 14;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 24;
            yield var73;
         }
         case 59 -> {
            byte var74 = 16;
            yield var74;
         }
         case 60 -> {
            byte var75 = 3;
            yield var75;
         }
         case 61 -> {
            byte var76 = 59;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 6;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      m[0] = "<'&2\u000f]*'#h\u001cJ=l n\u0010^,+7y[L\u001d";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "|\u0000\u0010A\u0001\u0017j\u0000\u0015\u001b\u0012\u0000}K\u0016\u001d\u001e\u0014l\f\u0001\nU\u0005N";
      m[3] = "]_/}\u0005hVP>2\u007flEQ.}IhR";
      m[4] = "`O9,i\\~G#c\u0006[xO6\t\"X\u007fK";
      m[5] = "'[\u0012\u001b(=,T\u0003TI3'_\u0007\u000e";
      m[6] = boolean.class;
      n[6] = "java/lang/Boolean";
      m[7] = "=Q6?TEHq=0E\n)\u007f6;AP]";
      m[8] = "}a(\t;6}a?U79g*?K7,`[o\u0016f";
      m[9] = "?v\u001eU\t\u001a?v\t\t\u0005\u0015%=\t\u0017\u0005\u0000\"L\\HR";
      m[10] = "yS\u001a\u0010:dyS\rL6kc\u0018\rR6~diX\ro";
      m[11] = "M@\u0016FUfM@\u0001\u001aYiW\u000b\u0001\u0004Y|PzU\\\u000e";
      m[12] = "^<(fNAH<-<]V_w.:QBN09-\u001aRV0;&@\u001fj+;;@X]<";
      m[13] = "SX\u0016PpmSX\u0001\f|bI\u0013\u0001\u0012|wNbSI,7";
      m[14] = ",5\u000e\f&j:5\u000bV5}-~\bP9i<9\u001fGry'";
      m[15] = "1\u0019p1IgD9{>X(%7p5\\rQ";
      m[16] = "PQ\u000f`<+NY\u0015/^7ID";
      m[17] = void.class;
      n[17] = "java/lang/Void";
      m[18] = "ESu\u0010w\u00070s~\u001ffHQ}u\u0014b\u0012%";
      m[19] = "\u001b*3.:2\u0005\")a]3\u00149$;{5";
      m[20] = "QuYE'NZzH\n[WUzNFeG";
      m[21] = ">:H$Y\u0000K\u001aC+HO*\u0014H L\u0015^";
      m[22] = "\u000e^\u0005\u0016n\u0017\u0018^\u0000L}\u0000\u000f\u0015\u0003Jq\u0014\u001eR\u0014]:\u0017";
      m[23] = "J:`\u0010b\u0002J:wLn\rPqwRn\u0018W\u0000%\u000e>S\u0011";
      m[24] = "h2Xa}kh2O=qdryO#qqu\b\u001ew$:\"4@.cqYe\u0014{)";
      m[25] = "/DZ\u001f\b\u001d/DMC\u0004\u00125\u000fM]\u0004\u00072~\u001c\tPE";
      m[26] = "\u001f\u001cj3i~\u001f\u001c}oeq\u0005W}qed\u0002&,%0/";
      m[27] = "mW\u0014u\u0005u{W\u0011/\u0016bl\u001c\u0012)\u001av}[\u0005>QgE";
      m[28] = "yi\u001bbgu\fI\u0010mv:mG\u001bfr`\u0019";
      m[29] = "/P0p\u0010o1X*?Xo+R2xQtka4tZs&P2t";
      m[30] = "\u0012rv!Z\u0006B1vq;\fD`\u0010%C\u0002Trl%P\u001b\u0018\f,/B\tH~v'X\b(";
      m[31] = "{~]Jq&%}\u000f\u001f\t0A&\u001e\u0018r#15PAy\\}u\u0015Ki.'}\u000fJ\t";
      m[32] = "\u00109\u0006wvB@z\u0006'\u0017ZK5\rHePGw\u0002%{\u001fLG";
      m[33] = "Y[ok\u00158K\\g3,oQUt\r\u0017=\b\u000b\ff\u001d}ZP~<\u0015g[0";
      m[34] = ";%j&,F2il\u0019!(\"ez))E<*q\u0019";
      m[35] = "CD~7z4\u0015\u0006u-\u0004=\u001fU\u007f*SjA\u0006\"F:9@R#4}k\u001eA";
      m[36] = "\u0010h)\u0002&O@+)RGGN{&GGG\u0011(r_7J\u0014|\u007f=";
      m[37] = "\rmw\fP1\nv7H.*\u001b`}\u001fR,\u001d\rk\u000fW']5uI\u001f&g";
      m[38] = "q\u0004OZK\u0001xHIeGohD_UN\u0002v\u000bTe";
      m[39] = "b5T:\"Zy=Jg]Mc1Q0\n\u001a8m\u0005e]Ck=S#$Xc#\u000e";
      m[40] = "D\u0003\u000f$DI[\u0002\u001a%%VHB\u0006:Id\u001c\u0004]c\u00183EW\u0007;ZJ^_\u0019f%";
      m[41] = "p8e\u0015\\*n~-\u0014ftq1`y]j{=b\u0005]ybq\u001c";
      m[42] = "|JbAS\u000f*\bi[-\u0006 [c\\zQ~\f;0\u001dU#Gd\\Q\tx[";
      m[43] = "X`\u0006p8AKq\b+UXHj8~n\u001c\bnHskH\u0005\f";
      m[44] = ",F\u001c`+F,_Ea[\\\u001cOO|jOp\u0012G#&";
      m[45] = "\t\u001a/w\u0019\u0005\u0017\\gv#]\f\u0018\u0010vSAe_gbO]\u0017\u0005oxN=";
      m[46] = "\u0011~:\u0007\"Z\u0003y2_\u001b\r\u0019p!a _C$Y\n*\u001f\u0012u+P\"\u0005\u0013\u0015";
      m[47] = "X\u00184Pr%\u0006\u001bf\u0005\n6b\u0018oZ6a\u0013\u0019<^0_XHb\u00014.Y\u001bf\u0007\n";
      m[48] = "_I\u0011?I\u000fXRQ{7\u0014Nd\u0004=K\u00045\u0015P<[\u0015GOX&Zu";
      m[49] = "@6\u0019\u0002y\u0015G-YF\u0007\u0004N;\u0000\u0002\u0007\u0004\u0011hT\u001aw\t\u0014<Yx";
      m[50] = "uE\tA:=gB\u0001\u0019\u0003j}K\u0012'88$\u0016jL2xvN\u0018\u0016:bw.";
      m[51] = "C\u001ar\u0016T]\u001d\u0019 C,MyB1DWX\tQ\u007f\u001d\\'\u0012\u001b}FNW\u001f\u001e)K,";
      m[52] = "GJ>=\u00124\\B `m#FN;7:t\u001d\u0012ofm-NB9$\u00146F\\d";
      m[53] = "Y3j}\n/K4b%3xQ=q\u001b\b*\bb\tp\u0002jZ8{*\np[X";
      m[54] = "L&\u001e?N\u0004\u00157\u001fz TK.\\\u0016\u001b\u0006\u0017z$.K\\\u001dr\u0018<LTEK";
      m[55] = "J7\u0015X-9M,U\u001cS*L;e\u0019+$\\)\u0019\u00198=\u0010WY\u0013*/@%\u0003\u001b0. ";
      m[56] = "QHa&?U\u0007\nj<A\\\rY`;\u0016\u000bR\u0004;W~\fV\ri5x\\\u0013\u0005";
      m[57] = ">s\u0014D\u0010 n0\u0014\u0014q9ih\u0015\u0005\u001c\u0002j\r\u0011G\u000b<~4J\u0016\u0011\u007f\u00041C\u0002\u001d#vkK\u0018\u001cC";
      m[58] = "6\u001crB\u001fG`^yXaEf\u001cwT\rw2P'\u000e] 7Qn_\u0001RmYt^a";
      m[59] = "4ZtsH54C-r8:\u0004\r|vT%vWtlU";
      m[60] = "a\u001d\\i)ei\u0017H~S71\u001aIo\u0004foF\u0014\u0003b3!\u001dW?j95\n";
      m[61] = "|rn{8!z\"={Gt\u0015{sy<feh= 7\u0019)(x*'ks b+G";
      m[62] = ":\u0012e0I*(\u0015mhp}2\u001c~VK/k@\u0006=Ao9\u0019tgIu8y";
      m[63] = "K|-X8c\u0016tr\u0014Af)t?V:pYgq\u000f1\u000fB-sT#\u007fO('YA";
      m[64] = "5\u001cV\u0016\t\u000be_VFh\tt/UQ\u0014\u0019\u000f^\u0001P\u0004\b}\u0004\tJ\u0005h";
      m[65] = "\u0013cL;)\u001b_?\u0017'J\u0012N\"N-& \u001e`\u0014vJK\u0012'B*8\u0011\u001a=CJ";
      m[66] = "HtK\u001fkb\u0016w\u0019J\u0013tr,\bMhg\u0002?F\u0014c\u0018\u001c%\u0010\twu\u001d6\u001bC\u0013";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(377153407634660L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(377153407634660L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(377153407634660L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 68;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 236;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 114;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 228;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 102;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 68;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 236;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 114;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bV_C0099",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bV" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(Object var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/bV_C0099",
                     "lambda$cancelQueued$0",
                     "(Ljava/lang/Object;Ldev/zprestige/prestige/bW_C0101;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/bW_C0101;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Object)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
