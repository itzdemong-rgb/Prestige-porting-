package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.BotDetectionEvent;
import dev.zprestige.prestige.api.events.PlayerValidationEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.WorldResetEvent;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public class PlayerValidationTracker implements MinecraftAccess {
   private final Set a;
   private final Map c;
   private static final long d = 135367222807581L;
   private static final Object[] e = new Object[40];
   private static final String[] f = new String[40];
   private static volatile MethodHandle bindingCache1;

   public PlayerValidationTracker(long var1) {
      super();
      var1 = 135367222807581L ^ var1;
      long var3 = var1 ^ 82596897518790L;

      this.a = new HashSet();
      this.c = new IdentityHashMap();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(TickEvent var1) {
      int var10000 = Event.cReturningInt();
      Map var5 = this.c;
      var5.clear();
      int var4 = var10000;
      Set var6 = this.a;
      boolean var16 = var6.isEmpty();
      int var13 = var4;
      boolean var12 = var16;
      boolean var10 = var12;
      if (var13 != 0) {
         boolean var14 = var10;
         if (!var14) {
            Set var17 = this.a;
            Predicate var9 = invokeBinding1();
            Set var8 = var17;
            boolean var15 = var8.removeIf(var9);
         }
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      Set var4 = this.a;
      var4.clear();
   }

   public void aReturningVoid(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 135367222807581L ^ var3;
      PlayerEntity var6 = var2;
      Set var5 = this.a;
      var5.add(var6);
   }

   public Set aReturningSet(Object[] var1) {
      return this.a;
   }

   public boolean aReturningBoolean(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 135367222807581L ^ var3;
      long var5 = var3 ^ 37346909680792L;
      int var7 = Event.bReturningInt();
      int var28 = var7;
      Entity var27 = var2;
      Object var24 = var27;
      Entity var23 = var27;
      if (var28 == 0) {
         MinecraftClient var10 = b;
         ClientPlayerEntity var30 = var10.player;
         Entity var29 = var23;
         if (var29 == var30) {
            return false;
         }

         Entity var14 = var2;
         Map var13 = this.c;
         var24 = var13.get(var14);
      }

      Boolean var8 = (Boolean)var24;
      int var32 = var7;
      Boolean var31 = var8;
      Boolean var26 = var31;
      Boolean var25 = var31;
      if (var32 == 0) {
         Boolean var33 = var25;
         if (var33 == null) {
            Object[] var18 = new Object[]{var2, var5};
            PlayerValidationTracker var17 = this;
            boolean var9 = var17.bReturningBoolean(var18);
            Map var10000 = this.c;
            boolean var19 = var9;
            Boolean var22 = var19;
            Entity var21 = var2;
            Map var20 = var10000;
            var20.put(var21, var22);
            return var9;
         }

         var26 = var8;
      }

      Boolean var16 = var26;
      return var16;
   }

   private boolean bReturningBoolean(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 135367222807581L ^ var2;
      long var5 = var2 ^ 22659859611865L;
      long var7 = var2 ^ 95426828417304L;
      int var9 = Event.cReturningInt();
      byte var10000 = ((byte)((var4 instanceof PlayerEntity) ? 1 : 0));
      int var47 = var9;
      byte var46 = var10000;
      byte var32 = var46;
      byte var31 = var46;
      if (var47 != 0) {
         byte var48 = var31;
         if (var48 == 0) {
            return true;
         }

         EventBus var71 = Prestige.b;
         Object[] var13 = new Object[]{BotDetectionEvent.class, var5};
         EventBus var12 = var71;
         var32 = ((byte)((var12.bReturningBoolean(var13)) ? 1 : 0));
      }

      int var50 = var9;
      byte var49 = var32;
      byte var34 = var49;
      byte var33 = var49;
      if (var50 != 0) {
         byte var51 = var33;
         if (var51 == 0) {
            return true;
         }

         BotDetectionEvent var72 = new BotDetectionEvent();
         Object[] var17 = new Object[]{var7};
         BotDetectionEvent var16 = var72;
         var34 = ((byte)((var16.bReturningBoolean(var17)) ? 1 : 0));
      }

      int var53 = var9;
      byte var52 = var34;
      byte var36 = var52;
      byte var35 = var52;
      if (var53 != 0) {
         byte var54 = var35;
         if (var54 == 0) {
            return true;
         }

         EventBus var73 = Prestige.b;
         Object[] var21 = new Object[]{PlayerValidationEvent.class, var5};
         EventBus var20 = var73;
         var36 = ((byte)((var20.bReturningBoolean(var21)) ? 1 : 0));
      }

      byte var40;
      int var56 = var9;
      byte var55 = var36;
      var40 = var55;
      byte var37 = var55;
      label65:
      if (var56 != 0) {
         byte var57 = var37;
         if (var57 != 0) {
            PlayerValidationEvent var74 = new PlayerValidationEvent((PlayerEntity)var4);
            Object[] var24 = new Object[]{var7};
            PlayerValidationEvent var23 = var74;
            var10000 = ((byte)((var23.bReturningBoolean(var24)) ? 1 : 0));
            int var59 = var9;
            byte var58 = var10000;
            var40 = var58;
            byte var38 = var58;
            if (var59 == 0) {
               break label65;
            }

            byte var60 = var38;
            byte var39 = var60;
            byte var61 = var39;
            if (var61 != 0) {
               return false;
            }
         }

         Entity var28 = var4;
         Set var27 = this.a;
         var40 = ((byte)((var27.contains(var28)) ? 1 : 0));
      }

      int var63 = var9;
      byte var62 = var40;
      byte var42 = var62;
      byte var41 = var62;
      if (var63 != 0) {
         byte var64 = var41;
         if (var64 == 0) {
            return false;
         }

         Entity var30 = var4;
         byte var65 = ((byte)((var30.isAlive()) ? 1 : 0));
         var42 = var65;
      }

      int var67 = var9;
      byte var66 = var42;
      byte var44 = var66;
      byte var43 = var66;
      if (var67 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var44);
      } else {
         byte var68 = var43;
         if (var68 != 0) {
            var44 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var44);
         } else {
            return false;
         }
      }
   }

   private static boolean lambda$onTick$0(Entity var0) {
      int var3 = Event.cReturningInt();
      Entity var4 = var0;
      byte var10000 = ((byte)((var4.isAlive()) ? 1 : 0));
      int var9 = var3;
      byte var8 = var10000;
      byte var6 = var8;
      byte var5 = var8;
      if (var9 != 0) {
         byte var10 = var5;
         if (var10 != 0) {
            return false;
         }

         var6 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var6);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = f[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = e[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 43;
            yield var15;
         }
         case 1 -> {
            byte var16 = 59;
            yield var16;
         }
         case 2 -> {
            byte var17 = 63;
            yield var17;
         }
         case 3 -> {
            byte var18 = 45;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 38;
            yield var23;
         }
         case 9 -> {
            byte var24 = 33;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 8;
            yield var26;
         }
         case 12 -> {
            byte var27 = 18;
            yield var27;
         }
         case 13 -> {
            byte var28 = 20;
            yield var28;
         }
         case 14 -> {
            byte var29 = 4;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 14;
            yield var31;
         }
         case 17 -> {
            byte var32 = 46;
            yield var32;
         }
         case 18 -> {
            byte var33 = 26;
            yield var33;
         }
         case 19 -> {
            byte var34 = 28;
            yield var34;
         }
         case 20 -> {
            byte var35 = 36;
            yield var35;
         }
         case 21 -> {
            byte var36 = 61;
            yield var36;
         }
         case 22 -> {
            byte var37 = 35;
            yield var37;
         }
         case 23 -> {
            byte var38 = 27;
            yield var38;
         }
         case 24 -> {
            byte var39 = 53;
            yield var39;
         }
         case 25 -> {
            byte var40 = 34;
            yield var40;
         }
         case 26 -> {
            byte var41 = 13;
            yield var41;
         }
         case 27 -> {
            byte var42 = 16;
            yield var42;
         }
         case 28 -> {
            byte var43 = 48;
            yield var43;
         }
         case 29 -> {
            byte var44 = 3;
            yield var44;
         }
         case 30 -> {
            byte var45 = 47;
            yield var45;
         }
         case 31 -> {
            byte var46 = 7;
            yield var46;
         }
         case 32 -> {
            byte var47 = 0;
            yield var47;
         }
         case 33 -> {
            byte var48 = 58;
            yield var48;
         }
         case 34 -> {
            byte var49 = 17;
            yield var49;
         }
         case 35 -> {
            byte var50 = 52;
            yield var50;
         }
         case 36 -> {
            byte var51 = 49;
            yield var51;
         }
         case 37 -> {
            byte var52 = 19;
            yield var52;
         }
         case 38 -> {
            byte var53 = 10;
            yield var53;
         }
         case 39 -> {
            byte var54 = 50;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 51;
            yield var56;
         }
         case 42 -> {
            byte var57 = 40;
            yield var57;
         }
         case 43 -> {
            byte var58 = 9;
            yield var58;
         }
         case 44 -> {
            byte var59 = 37;
            yield var59;
         }
         case 45 -> {
            byte var60 = 24;
            yield var60;
         }
         case 46 -> {
            byte var61 = 21;
            yield var61;
         }
         case 47 -> {
            byte var62 = 42;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 62;
            yield var64;
         }
         case 50 -> {
            byte var65 = 11;
            yield var65;
         }
         case 51 -> {
            byte var66 = 5;
            yield var66;
         }
         case 52 -> {
            byte var67 = 55;
            yield var67;
         }
         case 53 -> {
            byte var68 = 29;
            yield var68;
         }
         case 54 -> {
            byte var69 = 56;
            yield var69;
         }
         case 55 -> {
            byte var70 = 54;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 30;
            yield var72;
         }
         case 58 -> {
            byte var73 = 12;
            yield var73;
         }
         case 59 -> {
            byte var74 = 44;
            yield var74;
         }
         case 60 -> {
            byte var75 = 60;
            yield var75;
         }
         case 61 -> {
            byte var76 = 22;
            yield var76;
         }
         case 62 -> {
            byte var77 = 57;
            yield var77;
         }
         default -> 6;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            f[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      e[0] = "UD:`\tJKL /tZK";
      e[1] = "\u00018{I>(\u001f0a\u0006v(\u0005:yA\u007f3E\t\u007fMt4\b8yM";
      e[2] = boolean.class;
      f[2] = "java/lang/Boolean";
      e[3] = "n'\u0011\t5Kx'\u0014S&\\ol\u0017U*H~+\u0000BaZl";
      e[4] = "BS5\u001e\u0005)I\\$Qf$\\Q+:S&MB7\u0016D+";
      e[5] = "T\b\u0017\u0017b)B\b\u0012Mq>UC\u0011K}*D\u0004\u0006\\68u";
      e[6] = int.class;
      f[6] = "java/lang/Integer";
      e[7] = "\u0005D g&-\u001bL:(E9\u001f";
      e[8] = void.class;
      f[8] = "java/lang/Void";
      e[9] = "#\u0003e-/\u00135\u0003`w<\u0004\"Hcq0\u00103\u000ftf{\u0000+\u000fvm!M\u0017\u0014vp!\n \u0003";
      e[10] = "3-1q)a%-4+:v2f7-6b#! :}s\u001b";
      e[11] = "ZI\u001c\u007fbv/i\u0017ps9Ng\u001c{wc:";
      e[12] = "iLZ\u0015\u0015\u000fbCKZt\u0001iHO\u0000";
      e[13] = "S{'\u0005LwXt6J tVv4\u0005\f";
      e[14] = "=\u000b-dsX=\u000b:8\u007fW'@:&\u007fB 1j{.";
      e[15] = "\u001e\u0005S\u0007\u000bx\u001e\u0005D[\u0007w\u0004NDE\u0007b\u0003?\u0010\u001dP";
      e[16] = "5Q\u000e\b\u0004G@q\u0005\u0007\u0015\b!\u007f\u000e\f\u0011RU";
      e[17] = "i;8\u001a\u00063i;/F\n<sp/X\n)t\u0001}\u0006Rm";
      e[18] = "h6{5\u0005}\u001d\u0016p:\u00142|\u0018{1\u0010h\b";
      e[19] = "Z9k]:\u0000/\u0019`R+ON\u0017kY/\u0015:";
      e[20] = "\u0012\u0001/z9\u001b]BiqZ\u0011,\u001fqh8K\u0017\u0014a)={\u0015\u001d|z'AW\n*~Z";
      e[21] = "\u000fjX7%\u001a\u0006=\u00077\u001dTWe\u001a;ZD>8\t:tW\u0004z\u001elp*\u000fjX7%\u001a\u0006=\u00077\u001d";
      e[22] = "M5\u000fzm_I,\b/\u0015Ovt\u0002$w\u0014G$\u0003tm%";
      e[23] = "!S*\u0000F\u001b?\u0006\"<P\u0014%\f2Qk\u0017@\u00174@\u0015\u0006 \u00051\\*@.\u0007%A\u0010\u00029Q!<";
      e[24] = "{og=\u00143+hp9p?A6p0\b*z`n+HV{}f/\fm-c}op";
      e[25] = "7(/q$b31($\\s\fi\"/>)=9#\u007f$\u0018";
      e[26] = "\nH\u007f`\"v\u0003\u001f `\u001a,\\D$ls eJ$|wF\u0002M,hg|@Zzl\u001a";
      e[27] = "@gy2/)Sc0*\u00136F&)+\u007f\u0004\u0016jqq\u0013jE6 1)(R`$L";
      e[28] = "\u0000GO\nG \u0004^H_?0;V@A]j\u0000]P\u0000XZ\u0002TMSB`@C\u001bW?";
      e[29] = "J\u0002:J\u0001\u0017TW2v\u0004\u0019G:l\u000b\u0004\u0017YSgK\u001c\t+\u00032\u001a\u0004\b\u0011A%L\u0000u";
      e[30] = ",&\u0019f}fx-\td\u0018x|7i-e~s9\u0000&%fmKY`quc\"R ik\u0011";
      e[31] = "\u00025@1Z\u0012\u001c`H\r]\u0017\u0005qOlP\u000bc=[dT\u0002\n6\u001b|JpZcJdKJ\u0018t\u001c`6";
      e[32] = "gI9\u0013X\t3\u001b&\u0012c\u001bo\u001b=\u00074L1Lek\n\u0018e\u0015(R[\ba\u0016";
      e[33] = "\u0011\u0005Le5FA\u0002[aQI+\nKt3\u0013\u0010\u0001[56#\u0012\bFf,\u0019P\u001f\u0010bQ";
      e[34] = "rCU\u0006\u000e#&HE\u0004k9+CL\u0007ko0@YF\u0010/qJ_}";
      e[35] = "\u00048F#\u000fz\u001amN\u001f\u0002c(eXc\u0012\u0018\\nLv\u001e\"\u001ey\u001arc";
      e[36] = " z\u0015RzHdhO\n\u0019Z\u001e+^SpS~d\u001d\u0015{";
      e[37] = "$k\u0007IuKk(AB\u0016B\u001auY[t\u001b!~I\u001aq+'fV\\-Pg'\\Z\u0016";
      e[38] = "\u001e\u00140\u0000\u0016\u0016\u0000A8<\u0011\u0010\u0012E,<G\u000b\u0011PmG\u0007J\u001bVV";
      e[39] = "rc;\u0014ku&h+\u0016\u000e|2rK_sm-|\"T3u3\u000e{\u0012gf=gpR\u007fxO>6\u0006lv&5v\u001er\u0004";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = e[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            e[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  e[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(897940084336373L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  e[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(897940084336373L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        e[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(897940084336373L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 82;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 242;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 225;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 220;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 119;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 233;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 82;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 242;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 225;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/af_C0014",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/af" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/af_C0014", "lambda$onTick$0", "(Lnet/minecraft/entity/Entity;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
