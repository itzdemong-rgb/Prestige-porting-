package dev.zprestige.prestige.client.management;

public final class QueuedAction {
   public final Object a;
   public final int b;
   public final int c;
   public final Runnable d;

   public QueuedAction(Object var1, int var2, int var3, Runnable var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }
}
