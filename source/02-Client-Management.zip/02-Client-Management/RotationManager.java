package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.accessor.PlayerInteractItemC2SPacketAccessor;
import dev.zprestige.prestige.api.events.MovementResetEvent;
import dev.zprestige.prestige.api.events.MovementRotationEvent;
import dev.zprestige.prestige.api.events.MovementVectorEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.modules.Freecam;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.ToIntFunction;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.math.Vec3d;

public class RotationManager implements MinecraftAccess {
   private final CopyOnWriteArrayList a;
   private Rotation c;
   private Rotation d;
   private Rotation e;
   private static float f = 300.0F;
   private static float g = 90.0F;
   private Rotation h;
   private boolean i;
   private Object j;
   private Rotation k;
   private Object l;
   private final List m;
   private static final long n = 3643125559719L;
   private static final Object[] o = new Object[108];
   private static final String[] p = new String[108];
   private static volatile MethodHandle bindingCache1;

   @EventListener
   public void a(TickEvent var1) {
      int var6;
      label185: {
         RotationManager var78;
         label188: {
            Rotation var77;
            label189: {
               RotationManager var75;
               label182: {
                  label181: {
                     long var10001 = 50359750987525L ^ 19504697665381L;
                     int var10000 = Event.cReturningInt();
                     this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
                     var6 = var10000;
                     List var12 = this.m;
                     boolean var196 = var12.isEmpty();
                     int var114 = var6;
                     boolean var113 = var196;
                     boolean var70 = var113;
                     boolean var67 = var113;
                     if (var114 != 0) {
                        boolean var115 = var67;
                        if (!var115) {
                           ArrayList var7 = new ArrayList(this.m);
                           List var14 = this.m;
                           var14.clear();
                           ArrayList var15 = var7;
                           Iterator var8 = var15.iterator();

                           int var118;
                           do {
                              Iterator var16 = var8;
                              boolean var116 = var16.hasNext();
                              if (!var116) {
                                 break;
                              }

                              Iterator var17 = var8;
                              Runnable var9 = (Runnable)var17.next();

                              label174: {
                                 try {
                                    Runnable var18 = var9;
                                    var18.run();
                                 } catch (Throwable var188) {
                                    break label174;
                                 }

                                 int var117 = var6;
                                 if (var117 == 0) {
                                    break label181;
                                 }
                              }

                              var118 = var6;
                           } while (var118 != 0);
                        }

                        int var120 = var6;
                        RotationManager var119 = this;
                        var75 = var119;
                        RotationManager var69 = var119;
                        if (var120 == 0) {
                           break label182;
                        }

                        CopyOnWriteArrayList var19 = var69.a;
                        boolean var121 = var19.isEmpty();
                        var70 = var121;
                     }

                     boolean var122 = var70;
                     if (var122) {
                        int var124 = var6;
                        Rotation var123 = this.c;
                        var77 = var123;
                        Rotation var71 = var123;
                        if (var124 == 0) {
                           break label189;
                        }

                        Rotation var125 = var71;
                        Rotation var72 = var125;
                        Rotation var126 = var72;
                        if (var126 == null) {
                           int var128 = var6;
                           Rotation var127 = this.h;
                           var77 = var127;
                           Rotation var73 = var127;
                           if (var128 == 0) {
                              break label189;
                           }

                           Rotation var129 = var73;
                           Rotation var74 = var129;
                           Rotation var130 = var74;
                           if (var130 == null) {
                              this.d = null;
                              this.e = null;
                              return;
                           }
                        }
                     }
                  }

                  var75 = this;
               }

               int var132 = var6;
               RotationManager var131 = var75;
               var78 = var131;
               RotationManager var76 = var131;
               if (var132 == 0) {
                  break label188;
               }

               Rotation var133 = var76.d;
               var77 = var133;
            }

            Rotation var134 = var77;
            if (var134 != null) {
               break label185;
            }

            var78 = this;
         }

         MinecraftClient var27 = b;
         ClientPlayerEntity var28 = var27.player;
         float var10003 = var28.getYaw();
         MinecraftClient var29 = b;
         ClientPlayerEntity var30 = var29.player;
         var78.d = new Rotation(var10003, var30.getPitch());
      }

      byte var189 = 0;
      Rotation var135 = this.c;
      byte var79;
      if (var135 != null) {
         byte var136 = 1;
         var79 = var136;
      } else {
         var79 = 0;
      }

      byte var190 = var79;
      CopyOnWriteArrayList var32 = this.a;
      Iterator var191 = var32.iterator();

      RotationManager var96;
      label144: {
         label143: {
            Rotation var95;
            while (true) {
               Iterator var33 = var191;
               boolean var137 = var33.hasNext();
               if (var137) {
                  label138: {
                     Iterator var34 = var191;
                     RotationSource var10 = (RotationSource)var34.next();
                     Object[] var36 = new Object[]{66451759360096L};
                     RotationSource var35 = var10;
                     Rotation var11 = var35.aReturningdx_C0210(var36);
                     int var138 = var6;
                     if (var138 != 0) {
                        int var140 = var6;
                        Rotation var139 = var11;
                        var95 = var139;
                        Rotation var80 = var139;
                        if (var140 == 0) {
                           break;
                        }

                        Rotation var141 = var80;
                        Rotation var81 = var141;
                        Rotation var142 = var81;
                        if (var142 == null) {
                           break label138;
                        }

                        this.c = var11;
                     }

                     var189 = 1;
                  }

                  int var143 = var6;
                  if (var143 != 0) {
                     continue;
                  }
               }

               int var145 = var6;
               byte var144 = var189;
               byte var90 = var144;
               byte var82 = var144;
               if (var145 != 0) {
                  byte var146 = var82;
                  label127:
                  if (var146 == 0) {
                     int var148 = var6;
                     Rotation var147 = this.c;
                     Rotation var85 = var147;
                     Rotation var83 = var147;
                     if (var148 != 0) {
                        Rotation var149 = var83;
                        Rotation var84 = var149;
                        Rotation var150 = var84;
                        if (var150 == null) {
                           break label127;
                        }

                        Rotation var151 = this.c;
                        var85 = var151;
                     }

                     label120: {
                        Object[] var45 = new Object[0];
                        Rotation var44 = var85;
                        float var197 = var44.aReturningFloat(var45);
                        MinecraftClient var46 = b;
                        ClientPlayerEntity var47 = var46.player;
                        float var48 = var197 - var47.getYaw();
                        float var192 = Math.abs(var48);
                        int var154 = var6;
                        float var153 = f;
                        float var152 = var192;
                        float var88 = var152;
                        float var89 = var153;
                        float var86 = var152;
                        float var87 = var153;
                        if (var154 != 0) {
                           float var202;
                           int var155 = (var202 = var86 - var87) == 0.0F ? 0 : (var202 < 0.0F ? -1 : 1);
                           if (var155 <= 0) {
                              break label120;
                           }

                           Rotation var198 = this.c;
                           Object[] var51 = new Object[0];
                           Rotation var50 = var198;
                           var197 = var50.aReturningFloat(var51);
                           float var200 = f;
                           Rotation var10002 = this.c;
                           Object[] var53 = new Object[0];
                           Rotation var52 = var10002;
                           float var201 = var52.aReturningFloat(var53);
                           MinecraftClient var54 = b;
                           ClientPlayerEntity var55 = var54.player;
                           float var56 = var201 - var55.getYaw();
                           float var157 = var200 * Math.signum(var56);
                           float var156 = var197;
                           var88 = var156;
                           var89 = var157;
                        }

                        float var194 = var88 - var89;
                        Rotation var10004 = this.c;
                        Object[] var59 = new Object[0];
                        Rotation var58 = var10004;
                        this.c = new Rotation(var194, var58.bReturningFloat(var59));
                        int var158 = var6;
                        if (var158 != 0) {
                           break label127;
                        }
                     }

                     this.c = null;
                  }

                  var90 = var190;
               }

               byte var159 = var90;
               if (var159 != 0) {
                  int var161 = var6;
                  Rotation var160 = this.c;
                  var95 = var160;
                  Rotation var91 = var160;
                  if (var161 == 0) {
                     break;
                  }

                  Rotation var162 = var91;
                  Rotation var92 = var162;
                  Rotation var163 = var92;
                  if (var163 == null) {
                     MinecraftClient var63 = b;
                     ClientPlayerEntity var64 = var63.player;
                     float var193 = var64.getYaw() + (float)(Math.random() * 0.06 - 0.03);
                     MinecraftClient var65 = b;
                     ClientPlayerEntity var66 = var65.player;
                     float var195 = var66.getPitch() + (float)(Math.random() * 0.06 - 0.03);
                     this.h = new Rotation(var193, var195);
                     int var164 = var6;
                     if (var164 != 0) {
                        break label143;
                     }
                  }
               }

               int var166 = var6;
               RotationManager var165 = this;
               var96 = var165;
               RotationManager var93 = var165;
               if (var166 == 0) {
                  break label144;
               }

               RotationManager var167 = var93;
               RotationManager var94 = var167;
               Rotation var168 = var94.c;
               var95 = var168;
               break;
            }

            Rotation var169 = var95;
            if (var169 != null) {
               this.h = null;
            }
         }

         var96 = this;
      }

      RotationManager var111;
      Rotation var112;
      label98: {
         int var172 = var6;
         Rotation var171 = this.c;
         RotationManager var170 = var96;
         RotationManager var102 = var170;
         Rotation var103 = var171;
         RotationManager var97 = var170;
         Rotation var98 = var171;
         if (var172 != 0) {
            Rotation var174 = var98;
            RotationManager var173 = var97;
            RotationManager var101 = var173;
            RotationManager var99 = var173;
            if (var174 != null) {
               RotationManager var175 = var99;
               RotationManager var100 = var175;
               Rotation var177 = this.c;
               RotationManager var176 = var100;
               var111 = var176;
               var112 = var177;
               break label98;
            }

            var103 = this.h;
            var102 = var101;
         }

         int var180 = var6;
         Rotation var179 = var103;
         RotationManager var178 = var102;
         RotationManager var108 = var178;
         Rotation var109 = var179;
         RotationManager var104 = var178;
         Rotation var105 = var179;
         if (var180 != 0) {
            Rotation var182 = var105;
            RotationManager var181 = var104;
            RotationManager var110 = var181;
            RotationManager var106 = var181;
            if (var182 != null) {
               RotationManager var183 = var106;
               RotationManager var107 = var183;
               Rotation var185 = this.h;
               RotationManager var184 = var107;
               var111 = var184;
               var112 = var185;
            } else {
               var112 = null;
               var111 = var110;
            }
         } else {
            Rotation var187 = var109;
            RotationManager var186 = var108;
            var111 = var186;
            var112 = var187;
         }
      }

      var111.d = var112;
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      RotationManager var32;
      label26: {
         label25: {
            int var4 = Event.bReturningInt();
            int var34 = var4;
            Rotation var33 = this.c;
            Rotation var31 = var33;
            Rotation var28 = var33;
            if (var34 == 0) {
               Rotation var35 = var28;
               if (var35 != null) {
                  Rotation var10001 = this.c;
                  Object[] var7 = new Object[0];
                  Rotation var6 = var10001;
                  Object[] var9 = new Object[]{var6.aReturningFloat(var7)};
                  PlayerUpdateEvent var8 = var1;
                  var8.bReturningVoid(var9);
                  var10001 = this.c;
                  Object[] var11 = new Object[0];
                  Rotation var10 = var10001;
                  Object[] var13 = new Object[]{var10.bReturningFloat(var11)};
                  PlayerUpdateEvent var12 = var1;
                  var12.cReturningVoid(var13);
                  int var36 = var4;
                  if (var36 == 0) {
                     break label25;
                  }
               }

               int var38 = var4;
               RotationManager var37 = this;
               var32 = var37;
               RotationManager var29 = var37;
               if (var38 != 0) {
                  break label26;
               }

               RotationManager var39 = var29;
               RotationManager var30 = var39;
               Rotation var40 = var30.h;
               var31 = var40;
            }

            Rotation var41 = var31;
            if (var41 != null) {
               Rotation var43 = this.h;
               Object[] var18 = new Object[0];
               Rotation var17 = var43;
               Object[] var20 = new Object[]{var17.aReturningFloat(var18)};
               PlayerUpdateEvent var19 = var1;
               var19.bReturningVoid(var20);
               var43 = this.h;
               Object[] var22 = new Object[0];
               Rotation var21 = var43;
               Object[] var24 = new Object[]{var21.bReturningFloat(var22)};
               PlayerUpdateEvent var23 = var1;
               var23.cReturningVoid(var24);
               this.h = null;
            }
         }

         var32 = this;
      }

      var32.e = this.c;
      Object[] var27 = new Object[0];
      PlayerUpdateEvent var26 = var1;
      var26.aReturningVoid(var27);
   }

   @EventListener
   public void a(MovementVectorEvent var1) {
      int var4 = Event.bReturningInt();
      int var13 = var4;
      if (var13 == 0) {
         Rotation var14 = this.c;
         if (var14 != null) {
            Rotation var10001 = this.c;
            Object[] var7 = new Object[0];
            Rotation var6 = var10001;
            Object[] var9 = new Object[]{var6.aReturningFloat(var7)};
            MovementVectorEvent var8 = var1;
            var8.bReturningVoid(var9);
         }

         Object[] var12 = new Object[0];
         MovementVectorEvent var11 = var1;
         var11.aReturningVoid(var12);
      }
   }

   @EventListener
   public void a(MovementRotationEvent var1) {
      int var4 = Event.bReturningInt();
      int var13 = var4;
      if (var13 == 0) {
         Rotation var14 = this.c;
         if (var14 != null) {
            Rotation var10001 = this.c;
            Object[] var7 = new Object[0];
            Rotation var6 = var10001;
            var1.a = var6.aReturningFloat(var7);
            var10001 = this.c;
            Object[] var9 = new Object[0];
            Rotation var8 = var10001;
            var1.b = var8.bReturningFloat(var9);
         }

         Object[] var12 = new Object[0];
         MovementRotationEvent var11 = var1;
         var11.aReturningVoid(var12);
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 69374253604780L ^ 7489306554323L;
      var10001 = 69374253604780L ^ 36696032222600L;
      var10001 = 69374253604780L ^ 91541701781505L;
      int var10000 = Event.cReturningInt();
      Object[] var14 = new Object[0];
      PacketSendEvent var13 = var1;
      Packet var12 = var13.aReturningVoid(var14);
      int var10 = var10000;
      int var34 = var10;
      Packet var33 = var12;
      Packet var30 = var33;
      Packet var29 = var33;
      if (var34 != 0) {
         boolean var35 = var29 instanceof PlayerInteractItemC2SPacket;
         if (!var35) {
            return;
         }

         Packet var36 = var12;
         var30 = var36;
      }

      PlayerInteractItemC2SPacket var11 = (PlayerInteractItemC2SPacket)var30;
      int var38 = var10;
      RotationManager var37 = this;
      RotationManager var32 = var37;
      RotationManager var31 = var37;
      if (var38 != 0) {
         Rotation var39 = var31.c;
         if (var39 == null) {
            return;
         }

         RotationManager var40 = this;
         var32 = var40;
      }

      Object[] var20 = new Object[]{119132815357869L};
      RotationManager var19 = var32;
      boolean var41 = var19.aReturningBoolean(var20);
      if (!var41) {
         PlayerInteractItemC2SPacketAccessor var42 = new PlayerInteractItemC2SPacketAccessor(var11);
         Rotation var45 = this.c;
         Object[] var22 = new Object[0];
         Rotation var21 = var45;
         float var46 = var21.aReturningFloat(var22);
         Object[] var10004 = new Object[]{null, 63599050158207L};
         var10004[0] = var46;
         Object[] var24 = var10004;
         PlayerInteractItemC2SPacketAccessor var23 = var42;
         var23.aReturningVoid(var24);
         Rotation var47 = this.c;
         Object[] var26 = new Object[0];
         Rotation var25 = var47;
         float var48 = var25.bReturningFloat(var26);
         var10004 = new Object[]{null, 33292544442916L};
         var10004[0] = var48;
         Object[] var28 = var10004;
         PlayerInteractItemC2SPacketAccessor var27 = var42;
         var27.bReturningVoid(var28);
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 3643125559719L ^ var2;
      long var4 = var2 ^ 126737380852750L;
      int var6 = Event.bReturningInt();
      MinecraftClient var7 = b;
      int var27 = var6;
      ClientPlayerEntity var26 = var7.player;
      ClientPlayerEntity var20 = var26;
      ClientPlayerEntity var19 = var26;
      if (var27 == 0) {
         ClientPlayerEntity var28 = var19;
         if (var28 == null) {
            return false;
         }

         MinecraftClient var10 = b;
         var20 = var10.player;
      }

      ClientPlayerEntity var11 = var20;
      ItemStack var12 = var11.getMainHandStack();
      Object[] var13 = new Object[]{var12.getItem(), var4};
      byte var10000 = ((byte)((bReturningBoolean(var13)) ? 1 : 0));
      int var30 = var6;
      byte var29 = var10000;
      byte var24 = var29;
      byte var21 = var29;
      if (var30 == 0) {
         byte var31 = var21;
         if (var31 == 0) {
            MinecraftClient var15 = b;
            ClientPlayerEntity var16 = var15.player;
            ItemStack var17 = var16.getOffHandStack();
            Object[] var18 = new Object[]{var17.getItem(), var4};
            var10000 = ((byte)((bReturningBoolean(var18)) ? 1 : 0));
            int var33 = var6;
            byte var32 = var10000;
            var24 = var32;
            byte var22 = var32;
            if (var33 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var24);
            }

            byte var34 = var22;
            byte var23 = var34;
            byte var35 = var23;
            if (var35 == 0) {
               return false;
            }
         }

         var24 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   private static boolean bReturningBoolean(Object[] var0) {
      Item var1 = (Item)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 3643125559719L ^ var2;
      int var4 = Event.cReturningInt();
      int var36 = var4;
      Item var35 = Items.ENDER_PEARL;
      Item var34 = var1;
      Item var7 = var34;
      Item var8 = var35;
      Item var5 = var34;
      Item var6 = var35;
      if (var36 != 0) {
         Item var38 = var6;
         Item var37 = var5;
         if (var37 == var38) {
            return true;
         }

         Item var40 = Items.SNOWBALL;
         Item var39 = var1;
         var7 = var39;
         var8 = var40;
      }

      int var43 = var4;
      Item var42 = var8;
      Item var41 = var7;
      Item var11 = var41;
      Item var12 = var42;
      Item var9 = var41;
      Item var10 = var42;
      if (var43 != 0) {
         Item var45 = var10;
         Item var44 = var9;
         if (var44 == var45) {
            return true;
         }

         Item var47 = Items.EGG;
         Item var46 = var1;
         var11 = var46;
         var12 = var47;
      }

      int var50 = var4;
      Item var49 = var12;
      Item var48 = var11;
      Item var15 = var48;
      Item var16 = var49;
      Item var13 = var48;
      Item var14 = var49;
      if (var50 != 0) {
         Item var52 = var14;
         Item var51 = var13;
         if (var51 == var52) {
            return true;
         }

         Item var54 = Items.EXPERIENCE_BOTTLE;
         Item var53 = var1;
         var15 = var53;
         var16 = var54;
      }

      int var57 = var4;
      Item var56 = var16;
      Item var55 = var15;
      Item var19 = var55;
      Item var20 = var56;
      Item var17 = var55;
      Item var18 = var56;
      if (var57 != 0) {
         Item var59 = var18;
         Item var58 = var17;
         if (var58 == var59) {
            return true;
         }

         Item var61 = Items.SPLASH_POTION;
         Item var60 = var1;
         var19 = var60;
         var20 = var61;
      }

      int var64 = var4;
      Item var63 = var20;
      Item var62 = var19;
      Item var23 = var62;
      Item var24 = var63;
      Item var21 = var62;
      Item var22 = var63;
      if (var64 != 0) {
         Item var66 = var22;
         Item var65 = var21;
         if (var65 == var66) {
            return true;
         }

         Item var68 = Items.LINGERING_POTION;
         Item var67 = var1;
         var23 = var67;
         var24 = var68;
      }

      int var71 = var4;
      Item var70 = var24;
      Item var69 = var23;
      Item var27 = var69;
      Item var28 = var70;
      Item var25 = var69;
      Item var26 = var70;
      if (var71 != 0) {
         Item var73 = var26;
         Item var72 = var25;
         if (var72 == var73) {
            return true;
         }

         Item var75 = Items.TRIDENT;
         Item var74 = var1;
         var27 = var74;
         var28 = var75;
      }

      int var78 = var4;
      Item var77 = var28;
      Item var76 = var27;
      Item var31 = var76;
      Item var32 = var77;
      Item var29 = var76;
      Item var30 = var77;
      if (var78 != 0) {
         Item var80 = var30;
         Item var79 = var29;
         if (var79 == var80) {
            return true;
         }

         Item var82 = Items.WIND_CHARGE;
         Item var81 = var1;
         var31 = var81;
         var32 = var82;
      }

      Item var84 = var32;
      Item var83 = var31;
      return var83 == var84;
   }

   public void aReturningVoid(Object[] var1) {
      Rotation var2 = (Rotation)var1[0];
      this.c = var2;
   }

   public Rotation aReturningdx_C0210(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      var3 = 3643125559719L ^ var3;
      long var5 = var3 ^ 28101391486062L;
      int var7 = Event.cReturningInt();
      int var20 = var7;
      Rotation var19 = this.d;
      Rotation var17 = var19;
      Rotation var16 = var19;
      Rotation var18;
      if (var20 != 0) {
         Rotation var21 = var16;
         if (var21 != null) {
            Rotation var22 = this.d;
            var18 = var22;
         } else {
            MinecraftClient var11 = b;
            ClientPlayerEntity var12 = var11.player;
            float var10002 = var12.getYaw();
            MinecraftClient var13 = b;
            ClientPlayerEntity var14 = var13.player;
            var18 = new Rotation(var10002, var14.getPitch());
         }
      } else {
         Rotation var23 = var17;
         var18 = var23;
      }

      Rotation var8 = var18;
      float var25 = g;
      Object[] var10005 = new Object[]{null, null, null, var5};
      var10005[2] = var25;
      var10005[1] = var2;
      var10005[0] = var8;
      Object[] var15 = var10005;
      return RotationUtil.cReturningdx_C0210(var15);
   }

   public Rotation bReturningdx_C0210(Object[] var1) {
      return this.d;
   }

   public Rotation cReturningdx_C0210(Object[] var1) {
      return this.c;
   }

   public synchronized boolean cReturningBoolean(Object[] var1) {
      Object var5 = var1[0];
      Rotation var2 = (Rotation)var1[1];
      long var3 = (Long)var1[2];
      var3 = 3643125559719L ^ var3;
      long var6 = var3 ^ 45298897778313L;
      int var8 = Event.cReturningInt();
      Object var39 = var5;
      if (var39 != null) {
         Rotation var40 = var2;
         if (var40 != null) {
            int var42 = var8;
            RotationManager var41 = this;
            Object var32 = var41;
            RotationManager var31 = var41;
            if (var42 != 0) {
               Object[] var12 = new Object[]{var6};
               RotationManager var11 = var31;
               boolean var43 = var11.eReturningBoolean(var12);
               if (!var43) {
                  Object[] var15 = new Object[0];
                  RotationManager var14 = this;
                  var14.cReturningVoid(var15);
                  return false;
               }

               var32 = this.l;
            }

            RotationManager var38;
            label49: {
               int var45 = var8;
               Object var44 = var32;
               Object var35 = var44;
               Object var33 = var44;
               if (var45 != 0) {
                  MinecraftClient var17 = b;
                  ClientWorld var47 = var17.world;
                  Object var46 = var33;
                  if (var46 != var47) {
                     Object[] var20 = new Object[0];
                     RotationManager var19 = this;
                     var19.cReturningVoid(var20);
                  }

                  int var49 = var8;
                  RotationManager var48 = this;
                  var38 = var48;
                  RotationManager var34 = var48;
                  if (var49 == 0) {
                     break label49;
                  }

                  Object var50 = var34.j;
                  var35 = var50;
               }

               Object var51 = var35;
               if (var51 != null) {
                  int var53 = var8;
                  RotationManager var52 = this;
                  var38 = var52;
                  RotationManager var36 = var52;
                  if (var53 == 0) {
                     break label49;
                  }

                  RotationManager var54 = var36;
                  RotationManager var37 = var54;
                  Object var56 = var5;
                  Object var55 = var37.j;
                  if (var55 != var56) {
                     return false;
                  }
               }

               this.j = var5;
               Object[] var27 = new Object[0];
               Rotation var26 = var2;
               float var10003 = var26.aReturningFloat(var27);
               Object[] var29 = new Object[0];
               Rotation var28 = var2;
               this.k = new Rotation(var10003, var28.bReturningFloat(var29));
               var38 = this;
            }

            MinecraftClient var30 = b;
            var38.l = var30.world;
            return true;
         }
      }

      return false;
   }

   public synchronized boolean dReturningBoolean(Object[] var1) {
      Object var4 = var1[0];
      long var2 = (Long)var1[1];
      var2 = 3643125559719L ^ var2;
      long var5 = var2 ^ 14864240371245L;
      int var7 = Event.bReturningInt();
      Object var31 = var4;
      if (var31 != null) {
         RotationManager var29;
         label60: {
            Object var28;
            label61: {
               label51: {
                  RotationManager var26;
                  label62: {
                     int var33 = var7;
                     Rotation var32 = this.k;
                     Object var23 = var32;
                     Rotation var20 = var32;
                     if (var33 == 0) {
                        Rotation var34 = var20;
                        Rotation var21 = var34;
                        Rotation var35 = var21;
                        if (var35 == null) {
                           return false;
                        }

                        int var37 = var7;
                        RotationManager var36 = this;
                        var26 = var36;
                        RotationManager var22 = var36;
                        if (var37 != 0) {
                           break label62;
                        }

                        Object var38 = var22.l;
                        var23 = var38;
                     }

                     MinecraftClient var12 = b;
                     ClientWorld var40 = var12.world;
                     Object var39 = var23;
                     if (var39 == var40) {
                        int var42 = var7;
                        RotationManager var41 = this;
                        var28 = var41;
                        RotationManager var24 = var41;
                        if (var42 != 0) {
                           break label61;
                        }

                        RotationManager var43 = var24;
                        RotationManager var25 = var43;
                        Object[] var15 = new Object[]{var5};
                        RotationManager var14 = var25;
                        boolean var44 = var14.eReturningBoolean(var15);
                        if (var44) {
                           break label51;
                        }
                     }

                     RotationManager var45 = this;
                     var26 = var45;
                  }

                  Object[] var19 = new Object[0];
                  RotationManager var18 = var26;
                  var18.cReturningVoid(var19);
               }

               int var47 = var7;
               RotationManager var46 = this;
               var29 = var46;
               RotationManager var27 = var46;
               if (var47 != 0) {
                  break label60;
               }

               Object var48 = var27.j;
               var28 = var48;
            }

            Object var50 = var4;
            Object var49 = var28;
            if (var49 != var50) {
               return false;
            }

            RotationManager var51 = this;
            var29 = var51;
         }

         Rotation var52 = var29.k;
         return var52 != null;
      } else {
         return false;
      }
   }

   public synchronized Rotation dReturningdx_C0210(Object[] var1) {
      RotationManager var29;
      label39: {
         label38: {
            RotationManager var28;
            label42: {
               long var2 = (Long)var1[0];
               var2 = 3643125559719L ^ var2;
               long var4 = var2 ^ 78861100892388L;
               int var6 = Event.cReturningInt();
               int var32 = var6;
               Rotation var31 = this.k;
               Object var25 = var31;
               Rotation var23 = var31;
               if (var32 != 0) {
                  Rotation var33 = var23;
                  if (var33 == null) {
                     return null;
                  }

                  int var35 = var6;
                  RotationManager var34 = this;
                  var28 = var34;
                  RotationManager var24 = var34;
                  if (var35 == 0) {
                     break label42;
                  }

                  Object var36 = var24.l;
                  var25 = var36;
               }

               MinecraftClient var10 = b;
               ClientWorld var38 = var10.world;
               Object var37 = var25;
               if (var37 == var38) {
                  int var40 = var6;
                  RotationManager var39 = this;
                  var29 = var39;
                  RotationManager var26 = var39;
                  if (var40 == 0) {
                     break label39;
                  }

                  RotationManager var41 = var26;
                  RotationManager var27 = var41;
                  Object[] var13 = new Object[]{var4};
                  RotationManager var12 = var27;
                  boolean var42 = var12.eReturningBoolean(var13);
                  if (var42) {
                     break label38;
                  }
               }

               RotationManager var43 = this;
               var28 = var43;
            }

            Object[] var17 = new Object[0];
            RotationManager var16 = var28;
            var16.cReturningVoid(var17);
         }

         var29 = this;
      }

      Rotation var44 = var29.k;
      Rotation var30;
      if (var44 == null) {
         Object var45 = null;
         var30 = (Rotation)var45;
      } else {
         Rotation var10002 = this.k;
         Object[] var20 = new Object[0];
         Rotation var19 = var10002;
         float var47 = var19.aReturningFloat(var20);
         Rotation var10003 = this.k;
         Object[] var22 = new Object[0];
         Rotation var21 = var10003;
         var30 = new Rotation(var47, var21.bReturningFloat(var22));
      }

      return var30;
   }

   public synchronized void bReturningVoid(Object[] var1) {
      RotationManager var16;
      label26: {
         Object var2 = var1[0];
         long var3 = (Long)var1[1];
         long var10000 = 3643125559719L ^ var3;
         int var5 = Event.cReturningInt();
         int var18 = var5;
         Object var17 = var2;
         Object var15 = var17;
         Object var12 = var17;
         if (var18 != 0) {
            Object var19 = var12;
            if (var19 == null) {
               return;
            }

            int var21 = var5;
            RotationManager var20 = this;
            var16 = var20;
            RotationManager var13 = var20;
            if (var21 == 0) {
               break label26;
            }

            RotationManager var22 = var13;
            RotationManager var14 = var22;
            Object var23 = var14.j;
            var15 = var23;
         }

         Object var25 = var2;
         Object var24 = var15;
         if (var24 != var25) {
            return;
         }

         RotationManager var26 = this;
         var16 = var26;
      }

      Object[] var11 = new Object[0];
      RotationManager var10 = var16;
      var10.cReturningVoid(var11);
   }

   public boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 3643125559719L ^ var2;
      int var4 = Event.cReturningInt();
      int var49 = var4;
      MinecraftClient var48 = b;
      MinecraftClient var32 = var48;
      MinecraftClient var31 = var48;
      if (var49 != 0) {
         MinecraftClient var7 = var31;
         ClientPlayerEntity var50 = var7.player;
         if (var50 == null) {
            return false;
         }

         MinecraftClient var51 = b;
         var32 = var51;
      }

      int var53 = var4;
      MinecraftClient var52 = var32;
      MinecraftClient var34 = var52;
      MinecraftClient var33 = var52;
      if (var53 != 0) {
         MinecraftClient var10 = var33;
         ClientWorld var54 = var10.world;
         if (var54 == null) {
            return false;
         }

         MinecraftClient var55 = b;
         var34 = var55;
      }

      MinecraftClient var13 = var34;
      ClientPlayerEntity var14 = var13.player;
      boolean var80 = var14.hasVehicle();
      int var57 = var4;
      boolean var56 = var80;
      boolean var36 = var56;
      boolean var35 = var56;
      if (var57 == 0) {
         return var36;
      }

      boolean var58 = var35;
      if (!var58) {
         MinecraftClient var16 = b;
         Entity var81 = var16.getCameraEntity();
         MinecraftClient var17 = b;
         ClientPlayerEntity var60 = var17.player;
         Entity var59 = var81;
         if (var59 == var60) {
            int var63 = var4;
            ModuleManager var62 = Prestige.d;
            ModuleManager var38 = var62;
            ModuleManager var37 = var62;
            if (var63 != 0) {
               ModuleManager var64 = var37;
               if (var64 == null) {
                  return true;
               }

               var38 = Prestige.d;
            }

            ModuleManager var21 = var38;
            List var82 = var21.aReturningVoid();
            int var66 = var4;
            List var65 = var82;
            List var40 = var65;
            List var39 = var65;
            if (var66 != 0) {
               List var67 = var39;
               if (var67 == null) {
                  return true;
               }

               ModuleManager var24 = Prestige.d;
               var40 = var24.aReturningVoid();
            }

            List var25 = var40;
            Iterator var5 = var25.iterator();

            byte var47;
            while (true) {
               Iterator var26 = var5;
               boolean var68 = var26.hasNext();
               if (var68) {
                  Iterator var27 = var5;
                  Module var6 = (Module)var27.next();
                  byte var83 = ((byte)((var6 instanceof Freecam) ? 1 : 0));
                  int var70 = var4;
                  byte var69 = var83;
                  var47 = var69;
                  byte var41 = var69;
                  if (var70 == 0) {
                     break;
                  }

                  label96: {
                     int var72 = var4;
                     byte var71 = var41;
                     byte var44 = var71;
                     byte var42 = var71;
                     if (var72 != 0) {
                        byte var73 = var42;
                        byte var43 = var73;
                        byte var74 = var43;
                        if (var74 == 0) {
                           break label96;
                        }

                        Module var30 = var6;
                        byte var75 = ((byte)((var30.aReturningBoolean()) ? 1 : 0));
                        var44 = var75;
                     }

                     int var77 = var4;
                     byte var76 = var44;
                     byte var46 = var76;
                     byte var45 = var76;
                     if (var77 == 0) {
                        return dev.prestige.recovery.SourceSupport.asBoolean(var46);
                     }

                     byte var78 = var45;
                     if (var78 != 0) {
                        return false;
                     }
                  }

                  int var79 = var4;
                  if (var79 != 0) {
                     continue;
                  }
               }

               var47 = 1;
               break;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var47);
         }
      }

      return false;
   }

   @EventListener
   public synchronized void a(WorldResetEvent var1) {
      Object[] var5 = new Object[0];
      RotationManager var4 = this;
      var4.cReturningVoid(var5);
   }

   @EventListener
   public synchronized void a(MovementResetEvent var1) {
      RotationManager var16;
      label26: {
         int var4 = Event.cReturningInt();
         int var18 = var4;
         Object var17 = this.l;
         Object var15 = var17;
         Object var12 = var17;
         if (var18 != 0) {
            Object var19 = var12;
            if (var19 == null) {
               return;
            }

            int var21 = var4;
            RotationManager var20 = this;
            var16 = var20;
            RotationManager var13 = var20;
            if (var21 == 0) {
               break label26;
            }

            RotationManager var22 = var13;
            RotationManager var14 = var22;
            Object var23 = var14.l;
            var15 = var23;
         }

         MinecraftClient var8 = b;
         ClientWorld var25 = var8.world;
         Object var24 = var15;
         if (var24 == var25) {
            return;
         }

         RotationManager var26 = this;
         var16 = var26;
      }

      Object[] var11 = new Object[0];
      RotationManager var10 = var16;
      var10.cReturningVoid(var11);
   }

   private void cReturningVoid(Object[] var1) {
      this.j = null;
      this.k = null;
      this.l = null;
   }

   public RotationManager(long var1) {
      super();
      var1 = 3643125559719L ^ var1;
      long var3 = var1 ^ 79528149046671L;

      this.a = new CopyOnWriteArrayList();
      this.h = null;
      this.m = new CopyOnWriteArrayList();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   public void dReturningVoid(Object[] var1) {
      RotationSource var4 = (RotationSource)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 3643125559719L ^ var2;
      int var5 = Event.cReturningInt();
      int var17 = var5;
      CopyOnWriteArrayList var16 = this.a;
      CopyOnWriteArrayList var15 = var16;
      CopyOnWriteArrayList var14 = var16;
      if (var17 != 0) {
         RotationSource var7 = var4;
         CopyOnWriteArrayList var6 = var14;
         boolean var18 = var6.addIfAbsent(var7);
         if (!var18) {
            return;
         }

         var15 = this.a;
      }

      ToIntFunction var10 = invokeBinding1();
      Comparator var11 = Comparator.comparingInt(var10);
      Comparator var13 = var11.reversed();
      CopyOnWriteArrayList var12 = var15;
      var12.sort(var13);
   }

   public void eReturningVoid(Object[] var1) {
      RotationSource var4 = (RotationSource)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 3643125559719L ^ var2;
      RotationSource var6 = var4;
      CopyOnWriteArrayList var5 = this.a;
      var5.remove(var6);
   }

   public boolean fReturningBoolean(Object[] var1) {
      return this.i;
   }

   public void fReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      this.i = var2;
   }

   public void gReturningVoid(Object[] var1) {
      Runnable var2 = (Runnable)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 3643125559719L ^ var3;
      Runnable var7 = var2;
      if (var7 != null) {
         Runnable var6 = var2;
         List var5 = this.m;
         var5.add(var6);
      }
   }

   public void hReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 3643125559719L ^ var3;
      List var7 = this.m;
      RotationTask var6 = new RotationTask(this, var2);
      List var5 = var7;
      var5.add(var6);
   }

   static {
      aReturningVoid();
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 26;
            yield var15;
         }
         case 1 -> {
            byte var16 = 34;
            yield var16;
         }
         case 2 -> {
            byte var17 = 2;
            yield var17;
         }
         case 3 -> {
            byte var18 = 3;
            yield var18;
         }
         case 4 -> {
            byte var19 = 55;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 12;
            yield var21;
         }
         case 7 -> {
            byte var22 = 41;
            yield var22;
         }
         case 8 -> {
            byte var23 = 37;
            yield var23;
         }
         case 9 -> {
            byte var24 = 38;
            yield var24;
         }
         case 10 -> {
            byte var25 = 50;
            yield var25;
         }
         case 11 -> {
            byte var26 = 15;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 32;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 46;
            yield var31;
         }
         case 17 -> {
            byte var32 = 5;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 6;
            yield var34;
         }
         case 20 -> {
            byte var35 = 11;
            yield var35;
         }
         case 21 -> {
            byte var36 = 25;
            yield var36;
         }
         case 22 -> {
            byte var37 = 31;
            yield var37;
         }
         case 23 -> {
            byte var38 = 0;
            yield var38;
         }
         case 24 -> {
            byte var39 = 58;
            yield var39;
         }
         case 25 -> {
            byte var40 = 39;
            yield var40;
         }
         case 26 -> {
            byte var41 = 63;
            yield var41;
         }
         case 27 -> {
            byte var42 = 20;
            yield var42;
         }
         case 28 -> {
            byte var43 = 60;
            yield var43;
         }
         case 29 -> {
            byte var44 = 36;
            yield var44;
         }
         case 30 -> {
            byte var45 = 44;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 42;
            yield var47;
         }
         case 33 -> {
            byte var48 = 49;
            yield var48;
         }
         case 34 -> {
            byte var49 = 27;
            yield var49;
         }
         case 35 -> {
            byte var50 = 59;
            yield var50;
         }
         case 36 -> {
            byte var51 = 22;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 54;
            yield var53;
         }
         case 39 -> {
            byte var54 = 10;
            yield var54;
         }
         case 40 -> {
            byte var55 = 56;
            yield var55;
         }
         case 41 -> {
            byte var56 = 7;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 21;
            yield var58;
         }
         case 44 -> {
            byte var59 = 45;
            yield var59;
         }
         case 45 -> {
            byte var60 = 13;
            yield var60;
         }
         case 46 -> {
            byte var61 = 29;
            yield var61;
         }
         case 47 -> {
            byte var62 = 16;
            yield var62;
         }
         case 48 -> {
            byte var63 = 35;
            yield var63;
         }
         case 49 -> {
            byte var64 = 28;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 57;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 62;
            yield var68;
         }
         case 54 -> {
            byte var69 = 43;
            yield var69;
         }
         case 55 -> {
            byte var70 = 14;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 61;
            yield var72;
         }
         case 58 -> {
            byte var73 = 48;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 24;
            yield var75;
         }
         case 61 -> {
            byte var76 = 8;
            yield var76;
         }
         case 62 -> {
            byte var77 = 30;
            yield var77;
         }
         default -> 4;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      o[0] = "I?pOQ\u000e_?u\u0015B\u0019Htv\u0013N\rY3a\u0004\u0005\u001aT";
      o[1] = "{\u007fj\u0017mRpp{X\u0017Vcqk\u0017!Rt";
      o[2] = ";\u001ax\"\\\u0001-\u001a}xO\u0016:Q~~C\u0002+\u0016ii\b\u0010\u001a";
      o[3] = int.class;
      p[3] = "java/lang/Integer";
      o[4] = "(\u0004A{d']$Jtuh<*A\u007fq2H";
      o[5] = void.class;
      p[5] = "java/lang/Void";
      o[6] = "\u0002,CJD-\u001c$Y\u0005&1\u001b9";
      o[7] = ":\u007f8|pP$w\"3\u0017Q5l/i1W";
      o[8] = "\u001fD\u0005`\u0010#\tD\u0000:\u00034\u001e\u000f\u0003<\u000f \u000fH\u0014+D7*";
      o[9] = boolean.class;
      p[9] = "java/lang/Boolean";
      o[10] = "Yf\tW|&Yf\u001e\u000bp)C-\u001e\u0015p<D\\NH!";
      o[11] = "1\u0001m\u001cd-1\u0001z@h\"+Jz^h7,;/\u00011";
      o[12] = ">?L|~a>?[ rn$t[>r{#\u0005\t`*?";
      o[13] = "+<'X\u000e\u0003=<\"\u0002\u001d\u0014*w!\u0004\u0011\u0000;06\u0013Z\u0010\b";
      o[14] = "sSY\\p\u0000x\\H\u0013\u0011\u000esWLI";
      o[15] = "4\\EK@;4\\R\u0017L4.\u0017R\tL!)f\u0006Q\u001b";
      o[16] = "\u000f\u000b\b\rn6\u0019\u000b\rW}!\u000e@\u000eQq5\u001f\u0007\u0019F:%\u0007\u0007\u001bM`h;\u001c\u001bP`/\f\u000b";
      o[17] = "#4-\u0001W\u001054([D\u0007\"\u007f+]H\u001338<J\u0003\u0002&";
      o[18] = "aS;Rd\\\u0014s0]u\u0013u};VqI\u0001";
      o[19] = "\"[\\\u0000FOW{W\u000fW\u00006u\\\u0004SZB";
      o[20] = ";S.{Fc-S+!Ut:\u0018('Y`+_?0\u0012w'";
      o[21] = "tV\u0014M[{\u0001v\u001fBJ4`x\u0014INn\u0014";
      o[22] = float.class;
      p[22] = "java/lang/Float";
      o[23] = "\u0019acT5YlAh[$\u0016\rOcP Ly";
      o[24] = "\u000f,\u001dDh\u0017z\f\u0016KyX\u001b\u0002\u001d@}\u0002o";
      o[25] = "t\u0005e1k\u0010j\r\u007f~\u0006\ns\u0014r\"$\u0011q\u0016";
      o[26] = "RG6\u0004\u0010\fLO,KX\fVE4\fQ\u0017\u0016r/,P\r~S.\u0006J\u0010WH";
      o[27] = "\bm\u001ddZ.\u0016e\u0007+\u00174\fo\u001ew\u0006>\fxEF\u001b+\u001bC\u0005R\u00062\u0016i*w\u0006:\u001b@\u0002v\u0000";
      o[28] = "nJ:x\u007fvxJ?\"lao\u0001<$`u~F+3+U";
      o[29] = "\u0012\r\u0013\u0010Z.g-\u0018\u001fKa\u0006#\u0013\u0014O;r";
      o[30] = "p^\u0013[<\f\u0005~\u0018T-Cdp\u0013_)\u0019\u0010";
      o[31] = "S#5\u00111\u0000E#0K\"\u0017Rh3M.\u0003C/$Ze\u0012R";
      o[32] = "\u0002R\u0019\u0013A`wr\u0012\u001cP/\u0016|\u0019\u0017Tub";
      o[33] = "f\u0001\u0010\u0019n!f\u0001\u0007Eb.|J\u0007[b;{;V\u0002:~";
      o[34] = "u/\u000e:3.\u0000\u000f\u00055\"aa\u0001\u000e>&;\u0015";
      o[35] = "f$DM|Ep$A\u0017oRgoB\u0011cFv(U\u0006(Wa";
      o[36] = "U\u000e\u0010\u0001<R .\u001b\u000e-\u001dA \u0010\u0005)G5";
      o[37] = "(&hy0J(&\u007f%<E2m\u007f;<P5\u001c-om\u0011";
      o[38] = "L*KC6\u0016L*\\\u001f:\u0019Va\\\u0001:\fQ\u0010\u000eZbM";
      o[39] = "G]+\\Z5Q].\u0006I\"F\u0016-\u0000E6WQ:\u0017\u000e!a";
      o[40] = "FK\u000e#Y\u00123k\u0005,H]Re\u000e'L\u0007&";
      o[41] = "r\r2+<R\u0007-9$-\u001df#2/)G\u0012";
      o[42] = "~\u0011e\u001cr\"~\u0011r@~-dZr^~8c+ \u0005&r";
      o[43] = "y]tP(\u0010\f}\u007f_9_mstT=\u0005\u0019";
      o[44] = "P{\u0014X`DF{\u0011\u0002sSQ0\u0012\u0004\u007fG@w\u0005\u00134Pu";
      o[45] = "\u00171o'h!b\u0011d(yn\u0003\u001fo#}4w";
      o[46] = "tC.=\")\u007fL?rA$jJ";
      o[47] = "\t+-[u3\u0002$<\u0014\t*\r$:X7:";
      o[48] = double.class;
      p[48] = "java/lang/Double";
      o[49] = "Y`?iI\u0006O`:3Z\u0011X+95V\u0005Il.\"\u001d\u0014q";
      o[50] = "Lm7(PO9M<'A\u0000XC7,EZ,";
      o[51] = "<8\u0014's;/.H0K)A8Os;&#$E.0@,+E~)?0.\u0013yK";
      o[52] = "\u001c\u0011\u001fh/o\u001fSDb_c\u0004F\u0018o\b=_\u001bC\u0003&r\u001dELie7\u0005\u001b";
      o[53] = "\f\u0016O2\u0002\t\\H\u001b>9\u001c\b\u000f\u001eiU.^MB3\u0005y\u000b\u0003\u0017~\u0004\u0012\u000b\u0010\u0000~9";
      o[54] = "zbk\u0002T\u0012+e4rQpac`\u0002]\u0012}i=\t;Ny</\tF\u0015l?ar";
      o[55] = "\"\u001bQly6!LX?\u0000'b\u0011@o|!d|\u0006tm+eMJ::#\u001e";
      o[56] = "f9nOLtklrX6|\u0004.'\u0014Fsf2-IM\u0015?\"n^Upy#y[6";
      o[57] = "Ab\u0011:ThB J0$dY5\u0016=s:\u0005dMQ]u@6B;\u001e0Xh";
      o[58] = "F\u0006dZT3\t\u0003mR9'w[fKS7\u0007X1B\u0000N";
      o[59] = "y0\n0\u000by)n^<0l})[k\\^+k\u00071\r\t~%R|\rb~6E|0";
      o[60] = "5=\"\nXSysu\u0002#\u0004d?3g\u0012\u0019x0+\u001cZR`1O";
      o[61] = "\u0017t$\u0015P/\u001a!8\u0002*$ucmNZ(\u0017\u007fg\u0013QNNo$\u0004I+\bn3\u0001*";
      o[62] = "i\n\f%3/=\u000f\u001bzZvP\u0001Q+*y2\u001d[v!\u001fk\r\u0018a9z-\f\u000fdZ";
      o[63] = "~?Y'D]yp\u001aq|[ku&t\f[q3Mt\u001fLq\u000eHj\u0015B<eHy\u0002B\u0001";
      o[64] = "i\"uNvr=z/\u001a\u001at\u00031|Ra\"h'*Kf";
      o[65] = "\u001bxjRH-J\u007f5\"NO\u0000yaRA-\u001cs<Y'q\u0018&.YZ*\r%`\"";
      o[66] = "MtW9c\u0010N#^j\u001a\u000b\u0015~U)\u001a[\u000faG0\u007f\u001d\u000evBS";
      o[67] = "\u0011\u0014M7NN\u001bTT?'\u0014zY\u000ehW\u0019\u0018E\u00045\\\u007fAUG\"D\u001a\u0007TP''";
      o[68] = "?\u0002;*[N<@` +B'U<-|\u001c\u007f\u0005`ARS>Vh+\u0011\u0016&\b";
      o[69] = "/\u00169\u0018-R!\u001b5DFRq\u0010mM\u0011\u0005.M6!yBm\u0000wO?\fn\u001f";
      o[70] = "b\u0012\\q=\u0018rHX6\u0004\u001cg\u0002JJd\u001bk\tN:;\t:A6qz\u0015{\u001bS7{\u0002~x";
      o[71] = "r`p6\u0011Pb:tq(F|f[caEkg|q(\u001ek{eiSV cd\r\u0016EttapMPw:\u001a";
      o[72] = "\b>>e`\u001fX`ji[\n\f'o>78_c0h[\u0013\\)md*T\n??Y";
      o[73] = "n\u001cX\u0001i2xJA\u0006U0\u001f^\u001bK%?}B\u0011\u0016.Y$RR\u00016<bSE\u0004U";
      o[74] = "\nHY5Z[\b@TmkCmQ\u0005<\u001bO\u000fM\u000fa\u0010)V]Lv\bL\u0010\\[sk";
      o[75] = "dR\u00103TMc\u001dSelXr\u0005\u0003i\t\"k\u000e\u0010e\u001cNg\u0019R?l";
      o[76] = "w'FN\t\f'y\u0012B2\u0019s>\u0017\u0015^+#}IO2Bt&\t\tO\u0019a%Gr";
      o[77] = "mJ~PyM}\u0010z\u0017@Stmq\u0013<C\u000f\u001e~\u000f>IrEk\fp2";
      o[78] = "\u001812W\u001b*\u0012q+_rqs|q\b\u0002}\u0011`{U\t\u001bHp8B\u0011~\u000eq/Gr";
      o[79] = "coXT\"l7jO\u000bK6Z,\u0003\u0017'c+(R\u00162\\";
      o[80] = "vl\u00113P?1:\u0007am+g-\u00036\u0001\u00195`[`m7u)\ra\u0007t01SQ";
      o[81] = "\u0005_\u001f2\u0006 \u0002\u0010\\d>4\u001b\u0001\u0006r[O\u0014\u001e\t\u007f\u0003$\u0014\r\u001e\u007f>!\n\u0007\u00102U!\u0019\u0010\u0010\u000f";
      o[82] = "\u0006LZ+\u000fvWK\u0005[\t\u0014\u001e\b\u0011 \u0012w\rF\f[\u0011j\u001e\r\u00128\u0002$\u0003v";
      o[83] = "\u001d`e\\|\u0014Ier\u0003\u0015O$#>\u001fy\u001bU'o\u001el$";
      o[84] = "2Zk<\u0014R\"\u0000o{-L,]{nQJ*0=u@@+\u0001q;\u0017HP";
      o[85] = ",\u0005>}]\\}\u0002a\r_>7\u00045}T\\+\u000ehv2\u0000/[zvO[:X4\r";
      o[86] = "\u0015!x\u0011\u00069\u001b,tMm9K',D:n\u0015pt(\u00042\u001bvsXTlOz";
      o[87] = "^i\f(\u0018\u0019\u000fnSX\u001c{Eh\u0007(\u0011\u0019YbZ#w@I!M;\u0012\u0006H6HX";
      o[88] = "~3S\b0)*k\t\\\\)\u0014`\u000b\t&(i/\u000e\u0000.";
      o[89] = "M\u001f\u001d\u0003JAQ\u001aK\u0004(W \f\u0017\u000eXXB\u0010\u001dSS>N\u000eEO\u0015UN\u001dRO(";
      o[90] = "\u0004c\u0003\u00023\u0002\u0012q\u0005\u0000OA\u0006z}@1I\u0000\u007f\u0018\u00060^\u0005\u001c";
      o[91] = ")\u000fZ\t=x*M\u0001\u0003Mt1X]\u000e\u001a*n\u000e\u0005b4e([\t\bw 0\u0005";
      o[92] = "A\u0014U\u001bt\u001d\rZ\u0002\u0013\u000fL\u0014\u001d~\u001b\u007fP}XR\u0012qW\u0000\u0003G\u0011?,";
      o[93] = "H9C!QBKnJr(S\u000f\u0013M3TCt`B/VI\t;W,\u00182";
      o[94] = "auC_C(?-LY'?\u0004:\u0014TW0f&\u001e\t\\Vb)QX\u001fjvrO\u0003'";
      o[95] = "t\u0016b^AU+\u00043\u00169_y\u0014dUBHxjiSRTl\u001a6A\u0003\u001c\u0014";
      o[96] = "\u0004~y\u0010IDT -\u001crQ\u0000g(K\u001ecS#t\u0013rHPi*\u0011\u0003\u000f\u0006\u007fx,";
      o[97] = "l|h?I\u001c|&lxp\u0019csez\u001dc?ms{\u0014\u0018w&kzp]dr|\u007f\r\u0006qq2\u0004";
      o[98] = "}'~>sxa\"(9\u0011m\u00104t3aar(~nj\u0007~6&r,l~%1r\u0011";
      o[99] = "\u0012aq\u0015wdMs ]\u000f\u007f\u0015xb\ruu\u0014r[\u0002s\u0014\u0013w*\u00060}\u0000 \"\u001a\u000ft\u000evk\u001c\u007f+\u001c'#d";
      o[100] = "7\u001dA\u0001!64_\u001a\u000bQ:/JF\u0006\u0006d~\u001f\u0019j(+6I\u0012\u0000kn.\u0017";
      o[101] = "\"C~S>\u0006!\u0001%YN\n:\u0014yT\u0019XjA,\bN\u001d$\u0001s\b$^a\u0019-";
      o[102] = "#}dq?q ??{O};*cv\u0018#f|9\u001a6l\")7pu):w";
      o[103] = "(*|L)\b~7!UH[\u0015m{H6Ih6nKx2";
      o[104] = "+\u00161q-\u001e(A8\"T\u0007{\u001dZ*/\u001fh\u0015!bd\u0007iqdq0\u0010l\f?d3^\u0017";
      o[105] = "\u000bjZMJ^\u0005gV\u0011!UY}\n\u0013Mg\r<TL!\u0000E`\u0015\u0016QUL~\rt";
      o[106] = "_\u0015}\u0007Lg\\W&\r<kGBz\u0000k5\u001b\u0013%lEz^A.\u0006\u0006?F\u001f";
      o[107] = "a%\u001f@-4$&\u0012]O'\u001b7I\f?*y+CQ4Lv$C\u0001-3j!\u0015\u0006O";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(995766044081287L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(995766044081287L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(995766044081287L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 236;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 162;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 186;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 163;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 212;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 239;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 236;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 162;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 186;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dy_C0212",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dy" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static ToIntFunction invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsInt",
                  SourceSupport.methodType("()Ljava/util/function/ToIntFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 9, "dev/zprestige/prestige/dA_C0165", "a", "()I"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dA_C0165;)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ToIntFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

    public final boolean recoveryAccess_read_i() { return this.i; }

    public final java.util.List recoveryAccess_read_m() { return this.m; }

    public final boolean recoveryAccess_write_i(boolean value) { return this.i = value; }
}
