package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.PacketUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;

public class SelectedSlotTracker implements MinecraftAccess {
   private int a;
   private boolean c;
   private static final long d = 11568280612873L;
   private static final Object[] e = new Object[35];
   private static final String[] f = new String[35];

   public SelectedSlotTracker(long var1) {
      super();
      var1 = 11568280612873L ^ var1;
      long var3 = var1 ^ 58872602993612L;

      this.a = -1;
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 89920889801826L ^ 97788024213526L;
      int var6 = Event.cReturningInt();
      int var14 = var6;
      SelectedSlotTracker var13 = this;
      SelectedSlotTracker var12 = var13;
      SelectedSlotTracker var11 = var13;
      if (var14 != 0) {
         // int var15 = var11.a;
         if (var15 == var16) {
            return;
         }

         SelectedSlotTracker var17 = this;
         var12 = var17;
      }

      Object[] var10 = new Object[]{10137645587572L};
      SelectedSlotTracker var9 = var12;
      var9.bReturningVoid(var10);
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 76394393378466L ^ 83849277965014L;
      var10001 = 76394393378466L ^ 93236363002142L;
      int var8 = Event.cReturningInt();
      int var49 = var8;
      int var48 = this.a;
      int var37 = var48;
      int var36 = var48;
      if (var49 != 0) {
         // int var50 = var36;
         if (var50 == var51) {
            return;
         }

         Object[] var11 = new Object[0];
         PacketSendEvent var10 = var1;
         byte var52 = ((byte)((var10.aReturningVoid(var11) instanceof UpdateSelectedSlotC2SPacket) ? 1 : 0));
         var37 = var52;
      }

      int var41;
      int var54 = var8;
      int var53 = var37;
      var41 = var53;
      int var38 = var53;
      label55:
      if (var54 != 0) {
         int var55 = var38;
         if (var55 != 0) {
            int var57 = var8;
            byte var56 = ((byte)((this.c) ? 1 : 0));
            var41 = var56;
            byte var39 = var56;
            if (var57 == 0) {
               break label55;
            }

            byte var58 = var39;
            byte var40 = var58;
            byte var59 = var40;
            if (var59 == 0) {
               Object[] var17 = new Object[0];
               PacketSendEvent var16 = var1;
               var16.aReturningVoid(var17);
               return;
            }
         }

         Object[] var20 = new Object[0];
         PacketSendEvent var19 = var1;
         var41 = (((var19.aReturningVoid(var20) instanceof PlayerInteractItemC2SPacket) ? 1 : 0));
      }

      label66: {
         int var61 = var8;
         int var60 = var41;
         int var43 = var60;
         int var42 = var60;
         if (var61 != 0) {
            int var62 = var42;
            if (var62 != 0) {
               break label66;
            }

            Object[] var23 = new Object[0];
            PacketSendEvent var22 = var1;
            byte var63 = ((byte)((var22.aReturningVoid(var23) instanceof PlayerInteractBlockC2SPacket) ? 1 : 0));
            var43 = var63;
         }

         int var65 = var8;
         int var64 = var43;
         int var45 = var64;
         int var44 = var64;
         if (var65 != 0) {
            int var66 = var44;
            if (var66 != 0) {
               break label66;
            }

            Object[] var27 = new Object[0];
            PacketSendEvent var26 = var1;
            byte var67 = ((byte)((var26.aReturningVoid(var27) instanceof PlayerInteractEntityC2SPacket) ? 1 : 0));
            var45 = var67;
         }

         int var69 = var8;
         int var68 = var45;
         int var47 = var68;
         int var46 = var68;
         if (var69 != 0) {
            int var70 = var46;
            if (var70 == 0) {
               return;
            }

            MinecraftClient var30 = b;
            ClientPlayerEntity var31 = var30.player;
            Object[] var32 = new Object[]{var31.getMainHandStack(), 19476550655932L};
            byte var71 = ((byte)((InventoryUtil.aReturningBoolean(var32)) ? 1 : 0));
            var47 = var71;
         }

         int var72 = var47;
         if (var72 == 0) {
            return;
         }
      }

      Object[] var35 = new Object[]{10137645587572L};
      SelectedSlotTracker var34 = this;
      var34.bReturningVoid(var35);
   }

   public void aReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 11568280612873L ^ var2;
      long var5 = var2 ^ 50052767825617L;
      this.a = var4;
      this.c = dev.prestige.recovery.SourceSupport.asBoolean(1);
      Object[] var7 = new Object[]{new UpdateSelectedSlotC2SPacket(var4), var5};
      PacketUtil.aReturningVoid(var7);
      this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   public void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 11568280612873L ^ var2;
      long var4 = var2 ^ 122415391328185L;
      long var6 = var2 ^ 51398403468146L;
      int var8 = Event.cReturningInt();
      int var16 = var8;
      SelectedSlotTracker var15 = this;
      SelectedSlotTracker var14 = var15;
      SelectedSlotTracker var13 = var15;
      if (var16 != 0) {
         // int var17 = var13.a;
         if (var17 == var18) {
            return;
         }

         this.c = dev.prestige.recovery.SourceSupport.asBoolean(1);
         Object[] var11 = new Object[]{var6};
         Object[] var12 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var11)), var4};
         PacketUtil.aReturningVoid(var12);
         this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
         var14 = this;
      }

      var14.a = -1;
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = f[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = e[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 38;
            yield var15;
         }
         case 1 -> {
            byte var16 = 58;
            yield var16;
         }
         case 2 -> {
            byte var17 = 59;
            yield var17;
         }
         case 3 -> {
            byte var18 = 40;
            yield var18;
         }
         case 4 -> {
            byte var19 = 34;
            yield var19;
         }
         case 5 -> {
            byte var20 = 23;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 46;
            yield var22;
         }
         case 8 -> {
            byte var23 = 31;
            yield var23;
         }
         case 9 -> {
            byte var24 = 2;
            yield var24;
         }
         case 10 -> {
            byte var25 = 44;
            yield var25;
         }
         case 11 -> {
            byte var26 = 16;
            yield var26;
         }
         case 12 -> {
            byte var27 = 22;
            yield var27;
         }
         case 13 -> {
            byte var28 = 50;
            yield var28;
         }
         case 14 -> {
            byte var29 = 14;
            yield var29;
         }
         case 15 -> {
            byte var30 = 15;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 33;
            yield var32;
         }
         case 18 -> {
            byte var33 = 19;
            yield var33;
         }
         case 19 -> {
            byte var34 = 26;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 9;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 21;
            yield var39;
         }
         case 25 -> {
            byte var40 = 4;
            yield var40;
         }
         case 26 -> {
            byte var41 = 41;
            yield var41;
         }
         case 27 -> {
            byte var42 = 45;
            yield var42;
         }
         case 28 -> {
            byte var43 = 42;
            yield var43;
         }
         case 29 -> {
            byte var44 = 0;
            yield var44;
         }
         case 30 -> {
            byte var45 = 60;
            yield var45;
         }
         case 31 -> {
            byte var46 = 37;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 10;
            yield var48;
         }
         case 34 -> {
            byte var49 = 48;
            yield var49;
         }
         case 35 -> {
            byte var50 = 1;
            yield var50;
         }
         case 36 -> {
            byte var51 = 17;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 56;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 27;
            yield var55;
         }
         case 41 -> {
            byte var56 = 13;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 28;
            yield var58;
         }
         case 44 -> {
            byte var59 = 55;
            yield var59;
         }
         case 45 -> {
            byte var60 = 51;
            yield var60;
         }
         case 46 -> {
            byte var61 = 5;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 8;
            yield var63;
         }
         case 49 -> {
            byte var64 = 54;
            yield var64;
         }
         case 50 -> {
            byte var65 = 53;
            yield var65;
         }
         case 51 -> {
            byte var66 = 12;
            yield var66;
         }
         case 52 -> {
            byte var67 = 39;
            yield var67;
         }
         case 53 -> {
            byte var68 = 32;
            yield var68;
         }
         case 54 -> {
            byte var69 = 57;
            yield var69;
         }
         case 55 -> {
            byte var70 = 62;
            yield var70;
         }
         case 56 -> {
            byte var71 = 47;
            yield var71;
         }
         case 57 -> {
            byte var72 = 43;
            yield var72;
         }
         case 58 -> {
            byte var73 = 25;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 49;
            yield var75;
         }
         case 61 -> {
            byte var76 = 24;
            yield var76;
         }
         case 62 -> {
            byte var77 = 35;
            yield var77;
         }
         default -> 36;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            f[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      e[0] = "\u0013Bu=~E\u0013BbarJ\t\tb\u007fr_\u000ex6'%";
      e[1] = "x\u000b\n\fk\u001ex\u000b\u001dPg\u0011b@\u001dNg\u0004e1O\u0015?N";
      e[2] = "@N`Xa)VNe\u0002r>A\u0005f\u0004~*PBq\u00135:J";
      e[3] = "t\u00062\u0019,P\u007f\t#VO]j\u0004,=z_{\u00170\u0011mR";
      e[4] = "\u000f\u000eue\u0015{\u0019\u000ep?\u0006l\u000eEs9\nx\u001f\u0002d.Aj.";
      e[5] = int.class;
      f[5] = "java/lang/Integer";
      e[6] = "\u0013WFCj=\u0013WQ\u001ff2\t\u001cQ\u0001f'\u000em\u0001\\7";
      e[7] = "_<#C9r*\u001c(L(=K\u0012#G,g?";
      e[8] = void.class;
      f[8] = "java/lang/Void";
      e[9] = "\t\u0016\u0003F(]\u001f\u0016\u0006\u001c;J\b]\u0005\u001a7^\u0019\u001a\u0012\r|O\b";
      e[10] = "\u0007).>0Tr\t%1!\u001b\u0013\u0007.:%Ag";
      e[11] = "2Hx\u0012V\f2HoNZ\u0003(\u0003oPZ\u0016/r>\t\u0002S";
      e[12] = "\u000b2'UT+\u001d2\"\u000fG<\ny!\tK(\u001b>6\u001e\u00008\u0000";
      e[13] = "Fox\f;\u001b3Os\u0003*TRAx\b.\u000e&";
      e[14] = boolean.class;
      f[14] = "java/lang/Boolean";
      e[15] = "E !\u0014Y\u000e0\u0000*\u001bHAQ\u000e!\u0010L\u001b%";
      e[16] = "5\u0011y!B\u0005@1r.SJ!?y%W\u0010U";
      e[17] = "Upb\u0010.UCpgJ=BT;dL1VE|s[zF\u0001";
      e[18] = "\f;*l~\u0004y\u001b!coK\u0018\u0015*hk\u0011l";
      e[19] = "n\u0007D&|Qx\u0007A|oFoLBzcR~\u000bUm(Bf\u000bWfr\u000fZ\u0010W{rHm\u0007";
      e[20] = "}!@e\u0000\u0002k!E?\u0013\u0015|jF9\u001f\u0001m-Q.T\u0010U";
      e[21] = ":I8=<\u0012Oi32-].g89)\u0007Z";
      e[22] = "R3\u001f/YQY<\u000e`8_R7\n:";
      e[23] = ")hq5q\u0000j~+,N\u0011t\u007ft<\u0019F*(,P-\u0002tpai6Gx";
      e[24] = "@?|UMQ[zp7Y\u0005_\"z[kV\u001b~\"7G\u000b\u001c~`S[\u0003ZB";
      e[25] = "\u001e,f\u001fCLA5i\u00042X%(xXSU_xy\u001aW1\u001b\u007fmT\t\f\u0018=;\n2";
      e[26] = "T0Fp\u000bCX7N#hTd;Jr\tY\u001ekK0\r=XoN<R\u0007\u0003&V$h";
      e[27] = "%bQ\u0002\"34yD\r\u00127It\u0006\u0014net$\u0003Nm";
      e[28] = "\u000b~,\u0019gH[{v\u001a_\u001cf-4Y>\u0011\u001c}5\u001b:uXz!UdH[8w\u000b_";
      e[29] = "Xs\n>pn_k\u00168\u001cdf|\u00058}i\u001c,\u0004zy\rYi\u0003|a|[iA>\u001c";
      e[30] = "\u0002\u0016kc'V]Pfm\u001cQ;Qbu'TA\u0011ctz8\u0001\u000bx4pBA\nyi\u001c";
      e[31] = "_-0\u001cGM\u00004?\u00076[dxi\u001dD\n^# \u0005\\0";
      e[32] = "CP\u0013\u001b%BOW\u001bHFUs[\u001f\u0019'X\t\u000b\u001e[#<\u001a\u000f\bY#\rIT\u0002HF";
      e[33] = "\f\u000ew\bA\u0004\u000f\rc\u000b/\u0000f\u001d{LN\r\u001cMz\u000eJiXJn@\u0014T[\b8\u001e/";
      e[34] = "\r\u0003(hu*RE%fN.4\u0013?8/ NC>z+D\nD*4uy\t\u0006|jN";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = e[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            e[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  e[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1595077855742683L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = f[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  e[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1595077855742683L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        e[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1595077855742683L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 193;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 243;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 70;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 97;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 229;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 75;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 193;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 243;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 70;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cn_C0138",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cn" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
