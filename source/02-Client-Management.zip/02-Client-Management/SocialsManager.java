package dev.zprestige.prestige.client.management;


import com.mojang.authlib.GameProfile;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.annotation.NativeMarker;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.modules.Teams;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;

public class SocialsManager {
   private final Set a = new LinkedHashSet();
   private final Set b = new LinkedHashSet();
   private static final long c = 138924221183578L;
   private static final Object[] d = new Object[51];
   private static final String[] e = new String[51];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;

   @NativeMarker
   public void a(String var1) {
      String var5 = var1;
      Set var4 = this.a;
      var4.add(var5);
   }

   @NativeMarker
   public void b(String var1) {
      String var5 = var1;
      Set var4 = this.a;
      var4.remove(var5);
   }

   public void cReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      long var3 = (Long)var1[1];
      var3 = 138924221183578L ^ var3;
      invokeBinding1(this.b, var2, 4201090823056177544L, var3);
   }

   public void dReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      long var3 = (Long)var1[1];
      var3 = 138924221183578L ^ var3;
      invokeBinding2(this.b, var2, 6683999648587049494L, var3);
   }

   public boolean aReturningBoolean(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 138924221183578L ^ var2;
      long var5 = var2 ^ 40437176179080L;
      int var7 = Event.bReturningInt();
      Object[] var8 = new Object[]{var4, var5};
      boolean var10000 = Teams.aReturningBoolean(var8);
      int var16 = var7;
      boolean var15 = var10000;
      boolean var14 = var15;
      boolean var13 = var15;
      if (var16 == 0) {
         boolean var17 = var13;
         if (var17) {
            return true;
         }

         String var12 = var4;
         Set var11 = this.a;
         var14 = var11.contains(var12);
      }

      return var14;
   }

   public boolean bReturningBoolean(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 138924221183578L ^ var2;
      return invokeBinding3(this.b, var4, -6104786804494088207L, var2);
   }

    public int aReturningInt(Object[] objectArray) {
        int n;
        block10: {
            block11: {
                int n2;
                long l;
                block8: {
                    long l2;
                    String string;
                    block9: {
                        string = (String)objectArray[0];
                        l = (Long)objectArray[1];
                        long l3 = l = 0x7E59D0DAB65AL ^ l;
                        long l4 = l3 ^ 0x62F7D92C344BL;
                        l2 = l3 ^ 0x5BE513A948BL;
                        n2 = SocialsManager.invokeBinding4(-8530660074863729118L, l);
                        try {
                            try {
                                Object[] objectArray2 = new Object[2];
                                objectArray2[1] = l4;
                                objectArray2[0] = string;
                                n = (((SocialsManager.invokeBinding5(this, objectArray2, -8534118231605193506L, l)) ? 1 : 0));
                                if (n2 == 0) break block8;
                                if (n == 0) break block9;
                            }
                            catch (MatchException matchException) {
                                throw SocialsManager.invokeBinding6(matchException, -8533815042828718509L, l);
                            }
                            return 1;
                        }
                        catch (MatchException matchException) {
                            throw SocialsManager.invokeBinding7(matchException, -8533815042828718509L, l);
                        }
                    }
                    Object[] objectArray3 = new Object[2];
                    objectArray3[1] = l2;
                    objectArray3[0] = string;
                    n = SocialsManager.invokeBinding8(this, objectArray3, -8533906646317006128L, l) ? 1 : 0;
                }
                try {
                    try {
                        if (n2 == 0) break block10;
                        if (n == 0) break block11;
                    }
                    catch (MatchException matchException) {
                        throw SocialsManager.invokeBinding9(matchException, -8533815042828718509L, l);
                    }
                    return -1;
                }
                catch (MatchException matchException) {
                    throw SocialsManager.invokeBinding10(matchException, -8533815042828718509L, l);
                }
            }
            n = 0;
        }
        return n;
    }

    public Color aReturningColor(Object[] objectArray) {
        boolean bl;
        long l;
        block7: {
            long l2;
            String string;
            block8: {
                string = (String)objectArray[0];
                l = (Long)objectArray[1];
                long l3 = l = 0x7E59D0DAB65AL ^ l;
                long l4 = l3 ^ 0x66AC4481B6E3L;
                l2 = l3 ^ 0x1E5CC971623L;
                int n = SocialsManager.invokeBinding11(807557757234209930L, l);
                try {
                    try {
                        Object[] objectArray2 = new Object[2];
                        objectArray2[1] = l4;
                        objectArray2[0] = string;
                        bl = SocialsManager.invokeBinding12(this, objectArray2, 808603891423860342L, l);
                        if (n == 0) break block7;
                        if (!bl) break block8;
                    }
                    catch (MatchException matchException) {
                        throw SocialsManager.invokeBinding13(matchException, 808897739606895867L, l);
                    }
                    return SocialsManager.invokeBinding14(810338959124864247L, l);
                }
                catch (MatchException matchException) {
                    throw SocialsManager.invokeBinding15(matchException, 808897739606895867L, l);
                }
            }
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = l2;
            objectArray3[0] = string;
            bl = SocialsManager.invokeBinding16(this, objectArray3, 808815344373432440L, l);
        }
        try {
            if (bl) {
                return SocialsManager.invokeBinding17(808651726815608498L, l);
            }
        }
        catch (MatchException matchException) {
            throw SocialsManager.invokeBinding18(matchException, 808897739606895867L, l);
        }
        return SocialsManager.invokeBinding19(807418093418234112L, l);
    }

   @NativeMarker
   public List a() {
      return new ArrayList(this.a);
   }

   public List bReturningList(Object[] var1) {
      return new ArrayList(this.b);
   }

   @NativeMarker
   public List c() {
      long var10001 = 22728706407475L ^ 52788536082914L;
      var10001 = 22728706407475L ^ 30997063508719L;
      int var7 = Event.bReturningInt();
      MinecraftClient var12 = MinecraftClient.getInstance();
      ClientPlayNetworkHandler var55 = var12.getNetworkHandler();
      if (var55 == null) {
         return new ArrayList();
      }

      ArrayList var8 = new ArrayList();
      MinecraftClient var14 = MinecraftClient.getInstance();
      ClientPlayNetworkHandler var15 = var14.getNetworkHandler();
      ClientPlayNetworkHandler var16 = Objects.requireNonNull(var15);
      Collection var17 = var16.getPlayerList();
      Iterator var9 = var17.iterator();

      while (true) {
         Iterator var18 = var9;
         boolean var56 = var18.hasNext();
         if (!var56) {
            break;
         }

         Iterator var19 = var9;
         PlayerListEntry var10 = (PlayerListEntry)var19.next();
         PlayerListEntry var20 = var10;
         GameProfile var10000 = var20.getProfile();
         int var58 = var7;
         GameProfile var57 = var10000;
         GameProfile var46 = var57;
         GameProfile var45 = var57;
         if (var58 == 0) {
            GameProfile var59 = var45;
            if (var59 == null) {
               continue;
            }

            PlayerListEntry var22 = var10;
            var46 = var22.getProfile();
         }

         Object[] var23 = new Object[]{var46, 9461285330652L};
         String var60 = RaycastUtil.aReturningString(var23);
         if (var60 != null) {
            MinecraftClient var24 = MinecraftClient.getInstance();
            int var62 = var7;
            ClientPlayerEntity var61 = var24.player;
            ClientPlayerEntity var48 = var61;
            ClientPlayerEntity var47 = var61;
            if (var62 == 0) {
               ClientPlayerEntity var63 = var47;
               if (var63 == null) {
                  continue;
               }

               MinecraftClient var26 = MinecraftClient.getInstance();
               var48 = var26.player;
            }

            GameProfile var52;
            label72: {
               ClientPlayerEntity var27 = var48;
               UUID var77 = var27.getUuid();
               int var65 = var7;
               UUID var64 = var77;
               UUID var51 = var64;
               UUID var49 = var64;
               if (var65 == 0) {
                  UUID var66 = var49;
                  if (var66 == null) {
                     int var67 = var7;
                     if (var67 == 0) {
                        continue;
                     }
                  }

                  PlayerListEntry var30 = var10;
                  var10000 = var30.getProfile();
                  int var69 = var7;
                  GameProfile var68 = var10000;
                  var52 = var68;
                  GameProfile var50 = var68;
                  if (var69 != 0) {
                     break label72;
                  }

                  GameProfile var31 = var50;
                  UUID var70 = var31.id();
                  var51 = var70;
               }

               MinecraftClient var33 = MinecraftClient.getInstance();
               ClientPlayerEntity var34 = var33.player;
               UUID var36 = var34.getUuid();
               UUID var35 = var51;
               boolean var71 = var35.equals(var36);
               if (var71) {
                  continue;
               }

               PlayerListEntry var38 = var10;
               var52 = var38.getProfile();
            }

            Object[] var39 = new Object[]{var52, 9461285330652L};
            String var11 = RaycastUtil.aReturningString(var39);
            Object[] var41 = new Object[]{var11, 40309233401297L};
            SocialsManager var40 = this;
            boolean var79 = var40.aReturningBoolean(var41);
            int var73 = var7;
            boolean var72 = var79;
            boolean var53 = var72;
            if (var73 == 0) {
               boolean var74 = var53;
               if (!var74) {
                  String var44 = var11;
                  ArrayList var43 = var8;
                  boolean var75 = var43.add(var44);
               }
            }

            int var76 = var7;
            if (var76 != 0) {
               break;
            }
         }
      }

      return var8;
   }

   static {
      b();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = e[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = d[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 36;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 43;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 9;
            yield var21;
         }
         case 7 -> {
            byte var22 = 16;
            yield var22;
         }
         case 8 -> {
            byte var23 = 20;
            yield var23;
         }
         case 9 -> {
            byte var24 = 35;
            yield var24;
         }
         case 10 -> {
            byte var25 = 58;
            yield var25;
         }
         case 11 -> {
            byte var26 = 60;
            yield var26;
         }
         case 12 -> {
            byte var27 = 32;
            yield var27;
         }
         case 13 -> {
            byte var28 = 48;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 5;
            yield var30;
         }
         case 16 -> {
            byte var31 = 26;
            yield var31;
         }
         case 17 -> {
            byte var32 = 33;
            yield var32;
         }
         case 18 -> {
            byte var33 = 34;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 1;
            yield var35;
         }
         case 21 -> {
            byte var36 = 47;
            yield var36;
         }
         case 22 -> {
            byte var37 = 49;
            yield var37;
         }
         case 23 -> {
            byte var38 = 62;
            yield var38;
         }
         case 24 -> {
            byte var39 = 2;
            yield var39;
         }
         case 25 -> {
            byte var40 = 13;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 6;
            yield var42;
         }
         case 28 -> {
            byte var43 = 0;
            yield var43;
         }
         case 29 -> {
            byte var44 = 24;
            yield var44;
         }
         case 30 -> {
            byte var45 = 15;
            yield var45;
         }
         case 31 -> {
            byte var46 = 14;
            yield var46;
         }
         case 32 -> {
            byte var47 = 28;
            yield var47;
         }
         case 33 -> {
            byte var48 = 55;
            yield var48;
         }
         case 34 -> {
            byte var49 = 8;
            yield var49;
         }
         case 35 -> {
            byte var50 = 52;
            yield var50;
         }
         case 36 -> {
            byte var51 = 42;
            yield var51;
         }
         case 37 -> {
            byte var52 = 38;
            yield var52;
         }
         case 38 -> {
            byte var53 = 37;
            yield var53;
         }
         case 39 -> {
            byte var54 = 10;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 63;
            yield var56;
         }
         case 42 -> {
            byte var57 = 29;
            yield var57;
         }
         case 43 -> {
            byte var58 = 27;
            yield var58;
         }
         case 44 -> {
            byte var59 = 7;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 31;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 18;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 53;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 54;
            yield var68;
         }
         case 54 -> {
            byte var69 = 23;
            yield var69;
         }
         case 55 -> {
            byte var70 = 25;
            yield var70;
         }
         case 56 -> {
            byte var71 = 39;
            yield var71;
         }
         case 57 -> {
            byte var72 = 51;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 21;
            yield var75;
         }
         case 61 -> {
            byte var76 = 50;
            yield var76;
         }
         case 62 -> {
            byte var77 = 17;
            yield var77;
         }
         default -> 46;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            e[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      d[0] = "U U?!6C Pe2!TkSc>5E,Dtu't";
      d[1] = int.class;
      e[1] = "java/lang/Integer";
      d[2] = "[^.\u007f@\u0019M^+%S\u000eZ\u0015(#_\u001aKR?4\u0014\u000fF";
      d[3] = "\u0019;:w/}l\u001b1x>2\r\u0015:s:hy";
      d[4] = boolean.class;
      e[4] = "java/lang/Boolean";
      d[5] = "\t\u0019F\u007f]V\u001f\u0019C%NA\bR@#BU\u0019\u0015W4\t@\"";
      d[6] = "|K\t\r\rOwD\u0018BnBbI\u0017)[@sZ\u000b\u0005LM";
      d[7] = "\u001a\u000e\\\u001eSe\u0004\u0006FQ.u\u0004";
      d[8] = "g7|T\u0018?l8m\u001by1g3iA";
      d[9] = ";ZJ\u0001\u0017uNzA\u000e\u0006:/tJ\u0005\u0002`[";
      d[10] = "^76nY1+\u0017=aH~J\u00196jL$>";
      d[11] = "Q\u007f<c<^LjdA}STl";
      d[12] = "\u0014:9&\u0016\u0005\n2#im%7\u001f";
      d[13] = "\u0004\u001c1R:\u0003\r\u00122\u001by\r\u0012\u00074\u0010>\u000eI4=\u00112<\u0015\u001c:\u0015;\t";
      d[14] = "9%\u0000j)]'-\u001a%HJ9!\u0015\u007ft";
      d[15] = "B\u0006\u0006\n\u007fCB\u0006\u0011VsLXM\u0011HsY_<D\u0010\"";
      d[16] = "\\obP\u001cnBgx\u001fqtZbqRFrY`";
      d[17] = "O\u0016A|vtQ\u001e[3\u0011u@\u0005Vi7s";
      d[18] = "GQ/Lv~GQ8\u0010zq]\u001a8\u000ezdZkhS+";
      d[19] = "iWneoFiWy9cIs\u001cy'c\\tm,x6";
      d[20] = "z(u9 Wd ovBKc=";
      d[21] = "]XHk\u007fKKXM1l\\\\\u0013N7`HMTY +X\n";
      d[22] = "y}|$S\u001f\f]w+BPmS| F\n\u0019";
      d[23] = "g_O>wtlP^q\nl\u007fWW8";
      d[24] = "*\u00145F/\u001d*\u0014\"\u001a#\u00120_\"\u0004#\u00077.v\\t";
      d[25] = "n|k?%stmp\\6\u0017=:o!#*}?s2\\";
      d[26] = "d+\u001aZ\u000eW$!\u0011\u00047K9\u001bA\bNX*c\u001a\u0005\u000b\u0016U";
      d[27] = "o\t\n%4\b:NSaT-\u001fpo\u0016TBg\bM;.\u0017 Q\t";
      d[28] = "upkFH4}y1Y#?q|mPO\r&13\t#k,k5\u000e^+&`k7";
      d[29] = "-@]\u0013O{7QFp]\u001f~\u0006Y\rI\">\u0003E\u001e6";
      d[30] = "\u001fk=3\u0013%\u0013*0-o'\t;:&\u0013!\u000fV+ V?\u001ag;%\t4u";
      d[31] = "w2y&\u001c\u0018`)a=m\u000fq4p9\u0001=%u.dm\u0006|xt:\u0004Zr$,^";
      d[32] = "\u0006__\u0019\u0005D_\u0012B\u0003kHVN:C\u000eSP\u0012S\u000f\u0004MP\"\u0001C\n\u001aZ_Y\u0000\u000bE:";
      d[33] = "bV\u0007!+)uM\u001f:Z>dP\u000e>6\f0\u0011S`Z0sE\u0016(('h]\rY";
      d[34] = "3T\u0002iJ8#Q]b%o5KG\u0010\u0018l*Q\u000byTf4Q;";
      d[35] = "\u0002\u0015{\u0014e\t\u0015\u000ec\u000f\u0014\u0015\b\u0002v\u0000CBVU.lt\u0012\u0019\fyU,\u0007PR";
      d[36] = "#5e\u0015-f30:\u001eB7!!\u001a\u00012+Haa\ry759\"\f&W";
      d[37] = "T\u001d\\\t|8\b\u0013\u0000Q\u00184U\u0001\f\nt\u0006\u0002M\\U\u0018;\u0005\u0000\u0010\u0011{7D\r\u000em";
      d[38] = "Cdg!Xe\u0018i\"o'p\nsw7\\\u001dNkl9\u0017t\u0002ar9'&No%3Z~\rnzS";
      d[39] = "W_\u001f\u0007o$EM\u0004Q_:SJ\u0004\u000b%-xT\u001f,\"$Z3D\u000f-*\u000eZ\b\u00053*>\u000e\u001c\u00185pWB\u0016\u00065@";
      d[40] = "\u0004.}\u000e\u000f$]'0B2'=\"bRI$Ptt@\fN\u0006qn\tR3^2oV2";
      d[41] = "}`}\u001b5)$-`\u0001[6,x\u007f\u00026L|xj\u0016k%0rt\u0016[w||#\u001c&/?}||";
      d[42] = "\t*(_&\u0011\\mq\u001bF1t^\u0011\u0011~RGrkD9\u000b\u0003";
      d[43] = "\u0003\u0016H\u0007=cFCWP\u0004w8\u0017Y_\u007ftUAOM:\u001e\u0003DU\u0004dc[\u0007T[\u0004";
      d[44] = "P\u0018A\u0019 0\u0015M^N\u0019'k\u0019PAb'\u0006OFS'MPJ\\\u001ay0\b\t]E\u0019";
      d[45] = "\f@j'$-\\H`8\\5\rM\u000bc9.\u000b\u0011b/30\u000b!0c=g\u0001\\h <8a";
      d[46] = "\r\u001ds\u0012v4HHlEO 6NdM(sD\bp\u0015/I\n\u0019hMu;L\r0JO";
      d[47] = "o\u0017$M+s|\u001e:Z\u001a#\u0002\u00027_a oT!M$Jm\u0000&Fzws\r>N\u001a";
      d[48] = "\fu4@gTT`}\u001e\f\b\u0001`$D`:Q\"z\u001c\f]\u0006e6\\t\u0006\u000b x#";
      d[49] = "!\u001bi\u007f(BxVteFLz\u0000pq'Aff1}4M-\u000f}w*M\u001d]1y}G`\u0005rx\"'";
      d[50] = "Xrj'\u0018t\r53cxE9\u0003\u0015YH6Q43#\u001dq\bp";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = d[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(e[var4]);
            d[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = d[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            d[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  d[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(572631393788255L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = d[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = e[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  d[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(572631393788255L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        d[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(572631393788255L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 212;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 108;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 200;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 76;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 220;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 195;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 212;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 108;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 200;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fO_C0299",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fO" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static boolean invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = a(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = a(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static boolean invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = a(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding4(long var0, long var2) {
         MethodHandle var8 = bindingCache4;
         MethodHandle var7 = bindingCache4;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache4 = a(MethodHandles.lookup(), "Ã", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static boolean invokeBinding5(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = a(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = a(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding11(long var0, long var2) {
         MethodHandle var8 = bindingCache11;
         MethodHandle var7 = bindingCache11;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache11 = a(MethodHandles.lookup(), "Ã", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static boolean invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = a(
                  MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Color invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = a(MethodHandles.lookup(), "È", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = a(
                  MethodHandles.lookup(), "Ü", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Color invokeBinding17(long var0, long var2) {
         MethodHandle var8 = bindingCache17;
         MethodHandle var7 = bindingCache17;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache17 = a(MethodHandles.lookup(), "È", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = a(
                  MethodHandles.lookup(), "Ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Color invokeBinding19(long var0, long var2) {
         MethodHandle var8 = bindingCache19;
         MethodHandle var7 = bindingCache19;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache19 = a(MethodHandles.lookup(), "È", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }
}
