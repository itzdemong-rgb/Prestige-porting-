package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.TickEvent;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

public class TargetManager implements MinecraftAccess {
   private PlayerEntity a;
   private long c;
   private static final long d = 103339945356414L;
   private static final long[] e;
   private static final Long[] f;
   private static final Map g = new HashMap(13);
   private static final Object[] h = new Object[47];
   private static final String[] i = new String[47];

   public TargetManager(long var1) {
      super();
      var1 = 103339945356414L ^ var1;
      long var3 = var1 ^ 118618161533391L;

      this.a = null;
      short var10001 = 14192;
      long var10002 = 7342329045673014573L ^ var1;
      this.c = 0L;
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(TickEvent var1) {
      int var4 = Event.bReturningInt();
      PlayerEntity var19 = this.a;
      if (var19 != null) {
         TargetManager var18;
         label30: {
            MinecraftClient var5 = b;
            ClientWorld var20 = var5.world;
            if (var20 != null) {
               int var22 = var4;
               TargetManager var21 = this;
               var18 = var21;
               TargetManager var14 = var21;
               if (var22 != 0) {
                  break label30;
               }

               TargetManager var23 = var14;
               TargetManager var15 = var23;
               PlayerEntity var8 = var15.a;
               boolean var24 = var8.isAlive();
               if (var24) {
                  int var26 = var4;
                  TargetManager var25 = this;
                  var18 = var25;
                  TargetManager var16 = var25;
                  if (var26 != 0) {
                     break label30;
                  }

                  TargetManager var27 = var16;
                  TargetManager var17 = var27;
                  MinecraftClient var11 = b;
                  ClientPlayerEntity var13 = var11.player;
                  PlayerEntity var12 = var17.a;
                  float var31;
                  int var28 = (var31 = var12.distanceTo((Entity)var13) - 15.0F) == 0.0F ? 0 : (var31 < 0.0F ? -1 : 1);
                  if (var28 <= 0) {
                     long var32;
                     int var29 = (var32 = System.currentTimeMillis() - this.c - 5000L) == 0L ? 0 : (var32 < 0L ? -1 : 1);
                     if (var29 <= 0) {
                        return;
                     }
                  }
               }
            }

            TargetManager var30 = this;
            var18 = var30;
         }

         var18.a = null;
      }
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 83762553923239L ^ 114930184100726L;
      var10001 = 83762553923239L ^ 116823941008716L;
      int var10000 = Event.bReturningInt();
      Object[] var14 = new Object[0];
      AttackEntityEvent var13 = var1;
      Entity var9 = var13.aReturningEntity(var14);
      int var8 = var10000;
      byte var60 = ((byte)((var9 instanceof PlayerEntity) ? 1 : 0));
      int var43 = var8;
      boolean var42 = dev.prestige.recovery.SourceSupport.asBoolean(var60);
      boolean var37 = var42;
      boolean var36 = var42;
      if (var43 == 0) {
         boolean var44 = var36;
         if (var44) {
            PlayerEntity var10 = (PlayerEntity)var9;
            Object[] var17 = new Object[]{var10, 42255176231915L};
            TargetManager var16 = this;
            var16.aReturningVoid(var17);
            int var45 = var8;
            if (var45 == 0) {
               return;
            }
         }

         boolean var46 = var9 instanceof EndCrystalEntity;
         var37 = var46;
      }

      boolean var47 = var37;
      if (var47) {
         MinecraftClient var19 = b;
         ClientWorld var20 = var19.world;
         List var21 = var20.getPlayers();
         Iterator var11 = var21.iterator();

         while (true) {
            Iterator var22 = var11;
            boolean var48 = var22.hasNext();
            if (!var48) {
               break;
            }

            Iterator var23 = var11;
            PlayerEntity var12 = (PlayerEntity)var23.next();
            int var50 = var8;
            PlayerEntity var49 = var12;
            PlayerEntity var39 = var49;
            PlayerEntity var38 = var49;
            if (var50 == 0) {
               PlayerEntity var51 = var38;
               if (var51 == null) {
                  continue;
               }

               var39 = var12;
            }

            MinecraftClient var25 = b;
            ClientPlayerEntity var53 = var25.player;
            PlayerEntity var52 = var39;
            if (var52 != var53) {
               SocialsManager var61 = Prestige.g;
               PlayerEntity var26 = var12;
               Text var27 = var26.getName();
               Object[] var29 = new Object[]{var27.getString(), 40309233401297L};
               SocialsManager var28 = var61;
               var60 = ((byte)((var28.aReturningBoolean(var29)) ? 1 : 0));
               int var55 = var8;
               byte var54 = var60;
               byte var41 = var54;
               byte var40 = var54;
               if (var55 == 0) {
                  byte var56 = var40;
                  if (var56 != 0) {
                     int var57 = var8;
                     if (var57 == 0) {
                        continue;
                     }
                  }

                  Entity var33 = var9;
                  PlayerEntity var32 = var12;
                  float var64;
                  var41 = (byte)((var64 = var32.distanceTo(var33) - 5.0F) == 0.0F ? 0 : (var64 < 0.0F ? -1 : 1));
               }

               byte var58 = var41;
               if (var58 <= 0) {
                  Object[] var35 = new Object[]{var12, 42255176231915L};
                  TargetManager var34 = this;
                  var34.aReturningVoid(var35);
               }

               int var59 = var8;
               if (var59 != 0) {
                  break;
               }
            }
         }
      }
   }

   public PlayerEntity aReturningPlayerEntity(Object[] var1) {
      return this.a;
   }

   public void aReturningVoid(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 103339945356414L ^ var3;
      long var5 = var3 ^ 104710261881412L;
      int var7 = Event.cReturningInt();
      int var12 = var7;
      if (var12 != 0) {
         SocialsManager var10000 = Prestige.g;
         PlayerEntity var8 = var2;
         Text var9 = var8.getName();
         Object[] var11 = new Object[]{var9.getString(), var5};
         SocialsManager var10 = var10000;
         boolean var13 = var10.aReturningBoolean(var11);
         if (var13) {
            return;
         }

         this.a = var2;
         this.c = System.currentTimeMillis();
      }
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(40613652122544L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "B\u009fG\b0Î#¶³5Ðy/H4\u0001";
      int var7 = "B\u009fG\b0Î#¶³5Ðy/H4\u0001".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      e = var8;
      f = new Long[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 22335;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])g.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fT", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fT_C0309",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 0;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 42;
            yield var17;
         }
         case 3 -> {
            byte var18 = 21;
            yield var18;
         }
         case 4 -> {
            byte var19 = 51;
            yield var19;
         }
         case 5 -> {
            byte var20 = 23;
            yield var20;
         }
         case 6 -> {
            byte var21 = 20;
            yield var21;
         }
         case 7 -> {
            byte var22 = 40;
            yield var22;
         }
         case 8 -> {
            byte var23 = 26;
            yield var23;
         }
         case 9 -> {
            byte var24 = 43;
            yield var24;
         }
         case 10 -> {
            byte var25 = 33;
            yield var25;
         }
         case 11 -> {
            byte var26 = 60;
            yield var26;
         }
         case 12 -> {
            byte var27 = 12;
            yield var27;
         }
         case 13 -> {
            byte var28 = 31;
            yield var28;
         }
         case 14 -> {
            byte var29 = 38;
            yield var29;
         }
         case 15 -> {
            byte var30 = 32;
            yield var30;
         }
         case 16 -> {
            byte var31 = 41;
            yield var31;
         }
         case 17 -> {
            byte var32 = 25;
            yield var32;
         }
         case 18 -> {
            byte var33 = 34;
            yield var33;
         }
         case 19 -> {
            byte var34 = 3;
            yield var34;
         }
         case 20 -> {
            byte var35 = 17;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 4;
            yield var37;
         }
         case 23 -> {
            byte var38 = 48;
            yield var38;
         }
         case 24 -> {
            byte var39 = 7;
            yield var39;
         }
         case 25 -> {
            byte var40 = 29;
            yield var40;
         }
         case 26 -> {
            byte var41 = 18;
            yield var41;
         }
         case 27 -> {
            byte var42 = 39;
            yield var42;
         }
         case 28 -> {
            byte var43 = 6;
            yield var43;
         }
         case 29 -> {
            byte var44 = 8;
            yield var44;
         }
         case 30 -> {
            byte var45 = 36;
            yield var45;
         }
         case 31 -> {
            byte var46 = 5;
            yield var46;
         }
         case 32 -> {
            byte var47 = 16;
            yield var47;
         }
         case 33 -> {
            byte var48 = 19;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 61;
            yield var50;
         }
         case 36 -> {
            byte var51 = 15;
            yield var51;
         }
         case 37 -> {
            byte var52 = 13;
            yield var52;
         }
         case 38 -> {
            byte var53 = 2;
            yield var53;
         }
         case 39 -> {
            byte var54 = 1;
            yield var54;
         }
         case 40 -> {
            byte var55 = 24;
            yield var55;
         }
         case 41 -> {
            byte var56 = 37;
            yield var56;
         }
         case 42 -> {
            byte var57 = 56;
            yield var57;
         }
         case 43 -> {
            byte var58 = 47;
            yield var58;
         }
         case 44 -> {
            byte var59 = 35;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 54;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 9;
            yield var63;
         }
         case 49 -> {
            byte var64 = 28;
            yield var64;
         }
         case 50 -> {
            byte var65 = 55;
            yield var65;
         }
         case 51 -> {
            byte var66 = 52;
            yield var66;
         }
         case 52 -> {
            byte var67 = 59;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 10;
            yield var71;
         }
         case 57 -> {
            byte var72 = 45;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 53;
            yield var74;
         }
         case 60 -> {
            byte var75 = 57;
            yield var75;
         }
         case 61 -> {
            byte var76 = 50;
            yield var76;
         }
         case 62 -> {
            byte var77 = 58;
            yield var77;
         }
         default -> 27;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "z}BWKpqrS\u00186echQ[";
      h[1] = long.class;
      i[1] = "java/lang/Long";
      h[2] = "H5_\u0015^)^5ZOM>I~YIA*X9N^\n:@9LUPw|\"LHP0K5";
      h[3] = "nM1_\u000e7xM4\u0005\u001d o\u00067\u0003\u00114~A \u0014Z!E";
      h[4] = "\u0003\u0018.\u001b\u001epv8%\u0014\u000f?\u00176.\u001f\u000bec";
      h[5] = boolean.class;
      i[5] = "java/lang/Boolean";
      h[6] = "u?:Zbxc??\u0000qott<\u0006}{e3+\u00116iT";
      h[7] = int.class;
      i[7] = "java/lang/Integer";
      h[8] = "\rb\u000fTQ>\u001bb\n\u000eB)\f)\t\bN=\u001dn\u001e\u001f\u0005(=";
      h[9] = "\u0018\u0015W}\u0018n\u0013\u001aF2{c\u0006\u0017IYNa\u0017\u0004UuYl";
      h[10] = "\\\nANp\u0019\\\nV\u0012|\u0016FAV\f|\u0003A0\u0007U+A";
      h[11] = "v\u0015\u0014g\t/}\u001a\u0005(t7n\u001d\fa";
      h[12] = "@X/\u007fR@@X8#^OZ\u00138=^Z]bjg\n\u001e";
      h[13] = "\u0013\u001bcKO\u001d\u0005\u001bf\u0011\\\n\u0012Pe\u0017P\u001e\u0003\u0017r\u0000\u001b\u000f;";
      h[14] = "/87xN\u0002Z\u0018<w_M;\u00167|[\u0017O";
      h[15] = void.class;
      i[15] = "java/lang/Void";
      h[16] = "h\u0010Pi<\u0000h\u0010G50\u000fr[G+0\u001au*\u0015uh^";
      h[17] = float.class;
      i[17] = "java/lang/Float";
      h[18] = "WcUD=jWcB\u00181eM(B\u00061pJY\u0012[`";
      h[19] = "\u0017z\u0017B\u000eV\u0017z\u0000\u001e\u0002Y\r1\u0000\u0000\u0002L\n@U_[";
      h[20] = "OD*gt'OD=;x(U\u000f=%x=R~i}/";
      h[21] = "rui%\u007f/l}sj\u001d3k`";
      h[22] = "hTq:\u001cjv\\ku{kgGf/]m";
      h[23] = "mU\u000b\u001arA\u0018u\u0000\u0015c\u000ey{\u000b\u001egT\r";
      h[24] = "S\u0000C~bdE\u0000F$qsRKE\"}gC\fR56u\u007f";
      h[25] = "\u0013j'\u001d\u007fofJ,\u0012n \u0007D'\u0019jzs";
      h[26] = "\u0018@C{w~\u0013OR4\u0016p\u0018DVn";
      h[27] = "\u0019<\t\r\u0012*\u0011(\u0015\fvp\u0018.\u0012\u0014\u001aBLbNNH\u0015\u0018)\u001d\u0003\u001a/\u000bk\u0010\u0018v";
      h[28] = "\"A\\L\u007fh`\r\u001bH\u0019s\u007fL\u0002IuA/\u0000Z\u0013\u0019-iI\u0002Du+mV_.";
      h[29] = "D\u001a=\u0014yS\u0006Vz\u0010\u001fH\u0019\u0017c\u0011szIT8G\u001fG\u0014\u00123\u0010fP\u001aW`vt\u0013\u000f\u0015~\fcM\u000b\b\u0003";
      h[30] = "}\u000b\b\u0003T,\u007f\u0011\u0012X%(AP\u0000\u000f^<;UPV\u001aB";
      h[31] = "q \u0012*YY/\"NLM\u0014m(D*Z5v7D\tG\rs3RL[\u0006e5W!M\u0018&R";
      h[32] = ";o\u0011S{:3vF\r\u001c,\u00024G\u0013l'bg\u001dU#";
      h[33] = "A sq5f\u0012z5>Qo{|hsh}\u001dc3\u007f0\u0006@gwa;jFch<Q";
      h[34] = "Mp0\u000fi\u001f^2=\u0014\u0005D\\f%\u0016yBZ\u000b1\u00194[Fqf\u00048J ";
      h[35] = "\rCACHl\u000fY[\u00189i1\u0018IOB|K\u001d\u0019\u0016\u0006\u0002";
      h[36] = "p(h9&\n-*:5AXM5`&xJ+*;* 1'mvlpXt>j9A";
      h[37] = "`*1o\u0006j;}2f~3\u0000ti\u007fG!fk2s\u001fZjtv=\u0018#}z3n~";
      h[38] = "Y#[1F/Nd\u0015m6/Ts\u000f<ax\u000b.TPZ/N`\u000foR;Ra";
      h[39] = "2*Z\u0001<fo(\b\r[4\u000fi]R\"7`3^P!]1>\n\u001512k=\b\u0016[";
      h[40] = "43 9Cjc.,(%v7%mGD.!>{5\\.'d\u0011";
      h[41] = "$\r@\u0004:3k\u0004\u0011T\u0000mw\u0000*Czc|\u0013q\u000f?f\u007fFNOa}~|";
      h[42] = "W\f^I\u00062@K\u0010\u0015v2Z\\\nD!e\u0004\u000bR(\u001a\"R\tSEH%Q@";
      h[43] = "\u0003)\u00048CY\u000b0Sf$J:yVc_M\u00032\u000fk]";
      h[44] = "'\tO~]AlPG|0\u0011\u0016QOw\t\u0003pN\u0014{Qx|\tY=\u0001\u0011/ZEh0";
      h[45] = "<d2/+3ky>>M);yE<=5R9x(-#>?|7pI";
      h[46] = "S$.\u007f,B\u0011hi{JY\u000e)pz&k^i/\"J\u0002\u0012d+'{M\u001b5{\u001d";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1847226922595361L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1847226922595361L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1847226922595361L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 241;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 242;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 102;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 208;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 198;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 66;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 241;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 242;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 102;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fT_C0309",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
