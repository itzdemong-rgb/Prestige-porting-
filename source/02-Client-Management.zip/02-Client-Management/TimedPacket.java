package dev.zprestige.prestige.client.management;

import net.minecraft.network.packet.Packet;

public record TimedPacket(Packet<?> ae, long af) {

    public final long recoveryAccess_read_af() { return this.af; }

    public final net.minecraft.network.packet.Packet<?> recoveryAccess_read_ae() { return this.ae; }
}
