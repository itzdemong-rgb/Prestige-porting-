package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.WorldResetEvent;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.world.World;

public class TotemPopTracker implements MinecraftAccess {
   private final Object2IntMap a;
   private final HashSet c;
   private static final long d = 104358862141707L;
   private static final long e;
   private static final Object[] f = new Object[53];
   private static final String[] g = new String[53];

   public TotemPopTracker(long var1) {
      super();
      var1 = 104358862141707L ^ var1;
      long var3 = var1 ^ 69406763532065L;

      this.a = new Object2IntOpenHashMap();
      this.c = new HashSet();
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.cReturningInt();
      Object[] var9 = new Object[0];
      PacketReceiveEvent var8 = var1;
      Packet var6 = var8.aReturningVoid(var9);
      int var4 = var10000;
      int var35 = var4;
      Packet var34 = var6;
      Packet var29 = var34;
      Packet var28 = var34;
      if (var35 != 0) {
         boolean var36 = var28 instanceof EntityStatusS2CPacket;
         if (!var36) {
            return;
         }

         Packet var37 = var6;
         var29 = var37;
      }

      EntityStatusS2CPacket var5 = (EntityStatusS2CPacket)var29;
      int var39 = var4;
      EntityStatusS2CPacket var38 = var5;
      EntityStatusS2CPacket var31 = var38;
      EntityStatusS2CPacket var30 = var38;
      if (var39 != 0) {
         EntityStatusS2CPacket var12 = var30;
         byte var50 = var12.getStatus();
         int var41 = (int)e;
         byte var40 = var50;
         if (var40 != var41) {
            return;
         }

         EntityStatusS2CPacket var42 = var5;
         var31 = var42;
      }

      MinecraftClient var15 = b;
      ClientWorld var17 = var15.world;
      EntityStatusS2CPacket var16 = var31;
      Entity var7 = var16.getEntity((World)var17);
      int var44 = var4;
      Entity var43 = var7;
      Entity var33 = var43;
      Entity var32 = var43;
      if (var44 != 0) {
         boolean var45 = var32 instanceof PlayerEntity;
         if (!var45) {
            return;
         }

         Entity var46 = var7;
         var33 = var46;
      }

      PlayerEntity var47 = (PlayerEntity)var33;
      Object2IntMap var51 = this.a;
      PlayerEntity var20 = var47;
      UUID var22 = var20.getUuid();
      Object2IntMap var21 = var51;
      int var48 = var21.getOrDefault(var22, 0);
      Object2IntMap var52 = this.a;
      PlayerEntity var24 = var47;
      UUID var10001 = var24.getUuid();
      int var27 = ++var48;
      UUID var26 = var10001;
      Object2IntMap var25 = var52;
      var25.put(var26, var27);
   }

   @EventListener
   public void a(TickEvent var1) {
      int var4 = Event.cReturningInt();
      int var51 = var4;
      TotemPopTracker var50 = this;
      TotemPopTracker var38 = var50;
      TotemPopTracker var37 = var50;
      if (var51 != 0) {
         Object2IntMap var8 = var37.a;
         boolean var52 = var8.isEmpty();
         if (var52) {
            return;
         }

         var38 = this;
      }

      HashSet var11 = var38.c;
      var11.clear();
      MinecraftClient var12 = b;
      ClientWorld var13 = var12.world;
      List var14 = var13.getPlayers();
      Iterator var5 = var14.iterator();

      int var47;
      while (true) {
         Iterator var15 = var5;
         boolean var53 = var15.hasNext();
         if (var53) {
            Iterator var16 = var5;
            PlayerEntity var6 = (PlayerEntity)var16.next();
            PlayerEntity var17 = var6;
            UUID var7 = var17.getUuid();
            UUID var19 = var7;
            HashSet var18 = this.c;
            var18.add(var19);
            PlayerEntity var20 = var6;
            int var55 = var4;
            int var54 = var20.deathTime;
            var47 = var54;
            int var39 = var54;
            if (var55 == 0) {
               break;
            }

            int var57 = var4;
            int var56 = var39;
            int var40 = var56;
            label57:
            if (var57 != 0) {
               int var58 = var40;
               int var41 = var58;
               int var59 = var41;
               if (var59 <= 0) {
                  PlayerEntity var23 = var6;
                  float var76;
                  int var10000 = (var76 = var23.getHealth() - 0.0F) == 0.0F ? 0 : (var76 < 0.0F ? -1 : 1);
                  int var61 = var4;
                  int var60 = var10000;
                  int var42 = var60;
                  if (var61 == 0) {
                     break label57;
                  }

                  int var62 = var42;
                  int var43 = var62;
                  int var63 = var43;
                  if (var63 > 0) {
                     PlayerEntity var26 = var6;
                     boolean var74 = var26.isDead();
                     int var65 = var4;
                     boolean var64 = var74;
                     boolean var44 = var64;
                     if (var65 == 0) {
                        break label57;
                     }

                     boolean var66 = var44;
                     boolean var45 = var66;
                     boolean var67 = var45;
                     if (!var67) {
                        break label57;
                     }
                  }
               }

               UUID var30 = var7;
               Object2IntMap var29 = this.a;
               int var68 = var29.removeInt(var30);
            }

            int var69 = var4;
            if (var69 != 0) {
               continue;
            }
         }

         Object2IntMap var32 = this.a;
         var47 = (((var32.isEmpty()) ? 1 : 0));
         break;
      }

      int var71 = var4;
      int var70 = var47;
      int var48 = var70;
      if (var71 != 0) {
         int var72 = var48;
         if (var72 == 0) {
            Object2IntMap var34 = this.a;
            ObjectSet var75 = var34.keySet();
            HashSet var36 = this.c;
            ObjectSet var35 = var75;
            boolean var73 = var35.retainAll(var36);
         }
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      Object2IntMap var4 = this.a;
      var4.clear();
   }

   public int aReturningInt(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 104358862141707L ^ var2;
      Object2IntMap var8 = this.a;
      PlayerEntity var5 = var4;
      UUID var7 = var5.getUuid();
      Object2IntMap var6 = var8;
      return var6.getOrDefault(var7, 0);
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(77004251660427L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -3110689735739592011L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)212L,
            (byte)54484L,
            (byte)13948060L,
            (byte)3570703402L,
            (byte)914100071070L,
            (byte)234009618194121L,
            (byte)59906462257695154L,
            (byte)-3110689735739592011L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // e = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 0;
            yield var15;
         }
         case 1 -> {
            byte var16 = 47;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 51;
            yield var18;
         }
         case 4 -> {
            byte var19 = 14;
            yield var19;
         }
         case 5 -> {
            byte var20 = 31;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 3;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 60;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 1;
            yield var27;
         }
         case 13 -> {
            byte var28 = 61;
            yield var28;
         }
         case 14 -> {
            byte var29 = 46;
            yield var29;
         }
         case 15 -> {
            byte var30 = 50;
            yield var30;
         }
         case 16 -> {
            byte var31 = 35;
            yield var31;
         }
         case 17 -> {
            byte var32 = 52;
            yield var32;
         }
         case 18 -> {
            byte var33 = 62;
            yield var33;
         }
         case 19 -> {
            byte var34 = 43;
            yield var34;
         }
         case 20 -> {
            byte var35 = 37;
            yield var35;
         }
         case 21 -> {
            byte var36 = 29;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 13;
            yield var38;
         }
         case 24 -> {
            byte var39 = 49;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 40;
            yield var41;
         }
         case 27 -> {
            byte var42 = 12;
            yield var42;
         }
         case 28 -> {
            byte var43 = 26;
            yield var43;
         }
         case 29 -> {
            byte var44 = 38;
            yield var44;
         }
         case 30 -> {
            byte var45 = 25;
            yield var45;
         }
         case 31 -> {
            byte var46 = 56;
            yield var46;
         }
         case 32 -> {
            byte var47 = 30;
            yield var47;
         }
         case 33 -> {
            byte var48 = 21;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 27;
            yield var50;
         }
         case 36 -> {
            byte var51 = 5;
            yield var51;
         }
         case 37 -> {
            byte var52 = 42;
            yield var52;
         }
         case 38 -> {
            byte var53 = 11;
            yield var53;
         }
         case 39 -> {
            byte var54 = 17;
            yield var54;
         }
         case 40 -> {
            byte var55 = 54;
            yield var55;
         }
         case 41 -> {
            byte var56 = 41;
            yield var56;
         }
         case 42 -> {
            byte var57 = 33;
            yield var57;
         }
         case 43 -> {
            byte var58 = 6;
            yield var58;
         }
         case 44 -> {
            byte var59 = 58;
            yield var59;
         }
         case 45 -> {
            byte var60 = 63;
            yield var60;
         }
         case 46 -> {
            byte var61 = 44;
            yield var61;
         }
         case 47 -> {
            byte var62 = 53;
            yield var62;
         }
         case 48 -> {
            byte var63 = 23;
            yield var63;
         }
         case 49 -> {
            byte var64 = 32;
            yield var64;
         }
         case 50 -> {
            byte var65 = 9;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 18;
            yield var68;
         }
         case 54 -> {
            byte var69 = 19;
            yield var69;
         }
         case 55 -> {
            byte var70 = 7;
            yield var70;
         }
         case 56 -> {
            byte var71 = 16;
            yield var71;
         }
         case 57 -> {
            byte var72 = 28;
            yield var72;
         }
         case 58 -> {
            byte var73 = 55;
            yield var73;
         }
         case 59 -> {
            byte var74 = 15;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 4;
            yield var76;
         }
         case 62 -> {
            byte var77 = 10;
            yield var77;
         }
         default -> 34;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "\u001ej\u0010}\u0017b\u001ej\u0007!\u001bm\u0004!\u0007?\u001bx\u0003PUeO<";
      f[1] = "w-W>\u000bhi%MqpHT\b";
      f[2] = "'<\u00171\f\u00171<\u0012k\u001f\u0000&w\u0011m\u0013\u001470\u0006zX\u0001\u0019";
      f[3] = "\u0006Lo!Zr\rC~n9\u007f\u0018Nq\u0005\f}\t]m)\u001bp";
      f[4] = "tF\u0002\u0016\u001b$p[\u0002\u0007\u0006$3TM\u0010\u00018i[@M\u001a/wWO\u0017\u0006cRPF\u0006\u00169/{B\u00178,m";
      f[5] = "\t\u001dqnJ\u0014\u0002\u0012`!+\u001a\t\u0019d{";
      f[6] = int.class;
      g[6] = "java/lang/Integer";
      f[7] = "-\u001fVl\u001fi;\u001fS6\f~,TP0\u0000j=\u0013G'Kx\f";
      f[8] = "C`\u001d^kQC`\n\u0002g^Y+\n\u001cgK^ZZA6";
      f[9] = "U\u00150\u001eD!U\u0015'BH.O^'\\H;H/r\u0003\u0011";
      f[10] = "|29jLI|2.6@Ffy.(@Sa\b\u007fr\u0017\u0013";
      f[11] = "\u000f9(\u007f\u0004\"\u000f9?#\b-\u0015r?=\b8\u0012\u0003mhZ|";
      f[12] = "\u0014\u001fU\u001e\u0000P\u0014\u001fBB\f_\u000eTB\\\fJ\t%\u0010\u0002T\u000e";
      f[13] = "\u000b\"e\u001d\u0015N\u001d\"`G\u0006Y\nicA\nM\u001b.tVA\\\u000b";
      f[14] = "c_T\u0012Rf\u0016\u007f_\u001dC)wqT\u0016Gs\u0003";
      f[15] = "\u007f#%[1\u001e\u007f#2\u0007=\u0011eh2\u0019=\u0004b\u0019c@eA";
      f[16] = byte.class;
      g[16] = "java/lang/Byte";
      f[17] = void.class;
      g[17] = "java/lang/Void";
      f[18] = "Tp`\u0018f!BpeBu6U;fDy\"D|qS22\\|sXh\u007f`gsEh8Wp";
      f[19] = "\u0000H\u001fmK~\u0016H\u001a7Xi\u0001\u0003\u00191T}\u0010D\u000e&\u001fl(";
      f[20] = "yJD.nq\fjO!\u007f>mdD*{d\u0019";
      f[21] = "?7\u0001\u000e\u0014X!?\u001bAvD&\"";
      f[22] = "n,\u0018\u000e\n/p$\u0002Al;w%=\nP";
      f[23] = "?ni86:;si)+:x|&>,&\"s+c71<\u007f$9+}\u0019x-(;'\u0005\u007f3";
      f[24] = "*m\u0018'\u007f\u00054e\u0002h\u0012\u001f,`\u000b%%\u0019/b";
      f[25] = boolean.class;
      g[25] = "java/lang/Boolean";
      f[26] = "\u000b\u00171/+\f\u0015\u001f+`L\r\u0004\u0004&:j\u000b";
      f[27] = float.class;
      g[27] = "java/lang/Float";
      f[28] = "u[:\u0015\u001661T3{L'0K-\u0017~wr\u0015u{\u0010w V6\u0015\u0018+vWJ";
      f[29] = "\u0013P:\u001eI\nE@h\u0006'\rT\\TB\\\u0007T\\.A\u001e\u000bQ h\u001f\u0016\u0016X\u001f%\u0005J\u0016)\u001c2HD\u0004\u0016Q(\u0014Du";
      f[30] = "/\u0018a\"in:\u0005f+\u001b3>\u0007q:g58jjc#,?Uo?rlB";
      f[31] = "S\u001e=<aO_\u0014s3\\CnKd2?YQ\u0006~n?(";
      f[32] = "~\t\u001c\u0000d~{UM@\u0019'rIX~\":mDX\u0004!xaA$";
      f[33] = "W\b\u0019\"Q[\u0001\u0018K:?K\u0000\u00040?sI\u0003\u0011\n!C$V\u0003\u00058C^UA\t=?\u0018\u000bI\u00144\u0000U\u0011\u0015\u0014E\u0003B\\\u001b\u0006zNX\u0000\u001bw";
      f[34] = "#@ [KfgO)5\u0011wfP7Y#$\"\u000bj5\u0015j#\u00017O\rvgQP";
      f[35] = " yGl\"v1?Co\u0018qKo\u0013m `$r\fl$";
      f[36] = "EH\u0002\t]N@\u0014SI \u0011M\u0003|\u001aP\r$\u0018EIZLKEALJq";
      f[37] = "$\u0003\u001a\n3|r\u0013H\u0012]`s\u0002/\u0000!\u0003q\u001fH\bgx.\nI\u0017]";
      f[38] = "$$]\t\u0013Qs\"^\u001f\u007f\u0005w5P\u001e\u00137#y\fDA`w;Z\b\r\\b&]\u0001\u007f";
      f[39] = "@g{Ab=QahU\u000f?Jnb@\u000f>UreKpi\u0015e5:";
      f[40] = "H%f\f\u001d\\\r.b\u001daGq{:\u0006\fJ\u001f&.\f\u0001.K%>\u000b\u0005@\u001614\u0006a";
      f[41] = "8'$J6\u0015g2%U\f\u0014:7qNj'3/\u0018O7\u0014j+&Lw\u00020KxP2\u0014j$%T7\u0004W";
      f[42] = "GcrU>\"\u0011s MP<\u0006^yJ,,}sc\f*`\u0012.g\t:]";
      f[43] = "\u001eb\u0006\u001d\u0019\u0015Is\u000bB}\u0019Bs\u0012\u0011*N\u001d.I}C\u001aNn\u001aL\u0014\u001cMx";
      f[44] = "}\n\rb\u000e_2K\u0017fd[/L\n:\bi{\tVcU>}K\u001a;U\u0004=\u000b\u0010md\u000e/V\u0017$X_!\u000f\u000e]";
      f[45] = "8]:LB5)[)X/5:UJ\fT.+E0\u000f\u0016\".9*H\u0011&kVwL\u00146V";
      f[46] = "X\bE\u0013h\u001b\u000e\u0018\u0017\u000b\u0006\u001e\u000f\u001dL\nk%\u0004\u0004+O}\u0016\u001f\u0004QL?\u001a\u001ax\u0017\u00127\u0007\u0013GZ\bk\u0007b";
      f[47] = "\u0001Y\u007f\\\u0001EEVv2[TDIh^i\u0003\t\u00147\u000e>YG\u0017u\u000fQ\u0004C\u0012e2";
      f[48] = "\u0005nj{!GPg8dMI43dk?YL//j. ]&997RZ'?gM";
      f[49] = "\u001a}\fY(~\u0007b\r]Sxv~\u0003\f!h\u000ebH\r0\u0011\u001chC\u000f\"nK(T_S";
      f[50] = "\u0013jU'=aWe\\Il|G~I\u001e<'\u0013!%ud,Ik\u001a8~pI";
      f[51] = "$6-\u001b\u001f.kw7\u001fu*vp*C\u0019\u0018\"5v\u001bMOqh3FD)po5Bu";
      f[52] = "P:\biG\n\u0006*Zq)\u001e\u000e'\u000ft)\u001f\u0011;\b\u007fVHQ,X\u000e";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(386480795498629L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(386480795498629L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(386480795498629L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 253;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 244;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 170;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 87;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 71;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 192;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 253;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 244;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 170;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fZ_C0321",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fZ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
