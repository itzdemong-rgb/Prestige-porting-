package dev.zprestige.prestige.client.management;
import dev.zprestige.prestige.api.events.EntityRotationEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.rotation.Rotation;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class VisualRotationManager implements MinecraftAccess {
   private static final float a = 0.4F;
   private static final float c = 0.5F;
   private boolean d;
   private float e;
   private float f;
   private float g;
   private float h;
   private boolean i;
   private float j;
   private float k;
   private float l;
   private float m;
   private float n;
   private float o;
   private float p;
   private float q;
   private static final long r = 136399842879529L;
   private static final Object[] s = new Object[44];
   private static final String[] t = new String[44];

   public VisualRotationManager(long var1) {
      super();
      var1 = 136399842879529L ^ var1;
      long var3 = var1 ^ 82176569395186L;

      this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      EventBus var10000 = Prestige.b;
      Object[] var6 = new Object[]{this, var3};
      EventBus var5 = var10000;
      var5.aReturningVoid(var6);
   }

   @EventListener
   public void a(TickEvent var1) {
      int var4 = Event.bReturningInt();
      int var38 = var4;
      if (var38 == 0) {
         MinecraftClient var8 = b;
         ClientPlayerEntity var39 = var8.player;
         if (var39 != null) {
            int var41 = var4;
            VisualRotationManager var40 = this;
            VisualRotationManager var35 = var40;
            VisualRotationManager var34 = var40;
            if (var41 == 0) {
               boolean var42 = var34.d;
               if (var42) {
                  RotationManager var10000 = Prestige.o;
                  Object[] var18 = new Object[0];
                  RotationManager var17 = var10000;
                  Rotation var5 = var17.bReturningdx_C0210(var18);
                  int var45 = var4;
                  Rotation var44 = var5;
                  Rotation var37 = var44;
                  Rotation var36 = var44;
                  if (var45 == 0) {
                     Rotation var46 = var36;
                     if (var46 == null) {
                        MinecraftClient var20 = b;
                        ClientPlayerEntity var21 = var20.player;
                        this.e = var21.getYaw();
                        MinecraftClient var22 = b;
                        ClientPlayerEntity var23 = var22.player;
                        this.f = var23.getPitch();
                        this.g = this.e;
                        this.h = this.f;
                        return;
                     }

                     this.g = this.e;
                     this.h = this.f;
                     var37 = var5;
                  }

                  Object[] var26 = new Object[0];
                  Rotation var25 = var37;
                  float var27 = var25.aReturningFloat(var26) - this.e;
                  float var6 = MathHelper.wrapDegrees(var27);
                  Object[] var29 = new Object[0];
                  Rotation var28 = var5;
                  float var7 = var28.bReturningFloat(var29) - this.f;
                  float var30 = this.e + var6 * 0.4F;
                  this.e = MathHelper.wrapDegrees(var30);
                  float var10001 = this.f + var7 * 0.4F;
                  float var33 = 90.0F;
                  float var32 = -90.0F;
                  float var31 = var10001;
                  this.f = MathHelper.clamp(var31, var32, var33);
                  return;
               }

               MinecraftClient var12 = b;
               ClientPlayerEntity var13 = var12.player;
               this.e = var13.getYaw();
               MinecraftClient var14 = b;
               ClientPlayerEntity var15 = var14.player;
               this.f = var15.getPitch();
               this.g = this.e;
               this.h = this.f;
               VisualRotationManager var43 = this;
               var35 = var43;
            }

            var35.d = dev.prestige.recovery.SourceSupport.asBoolean(1);
            return;
         }

         this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
      }
   }

   @EventListener
   public void a(EntityRotationEvent var1) {
      int var4 = Event.bReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var105 = var7.player;
      Entity var104 = var1.a;
      if (var104 == var105) {
         boolean var106 = this.d;
         if (var106) {
            Object[] var11 = new Object[0];
            EntityRotationEvent var10 = var1;
            EventPhase var10000 = var10.aReturningEventPhase(var11);
            int var109 = var4;
            EventPhase var108 = EventPhase.PRE;
            EventPhase var107 = var10000;
            EventPhase var99 = var107;
            EventPhase var100 = var108;
            EventPhase var97 = var107;
            EventPhase var98 = var108;
            if (var109 == 0) {
               EventPhase var111 = var98;
               EventPhase var110 = var97;
               if (var110 == var111) {
                  boolean var112 = this.i;
                  if (var112) {
                     return;
                  }

                  RotationManager var127 = Prestige.o;
                  Object[] var16 = new Object[0];
                  RotationManager var15 = var127;
                  Rotation var113 = var15.bReturningdx_C0210(var16);
                  if (var113 == null) {
                     return;
                  }

                  MinecraftClient var18 = b;
                  ClientPlayerEntity var19 = var18.player;
                  float var20 = this.e - var19.getYaw();
                  float var21 = MathHelper.wrapDegrees(var20);
                  float var5 = Math.abs(var21);
                  MinecraftClient var22 = b;
                  ClientPlayerEntity var23 = var22.player;
                  float var24 = this.f - var23.getPitch();
                  float var6 = Math.abs(var24);
                  int var114 = var4;
                  if (var114 == 0) {
                     float var129;
                     int var115 = (var129 = var5 - 0.5F) == 0.0F ? 0 : (var129 < 0.0F ? -1 : 1);
                     if (var115 < 0) {
                        float var130;
                        int var116 = (var130 = var6 - 0.5F) == 0.0F ? 0 : (var130 < 0.0F ? -1 : 1);
                        if (var116 < 0) {
                           return;
                        }
                     }

                     MinecraftClient var28 = b;
                     ClientPlayerEntity var29 = var28.player;
                     this.j = var29.getYaw();
                     MinecraftClient var30 = b;
                     ClientPlayerEntity var31 = var30.player;
                     this.k = var31.getPitch();
                     MinecraftClient var32 = b;
                     ClientPlayerEntity var33 = var32.player;
                     this.l = var33.bodyYaw;
                     MinecraftClient var34 = b;
                     ClientPlayerEntity var35 = var34.player;
                     this.m = var35.headYaw;
                     MinecraftClient var36 = b;
                     ClientPlayerEntity var37 = var36.player;
                     this.n = var37.lastYaw;
                     MinecraftClient var38 = b;
                     ClientPlayerEntity var39 = var38.player;
                     this.o = var39.lastPitch;
                     MinecraftClient var40 = b;
                     ClientPlayerEntity var41 = var40.player;
                     this.p = var41.lastBodyYaw;
                     MinecraftClient var42 = b;
                     ClientPlayerEntity var43 = var42.player;
                     this.q = var43.lastHeadYaw;
                     MinecraftClient var44 = b;
                     float var46 = this.e;
                     ClientPlayerEntity var45 = var44.player;
                     var45.setYaw(var46);
                     MinecraftClient var47 = b;
                     float var49 = this.f;
                     ClientPlayerEntity var48 = var47.player;
                     var48.setPitch(var49);
                     MinecraftClient var50 = b;
                     float var52 = this.e;
                     ClientPlayerEntity var51 = var50.player;
                     var51.bodyYaw = var52;
                     MinecraftClient var53 = b;
                     float var55 = this.e;
                     ClientPlayerEntity var54 = var53.player;
                     var54.headYaw = var55;
                     MinecraftClient var56 = b;
                     float var58 = this.g;
                     ClientPlayerEntity var57 = var56.player;
                     var57.lastYaw = var58;
                     MinecraftClient var59 = b;
                     float var61 = this.h;
                     ClientPlayerEntity var60 = var59.player;
                     var60.lastPitch = var61;
                     MinecraftClient var62 = b;
                     float var64 = this.g;
                     ClientPlayerEntity var63 = var62.player;
                     var63.lastBodyYaw = var64;
                     MinecraftClient var65 = b;
                     float var67 = this.g;
                     ClientPlayerEntity var66 = var65.player;
                     var66.lastHeadYaw = var67;
                     this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  }

                  int var117 = var4;
                  if (var117 == 0) {
                     return;
                  }
               }

               Object[] var69 = new Object[0];
               EntityRotationEvent var68 = var1;
               var10000 = var68.aReturningEventPhase(var69);
               EventPhase var119 = EventPhase.POST;
               EventPhase var118 = var10000;
               var99 = var118;
               var100 = var119;
            }

            EventPhase var121 = var100;
            EventPhase var120 = var99;
            if (var120 == var121) {
               int var123 = var4;
               VisualRotationManager var122 = this;
               VisualRotationManager var103 = var122;
               VisualRotationManager var101 = var122;
               if (var123 == 0) {
                  VisualRotationManager var124 = var101;
                  VisualRotationManager var102 = var124;
                  boolean var125 = var102.i;
                  if (!var125) {
                     return;
                  }

                  MinecraftClient var73 = b;
                  float var75 = this.j;
                  ClientPlayerEntity var74 = var73.player;
                  var74.setYaw(var75);
                  MinecraftClient var76 = b;
                  float var78 = this.k;
                  ClientPlayerEntity var77 = var76.player;
                  var77.setPitch(var78);
                  MinecraftClient var79 = b;
                  float var81 = this.l;
                  ClientPlayerEntity var80 = var79.player;
                  var80.bodyYaw = var81;
                  MinecraftClient var82 = b;
                  float var84 = this.m;
                  ClientPlayerEntity var83 = var82.player;
                  var83.headYaw = var84;
                  MinecraftClient var85 = b;
                  float var87 = this.n;
                  ClientPlayerEntity var86 = var85.player;
                  var86.lastYaw = var87;
                  MinecraftClient var88 = b;
                  float var90 = this.o;
                  ClientPlayerEntity var89 = var88.player;
                  var89.lastPitch = var90;
                  MinecraftClient var91 = b;
                  float var93 = this.p;
                  ClientPlayerEntity var92 = var91.player;
                  var92.lastBodyYaw = var93;
                  MinecraftClient var94 = b;
                  float var96 = this.q;
                  ClientPlayerEntity var95 = var94.player;
                  var95.lastHeadYaw = var96;
                  VisualRotationManager var126 = this;
                  var103 = var126;
               }

               var103.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
            }

            return;
         }
      }
   }

   public boolean aReturningBoolean(Object[] var1) {
      return this.i;
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = t[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = s[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 27;
            yield var15;
         }
         case 1 -> {
            byte var16 = 14;
            yield var16;
         }
         case 2 -> {
            byte var17 = 26;
            yield var17;
         }
         case 3 -> {
            byte var18 = 45;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 60;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 54;
            yield var22;
         }
         case 8 -> {
            byte var23 = 2;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 22;
            yield var26;
         }
         case 12 -> {
            byte var27 = 21;
            yield var27;
         }
         case 13 -> {
            byte var28 = 32;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 0;
            yield var30;
         }
         case 16 -> {
            byte var31 = 49;
            yield var31;
         }
         case 17 -> {
            byte var32 = 57;
            yield var32;
         }
         case 18 -> {
            byte var33 = 12;
            yield var33;
         }
         case 19 -> {
            byte var34 = 8;
            yield var34;
         }
         case 20 -> {
            byte var35 = 61;
            yield var35;
         }
         case 21 -> {
            byte var36 = 24;
            yield var36;
         }
         case 22 -> {
            byte var37 = 40;
            yield var37;
         }
         case 23 -> {
            byte var38 = 58;
            yield var38;
         }
         case 24 -> {
            byte var39 = 44;
            yield var39;
         }
         case 25 -> {
            byte var40 = 1;
            yield var40;
         }
         case 26 -> {
            byte var41 = 31;
            yield var41;
         }
         case 27 -> {
            byte var42 = 15;
            yield var42;
         }
         case 28 -> {
            byte var43 = 17;
            yield var43;
         }
         case 29 -> {
            byte var44 = 42;
            yield var44;
         }
         case 30 -> {
            byte var45 = 35;
            yield var45;
         }
         case 31 -> {
            byte var46 = 10;
            yield var46;
         }
         case 32 -> {
            byte var47 = 43;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 23;
            yield var50;
         }
         case 36 -> {
            byte var51 = 16;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 47;
            yield var53;
         }
         case 39 -> {
            byte var54 = 20;
            yield var54;
         }
         case 40 -> {
            byte var55 = 7;
            yield var55;
         }
         case 41 -> {
            byte var56 = 28;
            yield var56;
         }
         case 42 -> {
            byte var57 = 36;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 52;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 4;
            yield var61;
         }
         case 47 -> {
            byte var62 = 13;
            yield var62;
         }
         case 48 -> {
            byte var63 = 53;
            yield var63;
         }
         case 49 -> {
            byte var64 = 18;
            yield var64;
         }
         case 50 -> {
            byte var65 = 9;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 46;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 33;
            yield var69;
         }
         case 55 -> {
            byte var70 = 29;
            yield var70;
         }
         case 56 -> {
            byte var71 = 56;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 62;
            yield var73;
         }
         case 59 -> {
            byte var74 = 63;
            yield var74;
         }
         case 60 -> {
            byte var75 = 55;
            yield var75;
         }
         case 61 -> {
            byte var76 = 3;
            yield var76;
         }
         case 62 -> {
            byte var77 = 39;
            yield var77;
         }
         default -> 37;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            t[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      s[0] = "Y\u001c\u0000\u0017?qO\u001c\u0005M,fXW\u0006K rI\u0010\u0011\\ke~";
      s[1] = "Cm!@|*Hb0\u000f\u001f']o?d*%L|#H=(";
      s[2] = ",.nDo\u0012,.y\u0018c\u001d6ey\u0006c\b1\u0014-^4";
      s[3] = float.class;
      t[3] = "java/lang/Float";
      s[4] = "WVrO3^AVw\u0015 IV\u001dt\u0013,]GZc\u0004gOv";
      s[5] = int.class;
      t[5] = "java/lang/Integer";
      s[6] = "=I^lj\u0001HiUc{N)g^h\u007f\u0014]";
      s[7] = "T\u001c\u000eP-\nB\u001c\u000b\n>\u001dUW\b\f2\tD\u0010\u001f\u001by\r";
      s[8] = void.class;
      t[8] = "java/lang/Void";
      s[9] = "Vy5\u000f@\u0007Vy\"SL\bL2\"ML\u001dKCr\u0010\u001d";
      s[10] = "A$Nd[/W$K>H8@oH8D,Q(_/\u000f<I(]$Uqu3]9U6B$";
      s[11] = "~\u001dF~:$h\u001dC$)3\u007fV@\"%'n\u0011W5n0c";
      s[12] = "n:nUb\u0011\u001b\u001aeZs^z\u0014nQw\u0004\u000e";
      s[13] = ")\u0003G)qm?\u0003Bsbz(HAunn9\u000fVb%y5";
      s[14] = "\u0001wky!%\nxz6B(\u001f~";
      s[15] = "_\u0014/;:9_\u00148g66E_8y6#B.h db";
      s[16] = "D\"\u001e\u0018L*R\"\u001bB_=Ei\u0018DS)T.\u000fS\u00188l";
      s[17] = "\u0010\u000f\u000e,\"1e/\u0005#3~\u0004!\u000e(7$p";
      s[18] = "Su\n\u001eN\u0004&U\u0001\u0011_KG[\n\u001a[\u00113";
      s[19] = "g7e\u0015\u0005j\u0012\u0017n\u001a\u0014%s\u0019e\u0011\u0010\u007f\u0007";
      s[20] = "8\u0019\u001bz\u0005^3\u0016\n5dP8\u001d\u000eo";
      s[21] = "JBQSlN\u0012O@+:7BNA[lQ\u0005\fB\u001aS\u000eF\u001e\\\u00145I\u0004\u001d\u001d+";
      s[22] = "pK~\u0014~l F|\u000eO9(B&\u0000\u0018iq\u0017~lu7.Sr\u0000*06K";
      s[23] = "J!]2C\u0015\u001a,_(r@\u0012(\u0005&%\u0010IxPJHN\u00149Q&\u0017I\f!";
      s[24] = "^64\u007f\u000b\u007f\u0007`*`v+e5#r\u00128\u0002i\"p\u0017A";
      s[25] = "\nfqvkJZkslZ\u001fRo)b\rO\t2v\u000e`\u0011T~}b?\u0016Lf";
      s[26] = "e:}k[457\u007fqja=3%\u007f=1fdy\u0013Po;\"q\u007f\u000fh#:";
      s[27] = "5\u0016\u0007f\u0012Me\u001b\u0005|#\u0013a\u000e[yO!7L\u0007#\u001fv6\u0012\\b\u0013\u001ai\u0015Dz#";
      s[28] = "ZwBz8 \u0004e\u00071\u0007rk{\u00162k&\u0017i\u0013tg\u0018Qw\u001b67t\u000ep\u0003.\u0007";
      s[29] = "\u0011\u0004\u0000\np\u0015HR\u001e\u0015\rB*P\u001a\u0010a\u0015VB\u001fVm+\u0017\r\u0017\u0010}GMQM\u0003\r";
      s[30] = "s\u000b6\u007f\u00121#\u00064e#o'\u0013j`O]qQ6:\u001c\np\u000fm{\u0013f/\buc#71\u000bjzCw*V;\u0007";
      s[31] = "\u001b \u001d\u0006\u0015\nK-\u001f\u001c$_C)E\u0012s\f\u0013t\u001b~\u001eQE8\u0011\u0012AV] ";
      s[32] = "NPAa\u0004B\u001e]C{5\u001c\u001aH\u001d~Y.L\nA$\byMT\u001ae\u0005\u0015\u0012S\u0002}5";
      s[33] = "s%HS\u0006=+3\u0016]b*w>I^\u000e\u0018#\u007f\u0012\u0007YO \"NER#\u007f%V]buz%U\t\u000e*}=M9X/}>\u0019U\u0007(e&)\u0003\u0002(frE\\\u00050~B";
      s[34] = "n\u00166N;Fm\r6CEI1\u0007#@\u0012\u001eoP{,|Cl\u0012v\u0017,Nn\b";
      s[35] = ")p1Yc\\h\u007fzA[U\u0016$g_gH}'fDe";
      s[36] = "6`Dt\u001c`5a_vfa\tkN0\n5uyKv\u0006\u000b8g\u001axY3fu_3f";
      s[37] = "\fT\u001d1B\u000fRFXz}^=XIy\u0011\tAJL?\u001d7\u0007TD}M[XS\\e}";
      s[38] = "L\u0014\u0000\u0015\u0018\u0012\u001eJ\u0016@!\u001bOQx\u0016A\u0015Y\u001a\u0014IF\rA*BLF\u000e\u0015F\u001dK^\u0016%";
      s[39] = "]\u001c?+#\u0002\u001c\u0013t3\u001b\u0006b\u001dk\"x\u000e\u0007\u0010utq";
      s[40] = "\u0007S\u0005Z@*\nMSS\"&mZ\u0000ANq\u0011H\u0005\u0007BOPM\u000eY_/\u0010VS\b\"";
      s[41] = "7!\t\u0003#~o7W\rGi3:\b\u000e+[g{SX|\fd&\u000f\u0015w`;!\u0017\rG6>!\u0014Y+i99\fi";
      s[42] = "Rqq-Y\r\u0002|s7hX\nx)9?\bQ)tURV\fi}9\rQ\u0014q";
      s[43] = "\u0001H--(oQE/7\u00191UPq2u\u0003\u0003\u0012-h'T\u0002Lv))8]Kn1\u0019iCHq(y)X\u0015 U";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = s[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(t[var4]);
            s[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = s[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            s[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  s[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1476195521058226L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = s[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  s[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1476195521058226L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        s[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1476195521058226L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 119;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 116;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 230;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 209;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 219;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 119;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 116;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 230;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dC_C0169",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
