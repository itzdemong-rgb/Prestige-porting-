package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {
   private ModeSetting a;
   private ModeSetting c;
   private FloatSetting d;
   private FloatSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private BooleanSetting j;
   private BooleanSetting k;
   private BooleanSetting l;
   private BooleanSetting m;
   private FloatSetting n;
   private FloatSetting o;
   private FloatSetting p;
   private BooleanSetting q;
   private FloatSetting r;
   private BooleanSetting s;
   private FloatSetting t;
   private BooleanSetting u;
   private BooleanSetting v;
   private Entity w;
   private ElapsedTimer x;
   private float y;
   private double[] z;
   private float A;
   private float B;
   private static final long C = 90093651303927L;
   private static final String[] D;
   private static final String[] E;
   private static final Map F = new HashMap(13);
   private static final Object[] G = new Object[157];
   private static final String[] H = new String[157];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   public AimAssist() {
      super();
      long var10001 = 75111396087362L ^ 41071224103275L;
      var10001 = 75111396087362L ^ 100222770848917L;
      var10001 = 75111396087362L ^ 22614958169582L;

      this.x = new ElapsedTimer(106698256430889L);
      this.y = 0.0F;
      this.z = new double[]{0.0, 0.0};
      this.A = 0.0F;
      this.B = 0.0F;
      BooleanSetting var10000 = this.j;
      Object[] var10 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var9 = var10000;
      var9.aReturningBooleanSetting(var10);
      var10000 = this.l;
      Object[] var12 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var11 = var10000;
      var11.aReturningBooleanSetting(var12);
      FloatSetting var26 = this.t;
      Object[] var14 = new Object[]{invokeBinding3(this), 34595201528535L};
      FloatSetting var13 = var26;
      var13.aReturningFloatSetting(var14);
      var10000 = this.k;
      Object[] var16 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var15 = var10000;
      var15.aReturningBooleanSetting(var16);
      var10000 = this.u;
      Object[] var18 = new Object[]{invokeBinding5(this), 88791076916140L};
      BooleanSetting var17 = var10000;
      var17.aReturningBooleanSetting(var18);
      var10000 = this.s;
      Object[] var20 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var19 = var10000;
      var19.aReturningBooleanSetting(var20);
      var10000 = this.m;
      Object[] var22 = new Object[]{invokeBinding7(this), 88791076916140L};
      BooleanSetting var21 = var10000;
      var21.aReturningBooleanSetting(var22);
      FloatSetting var31 = this.r;
      Object[] var24 = new Object[]{invokeBinding8(this), 34595201528535L};
      FloatSetting var23 = var31;
      var23.aReturningFloatSetting(var24);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 80069467027743L ^ 87330539272428L;
      var10001 = 80069467027743L ^ 121117885255967L;
      var10001 = 80069467027743L ^ 59721237491467L;
      var10001 = 80069467027743L ^ 122293560770782L;
      var10001 = 80069467027743L ^ 122736969329390L;
      var10001 = 80069467027743L ^ 69747818867570L;
      var10001 = 80069467027743L ^ 29852170263467L;
      var10001 = 80069467027743L ^ 98286514054819L;
      var10001 = 80069467027743L ^ 49242865262578L;
      var10001 = 80069467027743L ^ 15862247591178L;
      var10001 = 80069467027743L ^ 68017662279138L;
      int var26 = Event.cReturningInt();
      int var457 = var26;
      MinecraftClient var456 = b;
      MinecraftClient var351 = var456;
      MinecraftClient var350 = var456;
      if (var457 != 0) {
         MinecraftClient var44 = var350;
         Screen var458 = var44.currentScreen;
         if (var458 != null) {
            return;
         }

         MinecraftClient var459 = b;
         var351 = var459;
      }

      MinecraftClient var47 = var351;
      int var10000 = (((var47.isWindowFocused()) ? 1 : 0));
      int var461 = var26;
      boolean var460 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var353 = var460;
      boolean var352 = var460;
      if (var461 != 0) {
         boolean var462 = var352;
         if (!var462) {
            return;
         }

         var353 = AutoObbyCrystal.R;
      }

      int var464 = var26;
      boolean var463 = var353;
      boolean var355 = var463;
      boolean var354 = var463;
      if (var464 != 0) {
         boolean var465 = var354;
         if (var465) {
            return;
         }

         BooleanSetting var50 = this.i;
         Boolean var51 = (Boolean)var50.aReturningObject();
         var355 = var51;
      }

      boolean var364;
      int var467 = var26;
      boolean var466 = var355;
      var364 = var466;
      boolean var356 = var466;
      label502:
      if (var467 != 0) {
         Object var363;
         label500: {
            boolean var468 = var356;
            if (var468) {
               MinecraftClient var53 = b;
               int var470 = var26;
               HitResult var469 = var53.crosshairTarget;
               var363 = var469;
               HitResult var357 = var469;
               if (var470 == 0) {
                  break label500;
               }

               HitResult var471 = var357;
               HitResult var358 = var471;
               HitResult var472 = var358;
               if (var472 != null) {
                  MinecraftClient var56 = b;
                  HitResult var57 = var56.crosshairTarget;
                  Type var669 = var57.getType();
                  int var474 = var26;
                  Type var473 = var669;
                  var363 = var473;
                  Type var359 = var473;
                  if (var474 == 0) {
                     break label500;
                  }

                  Type var475 = var359;
                  Type var360 = var475;
                  Type var477 = Type.BLOCK;
                  Type var476 = var360;
                  if (var476 == var477) {
                     MinecraftClient var60 = b;
                     GameOptions var61 = var60.options;
                     KeyBinding var62 = var61.attackKey;
                     var10000 = (((var62.isPressed()) ? 1 : 0));
                     int var479 = var26;
                     boolean var478 = ((((int)(var10000) & 1) != 0));
                     var364 = var478;
                     boolean var361 = var478;
                     if (var479 == 0) {
                        break label502;
                     }

                     boolean var480 = var361;
                     boolean var362 = var480;
                     boolean var481 = var362;
                     if (var481) {
                        return;
                     }
                  }
               }
            }

            ModeSetting var65 = this.a;
            var363 = var65.aReturningObject();
         }

         String var671 = (String)var363;
         String var67 = "Players";
         String var66 = var671;
         var364 = var66.equals(var67);
      }

      AimAssist var384;
      label516: {
         boolean var377;
         int var483 = var26;
         boolean var482 = var364;
         var377 = var482;
         boolean var365 = var482;
         label486:
         if (var483 != 0) {
            boolean var484 = var365;
            if (var484) {
               boolean var372;
               BooleanSetting var69 = this.j;
               Boolean var70 = (Boolean)var69.aReturningObject();
               var10000 = ((((java.lang.Boolean)(var70)).booleanValue() ? 1 : 0));
               int var486 = var26;
               boolean var485 = ((((int)(var10000) & 1) != 0));
               var372 = var485;
               boolean var366 = var485;
               label481:
               if (var486 != 0) {
                  boolean var487 = var366;
                  boolean var367 = var487;
                  boolean var488 = var367;
                  if (var488) {
                     MinecraftClient var73 = b;
                     ClientPlayerEntity var74 = var73.player;
                     Object[] var75 = new Object[]{var74.getMainHandStack(), 19476550655932L};
                     var10000 = (((InventoryUtil.aReturningBoolean(var75)) ? 1 : 0));
                     int var490 = var26;
                     boolean var489 = ((((int)(var10000) & 1) != 0));
                     var372 = var489;
                     boolean var368 = var489;
                     if (var490 == 0) {
                        break label481;
                     }

                     boolean var491 = var368;
                     boolean var369 = var491;
                     boolean var492 = var369;
                     if (!var492) {
                        Object[] var78 = new Object[]{92307976266420L};
                        var10000 = (((InventoryUtil.aReturningItem(var78) instanceof AxeItem) ? 1 : 0));
                        int var494 = var26;
                        boolean var493 = ((((int)(var10000) & 1) != 0));
                        var372 = var493;
                        boolean var370 = var493;
                        if (var494 == 0) {
                           break label481;
                        }

                        boolean var495 = var370;
                        boolean var371 = var495;
                        boolean var496 = var371;
                        if (!var496) {
                           return;
                        }
                     }
                  }

                  BooleanSetting var81 = this.l;
                  Boolean var82 = (Boolean)var81.aReturningObject();
                  var372 = var82;
               }

               int var498 = var26;
               boolean var497 = var372;
               var377 = var497;
               boolean var373 = var497;
               if (var498 == 0) {
                  break label486;
               }

               boolean var499 = var373;
               if (var499) {
                  MinecraftClient var84 = b;
                  GameOptions var85 = var84.options;
                  KeyBinding var86 = var85.attackKey;
                  var10000 = (((var86.isPressed()) ? 1 : 0));
                  int var501 = var26;
                  boolean var500 = ((((int)(var10000) & 1) != 0));
                  var377 = var500;
                  boolean var374 = var500;
                  if (var501 == 0) {
                     break label486;
                  }

                  boolean var502 = var374;
                  boolean var375 = var502;
                  boolean var503 = var375;
                  if (!var503) {
                     return;
                  }
               }
            }

            int var505 = var26;
            AimAssist var504 = this;
            var384 = var504;
            AimAssist var376 = var504;
            if (var505 == 0) {
               break label516;
            }

            ModeSetting var89 = var376.a;
            String var676 = (String)var89.aReturningObject();
            String var91 = "Crystals";
            String var90 = var676;
            boolean var506 = var90.equals(var91);
            var377 = var506;
         }

         boolean var507 = var377;
         if (var507) {
            boolean var383;
            BooleanSetting var93 = this.k;
            Boolean var94 = (Boolean)var93.aReturningObject();
            var10000 = ((((java.lang.Boolean)(var94)).booleanValue() ? 1 : 0));
            int var509 = var26;
            boolean var508 = ((((int)(var10000) & 1) != 0));
            var383 = var508;
            boolean var378 = var508;
            label459:
            if (var509 != 0) {
               boolean var510 = var378;
               boolean var379 = var510;
               boolean var511 = var379;
               if (var511) {
                  Object[] var97 = new Object[]{Items.END_CRYSTAL, 8519502184947L};
                  var10000 = (((InventoryUtil.lReturningBoolean(var97)) ? 1 : 0));
                  int var513 = var26;
                  boolean var512 = ((((int)(var10000) & 1) != 0));
                  var383 = var512;
                  boolean var380 = var512;
                  if (var513 == 0) {
                     break label459;
                  }

                  boolean var514 = var380;
                  boolean var381 = var514;
                  boolean var515 = var381;
                  if (!var515) {
                     return;
                  }
               }

               int var517 = var26;
               AimAssist var516 = this;
               var384 = var516;
               AimAssist var382 = var516;
               if (var517 == 0) {
                  break label516;
               }

               BooleanSetting var100 = var382.m;
               Boolean var101 = (Boolean)var100.aReturningObject();
               boolean var518 = var101;
               var383 = var518;
            }

            boolean var519 = var383;
            if (var519) {
               MinecraftClient var103 = b;
               GameOptions var104 = var103.options;
               KeyBinding var105 = var104.useKey;
               boolean var520 = var105.isPressed();
               if (!var520) {
                  return;
               }
            }
         }

         var384 = this;
      }

      byte var410;
      label449: {
         label448: {
            AimAssist var409;
            label521: {
               Entity var27;
               Entity var406;
               label522: {
                  label445: {
                     AimAssist var404;
                     label523: {
                        boolean var401;
                        label443: {
                           Object var400;
                           var27 = var384.w;
                           int var522 = var26;
                           Entity var521 = this.w;
                           var400 = var521;
                           Entity var385 = var521;
                           label442:
                           if (var522 != 0) {
                              Entity var523 = var385;
                              label440:
                              if (var523 != null) {
                                 int var525 = var26;
                                 Entity var524 = this.w;
                                 Entity var388 = var524;
                                 Entity var386 = var524;
                                 if (var525 != 0) {
                                    Entity var526 = var386;
                                    Entity var387 = var526;
                                    Entity var110 = var387;
                                    boolean var527 = var110.isAlive();
                                    if (!var527) {
                                       this.w = null;
                                       int var528 = var26;
                                       if (var528 != 0) {
                                          break label440;
                                       }
                                    }

                                    Entity var529 = this.w;
                                    var388 = var529;
                                 }

                                 AimAssist var393;
                                 label526: {
                                    Entity var114 = var388;
                                    Vec3d var28 = var114.getEyePos();
                                    MinecraftClient var115 = b;
                                    Vec3d var116 = var28;
                                    Vec3d var117 = var28;
                                    Vec3d var118 = var28;
                                    double var124 = var118.z;
                                    double var122 = var117.y;
                                    double var120 = var116.x;
                                    ClientPlayerEntity var119 = var115.player;
                                    double var126 = var119.squaredDistanceTo(var120, var122, var124);
                                    double var679 = Math.sqrt(var126);
                                    FloatSetting var128 = this.e;
                                    Float var129 = (Float)var128.aReturningObject();
                                    double var740;
                                    var10000 = (var740 = var679 - var129.floatValue()) == 0.0 ? 0 : (var740 < 0.0 ? -1 : 1);
                                    int var531 = var26;
                                    int var530 = var10000;
                                    int var392 = var530;
                                    int var389 = var530;
                                    if (var531 != 0) {
                                       int var532 = var389;
                                       if (var532 > 0) {
                                          this.w = null;
                                          int var533 = var26;
                                          if (var533 != 0) {
                                             break label440;
                                          }
                                       }

                                       int var535 = var26;
                                       AimAssist var534 = this;
                                       var393 = var534;
                                       AimAssist var390 = var534;
                                       if (var535 == 0) {
                                          break label526;
                                       }

                                       AimAssist var536 = var390;
                                       AimAssist var391 = var536;
                                       FloatSetting var133 = var391.d;
                                       Float var134 = (Float)var133.aReturningObject();
                                       float var741;
                                       int var537 = (var741 = var134 - 360.0F) == 0.0F ? 0 : (var741 < 0.0F ? -1 : 1);
                                       var392 = var537;
                                    }

                                    int var538 = var392;
                                    if (var538 < 0) {
                                       Object[] var136 = new Object[]{var28, 43890541083073L};
                                       Rotation var29 = RotationUtil.aReturningdx_C0210(var136);
                                       MinecraftClient var137 = b;
                                       ClientPlayerEntity var138 = var137.player;
                                       float var10002 = var138.getYaw();
                                       MinecraftClient var139 = b;
                                       ClientPlayerEntity var140 = var139.player;
                                       Rotation var681 = new Rotation(var10002, var140.getPitch());
                                       FloatSetting var141 = this.d;
                                       Float var142 = (Float)var141.aReturningObject();
                                       var10002 = var142;
                                       Object[] var10005 = new Object[]{null, null, null, 110069800658669L};
                                       var10005[2] = var10002;
                                       var10005[1] = var29;
                                       var10005[0] = var681;
                                       Object[] var143 = var10005;
                                       boolean var539 = RotationUtil.fReturningBoolean(var143);
                                       if (!var539) {
                                          this.w = null;
                                       }
                                    }

                                    var393 = this;
                                 }

                                 int var541 = var26;
                                 Entity var540 = var393.w;
                                 var400 = var540;
                                 Entity var394 = var540;
                                 if (var541 == 0) {
                                    break label442;
                                 }

                                 Entity var542 = var394;
                                 if (var542 != null) {
                                    BooleanSetting var146 = this.g;
                                    Boolean var147 = (Boolean)var146.aReturningObject();
                                    boolean var682 = var147;
                                    int var544 = var26;
                                    boolean var543 = var682;
                                    var401 = var543;
                                    boolean var395 = var543;
                                    if (var544 == 0) {
                                       break label443;
                                    }

                                    boolean var545 = var395;
                                    boolean var396 = var545;
                                    boolean var546 = var396;
                                    if (!var546) {
                                       MinecraftClient var150 = b;
                                       Entity var152 = this.w;
                                       ClientPlayerEntity var151 = var150.player;
                                       var682 = var151.canSee(var152);
                                       int var548 = var26;
                                       boolean var547 = var682;
                                       var401 = var547;
                                       boolean var397 = var547;
                                       if (var548 == 0) {
                                          break label443;
                                       }

                                       boolean var549 = var397;
                                       boolean var398 = var549;
                                       boolean var550 = var398;
                                       if (!var550) {
                                          this.w = null;
                                       }
                                    }
                                 }
                              }

                              int var552 = var26;
                              AimAssist var551 = this;
                              var404 = var551;
                              AimAssist var399 = var551;
                              if (var552 == 0) {
                                 break label523;
                              }

                              BooleanSetting var156 = var399.f;
                              Object var553 = var156.aReturningObject();
                              var400 = var553;
                           }

                           Boolean var158 = (Boolean)var400;
                           var401 = var158;
                        }

                        boolean var554 = var401;
                        if (var554) {
                           int var556 = var26;
                           Entity var555 = this.w;
                           var406 = var555;
                           Entity var402 = var555;
                           if (var556 == 0) {
                              break label522;
                           }

                           Entity var557 = var402;
                           Entity var403 = var557;
                           Entity var558 = var403;
                           if (var558 != null) {
                              break label445;
                           }
                        }

                        var404 = this;
                     }

                     Object[] var162 = new Object[]{77788694557717L};
                     AimAssist var161 = this;
                     var404.w = var161.aReturningEntity(var162);
                  }

                  int var560 = var26;
                  AimAssist var559 = this;
                  var409 = var559;
                  AimAssist var405 = var559;
                  if (var560 == 0) {
                     break label521;
                  }

                  Entity var561 = var405.w;
                  var406 = var561;
               }

               Entity var562 = var406;
               if (var562 != null) {
                  Entity var165 = var27;
                  Entity var164 = this.w;
                  byte var684 = ((byte)((var164.equals(var165)) ? 1 : 0));
                  int var564 = var26;
                  byte var563 = var684;
                  var410 = var563;
                  byte var407 = var563;
                  if (var564 == 0) {
                     break label449;
                  }

                  byte var565 = var407;
                  byte var408 = var565;
                  byte var566 = var408;
                  if (((var566) != 0)) {
                     break label448;
                  }
               }

               ElapsedTimer var685 = this.x;
               Object[] var169 = new Object[]{42835128969216L};
               ElapsedTimer var168 = var685;
               var168.aReturningVoid(var169);
               FloatSetting var170 = this.n;
               Float var171 = (Float)var170.aReturningObject();
               float var725 = var171;
               Object[] var10006 = new Object[]{null, null, 128703941739773L};
               var10006[1] = 1.25F;
               var10006[0] = 0.75F;
               Object[] var172 = var10006;
               this.y = var725 * RandomUtil.aReturningFloat(var172);
               this.A = 0.0F;
               AimAssist var567 = this;
               var409 = var567;
            }

            var409.B = 0.0F;
         }

         BooleanSetting var174 = this.h;
         Boolean var175 = (Boolean)var174.aReturningObject();
         var410 = ((byte)(((java.lang.Boolean)(var175)).booleanValue() ? 1 : 0));
      }

      int var415;
      int var569 = var26;
      byte var568 = var410;
      var415 = var568;
      byte var411 = var568;
      label392:
      if (var569 != 0) {
         byte var570 = var411;
         if (((var570) != 0)) {
            double var661 = this.z[0];
            double var30 = this.z[1];
            MinecraftClient var177 = b;
            Mouse var178 = var177.mouse;
            this.z[0] = var178.getX();
            MinecraftClient var179 = b;
            Mouse var180 = var179.mouse;
            this.z[1] = var180.getY();
            double var742;
            var10000 = (var742 = var661 - this.z[0]) == 0.0 ? 0 : (var742 < 0.0 ? -1 : 1);
            int var572 = var26;
            int var571 = var10000;
            var415 = var571;
            int var412 = var571;
            if (var572 == 0) {
               break label392;
            }

            int var573 = var412;
            if (!((var573) != 0)) {
               double var743;
               var10000 = (var743 = var30 - this.z[1]) == 0.0 ? 0 : (var743 < 0.0 ? -1 : 1);
               int var575 = var26;
               int var574 = var10000;
               var415 = var574;
               int var413 = var574;
               if (var575 == 0) {
                  break label392;
               }

               int var576 = var413;
               int var414 = var576;
               int var577 = var414;
               if (!((var577) != 0)) {
                  return;
               }
            }
         }

         ElapsedTimer var688 = this.x;
         float var726 = this.y;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var726;
         Object[] var185 = var10004;
         ElapsedTimer var184 = var688;
         var415 = (((var184.aReturningBoolean(var185)) ? 1 : 0));
      }

      Entity var428;
      label382: {
         AimAssist var427;
         label543: {
            int var579 = var26;
            int var578 = var415;
            int var418 = var578;
            int var416 = var578;
            if (var579 != 0) {
               int var580 = var416;
               if (!((var580) != 0)) {
                  return;
               }

               int var582 = var26;
               AimAssist var581 = this;
               var427 = var581;
               AimAssist var417 = var581;
               if (var582 == 0) {
                  break label543;
               }

               BooleanSetting var187 = var417.v;
               Boolean var188 = (Boolean)var187.aReturningObject();
               byte var583 = ((byte)(((java.lang.Boolean)(var188)).booleanValue() ? 1 : 0));
               var418 = var583;
            }

            int var584 = var418;
            if (((var584) != 0)) {
               int var586 = var26;
               Entity var585 = this.w;
               var428 = var585;
               Entity var419 = var585;
               if (var586 == 0) {
                  break label382;
               }

               Entity var587 = var419;
               Entity var420 = var587;
               Entity var588 = var420;
               label370:
               if (var588 != null) {
                  MinecraftClient var192 = b;
                  int var590 = var26;
                  HitResult var589 = var192.crosshairTarget;
                  HitResult var423 = var589;
                  HitResult var421 = var589;
                  if (var590 != 0) {
                     HitResult var591 = var421;
                     HitResult var422 = var591;
                     HitResult var592 = var422;
                     if (var592 == null) {
                        break label370;
                     }

                     MinecraftClient var195 = b;
                     HitResult var593 = var195.crosshairTarget;
                     var423 = var593;
                  }

                  int var595 = var26;
                  HitResult var594 = var423;
                  HitResult var425 = var594;
                  HitResult var424 = var594;
                  if (var595 != 0) {
                     HitResult var197 = var424;
                     Type var689 = var197.getType();
                     Type var597 = Type.ENTITY;
                     Type var596 = var689;
                     if (var596 != var597) {
                        break label370;
                     }

                     MinecraftClient var199 = b;
                     HitResult var598 = var199.crosshairTarget;
                     var425 = var598;
                  }

                  EntityHitResult var201 = (EntityHitResult)var425;
                  Entity var690 = var201.getEntity();
                  int var600 = var26;
                  Entity var599 = var690;
                  var428 = var599;
                  Entity var426 = var599;
                  if (var600 == 0) {
                     break label382;
                  }

                  Entity var203 = this.w;
                  Entity var202 = var426;
                  boolean var601 = var202.equals(var203);
                  if (var601) {
                     return;
                  }
               }
            }

            var427 = this;
         }

         var428 = var427.w;
      }

      int var603 = var26;
      Entity var602 = var428;
      Entity var430 = var602;
      Entity var429 = var602;
      if (var603 != 0) {
         Entity var604 = var429;
         if (var604 == null) {
            return;
         }

         var430 = this.w;
      }

      Vec3d var662;
      label354: {
         Entity var207 = var430;
         var662 = var207.getEyePos();
         int var606 = var26;
         Entity var605 = this.w;
         Entity var432 = var605;
         Entity var431 = var605;
         if (var606 != 0) {
            boolean var607 = var431 instanceof EndCrystalEntity;
            if (!var607) {
               break label354;
            }

            Entity var608 = this.w;
            var432 = var608;
         }

         Object[] var210 = new Object[]{var432, 131657085751917L};
         var662 = RaycastUtil.aReturningVec3d(var210);
      }

      Vec3d var663;
      label348: {
         Entity var211 = this.w;
         double var730 = var211.getX();
         Entity var212 = this.w;
         var730 -= var212.lastX;
         Entity var213 = this.w;
         double var10003 = var213.getY();
         Entity var214 = this.w;
         var10003 -= var214.lastY;
         Entity var215 = this.w;
         double var736 = var215.getZ();
         Entity var216 = this.w;
         Vec3d var691 = new Vec3d(var730, var10003, var736 - var216.lastZ);
         FloatSetting var217 = this.t;
         Float var218 = (Float)var217.aReturningObject();
         double var220 = var218.floatValue();
         Vec3d var219 = var691;
         var663 = var219.multiply(var220);
         BooleanSetting var222 = this.s;
         Boolean var223 = (Boolean)var222.aReturningObject();
         boolean var692 = var223;
         int var610 = var26;
         boolean var609 = var692;
         boolean var434 = var609;
         boolean var433 = var609;
         if (var610 != 0) {
            boolean var611 = var433;
            if (!var611) {
               break label348;
            }

            ModeSetting var225 = this.a;
            String var693 = (String)var225.aReturningObject();
            String var227 = "Players";
            String var226 = var693;
            boolean var612 = var226.equals(var227);
            var434 = var612;
         }

         boolean var613 = var434;
         if (var613) {
            Vec3d var230 = var663;
            Vec3d var229 = var662;
            var662 = var229.add(var230);
         }
      }

      Object[] var231 = new Object[]{var662, 43890541083073L};
      Rotation var664 = RotationUtil.aReturningdx_C0210(var231);
      Object[] var233 = new Object[0];
      Rotation var232 = var664;
      float var694 = var232.aReturningFloat(var233);
      MinecraftClient var234 = b;
      ClientPlayerEntity var235 = var234.player;
      float var31 = var694 - var235.getYaw();
      Object[] var237 = new Object[0];
      Rotation var236 = var664;
      float var695 = var236.bReturningFloat(var237);
      MinecraftClient var238 = b;
      ClientPlayerEntity var239 = var238.player;
      float var32 = var695 - var239.getPitch();

      int var440;
      label340: {
         label532: {
            label338:
            while (true) {
               float var744;
               int var614 = (var744 = var31 - 180.0F) == 0.0F ? 0 : (var744 < 0.0F ? -1 : 1);
               if (var614 > 0) {
                  var31 -= 360.0F;
                  int var615 = var26;
                  if (var615 == 0) {
                     break;
                  }

                  int var616 = var26;
                  if (var616 != 0) {
                     continue;
                  }
               }

               while (true) {
                  float var745;
                  int var617 = (var745 = var31 - -180.0F) == 0.0F ? 0 : (var745 < 0.0F ? -1 : 1);
                  if (var617 >= 0) {
                     break label338;
                  }

                  var31 += 360.0F;
                  int var618 = var26;
                  if (var618 == 0) {
                     break label532;
                  }

                  int var619 = var26;
                  if (var619 == 0) {
                     break label338;
                  }
               }
            }

            FloatSetting var242 = this.d;
            Float var243 = (Float)var242.aReturningObject();
            float var746;
            var10000 = (var746 = var243 - 360.0F) == 0.0F ? 0 : (var746 < 0.0F ? -1 : 1);
            int var621 = var26;
            int var620 = var10000;
            var440 = var620;
            int var435 = var620;
            if (var621 == 0) {
               break label340;
            }

            int var622 = var435;
            if (var622 < 0) {
               float var245 = var31;
               float var697 = Math.abs(var245);
               FloatSetting var246 = this.d;
               Float var247 = (Float)var246.aReturningObject();
               float var747;
               var10000 = (var747 = var697 - var247 / 2.0F) == 0.0F ? 0 : (var747 < 0.0F ? -1 : 1);
               int var624 = var26;
               int var623 = var10000;
               int var438 = var623;
               int var436 = var623;
               if (var624 != 0) {
                  int var625 = var436;
                  int var437 = var625;
                  int var626 = var437;
                  if (var626 > 0) {
                     return;
                  }

                  float var250 = var32;
                  float var699 = Math.abs(var250);
                  FloatSetting var251 = this.d;
                  Float var252 = (Float)var251.aReturningObject();
                  float var748;
                  int var627 = (var748 = var699 - var252 / 2.0F) == 0.0F ? 0 : (var748 < 0.0F ? -1 : 1);
                  var438 = var627;
               }

               int var629 = var26;
               int var628 = var438;
               var440 = var628;
               int var439 = var628;
               if (var629 == 0) {
                  break label340;
               }

               int var630 = var439;
               if (var630 > 0) {
                  return;
               }
            }
         }

         MinecraftClient var255 = b;
         int var256 = var255.getCurrentFps();
         var440 = Math.max(var256, 1);
      }

      float var33 = var440;
      FloatSetting var258 = this.o;
      Float var259 = (Float)var258.aReturningObject();
      float var34 = var259 * 2.0F / var33;
      FloatSetting var260 = this.p;
      Float var261 = (Float)var260.aReturningObject();
      float var732 = var261 / 100.0F;
      Object[] var737 = new Object[]{null, null, 128703941739773L};
      var737[1] = var732;
      var737[0] = 0.0F;
      Object[] var262 = var737;
      float var35 = 1.0F - RandomUtil.aReturningFloat(var262) * 0.3F;
      var34 *= var35;
      FloatSetting var263 = this.o;
      Float var264 = (Float)var263.aReturningObject();
      float var700 = var264 / 100.0F * 0.15F;
      float var266 = 1.0F;
      float var265 = var700;
      float var36 = Math.min(var265, var266);
      BooleanSetting var267 = this.q;
      Boolean var268 = (Boolean)var267.aReturningObject();
      boolean var701 = var268;
      int var632 = var26;
      boolean var631 = var701;
      boolean var442 = var631;
      boolean var441 = var631;
      if (var632 != 0) {
         boolean var633 = var441;
         if (var633) {
            FloatSetting var270 = this.r;
            Float var271 = (Float)var270.aReturningObject();
            float var37 = var271 / 100.0F;
            float var273 = 1.0F - var37;
            float var272 = 0.02F;
            float var38 = Math.max(var272, var273);
            float var275 = var38 * 0.18F;
            float var274 = 0.005F;
            var36 = Math.max(var274, var275);
            var34 *= var38;
         }

         this.A = this.A + (var31 - this.A) * var36;
         this.B = this.B + (var32 - this.B) * var36;
         ModeSetting var276 = this.a;
         String var702 = (String)var276.aReturningObject();
         String var278 = "Crystals";
         String var277 = var702;
         var442 = var277.equals(var278);
      }

      boolean var447;
      label309: {
         boolean var446;
         label308: {
            label535: {
               int var635 = var26;
               boolean var634 = var442;
               boolean var444 = var634;
               boolean var443 = var634;
               if (var635 != 0) {
                  boolean var636 = var443;
                  if (!var636) {
                     break label535;
                  }

                  BooleanSetting var280 = this.u;
                  Boolean var281 = (Boolean)var280.aReturningObject();
                  boolean var637 = var281;
                  var444 = var637;
               }

               int var639 = var26;
               boolean var638 = var444;
               var446 = var638;
               boolean var445 = var638;
               if (var639 == 0) {
                  break label308;
               }

               boolean var640 = var445;
               if (var640) {
                  var446 = true;
                  break label308;
               }
            }

            var447 = false;
            break label309;
         }

         boolean var641 = var446;
         var447 = var641;
      }

      boolean var666 = var447;
      boolean var642 = var666;
      label296:
      if (!var642) {
         float var667;
         label294: {
            float var284 = this.A;
            float var703 = Math.abs(var284);
            float var286 = var34;
            float var285 = var703;
            float var704 = Math.min(var285, var286);
            float var287 = this.A;
            var667 = var704 * Math.signum(var287);
            int var643 = var26;
            if (var643 != 0) {
               float var288 = var31;
               float var749;
               int var644 = (var749 = Math.abs(var288) - var34) == 0.0F ? 0 : (var749 < 0.0F ? -1 : 1);
               if (var644 > 0) {
                  break label294;
               }

               MinecraftClient var290 = b;
               ClientPlayerEntity var705 = var290.player;
               Object[] var292 = new Object[0];
               Rotation var291 = var664;
               float var294 = var291.aReturningFloat(var292);
               ClientPlayerEntity var293 = var705;
               var293.setYaw(var294);
            }

            int var645 = var26;
            if (var645 != 0) {
               break label296;
            }
         }

         MinecraftClient var296 = b;
         ClientPlayerEntity var706 = var296.player;
         MinecraftClient var297 = b;
         ClientPlayerEntity var298 = var297.player;
         float var300 = var298.getYaw() + var667;
         ClientPlayerEntity var299 = var706;
         var299.setYaw(var300);
      }

      float var454;
      float var455;
      Entity var302 = this.w;
      Box var668 = var302.getBoundingBox();
      Box var303 = var668;
      Box var304 = var668;
      Box var305 = var668;
      float var707 = (float)(var303.minX + (var304.maxX - var305.minX) / 2.0);
      Box var306 = var668;
      Vec3d var307 = var663;
      float var727 = (float)(var306.minY + var307.getY());
      Box var308 = var668;
      Box var309 = var668;
      Box var310 = var668;
      var732 = (float)(var308.minZ + (var309.maxZ - var310.minZ) / 2.0);
      var737 = new Object[]{null, null, null, 43371877274609L};
      var737[2] = var732;
      var737[1] = var727;
      var737[0] = var707;
      Object[] var311 = var737;
      Rotation var39 = RotationUtil.bReturningdx_C0210(var311);
      Box var312 = var668;
      Box var313 = var668;
      Box var314 = var668;
      float var708 = (float)(var312.minX + (var313.maxX - var314.minX) / 2.0);
      Box var315 = var668;
      Vec3d var316 = var663;
      float var728 = (float)(var315.maxY + var316.getY());
      Box var317 = var668;
      Box var318 = var668;
      Box var319 = var668;
      var732 = (float)(var317.minZ + (var318.maxZ - var319.minZ) / 2.0);
      var737 = new Object[]{null, null, null, 43371877274609L};
      var737[2] = var732;
      var737[1] = var728;
      var737[0] = var708;
      Object[] var320 = var737;
      Rotation var40 = RotationUtil.bReturningdx_C0210(var320);
      Object[] var322 = new Object[0];
      Rotation var321 = var39;
      float var41 = var321.bReturningFloat(var322);
      Object[] var324 = new Object[0];
      Rotation var323 = var40;
      float var42 = var323.bReturningFloat(var324);
      MinecraftClient var325 = b;
      ClientPlayerEntity var326 = var325.player;
      float var709 = var326.getPitch();
      int var648 = var26;
      float var647 = var41;
      float var646 = var709;
      var454 = var646;
      var455 = var647;
      float var448 = var646;
      float var449 = var647;
      label285:
      if (var648 != 0) {
         float var750;
         int var649 = (var750 = var448 - var449) == 0.0F ? 0 : (var750 < 0.0F ? -1 : 1);
         if (var649 <= 0) {
            MinecraftClient var328 = b;
            ClientPlayerEntity var329 = var328.player;
            float var710 = var329.getPitch();
            int var652 = var26;
            float var651 = var42;
            float var650 = var710;
            var454 = var650;
            var455 = var651;
            float var450 = var650;
            float var451 = var651;
            if (var652 == 0) {
               break label285;
            }

            float var654 = var451;
            float var653 = var450;
            float var452 = var653;
            float var453 = var654;
            float var751;
            int var655 = (var751 = var452 - var453) == 0.0F ? 0 : (var751 < 0.0F ? -1 : 1);
            if (var655 >= 0) {
               return;
            }
         }

         float var332 = this.B;
         float var711 = Math.abs(var332);
         float var334 = var34;
         float var333 = var711;
         float var712 = Math.min(var333, var334);
         float var335 = this.B;
         float var657 = Math.signum(var335);
         float var656 = var712;
         var454 = var656;
         var455 = var657;
      }

      float var43;
      label276: {
         var43 = var454 * var455;
         int var658 = var26;
         if (var658 != 0) {
            float var337 = var32;
            float var752;
            int var659 = (var752 = Math.abs(var337) - var34) == 0.0F ? 0 : (var752 < 0.0F ? -1 : 1);
            if (var659 > 0) {
               break label276;
            }

            MinecraftClient var339 = b;
            ClientPlayerEntity var713 = var339.player;
            Object[] var341 = new Object[0];
            Rotation var340 = var664;
            float var343 = var340.bReturningFloat(var341);
            ClientPlayerEntity var342 = var713;
            var342.setPitch(var343);
         }

         int var660 = var26;
         if (var660 != 0) {
            return;
         }
      }

      MinecraftClient var345 = b;
      ClientPlayerEntity var714 = var345.player;
      MinecraftClient var346 = b;
      ClientPlayerEntity var347 = var346.player;
      float var349 = var347.getPitch() + var43;
      ClientPlayerEntity var348 = var714;
      var348.setPitch(var349);
   }

   private Entity aReturningEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 90093651303927L ^ var2;
      long var4 = var2 ^ 85217647766310L;
      long var6 = var2 ^ 51018486576423L;
      long var8 = var2 ^ 53039805381139L;
      long var10 = var2 ^ 57063977587763L;
      long var12 = var2 ^ 126807177875215L;
      int var10000 = Event.cReturningInt();
      ModeSetting var28 = this.c;
      String var15 = (String)var28.aReturningObject();
      Entity var16 = null;
      double var17 = Double.MAX_VALUE;
      MinecraftClient var29 = b;
      ClientPlayerEntity var30 = var29.player;
      float var10003 = var30.getYaw();
      MinecraftClient var31 = b;
      ClientPlayerEntity var32 = var31.player;
      Rotation var19 = new Rotation(var10003, var32.getPitch());
      int var14 = var10000;
      MinecraftClient var33 = b;
      ClientWorld var34 = var33.world;
      Iterable var35 = var34.getEntities();
      Iterator var20 = var35.iterator();

      Entity var141;
      while (true) {
         Iterator var36 = var20;
         boolean var142 = var36.hasNext();
         if (var142) {
            Iterator var37 = var20;
            Entity var21 = (Entity)var37.next();
            int var144 = var14;
            Entity var143 = var21;
            var141 = var143;
            Entity var107 = var143;
            if (var144 == 0) {
               break;
            }

            Entity var38 = var107;
            int var203 = (((var38.isAlive()) ? 1 : 0));
            int var146 = var14;
            boolean var145 = dev.prestige.recovery.SourceSupport.asBoolean(var203);
            boolean var110 = var145;
            boolean var108 = var145;
            if (var146 != 0) {
               boolean var147 = var108;
               boolean var109 = var147;
               boolean var148 = var109;
               if (!var148) {
                  continue;
               }

               var110 = var21 instanceof PlayerEntity;
            }

            boolean var114;
            int var150 = var14;
            boolean var149 = var110;
            var114 = var149;
            boolean var111 = var149;
            label151:
            if (var150 != 0) {
               boolean var151 = var111;
               if (!var151) {
                  var203 = (((var21 instanceof EndCrystalEntity) ? 1 : 0));
                  int var153 = var14;
                  boolean var152 = ((((int)(var203) & 1) != 0));
                  var114 = var152;
                  boolean var112 = var152;
                  if (var153 == 0) {
                     break label151;
                  }

                  boolean var154 = var112;
                  boolean var113 = var154;
                  boolean var155 = var113;
                  if (!var155) {
                     continue;
                  }
               }

               var114 = var21 instanceof PlayerEntity;
            }

            boolean var118;
            int var157 = var14;
            boolean var156 = var114;
            var118 = var156;
            boolean var115 = var156;
            label143:
            if (var157 != 0) {
               boolean var158 = var115;
               if (var158) {
                  ModeSetting var45 = this.a;
                  String var205 = (String)var45.aReturningObject();
                  short var10001 = 30845;
                  long var10002 = 6142323516484252930L ^ var2;
                  String var47 = "Players";
                  String var46 = var205;
                  var203 = (((var46.equals(var47)) ? 1 : 0));
                  int var160 = var14;
                  boolean var159 = ((((int)(var203) & 1) != 0));
                  var118 = var159;
                  boolean var116 = var159;
                  if (var160 == 0) {
                     break label143;
                  }

                  boolean var161 = var116;
                  boolean var117 = var161;
                  boolean var162 = var117;
                  if (!var162) {
                     continue;
                  }
               }

               var118 = var21 instanceof EndCrystalEntity;
            }

            boolean var122;
            int var164 = var14;
            boolean var163 = var118;
            var122 = var163;
            boolean var119 = var163;
            label135:
            if (var164 != 0) {
               boolean var165 = var119;
               if (var165) {
                  ModeSetting var51 = this.a;
                  String var207 = (String)var51.aReturningObject();
                  short var215 = 31214;
                  long var217 = 7365832332670792855L ^ var2;
                  String var53 = "Crystals";
                  String var52 = var207;
                  var203 = (((var52.equals(var53)) ? 1 : 0));
                  int var167 = var14;
                  boolean var166 = ((((int)(var203) & 1) != 0));
                  var122 = var166;
                  boolean var120 = var166;
                  if (var167 == 0) {
                     break label135;
                  }

                  boolean var168 = var120;
                  boolean var121 = var168;
                  boolean var169 = var121;
                  if (!var169) {
                     continue;
                  }
               }

               PlayerValidationTracker var209 = Prestige.i;
               Object[] var57 = new Object[]{var21, var4};
               PlayerValidationTracker var56 = var209;
               var122 = var56.aReturningBoolean(var57);
            }

            Entity var126;
            label165: {
               int var171 = var14;
               boolean var170 = var122;
               boolean var125 = var170;
               boolean var123 = var170;
               if (var171 != 0) {
                  boolean var172 = var123;
                  if (!var172) {
                     continue;
                  }

                  int var174 = var14;
                  Entity var173 = var21;
                  var126 = var173;
                  Entity var124 = var173;
                  if (var174 == 0) {
                     break label165;
                  }

                  boolean var175 = var124 instanceof PlayerEntity;
                  var125 = var175;
               }

               boolean var176 = var125;
               if (var176) {
                  SocialsManager var210 = Prestige.g;
                  Entity var60 = var21;
                  Text var61 = var60.getName();
                  Object[] var63 = new Object[]{var61.getString(), var10};
                  SocialsManager var62 = var210;
                  boolean var177 = var62.aReturningBoolean(var63);
                  if (var177) {
                     int var178 = var14;
                     if (var178 != 0) {
                        continue;
                     }
                  }
               }

               var126 = var21;
            }

            Entity var66 = var126;
            Vec3d var22 = var66.getEyePos();
            MinecraftClient var67 = b;
            Vec3d var68 = var22;
            Vec3d var69 = var22;
            Vec3d var70 = var22;
            double var76 = var70.z;
            double var74 = var69.y;
            double var72 = var68.x;
            ClientPlayerEntity var71 = var67.player;
            double var23 = var71.squaredDistanceTo(var72, var74, var76);
            double var78 = var23;
            double var211 = Math.sqrt(var78);
            int var181 = var14;
            double var179 = var211;
            double var129 = var179;
            double var127 = var179;
            if (var181 != 0) {
               FloatSetting var80 = this.e;
               Float var81 = (Float)var80.aReturningObject();
               double var221;
               int var182 = (var221 = var127 - var81.floatValue()) == 0.0 ? 0 : (var221 < 0.0 ? -1 : 1);
               if (var182 > 0) {
                  continue;
               }

               Vec3d var84 = var22;
               var129 = var84.x;
            }

            Rotation var25;
            AimAssist var136;
            label167: {
               int var135;
               float var212 = (float)var129;
               Vec3d var85 = var22;
               float var216 = (float)var85.y;
               Vec3d var86 = var22;
               float var218 = (float)var86.z;
               Object[] var10005 = new Object[]{null, null, null, var8};
               var10005[2] = var218;
               var10005[1] = var216;
               var10005[0] = var212;
               Object[] var87 = var10005;
               var25 = RotationUtil.bReturningdx_C0210(var87);
               FloatSetting var88 = this.d;
               Float var89 = (Float)var88.aReturningObject();
               float var222;
               var203 = (var222 = var89 - 360.0F) == 0.0F ? 0 : (var222 < 0.0F ? -1 : 1);
               int var184 = var14;
               int var183 = var203;
               var135 = var183;
               int var131 = var183;
               label119:
               if (var184 != 0) {
                  int var185 = var131;
                  if (var185 < 0) {
                     FloatSetting var91 = this.d;
                     Float var92 = (Float)var91.aReturningObject();
                     var218 = var92;
                     var10005 = new Object[]{null, null, null, var12};
                     var10005[2] = var218;
                     var10005[1] = var25;
                     var10005[0] = var19;
                     Object[] var93 = var10005;
                     byte var214 = ((byte)((RotationUtil.fReturningBoolean(var93)) ? 1 : 0));
                     int var187 = var14;
                     byte var186 = var214;
                     var135 = var186;
                     byte var132 = var186;
                     if (var187 == 0) {
                        break label119;
                     }

                     byte var188 = var132;
                     byte var133 = var188;
                     byte var189 = var133;
                     if (var189 == 0) {
                        int var190 = var14;
                        if (var190 != 0) {
                           continue;
                        }
                     }
                  }

                  int var192 = var14;
                  AimAssist var191 = this;
                  var136 = var191;
                  AimAssist var134 = var191;
                  if (var192 == 0) {
                     break label167;
                  }

                  BooleanSetting var97 = var134.g;
                  Boolean var98 = (Boolean)var97.aReturningObject();
                  byte var193 = ((byte)(((java.lang.Boolean)(var98)).booleanValue() ? 1 : 0));
                  var135 = var193;
               }

               int var194 = var135;
               if (var194 == 0) {
                  MinecraftClient var100 = b;
                  Entity var102 = var21;
                  ClientPlayerEntity var101 = var100.player;
                  boolean var195 = var101.canSee(var102);
                  if (!var195) {
                     int var196 = var14;
                     if (var196 != 0) {
                        continue;
                     }
                  }
               }

               var136 = this;
            }

            label109: {
               Object[] var10007 = new Object[]{null, null, var25, var15, var6};
               var10007[1] = var23;
               var10007[0] = var21;
               Object[] var106 = var10007;
               AimAssist var105 = var136;
               double var26 = var105.aReturningDouble(var106);
               int var199 = var14;
               double var197 = var26;
               double var139 = var197;
               double var137 = var197;
               if (var199 != 0) {
                  double var223;
                  int var200 = (var223 = var137 - var17) == 0.0 ? 0 : (var223 < 0.0 ? -1 : 1);
                  if (var200 >= 0) {
                     break label109;
                  }

                  var16 = var21;
                  var139 = var26;
               }

               var17 = var139;
            }

            int var201 = var14;
            if (var201 != 0) {
               continue;
            }
         }

         var141 = var16;
         break;
      }

      return var141;
   }

   private double aReturningDouble(Object[] var1) {
      Entity var2;
      double var5;
      Rotation var7;
      long var9;
      int var11;
      int var51;
      var2 = (Entity)var1[0];
      var5 = (Double)var1[1];
      var7 = (Rotation)var1[2];
      String var8 = (String)var1[3];
      long var3 = (Long)var1[4];
      var3 = 90093651303927L ^ var3;
      var9 = var3 ^ 137035685398963L;
      int var10000 = Event.cReturningInt();
      String var12 = var8;
      // var11 = var10000;
      String var15 = var12;
      var10000 = var15.hashCode();
      int var57 = var11;
      int var56 = var10000;
      var51 = var56;
      int var42 = var56;
      label74:
      if (var57 != 0) {
         int var58 = var42;
         switch (var58) {
            case -893036542:
               short var10001 = 18918;
               long var10002 = 2903120524056013899L ^ var3;
               String var18 = "Crosshair";
               String var17 = var12;
               byte var90 = ((byte)((var17.equals(var18)) ? 1 : 0));
               int var60 = var11;
               byte var59 = var90;
               var51 = var59;
               byte var43 = var59;
               if (var60 == 0) {
                  break label74;
               }

               byte var61 = var43;
               byte var44 = var61;
               byte var62 = var44;
               if (var62 == 0) {
                  break;
               }

               var13 = 0;
               int var63 = var11;
               if (var63 != 0) {
                  break;
               }
            case 1490826774:
               short var95 = 14104;
               long var98 = 117117542232969906L ^ var3;
               String var22 = "Lowest HP";
               String var21 = var12;
               byte var91 = ((byte)((var21.equals(var22)) ? 1 : 0));
               int var65 = var11;
               byte var64 = var91;
               var51 = var64;
               byte var45 = var64;
               if (var65 == 0) {
                  break label74;
               }

               byte var66 = var45;
               byte var46 = var66;
               byte var67 = var46;
               if (var67 == 0) {
                  break;
               }

               var13 = 1;
               int var68 = var11;
               if (var68 != 0) {
                  break;
               }
            case -1041727151:
               short var96 = 5966;
               long var99 = 6017768672660222688L ^ var3;
               String var26 = "Lowest Armor";
               String var25 = var12;
               byte var92 = ((byte)((var25.equals(var26)) ? 1 : 0));
               int var70 = var11;
               byte var69 = var92;
               var51 = var69;
               byte var47 = var69;
               if (var70 == 0) {
                  break label74;
               }

               byte var71 = var47;
               byte var48 = var71;
               byte var72 = var48;
               if (var72 == 0) {
                  break;
               }

               var13 = 2;
               int var73 = var11;
               if (var73 != 0) {
                  break;
               }
            case -1763776967:
               short var97 = 15423;
               long var100 = 1594744686749768083L ^ var3;
               String var30 = "Closest";
               String var29 = var12;
               byte var93 = ((byte)((var29.equals(var30)) ? 1 : 0));
               int var75 = var11;
               byte var74 = var93;
               var51 = var74;
               byte var49 = var74;
               if (var75 == 0) {
                  break label74;
               }

               byte var76 = var49;
               byte var50 = var76;
               byte var77 = var50;
               if (var77 != 0) {
                  var13 = 3;
               }
         }

         var51 = var13;
      }

      int var78 = var51;
      switch (var78) {
         case 0:
            Object[] var33 = new Object[]{var7, var9};
            return RotationUtil.aReturningFloat(var33);
         case 1:
            int var80 = var11;
            Entity var79 = var2;
            Entity var53 = var79;
            Entity var52 = var79;
            if (var80 != 0) {
               boolean var81 = var52 instanceof PlayerEntity;
               if (!var81) {
                  return var5;
               }

               Entity var82 = var2;
               var53 = var82;
            }

            PlayerEntity var88 = (PlayerEntity)var53;
            PlayerEntity var37 = var88;
            float var94 = var37.getHealth();
            PlayerEntity var38 = var88;
            return (var94 + var38.getAbsorptionAmount()) * 1000.0 + var5;
         case 2:
            int var84 = var11;
            Entity var83 = var2;
            Entity var55 = var83;
            Entity var54 = var83;
            if (var84 != 0) {
               boolean var85 = var54 instanceof PlayerEntity;
               if (!var85) {
                  return var5;
               }

               Entity var86 = var2;
               var55 = var86;
            }

            PlayerEntity var14 = (PlayerEntity)var55;
            PlayerEntity var41 = var14;
            return var41.getArmor() * 1000.0 + var5;
         case 3:
         default:
            return var5;
      }
   }

   private boolean lambda$new$7(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystals";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$6(Float var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.s;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.a;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Players";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$5(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Players";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$4(Float var1) {
      BooleanSetting var4 = this.q;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystals";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$2(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Players";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystals";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Players";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(80596286009542L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[8];
      String var6 = "ñ`\u008646\u009f¡+\u007f¹`y\u001fI\u008e\u0093\u0000°5\u0002ð@Ät\u0018\u0080×g3¹Ï%\b)¥ð> {äP`É\u0006¹\u0015\u0000ÕD \u0099°l`!f_\u0011Ða\u0086ÞïYé¹ñÀ1w\u009d\"á»7\u001e>\u001f¿\u0087L·\u0010N\u000e\u0013Â\u0095x0Hy8\u001céaøQ\u0083\u0010øüÍ¹«@]&HÚEýS+K\n 7ûd¶}¿\u001fµð\u0005°Ü\u001cºÜJQ\u009aïo¼Yÿ²¹óÉ{ã6ÙY";
      int var8 = "ñ`\u008646\u009f¡+\u007f¹`y\u001fI\u008e\u0093\u0000°5\u0002ð@Ät\u0018\u0080×g3¹Ï%\b)¥ð> {äP`É\u0006¹\u0015\u0000ÕD \u0099°l`!f_\u0011Ða\u0086ÞïYé¹ñÀ1w\u009d\"á»7\u001e>\u001f¿\u0087L·\u0010N\u000e\u0013Â\u0095x0Hy8\u001céaøQ\u0083\u0010øüÍ¹«@]&HÚEýS+K\n 7ûd¶}¿\u001fµð\u0005°Ü\u001cºÜJQ\u009aïo¼Yÿ²¹óÉ{ã6ÙY"
         .length();
      char var5 = 24;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     D = var9;
                     E = new String[8];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "ëé\u009c7|\u001bTKÄ\u0099Äûçkùô\u0007áð0\u001a\u0097õ>JYß¦EA¸è\u0010\u0002\u0000õ\u0090A$\u0086-]V\u008c\\²\u008c\u008fò";
                  var8 = "ëé\u009c7|\u001bTKÄ\u0099Äûçkùô\u0007áð0\u001a\u0097õ>JYß¦EA¸è\u0010\u0002\u0000õ\u0090A$\u0086-]V\u008c\\²\u008c\u008fò".length();
                  var5 = ' ';
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9370;
      if (E[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])F.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               F.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dR", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = D[var5].getBytes("ISO-8859-1");
         E[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return E[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dR_C0197",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = H[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = G[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 28;
            yield var15;
         }
         case 1 -> {
            byte var16 = 32;
            yield var16;
         }
         case 2 -> {
            byte var17 = 43;
            yield var17;
         }
         case 3 -> {
            byte var18 = 50;
            yield var18;
         }
         case 4 -> {
            byte var19 = 22;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 53;
            yield var21;
         }
         case 7 -> {
            byte var22 = 8;
            yield var22;
         }
         case 8 -> {
            byte var23 = 46;
            yield var23;
         }
         case 9 -> {
            byte var24 = 14;
            yield var24;
         }
         case 10 -> {
            byte var25 = 3;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 1;
            yield var27;
         }
         case 13 -> {
            byte var28 = 49;
            yield var28;
         }
         case 14 -> {
            byte var29 = 40;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 16;
            yield var31;
         }
         case 17 -> {
            byte var32 = 57;
            yield var32;
         }
         case 18 -> {
            byte var33 = 44;
            yield var33;
         }
         case 19 -> {
            byte var34 = 47;
            yield var34;
         }
         case 20 -> {
            byte var35 = 59;
            yield var35;
         }
         case 21 -> {
            byte var36 = 52;
            yield var36;
         }
         case 22 -> {
            byte var37 = 34;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 24;
            yield var39;
         }
         case 25 -> {
            byte var40 = 26;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 4;
            yield var42;
         }
         case 28 -> {
            byte var43 = 62;
            yield var43;
         }
         case 29 -> {
            byte var44 = 37;
            yield var44;
         }
         case 30 -> {
            byte var45 = 35;
            yield var45;
         }
         case 31 -> {
            byte var46 = 39;
            yield var46;
         }
         case 32 -> {
            byte var47 = 0;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 30;
            yield var49;
         }
         case 35 -> {
            byte var50 = 61;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 23;
            yield var52;
         }
         case 38 -> {
            byte var53 = 31;
            yield var53;
         }
         case 39 -> {
            byte var54 = 27;
            yield var54;
         }
         case 40 -> {
            byte var55 = 54;
            yield var55;
         }
         case 41 -> {
            byte var56 = 17;
            yield var56;
         }
         case 42 -> {
            byte var57 = 7;
            yield var57;
         }
         case 43 -> {
            byte var58 = 60;
            yield var58;
         }
         case 44 -> {
            byte var59 = 6;
            yield var59;
         }
         case 45 -> {
            byte var60 = 13;
            yield var60;
         }
         case 46 -> {
            byte var61 = 19;
            yield var61;
         }
         case 47 -> {
            byte var62 = 42;
            yield var62;
         }
         case 48 -> {
            byte var63 = 41;
            yield var63;
         }
         case 49 -> {
            byte var64 = 48;
            yield var64;
         }
         case 50 -> {
            byte var65 = 20;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 38;
            yield var67;
         }
         case 53 -> {
            byte var68 = 51;
            yield var68;
         }
         case 54 -> {
            byte var69 = 9;
            yield var69;
         }
         case 55 -> {
            byte var70 = 29;
            yield var70;
         }
         case 56 -> {
            byte var71 = 11;
            yield var71;
         }
         case 57 -> {
            byte var72 = 55;
            yield var72;
         }
         case 58 -> {
            byte var73 = 63;
            yield var73;
         }
         case 59 -> {
            byte var74 = 15;
            yield var74;
         }
         case 60 -> {
            byte var75 = 21;
            yield var75;
         }
         case 61 -> {
            byte var76 = 56;
            yield var76;
         }
         case 62 -> {
            byte var77 = 12;
            yield var77;
         }
         default -> 18;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            H[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      G[0] = "o!RR+\u0010d.C\u001dV\bw)JT";
      G[1] = "Z/Ew9 Q T8X.Z+Pb";
      G[2] = boolean.class;
      H[2] = "java/lang/Boolean";
      G[3] = "p-ze\u0011\u0003f-\u007f?\u0002\u0014qf|9\u000e\u0000`!k.E\u0017R";
      G[4] = "9\bgr4\u00042\u0007v=X\u0007<\u0005trt";
      G[5] = "g\u0016?4f=l\u0019.{\u00050y\u001f";
      G[6] = int.class;
      H[6] = "java/lang/Integer";
      G[7] = "4BN\b`\f4BYTl\u0003.\tYJl\u0016)x\b\u00154A9K[U~:h\u0013\n";
      G[8] = "VIG\u0006\u001buVIPZ\u0017zL\u0002PD\u0017oKs\u0001\u001bN";
      G[9] = double.class;
      H[9] = "java/lang/Double";
      G[10] = ";P\u0003,5\u0010;P\u0014p9\u001f!\u001b\u0014n9\n&jF0aN";
      G[11] = "\u0016?]'z\u0001\u0016?J{v\u000e\ftJev\u001b\u000b\u0005\u001a8%";
      G[12] = "*\u0010s$Q\u0018*\u0010dx]\u00170[df]\u00027*4;\f";
      G[13] = "l\u0002b\u0003z\u001bl\u0002u_v\u0014vIuAv\u0001q8\"\u001e ";
      G[14] = "X\rj\t\u0006JX\r}U\nEBF}K\nPE7)\u0013]";
      G[15] = float.class;
      H[15] = "java/lang/Float";
      G[16] = "3ACSP6%AF\tC!2\nE\u000fO5#MR\u0018\u0004\"\u0015";
      G[17] = "\u007f\u000fg\u0000\u0012_\n/l\u000f\u0003\u0010k!g\u0004\u0007J\u001f";
      G[18] = "\u0017U\u0012p<d\u0001U\u0017*/s\u0016\u001e\u0014,#g\u0007Y\u0003;hp\u000b";
      G[19] = "\u0000O\u0002(hn\u0016O\u0007r{y\u0001\u0004\u0004twm\u0010C\u0013c<}\u000b";
      G[20] = "1q4\u007fJ DQ?p[o%_4{_5Q";
      G[21] = "9d\u001bcw\u00149d\f?{\u001b#/\f!{\u000e$^^z#O";
      G[22] = "HV\u0013\u0015$&HV\u0004I()R\u001d\u0004W(<UlU\u000fz";
      G[23] = ":u=\u001b?7:u*G38 >*Y3-'Oz\u0004g";
      G[24] = "\u0014r\u000b\u0013j\u0013aR\u0000\u001c{\\\u0000\\\u000b\u0017\u007f\u0006t";
      G[25] = "\n\u0001\u000fRcr\n\u0001\u0018\u000eo}\u0010J\u0018\u0010oh\u0017;IO7";
      G[26] = "\u00107R\u0007T\u000e\u00067W]G\u0019\u0011|T[K\r\u0000;CL\u0000\u001a&";
      G[27] = "&XG(\u0005\u0004SxL'\u0014K2vG,\u0010\u0011F";
      G[28] = "h@yZ4Gh@n\u00068Hr\u000bn\u00188]uz>Mo\u0018";
      G[29] = "3\u0011:\u000eVd8\u001e+A5i-\u0013$*\u0000k<\u00008\u0006\u0017f";
      G[30] = "JO=L\u0013SJO*\u0010\u001f\\P\u0004*\u000e\u001fIWuzRJ";
      G[31] = "\bB\u0017E}N}b\u001cJl\u0001\u001cl\u0017Ah[h";
      G[32] = "#a,F&\u0011VA'I7^7O,B3\u0004C";
      G[33] = "!+E%5l7+@\u007f&{ `Cy*o1'Tna}\u0000";
      G[34] = void.class;
      H[34] = "java/lang/Void";
      G[35] = "bj1l9Etj46*Rc!70&Frf 'mS_";
      G[36] = "\u0002\u001e>E\u0017,w>5J\u0006c\u00160>A\u00029b";
      G[37] = "Xq\u0002\bo\u000f-Q\t\u0007~@L_\u0002\fz\u001a8";
      G[38] = "R,\u0019ZDRR,\u000e\u0006H]Hg\u000e\u0018HHO\u0016\\L\u0019\t";
      G[39] = "\u0002~_^}j\u0014~Z\u0004n}\u00035Y\u0002bi\u0012rN\u0015)~\u000f";
      G[40] = "l\u00166~f\u000b\u00196=qwDx86zs\u001e\f";
      G[41] = "\fP 8W\u0017\u001aP%bD\u0000\r\u001b&dH\u0014\u001c\\1s\u0003\u0004[";
      G[42] = "\u0002S^\u0016D2wsU\u0019U}\u0016}^\u0012Q'b";
      G[43] = "\u0004iAz~0qIJuo\u007f\u0010GA~k%d";
      G[44] = "*mMM\u0013d_MFB\u0002+>CMI\u0006qJ";
      G[45] = "{\u0010\u0003zR\t{\u0010\u0014&^\u0006a[\u00148^\u0013f*Fc\u0006Y";
      G[46] = "xz^0\u0014\u0002\rZU?\u0005MlT^4\u0001\u0017\u0018";
      G[47] = "SzGN\u0006\u0000XuV\u0001n\u0000VzE";
      G[48] = "G#\u001f?\u0007`Q#\u001ae\u0014wFh\u0019c\u0018cW/\u000etSsO/\f\u007f\t>s4\fb\tyD#";
      G[49] = "\u000e\tw(\u0010C\u0018\trr\u0003T\u000fBqt\u000f@\u001e\u0005fcDR\f";
      G[50] = "7bT\f\u007f\u000bBB_\u0003nD#LT\bj\u001eW";
      G[51] = "un7\n8Ucn2P+Bt%1V'Veb&AlC^";
      G[52] = "\r]d\u001bD0\u0013U~T#1\u0002Ns\u000e\u00057";
      G[53] = "{\u0018}+^\u0004{\u0018jwR\u000baSjiR\u001ef\";0\u0005\\";
      G[54] = "~03/%G\u000b\u00108 4\bj\u001e3+0R\u001e";
      G[55] = "y ,:4&r/=uS>v3;9v/";
      G[56] = "+Y8M\u0000\u000f^y3B\u0011@?w8I\u0015\u001aK";
      G[57] = "\u0019\t\u0014]+\f\u0019\t\u0003\u0001'\u0003\u0003B\u0003\u001f'\u0016\u00043V@~";
      G[58] = "lr? i\\rz%o\u0014Lr";
      G[59] = "8)<\u001f +.)9E3<9b:C?((%-Tt?\u0014";
      G[60] = "FjKKh63J@DyyRDKO}#&";
      G[61] = "X5\u0014GD\u000fN5\u0011\u001dW\u0018Y~\u0012\u001b[\fH9\u0005\f\u0010\u001bv";
      G[62] = "\u001eF,\u0004\u001d\u0015kf'\u000b\fZ\nh,\u0000\b\u0000~";
      G[63] = "Z<X\u0006PZZ<OZ\\U@wOD\\@G\u0006\u001d\u001e\b\u0004";
      G[64] = "D& \u001c\u0013C1\u0006+\u0013\u0002\fP\b \u0018\u0006V$";
      G[65] = "\u001cW#\u0004c\u007f\u0018\u001f+^\\fI\u001eGX'x\u001f\b&_deAn{\u001f'<F\u000f|\\:b R<\u001fceAU\u007f\u0002=\u0003";
      G[66] = ";\u000f0bCQ}Ah?8Yf\u001d=jo\u000e<Kc\u0006\u0004Hn\u0014\"`B\u00066I";
      G[67] = "\u0014\fA\u000e4\f_\u0010S\u000eI\u0010d\u0011I\u001c8I\u0014\u0019R\u00064";
      G[68] = "@>\u0003\u001f\\>H%\u0019\u0013d'1cO\n\\pV?\u0002\u0001\u000bp1`G\u000fT#Pa\u001c^_N";
      G[69] = "\tvHx]\u001fH1N~&\u001cUbUsqK\u000f5\u000b\u001f\u0018\n\u000e3Rx[\u001f\rw";
      G[70] = "\"\u001e]YnCzNJ[RZp\tEE>h'N\u001e\u001bm?#\r\u001f\u001e1X`\u0018\u001cZR";
      G[71] = ",Y?B\u0014\\q\u0000*StUq\u001d-J\u0018g%_u\u0011t\u000ed[qN\u0013MqX5-";
      G[72] = "lPMePRcU\u0013\u0000JQ~\negFU\u0005VU{\u0015^dQ\u0016fK8";
      G[73] = "N\u001bhn\u0016A\u0005\u0007znkS>\u0005zi\u0011F\u000e\u000f9n\u0006";
      G[74] = "3\u0003DJ\r\u0012d@\u0005\u0013\u0005*c>EG\u001b\u00124Y\u0019\n\u0010E4>EJG\u0017x\u0006\u0012\t\u0006Np>";
      G[75] = "\tKlE3\u001eD\u00037\u0003IJX^6P\u001e\u001d\u0006\u000eo<xI_\u000b=Eu[A\u0003";
      G[76] = "BO!)f\u001a\u001aM!%\u0017\u0011F\u000f}~{#\u0010M!$+tB\u001e`vt\u000eO\u0016b\u007f\u0017";
      G[77] = "\u001b\u0011y5N*\u001fYqoq3FN\u001d<\u001c+HKg1\u0014)A(t8\f9DRy0\u000e0'Ap(\u001e5]Lx*\u0017V";
      G[78] = "mVx6Iq \u001e#p3.0R&(_\u001cd\u0013x~3qeOv\"Rp>\u001e}O";
      G[79] = "T\u00121p/\b\u001c\u0013'{\"x\u0004,t:{@SK(wp\u0017S,t4c\u0002]\\<5u\tP,";
      G[80] = "\u0016\u001d!V\u0001GNM6T=VP\u000b0IF;\u0010F+T\u0007XB\u0014?P=\u0001\u0011\u0017i@\\\u0000JFb-";
      G[81] = "0\u0004T{{Eh\u0006Tw\nN4D\b,f|b\u0006Tv7+0U\u0015$iQ=]\u0017-\n";
      G[82] = "Hv[rA\u0006\u0010&Lp}\u0014\u0016pGe*DO$\u001f\tC\u0002M!@n\u0000\u0017Ne";
      G[83] = "\u0016\u000blH\u001f\b\u0018\u0006`\u000be\u0006|[;\u0014]R\u001b\u0007v\u001f\nR|\th\u001a\nT\u0018^i\u000b\u0004l";
      G[84] = "g\u0000\u0017\t,67H_\u001ddS8UW\b\u0016jnJ^Nu8<^Zt";
      G[85] = "j\u0013\u0004^sG/\u0010\u0011\u0010m <G\u00159vZ2L\u0006bc\u001a0O\u0013\bl\u001fn*";
      G[86] = "\"\f\u00029=ZqW\f:+5~^\u0019:+YL\r]kr5'H\u001ee*T \u000b\u0003;L";
      G[87] = "EIX\b\n-\u0016\u0012V\u000b\u001cB\u0019\u001bC\u000b\u001c.+H\u0007PAB\u0015\u001bB\u0004\u00188\u0018\u0013@\r{";
      G[88] = "\b*\u0012n\u001f|\fb\u001a4 {Mi\n\u000e\u001ex\u000e/\u0015i]m\rkv0X:\bp\u0011sM9L\u0013";
      G[89] = "I\b\u0003#{\\\bO\u0005%\u0000_\u0015\u001c\u001e(W\bOKCD>INM\u0019#}\\M\t";
      G[90] = "/\u001fuO\u0012c+W}\u0015-vy]\u0011F@b|EkKH`u&xBPpp\\uJRy\u0013";
      G[91] = "@?Mq[h\u0018oZsgz\u001e9Qf0*Go\u000b\nYlEhVm\u001ayF,";
      G[92] = "v\r\u001d:\u0013G%\t\u00042uM\u001aIWnM\u001a}\u0015\u001ae\u001a\u001a\u001a\u001d\u001e;\u0007ObH\b7I$";
      G[93] = "\u0004pqV\u0004+\\ fT82VgiJT\u0000\u0001 2\u0014\bW\u0005c3\u0011[0Fv0U8";
      G[94] = "F>:\u0003\u0004\u0018\u000bvaE~G\u001b:d\u001d\u0012uJy9KO\"J=\u007fE\u0018CM~b\u001b~";
      G[95] = ",xf\u0004i\u007f!#=ZT/M+0Zlx*w}Q;xM,x\u0004h%*om\u0007,F";
      G[96] = "\f{?\u0017\u0000>\u0003~ar\u0017-\u0018(8\tzmU3%H\u0019?\u0007'!r@l\u0004q1\u0013A7Uz\\";
      G[97] = "\u0017iH}2Y\u001dsZ<\u0002\f\u0018oTiU[B?\n\u0005<\u001aC>Sb\u007f\u000f@z";
      G[98] = "rx\"\u0002\u0016ixb0C&<}~>\u0016qk'.cz\u0018*&/9\u001d[?%k";
      G[99] = "\biPH\u007fOE!\u000b\u000e\u0005\u001bY|\n]RL\u0006 V1j\u0015_cQLbNHo";
      G[100] = "ViD'>eXdHdDo<9\u0013{|?[e^p+?<:\u001b~tl];@/\u007f\u0001";
      G[101] = "c?7\u0011\u001aS\"x1\u0017aP?+*\u001a6\u0007e|vv_Fdz-\u0011\u001cSg>";
      G[102] = "E?%\u007fR]\u001d=%s#VA\u007fy(Od\u0011=%~#\rT9%,DNA:aO\u001dK\u0016?z(^^\u0015{\u0019q[\t\u0010`~2N\nT\u0003'7\u0019\u000fOdd\"\u001aK,";
      G[103] = "I\nZU;\\CI]BA\u0005;M\u0003KyR\\\u0011N@.R;N\u000bNq\u0001ZOP\u001fzl";
      G[104] = "zl~\"PJpvlc`\u0014y{f=\f&-?<c\\q*\u007f<f\u0003\u0016ij?\"`";
      G[105] = "U\u001eqaub\u0018V*'\u000f6\u0004\u000b+tXaZXr\u0018o9Z\t3#53\u001a\u0003";
      G[106] = "!$v\u0019UY,\u007f-Gh\t@w GP^'+mL\u0007^@q{[\u0013\\<)+L\u0011`";
      G[107] = "\u0000/\nU&+\f8\u001fWY3\u000f6\u0013]5\u0001[uL\ncV]!\u000bAe*\u0005q\u001cCY";
      G[108] = "{\u0007\r9;!v\\Vg\u0006q\u001a\u000eWe9%h\u0016\u000fzy\u0018yQ\r<;ja\t\u0012|\u0006";
      G[109] = "+\u0013KW:;sC\\U\u0006\"y\u0004SKj\u0010.C\b\u0016?G*\u0000\t\u0010e i\u0015\nT\u0006";
      G[110] = "OW\u00041}r\u0002\u001f_w\u0007&\u001eB^$PqA\u001f\u0005H>s\u0002AJ!=vNO\u000b";
      G[111] = "?\u000btVp\u0005g[cTL\u0017a\rhA\u001bD1^=-r\u0001:\\oJ1\u00149\u0018";
      G[112] = "\n=\"VpAKz$P\u000bBV)?]\\\u0015\f~`15T\rx8VvA\u000e<";
      G[113] = "^\u00121\u0005lJ\u0004\u0018q\u000f\u0010\u0014S\u000fn\r|&\u0007L1Z+q\u0002\fg\u000ek\u0017DB?S\u0010";
      G[114] = "Fa\u0011]+%N:\u0006Q\u00146Hl\u0012CCa\u00189J/phGm\u000bJs#\u0016<";
      G[115] = "#\u0016mY\n\u0012 ]<\bw\u0012*ZcR\u001b ~\u001a8\twM\u007fG3X\u0016L$\u001685";
      G[116] = "eS\u0019V>06W\u0000^X:\t\u0017S\u0002`mnK\u001e\t7m\t\u0014[\u0007h>h\u0015\u0000VcS";
      G[117] = "+xGe>\u0003%uK&D\u000eA(\u00109|Y&t]2+YAzC7+_%-B&%g";
      G[118] = "2Y\u0010o\u0005\u0019hUA?{KT\f\u0000)DG5\u000bC4\u001a!";
      G[119] = "g0O9\u001d\r4kA:\u000bb;bT:\u000b\u000e\t1\u0010dSb7bU5\u000f\u0018:jW<l";
      G[120] = "c\u0017/BgBbS-\u0002`y=ENB+\u000b#\u0011-\u0010y\u001f'+wGz@&\u0010v\u0003x\u0000!+";
      G[121] = "#7BL ='\u007fJ\u0016\u001f:~a@QzAvc[C|;{kYJ\u001f(rsIOe%zq@,";
      G[122] = "V\u0001`%Q}\u0003\r5)*,\n\u000f>%C 3\u0001>5GFWP;xG'V\u000bjs*";
      G[123] = "\\\u0001m\u000f,&\u0004Qz\r\u0010?\u000e\u0016u\u0013|\r^Z-I\u0010`[\u000b%\u0019qa\u0000Z.t";
      G[124] = "d<\n|:7>0[,Dd\u0002i\u001a:{icnY'%\u000f";
      G[125] = "BZ\u000eW@b\u001aX\u000e[1iF\u001aR\u0000][\u0010X\u000eZ\u000e\fB\u000bO\bRvO\u0003M\u00011jZ\u0002H\nRg\u0013\nUg";
      G[126] = "gvv\u001c\u001bn?&a\u001e'w5an\u0000KEe-4V'/!di\u001cJnfbog";
      G[127] = "r\\\u000b\"!t-\r\u0014aS#H\u000fZj*p+]\b~.J";
      G[128] = ".6rtO\f$,`5\u007fY!0n`(\u000e{`2\fAOzaik\u0002Zy%";
      G[129] = "p6v\u0018UP(4v\u0014$[tv*OHi'2w\u0017$\u0001rr1\u0014XY\"e3(\u001e\u0006x:'I\u001f])1J";
      G[130] = ")\u0014\u0015rN~hS\u0013t5}u\u0000\byb*/WQ\u0015\u000bk.Q\u000frH~-\u0015";
      G[131] = "\f>^#zxAv\u0005e\u0000,]+\u00046W{\u0003|\\Zi~\u0000v\u001141|\u0000z";
      G[132] = "\fkq$mDQ2d5\rMQ/c,a\u007f\u0005m;p\r\u0016Di?(jUQj{K";
      G[133] = "wE\u001d\u000fweb\u0001\u001d\u000e\u0018n\u0010\u0005C\r 9wY\u000e\u0006w9\u0010Z\u0002\rbjsWK\u0005\u007f\u0007";
      G[134] = "*An?RTg\t5y(\u0000{T4*\u007fW%\u0003aF\u0018VhV0*E\u000f}G";
      G[135] = "[k\rD^S\u001d%U\u0019%[\u0006y\u0000Lr\f\\/] \u0019J\u000ep\u001fF_\u0004V-";
      G[136] = "&\u0017\u0017|y\nq\u0016\u0006rA\u0007MMMwyP*\u0011\u0000|.PM\u001d\u0010n.\r7\u0010\u0018l'n";
      G[137] = " CisCM)T}#,]8Eip{\u0003b\u00104\u001cAJhZfd\u0014\\d\u0014";
      G[138] = "\u00132\nI_mRu\fO$nO&\u0017Bs9\u0015qO.\u001ax\u0014w\u0010IYm\u00173";
      G[139] = "\u001fkg>x\\G;p<DEM|\u007f\"(w\u001d< zD\u0019\u0019m#<#\\\u001axm\"D";
      G[140] = "v^*}Q\r&\u0016bi\u0019h/\u000faF\u0006\u00183f 8\nX\"\u0007!c[SO";
      G[141] = "\u000b\nB2esHU@/\u0019qq\\\u000f3!&\u0016\u0000B8v&q\fR*v{\u000b\u0001Z(\u007f\u0018";
      G[142] = "\u001a7-b4\u0014B5-nE\u001f\u001ewq5)-H5-o{z\u001afl=&\u0000\u0017nn4E\u001c\u0002ok?&\u0011KgvR";
      G[143] = "_\u0001;\u000f(@WZ,\u0003\u0017SQ\f8\u0011@\u0004\u0000Qb}s\r^\r!\u0018pF\u000f\\";
      G[144] = "<S3=SK<[*9jSG\u0005e\"R\u0004 Y()\u0005\u0004GR>>\u0012\n|X$,S:";
      G[145] = "Y\u0018\u0018\u0001x_L\\\u0018\u0000\u0017T>XF\u0003/\u0003Y\u0004\u000b\bx\u0003>[N\u0006'P_Z\u0015W,=";
      G[146] = "U~f7~AQ6nmAX\u00007\u0002>,@\u0006$x3$B\u000fGk:<R\n=f2>[i.o*.^\u0013#g('=";
      G[147] = "Z*=k>\u001f\u0002z*i\u0002\u0006\b=%wn4^zx/;c\u000b*=h2X\u00010/)\u0002";
      G[148] = "V\u0019_\u0000\u000fr\n\u0013Z\u0007M\u001f\u000e_H\u0003\u001cc\bY%@M/\u0012\u0019@\u0010\u0005g\u0006Q%";
      G[149] = "]\u0007UU\u0005\t\u000e\u0003L]c\u000e1C\u001f\u0001[TV\u001fR\n\fT1@\u0017\u0004S\u0007PALUXj";
      G[150] = "pMeLs\u0017(Oe@\u0002\u001ct\r9\u001bn.'IeC\u0002\u0007`O \u001ah\u0000\u007fM$|";
      G[151] = "\"9P\u0012\u001bSu8A\u001c#]Ic\n\u0019\u001b\t.?G\u0012L\tI3W\u0000LT3>_\u0002E7";
      G[152] = "x}ouOfrg}4\u007f8{jwj\u0013\n/..<\u007f3}no=D9g|.\r\u00116nn'6\u001b,|/\u0017";
      G[153] = "MQ<i\u001b3V\u001c=ne%VD/);\"V^+U\f&OL%/\u0001.MEF";
      G[154] = "LJrmNUBG~.4X&\u001a%1\f\u000fAFh:[\u000f&Jx([R\\Gp*R1";
      G[155] = "r-$4~\u0003x76uN]q:<+\"o%~fuN\u0006d|`/)Eq\u007f$L Sd>lw*Iv\u007f\\";
      G[156] = "4=75_$78{;\u001eMhk6;H!Z?zb\u0016w\r?p!V7`cz$Qu\r";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = G[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(H[var4]);
            G[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = G[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = H[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            G[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  G[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(126928333122186L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = G[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = H[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  G[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(126928333122186L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        G[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(126928333122186L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 235;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 254;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 82;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 233;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 195;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 250;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 235;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 254;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 82;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dR_C0197",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AimAssist var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AimAssist var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AimAssist var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$6", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AimAssist var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AimAssist var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$7", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AimAssist var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AimAssist var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$3", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AimAssist var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dR_C0197;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dR_C0197", "lambda$new$4", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AimAssist)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
