package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.OverlayStyleEvent;
import dev.zprestige.prestige.api.events.WorldTimeEvent;
import dev.zprestige.prestige.api.events.AmbientColorEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Predicate;

public class Ambience extends Module {
   private BooleanSetting d;
   private FloatSetting a;
   private FloatSetting b;
   private ColorSetting c;
   private BooleanSetting e;
   private BooleanSetting f;
   private ColorSetting g;
   private BooleanSetting h;
   private IntSetting i;
   private static final long k = 130811361848167L;
   private static final Object[] l = new Object[54];
   private static final String[] m = new String[54];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;

   public Ambience() {
      super();
      long var10001 = 116978543486078L ^ 87789959735102L;
      var10001 = 116978543486078L ^ 128723965007529L;
      var10001 = 116978543486078L ^ 85635557531548L;
      var10001 = 116978543486078L ^ 64482359291858L;

      ColorSetting var10000 = this.g;
      Object[] var12 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var11 = var10000;
      var11.aReturningColorSetting(var12);
      var10000 = this.c;
      Object[] var14 = new Object[]{invokeBinding2(this), 41489415177024L};
      ColorSetting var13 = var10000;
      var13.aReturningColorSetting(var14);
      IntSetting var24 = this.i;
      Object[] var16 = new Object[]{invokeBinding3(this), 43459238656994L};
      IntSetting var15 = var24;
      var15.aReturningIntSetting(var16);
      BooleanSetting var25 = this.e;
      Object[] var18 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var17 = var25;
      var17.aReturningBooleanSetting(var18);
      FloatSetting var26 = this.a;
      Object[] var20 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var19 = var26;
      var19.aReturningFloatSetting(var20);
      FloatSetting var27 = this.b;
      Object[] var22 = new Object[]{invokeBinding6(this), 34595201528535L};
      FloatSetting var21 = var27;
      var21.aReturningFloatSetting(var22);
   }

   @EventListener
   public void a(OverlayStyleEvent var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var7 = this.d;
      Boolean var10000 = (Boolean)var7.aReturningObject();
      int var44 = var4;
      Boolean var43 = var10000;
      Object var40 = var43;
      Boolean var39 = var43;
      if (var44 != 0) {
         Boolean var8 = var39;
         boolean var45 = var8;
         if (!var45) {
            return;
         }

         FloatSetting var10 = this.a;
         Object var46 = var10.aReturningObject();
         var40 = var46;
      }

      Float var12 = (Float)var40;
      float var50 = var12;
      FloatSetting var13 = this.b;
      Float var14 = (Float)var13.aReturningObject();
      float var16 = var14;
      float var15 = var50;
      float var5 = Math.min(var15, var16);
      FloatSetting var17 = this.a;
      Float var18 = (Float)var17.aReturningObject();
      float var51 = var18;
      FloatSetting var19 = this.b;
      Float var20 = (Float)var19.aReturningObject();
      float var22 = var20;
      float var21 = var51;
      float var6 = Math.max(var21, var22);
      Object[] var24 = new Object[]{var5};
      OverlayStyleEvent var23 = var1;
      var23.cReturningVoid(var24);
      Object[] var26 = new Object[]{var6};
      OverlayStyleEvent var25 = var1;
      var25.dReturningVoid(var26);
      int var48 = var4;
      OverlayStyleEvent var47 = var1;
      OverlayStyleEvent var42 = var47;
      OverlayStyleEvent var41 = var47;
      if (var48 != 0) {
         ColorSetting var27 = this.c;
         Object[] var29 = new Object[]{(Color)var27.aReturningObject()};
         OverlayStyleEvent var28 = var41;
         var28.bReturningVoid(var29);
         BooleanSetting var30 = this.e;
         Boolean var31 = (Boolean)var30.aReturningObject();
         boolean var49 = var31;
         if (var49) {
            float var33 = var6;
            Object[] var35 = new Object[]{var33};
            OverlayStyleEvent var34 = var1;
            var34.eReturningVoid(var35);
         }

         var42 = var1;
      }

      Object[] var38 = new Object[0];
      OverlayStyleEvent var37 = var42;
      var37.aReturningVoid(var38);
   }

   @EventListener
   public void a(AmbientColorEvent var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var6 = this.f;
      Boolean var10000 = (Boolean)var6.aReturningObject();
      int var20 = var4;
      Boolean var19 = var10000;
      Object var18 = var19;
      Boolean var17 = var19;
      if (var20 == 0) {
         Boolean var7 = var17;
         boolean var21 = var7;
         if (!var21) {
            return;
         }

         ColorSetting var10 = this.g;
         var18 = var10.aReturningObject();
      }

      Color var5 = (Color)var18;
      Object[] var12 = new Object[]{var5};
      AmbientColorEvent var11 = var1;
      var11.bReturningVoid(var12);
      Object[] var14 = new Object[]{var5};
      AmbientColorEvent var13 = var1;
      var13.cReturningVoid(var14);
      Object[] var16 = new Object[0];
      AmbientColorEvent var15 = var1;
      var15.aReturningVoid(var16);
   }

   @EventListener
   public void a(WorldTimeEvent var1) {
      int var4 = Event.bReturningInt();
      int var15 = var4;
      if (var15 == 0) {
         BooleanSetting var5 = this.h;
         Boolean var6 = (Boolean)var5.aReturningObject();
         boolean var16 = var6;
         if (!var16) {
            return;
         }

         IntSetting var8 = this.i;
         Integer var9 = (Integer)var8.aReturningObject();
         Object[] var11 = new Object[]{(long)var9.intValue()};
         WorldTimeEvent var10 = var1;
         var10.bReturningVoid(var11);
      }

      Object[] var14 = new Object[0];
      WorldTimeEvent var13 = var1;
      var13.aReturningVoid(var14);
   }

   private boolean lambda$new$5(Integer var1) {
      BooleanSetting var4 = this.h;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$4(Color var1) {
      BooleanSetting var4 = this.f;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Boolean var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Color var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$1(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 60;
            yield var15;
         }
         case 1 -> {
            byte var16 = 24;
            yield var16;
         }
         case 2 -> {
            byte var17 = 18;
            yield var17;
         }
         case 3 -> {
            byte var18 = 53;
            yield var18;
         }
         case 4 -> {
            byte var19 = 2;
            yield var19;
         }
         case 5 -> {
            byte var20 = 56;
            yield var20;
         }
         case 6 -> {
            byte var21 = 4;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 35;
            yield var23;
         }
         case 9 -> {
            byte var24 = 42;
            yield var24;
         }
         case 10 -> {
            byte var25 = 26;
            yield var25;
         }
         case 11 -> {
            byte var26 = 45;
            yield var26;
         }
         case 12 -> {
            byte var27 = 10;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 43;
            yield var29;
         }
         case 15 -> {
            byte var30 = 34;
            yield var30;
         }
         case 16 -> {
            byte var31 = 40;
            yield var31;
         }
         case 17 -> {
            byte var32 = 58;
            yield var32;
         }
         case 18 -> {
            byte var33 = 8;
            yield var33;
         }
         case 19 -> {
            byte var34 = 13;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 51;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 9;
            yield var38;
         }
         case 24 -> {
            byte var39 = 31;
            yield var39;
         }
         case 25 -> {
            byte var40 = 22;
            yield var40;
         }
         case 26 -> {
            byte var41 = 32;
            yield var41;
         }
         case 27 -> {
            byte var42 = 33;
            yield var42;
         }
         case 28 -> {
            byte var43 = 1;
            yield var43;
         }
         case 29 -> {
            byte var44 = 50;
            yield var44;
         }
         case 30 -> {
            byte var45 = 30;
            yield var45;
         }
         case 31 -> {
            byte var46 = 54;
            yield var46;
         }
         case 32 -> {
            byte var47 = 21;
            yield var47;
         }
         case 33 -> {
            byte var48 = 55;
            yield var48;
         }
         case 34 -> {
            byte var49 = 44;
            yield var49;
         }
         case 35 -> {
            byte var50 = 6;
            yield var50;
         }
         case 36 -> {
            byte var51 = 29;
            yield var51;
         }
         case 37 -> {
            byte var52 = 47;
            yield var52;
         }
         case 38 -> {
            byte var53 = 3;
            yield var53;
         }
         case 39 -> {
            byte var54 = 49;
            yield var54;
         }
         case 40 -> {
            byte var55 = 17;
            yield var55;
         }
         case 41 -> {
            byte var56 = 14;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 28;
            yield var58;
         }
         case 44 -> {
            byte var59 = 46;
            yield var59;
         }
         case 45 -> {
            byte var60 = 38;
            yield var60;
         }
         case 46 -> {
            byte var61 = 48;
            yield var61;
         }
         case 47 -> {
            byte var62 = 41;
            yield var62;
         }
         case 48 -> {
            byte var63 = 16;
            yield var63;
         }
         case 49 -> {
            byte var64 = 11;
            yield var64;
         }
         case 50 -> {
            byte var65 = 12;
            yield var65;
         }
         case 51 -> {
            byte var66 = 25;
            yield var66;
         }
         case 52 -> {
            byte var67 = 61;
            yield var67;
         }
         case 53 -> {
            byte var68 = 62;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 19;
            yield var70;
         }
         case 56 -> {
            byte var71 = 27;
            yield var71;
         }
         case 57 -> {
            byte var72 = 5;
            yield var72;
         }
         case 58 -> {
            byte var73 = 57;
            yield var73;
         }
         case 59 -> {
            byte var74 = 59;
            yield var74;
         }
         case 60 -> {
            byte var75 = 7;
            yield var75;
         }
         case 61 -> {
            byte var76 = 0;
            yield var76;
         }
         case 62 -> {
            byte var77 = 20;
            yield var77;
         }
         default -> 36;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "^$g\u00155*U+vZY)[)t\u0015u";
      l[1] = boolean.class;
      m[1] = "java/lang/Boolean";
      l[2] = "54~\u0002~W#4{Xm@4\u007fx^aT%8oI*C\u0017";
      l[3] = "Cq\"\u00168cH~3YYmCu7\u0003";
      l[4] = ",\u007fS\r\u0014S:\u007fVW\u0007D-4UQ\u000bP<sBF@G\u001b";
      l[5] = "$]\u0014]\u0005f/R\u0005\u0012fk:_\nySi+L\u0016UDd";
      l[6] = "+3c2\u001a =3fh\t7*xen\u0005#;?ryN1\u0015";
      l[7] = "D*\"40\u000b1\n);!DP\u0004\"0%\u001e$";
      l[8] = void.class;
      m[8] = "java/lang/Void";
      l[9] = "A,\u000fp];J#\u001e?>6_%";
      l[10] = float.class;
      m[10] = "java/lang/Float";
      l[11] = "8\u001bSx\u001c\".\u001bV\"\u000f59PU$\u0003!(\u0017B3H3\u0019";
      l[12] = int.class;
      m[12] = "java/lang/Integer";
      l[13] = "\u0013S66d&fs=9ui\u0007}62q3s";
      l[14] = "\u0011jC&[ \u001aeRi3 \u0014jA";
      l[15] = "cG<3TA\u0016g7<E\u000ewi<7AT\u0003";
      l[16] = "\u0013N8{-Ifn3t<\u0006\u0007`8\u007f8\\s";
      l[17] = "H\u0001U\u0011\u0011,=!^\u001e\u0000c\\/U\u0015\u00049(";
      l[18] = "\f%q<8=\u001a%tf+*\rnw`'>\u001c)`wl/\u0011";
      l[19] = "CtVMlx6T]B}7WZVIym#";
      l[20] = "\u0001~k\u0002y\u001dt^`\rhR\u0015Pk\u0006l\ba";
      l[21] = "^6>\u0006m9H6;\\~._}8Zr:N:/M9-r";
      l[22] = "\u001bttSX7nT\u007f\\Ix\u000fZtWM\"{";
      l[23] = "\u0006`\u0007}>\r\u0010`\u0002'-\u001a\u0007+\u0001!!\u000e\u0016l\u00166j\u0019+";
      l[24] = "!p\u00021/rTP\t>>=5^\u00025:gA";
      l[25] = "w+P\\\u001b@a+U\u0006\bWv`V\u0000\u0004Cg'A\u0017OTY";
      l[26] = "\n\u00197A\u0016~\u007f9<N\u00071\u001e77E\u0003kj";
      l[27] = "H{4`r\t^{1:a\u001eI02<m\nXw%+&\u001dg";
      l[28] = "\u0018\u0006]2\"\tm&V=3F\f(]67\u001cx";
      l[29] = "\u0001\u0002\u0006ws6\u0017\u0002\u0003-`!\u0000I\u0000+l5\u0011\u000e\u0017<'$/";
      l[30] = "tl)\f.^\u0001L\"\u0003?\u0011`B)\b;K\u0014";
      l[31] = ".EHA[w%JY\u000e<u0AYE\u0007";
      l[32] = "\u0017F|\u0000w\u0001\u001d\u0015\u007f\u0002\tP,\u0017}SyAGPc\u000ed9\u0017M!\u001eqRPS|\u0003\t";
      l[33] = "'x#B&7zx4BHf\u001br6Gtip*/Gp\f&h#\u0018rlp-%EH";
      l[34] = ";*S`\u001f.pnF`%\u007f\u000b$U{\u001dmeq\n~I\u0015";
      l[35] = "B%7\u001cm^L4c^SF\u0015?^\u001d8DF)3]n\u001b\u0001OaI4\u0019\u001a\"!\u001fk^|p5EiE\u00110c\u001a.#";
      l[36] = "m\u0015~)\u0002\u00189\u0003a.f\u0000\u0000\rrhZ\fkUkh^im\u0015~)\u0002\u00189\u0003a.f";
      l[37] = "=\u0010tjJI9\rp;%\u0018V\u00150=\u0019\u0016=M)=\u001dsk\u000f%b\u001f\u0013=J#?%";
      l[38] = "rP4?\u0018R|A`}&J-\\]>MHv\\0~\u001b\u00171:bjA\u0015*W\"<\u001eRL\u00056f\u001cI!E`9[/";
      l[39] = "7\u0004\u001f$#\u0006$\b\u001d?\u001a\u0003X\f\u0011\u007f&\u000f3T\b\u007f\"j7\u0004\u001f$#\u0006$\b\u001d?\u001a";
      l[40] = "Vq\\^\r~\u0012e\u001dd\u001br\by\r\r\u0017K\u0006y\u001d\tq,QyX\u0004\u001f+\u001e`\u000fd";
      l[41] = "w\u0005\u0011yr\u0010<A\u0004yH@G\u000b\u0017bpS)^Hg$+";
      l[42] = "p*D(S2n8\u00011.f\u0013+\u0000q\u0012ixs\u0019q\u0016\f.1\u0015.\u0014lxt\u0013s.";
      l[43] = "apwhB`zn2:#s\u0001wwh\u001f\u007fj/nh\u001b\u001aapwhB`zn2:#";
      l[44] = "%\u001f_N-CsYZ\u0007PR\u001cYBC(Qc\rQC.;";
      l[45] = "+>eAW?2odIl$(xPN\b8#\u0004>H\u0013}6jk\u0017\u0016)N";
      l[46] = "{N\r\u0007#Pz\u0002\u0007C\u0013\u0001\u0019\u0013\u001b\u0003/\rrK\u0002\u0003+h{N\r\u0007#Pz\u0002\u0007C\u0013";
      l[47] = "rz7cS%/z c=uNp\"f\u0001{%(;f\u0005\u001esj79\u0007~%/1d=";
      l[48] = "\u0012\u0004\f/_MR\u001e\rl'[G\u0018\u0019oy\\G\u0002\u001d\u0013\u0018^DE\u0016~X\b\u001b\u0002p";
      l[49] = "\u001d\u001d\u0019Xf\u0013]\u0007\u0018\u001b\u001e\u0015E\u0002\u0018\tY\u0005,Y\u000e\u0003$\rA\u0019X\\ck\u001d\u001d\u0019Xf\u0013]\u0007\u0018\u001b\u001e";
      l[50] = "\u000b@smM'\u000f]w<\"w`E7:\u001ex\u000b\u001d.:\u001a\u001d]_\"e\u0018}\u000b\u001a$8\"";
      l[51] = "~\u0019tk'Y#\u0019ckI\u000eB\u0013anu\u0007)Kxnqb\u007f\tt1s\u0002)LrlI";
      l[52] = "DIX\u0016\u0007\u001b\u000f\rM\u0016=It\u0014MO\u0001E\u001fLTO\u0005 I\u000eX\u0010\u0007@\u001fK^M=";
      l[53] = "F'S{N9\u001b'D{ oz-F~\u001cg\u0011u_~\u0018\u0002G7S!\u001ab\u0011rU| ";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(279736840805683L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(279736840805683L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(279736840805683L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 240;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 230;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 231;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 200;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 66;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 87;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 240;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 230;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 231;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dS_C0199",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(Ambience var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dS_C0199;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dS_C0199", "lambda$new$4", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Ambience)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(Ambience var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dS_C0199;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dS_C0199", "lambda$new$2", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Ambience)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(Ambience var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dS_C0199;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dS_C0199", "lambda$new$5", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Ambience)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(Ambience var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dS_C0199;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dS_C0199", "lambda$new$3", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Ambience)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(Ambience var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dS_C0199;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dS_C0199", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Ambience)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(Ambience var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dS_C0199;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dS_C0199", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Ambience)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
