package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.InteractionUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AnchorExploder extends Module implements RotationSource {
   private BooleanSetting d;
   private MinMaxSetting a;
   private BooleanSetting c;
   private ModeSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private ModeSetting h;
   private IntSetting i;
   private BooleanSetting j;
   private BooleanSetting k;
   private BooleanSetting l;
   private MultiModeSetting m;
   private FloatSetting n;
   public static boolean o;
   private ElapsedTimer p;
   private ArrayList q;
   private int r;
   private int s;
   private static final long t = 21051731208211L;
   private static final String[] u;
   private static final String[] v;
   private static final Map w = new HashMap(13);
   private static final long x;
   private static final Object[] y = new Object[192];
   private static final String[] z = new String[192];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;

   public AnchorExploder() {
      super();
      long var10001 = 116241503042173L ^ 9560778804564L;
      var10001 = 116241503042173L ^ 130628339992746L;
      var10001 = 116241503042173L ^ 86029017301407L;
      var10001 = 116241503042173L ^ 7840088091065L;
      var10001 = 116241503042173L ^ 63195576693201L;

      this.p = new ElapsedTimer(106698256430889L);
      this.q = new ArrayList();
      this.r = -1;
      this.s = -1;
      ModeSetting var10000 = this.e;
      Object[] var14 = new Object[]{invokeBinding1(this), 121607650890692L};
      ModeSetting var13 = var10000;
      var13.aReturningModeSetting(var14);
      BooleanSetting var27 = this.j;
      Object[] var16 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var15 = var27;
      var15.aReturningBooleanSetting(var16);
      BooleanSetting var28 = this.k;
      Object[] var18 = new Object[]{invokeBinding3(this), 88791076916140L};
      BooleanSetting var17 = var28;
      var17.aReturningBooleanSetting(var18);
      IntSetting var29 = this.i;
      Object[] var20 = new Object[]{invokeBinding4(this), 43459238656994L};
      IntSetting var19 = var29;
      var19.aReturningIntSetting(var20);
      FloatSetting var30 = this.n;
      Object[] var22 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var21 = var30;
      var21.aReturningFloatSetting(var22);
      BooleanSetting var31 = this.f;
      Object[] var24 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var23 = var31;
      var23.aReturningBooleanSetting(var24);
      var10000 = this.h;
      Object[] var26 = new Object[]{invokeBinding7(this), 121607650890692L};
      ModeSetting var25 = var10000;
      var25.aReturningModeSetting(var26);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Boolean var10000 = Boolean.FALSE;
      BooleanSetting var4 = this.l;
      Object var6 = var4.aReturningObject();
      Boolean var5 = var10000;
      return var5.equals(var6);
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 8610144168404L ^ 131531517364226L;
      int var6 = Event.cReturningInt();
      Object[] var8 = new Object[]{123644152586710L};
      AnchorExploder var7 = this;
      int var10000 = var7.bReturningInt(var8);
      int var22 = var6;
      int var21 = var10000;
      int var20 = var21;
      int var19 = var21;
      if (var22 != 0) {
         int var24 = (int)x;
         int var23 = var19;
         if (var23 != var24) {
            return;
         }

         MinecraftClient var10 = b;
         ClientPlayerEntity var11 = var10.player;
         ItemStack var12 = var11.getMainHandStack();
         Item var27 = var12.getItem();
         Block var13 = Blocks.GLOWSTONE;
         Item var15 = var13.asItem();
         Item var14 = var27;
         byte var25 = ((byte)((var14.equals(var15)) ? 1 : 0));
         var20 = var25;
      }

      int var26 = var20;
      if (var26 != 0) {
         Object[] var18 = new Object[0];
         ItemUseEvent var17 = var1;
         var17.aReturningVoid(var18);
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      ArrayList var6 = this.q;
      var6.clear();
      this.r = -1;
      this.s = -1;
      o = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var10000 = Prestige.o;
      Object[] var8 = new Object[]{this, var4};
      RotationManager var7 = var10000;
      var7.eReturningVoid(var8);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      ArrayList var4 = this.q;
      var4.clear();
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 24278086404111L ^ 81263659066849L;
      var10001 = 24278086404111L ^ 104598373894822L;
      var10001 = 24278086404111L ^ 112009122985536L;
      var10001 = 24278086404111L ^ 53747121266703L;
      var10001 = 24278086404111L ^ 118164697168107L;
      var10001 = 24278086404111L ^ 106670708724340L;
      int var16 = Event.bReturningInt();
      int var91 = var16;
      MinecraftClient var90 = b;
      MinecraftClient var66 = var90;
      MinecraftClient var65 = var90;
      if (var91 == 0) {
         MinecraftClient var19 = var65;
         Screen var92 = var19.currentScreen;
         if (var92 != null) {
            return;
         }

         MinecraftClient var93 = b;
         var66 = var93;
      }

      MinecraftClient var22 = var66;
      boolean var10000 = var22.isWindowFocused();
      int var95 = var16;
      boolean var94 = var10000;
      boolean var68 = var94;
      boolean var67 = var94;
      if (var95 == 0) {
         boolean var96 = var67;
         if (!var96) {
            return;
         }

         MinecraftClient var24 = b;
         ClientPlayerEntity var25 = var24.player;
         boolean var97 = var25.isUsingItem();
         var68 = var97;
      }

      int var99 = var16;
      boolean var98 = var68;
      boolean var70 = var98;
      boolean var69 = var98;
      if (var99 == 0) {
         boolean var100 = var69;
         if (var100) {
            return;
         }

         RotationManager var137 = Prestige.o;
         Object[] var29 = new Object[0];
         RotationManager var28 = var137;
         var70 = var28.fReturningBoolean(var29);
      }

      int var102 = var16;
      boolean var101 = var70;
      boolean var72 = var101;
      boolean var71 = var101;
      if (var102 == 0) {
         boolean var103 = var71;
         if (var103) {
            return;
         }

         var72 = AutoObbyCrystal.R;
      }

      int var105 = var16;
      boolean var104 = var72;
      boolean var74 = var104;
      boolean var73 = var104;
      if (var105 == 0) {
         boolean var106 = var73;
         if (var106) {
            return;
         }

         ElapsedTimer var138 = this.p;
         Object[] var33 = new Object[]{this.a, 130913203968635L};
         ElapsedTimer var32 = var138;
         var74 = var32.bReturningBoolean(var33);
      }

      int var108 = var16;
      boolean var107 = var74;
      boolean var76 = var107;
      boolean var75 = var107;
      if (var108 == 0) {
         boolean var109 = var75;
         if (!var109) {
            return;
         }

         ElapsedTimer var139 = this.p;
         Object[] var36 = new Object[]{42835128969216L};
         ElapsedTimer var35 = var139;
         var35.aReturningVoid(var36);
         MinMaxSetting var140 = this.a;
         Object[] var38 = new Object[]{127318019014223L};
         MinMaxSetting var37 = var140;
         var37.bReturningVoid(var38);
         BooleanSetting var39 = this.d;
         Boolean var40 = (Boolean)var39.aReturningObject();
         var76 = var40;
      }

      int var111 = var16;
      boolean var110 = var76;
      boolean var77 = var110;
      if (var111 == 0) {
         boolean var112 = var77;
         if (var112) {
            ArrayList var141 = this.q;
            Predicate var43 = invokeBinding8();
            ArrayList var42 = var141;
            boolean var113 = var42.removeIf(var43);
         }
      }

      MinecraftClient var45 = b;
      HitResult var18 = var45.crosshairTarget;
      int var115 = var16;
      HitResult var114 = var18;
      HitResult var80 = var114;
      HitResult var79 = var114;
      if (var115 == 0) {
         boolean var116 = var79 instanceof BlockHitResult;
         if (!var116) {
            return;
         }

         HitResult var117 = var18;
         var80 = var117;
      }

      BlockHitResult var17 = (BlockHitResult)var80;
      int var118 = var16;
      if (var118 == 0) {
         BlockHitResult var49 = var17;
         Object[] var50 = new Object[]{var49.getBlockPos(), Blocks.RESPAWN_ANCHOR, 105536024440302L};
         byte var136 = ((byte)((BlockUtil.kReturningBoolean(var50)) ? 1 : 0));
         int var120 = var16;
         byte var119 = var136;
         byte var89 = var119;
         byte var81 = var119;
         if (var120 == 0) {
            byte var121 = var81;
            if (var121 != 0) {
               AnchorExploder var88;
               label127: {
                  boolean var87;
                  o = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  BooleanSetting var52 = this.c;
                  Boolean var53 = (Boolean)var52.aReturningObject();
                  var10000 = var53;
                  int var123 = var16;
                  boolean var122 = var10000;
                  var87 = var122;
                  boolean var82 = var122;
                  label86:
                  if (var123 == 0) {
                     boolean var124 = var82;
                     boolean var83 = var124;
                     boolean var125 = var83;
                     if (var125) {
                        Object[] var57 = new Object[]{80492424381097L};
                        AnchorExploder var56 = this;
                        var10000 = var56.dReturningBoolean(var57);
                        int var127 = var16;
                        boolean var126 = var10000;
                        var87 = var126;
                        boolean var84 = var126;
                        if (var127 != 0) {
                           break label86;
                        }

                        boolean var128 = var84;
                        boolean var85 = var128;
                        boolean var129 = var85;
                        if (var129) {
                           return;
                        }
                     }

                     int var131 = var16;
                     AnchorExploder var130 = this;
                     var88 = var130;
                     AnchorExploder var86 = var130;
                     if (var131 != 0) {
                        break label127;
                     }

                     BooleanSetting var60 = var86.g;
                     Boolean var61 = (Boolean)var60.aReturningObject();
                     boolean var132 = var61;
                     var87 = var132;
                  }

                  boolean var133 = var87;
                  if (!var133) {
                     return;
                  }

                  var88 = this;
               }

               Object[] var64 = new Object[]{137906878148836L};
               AnchorExploder var63 = var88;
               var63.jReturningVoid(var64);
               int var134 = var16;
               if (var134 == 0) {
                  return;
               }
            }

            byte var135 = 0;
            var89 = var135;
         }

         o = dev.prestige.recovery.SourceSupport.asBoolean(var89);
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2;
      long var4;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      long var18;
      long var20;
      long var22;
      long var24;
      long var26;
      long var28;
      long var30;
      long var32;
      long var34;
      int var36;
      byte var222;
      var2 = (Long)var1[0];
      var4 = var2 ^ 75092756173221L;
      var6 = var2 ^ 65762800970131L;
      var8 = var2 ^ 138007752420630L;
      var10 = var2 ^ 4547998816304L;
      var12 = var2 ^ 59641449638428L;
      var14 = var2 ^ 109453026100622L;
      var16 = var2 ^ 59700249274437L;
      var18 = var2 ^ 29904810088371L;
      var20 = var2 ^ 77379818547405L;
      var22 = var2 ^ 96421272380508L;
      var24 = var2 ^ 19182256418671L;
      var26 = var2 ^ 12834862060505L;
      var28 = var2 ^ 136934149894670L;
      var30 = var2 ^ 101783648619701L;
      var32 = var2 ^ 134366226930033L;
      var34 = var2 ^ 8161740823097L;
      var36 = Event.bReturningInt();
      MultiModeSetting var10000 = this.m;
      short var10001 = 5093;
      long var10002 = 1293072946247443410L ^ var2;
      Object[] var56 = new Object[]{"Glowstone", var28};
      MultiModeSetting var55 = var10000;
      byte var477 = ((byte)((var55.aReturningBoolean(var56)) ? 1 : 0));
      int var308 = var36;
      byte var307 = var477;
      var222 = var307;
      byte var219 = var307;
      label443:
      if (var308 == 0) {
         byte var309 = var219;
         if (var309 == 0) {
            var10000 = this.m;
            var10001 = 3160;
            var10002 = 7487560567969365098L ^ var2;
            Object[] var59 = new Object[]{"Explode", var28};
            MultiModeSetting var58 = var10000;
            byte var479 = ((byte)((var58.aReturningBoolean(var59)) ? 1 : 0));
            int var311 = var36;
            byte var310 = var479;
            var222 = var310;
            byte var220 = var310;
            if (var311 != 0) {
               break label443;
            }

            byte var312 = var220;
            byte var221 = var312;
            byte var313 = var221;
            if (var313 == 0) {
               return null;
            }
         }

         MinecraftClient var63 = b;
         ClientPlayerEntity var64 = var63.player;
         var222 = ((byte)((var64.isUsingItem()) ? 1 : 0));
      }

      int var315 = var36;
      byte var314 = var222;
      byte var224 = var314;
      byte var223 = var314;
      if (var315 == 0) {
         byte var316 = var223;
         if (var316 != 0) {
            return null;
         }

         RotationManager var480 = Prestige.o;
         Object[] var68 = new Object[0];
         RotationManager var67 = var480;
         var224 = ((byte)((var67.fReturningBoolean(var68)) ? 1 : 0));
      }

      int var318 = var36;
      byte var317 = var224;
      byte var226 = var317;
      byte var225 = var317;
      if (var318 == 0) {
         byte var319 = var225;
         if (var319 != 0) {
            return null;
         }

         var10000 = this.m;
         var10001 = 5093;
         var10002 = 1293072946247443410L ^ var2;
         Object[] var72 = new Object[]{"Glowstone", var28};
         MultiModeSetting var71 = var10000;
         var226 = ((byte)((var71.aReturningBoolean(var72)) ? 1 : 0));
      }

      byte var231;
      label433: {
         byte var230;
         label432: {
            label446: {
               int var321 = var36;
               byte var320 = var226;
               byte var228 = var320;
               byte var227 = var320;
               if (var321 == 0) {
                  byte var322 = var227;
                  if (var322 == 0) {
                     break label446;
                  }

                  BooleanSetting var74 = this.c;
                  Boolean var75 = (Boolean)var74.aReturningObject();
                  byte var323 = ((byte)(((java.lang.Boolean)(var75)).booleanValue() ? 1 : 0));
                  var228 = var323;
               }

               int var325 = var36;
               byte var324 = var228;
               var230 = var324;
               byte var229 = var324;
               if (var325 != 0) {
                  break label432;
               }

               byte var326 = var229;
               if (var326 != 0) {
                  var230 = 1;
                  break label432;
               }
            }

            var231 = 0;
            break label433;
         }

         byte var327 = var230;
         var231 = var327;
      }

      byte var37;
      byte var236;
      label420: {
         byte var235;
         label419: {
            label447: {
               var37 = var231;
               var10000 = this.m;
               var10001 = 3160;
               var10002 = 7487560567969365098L ^ var2;
               Object[] var79 = new Object[]{"Explode", var28};
               MultiModeSetting var78 = var10000;
               byte var483 = ((byte)((var78.aReturningBoolean(var79)) ? 1 : 0));
               int var329 = var36;
               byte var328 = var483;
               byte var233 = var328;
               byte var232 = var328;
               if (var329 == 0) {
                  byte var330 = var232;
                  if (var330 == 0) {
                     break label447;
                  }

                  BooleanSetting var81 = this.g;
                  Boolean var82 = (Boolean)var81.aReturningObject();
                  byte var331 = ((byte)(((java.lang.Boolean)(var82)).booleanValue() ? 1 : 0));
                  var233 = var331;
               }

               int var333 = var36;
               byte var332 = var233;
               var235 = var332;
               byte var234 = var332;
               if (var333 != 0) {
                  break label419;
               }

               byte var334 = var234;
               if (var334 != 0) {
                  var235 = 1;
                  break label419;
               }
            }

            var236 = 0;
            break label420;
         }

         byte var335 = var235;
         var236 = var335;
      }

      byte var38;
      label407: {
         var38 = var236;
         int var337 = var36;
         byte var336 = var37;
         byte var238 = var336;
         byte var237 = var336;
         if (var337 == 0) {
            byte var338 = var237;
            if (var338 != 0) {
               break label407;
            }

            var238 = var38;
         }

         byte var339 = var238;
         if (var339 == 0) {
            return null;
         }
      }

      label401: {
         MinecraftClient var87 = b;
         HitResult var40 = var87.crosshairTarget;
         int var341 = var36;
         HitResult var340 = var40;
         HitResult var240 = var340;
         HitResult var239 = var340;
         if (var341 == 0) {
            boolean var342 = var239 instanceof BlockHitResult;
            if (!var342) {
               break label401;
            }

            HitResult var343 = var40;
            var240 = var343;
         }

         BlockHitResult var39 = (BlockHitResult)var240;
         BlockHitResult var90 = var39;
         Object[] var91 = new Object[]{var90.getBlockPos(), Blocks.RESPAWN_ANCHOR, var14};
         boolean var344 = BlockUtil.kReturningBoolean(var91);
         if (var344) {
            return null;
         }
      }

      Rotation var466 = null;
      double var41 = Double.MAX_VALUE;
      Object[] var10004 = new Object[]{null, invokeBinding9(), var10};
      var10004[0] = 5;
      Object[] var93 = var10004;
      List var94 = BlockUtil.aReturningList(var93);
      Iterator var43 = var94.iterator();

      int var271;
      while (true) {
         Iterator var95 = var43;
         boolean var345 = var95.hasNext();
         if (var345) {
            Iterator var96 = var43;
            BlockPos var44 = (BlockPos)var96.next();
            Object[] var97 = new Object[]{var18};
            Vec3d var484 = RaycastUtil.bReturningVec3d(var97);
            BlockPos var98 = var44;
            Vec3d var100 = var98.toCenterPos();
            Vec3d var99 = var484;
            double var485 = var99.distanceTo(var100);
            Object[] var101 = new Object[]{var22};
            double var519;
            int var486 = (var519 = var485 - ItemUseUtil.bReturningFloat(var101)) == 0.0 ? 0 : (var519 < 0.0 ? -1 : 1);
            int var347 = var36;
            int var346 = var486;
            var271 = var346;
            int var241 = var346;
            if (var347 != 0) {
               break;
            }

            int var349 = var36;
            int var348 = var241;
            int var244 = var348;
            int var242 = var348;
            if (var349 == 0) {
               int var350 = var242;
               int var243 = var350;
               int var351 = var243;
               if (var351 > 0) {
                  continue;
               }

               BooleanSetting var104 = this.d;
               Boolean var105 = (Boolean)var104.aReturningObject();
               var244 = ((((java.lang.Boolean)(var105)).booleanValue() ? 1 : 0));
            }

            int var248;
            int var353 = var36;
            int var352 = var244;
            var248 = var352;
            int var245 = var352;
            label388:
            if (var353 == 0) {
               int var354 = var245;
               if (var354 != 0) {
                  BlockPos var108 = var44;
                  ArrayList var107 = this.q;
                  byte var487 = ((byte)((var107.contains(var108)) ? 1 : 0));
                  int var356 = var36;
                  byte var355 = var487;
                  var248 = var355;
                  byte var246 = var355;
                  if (var356 != 0) {
                     break label388;
                  }

                  byte var357 = var246;
                  byte var247 = var357;
                  byte var358 = var247;
                  if (var358 == 0) {
                     continue;
                  }
               }

               Object[] var111 = new Object[]{var44, var26};
               var248 = BlockUtil.aReturningInt(var111);
            }

            int var45;
            int var253;
            label381: {
               int var252;
               label380: {
                  label451: {
                     var45 = var248;
                     int var360 = var36;
                     byte var359 = var37;
                     int var250 = var359;
                     byte var249 = var359;
                     if (var360 == 0) {
                        byte var361 = var249;
                        if (var361 == 0) {
                           break label451;
                        }

                        var250 = var45;
                     }

                     int var363 = var36;
                     int var362 = var250;
                     var252 = var362;
                     int var251 = var362;
                     if (var363 != 0) {
                        break label380;
                     }

                     int var364 = var251;
                     if (var364 == 0) {
                        var252 = 1;
                        break label380;
                     }
                  }

                  var253 = 0;
                  break label381;
               }

               int var365 = var252;
               var253 = var365;
            }

            int var46;
            int var258;
            label368: {
               int var257;
               label367: {
                  label452: {
                     var46 = var253;
                     int var367 = var36;
                     byte var366 = var38;
                     int var255 = var366;
                     byte var254 = var366;
                     if (var367 == 0) {
                        byte var368 = var254;
                        if (var368 == 0) {
                           break label452;
                        }

                        var255 = var45;
                     }

                     int var370 = var36;
                     int var369 = var255;
                     var257 = var369;
                     int var256 = var369;
                     if (var370 != 0) {
                        break label367;
                     }

                     int var371 = var256;
                     if (var371 > 0) {
                        var257 = 1;
                        break label367;
                     }
                  }

                  var258 = 0;
                  break label368;
               }

               int var372 = var257;
               var258 = var372;
            }

            label355: {
               int var47 = var258;
               int var374 = var36;
               int var373 = var46;
               int var260 = var373;
               int var259 = var373;
               if (var374 == 0) {
                  int var375 = var259;
                  if (var375 != 0) {
                     break label355;
                  }

                  var260 = var47;
               }

               int var376 = var260;
               if (var376 == 0) {
                  continue;
               }
            }

            Vec3d var48;
            label349: {
               Object[] var117 = new Object[]{var44, var4};
               var48 = InteractionUtil.bReturningVec3d(var117);
               int var378 = var36;
               Vec3d var377 = var48;
               Vec3d var262 = var377;
               Vec3d var261 = var377;
               if (var378 == 0) {
                  Vec3d var379 = var261;
                  if (var379 != null) {
                     break label349;
                  }

                  BlockPos var119 = var44;
                  Vec3d var380 = var119.toCenterPos();
                  var262 = var380;
               }

               var48 = var262;
            }

            RotationManager var488 = Prestige.o;
            Object[] var122 = new Object[]{var48, var20};
            RotationManager var121 = var488;
            Rotation var49 = var121.aReturningdx_C0210(var122);
            Object[] var123 = new Object[]{var49, var48, var30};
            var49 = RotationUtil.dReturningdx_C0210(var123);
            Object[] var125 = new Object[0];
            Rotation var124 = var49;
            float var489 = var124.aReturningFloat(var125);
            MinecraftClient var126 = b;
            ClientPlayerEntity var127 = var126.player;
            float var50 = var489 - var127.getYaw();
            FloatSetting var128 = this.n;
            Float var129 = (Float)var128.aReturningObject();
            float var520;
            int var490 = (var520 = var50 - var129) == 0.0F ? 0 : (var520 < 0.0F ? -1 : 1);
            int var382 = var36;
            int var381 = var490;
            int var264 = var381;
            int var263 = var381;
            if (var382 == 0) {
               int var383 = var263;
               if (var383 > 0) {
                  continue;
               }

               FloatSetting var131 = this.n;
               Float var132 = (Float)var131.aReturningObject();
               float var521;
               var264 = (var521 = var50 - -var132) == 0.0F ? 0 : (var521 < 0.0F ? -1 : 1);
            }

            int var384 = var264;
            if (var384 < 0) {
               continue;
            }

            Object[] var133 = new Object[]{var49, var12};
            HitResult var51 = RotationUtil.aReturningHitResult(var133);
            int var386 = var36;
            HitResult var385 = var51;
            HitResult var266 = var385;
            HitResult var265 = var385;
            if (var386 == 0) {
               boolean var387 = var265 instanceof BlockHitResult;
               if (!var387) {
                  continue;
               }

               var266 = var51;
            }

            BlockHitResult var52 = (BlockHitResult)var266;
            BlockHitResult var135 = var52;
            BlockPos var491 = var135.getBlockPos();
            BlockPos var137 = var44;
            BlockPos var136 = var491;
            boolean var388 = var136.equals(var137);
            if (!var388) {
               continue;
            }

            label337: {
               Object[] var139 = new Object[]{var18};
               Vec3d var492 = RaycastUtil.bReturningVec3d(var139);
               BlockPos var140 = var44;
               Vec3d var142 = var140.toCenterPos();
               Vec3d var141 = var492;
               double var53 = var141.distanceTo(var142);
               double var522;
               int var493 = (var522 = var53 - var41) == 0.0 ? 0 : (var522 < 0.0 ? -1 : 1);
               int var390 = var36;
               int var389 = var493;
               int var268 = var389;
               int var267 = var389;
               if (var390 == 0) {
                  int var391 = var267;
                  if (var391 >= 0) {
                     break label337;
                  }

                  var41 = var53;
                  var466 = var49;
                  var268 = var46;
               }

               var467 = var268;
            }

            int var392 = var36;
            if (var392 == 0) {
               continue;
            }
         }

         int var394 = var36;
         Rotation var393 = var466;
         Rotation var270 = var393;
         Rotation var269 = var393;
         if (var394 == 0) {
            Rotation var395 = var269;
            if (var395 == null) {
               return null;
            }

            var270 = var466;
         }

         Object[] var147 = new Object[0];
         Rotation var146 = var270;
         var271 = (((var146.aReturningBoolean(var147)) ? 1 : 0));
         break;
      }

      int var397 = var36;
      int var396 = var271;
      int var273 = var396;
      int var272 = var396;
      if (var397 == 0) {
         int var398 = var272;
         if (var398 != 0) {
            return var466;
         }

         var273 = var467;
      }

      int var468 = var273;
      Object[] var150 = new Object[]{var466, var12};
      HitResult var469 = RotationUtil.aReturningHitResult(var150);
      int var400 = var36;
      HitResult var399 = var469;
      HitResult var275 = var399;
      HitResult var274 = var399;
      if (var400 == 0) {
         boolean var401 = var274 instanceof BlockHitResult;
         if (!var401) {
            return null;
         }

         HitResult var402 = var469;
         var275 = var402;
      }

      BlockHitResult var470 = (BlockHitResult)var275;
      int var403 = var36;
      if (var403 == 0) {
         int var404 = var468;
         if (var404 != 0) {
            int var281;
            ModeSetting var154 = this.e;
            String var471 = (String)var154.aReturningObject();
            // String var155 = var471;
            int var494 = var155.hashCode();
            int var406 = var36;
            int var405 = var494;
            var281 = var405;
            int var276 = var405;
            label296:
            if (var406 == 0) {
               int var407 = var276;
               switch (var407) {
                  case 2433880:
                     var10001 = 27884;
                     var10002 = 4273404986663623896L ^ var2;
                     String var158 = "None";
                     String var157 = var471;
                     byte var495 = ((byte)((var157.equals(var158)) ? 1 : 0));
                     int var409 = var36;
                     byte var408 = var495;
                     var281 = var408;
                     byte var277 = var408;
                     if (var409 != 0) {
                        break label296;
                     }

                     byte var410 = var277;
                     byte var278 = var410;
                     byte var411 = var278;
                     if (var411 == 0) {
                        break;
                     }

                     var474 = 0;
                     int var412 = var36;
                     if (var412 == 0) {
                        break;
                     }
                  case 2590131:
                     var10001 = 5855;
                     var10002 = 12622144128984815L ^ var2;
                     String var162 = "Swap";
                     String var161 = var471;
                     byte var496 = ((byte)((var161.equals(var162)) ? 1 : 0));
                     int var414 = var36;
                     byte var413 = var496;
                     var281 = var413;
                     byte var279 = var413;
                     if (var414 != 0) {
                        break label296;
                     }

                     byte var415 = var279;
                     byte var280 = var415;
                     byte var416 = var280;
                     if (var416 != 0) {
                        var474 = 1;
                     }
               }

               var281 = var474;
            }

            int var418 = var36;
            int var417 = var281;
            int var282 = var417;
            label289:
            if (var418 == 0) {
               int var419 = var282;
               switch (var419) {
                  case 0:
                     Object[] var166 = new Object[]{Items.GLOWSTONE, var6};
                     boolean var498 = InventoryUtil.lReturningBoolean(var166);
                     int var421 = var36;
                     boolean var420 = var498;
                     boolean var283 = var420;
                     if (var421 != 0) {
                        break label289;
                     }

                     boolean var422 = var283;
                     boolean var284 = var422;
                     boolean var423 = var284;
                     if (!var423) {
                        return null;
                     }
                     break;
                  case 1:
                     BooleanSetting var170 = this.f;
                     Boolean var171 = (Boolean)var170.aReturningObject();
                     boolean var497 = var171;
                     int var425 = var36;
                     boolean var424 = var497;
                     boolean var286 = var424;
                     boolean var285 = var424;
                     if (var425 == 0) {
                        boolean var426 = var285;
                        if (var426) {
                           Object[] var173 = new Object[]{var24};
                           this.r = InventoryUtil.aReturningInt(var173);
                        }

                        Object[] var175 = new Object[]{Blocks.GLOWSTONE, var34};
                        var286 = InventoryUtil.iReturningVoid(var175);
                     }

                     int var428 = var36;
                     boolean var427 = var286;
                     boolean var287 = var427;
                     if (var428 != 0) {
                        break label289;
                     }

                     boolean var429 = var287;
                     if (!var429) {
                        return null;
                     }
               }

               Object[] var178 = new Object[]{var470, var16};
               boolean var288 = ItemUseUtil.aReturningBoolean(var178);
            }

            int var430 = var36;
            if (var430 == 0) {
               return var466;
            }
         }

         int var294;
         ModeSetting var179 = this.h;
         String var472 = (String)var179.aReturningObject();
         // String var180 = var472;
         int var499 = var180.hashCode();
         int var432 = var36;
         int var431 = var499;
         var294 = var431;
         int var289 = var431;
         label267:
         if (var432 == 0) {
            int var433 = var289;
            switch (var433) {
               case 2433880:
                  var10001 = 27884;
                  var10002 = 4273404986663623896L ^ var2;
                  String var183 = "None";
                  String var182 = var472;
                  byte var500 = ((byte)((var182.equals(var183)) ? 1 : 0));
                  int var435 = var36;
                  byte var434 = var500;
                  var294 = var434;
                  byte var290 = var434;
                  if (var435 != 0) {
                     break label267;
                  }

                  byte var436 = var290;
                  byte var291 = var436;
                  byte var437 = var291;
                  if (var437 == 0) {
                     break;
                  }

                  var475 = 0;
                  int var438 = var36;
                  if (var438 == 0) {
                     break;
                  }
               case 2590131:
                  var10001 = 5855;
                  var10002 = 12622144128984815L ^ var2;
                  String var187 = "Swap";
                  String var186 = var472;
                  byte var501 = ((byte)((var186.equals(var187)) ? 1 : 0));
                  int var440 = var36;
                  byte var439 = var501;
                  var294 = var439;
                  byte var292 = var439;
                  if (var440 != 0) {
                     break label267;
                  }

                  byte var441 = var292;
                  byte var293 = var441;
                  byte var442 = var293;
                  if (var442 != 0) {
                     var475 = 1;
                  }
            }

            var294 = var475;
         }

         int var300;
         int var444 = var36;
         int var443 = var294;
         var300 = var443;
         int var295 = var443;
         label260:
         if (var444 == 0) {
            int var445 = var295;
            switch (var445) {
               case 0:
                  IntSetting var191 = this.i;
                  Integer var192 = (Integer)var191.aReturningObject();
                  int var503 = var192 - 1;
                  int var447 = var36;
                  int var446 = var503;
                  var300 = var446;
                  int var296 = var446;
                  if (var447 != 0) {
                     break label260;
                  }

                  int var448 = var296;
                  int var297 = var448;
                  Object[] var194 = new Object[]{var24};
                  int var450 = InventoryUtil.aReturningInt(var194);
                  int var449 = var297;
                  if (var449 != var450) {
                     return null;
                  }
                  break;
               case 1:
                  BooleanSetting var197 = this.j;
                  Boolean var198 = (Boolean)var197.aReturningObject();
                  byte var502 = ((byte)(((java.lang.Boolean)(var198)).booleanValue() ? 1 : 0));
                  int var452 = var36;
                  byte var451 = var502;
                  int var299 = var451;
                  byte var298 = var451;
                  if (var452 == 0) {
                     byte var453 = var298;
                     if (var453 != 0) {
                        Object[] var200 = new Object[]{var24};
                        this.s = InventoryUtil.aReturningInt(var200);
                     }

                     IntSetting var202 = this.i;
                     Integer var203 = (Integer)var202.aReturningObject();
                     var299 = var203 - 1;
                  }

                  Object[] var10003 = new Object[]{null, var8};
                  var10003[0] = var299;
                  Object[] var204 = var10003;
                  InventoryUtil.aReturningVoid(var204);
            }

            BooleanSetting var205 = this.k;
            Boolean var206 = (Boolean)var205.aReturningObject();
            var300 = ((((java.lang.Boolean)(var206)).booleanValue() ? 1 : 0));
         }

         int var455 = var36;
         int var454 = var300;
         int var301 = var454;
         if (var455 == 0) {
            int var456 = var301;
            if (var456 != 0) {
               Object[] var208 = new Object[]{var32};
               PlayerEntity var473 = EntityUtil.aReturningPlayerEntity(var208);
               PlayerEntity var457 = var473;
               if (var457 != null) {
                  MinecraftClient var209 = b;
                  PlayerEntity var211 = var473;
                  ClientPlayerEntity var210 = var209.player;
                  float var523;
                  int var504 = (var523 = var210.distanceTo((Entity)var211) - 10.0F) == 0.0F ? 0 : (var523 < 0.0F ? -1 : 1);
                  int var459 = var36;
                  int var458 = var504;
                  int var302 = var458;
                  if (var459 != 0) {
                     return var466;
                  }

                  int var460 = var302;
                  int var303 = var460;
                  int var461 = var303;
                  if (var461 < 0) {
                     PlayerEntity var214 = var473;
                     int var463 = var36;
                     int var462 = var214.hurtTime;
                     int var304 = var462;
                     if (var463 != 0) {
                        return var466;
                     }

                     int var464 = var304;
                     int var305 = var464;
                     int var465 = var305;
                     if (var465 != 0) {
                        return null;
                     }
                  }
               }
            }

            Object[] var218 = new Object[]{var470, var16};
            boolean var306 = ItemUseUtil.aReturningBoolean(var218);
         }

         return var466;
      } else {
         return null;
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 21051731208211L ^ var2;
      long var4 = var2 ^ 6512841213780L;
      long var6 = var2 ^ 88151704824479L;
      long var8 = var2 ^ 103010484087625L;
      long var10 = var2 ^ 130920547855797L;
      long var12 = var2 ^ 30666203131852L;
      long var14 = var2 ^ 120723986125059L;
      long var16 = var2 ^ 106704880687331L;
      int var18 = Event.cReturningInt();
      int var103 = var18;
      int var102 = this.r;
      int var74 = var102;
      int var73 = var102;
      if (var103 != 0) {
         // int var104 = var73;
         if (var104 == var105) {
            MinecraftClient var25 = b;
            HitResult var20 = var25.crosshairTarget;
            int var159 = (((var20 instanceof BlockHitResult) ? 1 : 0));
            int var108 = var18;
            byte var107 = (byte)var159;
            byte var76 = var107;
            byte var75 = var107;
            if (var108 != 0) {
               byte var109 = var75;
               if (var109 != 0) {
                  BlockHitResult var19 = (BlockHitResult)var20;
                  int var110 = var18;
                  if (var110 != 0) {
                     MinecraftClient var28 = b;
                     ClientPlayerEntity var29 = var28.player;
                     var159 = (((var29.isSneaking()) ? 1 : 0));
                     int var113 = var18;
                     byte var112 = ((byte)(var159));
                     byte var87 = var112;
                     byte var77 = var112;
                     if (var113 != 0) {
                        byte var114 = var77;
                        if (var114 == 0) {
                           BlockHitResult var31 = var19;
                           Object[] var32 = new Object[]{var31.getBlockPos(), Blocks.RESPAWN_ANCHOR, var4};
                           var159 = (((BlockUtil.kReturningBoolean(var32)) ? 1 : 0));
                           int var116 = var18;
                           byte var115 = ((byte)(var159));
                           var87 = var115;
                           byte var78 = var115;
                           if (var116 == 0) {
                              return dev.prestige.recovery.SourceSupport.asBoolean(var87);
                           }

                           byte var117 = var78;
                           byte var79 = var117;
                           byte var118 = var79;
                           label111:
                           if (var118 != 0) {
                              Object var88;
                              label137: {
                                 BooleanSetting var35 = this.d;
                                 Boolean var36 = (Boolean)var35.aReturningObject();
                                 var159 = ((((java.lang.Boolean)(var36)).booleanValue() ? 1 : 0));
                                 int var120 = var18;
                                 byte var119 = ((byte)(var159));
                                 int var86 = var119;
                                 byte var80 = var119;
                                 if (var120 != 0) {
                                    byte var121 = var80;
                                    byte var81 = var121;
                                    byte var122 = var81;
                                    if (var122 != 0) {
                                       ArrayList var163 = this.q;
                                       BlockHitResult var39 = var19;
                                       BlockPos var41 = var39.getBlockPos();
                                       ArrayList var40 = var163;
                                       var159 = (((var40.contains(var41)) ? 1 : 0));
                                       int var124 = var18;
                                       byte var123 = ((byte)(var159));
                                       var87 = var123;
                                       byte var82 = var123;
                                       if (var124 == 0) {
                                          return dev.prestige.recovery.SourceSupport.asBoolean(var87);
                                       }

                                       byte var125 = var82;
                                       byte var83 = var125;
                                       byte var126 = var83;
                                       if (var126 == 0) {
                                          break label111;
                                       }
                                    }

                                    BlockHitResult var44 = var19;
                                    BlockPos var165 = var44.getBlockPos();
                                    int var128 = var18;
                                    BlockPos var127 = var165;
                                    var88 = var127;
                                    BlockPos var84 = var127;
                                    if (var128 == 0) {
                                       break label137;
                                    }

                                    BlockPos var129 = var84;
                                    BlockPos var85 = var129;
                                    Object[] var46 = new Object[]{var85, var14};
                                    int var130 = BlockUtil.aReturningInt(var46);
                                    var86 = var130;
                                 }

                                 int var131 = var86;
                                 if (var131 != 0) {
                                    break label111;
                                 }

                                 ModeSetting var48 = this.e;
                                 var88 = var48.aReturningObject();
                              }

                              int var94;
                              String var158 = (String)var88;
                              // String var49 = var158;
                              var159 = var49.hashCode();
                              int var133 = var18;
                              int var132 = var159;
                              var94 = var132;
                              int var89 = var132;
                              label97:
                              if (var133 != 0) {
                                 int var134 = var89;
                                 switch (var134) {
                                    case 2433880:
                                       short var10001 = 16264;
                                       long var10002 = 3255121899805527395L ^ var2;
                                       String var52 = "None";
                                       String var51 = var158;
                                       byte var167 = ((byte)((var51.equals(var52)) ? 1 : 0));
                                       int var136 = var18;
                                       byte var135 = var167;
                                       var94 = var135;
                                       byte var90 = var135;
                                       if (var136 == 0) {
                                          break label97;
                                       }

                                       byte var137 = var90;
                                       byte var91 = var137;
                                       byte var138 = var91;
                                       if (var138 == 0) {
                                          break;
                                       }

                                       var21 = 0;
                                       int var139 = var18;
                                       if (var139 != 0) {
                                          break;
                                       }
                                    case 2590131:
                                       short var171 = 5855;
                                       long var172 = 12580223723201589L ^ var2;
                                       String var56 = "Swap";
                                       String var55 = var158;
                                       byte var168 = ((byte)((var55.equals(var56)) ? 1 : 0));
                                       int var141 = var18;
                                       byte var140 = var168;
                                       var94 = var140;
                                       byte var92 = var140;
                                       if (var141 == 0) {
                                          break label97;
                                       }

                                       byte var142 = var92;
                                       byte var93 = var142;
                                       byte var143 = var93;
                                       if (var143 != 0) {
                                          var21 = 1;
                                       }
                                 }

                                 var94 = var21;
                              }

                              int var145 = var18;
                              int var144 = var94;
                              int var101 = var144;
                              int var95 = var144;
                              if (var145 != 0) {
                                 int var146 = var95;
                                 switch (var146) {
                                    case 0:
                                       Object[] var60 = new Object[]{Items.GLOWSTONE, var8};
                                       boolean var170 = InventoryUtil.lReturningBoolean(var60);
                                       int var148 = var18;
                                       boolean var147 = var170;
                                       boolean var176 = var147;
                                       boolean var96 = var147;
                                       if (var148 == 0) {
                                          return var176;
                                       }

                                       boolean var149 = var96;
                                       boolean var97 = var149;
                                       boolean var150 = var97;
                                       if (!var150) {
                                          return false;
                                       }
                                       break;
                                    case 1:
                                       BooleanSetting var64 = this.f;
                                       Boolean var65 = (Boolean)var64.aReturningObject();
                                       boolean var169 = var65;
                                       int var152 = var18;
                                       boolean var151 = var169;
                                       boolean var99 = var151;
                                       boolean var98 = var151;
                                       if (var152 != 0) {
                                          boolean var153 = var98;
                                          if (var153) {
                                             Object[] var67 = new Object[]{var10};
                                             this.r = InventoryUtil.aReturningInt(var67);
                                          }

                                          Object[] var69 = new Object[]{Blocks.GLOWSTONE, var16};
                                          var99 = InventoryUtil.iReturningVoid(var69);
                                       }

                                       int var155 = var18;
                                       boolean var154 = var99;
                                       boolean var175 = var154;
                                       boolean var100 = var154;
                                       if (var155 == 0) {
                                          return var175;
                                       }

                                       boolean var156 = var100;
                                       if (!var156) {
                                          return false;
                                       }
                                 }

                                 Object[] var72 = new Object[]{var19, var6};
                                 ItemUseUtil.aReturningBoolean(var72);
                                 var101 = 1;
                              }

                              return dev.prestige.recovery.SourceSupport.asBoolean(var101);
                           }
                        }

                        var87 = 0;
                     }

                     return dev.prestige.recovery.SourceSupport.asBoolean(var87);
                  }
               }

               byte var111 = 0;
               var76 = var111;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var76);
         }

         int var10000 = this.r;
         Object[] var10003 = new Object[]{null, var12};
         var10003[0] = var10000;
         Object[] var23 = var10003;
         InventoryUtil.aReturningVoid(var23);
         this.r = -1;
         byte var106 = 0;
         var74 = var106;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var74);
   }

   private void jReturningVoid(Object[] var1) {
      long var4;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      int var18;
      int var98;
      long var197;
      long var2 = (Long)var1[0];
      var197 = 21051731208211L ^ var2;
      var4 = var197 ^ 31429769765039L;
      var6 = var197 ^ 54655802504473L;
      var8 = var197 ^ 110455874541778L;
      var10 = var197 ^ 73992498618360L;
      var12 = var197 ^ 52492553674113L;
      var14 = var197 ^ 98500082148174L;
      long var16 = var197 ^ 44036772932070L;
      var18 = Event.bReturningInt();
      BooleanSetting var22 = this.k;
      Boolean var23 = (Boolean)var22.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var23)).booleanValue() ? 1 : 0));
      int var129 = var18;
      byte var128 = (byte)var10000;
      var98 = var128;
      byte var93 = var128;
      label164:
      if (var129 == 0) {
         byte var130 = var93;
         if (var130 != 0) {
            Object[] var25 = new Object[]{var16};
            PlayerEntity var19 = EntityUtil.aReturningPlayerEntity(var25);
            PlayerEntity var131 = var19;
            if (var131 != null) {
               MinecraftClient var26 = b;
               PlayerEntity var28 = var19;
               ClientPlayerEntity var27 = var26.player;
               float var213;
               var10000 = (var213 = var27.distanceTo((Entity)var28) - 10.0F) == 0.0F ? 0 : (var213 < 0.0F ? -1 : 1);
               int var133 = var18;
               int var132 = var10000;
               var98 = var132;
               int var94 = var132;
               if (var133 != 0) {
                  break label164;
               }

               int var134 = var94;
               int var95 = var134;
               int var135 = var95;
               if (var135 < 0) {
                  PlayerEntity var31 = var19;
                  int var137 = var18;
                  int var136 = var31.hurtTime;
                  var98 = var136;
                  int var96 = var136;
                  if (var137 != 0) {
                     break label164;
                  }

                  int var138 = var96;
                  int var97 = var138;
                  int var139 = var97;
                  if (var139 != 0) {
                     return;
                  }
               }
            }
         }

         var98 = this.s;
      }

      int var141 = var18;
      int var140 = var98;
      int var100 = var140;
      int var99 = var140;
      if (var141 == 0) {
         // int var142 = var99;
         if (var142 == var143) {
            MinecraftClient var37 = b;
            HitResult var20 = var37.crosshairTarget;
            int var146 = var18;
            HitResult var145 = var20;
            HitResult var102 = var145;
            HitResult var101 = var145;
            if (var146 == 0) {
               boolean var147 = var101 instanceof BlockHitResult;
               if (!var147) {
                  return;
               }

               HitResult var148 = var20;
               var102 = var148;
            }

            BlockHitResult var198 = (BlockHitResult)var102;
            int var149 = var18;
            if (var149 == 0) {
               MinecraftClient var41 = b;
               ClientPlayerEntity var42 = var41.player;
               int var201 = (((var42.isSneaking()) ? 1 : 0));
               int var151 = var18;
               byte var150 = (byte)var201;
               byte var104 = var150;
               byte var103 = var150;
               if (var151 == 0) {
                  byte var152 = var103;
                  if (var152 != 0) {
                     return;
                  }

                  BlockHitResult var44 = var198;
                  Object[] var45 = new Object[]{var44.getBlockPos(), Blocks.RESPAWN_ANCHOR, var6};
                  byte var153 = ((byte)((BlockUtil.kReturningBoolean(var45)) ? 1 : 0));
                  var104 = var153;
               }

               int var155 = var18;
               byte var154 = var104;
               byte var106 = var154;
               byte var105 = var154;
               if (var155 == 0) {
                  byte var156 = var105;
                  if (var156 == 0) {
                     return;
                  }

                  BooleanSetting var48 = this.d;
                  Boolean var49 = (Boolean)var48.aReturningObject();
                  byte var157 = ((byte)(((java.lang.Boolean)(var49)).booleanValue() ? 1 : 0));
                  var106 = var157;
               }

               Object var113;
               label168: {
                  int var112;
                  int var159 = var18;
                  byte var158 = var106;
                  var112 = var158;
                  byte var107 = var158;
                  label137:
                  if (var159 == 0) {
                     byte var160 = var107;
                     if (var160 != 0) {
                        ArrayList var202 = this.q;
                        BlockHitResult var52 = var198;
                        BlockPos var54 = var52.getBlockPos();
                        ArrayList var53 = var202;
                        var201 = (((var53.contains(var54)) ? 1 : 0));
                        int var162 = var18;
                        byte var161 = ((byte)(var201));
                        var112 = var161;
                        byte var108 = var161;
                        if (var162 != 0) {
                           break label137;
                        }

                        byte var163 = var108;
                        byte var109 = var163;
                        byte var164 = var109;
                        if (var164 == 0) {
                           return;
                        }
                     }

                     BlockHitResult var57 = var198;
                     BlockPos var204 = var57.getBlockPos();
                     int var166 = var18;
                     BlockPos var165 = var204;
                     var113 = var165;
                     BlockPos var110 = var165;
                     if (var166 != 0) {
                        break label168;
                     }

                     BlockPos var167 = var110;
                     BlockPos var111 = var167;
                     Object[] var59 = new Object[]{var111, var14};
                     int var168 = BlockUtil.aReturningInt(var59);
                     var112 = var168;
                  }

                  int var169 = var112;
                  if (var169 == 0) {
                     return;
                  }

                  ModeSetting var61 = this.h;
                  var113 = var61.aReturningObject();
               }

               int var119;
               String var199 = (String)var113;
               // String var62 = var199;
               var201 = var62.hashCode();
               int var171 = var18;
               int var170 = var201;
               var119 = var170;
               int var114 = var170;
               label117:
               if (var171 == 0) {
                  int var172 = var114;
                  switch (var172) {
                     case 2433880:
                        short var10001 = 27884;
                        long var10002 = 4273490570480659535L ^ var197;
                        String var65 = "None";
                        String var64 = var199;
                        byte var206 = ((byte)((var64.equals(var65)) ? 1 : 0));
                        int var174 = var18;
                        byte var173 = var206;
                        var119 = var173;
                        byte var115 = var173;
                        if (var174 != 0) {
                           break label117;
                        }

                        byte var175 = var115;
                        byte var116 = var175;
                        byte var176 = var116;
                        if (var176 == 0) {
                           break;
                        }

                        var21 = 0;
                        int var177 = var18;
                        if (var177 == 0) {
                           break;
                        }
                     case 2590131:
                        short var210 = 5855;
                        long var211 = 12532218468521592L ^ var197;
                        String var69 = "Swap";
                        String var68 = var199;
                        byte var207 = ((byte)((var68.equals(var69)) ? 1 : 0));
                        int var179 = var18;
                        byte var178 = var207;
                        var119 = var178;
                        byte var117 = var178;
                        if (var179 != 0) {
                           break label117;
                        }

                        byte var180 = var117;
                        byte var118 = var180;
                        byte var181 = var118;
                        if (var181 != 0) {
                           var21 = 1;
                        }
                  }

                  var119 = var21;
               }

               AnchorExploder var127;
               label171: {
                  int var126;
                  int var183 = var18;
                  int var182 = var119;
                  var126 = var182;
                  int var120 = var182;
                  label101:
                  if (var183 == 0) {
                     int var184 = var120;
                     switch (var184) {
                        case 0:
                           IntSetting var73 = this.i;
                           Integer var74 = (Integer)var73.aReturningObject();
                           var201 = var74 - 1;
                           int var186 = var18;
                           int var185 = var201;
                           var126 = var185;
                           int var121 = var185;
                           if (var186 != 0) {
                              break label101;
                           }

                           int var187 = var121;
                           int var122 = var187;
                           Object[] var76 = new Object[]{var10};
                           int var189 = InventoryUtil.aReturningInt(var76);
                           int var188 = var122;
                           if (var188 != var189) {
                              return;
                           }
                           break;
                        case 1:
                           BooleanSetting var79 = this.j;
                           Boolean var80 = (Boolean)var79.aReturningObject();
                           byte var208 = ((byte)(((java.lang.Boolean)(var80)).booleanValue() ? 1 : 0));
                           int var191 = var18;
                           byte var190 = var208;
                           int var124 = var190;
                           byte var123 = var190;
                           if (var191 == 0) {
                              byte var192 = var123;
                              if (var192 != 0) {
                                 Object[] var82 = new Object[]{var10};
                                 this.s = InventoryUtil.aReturningInt(var82);
                              }

                              IntSetting var84 = this.i;
                              Integer var85 = (Integer)var84.aReturningObject();
                              var124 = var85 - 1;
                           }

                           Object[] var212 = new Object[]{null, var12};
                           var212[0] = var124;
                           Object[] var86 = var212;
                           InventoryUtil.aReturningVoid(var86);
                     }

                     Object[] var87 = new Object[]{var198, var8};
                     ItemUseUtil.aReturningBoolean(var87);
                     int var194 = var18;
                     AnchorExploder var193 = this;
                     var127 = var193;
                     AnchorExploder var125 = var193;
                     if (var194 != 0) {
                        break label171;
                     }

                     BooleanSetting var88 = var125.l;
                     Boolean var89 = (Boolean)var88.aReturningObject();
                     byte var195 = ((byte)(((java.lang.Boolean)(var89)).booleanValue() ? 1 : 0));
                     var126 = var195;
                  }

                  int var196 = var126;
                  if (var196 == 0) {
                     return;
                  }

                  var127 = this;
               }

               Object[] var92 = new Object[]{var4};
               AnchorExploder var91 = var127;
               var91.aReturningVoid(var92);
               return;
            }

            return;
         }

         int var144 = this.s;
         var100 = var144;
      }

      Object[] var10003 = new Object[]{null, var12};
      var10003[0] = var100;
      Object[] var36 = var10003;
      InventoryUtil.aReturningVoid(var36);
      this.s = -1;
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 99459323511616L ^ 9859747324721L;
      var10001 = 99459323511616L ^ 19098328307333L;
      int var10000 = Event.cReturningInt();
      Object[] var14 = new Object[0];
      PacketSendEvent var13 = var1;
      Packet var10 = var13.aReturningVoid(var14);
      int var8 = var10000;
      int var96 = var8;
      Packet var95 = var10;
      Packet var64 = var95;
      Packet var63 = var95;
      if (var96 != 0) {
         boolean var97 = var63 instanceof PlayerInteractBlockC2SPacket;
         if (!var97) {
            return;
         }

         Packet var98 = var10;
         var64 = var98;
      }

      PlayerInteractBlockC2SPacket var9 = (PlayerInteractBlockC2SPacket)var64;
      int var99 = var8;
      if (var99 != 0) {
         PlayerInteractBlockC2SPacket var18 = var9;
         Hand var141 = var18.getHand();
         Hand var20 = Hand.MAIN_HAND;
         Hand var19 = var141;
         boolean var100 = var19.equals(var20);
         ItemStack var65;
         if (var100) {
            MinecraftClient var21 = b;
            ClientPlayerEntity var22 = var21.player;
            ItemStack var101 = var22.getMainHandStack();
            var65 = var101;
         } else {
            MinecraftClient var24 = b;
            ClientPlayerEntity var25 = var24.player;
            var65 = var25.getOffHandStack();
         }

         ItemStack var140 = var65;
         ItemStack var26 = var140;
         Item var142 = var26.getItem();
         Item var103 = Items.RESPAWN_ANCHOR;
         Item var102 = var142;
         if (var102 == var103) {
            BlockHitResult var11;
            BlockPos var12;
            ArrayList var72;
            BlockPos var73;
            label79: {
               PlayerInteractBlockC2SPacket var28 = var9;
               var11 = var28.getBlockHitResult();
               BlockHitResult var29 = var11;
               BlockPos var143 = var29.getBlockPos();
               BlockHitResult var30 = var11;
               Direction var31 = var30.getSide();
               int var147 = var31.getOffsetX();
               BlockHitResult var32 = var11;
               Direction var33 = var32.getSide();
               int var10002 = var33.getOffsetY();
               BlockHitResult var34 = var11;
               Direction var35 = var34.getSide();
               int var39 = var35.getOffsetZ();
               int var38 = var10002;
               int var37 = var147;
               BlockPos var36 = var143;
               var12 = var36.add(var37, var38, var39);
               BooleanSetting var40 = this.d;
               Boolean var41 = (Boolean)var40.aReturningObject();
               boolean var144 = var41;
               int var105 = var8;
               boolean var104 = var144;
               boolean var71 = var104;
               boolean var66 = var104;
               if (var105 != 0) {
                  boolean var106 = var66;
                  if (!var106) {
                     return;
                  }

                  int var109 = var8;
                  BlockPos var108 = var12;
                  ArrayList var107 = this.q;
                  var72 = var107;
                  var73 = var108;
                  ArrayList var67 = var107;
                  BlockPos var68 = var108;
                  if (var109 == 0) {
                     break label79;
                  }

                  BlockPos var111 = var68;
                  ArrayList var110 = var67;
                  ArrayList var69 = var110;
                  BlockPos var70 = var111;
                  BlockPos var45 = var70;
                  ArrayList var44 = var69;
                  boolean var112 = var44.contains(var45);
                  var71 = var112;
               }

               boolean var113 = var71;
               if (var113) {
                  return;
               }

               ArrayList var145 = this.q;
               BlockHitResult var47 = var11;
               var73 = var47.getBlockPos();
               var72 = var145;
            }

            ArrayList var93;
            BlockPos var94;
            label54: {
               ArrayList var89;
               label53: {
                  int var116 = var8;
                  BlockPos var115 = var73;
                  ArrayList var114 = var72;
                  ArrayList var90 = var114;
                  BlockPos var91 = var115;
                  ArrayList var74 = var114;
                  BlockPos var75 = var115;
                  if (var116 != 0) {
                     Object[] var48 = new Object[]{var75, Blocks.RESPAWN_ANCHOR, 90720632922225L};
                     boolean var118 = BlockUtil.bReturningBoolean(var48);
                     ArrayList var117 = var74;
                     var89 = var117;
                     ArrayList var76 = var117;
                     if (var118) {
                        break label53;
                     }

                     ArrayList var119 = var76;
                     ArrayList var77 = var119;
                     BlockHitResult var50 = var11;
                     BlockPos var148 = var50.getBlockPos();
                     int var122 = var8;
                     BlockPos var121 = var148;
                     ArrayList var120 = var77;
                     var90 = var120;
                     var91 = var121;
                     ArrayList var78 = var120;
                     BlockPos var79 = var121;
                     if (var122 != 0) {
                        BlockPos var124 = var79;
                        ArrayList var123 = var78;
                        ArrayList var80 = var123;
                        BlockPos var81 = var124;
                        Object[] var52 = new Object[]{var81, Blocks.FIRE, 90720632922225L};
                        boolean var126 = BlockUtil.bReturningBoolean(var52);
                        ArrayList var125 = var80;
                        var89 = var125;
                        ArrayList var82 = var125;
                        if (var126) {
                           break label53;
                        }

                        ArrayList var127 = var82;
                        ArrayList var83 = var127;
                        BlockHitResult var54 = var11;
                        BlockPos var149 = var54.getBlockPos();
                        int var130 = var8;
                        BlockPos var129 = var149;
                        ArrayList var128 = var83;
                        var90 = var128;
                        var91 = var129;
                        ArrayList var84 = var128;
                        BlockPos var85 = var129;
                        if (var130 != 0) {
                           BlockPos var132 = var85;
                           ArrayList var131 = var84;
                           ArrayList var86 = var131;
                           BlockPos var87 = var132;
                           Object[] var56 = new Object[]{82650215142853L};
                           Object[] var57 = new Object[]{var87, BlockUtil.aReturningBlock(var56), 90720632922225L};
                           boolean var134 = BlockUtil.bReturningBoolean(var57);
                           ArrayList var133 = var86;
                           ArrayList var92 = var133;
                           ArrayList var88 = var133;
                           if (!var134) {
                              var94 = var12;
                              var93 = var92;
                              break label54;
                           }

                           ArrayList var135 = var88;
                           var89 = var135;
                           break label53;
                        }
                     }
                  }

                  BlockPos var139 = var91;
                  ArrayList var138 = var90;
                  var93 = var138;
                  var94 = var139;
                  break label54;
               }

               BlockHitResult var59 = var11;
               BlockPos var137 = var59.getBlockPos();
               ArrayList var136 = var89;
               var93 = var136;
               var94 = var137;
            }

            BlockPos var62 = var94;
            ArrayList var61 = var93;
            var61.add(var62);
         }
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.bReturningInt();
      Object[] var8 = new Object[0];
      PacketReceiveEvent var7 = var1;
      Packet var6 = var7.aReturningVoid(var8);
      int var4 = var10000;
      int var26 = var4;
      Packet var25 = var6;
      Packet var22 = var25;
      Packet var21 = var25;
      if (var26 == 0) {
         boolean var27 = var21 instanceof BlockUpdateS2CPacket;
         if (!var27) {
            return;
         }

         Packet var28 = var6;
         var22 = var28;
      }

      BlockUpdateS2CPacket var5 = (BlockUpdateS2CPacket)var22;
      int var29 = var4;
      if (var29 == 0) {
         BlockUpdateS2CPacket var12 = var5;
         BlockState var36 = var12.getState();
         int var31 = var4;
         BlockState var30 = var36;
         BlockState var24 = var30;
         BlockState var23 = var30;
         if (var31 == 0) {
            BlockState var32 = var23;
            if (var32 == null) {
               return;
            }

            BlockUpdateS2CPacket var14 = var5;
            BlockState var33 = var14.getState();
            var24 = var33;
         }

         BlockState var16 = var24;
         Block var37 = var16.getBlock();
         Block var35 = Blocks.RESPAWN_ANCHOR;
         Block var34 = var37;
         if (var34 != var35) {
            ArrayList var38 = this.q;
            BlockUpdateS2CPacket var18 = var5;
            BlockPos var20 = var18.getPos();
            ArrayList var19 = var38;
            var19.remove(var20);
         }
      }
   }

   private static boolean lambda$calculate$8(BlockPos var0) {
      long var10001 = 138802824545835L ^ 49198952375898L;
      Object[] var5 = new Object[]{var0, Blocks.RESPAWN_ANCHOR, 90720632922225L};
      return BlockUtil.bReturningBoolean(var5);
   }

   private static boolean lambda$onTick$7(BlockPos var0) {
      MinecraftClient var3 = b;
      BlockPos var5 = var0;
      ClientWorld var4 = var3.world;
      BlockState var6 = var4.getBlockState(var5);
      Block var10000 = var6.getBlock();
      Block var9 = Blocks.RESPAWN_ANCHOR;
      Block var8 = var10000;
      byte var7;
      if (var8 != var9) {
         byte var10 = 1;
         var7 = var10;
      } else {
         var7 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private boolean lambda$new$6(Float var1) {
      long var10001 = 12225347653390L ^ 83443050304864L;
      int var6 = Event.cReturningInt();
      MultiModeSetting var10000 = this.m;
      Object[] var8 = new Object[]{"Glowstone", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 != 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.m;
            Object[] var11 = new Object[]{"Explode", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$5(Boolean var1) {
      BooleanSetting var4 = this.g;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$4(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.g;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.h;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$3(Integer var1) {
      BooleanSetting var4 = this.g;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(String var1) {
      BooleanSetting var4 = this.g;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$1(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.c;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.e;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$0(String var1) {
      BooleanSetting var4 = this.c;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(21024841922429L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[8];
      String var11 = "#-Þ#\u0019Lã¤¤\u0097*\u0017D\u000eNÖ\u0010PÞ©1P'°8\u0094\u001fkï¤\u0099.G\u0010R\u001e\u008d.\u00108\u0088L\u0097Æ\u000eÐ\u0094hDµ\u0010ô\u0099ùÝ?\u0016£?ôíë3XYè\u0003\u0018]\u000f×½\u00802h½2\u001c+\u0098u_\u009cò\u0096ÑóTÛd;ô R\u001b\u008b\rb\u00adt5\u009dj6Ê.\u009bcúhb*Uy\u0087yé\u001e\u0090½Ì£\u0006#ü";
      int var13 = "#-Þ#\u0019Lã¤¤\u0097*\u0017D\u000eNÖ\u0010PÞ©1P'°8\u0094\u001fkï¤\u0099.G\u0010R\u001e\u008d.\u00108\u0088L\u0097Æ\u000eÐ\u0094hDµ\u0010ô\u0099ùÝ?\u0016£?ôíë3XYè\u0003\u0018]\u000f×½\u00802h½2\u001c+\u0098u_\u009cò\u0096ÑóTÛd;ô R\u001b\u008b\rb\u00adt5\u009dj6Ê.\u009bcúhb*Uy\u0087yé\u001e\u0090½Ì£\u0006#ü"
         .length();
      char var10 = 16;
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         // while (true) {
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     u = var14;
                     v = new String[8];
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(21024841922429L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = 1453172513976068730L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)20L,
                           (byte)5162L,
                           (byte)1321652L,
                           (byte)338343091L,
                           (byte)86615831492L,
                           (byte)22173652862183L,
                           (byte)5676455132719018L,
                           (byte)1453172513976068730L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     x = var31;
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "\u00105«\u001e\u009eÿt5¸ñ}¥¼¦M©\u0010m²¯M\u001a\u0097$\u0087ÓI\u007fD\u008c\u009e2p";
                  var13 = "\u00105«\u001e\u009eÿt5¸ñ}¥¼¦M©\u0010m²¯M\u001a\u0097$\u0087ÓI\u007fD\u008c\u009e2p".length();
                  var10 = 16;
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22611;
      if (v[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])w.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               w.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dT", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = u[var5].getBytes("ISO-8859-1");
         v[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return v[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dT_C0201",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 52;
            yield var15;
         }
         case 1 -> {
            byte var16 = 32;
            yield var16;
         }
         case 2 -> {
            byte var17 = 53;
            yield var17;
         }
         case 3 -> {
            byte var18 = 21;
            yield var18;
         }
         case 4 -> {
            byte var19 = 48;
            yield var19;
         }
         case 5 -> {
            byte var20 = 46;
            yield var20;
         }
         case 6 -> {
            byte var21 = 10;
            yield var21;
         }
         case 7 -> {
            byte var22 = 28;
            yield var22;
         }
         case 8 -> {
            byte var23 = 3;
            yield var23;
         }
         case 9 -> {
            byte var24 = 36;
            yield var24;
         }
         case 10 -> {
            byte var25 = 12;
            yield var25;
         }
         case 11 -> {
            byte var26 = 1;
            yield var26;
         }
         case 12 -> {
            byte var27 = 38;
            yield var27;
         }
         case 13 -> {
            byte var28 = 20;
            yield var28;
         }
         case 14 -> {
            byte var29 = 9;
            yield var29;
         }
         case 15 -> {
            byte var30 = 15;
            yield var30;
         }
         case 16 -> {
            byte var31 = 18;
            yield var31;
         }
         case 17 -> {
            byte var32 = 39;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 16;
            yield var34;
         }
         case 20 -> {
            byte var35 = 42;
            yield var35;
         }
         case 21 -> {
            byte var36 = 41;
            yield var36;
         }
         case 22 -> {
            byte var37 = 5;
            yield var37;
         }
         case 23 -> {
            byte var38 = 54;
            yield var38;
         }
         case 24 -> {
            byte var39 = 37;
            yield var39;
         }
         case 25 -> {
            byte var40 = 44;
            yield var40;
         }
         case 26 -> {
            byte var41 = 59;
            yield var41;
         }
         case 27 -> {
            byte var42 = 19;
            yield var42;
         }
         case 28 -> {
            byte var43 = 61;
            yield var43;
         }
         case 29 -> {
            byte var44 = 33;
            yield var44;
         }
         case 30 -> {
            byte var45 = 40;
            yield var45;
         }
         case 31 -> {
            byte var46 = 17;
            yield var46;
         }
         case 32 -> {
            byte var47 = 27;
            yield var47;
         }
         case 33 -> {
            byte var48 = 43;
            yield var48;
         }
         case 34 -> {
            byte var49 = 25;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 35;
            yield var51;
         }
         case 37 -> {
            byte var52 = 50;
            yield var52;
         }
         case 38 -> {
            byte var53 = 11;
            yield var53;
         }
         case 39 -> {
            byte var54 = 6;
            yield var54;
         }
         case 40 -> {
            byte var55 = 8;
            yield var55;
         }
         case 41 -> {
            byte var56 = 57;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 7;
            yield var58;
         }
         case 44 -> {
            byte var59 = 55;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 4;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 34;
            yield var63;
         }
         case 49 -> {
            byte var64 = 0;
            yield var64;
         }
         case 50 -> {
            byte var65 = 30;
            yield var65;
         }
         case 51 -> {
            byte var66 = 31;
            yield var66;
         }
         case 52 -> {
            byte var67 = 58;
            yield var67;
         }
         case 53 -> {
            byte var68 = 56;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 24;
            yield var70;
         }
         case 56 -> {
            byte var71 = 60;
            yield var71;
         }
         case 57 -> {
            byte var72 = 23;
            yield var72;
         }
         case 58 -> {
            byte var73 = 14;
            yield var73;
         }
         case 59 -> {
            byte var74 = 49;
            yield var74;
         }
         case 60 -> {
            byte var75 = 29;
            yield var75;
         }
         case 61 -> {
            byte var76 = 26;
            yield var76;
         }
         case 62 -> {
            byte var77 = 22;
            yield var77;
         }
         default -> 2;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      y[0] = "\u000bC\u0003r\n\\\u001dC\u0006(\u0019K\n\b\u0005.\u0015_\u001bO\u00129^H;";
      y[1] = "\"5\u001ctNA):\r;-L<7\u0002P\u0018N-$\u001e|\u000fC";
      y[2] = "Qog(i\nZ`vg\u0014\u0012Ig\u007f.";
      y[3] = "vN=zya}A,5\u0018ovJ(o";
      y[4] = boolean.class;
      z[4] = "java/lang/Boolean";
      y[5] = "\u007f:g/N2i:bu]%~qasQ1o6vd\u001a#^";
      y[6] = int.class;
      z[6] = "java/lang/Integer";
      y[7] = "y\u0018#\u000f^Ey\u00184SRJcS4MR_d\"e\u0013\u0007\u001a";
      y[8] = "s\u0012!%.`s\u00126y\"oiY6g\"zn(g9w1";
      y[9] = "n`p&6Qx`u|%Fo+vz)R~lambG_";
      y[10] = "v}H\u0011=k\u0003]C\u001e,$bSH\u0015(~\u0016";
      y[11] = "C\u000b\u0011\u001a(dC\u000b\u0006F$kY@\u0006X$~^1T\u0002p:";
      y[12] = "2V\u0018FgI$V\u001d\u001ct^3\u001d\u001e\u001axJ\"Z\t\r3Z9";
      y[13] = "|%uwp\u0002\t\u0005~xaMh\u000buse\u0017\u001c";
      y[14] = void.class;
      z[14] = "java/lang/Void";
      y[15] = "PV*\u0004qIPV=X}FJ\u001d=F}SMli\u001e*";
      y[16] = "v\u001cZP\u0017\u0000h\u0014@\u001fx\u0007n\u001cU}P\u0006h";
      y[17] = "v]h\u0002Q'}RyM=$sP{\u0002\u0011";
      y[18] = "Ut]\"\t\tCtXx\u001a\u001eT?[~\u0016\nExLi]\u001d`";
      y[19] = "u\r1G{t\u0000-:Hj;a#1Cna\u0015";
      y[20] = ".yO}\u001b4.yX!\u0017;42X?\u0017.3C\bbF";
      y[21] = "_GaJj<_Gv\u0016f3E\fv\bf&B}'W>";
      y[22] = "mvz\u0013@~{v\u007fISil=|O_}}zkX\u0014jO";
      y[23] = "ts}t)ftsj(%in8j6%|iI8h}8";
      y[24] = float.class;
      z[24] = "java/lang/Float";
      y[25] = "49ifV'?6x)1%*=xb\n";
      y[26] = "?\u0016_xQ\u0006)\u0016Z\"B\u0011>]Y$N\u0005/\u001aN3\u0005\u00177";
      y[27] = "Js{\u0004AH?Sp\u000bP\u0007^]{\u0000T]*";
      y[28] = "dw`\u000f70\u0011Wk\u0000&\u007fpY`\u000b\"%\u0004";
      y[29] = "O`\u00066E6O`\u0011jI9U+\u0011tI,RZA!\u001ej";
      y[30] = ":FJm\u007f\u000f:F]1s\u0000 \r]/s\u0015'|\fp!^";
      y[31] = "EDL\u001e`+SDIDs<D\u000fJB\u007f(UH]U48M";
      y[32] = "]\u0000N\u0000RJ( E\u000fC\u0005I.N\u0004G_=";
      y[33] = "\u0010V5Qe\u0006ev>^tI\u0004x5Up\u0013p";
      y[34] = "rX\u001ci,&rX\u000b5 )h\u0013\u000b+ <obZqy\u007f";
      y[35] = "dqiF\u007f+dq~\u001as$~:~\u0004s1yK+[*";
      y[36] = "\u0000\u00141@FT\u0000\u0014&\u001cJ[\u001a_&\u0002JN\u001d.tY\u0012\u0004";
      y[37] = "HD\rOcVHD\u001a\u0013oYR\u000f\u001a\roLU~HV7\r";
      y[38] = "o.\u0012\u0016\u0001O\u001a\u000e\u0019\u0019\u0010\u0000{\u0000\u0012\u0012\u0014Z\u000f";
      y[39] = "1\u0014(<!YD4#30\u0016%:(84LQ";
      y[40] = "2\t<\u0018*02\t+D&?(B+Z&*/3z\u0000uo";
      y[41] = "\u001b\\?k<n\r\\:1/y\u001a\u001797#m\u000bP. h|\u001b";
      y[42] = "I[3\u0019$\u0014<{8\u00165[]u3\u001d1\u0001)";
      y[43] = "Yc>31DYc)o=KC()q=^DYx(e\u001b";
      y[44] = "#Pnl;a5Pk6(v\"\u001bh0$b3\\\u007f'ou\t";
      y[45] = "uoT]H4\u0000O_RY{aATY]!\u0015";
      y[46] = "s\\0xB\u001dmT*7?\rm";
      y[47] = "\u001d\u0004<l-\u0007\u000b\u000496>\u0010\u001cO:02\u0004\r\b-'y\u0013\u0000";
      y[48] = "<IfK\u0005wIimD\u00148(gfO\u0010b\\";
      y[49] = "3<$r=F%<!(.Q2w\".\"E#059iU;0723\u0018\u0007+7/3_0<";
      y[50] = "\u000b(2\u0005B'~\b9\nSh\u001f\u00062\u0001W2k";
      y[51] = "(F=aF\u0014>F8;U\u0003)\r;=Y\u00178J,*\u0012\u0000\u0000";
      y[52] = "RY\u007f+7Q'yt$&\u001eFw\u007f/\"D2";
      y[53] = "\u0012\u001bm1\\n\u0012\u001bzmPa\bPzsPt\u000f!-,\u0006";
      y[54] = "vaC5t=`aFog*w*Eik>fmR~ +K";
      y[55] = "Fk\u000ft\u007f?3K\u0004{npRE\u000fpj*&";
      y[56] = ":Vg\u000e\u00102Ovl\u0001\u0001}.xg\n\u0005'Z";
      y[57] = "SU>?(fM]$p`fWW<7i}\u0017d:;bzZU<;";
      y[58] = "cSvE\u00125\u0016s}J\u0003zw}vA\u0007 \u0003";
      y[59] = "K#^}\u0016J>\u0003Ur\u0007\u0005_\r^y\u0003_+";
      y[60] = "\tFP\u0006x\u0010|f[\ti_\u001dhP\u0002m\u0005i";
      y[61] = "VG\u007fJ\u001d5VGh\u0016\u0011:L\fh\b\u0011/K}:\\@n";
      y[62] = "iY\u001e`F$\u001cy\u0015oWk}w\u001edS1\t";
      y[63] = "'o8g|\u0012RO3hm]3A8ci\u0007G";
      y[64] = "m>mMc{\u0018\u001efBr4y\u0010mIvn\r";
      y[65] = "N@;\u00075RPH!HWNWU";
      y[66] = "\u0016+\u000f32\u0002\b#\u0015|U\u0003\u00198\u0018&s\u0005";
      y[67] = "\u0000<Z\u0011g\u0007\u0016<_Kt\u0010\u0001w\\Mx\u0004\u00100KZ3\u0013\u001c";
      y[68] = "Re\u000e(\u0003K'E\u0005'\u0012\u0004FK\u000e,\u0016^2";
      y[69] = "'SkGJE'S|\u001bFJ=\u0018|\u0005F_:i-]\u0014";
      y[70] = double.class;
      z[70] = "java/lang/Double";
      y[71] = ";\nehsk-\n`2`|:Ac4lh+\u0006t#'\u007f\u001d";
      y[72] = "1Q.Uk1Dq%Zz~%\u007f.Q~$Q";
      y[73] = "/\n\u0003&U\\9\n\u0006|FK.A\u0005zJ_?\u0006\u0012m\u0001Oy";
      y[74] = "P\u0019-TlB%9&[}\rD7-PyW0";
      y[75] = ">nI\u0007L\u0001KNB\b]N*@I\u0003Y\u0014^";
      y[76] = "0\u0015A\u0019Y\u0012E5J\u0016H]$;A\u001dL\u0007P";
      y[77] = "\f.,c8L\u001a.)9+[\re*?'O\u001c\"=(l_[";
      y[78] = "CkU)\u0002I6K^&\u0013\u0006WEU-\u0017\\#";
      y[79] = "#\u0015\u001cM\u0017\u007fV5\u0017B\u000607;\u001cI\u0002jC";
      y[80] = "3_B\u001e`\u00108PSQ\b\u00106_@";
      y[81] = "\rcKwXDxC@xI\u000b\u0019MKsMQm";
      y[82] = "=OE\u001dh\u0013HoN\u0012y\\)aE\u0019}\u0006]";
      y[83] = "\u00147NVVy\u00147Y\nZv\u000e|Y\u0014Zc\t\r\b@\u0003%";
      y[84] = "\u001eE_`)m\u001eEH<%b\u0004\u000eH\"%w\u0003\u007f\u0019}q4";
      y[85] = "V\u0018\by\u0010\u007f@\u0018\r#\u0003hWS\u000e%\u000f|F\u0014\u00192DmW";
      y[86] = "}HWc\u000b\t\bh\\l\u001aFifWg\u001e\u001c\u001d";
      y[87] = "d\u0004l_[\u0003d\u0004{\u0003W\f~O{\u001dW\u0019y>)C\u0000R";
      y[88] = "66WsxPC\u0016\\|i\u001f\"\u0018WwmEV";
      y[89] = "zUdXh*lUa\u0002{={\u001eb\u0004w)jYu\u0013<>V";
      y[90] = "V\u0019\n\rFB#9\u0001\u0002W\rB7\n\tSW6";
      y[91] = "ra&e\u001c/da#?\u000f8s* 9\u0003,bm7.H;\\";
      y[92] = "\b\u0014\u0013R\u001cl}4\u0018]\r#\u001c:\u0013V\tyh";
      y[93] = "\t\u0011LO\u0015d\u001f\u0011I\u0015\u0006s\bZJ\u0013\ng\u0019\u001d]\u0004Ap&";
      y[94] = "\u0003|A\u0011\r\nv\\J\u001e\u001cE\u0017RA\u0015\u0018\u001fc";
      y[95] = "^F2r/\u0002HF7(<\u0015_\r4.0\u0001NJ#9{\u0016w";
      y[96] = "\u0015]^\u000bdM`}U\u0004u\u0002\u0001s^\u000fqXu";
      y[97] = "BV\u0000Ds8\b\u0012_.sWK\u0016\u0019\u0016t/\u001d\u001a\u0006\u0015xW\u001bQ\u0000K*g\u0012\u0017\u0007\u0017\u0011";
      y[98] = "d R<LZ,e\u000e+Uc7\u0018S.H[8`\u0005\"WX4\u0018\u0003iQ\u0006f(\n/VZ]";
      y[99] = "'P\u0010{-\u0012'\bAuJHt\u0013\u0010[-DphLjsA \u000b\u000bm{D\u001d";
      y[100] = ":t12|!\u007f5}\"xBj\fz?ozft,3pyj\fz:a2lo?{-\"h\f";
      y[101] = ";M\u0019$\f%2F\u0019zw20AA{\u001b\u0000g\u0003\u001b$KW`Y\\d\t)/@Zdw";
      y[102] = "\u0017\u0017TG+\u0005@C\u0004_\u0012S\u001bJ\rTE\u0004E\u001aT8+\u0004FEX\u0005yR\u001d\u0017\u000b";
      y[103] = "L_v\u0011\"7]Ww\u000fM+Z\u001b}\u000e!\u0019\u000e^&Q}NQ\u0017%Q6<X\u001c%\u000fM";
      y[104] = "^_~*ID\u000f\u0004lv.DZG`tBv\f\u0005<.\u0012!XEpuV\u0018UJpx.";
      y[105] = "ym.`qD(6<<\u0016D}u0>zv-6id\u0016\u001a~654|Zkp.Y";
      y[106] = "\f7n>\u001cM\u0001q`f!\u001ass-y\u0019\u0013\u000b%!f\u001a\u001fs#j`DMC*,g\u0018v";
      y[107] = "8CrXD2?\u001e&[DQ`\u000erZF-f\b\u001f\u0019Fh1Iz\u001fIic\u0012\u001f";
      y[108] = "+5\r\u007f\u0011D;3\u0018&s:\tO'Ps\u001f~z\u001e\u007fC\u000fxoG";
      y[109] = "~D(\u0000o\")\u0010x\u0018V\u007f~\bu\u0018:M*I+NV!}Kp\u0012<ah\rk\u007f";
      y[110] = "i%HbIN-!Q9B59_\u0016/Z\r5'@#E\u000e9_\u0016(A\u0005?$R,X^4_";
      y[111] = "\u0001{,+mS\u0011gcn\u000bI\u0007bO;oU\f\u001e-(2A\\}j/:Da";
      y[112] = ";P\u00147yM9S\tp\u0007\\ZT\u00055?Z\"\u0002\t*<VZV\u0016vbR0\u0016\u00030y?";
      y[113] = "\u001c\u0017[R=\r\u001a\u0018Z\u0000fhC\u0013\u0012\u001e\u0006RH\u0012\u001e\u0001;\u0013\u001d\u0006\u0012b";
      y[114] = "$eV\u0010S6m&\u0001IX\u000ft\u0018V\u0004_7x`\u0000\b@4t\u0018V\u0004\u001afm!\u001fGM?f\u0018";
      y[115] = "\u0003\tCf\u0001VB\\Wjb\u0006@\u0019F~\u0019k\u0003\tCf\u0001VB\\WjbPW[Jw\b\u0010B\u001dQ\u001a";
      y[116] = "Gz6\u000f>~\u000671\t@p|3 \rx|\u0004e,\u0012{p|cg\u0014%\"Lj!\u0013y\u0019";
      y[117] = "-pMX\u001f7,kSOq?F,NTI0>zBKJ<F)I\u0011\u0018h%nN\u0019\u001dU";
      y[118] = "\u000fJ=\u0011\u0005FE\u000eb{\u000e)\u0006\u001e9C\tJ\\\u000bgAg\u0010V\u0016`\u0015\u0004JCHb{";
      y[119] = "M*OR%(I/J\u0007T4Jp\u0017C9N\u001dx\u001cA7s\\-\bMTuI*\u0015P>5\\l\u000e=";
      y[120] = "\u001a\u0000M&gT\u001aX\u001c(\u0000\u0003YED){n\u001aUA1cS[\u0000U=\u0000UN\u0007H j\u0015[ASM";
      y[121] = "$77SiQe*oX;;x?,_dWJkh\u0006=\u0006\u001dn*\u0006j\u0006~)-\u000eo;";
      y[122] = "d]\\\u001aM*f\t\u001bP\u0012K70\u001bW\ns8HM[\u0015p40\u001b@\tr?IIP\u001b270";
      y[123] = "MC\u0007\u0006:c\u0005O\u001e\f+\u001f\u001d/\\\u00009'\u0011W\n\f&$\u001d/\b\u0007{&\u0011N[\u001d\"qt";
      y[124] = "\u0002.i:M5\u0000-t}3.c*x8\u000b\"\u001b|t'\b.c*4)K,\u0000-i}H,c";
      y[125] = "[-y}FRZ6gj(Y0qzq\u0010UH'vn\u0013Y0!=hM\u000b\u0000({o\u00110";
      y[126] = "-\u0013\"0R\u0018zGr(kN!N{#<\u0019\u007f\u001d\"O\u0006Z~\u001az.U@'M";
      y[127] = "\u0005\u001cgzU4\u0007\u0005'9RSV|.>NkY\u0004x2QhU|.)Mj^\u0005|9_*V|";
      y[128] = "Go\u0014\tF?\u0010;D\u0011\u007fiK2M\u001a(>\u0014o\u0016v\u0018aE'J\f\u0005lW/";
      y[129] = "?}&3D,kp*0OHo\u0014o?Tpcl93Kso\u0014m,\u0017-k~-9Q6\u0006";
      y[130] = "s=7*F\u0003\"f%v!\u0003w%)tM1$av\"!\u001e+ayb@Vz21\u0013";
      y[131] = "CHN\u0013\"\u0007\t\f\u0011y,hJ\bWA%\u0010\u001c\u0004HB)hH\u001b\u0014\u001c-\u0002\b\u000eR\u0007@";
      y[132] = "q\u00143)\u0006g-\u0003:'\u0016_&\u00127(\u0011\buCb|}f/\u001a?7E:8\u00131'";
      y[133] = "wo\u001eKG\u0014}h\f\u0018'F\u0013-\u001d\n\u001fJk{\u0011\u0015\u001cF\u0013/\u000eIBByo\u001b\u000fY/";
      y[134] = "V~i\u00028K[y;\u0017\u0001Gf-{\u00139C\u001e{w\f:Of/hPdK\fo}\u0016\u007f&";
      y[135] = "Kx#\u00127!\u001a#1NP!O`=L<\u0013\u001c%d\u0016P\u007fL#8F:?Ye#+";
      y[136] = "k\u0001Ff]\u0018*LA`#\u0015PMW!JB3\nP)O\u007f";
      y[137] = "L\nngMcT\b!>2u1Lm\"\nyI\u001aa=\tu1N~aWq[\u000ek'L\u001c";
      y[138] = "]R\u0010_9Q\u0015\u0003C\u0017HUH\u001fH\b$g\u001aR\u0010^HI\u0014\u001b\u0013\t$RB\rBo";
      y[139] = "\u0017*{WCNXf:\f*]Ky$P}\t\u0011-}\u0006*\u000eNi8BTAWo8";
      y[140] = "4^>=\r\u001f5\u0011=yw\ne\u0002b* Z>T;FK\u001e=\u0006;%\f\u00195\u0003";
      y[141] = "q\u0011R\u001f;\u0013|\u0016\u0000\n\u0002\u0017AB@\u000e:\u001b9\u0014L\u00119\u0017A\u0012\u0007\u0017gEq\u001bA\u0010;~";
      y[142] = "[>/:`\u0018Gi5 \u0005\u0011J\u0000m<i\nG=,i}\u0006$\u007fi)n\u0013Jc>3tv";
      y[143] = "6\u000f\u0010\u0013fI&\t\u0005J\u0004\u0013:V\u0005\u001cm\u001f\u0003X\u0005\fiyf_^\u0014i\u0013&J\u0018\u000f\u0004";
      y[144] = "D\u0017n{x_\u0005Zi}\u0006S\u007f[\u007f<o\u0005\u001c\u001cx4j8";
      y[145] = "vG\u0000O@@2\u0003\u0007\u0013\u00179%~Y\u0003S\u0001*\u0006\u000f\u000fL\u0002&~[\u0010\u0010\\\"\u0014\u001b\u0005VGO";
      y[146] = "8-\u0016\u001d45<)JLQ;VlJL-1k-\u001fX!R";
      y[147] = "N-7\u00191\u0011\u001fv%EV\u0011J5)G:#\u001avr\u0011V\u001bC'+NhJ]*) 9\nW/1\u00194\u0005W\"I";
      y[148] = "#ae\u001c|+.'kDA~\\%&[yu$s*Dzy\\'5\u0018$}6g ^?\u0010";
      y[149] = "H\u0018\u0007=]\u001fL\u001d\u0002h,\u0003OB_,A8L'\u0001n\u0012C\\C@bK\u001cI'\u0003<\u0013\u001cOMC)U\u0007\"";
      y[150] = "U'n$~}Xa`|C+*c-c{#R5!|x/*3jz&}\u001a:,}zF";
      y[151] = "!\u0002/*#\u001fvV\u007f2\u001aI-_v9M\u001es\b.UsC2\u000bu0\"\u0018 W";
      y[152] = ":\u001d!uWr~Y&)\u0000\u000bj$x9D3f\\.5[0j$(~]n8\u0014!8Z2\u0003";
      y[153] = "w\u001f\r\u0018%`qG\t\r;\t+\u0017H\u0012 e\u0019C\u000eO{2N\u0019\u0004\u0014|0p\u0011]\u0003x\t";
      y[154] = "I;$8X\\\u0006wec1O\u0015h{?f\u0018L< j1\u001c\u0010xg-OS\t~g";
      y[155] = "~v\u000e&\u0005Qc%\u0011xgVc1\u001b%\u001c; !\u001e=\u0004\u0006at\n1g\u0000ts\u0017,\r@a5\fA";
      y[156] = "(R\u0011\u0006{\u00192W\u001c\u0011F\u001aYB\u000bC}@bOMM%";
      y[157] = "\u0007wA\u0006A}SzM\u0005J\u0019W\u001e\b\nQ![f^\u0006N\"W\u001e^\t]\u007fF'S\u0006]r>";
      y[158] = "\tf\u000bUa,H{S^3FUn\u0010Yl*g:T\u00007v0?\u0016\u0000b{Sx\u0011\bgF";
      y[159] = "]Cc}*jPD1h\u0013nm\u0010ql+b\u0015F}s(nm\u0015v)z:\u000eRq!\u007f\u0007";
      y[160] = "JXte\"1LWu7yT\u0013X6\u0013t$\u000f1v;&1\u001e[6.`*s";
      y[161] = "m[c\u00030:?KqC8C1\\`Z5/\u0003\b$\u0000hCm[c\u00030:?KqC8CmZ`\u0002)}e\bnT4C";
      y[162] = "5\u0017{2(B=Nl6\u0011\u0019;[}n}+o\u0018\"6.|2\u001dans\u0016/N~0\u0011";
      y[163] = "8wge\t@p{~o\u0018<m\u001b<c\n\u0004dcjo\u0015\u0007h\u001b<w\u0006Mm\u007fhz\nNf\u001b";
      y[164] = "_:Szm.]9N=\u00135>>Bx+9FhNg(5>;E=za]|B5\u007f\\";
      y[165] = "k\u0003O\u0017tFv\u000e]\u001f\u0017Ya\u0019@\b{k<^\u001aW\u0017X6\u0019G\r}Ee\u0006\u0019oqL4][\u001dxG4\u0003 ";
      y[166] = "s{`+w>$c7~nY#\u001d6gua/e`kjb#\u001drs{&!wvjf4J";
      y[167] = "k\u0013wdWy$\nqd)b;\u000bj{EPfL:-)~g\u000f1zEe1\u0019`\u001c";
      y[168] = "E,\u001dGm_T$\u001cY\u0002CSh\u0016Xnq\u0007-M\u00073&Z.\nX`LG}\u0015\u0006\u0002";
      y[169] = "\u000f0|r\u0002'\u001f6i+`z\u001dsdt\u001b\u0017^cal\u0003*\u001f6u``,\n1h}\nl\u001fws\u0010";
      y[170] = "G\u001fSc\u0001yJ\u0018\u0001v8pwLAr\u0000q\u000f\u001aMm\u0003}wNR1]y\u001d\u000eGwF\u0014";
      y[171] = "3?f&gN1<{a\u0019VR;w$!Y*m{;\"UR9dg|Q8yq!g<";
      y[172] = "; 4\u00061oz,=\u0003C:\u0005w%D{6}!)[x:\u0005~i\u00008)~\u007f&\u0003|S";
      y[173] = "\u001a*wW\u001b\u0018Kqe\u000b|\u0018\u001e2i\t\u0010*Mv5Q|\u0005Bv9\u001f\u001dM\u0013%qn";
      y[174] = "\\\u000ffN\u001aNX\nc\u001bkCQV%H\nNM0cL\u0007TU\r\"\u0019\u0013X6\u000b7\u001e\u000eE\\K\"X\u0015(";
      y[175] = "tWW)B\u0013=PF>Fj#\bS\"S=wR\u0007z\u0006j4XF}Y\u0006/\u000eP,";
      y[176] = "lT\u001djY\bhQ\u0018?(\u0007j\u0007\"?E\u0002z\b\u001f~\u0010\u0016vk\u0019k\u0017\u000bk\u0001Y~Q\u0010\u0006";
      y[177] = "~dWLf\u0002x<SYxk\"l\u0012Fc\u0007\u00108T\u001b8UG8\tOa\u0010\u007fd\u001eFo\u0000G";
      y[178] = "\u001bh\u000bW\\d\u0006;\u0014\t>k\u0012.\u0017WRYClJ\r\u000e\u000eF8\b\t\\w\u0014(\u001aIT\u000e";
      y[179] = "_(S\u0002\u0000\f\u00028[_\u001b`\u000fS\u000fN\u000eX\u0003+YB\u0011[\u000fS\u000fH\u0017Q\u0014?RX\u001f\f\u000fS";
      y[180] = "\u0011\u0007,`HM\u0015\u0002)59@\u001fUzu9BA]v4\tK\u0007Z*\u000f";
      y[181] = "\u001b+V\u0003m\nZ9B\u001a$nL-A\u0013i0K-[\u0017\u0015\u0001\\9@\u0002,\fS9Mz";
      y[182] = "\u001f\\#\u0010jA^A{\u001b8+CT8\u001cgGq\u0000|E>\u0017&\u0005>Ei\u0016EB9Ml+";
      y[183] = "^!2_M]Lq~\u0010#Q\"\"~S\u001b]ZtrL\u0018Q\"fj]\\SHbs@N8";
      y[184] = "yO1\u0002\\\u0005sH#Q<T\u001d\r2C\u0004[e[>\\\u0007W\u001d[1OZF$V>OW>";
      y[185] = "?y\u0002.\u00125v~\u00139\u0016Lh&\u0006%\u0003\u001b6wSxo57?P'\u0003.a)\u0001";
      y[186] = "\u001c\u0005F\u000fc\u001a\u0011CHW^HcA\u0005HfD\u001b\u0017\tWeHcA\u0011D/M\u0007\u0015\u001cH,Fc";
      y[187] = "\u0018?e\u0011\u001a\tD(l\u001f\n1L!q\u001d\u0005J!ba\u0018\u001dR\u001c#4\f\u00111\u001a63\u0011\f[Z#u\na";
      y[188] = "\tx\nt{\u001dF4K/\u0012\u000eU+UsEY\f~\n!\u0012]P;Ial\u0012I=I";
      y[189] = "4\u0014j\u001bd{6\u0017w\\\u001a`U\u0010{\u0019\"l-Fw\u0006!`U\u0014b\u0018bw+[{\u001eb\t";
      y[190] = "6\\\u00047e]+\u000f\u001bi\u0007R?\u001a\u00187k`k^@n67n\u001cA9:T)\u001bI<\u0007\u000b(_\u0011mdL/W\u0014P;Mk\u000fE3|Jc\nx4=K5\u0004\u0012)nTkf";
      y[191] = "J3w\u0019'\u0013Bj`\u001d\u001eHD\u007fqErz\u0010<.\u0012&-\u0010fvNtGQ{.E&-";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(243698531891109L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(243698531891109L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(243698531891109L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 101;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 252;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 104;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 121;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 206;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 192;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 101;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 252;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 104;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dT_C0201",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AnchorExploder var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$0", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AnchorExploder var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$4", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AnchorExploder var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AnchorExploder var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$3", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AnchorExploder var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$6", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AnchorExploder var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AnchorExploder var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dT_C0201;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dT_C0201", "lambda$new$2", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorExploder)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8() {
         MethodHandle var4 = bindingCache8;
         MethodHandle var3 = bindingCache8;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dT_C0201", "lambda$onTick$7", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding9() {
         MethodHandle var4 = bindingCache9;
         MethodHandle var3 = bindingCache9;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/dT_C0201", "lambda$calculate$8", "(Lnet/minecraft/util/math/BlockPos;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
