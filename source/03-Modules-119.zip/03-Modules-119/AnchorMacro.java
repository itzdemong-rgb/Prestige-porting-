package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class AnchorMacro extends Module {
   private BooleanSetting d;
   private MinMaxSetting a;
   private BooleanSetting c;
   private BindSetting f;
   private ModeSetting e;
   private BooleanSetting g;
   private BooleanSetting h;
   private ModeSetting i;
   private BooleanSetting j;
   private BooleanSetting k;
   private BooleanSetting l;
   private ModeSetting m;
   private IntSetting n;
   private BooleanSetting o;
   public static boolean p;
   private ElapsedTimer q;
   private boolean r;
   private ArrayList s;
   private ArrayList t;
   private int u;
   private int v;
   private int w;
   private static final long x = 41631174899288L;
   private static final String[] y;
   private static final String[] z;
   private static final Map A = new HashMap(13);
   private static final Object[] B = new Object[140];
   private static final String[] C = new String[140];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;

   public AnchorMacro() {
      super();
      long var10001 = 58757189902717L ^ 92886834255444L;
      var10001 = 58757189902717L ^ 20851480451743L;
      var10001 = 58757189902717L ^ 116505229887948L;
      var10001 = 58757189902717L ^ 101058529194681L;
      var10001 = 58757189902717L ^ 111811721947857L;

      this.q = new ElapsedTimer(106698256430889L);
      this.s = new ArrayList();
      this.t = new ArrayList();
      this.u = -1;
      this.v = -1;
      this.w = -1;
      IntSetting var10000 = this.n;
      Object[] var14 = new Object[]{invokeBinding1(this), 43459238656994L};
      IntSetting var13 = var10000;
      var13.aReturningIntSetting(var14);
      BooleanSetting var31 = this.o;
      Object[] var16 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var15 = var31;
      var15.aReturningBooleanSetting(var16);
      ModeSetting var32 = this.i;
      Object[] var18 = new Object[]{invokeBinding3(this), 121607650890692L};
      ModeSetting var17 = var32;
      var17.aReturningModeSetting(var18);
      BooleanSetting var33 = this.k;
      Object[] var20 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var19 = var33;
      var19.aReturningBooleanSetting(var20);
      BooleanSetting var34 = this.j;
      Object[] var22 = new Object[]{invokeBinding5(this), 88791076916140L};
      BooleanSetting var21 = var34;
      var21.aReturningBooleanSetting(var22);
      ModeSetting var35 = this.m;
      Object[] var24 = new Object[]{invokeBinding6(this), 121607650890692L};
      ModeSetting var23 = var35;
      var23.aReturningModeSetting(var24);
      BindSetting var36 = this.f;
      Object[] var26 = new Object[]{invokeBinding7(this), 101728543910065L};
      BindSetting var25 = var36;
      var25.aReturningBindSetting(var26);
      BooleanSetting var37 = this.g;
      Object[] var28 = new Object[]{invokeBinding8(this), 88791076916140L};
      BooleanSetting var27 = var37;
      var27.aReturningBooleanSetting(var28);
      ModeSetting var38 = this.e;
      Object[] var30 = new Object[]{invokeBinding9(this), 121607650890692L};
      ModeSetting var29 = var38;
      var29.aReturningModeSetting(var30);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      ArrayList var4 = this.s;
      var4.clear();
      ArrayList var5 = this.t;
      var5.clear();
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 96973222086681L ^ 85284523571790L;
      var10001 = 96973222086681L ^ 48352192329302L;
      var10001 = 96973222086681L ^ 139393210900505L;
      var10001 = 96973222086681L ^ 56809745945111L;
      var10001 = 96973222086681L ^ 118582217922359L;
      var10001 = 96973222086681L ^ 51826522083938L;
      int var16 = Event.bReturningInt();
      int var88 = var16;
      MinecraftClient var87 = b;
      MinecraftClient var64 = var87;
      MinecraftClient var63 = var87;
      if (var88 == 0) {
         MinecraftClient var17 = var63;
         Screen var89 = var17.currentScreen;
         if (var89 != null) {
            return;
         }

         MinecraftClient var90 = b;
         var64 = var90;
      }

      MinecraftClient var20 = var64;
      byte var10000 = ((byte)((var20.isWindowFocused()) ? 1 : 0));
      int var92 = var16;
      byte var91 = var10000;
      byte var66 = var91;
      byte var65 = var91;
      if (var92 == 0) {
         byte var93 = var65;
         if (var93 == 0) {
            return;
         }

         MinecraftClient var22 = b;
         ClientPlayerEntity var23 = var22.player;
         byte var94 = ((byte)((var23.isUsingItem()) ? 1 : 0));
         var66 = var94;
      }

      int var96 = var16;
      byte var95 = var66;
      byte var68 = var95;
      byte var67 = var95;
      if (var96 == 0) {
         byte var97 = var67;
         if (var97 != 0) {
            return;
         }

         var68 = ((byte)((AutoObbyCrystal.R) ? 1 : 0));
      }

      int var99 = var16;
      byte var98 = var68;
      byte var70 = var98;
      byte var69 = var98;
      if (var99 == 0) {
         byte var100 = var69;
         if (var100 != 0) {
            return;
         }

         RotationManager var128 = Prestige.o;
         Object[] var28 = new Object[0];
         RotationManager var27 = var128;
         byte var101 = ((byte)((var27.fReturningBoolean(var28)) ? 1 : 0));
         var70 = var101;
      }

      int var103 = var16;
      byte var102 = var70;
      byte var72 = var102;
      byte var71 = var102;
      if (var103 == 0) {
         byte var104 = var71;
         if (var104 != 0) {
            return;
         }

         ElapsedTimer var129 = this.q;
         Object[] var32 = new Object[]{this.a, 130913203968635L};
         ElapsedTimer var31 = var129;
         var72 = ((byte)((var31.bReturningBoolean(var32)) ? 1 : 0));
      }

      int var106 = var16;
      byte var105 = var72;
      byte var74 = var105;
      byte var73 = var105;
      if (var106 == 0) {
         byte var107 = var73;
         if (var107 == 0) {
            return;
         }

         BooleanSetting var34 = this.d;
         Boolean var35 = (Boolean)var34.aReturningObject();
         var74 = ((byte)(((java.lang.Boolean)(var35)).booleanValue() ? 1 : 0));
      }

      int var109 = var16;
      byte var108 = var74;
      byte var76 = var108;
      byte var75 = var108;
      if (var109 == 0) {
         byte var110 = var75;
         if (var110 != 0) {
            ArrayList var130 = this.s;
            Predicate var38 = invokeBinding10();
            ArrayList var37 = var130;
            var37.removeIf(var38);
         }

         ElapsedTimer var131 = this.q;
         Object[] var41 = new Object[]{42835128969216L};
         ElapsedTimer var40 = var131;
         var40.aReturningVoid(var41);
         MinMaxSetting var132 = this.a;
         Object[] var43 = new Object[]{127318019014223L};
         MinMaxSetting var42 = var132;
         var42.bReturningVoid(var43);
         p = dev.prestige.recovery.SourceSupport.asBoolean(1);
         BooleanSetting var44 = this.c;
         Boolean var45 = (Boolean)var44.aReturningObject();
         var76 = ((byte)(((java.lang.Boolean)(var45)).booleanValue() ? 1 : 0));
      }

      byte var80;
      int var112 = var16;
      byte var111 = var76;
      var80 = var111;
      byte var77 = var111;
      label83:
      if (var112 == 0) {
         byte var113 = var77;
         if (var113 != 0) {
            Object[] var48 = new Object[]{23787941655127L};
            AnchorMacro var47 = this;
            var10000 = ((byte)((var47.dReturningBoolean(var48)) ? 1 : 0));
            int var115 = var16;
            byte var114 = var10000;
            var80 = var114;
            byte var78 = var114;
            if (var115 != 0) {
               break label83;
            }

            byte var116 = var78;
            byte var79 = var116;
            byte var117 = var79;
            if (var117 != 0) {
               return;
            }
         }

         BooleanSetting var51 = this.h;
         Boolean var52 = (Boolean)var51.aReturningObject();
         var80 = ((byte)(((java.lang.Boolean)(var52)).booleanValue() ? 1 : 0));
      }

      byte var84;
      int var119 = var16;
      byte var118 = var80;
      var84 = var118;
      byte var81 = var118;
      label76:
      if (var119 == 0) {
         byte var120 = var81;
         if (var120 != 0) {
            Object[] var55 = new Object[]{118306397657614L};
            AnchorMacro var54 = this;
            var10000 = ((byte)((var54.eReturningBoolean(var55)) ? 1 : 0));
            int var122 = var16;
            byte var121 = var10000;
            var84 = var121;
            byte var82 = var121;
            if (var122 != 0) {
               break label76;
            }

            byte var123 = var82;
            byte var83 = var123;
            byte var124 = var83;
            if (var124 != 0) {
               return;
            }
         }

         BooleanSetting var58 = this.l;
         Boolean var59 = (Boolean)var58.aReturningObject();
         var84 = ((byte)(((java.lang.Boolean)(var59)).booleanValue() ? 1 : 0));
      }

      int var126 = var16;
      byte var125 = var84;
      byte var86 = var125;
      byte var85 = var125;
      if (var126 == 0) {
         byte var127 = var85;
         if (var127 != 0) {
            Object[] var62 = new Object[]{57087707930414L};
            AnchorMacro var61 = this;
            var61.jReturningVoid(var62);
         }

         var86 = 0;
      }

      p = dev.prestige.recovery.SourceSupport.asBoolean(var86);
   }

   private boolean dReturningBoolean(Object[] var1) {
      int var332;

      long var4;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      long var20;
      long var22;
      long var24;
      int var26;
      int var142;
      long var331;
      label274: {
         long var2 = (Long)var1[0];
         var331 = 41631174899288L ^ var2;
         var4 = var331 ^ 64061602497578L;
         var6 = var331 ^ 61298130617852L;
         var8 = var331 ^ 108838895395966L;
         var10 = var331 ^ 105432749357740L;
         var12 = var331 ^ 32425841083136L;
         var14 = var331 ^ 124845608534393L;
         var16 = var331 ^ 88660399088164L;
         long var18 = var331 ^ 105470348098083L;
         var20 = var331 ^ 8400222945206L;
         var22 = var331 ^ 135600910701002L;
         var24 = var331 ^ 12523059328598L;
         var26 = Event.bReturningInt();
         BindSetting var32 = this.f;
         Integer var33 = (Integer)var32.aReturningObject();
         int var10000 = var33;
         int var212 = var26;
         
         int var140 = var210;
         byte var141 = var211;
         int var137 = var210;
         byte var138 = var211;
         if (var212 == 0) {
            byte var214 = var138;
            int var213 = var137;
            if (var213 == var214) {
               return false;
            }

            int var216 = var26;
            int var215 = this.u;
            var142 = var215;
            int var139 = var215;
            if (var216 != 0) {
               break label274;
            }

            
            var140 = var217;
            var141 = var218;
         }

         byte var220 = var141;
         int var219 = var140;
         if (var219 != var220) {
            var10000 = this.u;
            Object[] var10003 = new Object[]{null, var14};
            var10003[0] = var10000;
            Object[] var37 = var10003;
            InventoryUtil.aReturningVoid(var37);
            this.u = -1;
            return false;
         }

         BindSetting var333 = this.f;
         Object[] var40 = new Object[]{var18};
         BindSetting var39 = var333;
         var142 = (((var39.cReturningBoolean(var40)) ? 1 : 0));
      }

      int var222 = var26;
      int var221 = var142;
      int var144 = var221;
      int var143 = var221;
      if (var222 == 0) {
         int var223 = var143;
         if (var223 == 0) {
            this.r = false;
            return false;
         }

         var144 = (((this.r) ? 1 : 0));
      }

      int var225 = var26;
      int var224 = var144;
      int var146 = var224;
      int var145 = var224;
      if (var225 == 0) {
         int var226 = var145;
         if (var226 == 0) {
            short var10001 = 21861;
            long var10002 = 6460965921284755826L ^ var331;
            Object[] var44 = new Object[]{this, "Is placing an anchor.", NotificationType.INFO, var10};
            ModuleNotificationsWidget.s(var44);
         }

         var146 = (((this.r) ? 1 : 0));
      }

      int var228 = var26;
      int var227 = var146;
      int var149 = var227;
      int var147 = var227;
      if (var228 == 0) {
         int var229 = var147;
         if (var229 == 0) {
            MinecraftClient var47 = b;
            HitResult var28 = var47.crosshairTarget;
            int var335 = (((var28 instanceof BlockHitResult) ? 1 : 0));
            int var231 = var26;
            boolean var230 = dev.prestige.recovery.SourceSupport.asBoolean(var335);
            boolean var358 = var230;
            boolean var148 = var230;
            if (var231 != 0) {
               return var358;
            }

            boolean var232 = var148;
            if (var232) {
               BlockHitResult var27 = (BlockHitResult)var28;
               int var233 = var26;
               if (var233 == 0) {
                  int var154;
                  label252: {
                     int var153;
                     label251: {
                        label277: {
                           BlockHitResult var50 = var27;
                           Object[] var51 = new Object[]{var50.getBlockPos(), Blocks.RESPAWN_ANCHOR, var8};
                           var335 = (((BlockUtil.bReturningBoolean(var51)) ? 1 : 0));
                           int var236 = var26;
                           byte var235 = ((byte)(var335));
                           int var151 = var235;
                           byte var150 = var235;
                           if (var236 == 0) {
                              byte var237 = var150;
                              if (var237 == 0) {
                                 break label277;
                              }

                              BlockHitResult var53 = var27;
                              Object[] var54 = new Object[]{var53.getBlockPos(), var20};
                              int var238 = BlockUtil.aReturningInt(var54);
                              var151 = var238;
                           }

                           int var240 = var26;
                           int var239 = var151;
                           var153 = var239;
                           int var152 = var239;
                           if (var240 != 0) {
                              break label251;
                           }

                           int var241 = var152;
                           if (var241 == 0) {
                              var153 = 1;
                              break label251;
                           }
                        }

                        var154 = 0;
                        break label252;
                     }

                     int var242 = var153;
                     var154 = var242;
                  }

                  int var158;
                  var332 = var154;
                  Object[] var57 = new Object[]{var27, var16};
                  var335 = (((BlockUtil.dReturningBoolean(var57)) ? 1 : 0));
                  int var244 = var26;
                  byte var243 = ((byte)(var335));
                  var158 = var243;
                  byte var155 = var243;
                  label239:
                  if (var244 == 0) {
                     byte var245 = var155;
                     if (var245 == 0) {
                        int var247 = var26;
                        int var246 = var332;
                        var158 = var246;
                        int var156 = var246;
                        if (var247 != 0) {
                           break label239;
                        }

                        int var248 = var156;
                        int var157 = var248;
                        int var249 = var157;
                        if (var249 == 0) {
                           return false;
                        }
                     }

                     var158 = -1;
                  }

                  int var29;
                  int var166;
                  var29 = var158;
                  ModeSetting var62 = this.e;
                  String var30 = (String)var62.aReturningObject();
                  
                  var335 = var63.hashCode();
                  int var251 = var26;
                  int var250 = var335;
                  var166 = var250;
                  int var159 = var250;
                  label232:
                  if (var251 == 0) {
                     int var252 = var159;
                     switch (var252) {
                        case 2433880:
                           short var347 = 11729;
                           long var352 = 3651576961149659585L ^ var331;
                           String var66 = "None";
                           String var65 = var30;
                           byte var339 = ((byte)((var65.equals(var66)) ? 1 : 0));
                           int var254 = var26;
                           byte var253 = var339;
                           var166 = var253;
                           byte var160 = var253;
                           if (var254 != 0) {
                              break label232;
                           }

                           byte var255 = var160;
                           byte var161 = var255;
                           byte var256 = var161;
                           if (var256 == 0) {
                              break;
                           }

                           var31 = 0;
                           int var257 = var26;
                           if (var257 == 0) {
                              break;
                           }
                        case 2590131:
                           short var348 = 6368;
                           long var353 = 2601508401600322804L ^ var331;
                           String var70 = "Swap";
                           String var69 = var30;
                           byte var340 = ((byte)((var69.equals(var70)) ? 1 : 0));
                           int var259 = var26;
                           byte var258 = var340;
                           var166 = var258;
                           byte var162 = var258;
                           if (var259 != 0) {
                              break label232;
                           }

                           byte var260 = var162;
                           byte var163 = var260;
                           byte var261 = var163;
                           if (var261 == 0) {
                              break;
                           }

                           var31 = 1;
                           int var262 = var26;
                           if (var262 == 0) {
                              break;
                           }
                        case -1818460043:
                           short var349 = 22998;
                           long var354 = 7410715938151996869L ^ var331;
                           String var74 = "Silent";
                           String var73 = var30;
                           byte var341 = ((byte)((var73.equals(var74)) ? 1 : 0));
                           int var264 = var26;
                           byte var263 = var341;
                           var166 = var263;
                           byte var164 = var263;
                           if (var264 != 0) {
                              break label232;
                           }

                           byte var265 = var164;
                           byte var165 = var265;
                           byte var266 = var165;
                           if (var266 != 0) {
                              var31 = 2;
                           }
                     }

                     var166 = var31;
                  }

                  int var186;
                  int var268 = var26;
                  int var267 = var166;
                  var186 = var267;
                  int var167 = var267;
                  label213:
                  if (var268 == 0) {
                     int var269 = var167;
                     switch (var269) {
                        case 0:
                           int var172;
                           int var271 = var26;
                           int var270 = var332;
                           var172 = var270;
                           int var168 = var270;
                           label207:
                           if (var271 == 0) {
                              int var272 = var168;
                              int var169 = var272;
                              int var273 = var169;
                              if (var273 != 0) {
                                 Object[] var80 = new Object[]{Items.GLOWSTONE, var6};
                                 byte var345 = ((byte)((InventoryUtil.lReturningBoolean(var80)) ? 1 : 0));
                                 int var275 = var26;
                                 byte var274 = var345;
                                 var172 = var274;
                                 byte var170 = var274;
                                 if (var275 != 0) {
                                    break label207;
                                 }

                                 byte var276 = var170;
                                 byte var171 = var276;
                                 byte var277 = var171;
                                 if (var277 == 0) {
                                    return false;
                                 }
                              }

                              Object[] var84 = new Object[]{Items.RESPAWN_ANCHOR, var6};
                              var172 = (((InventoryUtil.lReturningBoolean(var84)) ? 1 : 0));
                           }

                           int var279 = var26;
                           int var278 = var172;
                           var186 = var278;
                           int var173 = var278;
                           if (var279 != 0) {
                              break label213;
                           }

                           int var280 = var173;
                           if (var280 == 0) {
                              return false;
                           }
                           break;
                        case 1:
                           BooleanSetting var87 = this.g;
                           Boolean var88 = (Boolean)var87.aReturningObject();
                           byte var343 = ((byte)(((java.lang.Boolean)(var88)).booleanValue() ? 1 : 0));
                           int var282 = var26;
                           byte var281 = var343;
                           int var175 = var281;
                           byte var174 = var281;
                           if (var282 == 0) {
                              byte var283 = var174;
                              if (var283 != 0) {
                                 Object[] var90 = new Object[]{var12};
                                 this.u = InventoryUtil.aReturningInt(var90);
                              }

                              var175 = var332;
                           }

                           int var285 = var26;
                           int var284 = var175;
                           int var179 = var284;
                           int var176 = var284;
                           if (var285 == 0) {
                              int var286 = var176;
                              if (var286 != 0) {
                                 Object[] var93 = new Object[]{Blocks.GLOWSTONE, var24};
                                 var343 = ((byte)((InventoryUtil.iReturningVoid(var93)) ? 1 : 0));
                                 int var288 = var26;
                                 byte var287 = var343;
                                 var186 = var287;
                                 byte var177 = var287;
                                 if (var288 != 0) {
                                    break label213;
                                 }

                                 byte var289 = var177;
                                 byte var178 = var289;
                                 byte var290 = var178;
                                 if (var290 == 0) {
                                    return false;
                                 }
                                 break;
                              }

                              Object[] var97 = new Object[]{Blocks.RESPAWN_ANCHOR, var24};
                              var179 = (((InventoryUtil.iReturningVoid(var97)) ? 1 : 0));
                           }

                           int var292 = var26;
                           int var291 = var179;
                           var186 = var291;
                           int var180 = var291;
                           if (var292 != 0) {
                              break label213;
                           }

                           int var293 = var180;
                           if (var293 == 0) {
                              return false;
                           }
                           break;
                        case 2:
                           label280: {
                              Object[] var100 = new Object[]{var12};
                              var29 = InventoryUtil.aReturningInt(var100);
                              int var295 = var26;
                              int var294 = var332;
                              int var184 = var294;
                              int var181 = var294;
                              if (var295 == 0) {
                                 int var296 = var181;
                                 if (var296 != 0) {
                                    Object[] var102 = new Object[]{Blocks.GLOWSTONE, var24};
                                    byte var342 = ((byte)((InventoryUtil.iReturningVoid(var102)) ? 1 : 0));
                                    int var298 = var26;
                                    byte var297 = var342;
                                    var186 = var297;
                                    byte var182 = var297;
                                    if (var298 != 0) {
                                       break label213;
                                    }

                                    byte var299 = var182;
                                    byte var183 = var299;
                                    byte var300 = var183;
                                    if (var300 == 0) {
                                       return false;
                                    }
                                    break label280;
                                 }

                                 Object[] var106 = new Object[]{Blocks.RESPAWN_ANCHOR, var24};
                                 var184 = (((InventoryUtil.iReturningVoid(var106)) ? 1 : 0));
                              }

                              int var302 = var26;
                              int var301 = var184;
                              var186 = var301;
                              int var185 = var301;
                              if (var302 != 0) {
                                 break label213;
                              }

                              int var303 = var185;
                              if (var303 == 0) {
                                 return false;
                              }
                           }
                     }

                     var186 = var332;
                  }

                  int var305 = var26;
                  int var304 = var186;
                  int var207 = var304;
                  int var187 = var304;
                  if (var305 == 0) {
                     int var306 = var187;
                     if (var306 == 0) {
                        ArrayList var205;
                        BlockPos var206;
                        ArrayList var346 = this.t;
                        BlockHitResult var110 = var27;
                        BlockPos var350 = var110.getBlockPos();
                        int var309 = var26;
                        BlockPos var308 = var350;
                        ArrayList var307 = var346;
                        ArrayList var200 = var307;
                        BlockPos var201 = var308;
                        ArrayList var188 = var307;
                        BlockPos var189 = var308;
                        label174:
                        if (var309 == 0) {
                           ArrayList var199;
                           BlockPos var311 = var189;
                           ArrayList var310 = var188;
                           ArrayList var190 = var310;
                           BlockPos var191 = var311;
                           Object[] var112 = new Object[]{var191, Blocks.FIRE, var8};
                           boolean var313 = BlockUtil.bReturningBoolean(var112);
                           ArrayList var312 = var190;
                           var199 = var312;
                           ArrayList var192 = var312;
                           label171:
                           if (!var313) {
                              ArrayList var314 = var192;
                              ArrayList var193 = var314;
                              BlockHitResult var114 = var27;
                              var350 = var114.getBlockPos();
                              int var317 = var26;
                              BlockPos var316 = var350;
                              ArrayList var315 = var193;
                              ArrayList var203 = var315;
                              BlockPos var204 = var316;
                              ArrayList var194 = var315;
                              BlockPos var195 = var316;
                              if (var317 == 0) {
                                 BlockPos var319 = var195;
                                 ArrayList var318 = var194;
                                 ArrayList var196 = var318;
                                 BlockPos var197 = var319;
                                 Object[] var116 = new Object[]{var22};
                                 Object[] var117 = new Object[]{var197, BlockUtil.aReturningBlock(var116), var8};
                                 boolean var321 = BlockUtil.bReturningBoolean(var117);
                                 ArrayList var320 = var196;
                                 ArrayList var202 = var320;
                                 ArrayList var198 = var320;
                                 if (var321) {
                                    ArrayList var322 = var198;
                                    var199 = var322;
                                    break label171;
                                 }

                                 BlockHitResult var121 = var27;
                                 var204 = var121.getBlockPos();
                                 var203 = var202;
                              }

                              BlockHitResult var122 = var27;
                              Direction var123 = var122.getSide();
                              int var355 = var123.getOffsetX();
                              BlockHitResult var124 = var27;
                              Direction var125 = var124.getSide();
                              int var356 = var125.getOffsetY();
                              BlockHitResult var126 = var27;
                              Direction var127 = var126.getSide();
                              int var131 = var127.getOffsetZ();
                              int var130 = var356;
                              int var129 = var355;
                              BlockPos var128 = var204;
                              var206 = var128.add(var129, var130, var131);
                              var205 = var203;
                              break label174;
                           }

                           BlockHitResult var119 = var27;
                           BlockPos var324 = var119.getBlockPos();
                           ArrayList var323 = var199;
                           var205 = var323;
                           var206 = var324;
                        } else {
                           BlockPos var326 = var201;
                           ArrayList var325 = var200;
                           var205 = var325;
                           var206 = var326;
                        }

                        BlockPos var133 = var206;
                        ArrayList var132 = var205;
                        var132.add(var133);
                     }

                     Object[] var134 = new Object[]{var27, var4};
                     ItemUseUtil.aReturningBoolean(var134);
                     var207 = var29;
                  }

                  int var328 = var26;
                  int var327 = var207;
                  int var209 = var327;
                  int var208 = var327;
                  if (var328 == 0) {
                     
                     if (var329 != var330) {
                        Object[] var357 = new Object[]{null, var14};
                        var357[0] = var29;
                        Object[] var136 = var357;
                        InventoryUtil.aReturningVoid(var136);
                     }

                     this.r = true;
                     var209 = 1;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var209);
               }
            }
         }

         byte var234 = 0;
         var149 = var234;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var149);
   }

   public boolean eReturningBoolean(Object[] var1) {
      int var204;

      long var2 = (Long)var1[0];
      var2 = 41631174899288L ^ var2;
      long var4 = var2 ^ 19483524972984L;
      long var6 = var2 ^ 75283597028467L;
      long var8 = var2 ^ 81345611853221L;
      long var10 = var2 ^ 109154173463385L;
      long var12 = var2 ^ 17249513990432L;
      long var14 = var2 ^ 133693763786735L;
      long var16 = var2 ^ 129021178404367L;
      int var18 = Event.cReturningInt();
      int var131 = var18;
      int var130 = this.v;
      int var94 = var130;
      int var93 = var130;
      if (var131 != 0) {
         
         if (var132 == var133) {
            MinecraftClient var26 = b;
            HitResult var20 = var26.crosshairTarget;
            int var205 = (((var20 instanceof BlockHitResult) ? 1 : 0));
            int var136 = var18;
            byte var135 = (byte)var205;
            byte var96 = var135;
            byte var95 = var135;
            if (var136 != 0) {
               byte var137 = var95;
               if (var137 != 0) {
                  BlockHitResult var19 = (BlockHitResult)var20;
                  int var138 = var18;
                  if (var138 != 0) {
                     MinecraftClient var29 = b;
                     ClientPlayerEntity var30 = var29.player;
                     var205 = (((var30.isSneaking()) ? 1 : 0));
                     int var141 = var18;
                     byte var140 = ((byte)(var205));
                     byte var106 = var140;
                     byte var97 = var140;
                     if (var141 != 0) {
                        byte var142 = var97;
                        if (var142 == 0) {
                           BlockHitResult var32 = var19;
                           Object[] var33 = new Object[]{var32.getBlockPos(), Blocks.RESPAWN_ANCHOR, var4};
                           var205 = (((BlockUtil.kReturningBoolean(var33)) ? 1 : 0));
                           int var144 = var18;
                           byte var143 = ((byte)(var205));
                           var106 = var143;
                           byte var98 = var143;
                           if (var144 == 0) {
                              return dev.prestige.recovery.SourceSupport.asBoolean(var106);
                           }

                           byte var145 = var98;
                           byte var99 = var145;
                           byte var146 = var99;
                           label159:
                           if (var146 != 0) {
                              BooleanSetting var36 = this.d;
                              Boolean var37 = (Boolean)var36.aReturningObject();
                              var205 = ((((java.lang.Boolean)(var37)).booleanValue() ? 1 : 0));
                              int var148 = var18;
                              byte var147 = ((byte)(var205));
                              int var104 = var147;
                              byte var100 = var147;
                              if (var148 != 0) {
                                 byte var149 = var100;
                                 byte var101 = var149;
                                 byte var150 = var101;
                                 if (var150 != 0) {
                                    ArrayList var209 = this.s;
                                    BlockHitResult var40 = var19;
                                    BlockPos var42 = var40.getBlockPos();
                                    ArrayList var41 = var209;
                                    var205 = (((var41.contains(var42)) ? 1 : 0));
                                    int var152 = var18;
                                    byte var151 = ((byte)(var205));
                                    var106 = var151;
                                    byte var102 = var151;
                                    if (var152 == 0) {
                                       return dev.prestige.recovery.SourceSupport.asBoolean(var106);
                                    }

                                    byte var153 = var102;
                                    byte var103 = var153;
                                    byte var154 = var103;
                                    if (var154 == 0) {
                                       break label159;
                                    }
                                 }

                                 BlockHitResult var45 = var19;
                                 Object[] var46 = new Object[]{var45.getBlockPos(), var14};
                                 int var155 = BlockUtil.aReturningInt(var46);
                                 var104 = var155;
                              }

                              int var157 = var18;
                              int var156 = var104;
                              int var107 = var156;
                              int var105 = var156;
                              if (var157 != 0) {
                                 int var158 = var105;
                                 if (var158 != 0) {
                                    break label159;
                                 }

                                 BooleanSetting var49 = this.k;
                                 Boolean var50 = (Boolean)var49.aReturningObject();
                                 var107 = ((((java.lang.Boolean)(var50)).booleanValue() ? 1 : 0));
                              }

                              int var111;
                              int var160 = var18;
                              int var159 = var107;
                              var111 = var159;
                              int var108 = var159;
                              label140:
                              if (var160 != 0) {
                                 int var161 = var108;
                                 if (var161 != 0) {
                                    ArrayList var211 = this.t;
                                    BlockHitResult var52 = var19;
                                    BlockPos var54 = var52.getBlockPos();
                                    ArrayList var53 = var211;
                                    var205 = (((var53.contains(var54)) ? 1 : 0));
                                    int var163 = var18;
                                    byte var162 = ((byte)(var205));
                                    var111 = var162;
                                    byte var109 = var162;
                                    if (var163 == 0) {
                                       break label140;
                                    }

                                    byte var164 = var109;
                                    byte var110 = var164;
                                    byte var165 = var110;
                                    if (var165 == 0) {
                                       return false;
                                    }
                                 }

                                 var111 = -1;
                              }

                              int var119;
                              var204 = var111;
                              ModeSetting var58 = this.i;
                              String var21 = (String)var58.aReturningObject();
                              
                              var205 = var59.hashCode();
                              int var167 = var18;
                              int var166 = var205;
                              var119 = var166;
                              int var112 = var166;
                              label133:
                              if (var167 != 0) {
                                 int var168 = var112;
                                 switch (var168) {
                                    case 2433880:
                                       short var10001 = 6667;
                                       long var10002 = 5277146560649180736L ^ var2;
                                       String var62 = "None";
                                       String var61 = var21;
                                       byte var214 = ((byte)((var61.equals(var62)) ? 1 : 0));
                                       int var170 = var18;
                                       byte var169 = var214;
                                       var119 = var169;
                                       byte var113 = var169;
                                       if (var170 == 0) {
                                          break label133;
                                       }

                                       byte var171 = var113;
                                       byte var114 = var171;
                                       byte var172 = var114;
                                       if (var172 == 0) {
                                          break;
                                       }

                                       var22 = 0;
                                       int var173 = var18;
                                       if (var173 != 0) {
                                          break;
                                       }
                                    case 2590131:
                                       short var220 = 231;
                                       long var222 = 730838224346492072L ^ var2;
                                       String var66 = "Swap";
                                       String var65 = var21;
                                       byte var215 = ((byte)((var65.equals(var66)) ? 1 : 0));
                                       int var175 = var18;
                                       byte var174 = var215;
                                       var119 = var174;
                                       byte var115 = var174;
                                       if (var175 == 0) {
                                          break label133;
                                       }

                                       byte var176 = var115;
                                       byte var116 = var176;
                                       byte var177 = var116;
                                       if (var177 == 0) {
                                          break;
                                       }

                                       var22 = 1;
                                       int var178 = var18;
                                       if (var178 != 0) {
                                          break;
                                       }
                                    case -1818460043:
                                       short var221 = 17983;
                                       long var223 = 7889673308882037363L ^ var2;
                                       String var70 = "Silent";
                                       String var69 = var21;
                                       byte var216 = ((byte)((var69.equals(var70)) ? 1 : 0));
                                       int var180 = var18;
                                       byte var179 = var216;
                                       var119 = var179;
                                       byte var117 = var179;
                                       if (var180 == 0) {
                                          break label133;
                                       }

                                       byte var181 = var117;
                                       byte var118 = var181;
                                       byte var182 = var118;
                                       if (var182 != 0) {
                                          var22 = 2;
                                       }
                                 }

                                 var119 = var22;
                              }

                              int var127;
                              int var184 = var18;
                              int var183 = var119;
                              var127 = var183;
                              int var120 = var183;
                              label114:
                              if (var184 != 0) {
                                 int var185 = var120;
                                 switch (var185) {
                                    case 0:
                                       Object[] var74 = new Object[]{Items.GLOWSTONE, var8};
                                       byte var219 = ((byte)((InventoryUtil.lReturningBoolean(var74)) ? 1 : 0));
                                       int var187 = var18;
                                       byte var186 = var219;
                                       var127 = var186;
                                       byte var121 = var186;
                                       if (var187 == 0) {
                                          break label114;
                                       }

                                       byte var188 = var121;
                                       byte var122 = var188;
                                       byte var189 = var122;
                                       if (var189 == 0) {
                                          return false;
                                       }
                                       break;
                                    case 1:
                                       BooleanSetting var78 = this.j;
                                       Boolean var79 = (Boolean)var78.aReturningObject();
                                       byte var218 = ((byte)(((java.lang.Boolean)(var79)).booleanValue() ? 1 : 0));
                                       int var191 = var18;
                                       byte var190 = var218;
                                       byte var124 = var190;
                                       byte var123 = var190;
                                       if (var191 != 0) {
                                          byte var192 = var123;
                                          if (var192 != 0) {
                                             Object[] var81 = new Object[]{var10};
                                             this.v = InventoryUtil.aReturningInt(var81);
                                          }

                                          Object[] var83 = new Object[]{Blocks.GLOWSTONE, var16};
                                          var124 = ((byte)((InventoryUtil.iReturningVoid(var83)) ? 1 : 0));
                                       }

                                       int var194 = var18;
                                       byte var193 = var124;
                                       var127 = var193;
                                       byte var125 = var193;
                                       if (var194 == 0) {
                                          break label114;
                                       }

                                       byte var195 = var125;
                                       if (var195 == 0) {
                                          return false;
                                       }
                                       break;
                                    case 2:
                                       Object[] var86 = new Object[]{var10};
                                       var204 = InventoryUtil.aReturningInt(var86);
                                       Object[] var87 = new Object[]{Blocks.GLOWSTONE, var16};
                                       byte var217 = ((byte)((InventoryUtil.iReturningVoid(var87)) ? 1 : 0));
                                       int var197 = var18;
                                       byte var196 = var217;
                                       var127 = var196;
                                       byte var126 = var196;
                                       if (var197 == 0) {
                                          break label114;
                                       }

                                       byte var198 = var126;
                                       if (var198 == 0) {
                                          return false;
                                       }
                                 }

                                 Object[] var90 = new Object[]{var19, var6};
                                 ItemUseUtil.aReturningBoolean(var90);
                                 var127 = var204;
                              }

                              int var200 = var18;
                              int var199 = var127;
                              int var129 = var199;
                              int var128 = var199;
                              if (var200 != 0) {
                                 
                                 if (var201 != var202) {
                                    Object[] var224 = new Object[]{null, var12};
                                    var224[0] = var204;
                                    Object[] var92 = var224;
                                    InventoryUtil.aReturningVoid(var92);
                                 }

                                 var129 = 1;
                              }

                              return dev.prestige.recovery.SourceSupport.asBoolean(var129);
                           }
                        }

                        var106 = 0;
                     }

                     return dev.prestige.recovery.SourceSupport.asBoolean(var106);
                  }
               }

               byte var139 = 0;
               var96 = var139;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var96);
         }

         int var10000 = this.v;
         Object[] var10003 = new Object[]{null, var12};
         var10003[0] = var10000;
         Object[] var24 = var10003;
         InventoryUtil.aReturningVoid(var24);
         this.v = -1;
         byte var134 = 0;
         var94 = var134;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var94);
   }

   private void jReturningVoid(Object[] var1) {
      int var183;

      long var2 = (Long)var1[0];
      var2 = 41631174899288L ^ var2;
      long var4 = var2 ^ 81135201027224L;
      long var6 = var2 ^ 30832669305171L;
      long var8 = var2 ^ 65098584419961L;
      long var10 = var2 ^ 96493577219072L;
      long var12 = var2 ^ 37291574645455L;
      int var14 = Event.bReturningInt();
      int var117 = var14;
      int var116 = this.w;
      int var83 = var116;
      int var82 = var116;
      if (var117 == 0) {
         
         if (var118 == var119) {
            MinecraftClient var22 = b;
            HitResult var16 = var22.crosshairTarget;
            int var122 = var14;
            HitResult var121 = var16;
            HitResult var85 = var121;
            HitResult var84 = var121;
            if (var122 == 0) {
               boolean var123 = var84 instanceof BlockHitResult;
               if (!var123) {
                  return;
               }

               HitResult var124 = var16;
               var85 = var124;
            }

            BlockHitResult var15 = (BlockHitResult)var85;
            int var125 = var14;
            if (var125 == 0) {
               MinecraftClient var26 = b;
               ClientPlayerEntity var27 = var26.player;
               int var10000 = (((var27.isSneaking()) ? 1 : 0));
               int var127 = var14;
               byte var126 = (byte)var10000;
               byte var87 = var126;
               byte var86 = var126;
               if (var127 == 0) {
                  byte var128 = var86;
                  if (var128 != 0) {
                     return;
                  }

                  BlockHitResult var29 = var15;
                  Object[] var30 = new Object[]{var29.getBlockPos(), Blocks.RESPAWN_ANCHOR, var4};
                  byte var129 = ((byte)((BlockUtil.kReturningBoolean(var30)) ? 1 : 0));
                  var87 = var129;
               }

               int var131 = var14;
               byte var130 = var87;
               byte var89 = var130;
               byte var88 = var130;
               if (var131 == 0) {
                  byte var132 = var88;
                  if (var132 == 0) {
                     return;
                  }

                  BooleanSetting var33 = this.d;
                  Boolean var34 = (Boolean)var33.aReturningObject();
                  byte var133 = ((byte)(((java.lang.Boolean)(var34)).booleanValue() ? 1 : 0));
                  var89 = var133;
               }

               int var93;
               int var135 = var14;
               byte var134 = var89;
               var93 = var134;
               byte var90 = var134;
               label136:
               if (var135 == 0) {
                  byte var136 = var90;
                  if (var136 != 0) {
                     ArrayList var184 = this.s;
                     BlockHitResult var37 = var15;
                     BlockPos var39 = var37.getBlockPos();
                     ArrayList var38 = var184;
                     var10000 = (((var38.contains(var39)) ? 1 : 0));
                     int var138 = var14;
                     byte var137 = ((byte)(var10000));
                     var93 = var137;
                     byte var91 = var137;
                     if (var138 != 0) {
                        break label136;
                     }

                     byte var139 = var91;
                     byte var92 = var139;
                     byte var140 = var92;
                     if (var140 == 0) {
                        return;
                     }
                  }

                  BlockHitResult var42 = var15;
                  Object[] var43 = new Object[]{var42.getBlockPos(), var12};
                  int var141 = BlockUtil.aReturningInt(var43);
                  var93 = var141;
               }

               int var143 = var14;
               int var142 = var93;
               int var95 = var142;
               int var94 = var142;
               if (var143 == 0) {
                  int var144 = var94;
                  if (var144 == 0) {
                     return;
                  }

                  var95 = -1;
               }

               int var103;
               var183 = var95;
               ModeSetting var46 = this.m;
               String var17 = (String)var46.aReturningObject();
               
               var10000 = var47.hashCode();
               int var146 = var14;
               int var145 = var10000;
               var103 = var145;
               int var96 = var145;
               label117:
               if (var146 == 0) {
                  int var147 = var96;
                  switch (var147) {
                     case 2433880:
                        short var10001 = 11729;
                        long var10002 = 3651618507521639608L ^ var2;
                        String var50 = "None";
                        String var49 = var17;
                        byte var187 = ((byte)((var49.equals(var50)) ? 1 : 0));
                        int var149 = var14;
                        byte var148 = var187;
                        var103 = var148;
                        byte var97 = var148;
                        if (var149 != 0) {
                           break label117;
                        }

                        byte var150 = var97;
                        byte var98 = var150;
                        byte var151 = var98;
                        if (var151 == 0) {
                           break;
                        }

                        var18 = 0;
                        int var152 = var14;
                        if (var152 == 0) {
                           break;
                        }
                     case 2590131:
                        short var193 = 6368;
                        long var196 = 2601475653435289997L ^ var2;
                        String var54 = "Swap";
                        String var53 = var17;
                        byte var188 = ((byte)((var53.equals(var54)) ? 1 : 0));
                        int var154 = var14;
                        byte var153 = var188;
                        var103 = var153;
                        byte var99 = var153;
                        if (var154 != 0) {
                           break label117;
                        }

                        byte var155 = var99;
                        byte var100 = var155;
                        byte var156 = var100;
                        if (var156 == 0) {
                           break;
                        }

                        var18 = 1;
                        int var157 = var14;
                        if (var157 == 0) {
                           break;
                        }
                     case -1818460043:
                        short var194 = 22998;
                        long var197 = 7410673911003787452L ^ var2;
                        String var58 = "Silent";
                        String var57 = var17;
                        byte var189 = ((byte)((var57.equals(var58)) ? 1 : 0));
                        int var159 = var14;
                        byte var158 = var189;
                        var103 = var158;
                        byte var101 = var158;
                        if (var159 != 0) {
                           break label117;
                        }

                        byte var160 = var101;
                        byte var102 = var160;
                        byte var161 = var102;
                        if (var161 != 0) {
                           var18 = 2;
                        }
                  }

                  var103 = var18;
               }

               int var115;
               label156: {
                  int var113;
                  int var114;
                  label157: {
                     int var163 = var14;
                     int var162 = var103;
                     int var111 = var162;
                     int var104 = var162;
                     if (var163 == 0) {
                        int var164 = var104;
                        switch (var164) {
                           case 0:
                              IntSetting var62 = this.n;
                              Integer var63 = (Integer)var62.aReturningObject();
                              var10000 = var63 - 1;
                              Object[] var64 = new Object[]{var8};
                              int var195 = InventoryUtil.aReturningInt(var64);
                              int var167 = var14;
                              int var166 = var195;
                              int var165 = var10000;
                              var113 = var165;
                              var114 = var166;
                              int var105 = var165;
                              int var106 = var166;
                              if (var167 != 0) {
                                 break label157;
                              }

                              int var169 = var106;
                              int var168 = var105;
                              int var107 = var168;
                              int var108 = var169;
                              int var171 = var108;
                              int var170 = var107;
                              if (var170 != var171) {
                                 return;
                              }
                              break;
                           case 1:
                              BooleanSetting var67 = this.o;
                              Boolean var68 = (Boolean)var67.aReturningObject();
                              byte var190 = ((byte)(((java.lang.Boolean)(var68)).booleanValue() ? 1 : 0));
                              int var173 = var14;
                              byte var172 = var190;
                              int var110 = var172;
                              byte var109 = var172;
                              if (var173 == 0) {
                                 byte var174 = var109;
                                 if (var174 != 0) {
                                    Object[] var70 = new Object[]{var8};
                                    this.w = InventoryUtil.aReturningInt(var70);
                                 }

                                 IntSetting var72 = this.n;
                                 Integer var73 = (Integer)var72.aReturningObject();
                                 var110 = var73 - 1;
                              }

                              Object[] var198 = new Object[]{null, var10};
                              var198[0] = var110;
                              Object[] var74 = var198;
                              InventoryUtil.aReturningVoid(var74);
                              int var175 = var14;
                              if (var175 == 0) {
                                 break;
                              }
                           case 2:
                              Object[] var75 = new Object[]{var8};
                              var183 = InventoryUtil.aReturningInt(var75);
                              IntSetting var76 = this.n;
                              Integer var77 = (Integer)var76.aReturningObject();
                              var10000 = var77 - 1;
                              Object[] var199 = new Object[]{null, var10};
                              var199[0] = var10000;
                              Object[] var78 = var199;
                              InventoryUtil.aReturningVoid(var78);
                        }

                        Object[] var79 = new Object[]{var15, var6};
                        ItemUseUtil.aReturningBoolean(var79);
                        var111 = var183;
                     }

                     int var177 = var14;
                     int var176 = var111;
                     var115 = var176;
                     int var112 = var176;
                     if (var177 != 0) {
                        break label156;
                     }

                     
                     var113 = var178;
                     var114 = var179;
                  }

                  int var181 = var114;
                  int var180 = var113;
                  if (var180 == var181) {
                     return;
                  }

                  var115 = var183;
               }

               Object[] var200 = new Object[]{null, var10};
               var200[0] = var115;
               Object[] var81 = var200;
               InventoryUtil.aReturningVoid(var81);
               return;
            }

            return;
         }

         int var120 = this.w;
         var83 = var120;
      }

      Object[] var10003 = new Object[]{null, var10};
      var10003[0] = var83;
      Object[] var21 = var10003;
      InventoryUtil.aReturningVoid(var21);
      this.w = -1;
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 28935387986668L ^ 80073233062557L;
      var10001 = 28935387986668L ^ 89586763263785L;
      int var10000 = Event.cReturningInt();
      Object[] var14 = new Object[0];
      PacketSendEvent var13 = var1;
      Packet var10 = var13.aReturningVoid(var14);
      int var8 = var10000;
      int var94 = var8;
      Packet var93 = var10;
      Packet var62 = var93;
      Packet var61 = var93;
      if (var94 != 0) {
         boolean var95 = var61 instanceof PlayerInteractBlockC2SPacket;
         if (!var95) {
            return;
         }

         Packet var96 = var10;
         var62 = var96;
      }

      PlayerInteractBlockC2SPacket var9 = (PlayerInteractBlockC2SPacket)var62;
      PlayerInteractBlockC2SPacket var17 = var9;
      Hand var138 = var17.getHand();
      Hand var19 = Hand.MAIN_HAND;
      Hand var18 = var138;
      boolean var97 = var18.equals(var19);
      ItemStack var63;
      if (var97) {
         MinecraftClient var20 = b;
         ClientPlayerEntity var21 = var20.player;
         ItemStack var98 = var21.getMainHandStack();
         var63 = var98;
      } else {
         MinecraftClient var23 = b;
         ClientPlayerEntity var24 = var23.player;
         var63 = var24.getOffHandStack();
      }

      ItemStack var137 = var63;
      ItemStack var25 = var137;
      Item var139 = var25.getItem();
      Item var100 = Items.RESPAWN_ANCHOR;
      Item var99 = var139;
      if (var99 == var100) {
         BlockHitResult var11;
         BlockPos var12;
         ArrayList var70;
         BlockPos var71;
         label75: {
            PlayerInteractBlockC2SPacket var26 = var9;
            var11 = var26.getBlockHitResult();
            BlockHitResult var27 = var11;
            BlockPos var140 = var27.getBlockPos();
            BlockHitResult var28 = var11;
            Direction var29 = var28.getSide();
            int var144 = var29.getOffsetX();
            BlockHitResult var30 = var11;
            Direction var31 = var30.getSide();
            int var10002 = var31.getOffsetY();
            BlockHitResult var32 = var11;
            Direction var33 = var32.getSide();
            int var37 = var33.getOffsetZ();
            int var36 = var10002;
            int var35 = var144;
            BlockPos var34 = var140;
            var12 = var34.add(var35, var36, var37);
            BooleanSetting var38 = this.d;
            Boolean var39 = (Boolean)var38.aReturningObject();
            boolean var141 = var39;
            int var102 = var8;
            boolean var101 = var141;
            boolean var69 = var101;
            boolean var64 = var101;
            if (var102 != 0) {
               boolean var103 = var64;
               if (!var103) {
                  return;
               }

               int var106 = var8;
               BlockPos var105 = var12;
               ArrayList var104 = this.s;
               var70 = var104;
               var71 = var105;
               ArrayList var65 = var104;
               BlockPos var66 = var105;
               if (var106 == 0) {
                  break label75;
               }

               BlockPos var108 = var66;
               ArrayList var107 = var65;
               ArrayList var67 = var107;
               BlockPos var68 = var108;
               BlockPos var43 = var68;
               ArrayList var42 = var67;
               boolean var109 = var42.contains(var43);
               var69 = var109;
            }

            boolean var110 = var69;
            if (var110) {
               return;
            }

            ArrayList var142 = this.s;
            BlockHitResult var45 = var11;
            var71 = var45.getBlockPos();
            var70 = var142;
         }

         ArrayList var91;
         BlockPos var92;
         label50: {
            ArrayList var87;
            label49: {
               int var113 = var8;
               BlockPos var112 = var71;
               ArrayList var111 = var70;
               ArrayList var88 = var111;
               BlockPos var89 = var112;
               ArrayList var72 = var111;
               BlockPos var73 = var112;
               if (var113 != 0) {
                  Object[] var46 = new Object[]{var73, Blocks.RESPAWN_ANCHOR, 90720632922225L};
                  boolean var115 = BlockUtil.bReturningBoolean(var46);
                  ArrayList var114 = var72;
                  var87 = var114;
                  ArrayList var74 = var114;
                  if (var115) {
                     break label49;
                  }

                  ArrayList var116 = var74;
                  ArrayList var75 = var116;
                  BlockHitResult var48 = var11;
                  BlockPos var145 = var48.getBlockPos();
                  int var119 = var8;
                  BlockPos var118 = var145;
                  ArrayList var117 = var75;
                  var88 = var117;
                  var89 = var118;
                  ArrayList var76 = var117;
                  BlockPos var77 = var118;
                  if (var119 != 0) {
                     BlockPos var121 = var77;
                     ArrayList var120 = var76;
                     ArrayList var78 = var120;
                     BlockPos var79 = var121;
                     Object[] var50 = new Object[]{var79, Blocks.FIRE, 90720632922225L};
                     boolean var123 = BlockUtil.bReturningBoolean(var50);
                     ArrayList var122 = var78;
                     var87 = var122;
                     ArrayList var80 = var122;
                     if (var123) {
                        break label49;
                     }

                     ArrayList var124 = var80;
                     ArrayList var81 = var124;
                     BlockHitResult var52 = var11;
                     BlockPos var146 = var52.getBlockPos();
                     int var127 = var8;
                     BlockPos var126 = var146;
                     ArrayList var125 = var81;
                     var88 = var125;
                     var89 = var126;
                     ArrayList var82 = var125;
                     BlockPos var83 = var126;
                     if (var127 != 0) {
                        BlockPos var129 = var83;
                        ArrayList var128 = var82;
                        ArrayList var84 = var128;
                        BlockPos var85 = var129;
                        Object[] var54 = new Object[]{82650215142853L};
                        Object[] var55 = new Object[]{var85, BlockUtil.aReturningBlock(var54), 90720632922225L};
                        boolean var131 = BlockUtil.bReturningBoolean(var55);
                        ArrayList var130 = var84;
                        ArrayList var90 = var130;
                        ArrayList var86 = var130;
                        if (!var131) {
                           var92 = var12;
                           var91 = var90;
                           break label50;
                        }

                        ArrayList var132 = var86;
                        var87 = var132;
                        break label49;
                     }
                  }
               }

               BlockPos var136 = var89;
               ArrayList var135 = var88;
               var91 = var135;
               var92 = var136;
               break label50;
            }

            BlockHitResult var57 = var11;
            BlockPos var134 = var57.getBlockPos();
            ArrayList var133 = var87;
            var91 = var133;
            var92 = var134;
         }

         BlockPos var60 = var92;
         ArrayList var59 = var91;
         var59.add(var60);
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.cReturningInt();
      Object[] var8 = new Object[0];
      PacketReceiveEvent var7 = var1;
      Packet var6 = var7.aReturningVoid(var8);
      int var4 = var10000;
      int var28 = var4;
      Packet var27 = var6;
      Packet var24 = var27;
      Packet var23 = var27;
      if (var28 != 0) {
         boolean var29 = var23 instanceof BlockUpdateS2CPacket;
         if (!var29) {
            return;
         }

         Packet var30 = var6;
         var24 = var30;
      }

      BlockUpdateS2CPacket var5 = (BlockUpdateS2CPacket)var24;
      BlockUpdateS2CPacket var11 = var5;
      BlockState var37 = var11.getState();
      int var32 = var4;
      BlockState var31 = var37;
      BlockState var26 = var31;
      BlockState var25 = var31;
      if (var32 != 0) {
         BlockState var33 = var25;
         if (var33 == null) {
            return;
         }

         BlockUpdateS2CPacket var13 = var5;
         BlockState var34 = var13.getState();
         var26 = var34;
      }

      BlockState var15 = var26;
      Block var38 = var15.getBlock();
      Block var36 = Blocks.RESPAWN_ANCHOR;
      Block var35 = var38;
      if (var35 != var36) {
         ArrayList var39 = this.t;
         BlockUpdateS2CPacket var17 = var5;
         BlockPos var19 = var17.getPos();
         ArrayList var18 = var39;
         var18.remove(var19);
         ArrayList var40 = this.s;
         BlockUpdateS2CPacket var20 = var5;
         BlockPos var22 = var20.getPos();
         ArrayList var21 = var40;
         var21.remove(var22);
      }
   }

   private static boolean lambda$onTick$9(BlockPos var0) {
      MinecraftClient var3 = b;
      BlockPos var5 = var0;
      ClientWorld var4 = var3.world;
      BlockState var6 = var4.getBlockState(var5);
      Block var10000 = var6.getBlock();
      Block var9 = Blocks.RESPAWN_ANCHOR;
      Block var8 = var10000;
      byte var7;
      if (var8 != var9) {
         byte var10 = 1;
         var7 = var10;
      } else {
         var7 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private boolean lambda$new$8(Boolean var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.l;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.m;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$7(Integer var1) {
      BooleanSetting var4 = this.l;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$6(String var1) {
      BooleanSetting var4 = this.l;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$5(Boolean var1) {
      BooleanSetting var4 = this.h;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$4(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.h;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.i;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$3(String var1) {
      BooleanSetting var4 = this.h;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.c;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.e;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$1(String var1) {
      BooleanSetting var4 = this.c;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Integer var1) {
      BooleanSetting var4 = this.c;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(105461908071848L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[7];
      String var6 = "\u0007dy\u0018\u0088ßï*\u007fÚ{Ê\u0007yÍù(Õ±C\u009d8a\u0007\u008a\u0014\u00ad\"ém\u0005½\u0091\u008e Ï`Ü\b\u0089û\u0010÷!\u0084\u0087ê#\r9\u0003\u0002P´\u001fO3\u0010D4Ê,k/Æ\u0010\u009d\u0010_\u0004\u0006\u0089<i\u00100\u0016(Æ+»>æd¦F\u001eæØÝa\u0010\u0092\u0017 D4\u009dZ\u0085¶ØOÖÐì\u000e¸";
      int var8 = "\u0007dy\u0018\u0088ßï*\u007fÚ{Ê\u0007yÍù(Õ±C\u009d8a\u0007\u008a\u0014\u00ad\"ém\u0005½\u0091\u008e Ï`Ü\b\u0089û\u0010÷!\u0084\u0087ê#\r9\u0003\u0002P´\u001fO3\u0010D4Ê,k/Æ\u0010\u009d\u0010_\u0004\u0006\u0089<i\u00100\u0016(Æ+»>æd¦F\u001eæØÝa\u0010\u0092\u0017 D4\u009dZ\u0085¶ØOÖÐì\u000e¸"
         .length();
      char var5 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     y = var9;
                     z = new String[7];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "\u0003«\u0089úòP²1\u000få¸\u001a;^ÎÜ\u0010¢\u0090\u008br\u008a]òP\u0097 Ò\b\f½\u001c\u009c";
                  var8 = "\u0003«\u0089úòP²1\u000få¸\u001a;^ÎÜ\u0010¢\u0090\u008br\u008a]òP\u0097 Ò\b\f½\u001c\u009c".length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25;
      if (z[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])A.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               A.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dU", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = y[var5].getBytes("ISO-8859-1");
         z[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return z[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dU_C0203",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = C[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = B[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 25;
            yield var15;
         }
         case 1 -> {
            byte var16 = 39;
            yield var16;
         }
         case 2 -> {
            byte var17 = 57;
            yield var17;
         }
         case 3 -> {
            byte var18 = 11;
            yield var18;
         }
         case 4 -> {
            byte var19 = 51;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 42;
            yield var21;
         }
         case 7 -> {
            byte var22 = 37;
            yield var22;
         }
         case 8 -> {
            byte var23 = 27;
            yield var23;
         }
         case 9 -> {
            byte var24 = 62;
            yield var24;
         }
         case 10 -> {
            byte var25 = 22;
            yield var25;
         }
         case 11 -> {
            byte var26 = 14;
            yield var26;
         }
         case 12 -> {
            byte var27 = 36;
            yield var27;
         }
         case 13 -> {
            byte var28 = 16;
            yield var28;
         }
         case 14 -> {
            byte var29 = 54;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 40;
            yield var31;
         }
         case 17 -> {
            byte var32 = 47;
            yield var32;
         }
         case 18 -> {
            byte var33 = 9;
            yield var33;
         }
         case 19 -> {
            byte var34 = 49;
            yield var34;
         }
         case 20 -> {
            byte var35 = 21;
            yield var35;
         }
         case 21 -> {
            byte var36 = 26;
            yield var36;
         }
         case 22 -> {
            byte var37 = 15;
            yield var37;
         }
         case 23 -> {
            byte var38 = 45;
            yield var38;
         }
         case 24 -> {
            byte var39 = 23;
            yield var39;
         }
         case 25 -> {
            byte var40 = 5;
            yield var40;
         }
         case 26 -> {
            byte var41 = 8;
            yield var41;
         }
         case 27 -> {
            byte var42 = 50;
            yield var42;
         }
         case 28 -> {
            byte var43 = 12;
            yield var43;
         }
         case 29 -> {
            byte var44 = 1;
            yield var44;
         }
         case 30 -> {
            byte var45 = 43;
            yield var45;
         }
         case 31 -> {
            byte var46 = 59;
            yield var46;
         }
         case 32 -> {
            byte var47 = 29;
            yield var47;
         }
         case 33 -> {
            byte var48 = 24;
            yield var48;
         }
         case 34 -> {
            byte var49 = 48;
            yield var49;
         }
         case 35 -> {
            byte var50 = 35;
            yield var50;
         }
         case 36 -> {
            byte var51 = 60;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 17;
            yield var53;
         }
         case 39 -> {
            byte var54 = 18;
            yield var54;
         }
         case 40 -> {
            byte var55 = 61;
            yield var55;
         }
         case 41 -> {
            byte var56 = 56;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 53;
            yield var58;
         }
         case 44 -> {
            byte var59 = 32;
            yield var59;
         }
         case 45 -> {
            byte var60 = 30;
            yield var60;
         }
         case 46 -> {
            byte var61 = 33;
            yield var61;
         }
         case 47 -> {
            byte var62 = 28;
            yield var62;
         }
         case 48 -> {
            byte var63 = 46;
            yield var63;
         }
         case 49 -> {
            byte var64 = 0;
            yield var64;
         }
         case 50 -> {
            byte var65 = 38;
            yield var65;
         }
         case 51 -> {
            byte var66 = 31;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 13;
            yield var68;
         }
         case 54 -> {
            byte var69 = 58;
            yield var69;
         }
         case 55 -> {
            byte var70 = 34;
            yield var70;
         }
         case 56 -> {
            byte var71 = 19;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 4;
            yield var73;
         }
         case 59 -> {
            byte var74 = 20;
            yield var74;
         }
         case 60 -> {
            byte var75 = 7;
            yield var75;
         }
         case 61 -> {
            byte var76 = 55;
            yield var76;
         }
         case 62 -> {
            byte var77 = 3;
            yield var77;
         }
         default -> 6;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            C[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      B[0] = "\u001f\u0000M<_A\u0014\u000f\\s\"Y\u0007\bU:";
      B[1] = "*<\\eXD!3M*9J*8Ip";
      B[2] = boolean.class;
      C[2] = "java/lang/Boolean";
      B[3] = "\u0012\b5\u0019N$\u0004\b0C]3\u0013C3EQ'\u0002\u0004$R\u001a53";
      B[4] = int.class;
      C[4] = "java/lang/Integer";
      B[5] = "v']f,#v'J: ,llJ$ 9k\u001d\u001bzu|";
      B[6] = "Z\u001a\u000e)U^Z\u001a\u0019uYQ@Q\u0019kYDG H5\f\u000f";
      B[7] = "\u001dVJ!\u0007z\u000bVO{\u0014m\u001c\u001dL}\u0018y\rZ[jSi\u0016";
      B[8] = "nG\u000e\u0015,\u0005\u001bg\u0005\u001a=Jzi\u000e\u00119\u0010\u000e";
      B[9] = void.class;
      C[9] = "java/lang/Void";
      B[10] = "Q\bQN\b\u0015Q\bF\u0012\u0004\u001aKCF\f\u0004\u000fL2\u0012TS";
      B[11] = "4\u0013mGpR*\u001bw\b\u001fU,\u0013bj7T*";
      B[12] = "]_H01mVPY\u007f]nXR[0q";
      B[13] = "V7CcqaV7T?}nL|T!}{K\r\u0004|,";
      B[14] = "a\u001f\bL-%a\u001f\u001f\u0010!*{T\u001f\u000e!?|%NQy";
      B[15] = "/-}R\nC9-x\b\u0019T.f{\u000e\u0015@?!l\u0019^W\r";
      B[16] = "YN\u0018\r\u000bQRA\tBlSGJ\t\tW";
      B[17] = "q^\u0005\tR#g^\u0000SA4p\u0015\u0003UM aR\u0014B\u00062y";
      B[18] = "!!/}iTT\u0001$rx\u001b5\u000f/y|AA";
      B[19] = "]\u0003m\\uJ(#fSd\u0005I-mX`_=";
      B[20] = "\u001cvE\u0010$\"\u001cvRL(-\u0006=RR(8\u0001L\u0002\u0007\u007f~";
      B[21] = "\u001dw9,\u00073\u001dw.p\u000b<\u0007<.n\u000b)\u0000M\u007f1Yb";
      B[22] = "\u0016\u001b@f&C\u0000\u001bE<5T\u0017PF:9@\u0006\u0017Q-rP\u001e";
      B[23] = "\u00026HN\u0011Kw\u0016CA\u0000\u0004\u0016\u0018HJ\u0004^b";
      B[24] = "7?M\u0010\u0005\u001bB\u001fF\u001f\u0014T#\u0011M\u0014\u0010\u000eW";
      B[25] = "\u0000(\u001c|Tu\u0016(\u0019&Gb\u0001c\u001a Kv\u0010$\r7\u0000a1";
      B[26] = "h';3B\\c(*|!Qv%%\u0017\u0014Sg69;\u0003^";
      B[27] = ":9]\u001fEZ,9XEVM;r[CZY*5LT\u0011N\u0016";
      B[28] = "\u0019\u000e#[\u0007yl.(T\u00166\r #_\u0012ly";
      B[29] = "K\u0017( !\u0016]\u0017-z2\u0001J\\.|>\u0015[\u001b9ku\u0002h";
      B[30] = "\u0013H\u007f?Q<fht0@s\u0007f\u007f;D)s";
      B[31] = "}\u00079\u00100Ek\u0007<J#R|L?L/Fm\u000b([dQR";
      B[32] = "xam\u0015\u0000o\rAf\u001a\u0011 lOm\u0011\u0015z\u0018";
      B[33] = "#\b-\u001dex5\b(Gvo\"C+Az{3\u0004<V1l\n";
      B[34] = "Y.Ii@o,\u000eBfQ M\u0000ImUz9";
      B[35] = "\u0014\u0018\"\u0000\u001d]\u0014\u00185\\\u0011R\u000eS5B\u0011G\t\"d\u001dE\u0004";
      B[36] = "XQ\u0002Y\u0014NNQ\u0007\u0003\u0007YY\u001a\u0004\u0005\u000bMH]\u0013\u0012@\\\u0005";
      B[37] = ";o\u0018\n nNO\u0013\u00051!/A\u0018\u000e5{[";
      B[38] = "tZHSDm\u0001zC\\U\"`tHWQx\u0014";
      B[39] = "/\u0011\u001b\u001aH\u0016Z1\u0010\u0015YY;?\u001b\u001e]\u0003O";
      B[40] = "7e&>fPBE-1w\u001f#K&:sEW";
      B[41] = "W^\u0001\\B\tW^\u0016\u0000N\u0006M\u0015\u0016\u001eN\u0013JdDJ\u001fR";
      B[42] = "7.E\u000fs[7.RS\u007fT-eRM\u007fA*\u0014\u0000\u0016'\u0000";
      B[43] = "DF7Q\u000f^1f<^\u001e\u0011Ph7U\u001aK$";
      B[44] = "h(\"\u0015\u0002A\u001d\b)\u001a\u0013\u000e|\u0006\"\u0011\u0017T\b";
      B[45] = "9hN3&VLHE<7\u0019-FN73CY";
      B[46] = "rn\u0019\u007f07lf\u00030M'l";
      B[47] = "!.5\u0004l4!.\"X`;;e\"F`.<\u0014s\u001c3k";
      B[48] = "k\u001f'}Tnk\u001f0!XaqT0?Xtv%ae\u00017";
      B[49] = "\u007f]\u0016nm.i]\u00134~9~\u0016\u00102r-oQ\u0007%9<\u007f";
      B[50] = "lA\u001b\u0014/^\u0019a\u0010\u001b>\u0011xo\u001b\u0010:K\f";
      B[51] = "_^`V\u007f$_^w\ns+E\u0015w\u0014s>Bd&M+{";
      B[52] = "::FU\"^::Q\t.Q qQ\u0017.D'\u0000\u0004Hw";
      B[53] = ";HL\u000f|\u000b;H[Sp\u0004!\u0003[Mp\u0011&r\t\u0016([";
      B[54] = "\fg\r'Go\fg\u001a{K`\u0016,\u001aeKu\u0011]K1\u00123";
      B[55] = "w\u001e*ae+a\u001e/;v<vU,=z(g\u0012;*19v";
      B[56] = "lATUKc\u0019a_ZZ,xoTQ^v\f";
      B[57] = "Mw<@}fMw+\u001cqiW<+\u0002q|PMy\\&7";
      B[58] = "\u000e1_1\u000e-\u00181Zk\u001d:\u000fzYm\u0011.\u001e=NzZ9&";
      B[59] = "f%13.W\u0013\u0005:<?\u0018r\u000b17;B\u0006";
      B[60] = "\u0004%Fnjmq\u0005Ma{\"\u0010\u000bFj\u007fxd";
      B[61] = "`\u0018<P\u001f\r`\u0018+\f\u0013\u0002zS+\u0012\u0013\u0017}\"|ME";
      B[62] = "%=,XS)P\u001d'WBf1\u0013,\\F<E";
      B[63] = "'m&pkG1m#*xP&& ,tD7a7;?Q\u001a";
      B[64] = "f?*\u0005g;\u0013\u001f!\nvtr\u0011*\u0001r.\u0006";
      B[65] = "e;\":t\u0018\u0010\u001b)5eWq\u0015\">a\r\u0005";
      B[66] = "MGI\u0006wW[GL\\d@L\fOZhT]KXM#CP";
      B[67] = "|&v>QM\t\u0006}1@\u0002h\bv:DX\u001c";
      B[68] = "vS@;H\u000eh[Zt\u0000\u000erQB3\t\u00152bD?\u0002\u0012\u007fSB?";
      B[69] = "/yv\b$\u0018ZY}\u00075W;Wv\f1\rO";
      B[70] = "&>c\u001dcA0>fGpV'ueA|B62rV7R.2p]m\u001f\u0012)p@mX%>";
      B[71] = "Qs\b\u001a_p\u000e#RO[\u0017\u0002OV@\ny\u000e=WJYy\u0001OQHVi\u00115\rSV*h";
      B[72] = "wVd\f\\U.\u0005pvEYi]I\u0011I]\u0012\u0007\u007f\u0015_\fwVb\u0019]0";
      B[73] = "StO\u00173\u0012PzFPX\u00141$\u001c\u00106\u001bC%\u0016C6\u00141\u007f\u001e\u0014c\u0016^|\u0010\u001d$}";
      B[74] = "'[pZd\u00045XlX\u0016_:M}\u0001zmm\u000f'^*:kS|\u0005|\\5Tq^\u0016";
      B[75] = "JtWX\u0004%\t+\u0011Sg%\u001a%\rS0rDuT?^u\u001e(\bUZ-\u0014-\u001b";
      B[76] = "?\u001cU\u001bGP|\u0015\u0014\u001d#E-\u0005K\u001aOwy@\u0010E\u0013 0\u0013FAQ\u001e\"\u0010ZC#";
      B[77] = "'>QFkG}=K\u0000PRu|KX<`%?\u0012\u0002P\u000ey\u007fEF2\u0007ypF?";
      B[78] = "R3,hjA\u0011ljc\tJ\u000esrhexZ2,>\t\u0016\u0002p|vk\u001f\u0002\u007f\u007f\u000f";
      B[79] = "YiL|\u0005|I:Iw8oU|v.\\s^\u0000\u0012:[t\u000feC'Wv3";
      B[80] = "0_\u0018\u001fjV:W\u000b\u0000\u0016_Z\u0016\u0010SxZ(\u0017\u001a\u0000xUZ\u0016\u001a\u0010xE8\u001f\u001a\u001f{<";
      B[81] = "OZxg\u001dRD\u001d#bg\\)_/d\tS[^%7\t\\)\u0000xdXON\u000b??]5";
      B[82] = "\u0012/wA\u007fEAk5C\u0010\u000f@5)\u0004}u\u0014ip\u001cm\u001cGjp\u0006\u0010LL/ \u0003rEL #z";
      B[83] = "JA\rIR>\u0013\u0012\u00193F\"RC\u000fH+b\u0016\u0014\rNB1\u0015\u0014\u00173\u0012:PD\u0012Q\u001b:_Gk";
      B[84] = "\u0012<8esR\u00041<m\u001eJ\u0018/'zrxLk~##/O.$g\"J\u001e3(e\u001e";
      B[85] = "9\u0003)vw7g\u0014/(I%YB!('!+C+{'.YE)t7>#\u00192ttG";
      B[86] = "Bdrc\u0011\u001a\u0001;4hr\u001a\u00125(h%MLfq\u0004\u001bIH#0z\u0011\u001b\u000e%";
      B[87] = "8\tM!8C4\rX3J\u0015[IOs$\u001a)HE $\u0015[\u0013]&$\u000ed\u001fY36|";
      B[88] = "4f\u0005\u000193w9C\nZ3d7_\n\rd;j\u0004fce91Z\u001dg!51\u0003";
      B[89] = "\u0000\u000fV\u0003K2Z\fLEp'RML\u001d\u001c\u0015\u0001\t\u0013Kp{\u0006\t]\u001b\u001d?A\rH\u0000p";
      B[90] = "`j(4A]d,xf_b77{:J5df.n&[eh|9\u0019_#8.'";
      B[91] = "\bZM\u0013EJ\bMS\u0004yFf\u0019AR\u0017I\u0014\u0018K\u0001\u0017Ff\u0019K\u0011\u0017V\u0004\u0010K\u001e\u0014/";
      B[92] = "c\u0018[N\u001fW#\u0014C\r'Q_SS\u0000IV-RYSIY_SYCII=ZYLJ0";
      B[93] = "'oS=1`}lI{\nuu-I#fG&h\u0010y\n)y.G=h y!DD";
      B[94] = "k\u0019|BOw.I+\u0007-aQ\u00180ZW74I-VU\u000b";
      B[95] = "-^O_\u0007,i\u0019KJ\u001cAq\n\u000bN\u0001-CXF\u0016WAh\u001c\u0018GYp)^\fCf";
      B[96] = ".eVD\"Uhq\u0015_F\u000btp\u000eP\u0011_.$W\u0006FYw|\tV \u0007pqR";
      B[97] = "HAs\t$-\bMkJ\u001c#t\n{Gr,\u0006\u000bq\u0014r#t\rs\u001bb3\u000eQh\u001b!J";
      B[98] = "\u0011\u000bN?D!\u001e\nG'9\u007f\u0001{\u0015w\u0007~\u0012\u0012Ft\u0007do\u0005\\,HeV\n]%P\u0018";
      B[99] = "(G\bk/\u0010vP\u000e5\u0011\fH\u0006\u00005\u007f\u0006:\u0007\nf\u007f\tH\u0006\nv\u007f\u0019*\u000f\ny|`";
      B[100] = "#\u0002y`\u001b\u001bs\u0004|+}\ft\u001f`}\u0014\u0000M\u0011`m\u0010f*\u0019{~\u0004\u0004#\u0019t}}";
      B[101] = "0\u0006\u007fnV?uV(+4(\n\u00073vN\u007foV.zLC";
      B[102] = "L\u0016\\S'-M\u001a\u001c\n&G\u001f&T\u0007{)\u0013TU\r()\u001c&T\r8)\fD]\r7*u";
      B[103] = "\u001bP$r\u0005[\u0003[ct<Hr\u000f$vZ\\\u001b\\'v@!";
      B[104] = "sMx\u0011\u0017\u0010;\u001fi\u0019\u001f{$$+\u0014\u0012\u0015,V*\u001eA\u0015#$+\u001eQ\u00153F\"\u001e^\u0016J";
      B[105] = "\u0011\u000etC>0BJ6AQzC\u0014*\u0006<A@qt\u0012?~I\n!\u00154kAqt\u0019.nW\u0013}\u0019!m.";
      B[106] = "\u007f\u0001aeS$<^'n0$/P;ngsq\u0007c\u0002\u000ft4DdrUw.\u0002";
      B[107] = "p\u0004Bc:\u0019y^\u0016u4r,S\u0006\u007f9\u001e\u001e\u0007@\"bIIS\u0011'!J _Aq2r";
      B[108] = "5,yq{\u00164 9(z|e\u001cq%'\u0012jnp/t\u0012e\u001cv-{\u0002uf*6{A\f";
      B[109] = "g\u0011;T\u0005q!\u0005xOa/=\u0004c@6xdP8\u0015a}>\bdF\u0007#9\u0005?";
      B[110] = "=5-|6P+8)t[H7&2c7zcbk8k-`'1~gH1:=|[";
      B[111] = "E<e#`.\u0001me%%G\u001bW-)t)E<e{e!M";
      B[112] = "[<U\rj)\u001b0MNR'gw]C<(\u0015vW\u0010<'gtK\u001c(r\u0002%V\u0010*N";
      B[113] = "z`\u007foL&v0)|t*zw'w\u0018\u0018.4x/KOy7}v\f&,k8ut";
      B[114] = "^T6\u0017A1T\\%\b=24\u001d>[S=F\u001c4\bS24\u001e(\u0004GgQO5\bE[";
      B[115] = "s\"-.A'wf!.\u0018\\/wm%G0\u001d**\u007f\u0018\\$&+#X5qzn  , w-7\u001e>#k/E";
      B[116] = "XO\u001elVhZ\u000eX,ET\bu\u001a\u007f\u0003:\u0007\u0007\u001buP:\buQtDe\u0011LQi\u000eda";
      B[117] = "82\u0013Z\u0015B{;R\\qW*+\r[\u001de~nV\u0004@2)kWZ\t[|7\u0012Yq";
      B[118] = "\u001d\u0013^[3k\u000eNL\u0012\u000f!eFU\u0016a<\u0017G_Ea3eA]Jq#\u001f\u001dFJ2Z";
      B[119] = "&vp%\u0012ufzhf*v\u001a=xkDth<r8D{\u001a=r(Dkx4r'G\u0012";
      B[120] = "%78f_\u0004/?+y#\u0004O~0*M\b=\u007f:yM\u0007O~:iM\u0017-w:fNn";
      B[121] = "<\u0003\u0001H\"rf\u0000\u001b\u000e\u0019gnA\u001bVuU=\u0005G\u000e\u0019;:\u0005\nPt\u007f}\u0001\u001fK\u0019";
      B[122] = "7/t\u0012-\u0017='g\rQ\u0011]f|^?\u001b/gv\r?\u0014]fv\u001d?\u0004?ov\u0012<}";
      B[123] = "\u0000C&\u0006\u001fES\u0007d\u0004p\u001eXZcT\u0011\u0013D<&\u0004N\u0013BUu\u0007N\t?\u0005~B\u001e\f]\f~M\u001du";
      B[124] = "0xGkYl;4F}!~*iCmv*p=\u001b8!l0kN>\u0010-r\u007fJ";
      B[125] = "\u0011\n7\u00039sBNu\u0001V*B\u0019\u000e\u0001o}H\bgRl}Ru7Y)-W\u0017>Y&..";
      B[126] = "m\t+m;\u001edS\u007f{5u1^oq8\u0019\u0003\n),cKT\n
      B[127] = "n\u0002{w\u001f\u00070\u0015})!\u001a\u000eCs)O\u0011|ByzO\u001e\u000eCyjO\u000elJyeLw";
      B[128] = "LH\u0001 I XOF%\"-)LRcL\"[MX0L-)\u0010\u0004g]/M\u0004\u0003 XD";
      B[129] = "nbw\u001d\u001d\u0017=&5\u001frL5p'\\r\u00192}0_\bE)}s&";
      B[130] = "e\fF<=|s\u0001B4Pdo\u001fY#<V;[\u0000zl\u00018\u001eZ>ldi\u0003V<P";
      B[131] = " y5D~P m8\u001dD_Q/5B*P#.?\u0011*_Qd>\u0005uFhd#Ot6";
      B[132] = "\u0005b\u00063^#\u000e.\u0007%&1\u001fs\u00025qoN&_YZ$\u0011wYh\u001bf\u0005s";
      B[133] = "n\u0014qT]H(\u00002O9\u00164\u0001)@nAmTv\u00129D7\r.F_\u001a0\u0000u";
      B[134] = "\u0001\u0003%\u0014\u001f\u0000\u0005EuF\u0001?UFf\u0017\u001cD8\u0006\"@\u001eBQU!@\u0004?\u0001^d\u0010\u0001]\b^k\u0013x";
      B[135] = "E\u0017svh\f\u001b\u0000u(V\u0015%\u000eqxj\fG\u000f.%o|D\u000e|(&\u001eEQ!-V";
      B[136] = "54\u0003\u001crB?<\u0010\u0003\u000eA_}\u000bP`N-|\u0001\u0003`A_x\u0002\rmB9&\u0005\u00006(";
      B[137] = "d\u0000:\u0019h\u00151\\\u007f\u001a\u0010\u0019g@`\u0018|+3\u00048A!|0Ac\u0005,\u0019a\\o\u0007\u0010Fw_zCu\u0017jSx\u007f*\u0001iF<\u001a{\u001ceD\u0000\u0011,FlDiDp\u0003o<";
      B[138] = "1G\u000eO\u001e>=\u0017X\\&21PVWJ\u0000e\u0013\t\u0000\u001eW;CIHK*-NM@&";
      B[139] = "\u007f\u0012:|x\u000bs\u0016/n\n_\u001cR8.dRnS2}d]\u001cR2mdM~[2bg4";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = B[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(C[var4]);
            B[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = B[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            B[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  B[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(104903148851669L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = B[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  B[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(104903148851669L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        B[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(104903148851669L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 88;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 164;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 70;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 255;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 112;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 201;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 88;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 164;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 70;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dU_C0203",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AnchorMacro var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$7", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AnchorMacro var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$8", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AnchorMacro var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$3", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AnchorMacro var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AnchorMacro var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$4", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AnchorMacro var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$6", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AnchorMacro var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$0", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AnchorMacro var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(AnchorMacro var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dU_C0203;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dU_C0203", "lambda$new$1", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AnchorMacro)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10() {
         MethodHandle var4 = bindingCache10;
         MethodHandle var3 = bindingCache10;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dU_C0203", "lambda$onTick$9", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
