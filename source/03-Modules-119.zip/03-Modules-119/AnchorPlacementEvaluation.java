package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record AnchorPlacementEvaluation(BlockPos h, BlockPos i, Vec3d j, boolean k, int l, double m, boolean n, boolean o, int p, double q, double r, double s) {

    public final double recoveryAccess_read_s() { return this.s; }

    public final int recoveryAccess_read_p() { return this.p; }

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_h() { return this.h; }

    public final boolean recoveryAccess_read_k() { return this.k; }

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_i() { return this.i; }

    public final net.minecraft.util.math.Vec3d recoveryAccess_read_j() { return this.j; }

    public final double recoveryAccess_read_r() { return this.r; }

    public final double recoveryAccess_read_q() { return this.q; }

    public final double recoveryAccess_read_m() { return this.m; }

    public final boolean recoveryAccess_read_n() { return this.n; }

    public final boolean recoveryAccess_read_o() { return this.o; }

    public final int recoveryAccess_read_l() { return this.l; }
}
