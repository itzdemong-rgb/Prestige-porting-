package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record AnchorPlacementPlan(BlockPos a, BlockPos b, Vec3d c, boolean d, BlockPos e, BlockPos f, Vec3d g) {

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_a() { return this.a; }

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_b() { return this.b; }

    public final net.minecraft.util.math.Vec3d recoveryAccess_read_c() { return this.c; }

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_e() { return this.e; }

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_f() { return this.f; }

    public final net.minecraft.util.math.Vec3d recoveryAccess_read_g() { return this.g; }

    public final boolean recoveryAccess_read_d() { return this.d; }
}
