package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record AnchorPlacementPoint(BlockPos t, Vec3d u) {

    public final net.minecraft.util.math.BlockPos recoveryAccess_read_t() { return this.t; }

    public final net.minecraft.util.math.Vec3d recoveryAccess_read_u() { return this.u; }
}
