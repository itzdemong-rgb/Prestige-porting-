package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.util.InteractionUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AnchorPlacer extends Module implements RotationSource {
   private ModeSetting a;
   private MinMaxSetting c;
   private ModeSetting d;
   private BooleanSetting e;
   private BooleanSetting f;
   private FloatSetting g;
   public ArrayList h;
   private ElapsedTimer i;
   private int j;
   private static final long k = 28389521308604L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[165];
   private static final String[] p = new String[165];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public AnchorPlacer() {
      super();
      long var10001 = 1969076024614L ^ 106381671629327L;
      var10001 = 1969076024614L ^ 33795564701681L;
      var10001 = 1969076024614L ^ 89108735786634L;

      this.h = new ArrayList();
      this.i = new ElapsedTimer(106698256430889L);
      this.j = -1;
      FloatSetting var10000 = this.g;
      Object[] var10 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var9 = var10000;
      var9.aReturningFloatSetting(var10);
      BooleanSetting var13 = this.e;
      Object[] var12 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var11 = var13;
      var11.aReturningBooleanSetting(var12);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      short var10000 = 29857;
      long var2 = (Long)var1[0];
      long var10001 = 7767591622362823663L ^ var2;
      ModeSetting var4 = this.a;
      Object var6 = var4.aReturningObject();
      String var5 = "Persistent";
      return var5.equals(var6);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      ArrayList var4 = this.h;
      var4.clear();
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.bReturningInt();
      Object[] var8 = new Object[0];
      PacketReceiveEvent var7 = var1;
      Packet var6 = var7.aReturningVoid(var8);
      int var4 = var10000;
      int var24 = var4;
      Packet var23 = var6;
      Packet var20 = var23;
      Packet var19 = var23;
      if (var24 == 0) {
         boolean var25 = var19 instanceof BlockUpdateS2CPacket;
         if (!var25) {
            return;
         }

         Packet var26 = var6;
         var20 = var26;
      }

      BlockUpdateS2CPacket var5 = (BlockUpdateS2CPacket)var20;
      BlockUpdateS2CPacket var11 = var5;
      BlockState var33 = var11.getState();
      int var28 = var4;
      BlockState var27 = var33;
      BlockState var22 = var27;
      BlockState var21 = var27;
      if (var28 == 0) {
         BlockState var29 = var21;
         if (var29 == null) {
            return;
         }

         BlockUpdateS2CPacket var13 = var5;
         BlockState var30 = var13.getState();
         var22 = var30;
      }

      BlockState var15 = var22;
      Block var34 = var15.getBlock();
      Block var32 = Blocks.RESPAWN_ANCHOR;
      Block var31 = var34;
      if (var31 != var32) {
         ArrayList var35 = this.h;
         BlockUpdateS2CPacket var16 = var5;
         BlockPos var18 = var16.getPos();
         ArrayList var17 = var35;
         var17.remove(var18);
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      this.j = -1;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      ArrayList var6 = this.h;
      var6.clear();
      this.j = -1;
      RotationManager var10000 = Prestige.o;
      Object[] var8 = new Object[]{this, var4};
      RotationManager var7 = var10000;
      var7.eReturningVoid(var8);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 28389521308604L ^ var2;
      long var4 = var2 ^ 93816419617026L;
      int var6 = Event.cReturningInt();
      int var17 = var6;
      AnchorPlacer var16 = this;
      AnchorPlacer var15 = var16;
      AnchorPlacer var14 = var16;
      if (var17 != 0) {
         ModeSetting var7 = var14.a;
         String var10000 = (String)var7.aReturningObject();
         short var10001 = 21310;
         long var10002 = 8299666518579758871L ^ var2;
         String var9 = "One-Shot";
         String var8 = var10000;
         boolean var18 = var8.equals(var9);
         if (!var18) {
            return;
         }

         AnchorPlacer var19 = this;
         var15 = var19;
      }

      Object[] var13 = new Object[]{var4};
      AnchorPlacer var12 = var15;
      var12.aReturningVoid(var13);
   }

   @EventListener
   public void a(TickEvent var1) {
      int var198;

      long var10001 = 87202252032960L ^ 14002028557329L;
      var10001 = 87202252032960L ^ 124320521388326L;
      var10001 = 87202252032960L ^ 28050644241122L;
      var10001 = 87202252032960L ^ 32769800989617L;
      var10001 = 87202252032960L ^ 18119127806115L;
      var10001 = 87202252032960L ^ 16197224255158L;
      var10001 = 87202252032960L ^ 52304321293803L;
      var10001 = 87202252032960L ^ 136410397551309L;
      var10001 = 87202252032960L ^ 132572816846969L;
      var10001 = 87202252032960L ^ 61983898816955L;
      int var24 = Event.bReturningInt();
      int var131 = var24;
      MinecraftClient var130 = b;
      MinecraftClient var95 = var130;
      MinecraftClient var94 = var130;
      if (var131 == 0) {
         MinecraftClient var28 = var94;
         Screen var132 = var28.currentScreen;
         if (var132 != null) {
            return;
         }

         MinecraftClient var133 = b;
         var95 = var133;
      }

      MinecraftClient var31 = var95;
      int var10000 = (((var31.isWindowFocused()) ? 1 : 0));
      int var135 = var24;
      byte var134 = (byte)var10000;
      byte var97 = var134;
      byte var96 = var134;
      if (var135 == 0) {
         byte var136 = var96;
         if (var136 == 0) {
            return;
         }

         MinecraftClient var33 = b;
         ClientPlayerEntity var34 = var33.player;
         byte var137 = ((byte)((var34.isUsingItem()) ? 1 : 0));
         var97 = var137;
      }

      int var139 = var24;
      byte var138 = var97;
      byte var99 = var138;
      byte var98 = var138;
      if (var139 == 0) {
         byte var140 = var98;
         if (var140 != 0) {
            return;
         }

         RotationManager var199 = Prestige.o;
         Object[] var38 = new Object[0];
         RotationManager var37 = var199;
         var99 = ((byte)((var37.fReturningBoolean(var38)) ? 1 : 0));
      }

      int var142 = var24;
      byte var141 = var99;
      byte var101 = var141;
      byte var100 = var141;
      if (var142 == 0) {
         byte var143 = var100;
         if (var143 != 0) {
            return;
         }

         var101 = ((byte)((AutoObbyCrystal.R) ? 1 : 0));
      }

      int var145 = var24;
      byte var144 = var101;
      byte var103 = var144;
      byte var102 = var144;
      if (var145 == 0) {
         byte var146 = var102;
         if (var146 != 0) {
            return;
         }

         ElapsedTimer var200 = this.i;
         Object[] var42 = new Object[]{this.c, 130913203968635L};
         ElapsedTimer var41 = var200;
         var103 = ((byte)((var41.bReturningBoolean(var42)) ? 1 : 0));
      }

      int var148 = var24;
      byte var147 = var103;
      int var105 = var147;
      byte var104 = var147;
      if (var148 == 0) {
         byte var149 = var104;
         if (var149 == 0) {
            return;
         }

         var105 = this.j;
      }

      int var151 = var24;
      int var150 = var105;
      int var107 = var150;
      int var106 = var150;
      if (var151 == 0) {
         // int var152 = var106;
         if (var152 != var153) {
            var10000 = this.j;
            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var10000;
            Object[] var45 = var10003;
            InventoryUtil.aReturningVoid(var45);
            this.j = -1;
            Object[] var47 = new Object[]{68577671875302L};
            AnchorPlacer var46 = this;
            var46.jReturningVoid(var47);
            return;
         }

         BooleanSetting var49 = this.f;
         Boolean var50 = (Boolean)var49.aReturningObject();
         var107 = ((((java.lang.Boolean)(var50)).booleanValue() ? 1 : 0));
      }

      HitResult var26;
      boolean var115;
      label190: {
         int var154 = var107;
         label163:
         if (var154 != 0) {
            MinecraftClient var51 = b;
            var26 = var51.crosshairTarget;
            int var156 = var24;
            HitResult var155 = var26;
            HitResult var109 = var155;
            HitResult var108 = var155;
            if (var156 == 0) {
               boolean var157 = var108 instanceof BlockHitResult;
               if (!var157) {
                  return;
               }

               HitResult var158 = var26;
               var109 = var158;
            }

            BlockHitResult var25 = (BlockHitResult)var109;
            Object[] var54 = new Object[]{var25, 106503767598635L};
            boolean var201 = BlockUtil.dReturningBoolean(var54);
            int var160 = var24;
            boolean var159 = var201;
            boolean var113 = var159;
            boolean var110 = var159;
            if (var160 == 0) {
               boolean var161 = var110;
               if (var161) {
                  Object[] var56 = new Object[]{var25, 95435648532770L};
                  Object[] var57 = new Object[]{BlockUtil.aReturningBlockPos(var56), 56486840213773L};
                  var201 = BlockUtil.gReturningBoolean(var57);
                  int var163 = var24;
                  boolean var162 = var201;
                  var115 = var162;
                  boolean var111 = var162;
                  if (var163 != 0) {
                     break label190;
                  }

                  boolean var164 = var111;
                  boolean var112 = var164;
                  boolean var165 = var112;
                  if (!var165) {
                     break label163;
                  }
               }

               BlockHitResult var60 = var25;
               Object[] var61 = new Object[]{var60.getBlockPos(), Blocks.RESPAWN_ANCHOR, 90720632922225L};
               boolean var166 = BlockUtil.bReturningBoolean(var61);
               var113 = var166;
            }

            int var168 = var24;
            boolean var167 = var113;
            var115 = var167;
            boolean var114 = var167;
            if (var168 != 0) {
               break label190;
            }

            boolean var169 = var114;
            if (!var169) {
               return;
            }
         }

         MinecraftClient var64 = b;
         var26 = var64.crosshairTarget;
         int var170 = var24;
         if (var170 != 0) {
            return;
         }

         boolean var171 = var26 instanceof BlockHitResult;
         var115 = var171;
      }

      boolean var172 = var115;
      if (var172) {
         BlockHitResult var197 = (BlockHitResult)var26;
         int var173 = var24;
         if (var173 == 0) {
            int var120;
            label137: {
               int var119;
               label136: {
                  label193: {
                     BlockHitResult var69 = var197;
                     Object[] var70 = new Object[]{var69.getBlockPos(), Blocks.RESPAWN_ANCHOR, 90720632922225L};
                     byte var203 = ((byte)((BlockUtil.bReturningBoolean(var70)) ? 1 : 0));
                     int var175 = var24;
                     byte var174 = var203;
                     int var117 = var174;
                     byte var116 = var174;
                     if (var175 == 0) {
                        byte var176 = var116;
                        if (var176 == 0) {
                           break label193;
                        }

                        BlockHitResult var72 = var197;
                        Object[] var73 = new Object[]{var72.getBlockPos(), 61419523816377L};
                        int var177 = BlockUtil.aReturningInt(var73);
                        var117 = var177;
                     }

                     int var179 = var24;
                     int var178 = var117;
                     var119 = var178;
                     int var118 = var178;
                     if (var179 != 0) {
                        break label136;
                     }

                     int var180 = var118;
                     if (var180 == 0) {
                        var119 = 1;
                        break label136;
                     }
                  }

                  var120 = 0;
                  break label137;
               }

               int var181 = var119;
               var120 = var181;
            }

            int var125;
            label124: {
               int var124;
               label123: {
                  label194: {
                     var198 = var120;
                     BlockHitResult var76 = var197;
                     Object[] var77 = new Object[]{var76.getBlockPos(), Blocks.RESPAWN_ANCHOR, 90720632922225L};
                     byte var204 = ((byte)((BlockUtil.bReturningBoolean(var77)) ? 1 : 0));
                     int var183 = var24;
                     byte var182 = var204;
                     int var122 = var182;
                     byte var121 = var182;
                     if (var183 == 0) {
                        byte var184 = var121;
                        if (var184 == 0) {
                           break label194;
                        }

                        BlockHitResult var79 = var197;
                        Object[] var80 = new Object[]{var79.getBlockPos(), 61419523816377L};
                        int var185 = BlockUtil.aReturningInt(var80);
                        var122 = var185;
                     }

                     int var187 = var24;
                     int var186 = var122;
                     var124 = var186;
                     int var123 = var186;
                     if (var187 != 0) {
                        break label123;
                     }

                     int var188 = var123;
                     if (var188 > 0) {
                        var124 = 1;
                        break label123;
                     }
                  }

                  var125 = 0;
                  break label124;
               }

               int var189 = var124;
               var125 = var189;
            }

            int var27 = var125;
            int var191 = var24;
            int var190 = var27;
            int var127 = var190;
            int var126 = var190;
            if (var191 == 0) {
               int var192 = var126;
               if (var192 != 0) {
                  Object[] var85 = new Object[]{var197, 104685187677027L};
                  AnchorPlacer var84 = this;
                  var84.lReturningVoid(var85);
                  return;
               }

               Object[] var87 = new Object[]{var197, 106503767598635L};
               var127 = (((BlockUtil.dReturningBoolean(var87)) ? 1 : 0));
            }

            label110: {
               int var194 = var24;
               int var193 = var127;
               int var129 = var193;
               int var128 = var193;
               if (var194 == 0) {
                  int var195 = var128;
                  if (var195 != 0) {
                     break label110;
                  }

                  var129 = var198;
               }

               int var196 = var129;
               if (var196 == 0) {
                  Object[] var90 = new Object[]{68577671875302L};
                  AnchorPlacer var89 = this;
                  var89.jReturningVoid(var90);
                  return;
               }
            }

            Object[] var10005 = new Object[]{null, null, 74712075059153L};
            var10005[1] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var198));
            var10005[0] = var197;
            Object[] var93 = var10005;
            AnchorPlacer var92 = this;
            var92.mReturningVoid(var93);
            return;
         }
      }

      Object[] var67 = new Object[]{68577671875302L};
      AnchorPlacer var66 = this;
      var66.jReturningVoid(var67);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 75092756173221L;
      long var6 = var2 ^ 117357136374082L;
      long var8 = var2 ^ 121987986589713L;
      long var10 = var2 ^ 101899554442827L;
      long var12 = var2 ^ 4547998816304L;
      long var14 = var2 ^ 59641449638428L;
      long var16 = var2 ^ 82878281429531L;
      long var18 = var2 ^ 87666872358447L;
      long var20 = var2 ^ 29159961624672L;
      long var22 = var2 ^ 68714957681944L;
      long var24 = var2 ^ 77379818547405L;
      long var26 = var2 ^ 16698288195949L;
      long var28 = var2 ^ 101783648619701L;
      int var30 = Event.bReturningInt();
      BooleanSetting var44 = this.f;
      Boolean var45 = (Boolean)var44.aReturningObject();
      boolean var10000 = var45;
      int var167 = var30;
      boolean var166 = var10000;
      boolean var134 = var166;
      boolean var133 = var166;
      if (var167 == 0) {
         boolean var168 = var133;
         if (!var168) {
            return null;
         }

         MinecraftClient var48 = b;
         ClientPlayerEntity var49 = var48.player;
         var134 = var49.isUsingItem();
      }

      int var170 = var30;
      boolean var169 = var134;
      boolean var136 = var169;
      boolean var135 = var169;
      if (var170 == 0) {
         boolean var171 = var135;
         if (var171) {
            return null;
         }

         ElapsedTimer var233 = this.i;
         Object[] var53 = new Object[]{this.c, var16};
         ElapsedTimer var52 = var233;
         var136 = var52.bReturningBoolean(var53);
      }

      int var173 = var30;
      boolean var172 = var136;
      boolean var138 = var172;
      boolean var137 = var172;
      if (var173 == 0) {
         boolean var174 = var137;
         if (!var174) {
            return null;
         }

         RotationManager var234 = Prestige.o;
         Object[] var57 = new Object[0];
         RotationManager var56 = var234;
         var138 = var56.fReturningBoolean(var57);
      }

      boolean var175 = var138;
      if (var175) {
         return null;
      }

      label178: {
         MinecraftClient var59 = b;
         HitResult var32 = var59.crosshairTarget;
         int var177 = var30;
         HitResult var176 = var32;
         HitResult var140 = var176;
         HitResult var139 = var176;
         if (var177 == 0) {
            boolean var178 = var139 instanceof BlockHitResult;
            if (!var178) {
               break label178;
            }

            HitResult var179 = var32;
            var140 = var179;
         }

         boolean var144;
         BlockHitResult var31 = (BlockHitResult)var140;
         Object[] var62 = new Object[]{var31, var10};
         var10000 = BlockUtil.dReturningBoolean(var62);
         int var181 = var30;
         boolean var180 = var10000;
         var144 = var180;
         boolean var141 = var180;
         label165:
         if (var181 == 0) {
            boolean var182 = var141;
            if (var182) {
               Object[] var64 = new Object[]{var31, var6};
               Object[] var65 = new Object[]{BlockUtil.aReturningBlockPos(var64), var26};
               var10000 = BlockUtil.gReturningBoolean(var65);
               int var184 = var30;
               boolean var183 = var10000;
               var144 = var183;
               boolean var142 = var183;
               if (var184 != 0) {
                  break label165;
               }

               boolean var185 = var142;
               boolean var143 = var185;
               boolean var186 = var143;
               if (!var186) {
                  return null;
               }
            }

            BlockHitResult var68 = var31;
            Object[] var69 = new Object[]{var68.getBlockPos(), Blocks.RESPAWN_ANCHOR, var8};
            boolean var187 = BlockUtil.bReturningBoolean(var69);
            var144 = var187;
         }

         boolean var188 = var144;
         if (var188) {
            return null;
         }
      }

      Rotation var228 = null;
      double var229 = Double.MAX_VALUE;
      Object[] var10004 = new Object[]{null, invokeBinding3(), var12};
      var10004[0] = 5;
      Object[] var72 = var10004;
      List var73 = BlockUtil.aReturningList(var72);
      Iterator var34 = var73.iterator();

      Rotation var163;
      label179: {
         boolean var162;
         while (true) {
            Iterator var74 = var34;
            boolean var189 = var74.hasNext();
            if (var189) {
               Iterator var75 = var34;
               BlockPos var35 = (BlockPos)var75.next();
               BlockPos var76 = var35;
               BlockPos var237 = var76.up();
               int var191 = var30;
               BlockPos var190 = var237;
               BlockPos var148 = var190;
               BlockPos var145 = var190;
               if (var191 == 0) {
                  Object[] var77 = new Object[]{var145, var26};
                  var10000 = BlockUtil.gReturningBoolean(var77);
                  int var193 = var30;
                  boolean var192 = var10000;
                  var162 = var192;
                  boolean var146 = var192;
                  if (var193 != 0) {
                     break;
                  }

                  boolean var194 = var146;
                  boolean var147 = var194;
                  boolean var195 = var147;
                  if (var195) {
                     continue;
                  }

                  var148 = var35;
               }

               Object[] var80 = new Object[]{var148, var4};
               Vec3d var36 = InteractionUtil.bReturningVec3d(var80);
               int var197 = var30;
               Vec3d var196 = var36;
               Vec3d var150 = var196;
               Vec3d var149 = var196;
               if (var197 == 0) {
                  Vec3d var198 = var149;
                  if (var198 == null) {
                     continue;
                  }

                  MinecraftClient var82 = b;
                  ClientPlayerEntity var83 = var82.player;
                  var150 = var83.getEyePos();
               }

               Vec3d var85 = var36;
               Vec3d var84 = var150;
               double var248;
               int var199 = (var248 = var84.distanceTo(var85) - 4.4) == 0.0 ? 0 : (var248 < 0.0 ? -1 : 1);
               if (var199 > 0) {
                  continue;
               }

               RotationManager var239 = Prestige.o;
               Object[] var88 = new Object[]{var36, var24};
               RotationManager var87 = var239;
               Rotation var37 = var87.aReturningdx_C0210(var88);
               Object[] var89 = new Object[]{var37, var36, var28};
               var37 = RotationUtil.dReturningdx_C0210(var89);
               Object[] var91 = new Object[0];
               Rotation var90 = var37;
               float var240 = var90.aReturningFloat(var91);
               MinecraftClient var92 = b;
               ClientPlayerEntity var93 = var92.player;
               float var38 = var240 - var93.getYaw();
               Object[] var95 = new Object[0];
               Rotation var94 = var37;
               float var241 = var94.bReturningFloat(var95);
               MinecraftClient var96 = b;
               ClientPlayerEntity var97 = var96.player;
               float var39 = var241 - var97.getPitch();
               float var98 = var38;
               float var242 = Math.abs(var98);
               FloatSetting var99 = this.g;
               Float var100 = (Float)var99.aReturningObject();
               float var249;
               int var200 = (var249 = var242 - var100) == 0.0F ? 0 : (var249 < 0.0F ? -1 : 1);
               if (var200 > 0) {
                  continue;
               }

               Object[] var102 = new Object[]{var37, var14};
               HitResult var40 = RotationUtil.aReturningHitResult(var102);
               int var202 = var30;
               HitResult var201 = var40;
               HitResult var152 = var201;
               HitResult var151 = var201;
               if (var202 == 0) {
                  boolean var203 = var151 instanceof BlockHitResult;
                  if (!var203) {
                     continue;
                  }

                  var152 = var40;
               }

               label142: {
                  BlockHitResult var41 = (BlockHitResult)var152;
                  BlockHitResult var104 = var41;
                  BlockPos var243 = var104.getBlockPos();
                  BlockPos var106 = var35;
                  BlockPos var105 = var243;
                  var10000 = var105.equals(var106);
                  int var205 = var30;
                  boolean var204 = var10000;
                  boolean var154 = var204;
                  boolean var153 = var204;
                  if (var205 == 0) {
                     boolean var206 = var153;
                     if (var206) {
                        break label142;
                     }

                     BlockHitResult var108 = var41;
                     BlockPos var109 = var108.getBlockPos();
                     BlockPos var245 = var109.up();
                     BlockPos var111 = var35;
                     BlockPos var110 = var245;
                     boolean var207 = var110.equals(var111);
                     var154 = var207;
                  }

                  boolean var208 = var154;
                  if (!var208) {
                     continue;
                  }
               }

               label136: {
                  double var113 = var38 * var38 + var39 * var39;
                  double var42 = Math.sqrt(var113);
                  int var211 = var30;
                  double var209 = var42;
                  double var157 = var209;
                  double var155 = var209;
                  if (var211 == 0) {
                     double var250;
                     int var212 = (var250 = var155 - var229) == 0.0 ? 0 : (var250 < 0.0 ? -1 : 1);
                     if (var212 >= 0) {
                        break label136;
                     }

                     double var213 = var42;
                     var157 = var213;
                  }

                  var229 = var157;
                  var228 = var37;
               }

               int var215 = var30;
               if (var215 == 0) {
                  continue;
               }
            }

            int var217 = var30;
            Rotation var216 = var228;
            Rotation var160 = var216;
            Rotation var159 = var216;
            if (var217 == 0) {
               Rotation var218 = var159;
               if (var218 == null) {
                  return null;
               }

               var160 = var228;
            }

            int var220 = var30;
            Rotation var219 = var160;
            var163 = var219;
            Rotation var161 = var219;
            if (var220 != 0) {
               break label179;
            }

            Object[] var120 = new Object[0];
            Rotation var119 = var161;
            boolean var221 = var119.aReturningBoolean(var120);
            var162 = var221;
            break;
         }

         boolean var222 = var162;
         if (var222) {
            return var228;
         }

         var163 = var228;
      }

      Object[] var123 = new Object[]{var163, var14};
      HitResult var230 = RotationUtil.aReturningHitResult(var123);
      int var224 = var30;
      HitResult var223 = var230;
      HitResult var165 = var223;
      HitResult var164 = var223;
      if (var224 == 0) {
         boolean var225 = var164 instanceof BlockHitResult;
         if (!var225) {
            return var228;
         }

         HitResult var226 = var230;
         var165 = var226;
      }

      BlockHitResult var231 = (BlockHitResult)var165;
      int var227 = var30;
      if (var227 == 0) {
         Object[] var128 = new Object[]{var231, var22};
         AnchorPlacer var127 = this;
         var127.kReturningVoid(var128);
         ElapsedTimer var246 = this.i;
         Object[] var130 = new Object[]{var20};
         ElapsedTimer var129 = var246;
         var129.aReturningVoid(var130);
         MinMaxSetting var247 = this.c;
         Object[] var132 = new Object[]{var18};
         MinMaxSetting var131 = var247;
         var131.bReturningVoid(var132);
         return var228;
      } else {
         return var228;
      }
   }

   private void kReturningVoid(Object[] var1) {
      BlockHitResult var4;
      long var5;
      long var7;
      long var9;
      long var11;
      long var13;
      int var15;
      int var44;
      label71: {
         int var43;
         label70: {
            label74: {
               var4 = (BlockHitResult)var1[0];
               long var2 = (Long)var1[1];
               var2 = 28389521308604L ^ var2;
               var5 = var2 ^ 96947121871125L;
               var7 = var2 ^ 80666119767733L;
               var9 = var2 ^ 75775757770151L;
               var11 = var2 ^ 135249984962799L;
               var13 = var2 ^ 48392882707837L;
               var15 = Event.cReturningInt();
               BlockHitResult var18 = var4;
               Object[] var19 = new Object[]{var18.getBlockPos(), Blocks.RESPAWN_ANCHOR, var7};
               byte var10000 = ((byte)((BlockUtil.bReturningBoolean(var19)) ? 1 : 0));
               int var55 = var15;
               byte var54 = var10000;
               int var41 = var54;
               byte var40 = var54;
               if (var55 != 0) {
                  byte var56 = var40;
                  if (var56 == 0) {
                     break label74;
                  }

                  BlockHitResult var21 = var4;
                  Object[] var22 = new Object[]{var21.getBlockPos(), var13};
                  int var57 = BlockUtil.aReturningInt(var22);
                  var41 = var57;
               }

               int var59 = var15;
               int var58 = var41;
               var43 = var58;
               int var42 = var58;
               if (var59 == 0) {
                  break label70;
               }

               int var60 = var42;
               if (var60 == 0) {
                  var43 = 1;
                  break label70;
               }
            }

            var44 = 0;
            break label71;
         }

         int var61 = var43;
         var44 = var61;
      }

      int var16;
      int var49;
      label58: {
         int var48;
         label57: {
            label75: {
               var16 = var44;
               BlockHitResult var25 = var4;
               Object[] var26 = new Object[]{var25.getBlockPos(), Blocks.RESPAWN_ANCHOR, var7};
               byte var78 = ((byte)((BlockUtil.bReturningBoolean(var26)) ? 1 : 0));
               int var63 = var15;
               byte var62 = var78;
               int var46 = var62;
               byte var45 = var62;
               if (var63 != 0) {
                  byte var64 = var45;
                  if (var64 == 0) {
                     break label75;
                  }

                  BlockHitResult var28 = var4;
                  Object[] var29 = new Object[]{var28.getBlockPos(), var13};
                  int var65 = BlockUtil.aReturningInt(var29);
                  var46 = var65;
               }

               int var67 = var15;
               int var66 = var46;
               var48 = var66;
               int var47 = var66;
               if (var67 == 0) {
                  break label57;
               }

               int var68 = var47;
               if (var68 > 0) {
                  var48 = 1;
                  break label57;
               }
            }

            var49 = 0;
            break label58;
         }

         int var69 = var48;
         var49 = var69;
      }

      int var17 = var49;
      int var71 = var15;
      int var70 = var17;
      int var51 = var70;
      int var50 = var70;
      if (var71 != 0) {
         int var72 = var50;
         if (var72 != 0) {
            Object[] var34 = new Object[]{var4, var9};
            AnchorPlacer var33 = this;
            var33.lReturningVoid(var34);
            return;
         }

         Object[] var36 = new Object[]{var4, var11};
         var51 = (((BlockUtil.dReturningBoolean(var36)) ? 1 : 0));
      }

      label44: {
         int var74 = var15;
         int var73 = var51;
         int var53 = var73;
         int var52 = var73;
         if (var74 != 0) {
            int var75 = var52;
            if (var75 != 0) {
               break label44;
            }

            var53 = var16;
         }

         int var76 = var53;
         if (var76 == 0) {
            return;
         }
      }

      Object[] var10005 = new Object[]{null, null, var5};
      var10005[1] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var16));
      var10005[0] = var4;
      Object[] var39 = var10005;
      AnchorPlacer var38 = this;
      var38.mReturningVoid(var39);
   }

   private void lReturningVoid(Object[] var1) {
      BlockHitResult var4;
      long var5;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      int var19;
      int var74;
      var4 = (BlockHitResult)var1[0];
      long var2 = (Long)var1[1];
      var2 = 28389521308604L ^ var2;
      var5 = var2 ^ 84490959307002L;
      var7 = var2 ^ 71861276721452L;
      var9 = var2 ^ 132744084195897L;
      var11 = var2 ^ 17960541211481L;
      var13 = var2 ^ 118636361484240L;
      var15 = var2 ^ 7767292396969L;
      var17 = var2 ^ 80253603231280L;
      int var10000 = Event.bReturningInt();
      ModeSetting var24 = this.d;
      String var20 = (String)var24.aReturningObject();
      // var19 = var10000;
      String var25 = var20;
      var10000 = var25.hashCode();
      int var92 = var19;
      int var91 = var10000;
      var74 = var91;
      int var69 = var91;
      label113:
      if (var92 == 0) {
         int var93 = var69;
         switch (var93) {
            case 2590131:
               short var10001 = 21627;
               long var10002 = 6433548317903811030L ^ var2;
               String var28 = "Swap";
               String var27 = var20;
               byte var136 = ((byte)((var27.equals(var28)) ? 1 : 0));
               int var95 = var19;
               byte var94 = var136;
               var74 = var94;
               byte var70 = var94;
               if (var95 != 0) {
                  break label113;
               }

               byte var96 = var70;
               byte var71 = var96;
               byte var97 = var71;
               if (var97 == 0) {
                  break;
               }

               var21 = 0;
               int var98 = var19;
               if (var98 == 0) {
                  break;
               }
            case 2433880:
               short var142 = 32174;
               long var143 = 8394919056392050692L ^ var2;
               String var32 = "None";
               String var31 = var20;
               byte var137 = ((byte)((var31.equals(var32)) ? 1 : 0));
               int var100 = var19;
               byte var99 = var137;
               var74 = var99;
               byte var72 = var99;
               if (var100 != 0) {
                  break label113;
               }

               byte var101 = var72;
               byte var73 = var101;
               byte var102 = var73;
               if (var102 != 0) {
                  var21 = 1;
               }
         }

         var74 = var21;
      }

      int var103 = var74;
      switch (var103) {
         case 0:
            label96: {
               AnchorPlacer var87;
               label117: {
                  int var86;
                  label118: {
                     label119: {
                        label120: {
                           Object[] var35 = new Object[]{Items.TOTEM_OF_UNDYING, var11};
                           Integer var22 = InventoryUtil.aReturningBoxedInteger(var35);
                           int var105 = var19;
                           Integer var104 = var22;
                           Object var76 = var104;
                           Integer var75 = var104;
                           if (var105 == 0) {
                              Integer var106 = var75;
                              if (var106 == null) {
                                 break label120;
                              }

                              BooleanSetting var37 = this.e;
                              Object var107 = var37.aReturningObject();
                              var76 = var107;
                           }

                           Boolean var39 = (Boolean)var76;
                           byte var138 = ((byte)(((java.lang.Boolean)(var39)).booleanValue() ? 1 : 0));
                           int var109 = var19;
                           byte var108 = var138;
                           int var78 = var108;
                           byte var77 = var108;
                           if (var109 == 0) {
                              byte var110 = var77;
                              if (var110 != 0) {
                                 Object[] var41 = new Object[]{var13};
                                 this.j = InventoryUtil.aReturningInt(var41);
                              }

                              Integer var43 = var22;
                              var78 = var43;
                           }

                           Object[] var10003 = new Object[]{null, var15};
                           var10003[0] = var78;
                           Object[] var44 = var10003;
                           InventoryUtil.aReturningVoid(var44);
                           int var111 = var19;
                           if (var111 == 0) {
                              break label119;
                           }
                        }

                        Object[] var45 = new Object[]{Items.GLOWSTONE, var7};
                        byte var139 = ((byte)((InventoryUtil.lReturningBoolean(var45)) ? 1 : 0));
                        int var113 = var19;
                        byte var112 = var139;
                        var86 = var112;
                        byte var79 = var112;
                        if (var113 != 0) {
                           break label118;
                        }

                        byte var114 = var79;
                        byte var80 = var114;
                        byte var115 = var80;
                        if (var115 != 0) {
                           Object[] var48 = new Object[]{Items.GLOWSTONE, var17};
                           Integer var23 = InventoryUtil.bReturningBoxedInteger(var48);
                           int var117 = var19;
                           Integer var116 = var23;
                           Object var82 = var116;
                           Integer var81 = var116;
                           if (var117 == 0) {
                              Integer var118 = var81;
                              if (var118 == null) {
                                 return;
                              }

                              BooleanSetting var50 = this.e;
                              var82 = var50.aReturningObject();
                           }

                           Boolean var51 = (Boolean)var82;
                           var139 = ((byte)(((java.lang.Boolean)(var51)).booleanValue() ? 1 : 0));
                           int var120 = var19;
                           byte var119 = var139;
                           int var84 = var119;
                           byte var83 = var119;
                           if (var120 == 0) {
                              byte var121 = var83;
                              if (var121 != 0) {
                                 Object[] var53 = new Object[]{var13};
                                 this.j = InventoryUtil.aReturningInt(var53);
                              }

                              Integer var55 = var23;
                              var84 = var55;
                           }

                           Object[] var144 = new Object[]{null, var15};
                           var144[0] = var84;
                           Object[] var56 = var144;
                           InventoryUtil.aReturningVoid(var56);
                        }
                     }

                     Object[] var57 = new Object[]{var4, var5};
                     ItemUseUtil.aReturningBoolean(var57);
                     int var123 = var19;
                     AnchorPlacer var122 = this;
                     var87 = var122;
                     AnchorPlacer var85 = var122;
                     if (var123 != 0) {
                        break label117;
                     }

                     int var124 = var85.j;
                     var86 = var124;
                  }

                  // int var125 = var86;
                  if (var125 != var126) {
                     break label96;
                  }

                  AnchorPlacer var127 = this;
                  var87 = var127;
               }

               Object[] var61 = new Object[]{var9};
               AnchorPlacer var60 = var87;
               var60.jReturningVoid(var61);
            }

            int var128 = var19;
            if (var128 == 0) {
               break;
            }
         case 1:
            Object[] var62 = new Object[]{Items.GLOWSTONE, var7};
            boolean var141 = InventoryUtil.lReturningBoolean(var62);
            int var130 = var19;
            boolean var129 = var141;
            boolean var88 = var129;
            if (var130 == 0) {
               boolean var131 = var88;
               boolean var89 = var131;
               boolean var132 = var89;
               if (var132) {
                  return;
               }

               Object[] var65 = new Object[]{var4, var5};
               boolean var133 = ItemUseUtil.aReturningBoolean(var65);
            }

            Object[] var68 = new Object[]{var9};
            AnchorPlacer var67 = this;
            var67.jReturningVoid(var68);
      }
   }

   private void mReturningVoid(Object[] var1) {
      BlockHitResult var2;
      byte var5;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      long var18;
      long var20;
      long var22;
      int var24;
      int var102;
      var2 = (BlockHitResult)var1[0];
      var5 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var1[1]))))))))) ? 1 : 0);
      long var3 = (Long)var1[2];
      var3 = 28389521308604L ^ var3;
      var6 = var3 ^ 88092937602120L;
      var8 = var3 ^ 102929562486174L;
      var10 = var3 ^ 110484982402699L;
      var12 = var3 ^ 46081655142946L;
      var14 = var3 ^ 137266706115693L;
      var16 = var3 ^ 9484277507100L;
      var18 = var3 ^ 130981603443554L;
      var20 = var3 ^ 18731179856296L;
      var22 = var3 ^ 106923174131252L;
      int var10000 = Event.bReturningInt();
      ModeSetting var27 = this.d;
      String var25 = (String)var27.aReturningObject();
      var24 = var10000;
      // String var28 = var25;
      var10000 = var28.hashCode();
      int var129 = var24;
      int var128 = var10000;
      var102 = var128;
      int var97 = var128;
      label142:
      if (var129 == 0) {
         int var130 = var97;
         switch (var130) {
            case 2433880:
               short var10001 = 15999;
               long var10002 = 2014426305862704994L ^ var3;
               String var31 = "None";
               String var30 = var25;
               byte var189 = ((byte)((var30.equals(var31)) ? 1 : 0));
               int var132 = var24;
               byte var131 = var189;
               var102 = var131;
               byte var98 = var131;
               if (var132 != 0) {
                  break label142;
               }

               byte var133 = var98;
               byte var99 = var133;
               byte var134 = var99;
               if (var134 == 0) {
                  break;
               }

               var26 = 0;
               int var135 = var24;
               if (var135 == 0) {
                  break;
               }
            case 2590131:
               short var198 = 15462;
               long var200 = 5016006279570955642L ^ var3;
               String var35 = "Swap";
               String var34 = var25;
               byte var190 = ((byte)((var34.equals(var35)) ? 1 : 0));
               int var137 = var24;
               byte var136 = var190;
               var102 = var136;
               byte var100 = var136;
               if (var137 != 0) {
                  break label142;
               }

               byte var138 = var100;
               byte var101 = var138;
               byte var139 = var101;
               if (var139 != 0) {
                  var26 = 1;
               }
         }

         var102 = var26;
      }

      BlockPos var123;
      label154: {
         int var118;
         int var141 = var24;
         int var140 = var102;
         var118 = var140;
         int var103 = var140;
         label127:
         if (var141 == 0) {
            int var142 = var103;
            switch (var142) {
               case 0:
                  int var144 = var24;
                  byte var143 = var5;
                  byte var108 = var143;
                  byte var104 = var143;
                  if (var144 == 0) {
                     byte var145 = var104;
                     byte var105 = var145;
                     byte var146 = var105;
                     if (var146 != 0) {
                        Object[] var41 = new Object[]{Items.GLOWSTONE, var8};
                        byte var193 = ((byte)((InventoryUtil.lReturningBoolean(var41)) ? 1 : 0));
                        int var148 = var24;
                        byte var147 = var193;
                        var118 = var147;
                        byte var106 = var147;
                        if (var148 != 0) {
                           break label127;
                        }

                        byte var149 = var106;
                        byte var107 = var149;
                        byte var150 = var107;
                        if (var150 == 0) {
                           return;
                        }
                        break;
                     }

                     Object[] var44 = new Object[]{Items.RESPAWN_ANCHOR, var8};
                     var108 = ((byte)((InventoryUtil.lReturningBoolean(var44)) ? 1 : 0));
                  }

                  int var152 = var24;
                  byte var151 = var108;
                  var118 = var151;
                  byte var109 = var151;
                  if (var152 != 0) {
                     break label127;
                  }

                  byte var153 = var109;
                  if (var153 == 0) {
                     return;
                  }
                  break;
               case 1:
                  label148: {
                     BooleanSetting var46 = this.e;
                     Boolean var47 = (Boolean)var46.aReturningObject();
                     byte var191 = ((byte)(((java.lang.Boolean)(var47)).booleanValue() ? 1 : 0));
                     int var155 = var24;
                     byte var154 = var191;
                     byte var111 = var154;
                     byte var110 = var154;
                     if (var155 == 0) {
                        byte var156 = var110;
                        if (var156 != 0) {
                           Object[] var49 = new Object[]{var18};
                           this.j = InventoryUtil.aReturningInt(var49);
                        }

                        var111 = var5;
                     }

                     int var158 = var24;
                     byte var157 = var111;
                     byte var115 = var157;
                     byte var112 = var157;
                     if (var158 == 0) {
                        byte var159 = var112;
                        if (var159 != 0) {
                           Object[] var52 = new Object[]{Blocks.GLOWSTONE, var22};
                           var191 = ((byte)((InventoryUtil.iReturningVoid(var52)) ? 1 : 0));
                           int var161 = var24;
                           byte var160 = var191;
                           var118 = var160;
                           byte var113 = var160;
                           if (var161 != 0) {
                              break label127;
                           }

                           byte var162 = var113;
                           byte var114 = var162;
                           byte var163 = var114;
                           if (var163 == 0) {
                              Object[] var56 = new Object[]{var10};
                              AnchorPlacer var55 = this;
                              var55.jReturningVoid(var56);
                              return;
                           }
                           break label148;
                        }

                        Object[] var58 = new Object[]{Blocks.RESPAWN_ANCHOR, var22};
                        var115 = ((byte)((InventoryUtil.iReturningVoid(var58)) ? 1 : 0));
                     }

                     int var165 = var24;
                     byte var164 = var115;
                     var118 = var164;
                     byte var116 = var164;
                     if (var165 != 0) {
                        break label127;
                     }

                     byte var166 = var116;
                     if (var166 == 0) {
                        Object[] var61 = new Object[]{var10};
                        AnchorPlacer var60 = this;
                        var60.jReturningVoid(var61);
                        return;
                     }
                  }
            }

            BlockHitResult var63 = var2;
            BlockPos var194 = var63.getBlockPos();
            int var168 = var24;
            BlockPos var167 = var194;
            BlockPos var121 = var167;
            BlockPos var117 = var167;
            if (var168 != 0) {
               BlockPos var176 = var121;
               var123 = var176;
               break label154;
            }

            Object[] var64 = new Object[]{var117, Blocks.FIRE, var16};
            byte var169 = ((byte)((BlockUtil.bReturningBoolean(var64)) ? 1 : 0));
            var118 = var169;
         }

         int var170 = var118;
         label98:
         if (var170 == 0) {
            BlockHitResult var66 = var2;
            BlockPos var195 = var66.getBlockPos();
            int var172 = var24;
            BlockPos var171 = var195;
            BlockPos var122 = var171;
            BlockPos var119 = var171;
            if (var172 == 0) {
               BlockPos var173 = var119;
               BlockPos var120 = var173;
               Object[] var68 = new Object[]{var20};
               Object[] var69 = new Object[]{var120, BlockUtil.aReturningBlock(var68), var16};
               boolean var174 = BlockUtil.bReturningBoolean(var69);
               if (var174) {
                  break label98;
               }

               BlockHitResult var73 = var2;
               var122 = var73.getBlockPos();
            }

            BlockHitResult var74 = var2;
            Direction var75 = var74.getSide();
            int var199 = var75.getOffsetX();
            BlockHitResult var76 = var2;
            Direction var77 = var76.getSide();
            int var201 = var77.getOffsetY();
            BlockHitResult var78 = var2;
            Direction var79 = var78.getSide();
            int var83 = var79.getOffsetZ();
            int var82 = var201;
            int var81 = var199;
            BlockPos var80 = var122;
            var123 = var80.add(var81, var82, var83);
            break label154;
         }

         BlockHitResult var71 = var2;
         BlockPos var175 = var71.getBlockPos();
         var123 = var175;
      }

      AnchorPlacer var127;
      label151: {
         BlockPos var187 = var123;
         int var178 = var24;
         byte var177 = var5;
         int var126 = var177;
         byte var124 = var177;
         if (var178 == 0) {
            byte var179 = var124;
            if (var179 == 0) {
               BlockPos var86 = var187;
               ArrayList var85 = this.h;
               var85.add(var86);
            }

            Object[] var88 = new Object[]{var2, var6};
            ItemUseUtil.aReturningBoolean(var88);
            ElapsedTimer var196 = this.i;
            Object[] var90 = new Object[]{var14};
            ElapsedTimer var89 = var196;
            var89.aReturningVoid(var90);
            MinMaxSetting var197 = this.c;
            Object[] var92 = new Object[]{var12};
            MinMaxSetting var91 = var197;
            var91.bReturningVoid(var92);
            int var181 = var24;
            AnchorPlacer var180 = this;
            var127 = var180;
            AnchorPlacer var125 = var180;
            if (var181 != 0) {
               break label151;
            }

            int var182 = var125.j;
            var126 = var182;
         }

         // int var183 = var126;
         if (var183 != var184) {
            return;
         }

         AnchorPlacer var185 = this;
         var127 = var185;
      }

      Object[] var96 = new Object[]{var10};
      AnchorPlacer var95 = var127;
      var95.jReturningVoid(var96);
   }

   private static boolean lambda$calculate$2(BlockPos var0) {
      long var10001 = 95279355041552L ^ 120574466660752L;
      Object[] var5 = new Object[]{var0, 64933905403520L};
      return BlockUtil.eReturningBoolean(var5);
   }

   private boolean lambda$new$1(Float var1) {
      BooleanSetting var4 = this.f;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.d;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Swap";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(64061274966058L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      String var6 = "\u000f !OÒ\u0081@\u0094P²\u001eP\u000eéÍÜ\u0010Q]\n{·Ùì\u001díý\u008a\u0082\u001dó\u0080e\u0018h4\u0016äüôØ¼\u000e\nÚmzd§Õ\u0006\u0084rïÙ\u0094\u009dò\u0010ïéö¿\u0089\u001dIÇí<\u0017ù\u0094(Eè";
      int var8 = "\u000f !OÒ\u0081@\u0094P²\u001eP\u000eéÍÜ\u0010Q]\n{·Ùì\u001díý\u008a\u0082\u001dó\u0080e\u0018h4\u0016äüôØ¼\u000e\nÚmzd§Õ\u0006\u0084rïÙ\u0094\u009dò\u0010ïéö¿\u0089\u001dIÇí<\u0017ù\u0094(Eè"
         .length();
      char var5 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     l = var9;
                     m = new String[6];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "\u007f< \u009axw\u008a\u0016#\u001bUÚI¸\u0015\u0089 \u0085v\u0086\u0019á¿N´\u00866\u0000ëÁ\u00ad/sYÎ`á\u001c4³\u00031á¸êy°`K";
                  var8 = "\u007f< \u009axw\u008a\u0016#\u001bUÚI¸\u0015\u0089 \u0085v\u0086\u0019á¿N´\u00866\u0000ëÁ\u00ad/sYÎ`á\u001c4³\u00031á¸êy°`K"
                     .length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9585;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dV", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dV_C0205",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dV" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 28;
            yield var15;
         }
         case 1 -> {
            byte var16 = 25;
            yield var16;
         }
         case 2 -> {
            byte var17 = 32;
            yield var17;
         }
         case 3 -> {
            byte var18 = 1;
            yield var18;
         }
         case 4 -> {
            byte var19 = 54;
            yield var19;
         }
         case 5 -> {
            byte var20 = 5;
            yield var20;
         }
         case 6 -> {
            byte var21 = 57;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 29;
            yield var24;
         }
         case 10 -> {
            byte var25 = 0;
            yield var25;
         }
         case 11 -> {
            byte var26 = 51;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 46;
            yield var28;
         }
         case 14 -> {
            byte var29 = 53;
            yield var29;
         }
         case 15 -> {
            byte var30 = 10;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 26;
            yield var32;
         }
         case 18 -> {
            byte var33 = 6;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 43;
            yield var35;
         }
         case 21 -> {
            byte var36 = 8;
            yield var36;
         }
         case 22 -> {
            byte var37 = 37;
            yield var37;
         }
         case 23 -> {
            byte var38 = 31;
            yield var38;
         }
         case 24 -> {
            byte var39 = 17;
            yield var39;
         }
         case 25 -> {
            byte var40 = 63;
            yield var40;
         }
         case 26 -> {
            byte var41 = 2;
            yield var41;
         }
         case 27 -> {
            byte var42 = 36;
            yield var42;
         }
         case 28 -> {
            byte var43 = 21;
            yield var43;
         }
         case 29 -> {
            byte var44 = 7;
            yield var44;
         }
         case 30 -> {
            byte var45 = 38;
            yield var45;
         }
         case 31 -> {
            byte var46 = 56;
            yield var46;
         }
         case 32 -> {
            byte var47 = 34;
            yield var47;
         }
         case 33 -> {
            byte var48 = 52;
            yield var48;
         }
         case 34 -> {
            byte var49 = 14;
            yield var49;
         }
         case 35 -> {
            byte var50 = 35;
            yield var50;
         }
         case 36 -> {
            byte var51 = 39;
            yield var51;
         }
         case 37 -> {
            byte var52 = 27;
            yield var52;
         }
         case 38 -> {
            byte var53 = 41;
            yield var53;
         }
         case 39 -> {
            byte var54 = 62;
            yield var54;
         }
         case 40 -> {
            byte var55 = 15;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 18;
            yield var58;
         }
         case 44 -> {
            byte var59 = 20;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 33;
            yield var62;
         }
         case 48 -> {
            byte var63 = 12;
            yield var63;
         }
         case 49 -> {
            byte var64 = 61;
            yield var64;
         }
         case 50 -> {
            byte var65 = 50;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 40;
            yield var67;
         }
         case 53 -> {
            byte var68 = 19;
            yield var68;
         }
         case 54 -> {
            byte var69 = 55;
            yield var69;
         }
         case 55 -> {
            byte var70 = 58;
            yield var70;
         }
         case 56 -> {
            byte var71 = 16;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 49;
            yield var73;
         }
         case 59 -> {
            byte var74 = 42;
            yield var74;
         }
         case 60 -> {
            byte var75 = 44;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 3;
            yield var77;
         }
         default -> 22;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "qS=in\fgS83}\u001bp\u0018;5q\u000fa_,\":\u001dy";
      o[1] = "\u0007.\u0004sX\"r\u000e\u000f|Im\u0013\u0000\u0004wM7g";
      o[2] = boolean.class;
      p[2] = "java/lang/Boolean";
      o[3] = "l-y<\u0000\u000el-n`\f\u0001vfn~\f\u0014q\u0017? YQ";
      o[4] = "0*  ,a0*7| n*a7b {-\u0010f<u0";
      o[5] = "=U<T/\n+U9\u000e<\u001d<\u001e:\b0\t-Y-\u001f{\u001e\u000f";
      o[6] = "l:sA6\"g5b\u000eU/r8me`-c+qIw ";
      o[7] = "L\u0001F\b2C9!M\u0007#\fX/F\f'V,";
      o[8] = "YQ$\u0019\u000b\u0002OQ!C\u0018\u0015X\u001a\"E\u0014\u0001I]5R_\u0013x";
      o[9] = int.class;
      p[9] = "java/lang/Integer";
      o[10] = "hv1oy\"\u001dV:`hm|X1kl7\b";
      o[11] = void.class;
      p[11] = "java/lang/Void";
      o[12] = "(0]\u000f\"\\(0JS.S2{JM.F5\n\u001a\u0018y\u0000";
      o[13] = "4>SC\u0010z4>D\u001f\u001cu.uD\u0001\u001c`)\u0004\u0015^N+";
      o[14] = "z\u0001KxqJ\u000f!@w`\u0005n/K|d_\u001a";
      o[15] = "(\\!Yb(]|*Vsg<r!]w=H";
      o[16] = "?\f\rs\b )\f\b)\u001b7>G\u000b/\u0017#/\u0000\u001c8\\4\"";
      o[17] = "\u001eB\u00049\u007fxkb\u000f6n7\nl\u0004=jm~";
      o[18] = "\n`u\u0015U^\u001c`pOFI\u000b+sIJ]\u001ald^\u0001M\u0002lfU[\u0000>wfH[G\t`";
      o[19] = "-{X\u0003*\u0007&tILW\u001f5s@\u0005";
      o[20] = "CM!bJqHB0-+\u007fCI4w";
      o[21] = "w\u000b\u001e>E\na\u000b\u001bdV\u001dv@\u0018bZ\tg\u0007\u000fu\u0011\u0019|";
      o[22] = "ANS:R\u00114nX5C^U`S>G\u0004!";
      o[23] = "q\u0005\u0014\u0010\u0017}z\n\u0005_p\u007fo\u0001\u0005\u0014K";
      o[24] = "\u000b'\u000b[n\u0006~\u0007\u0000T\u007fI\u001f\t\u000b_{\u0013k";
      o[25] = "x\u0010-i\u0003Rx\u0010:5\u000f]b[:+\u000fHe*h\u007f^\t";
      o[26] = "{/\u000eo\u001a({/\u00193\u0016'ad\u0019-\u00162f\u0015KvNs";
      o[27] = "p\\d\u001b%@\u0005|o\u00144\u000fdrd\u001f0U\u0010";
      o[28] = "Bj?yLwIe.6 tGg,y\f";
      o[29] = "\u0016\u000en\u001d\u00109\u0000\u000ekG\u0003.\u0017EhA\u000f:\u0006\u0002\u007fVD-4";
      o[30] = "N\\\u0014M\u001c\b;|\u001fB\rGZr\u0014I\t\u001d.";
      o[31] = " T6d[mUt=kJ\"4z6`Nx@";
      o[32] = "\u000e!yl\u001cR\u0018!|6\u000fE\u000fj\u007f0\u0003Q\u001e-h'HA\u0006";
      o[33] = "%YG\u0014-\u0011PyL\u001b<^1wG\u00108\u0004E";
      o[34] = "I.\u000f\u0010_\r<\u000e\u0004\u001fNB]\u0000\u000f\u0014J\u0018)";
      o[35] = "?\u0019-8\b\u0010?\u0019:d\u0004\u001f%R:z\u0004\n\"#k WO";
      o[36] = "xJ\u0019g{WfB\u0003(\u0014P`J\u0016J<Qf";
      o[37] = "\r|qi\u0003\u001a\r|f5\u000f\u0015\u00177f+\u000f\u0000\u0010F7qVC";
      o[38] = "l\u0012p$|=z\u0012u~o*mYvxc>|\u001eao(/l";
      o[39] = "J^\u0005\u0003y~?~\u000e\fh1^p\u0005\u0007lk*";
      o[40] = "+|&@!<+|1\u001c-3171\u0002-&6F`[uc";
      o[41] = "hO\u000eVj.\u001do\u0005Y{a|a\u000eR\u007f;\b";
      o[42] = "O{\"}3AY{'' VN0$!,B_w36gUg";
      o[43] = "Y}s\\zN,]xSk\u0001MSsXo[9";
      o[44] = "\f\u000b\n\u0002Q2y+\u0001\r@}\u0018%\n\u0006D'l";
      o[45] = "P`\u0011\u00143\u0001P`\u0006H?\u000eJ+\u0006V?\u001bMZR\u000eh";
      o[46] = float.class;
      p[46] = "java/lang/Float";
      o[47] = "BLU]d\r\\DO\u0012\u0006\u0011[Y";
      o[48] = "\u0017\u001b/&W/\t\u00135i0.\u0018\b83\u0016(";
      o[49] = "\u0010\u0015\u001eedZ\u0006\u0015\u001b?wM\u0011^\u00189{Y\u0000\u0019\u000f.0L-";
      o[50] = "dTh\u007f\f\u0005\u0011tcp\u001dJpzh{\u0019\u0010\u0004";
      o[51] = "\u0017\n\f\u001a4}b*\u0007\u0015%2\u0003$\f\u001e!hw";
      o[52] = "3cB\u001dke3cUAgj)(U_g\u007f.Y\u0005\u00026";
      o[53] = "Gx4\\o\u00152X?S~ZSV4Xz\u0000'";
      o[54] = "\u0003OC\u0007E>\u0015OF]V)\u0002\u0004E[Z=\u0013CRL\u0011*\u001f";
      o[55] = "6-8;\u0011oC\r34\u0000 \"\u00038?\u0004zV";
      o[56] = "J\t?\u0016\u0002\u0012A\u0006.Ya\u001fT\u0000";
      o[57] = double.class;
      p[57] = "java/lang/Double";
      o[58] = "\u000eW+\u0018xb\u000eW<Dtm\u0014\u001c<Ztx\u0013mm\u0002&";
      o[59] = "\u0013\u0001F2`2f!M=q}\u0007/F6u's";
      o[60] = "\u001dBjK\u000bH\u000bBo\u0011\u0018_\u001c\tl\u0017\u0014K\rN{\u0000_\\;";
      o[61] = "nZ@h<Z\u001bzKg-\u0015zt@l)O\u000e";
      o[62] = "Qg|K%AGgy\u00116VP,z\u0017:BAkm\u0000qR\u0007";
      o[63] = "^Zw87\u0011+z|7&^Jtw<\"\u0004>";
      o[64] = "oc5w.j\u001aC>x?%{M5s;\u007f\u000f";
      o[65] = "Fx<\u0007\u0018@Fx+[\u0014O\\3+E\u0014Z[Bz\u001aL";
      o[66] = "LF\u0012\u001c\n\\9f\u0019\u0013\u001b\u0013Xh\u0012\u0018\u001fI,";
      o[67] = "jQ);t!\u001fq\"4en~\u007f)?a4\n";
      o[68] = "{\nh\u0003d\u0001\u000e*c\fuNo$h\u0007q\u0014\u001b";
      o[69] = "$wolN /x~#& !wm";
      o[70] = "QmY>?9$MR1.vECY:*,1";
      o[71] = "\u000f9N\u001d\u0006!z\u0019E\u0012\u0017n\u001b\u0017N\u0019\u00134o";
      o[72] = "\u000e\u001b\u0000KhJ\u000e\u001b\u0017\u0017dE\u0014P\u0017\tdP\u0013!@V2";
      o[73] = "$|r}!\":th2\\2:";
      o[74] = "dT-Z\u001a\u0018\u0011t&U\u000bWpz-^\u000f\r\u0004";
      o[75] = "\n\u0019&qW2\u001c\u0019#+D%\u000bR -H1\u001a\u00157:\u0003&?";
      o[76] = "\u0005 \bI2\u0010p\u0000\u0003F#_\u0011\u000e\bM'\u0005e";
      o[77] = "\u0001!rS\u0010b\u0001!e\u000f\u001cm\u001bje\u0011\u001cx\u001c\u001b4NH;";
      o[78] = "o:Nv3X\u001a\u001aEy\"\u0017{\u0014Nr&M\u000f";
      o[79] = "C\u007f}y\u0001\t6_vv\u0010FWQ}}\u0014\u001c#";
      o[80] = "\u001e!)t`M\b!,.sZ\u001fj/(\u007fN\u000e-8?4Y2";
      o[81] = "\u0019G*{\u007f,lg!tnc\ri*\u007fj9y";
      o[82] = "\u0005\fww\u0016y\u0013\fr-\u0005n\u0004Gq+\tz\u0015\u0000f<Bm+";
      o[83] = "}\fS\u007f\u00048\b,Xp\u0015wi\"S{\u0011-\u001d";
      o[84] = "(6\u0017u\u001bg+&\u0019:'}Tu\u0002/\u001cu+w\u001c&U~Ts\u0000wZwjw\u0006&\u001e\u0017";
      o[85] = "\u001a\u0005\u0003\u0019\u000fN\f\u001d\u0016\u001akO\u001f\u0017\u0006 \fC\u001blX\u0006\u001aV\u0015\u001cXW\u0017Hv";
      o[86] = "%y&QH\u0018%q8\u0013Fwu\u001bd\u000bRL~df\u0015[\u0005u\u001bd\rMIbtd\u0005S\u000bl\u001b";
      o[87] = "2\u00157Cs\u0011'R)\u001cB\u0018&R.F.*q\u0010t\u0019~}qS5C!D:\u0012)\u0018B";
      o[88] = "}ON,+1(\u0010\u0015&)K*\u0016C3&\u001c}H\u0013jJr)\u001aS4zr.N\u0016l";
      o[89] = "@\u000fBvFL\u0018\u0018R<{VJ\r\\c\u0017d\u001eH\u0007<K3^JEfJ_K\r[9{";
      o[90] = "WR\u001e}`=\u0018JFr\f?DKFg`\r\u0012\t\u001a=0ZV\u000fH{adR\u000f[=\f";
      o[91] = "*\u0019l\u001b\u00113v\no\u0007m4\u0011Y1CW!)\t)\u001a\n]-\u0003kE\u0011e}\u001b2\u0018m";
      o[92] = "}A5DC\u001bg[4\u0004s\u0007\u0017\u001c!PH\th\u001e?Y\u0001\u0002\u0017\u001a#\b\u000e\u000b)\u001e%YJk";
      o[93] = "z7\bb\rMy-_wt\u0016y<Of\b\u0010\u007fQEq\r\u001at1G`\u001b\u0019\u0005";
      o[94] = "\u0016.\u00003YWCq[9[-J{\u001c(_Ax/]v\t-\u0016{\u001aq\u0007GCh\r#8";
      o[95] = "zQXLN\u0000zKW\u0011\r1*2\u0010\u0013Q\n!M\u0012\rXC*2\u0010\u0014D\n8\u0003\u0010\u000eKW{2";
      o[96] = "a\u0007}\u0000^\u0016n\u0019w\u0002 \u0019h\u001b\u0012\u001bD\u0005cgr\u001fQ\u0001m\u0017rN\\\u001f\u000e";
      o[97] = "'A\u0002M(\u0000hYZBD\u00024XZW(0b\u001a\u0006\ryg&\u001cTK)Y\"\u001cG\rD";
      o[98] = "\u000b*asO<\t;wp>:\u0016$d\u001eS5\n/$pR9\u001b,\u0018";
      o[99] = "\f\u0010Vi:\u0005W\u0011\u0003m1yNR\u001ciH@\u000eL\u000bn(\u0000\f\u0017\u0006hH@\u000eL\u000bn(\u0000\f\u0017\u0006hH";
      o[100] = "9066]\u0015b1c2Viia}JPQnpktTQ}6\u00065\u0017\u0007{f81\u0017\u0014=\u000b";
      o[101] = "A\u001aG]T~\u001d\tDA(uz_\u0018]\u0013r\u0005]\u0006TZyzY\u001a\u0005UpD]\u001cT\u0011\u0010";
      o[102] = "W!qIJg\u00189)F&eD8)SJW\u0012\u007ft\u000b\u001f\u0000\u0010x4\bXp\u001364U\u001a\u0000";
      o[103] = "8V\u001aa\u0015\u00131C\u0019+t\u000b-W\u0005.\u0019q-[\u0013+H\u001f,W\u0002(tH-H[o\u001e\u001d>_\tP";
      o[104] = "v\u001bD\u0004:w`\u0003Q\u0007^{c\u000fH\u0012%\u0016w\u001bP\rbxv\u0017A\u000e^/w\b\u0018I4zd\u001fJv";
      o[105] = " g&9+Id{wv4#|j:f/ON>~?v\u001e\u00199+w1@i9zz/#";
      o[106] = "\n\u0014\u0013\u007f\u0017\"\u000b\b\u0015qu;gR\u000e\u007fN0\u0018P\u0010v\u0007;g\u0004\n*\u0007,\t\u000b\u0014 \u0005R";
      o[107] = "\u0000`{\u001bi;H&m\u0005lKS^0\u001cbp[!2\u0002k9P^0D{wG.3\n{*\u0005^";
      o[108] = "\u001d4t^jd\\eu\u0002wTM\n}\u0003joFu\u007f\u001dc&M\n}Vl:\u001cn$[ukD\n";
      o[109] = "@PcG\u0004\u001b]Fq,\u0003q\u001cMe\u0017\b\u000e\u001eSl^\u0003qZO<A\u0013KYUkTj";
      o[110] = "U\u00128\u000e\u0019-\u0000Mc\u0004\u001bW\u0002K5\u0011\u0014\u0000U\u0015fHxn]H6M\u001c7PQg\u0015";
      o[111] = "<T\u001cyD%cPNgUGl;\u0015~Q|gD\u0017`X5l;\u0013|\t:e\u0005\u0017zX~\u0005";
      o[112] = "\u001d2\u0001qN=K;\u000e7\u0018TM\u000bZoEoFtXqL&M\u000bZf[m\u001ba\u000fuL?$";
      o[113] = "v\u0004rX\u0004\u0016xWj\bk\u001e*\u0017`^\u0007,~S8\tW{v\u0004rX\u0004\u0016xWj\bk";
      o[114] = "\u0003c\u001b\fYm_p\u0018\u0010%a8&D\f\u001eaG$Z\u0005Wj8 FTXc\u0006$@\u0005\u001c\u0003";
      o[115] = "\u001dC'v2yA\u0007$u\u000frx\u00039v4y\u0007\u0001'\u007f}rx\u00030h6$\u0012V#\u007fd\u001b";
      o[116] = "7f`\u0006:;6zf\bX!Z }\u0006c)%\"c\u000f*\"ZvyS*54ygY(K";
      o[117] = "\u0000xp\u000eAL\u0001dv\u0000#]m>m\u000e\u0018^\u0012<s\u0007QUm>d\u0010\u001a\u0003\u0007kw\u0007H<";
      o[118] = "\u0006e7\u0011+\u0018I}o\u001eG\u001a\u0015|o\u000b+(F96QGF\u0015z6S-\u0013\u0006mdl";
      o[119] = "^,M\u0016i\u0010\u0005x\t\nT\u0015cw\u001d\u0019-\u001c\u0013wL\u00143\u007f";
      o[120] = "Rxu:\u001f'OngQ\u0018M\u000eesj\u00132\f{z#\u0018M\u0006ne0\u001e \b=}`q";
      o[121] = "H8!d%\n\u001c/;u[\n\u0013:5w\f^Inl![^\u000f,3xb\u0015N0h";
      o[122] = "\u001eBnW\u007f\u0014\u001f^hY\u001d\rs\u0004sW&\u0006\f\u0006m^o\rs\u0002q\u000f`\u0004M\u0006w^$d";
      o[123] = "a)\u0003d\u0001W2-DmI,?)?r\u0018]#{Qs\u0014L G\u0006qMW(<Uu\n^`G";
      o[124] = "%M!L\u0017_~\u0019eP*[\u0018\u0016qCSSh\u0016 NM0";
      o[125] = "\u0015\\[>n\u0012L_Sm\u000fC\u0010ZQnfO)TQ~b)NPO:0C\u001bCXh\u000f";
      o[126] = "\u0012\u000fn\u001d(\rYBr\u001e\u0010\u0000c\njC+\b\u001c\btJb\u0003c\nc])U\t_pJ{j";
      o[127] = "Xw1\u0000D^Zsq\\{[;'b\u0012\u0000\u000eU&n\u0003\u00032";
      o[128] = "c7G\u000fv:y-FOF$\tjS\u001b}(vhM\u00124#\tjZ\u0005\u007fuc?I\u0012-J";
      o[129] = "em&s\u0004\\\u007fw'34A\u000f02g\u000fNp2,nFE\u000f60?IL126n\r,";
      o[130] = "dH=!\\Z1\u0017f+^ 3\u00110>QwdOgf=^8H 6Z\u0011 \u0010/";
      o[131] = "\u001c\u0015P{R\u0017WXLxj\u0019m\u0010T%Q\u0012\u0012\u0012J,\u0018\u0019m\u0016V}\u0017\u0010S\u0012P,Sp";
      o[132] = "\u000e=qrm<\u0000ni\"\u0002<F/jwyQR;rh>?S7ck\u0002hR(:,h=A?h\u0013";
      o[133] = "h#HGi\t<4RV\u0017\t3!\\T@^ju\u0007\u0001\u0017]/7Z[.\u0016n+\u0001";
      o[134] = "M?7l\u0019nXvmyz0&,6s\ngV6,rJ";
      o[135] = ")jT)in\u007fc[o?\u0007yS\u000f7b<r,\r)kuySIkh|}mMk{:\u0010";
      o[136] = "\u0011c\u001fbh:U\u007fN-wPMn\u0003=l<\u007f:Gd7`(=\u0012,r3X=C!lP";
      o[137] = "<\u0014%\u0010\r =\b#\u001eo9QR8\u0010T2.P&\u0019\u001d9QU1\u0005\u00163!U`\b\bP";
      o[138] = "Wy{|OF\u000bjx`3Ll<$|\bJ\u0013>:uAAl:&$NHR> u\n(";
      o[139] = "\u001d9N\u0015\u0010r\u001f(X\u0016ar\u0004<q\u0015\u0011nm~Z\u0002X-\u0007+I\u0015\n\u0012";
      o[140] = "cbX:s\u0013`,Xg1c?3Yfj\u000f\rg\u001d<7ccbX:s\u0013`,Xg1cceBkv\u0003#g\u0019fpc";
      o[141] = "\u001c'\u001aR{-\u0010?\u0010K\u001a)A)\u001dJv\u001b\u0015jB\u0012%L\u001d:\u000fLu!\u0013i\u0017\u001c\u001a";
      o[142] = "lpA\u00071FqfSl0,0mGW=S2sN\u001e6,0dYU`FewN\u0007_";
      o[143] = "\u000fc U|XN2!\tahZ])\b|ST\"+\u0016u\u001a_])Uz\u0012Y4\u007f\\uT\u000f]";
      o[144] = "L'M\",\u0013Q1_I+y\u0010:Kr \u0006\u0012$B;+y\u00173^0!\t\u0017bS.B";
      o[145] = "eiO8[\u0006=~_rf\u001cokQ-\n.;.\nrWy3xC+\t\u0014=+[{f";
      o[146] = "&r<1oa;d.Zl\u000bzo:actxq3(h\u000bzf$c>a/u31\u0001";
      o[147] = "Sc>ER4Nu,.V^\u000f~8\u0015^!\r`1\\U^\u000fw&\u0017\u00034Zd1E<";
      o[148] = "\u001ar\u0005}\u001c\u001f\u001bn\u0003s~\u000bw4\u0018}E\r\b6\u0006t\f\u0006w4\u0011cGP\u001da\u0002t\u0015o";
      o[149] = "ycdbC~c<ady`xh=a.>#5i\r\u00182\"8ai\u0006|f{";
      o[150] = "&kJ;f8pbE}0QuR\u0011%mj}-\u0013;d#vRWyg*rlSytl\u001f";
      o[151] = "J%6\u000e\u0004$W3$e\u0006N\u001680^\b1\u0014&9\u0017\u0003N\u00161.\\U$C\"9\u000ej";
      o[152] = "\"\u0001!U8m8^$S\u0002s#\nxVU'y^ \u0003\u0002|~\\!\u0002fb0\u0018b";
      o[153] = "D\u000fB2A\u0015M\u001aAx \u001eP\u0007:nI\u0006GWToE\u0017Dk\u0003nZN\u0003\u0001V}M\u001c<";
      o[154] = "\u001fL=-Jv\u001fM<-P\u0019HC5/MGOC/+1f\u001eI)+\u000fb\u001eZoF";
      o[155] = "$tc=X\u000e-a`w9\u00078}rv9S:,fl\u0007W<}\"\f";
      o[156] = "%p_<\u001ecal\u000es\u0001\ty}Cc\u001aeK)\u0007:C5\u001c.Rr\u0004jl.\u0003\u007f\u001a\t";
      o[157] = "AKr/;\nXBtr\u0006\u00008\u001f++=\u000bG\u001d5\"t\u00008]#ul\f_L5*<i";
      o[158] = "n\r|hV<tRynl\"o\u0006%k;|>Sx\u0007\rp5Vyc\u0013>q\u0015";
      o[159] = "u] 7\u0013\u0010)N#+o\u001dN\u0018\u007f7T\u001c1\u001aa>\u001d\u0017N\u001e}o\u0012\u001ep\u001a{>V~";
      o[160] = "~!gi/2d;f)\u001f+\u0014|s}$ k~mtm+\u0014|.{e-}*'t#{\u0014";
      o[161] = "SiW zo\u0007~M1\u0004o\bkC3S8Q>\u001ca\u0004;\u0014}E<=pUa\u001e";
      o[162] = "\u001d\u0018vP\u001ew\u0000\u000ed;\u0019\u001dA\u0005p\u0000\u0012bC\u001byI\u0019\u001dB\u001coY\u0013$\t]s\u0002p";
      o[163] = "$[5r\u00009*\b-\"o1xH't\u0003\u0003,\f\u007f-^T+Y6j\f$+\b;tojxE>p\u001fj)H \u0013Q9dM$cQhiSG\"\u0000&t[*,S>$4";
      o[164] = "/x\u00026 O#`\b/AKrv\u0005.-y&5Zyy.&j\u0005v\"DbvT9=.";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1452776091611677L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1452776091611677L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1452776091611677L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 75;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 227;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 69;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 251;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 103;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 75;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 227;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 69;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dV_C0205",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dV" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AnchorPlacer var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dV_C0205;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dV_C0205", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorPlacer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AnchorPlacer var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dV_C0205;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dV_C0205", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AnchorPlacer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/dV_C0205", "lambda$calculate$2", "(Lnet/minecraft/util/math/BlockPos;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
