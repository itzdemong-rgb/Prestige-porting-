package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.HeldItemRendererAccessor;
import dev.zprestige.prestige.api.events.SwingDurationEvent;
import dev.zprestige.prestige.api.events.HeldItemTransformEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;

public class Animations extends Module {
   private IntSetting a;
   private BooleanSetting d;
   private static final long k = 119795595320950L;
   private static final long l;
   private static final Object[] m = new Object[70];
   private static final String[] n = new String[70];

   @EventListener
   public void a(Render3DEvent var1) {
      HeldItemRendererAccessor var43;
      label26: {
         long var10001 = 43262508352867L ^ 37270864158566L;
         var10001 = 43262508352867L ^ 61079385894190L;
         var10001 = 43262508352867L ^ 87290697647275L;
         var10001 = 43262508352867L ^ 119812574475131L;
         var10001 = 43262508352867L ^ 38566728652926L;
         var10001 = 43262508352867L ^ 43442169122927L;
         int var10000 = Event.bReturningInt();
         MinecraftClient var18 = b;
         EntityRenderManager var19 = var18.getEntityRenderDispatcher();
         HeldItemRendererAccessor var17 = new HeldItemRendererAccessor(var19.getHeldItemRenderer());
         int var16 = var10000;
         Object[] var21 = new Object[]{114603240964552L};
         HeldItemRendererAccessor var20 = var17;
         float var59;
         var10000 = (var59 = var20.aReturningFloat(var21) - 1.0F) == 0.0F ? 0 : (var59 < 0.0F ? -1 : 1);
         int var45 = var16;
         int var44 = var10000;
         int var42 = var44;
         int var40 = var44;
         if (var45 == 0) {
            int var46 = var40;
            if (var46 <= 0) {
               Object[] var10004 = new Object[]{null, 938408301836L};
               var10004[0] = 1.0F;
               Object[] var24 = var10004;
               HeldItemRendererAccessor var23 = var17;
               var23.aReturningVoid(var24);
               MinecraftClient var25 = b;
               ClientPlayerEntity var26 = var25.player;
               Object[] var28 = new Object[]{var26.getMainHandStack(), 4721550564637L};
               HeldItemRendererAccessor var27 = var17;
               var27.cReturningVoid(var28);
            }

            int var48 = var16;
            HeldItemRendererAccessor var47 = var17;
            var43 = var47;
            HeldItemRendererAccessor var41 = var47;
            if (var48 != 0) {
               break label26;
            }

            Object[] var31 = new Object[]{18511064213581L};
            HeldItemRendererAccessor var30 = var41;
            float var60;
            int var49 = (var60 = var30.bReturningFloat(var31) - 1.0F) == 0.0F ? 0 : (var60 < 0.0F ? -1 : 1);
            var42 = var49;
         }

         int var50 = var42;
         if (var50 > 0) {
            return;
         }

         Object[] var58 = new Object[]{null, 83154316670488L};
         var58[0] = 1.0F;
         Object[] var34 = var58;
         HeldItemRendererAccessor var33 = var17;
         var33.bReturningVoid(var34);
         HeldItemRendererAccessor var51 = var17;
         var43 = var51;
      }

      MinecraftClient var36 = b;
      ClientPlayerEntity var37 = var36.player;
      Object[] var39 = new Object[]{var37.getOffHandStack(), 7409270462981L};
      HeldItemRendererAccessor var38 = var43;
      var38.dReturningVoid(var39);
   }

   @EventListener
   public void a(SwingDurationEvent var1) {
      int var4 = Event.cReturningInt();
      int var11 = var4;
      if (var11 != 0) {
         BooleanSetting var5 = this.d;
         Boolean var6 = (Boolean)var5.aReturningObject();
         boolean var12 = var6;
         if (!var12) {
            return;
         }

         var1.a = (int)l;
      }

      Object[] var10 = new Object[0];
      SwingDurationEvent var9 = var1;
      var9.aReturningVoid(var10);
   }

   @EventListener
   public void a(HeldItemTransformEvent var1) {
      long var10001 = 92681791496679L ^ 105878861347884L;
      var10001 = 92681791496679L ^ 76955439365723L;
      Object[] var16 = new Object[0];
      HeldItemTransformEvent var15 = var1;
      MatrixStack var9 = var15.aReturningMatrixStack(var16);
      int var10000 = Event.cReturningInt();
      Object[] var18 = new Object[0];
      HeldItemTransformEvent var17 = var1;
      Arm var10 = var17.aReturningArm(var18);
      int var8 = var10000;
      Object[] var20 = new Object[0];
      HeldItemTransformEvent var19 = var1;
      float var11 = var19.aReturningFloat(var20);
      Arm var132 = Arm.RIGHT;
      Arm var131 = var10;
      byte var130;
      if (var131 == var132) {
         byte var133 = 1;
         var130 = var133;
      } else {
         var130 = -1;
      }

      byte var12 = var130;
      int var134 = var8;
      if (var134 != 0) {
         IntSetting var22 = this.a;
         Integer var23 = (Integer)var22.aReturningObject();
         int var135 = var23;
         switch (var135) {
            case 1:
               Object[] var10006 = new Object[]{null, null, null, 57178877140427L};
               var10006[2] = 0.0F;
               var10006[1] = var10;
               var10006[0] = var9;
               Object[] var26 = var10006;
               Animations var25 = this;
               var25.jReturningVoid(var26);
               double var27 = var11 * var11 * (float) Math.PI;
               float var13 = MathHelper.sin(var27);
               float var30 = var12 * (45.0F + var13 * -20.0F);
               RotationAxis var29 = RotationAxis.POSITIVE_Y;
               Quaternionf var32 = var29.rotationDegrees(var30);
               MatrixStack var31 = var9;
               var31.multiply((Quaternionfc)var32);
               float var33 = var11;
               double var34 = MathHelper.sqrt(var33) * (float) Math.PI;
               float var14 = MathHelper.sin(var34);
               float var37 = var12 * var14 * -10.0F;
               RotationAxis var36 = RotationAxis.POSITIVE_Z;
               Quaternionf var39 = var36.rotationDegrees(var37);
               MatrixStack var38 = var9;
               var38.multiply((Quaternionfc)var39);
               float var41 = var14 * -80.0F;
               RotationAxis var40 = RotationAxis.POSITIVE_X;
               Quaternionf var43 = var40.rotationDegrees(var41);
               MatrixStack var42 = var9;
               var42.multiply((Quaternionfc)var43);
               float var45 = var12 * -45.0F;
               RotationAxis var44 = RotationAxis.POSITIVE_Y;
               Quaternionf var47 = var44.rotationDegrees(var45);
               MatrixStack var46 = var9;
               var46.multiply((Quaternionfc)var47);
               int var136 = var8;
               if (var136 != 0) {
                  break;
               }
            case 2:
               Object[] var147 = new Object[]{null, null, null, 57178877140427L};
               var147[2] = 0.0F;
               var147[1] = var10;
               var147[0] = var9;
               Object[] var49 = var147;
               Animations var48 = this;
               var48.jReturningVoid(var49);
               float var51 = var12 * 45.0F;
               RotationAxis var50 = RotationAxis.POSITIVE_Y;
               Quaternionf var53 = var50.rotationDegrees(var51);
               MatrixStack var52 = var9;
               var52.multiply((Quaternionfc)var53);
               float var54 = var11;
               double var55 = MathHelper.sqrt(var54) * (float) Math.PI;
               float var142 = MathHelper.sin(var55);
               float var58 = var12 * var142 * -10.0F;
               RotationAxis var57 = RotationAxis.POSITIVE_Z;
               Quaternionf var60 = var57.rotationDegrees(var58);
               MatrixStack var59 = var9;
               var59.multiply((Quaternionfc)var60);
               float var62 = var142 * -40.0F;
               RotationAxis var61 = RotationAxis.POSITIVE_X;
               Quaternionf var64 = var61.rotationDegrees(var62);
               MatrixStack var63 = var9;
               var63.multiply((Quaternionfc)var64);
               float var66 = var12 * -45.0F;
               RotationAxis var65 = RotationAxis.POSITIVE_Y;
               Quaternionf var68 = var65.rotationDegrees(var66);
               MatrixStack var67 = var9;
               var67.multiply((Quaternionfc)var68);
               int var137 = var8;
               if (var137 != 0) {
                  break;
               }
            case 3:
               label24: {
                  Object[] var148 = new Object[]{null, null, null, 57178877140427L};
                  var148[2] = 0.0F;
                  var148[1] = var10;
                  var148[0] = var9;
                  Object[] var70 = var148;
                  Animations var69 = this;
                  var69.jReturningVoid(var70);
                  Arm var139 = Arm.RIGHT;
                  Arm var138 = var10;
                  if (var138 == var139) {
                     MinecraftClient var72 = b;
                     ClientPlayerEntity var73 = var72.player;
                     Object[] var74 = new Object[]{var73.getMainHandStack(), 19476550655932L};
                     boolean var140 = InventoryUtil.aReturningBoolean(var74);
                     if (var140) {
                        float var79 = -0.2F;
                        float var78 = 0.1F;
                        float var77 = 0.0F;
                        MatrixStack var76 = var9;
                        var76.translate(var77, var78, var79);
                        float var81 = var12 * 65.0F;
                        RotationAxis var80 = RotationAxis.POSITIVE_Y;
                        Quaternionf var83 = var80.rotationDegrees(var81);
                        MatrixStack var82 = var9;
                        var82.multiply((Quaternionfc)var83);
                        float var85 = var12 * -100.0F;
                        RotationAxis var84 = RotationAxis.POSITIVE_X;
                        Quaternionf var87 = var84.rotationDegrees(var85);
                        MatrixStack var86 = var9;
                        var86.multiply((Quaternionfc)var87);
                        float var89 = var12 * 20.0F;
                        RotationAxis var88 = RotationAxis.POSITIVE_Z;
                        Quaternionf var91 = var88.rotationDegrees(var89);
                        MatrixStack var90 = var9;
                        var90.multiply((Quaternionfc)var91);
                        float var93 = var12 * -220.0F;
                        RotationAxis var92 = RotationAxis.POSITIVE_Y;
                        Quaternionf var95 = var92.rotationDegrees(var93);
                        MatrixStack var94 = var9;
                        var94.multiply((Quaternionfc)var95);
                        float var96 = var11;
                        double var97 = MathHelper.sqrt(var96) * (float) Math.PI;
                        float var143 = MathHelper.sin(var97);
                        float var100 = var12 * var143 * -40.0F;
                        RotationAxis var99 = RotationAxis.POSITIVE_Z;
                        Quaternionf var102 = var99.rotationDegrees(var100);
                        MatrixStack var101 = var9;
                        var101.multiply((Quaternionfc)var102);
                        float var104 = var12 * -45.0F;
                        RotationAxis var103 = RotationAxis.POSITIVE_Y;
                        Quaternionf var106 = var103.rotationDegrees(var104);
                        MatrixStack var105 = var9;
                        var105.multiply((Quaternionfc)var106);
                        int var141 = var8;
                        if (var141 != 0) {
                           break label24;
                        }
                     }
                  }

                  double var107 = var11 * var11 * (float) Math.PI;
                  float var144 = MathHelper.sin(var107);
                  float var110 = var12 * (45.0F + var144 * -20.0F);
                  RotationAxis var109 = RotationAxis.POSITIVE_Y;
                  Quaternionf var112 = var109.rotationDegrees(var110);
                  MatrixStack var111 = var9;
                  var111.multiply((Quaternionfc)var112);
                  float var113 = var11;
                  double var114 = MathHelper.sqrt(var113) * (float) Math.PI;
                  float var145 = MathHelper.sin(var114);
                  float var117 = var12 * var145 * -20.0F;
                  RotationAxis var116 = RotationAxis.POSITIVE_Z;
                  Quaternionf var119 = var116.rotationDegrees(var117);
                  MatrixStack var118 = var9;
                  var118.multiply((Quaternionfc)var119);
                  float var121 = var145 * -80.0F;
                  RotationAxis var120 = RotationAxis.POSITIVE_X;
                  Quaternionf var123 = var120.rotationDegrees(var121);
                  MatrixStack var122 = var9;
                  var122.multiply((Quaternionfc)var123);
                  float var125 = var12 * -45.0F;
                  RotationAxis var124 = RotationAxis.POSITIVE_Y;
                  Quaternionf var127 = var124.rotationDegrees(var125);
                  MatrixStack var126 = var9;
                  var126.multiply((Quaternionfc)var127);
               }
         }

         Object[] var129 = new Object[0];
         HeldItemTransformEvent var128 = var1;
         var128.aReturningVoid(var129);
      }
   }

   private void jReturningVoid(Object[] var1) {
      MatrixStack var2 = (MatrixStack)var1[0];
      Arm var6 = (Arm)var1[1];
      float var5 = (Float)var1[2];
      long var3 = (Long)var1[3];
      long var10000 = 119795595320950L ^ var3;
      Arm var15 = Arm.RIGHT;
      Arm var14 = var6;
      byte var13;
      if (var14 == var15) {
         byte var16 = 1;
         var13 = var16;
      } else {
         var13 = -1;
      }

      byte var7 = var13;
      float var10001 = var7 * 0.56F;
      float var10002 = -0.52F + var5 * -0.6F;
      float var12 = -0.72F;
      float var11 = var10002;
      float var10 = var10001;
      MatrixStack var9 = var2;
      var9.translate(var10, var11, var12);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(46602280050594L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -6016387896375370413L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)172L,
            (byte)44161L,
            (byte)11305343L,
            (byte)2894167829L,
            (byte)740906964381L,
            (byte)189672182881686L,
            (byte)48556078817711645L,
            (byte)-6016387896375370413L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 9;
            yield var15;
         }
         case 1 -> {
            byte var16 = 13;
            yield var16;
         }
         case 2 -> {
            byte var17 = 37;
            yield var17;
         }
         case 3 -> {
            byte var18 = 35;
            yield var18;
         }
         case 4 -> {
            byte var19 = 44;
            yield var19;
         }
         case 5 -> {
            byte var20 = 56;
            yield var20;
         }
         case 6 -> {
            byte var21 = 12;
            yield var21;
         }
         case 7 -> {
            byte var22 = 46;
            yield var22;
         }
         case 8 -> {
            byte var23 = 10;
            yield var23;
         }
         case 9 -> {
            byte var24 = 22;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 11;
            yield var26;
         }
         case 12 -> {
            byte var27 = 40;
            yield var27;
         }
         case 13 -> {
            byte var28 = 38;
            yield var28;
         }
         case 14 -> {
            byte var29 = 53;
            yield var29;
         }
         case 15 -> {
            byte var30 = 0;
            yield var30;
         }
         case 16 -> {
            byte var31 = 6;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 20;
            yield var33;
         }
         case 19 -> {
            byte var34 = 15;
            yield var34;
         }
         case 20 -> {
            byte var35 = 33;
            yield var35;
         }
         case 21 -> {
            byte var36 = 17;
            yield var36;
         }
         case 22 -> {
            byte var37 = 39;
            yield var37;
         }
         case 23 -> {
            byte var38 = 28;
            yield var38;
         }
         case 24 -> {
            byte var39 = 55;
            yield var39;
         }
         case 25 -> {
            byte var40 = 7;
            yield var40;
         }
         case 26 -> {
            byte var41 = 16;
            yield var41;
         }
         case 27 -> {
            byte var42 = 23;
            yield var42;
         }
         case 28 -> {
            byte var43 = 18;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 2;
            yield var45;
         }
         case 31 -> {
            byte var46 = 31;
            yield var46;
         }
         case 32 -> {
            byte var47 = 25;
            yield var47;
         }
         case 33 -> {
            byte var48 = 26;
            yield var48;
         }
         case 34 -> {
            byte var49 = 4;
            yield var49;
         }
         case 35 -> {
            byte var50 = 29;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 36;
            yield var52;
         }
         case 38 -> {
            byte var53 = 58;
            yield var53;
         }
         case 39 -> {
            byte var54 = 52;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 8;
            yield var56;
         }
         case 42 -> {
            byte var57 = 34;
            yield var57;
         }
         case 43 -> {
            byte var58 = 51;
            yield var58;
         }
         case 44 -> {
            byte var59 = 3;
            yield var59;
         }
         case 45 -> {
            byte var60 = 57;
            yield var60;
         }
         case 46 -> {
            byte var61 = 60;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 45;
            yield var64;
         }
         case 50 -> {
            byte var65 = 24;
            yield var65;
         }
         case 51 -> {
            byte var66 = 47;
            yield var66;
         }
         case 52 -> {
            byte var67 = 43;
            yield var67;
         }
         case 53 -> {
            byte var68 = 63;
            yield var68;
         }
         case 54 -> {
            byte var69 = 50;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 27;
            yield var71;
         }
         case 57 -> {
            byte var72 = 48;
            yield var72;
         }
         case 58 -> {
            byte var73 = 61;
            yield var73;
         }
         case 59 -> {
            byte var74 = 32;
            yield var74;
         }
         case 60 -> {
            byte var75 = 41;
            yield var75;
         }
         case 61 -> {
            byte var76 = 62;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 54;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "O\u0017y;/\u0014Y\u0017|a<\u0003N\\\u007fg0\u0017_\u001bhp{\u0000|";
      m[1] = "Dp^huQ1PUgd\u001eP^^l`D$";
      m[2] = void.class;
      n[2] = "java/lang/Void";
      m[3] = "\u007f\n>,\u0010Di\n;v\u0003S~A8p\u000fGo\u0006/gDVk";
      m[4] = "\u0000-O|7\u0013u\rDs&\\\u0014\u0003Ox\"\u0006`";
      m[5] = "<s9h\u0014a<s.4\u0018n&8.*\u0018{!I|uI>";
      m[6] = " #xkUJ #o7YE:ho)YP=\u0019;}\u000b\u0010";
      m[7] = "?~M\u0015E]?~ZIIR%5ZWIG\"D\u000e\u000f\u001e";
      m[8] = "\u001eKVV^\t\u001eKA\nR\u0006\u0004\u0000A\u0014R\u0013\u0003q\u0013O\nY";
      m[9] = "-P\u000b\u0018ah-P\u001cDmg7\u001b\u001cZmr0jL\u0003?3";
      m[10] = double.class;
      n[10] = "java/lang/Double";
      m[11] = float.class;
      n[11] = "java/lang/Float";
      m[12] = "c#\t-\u00047a=@R\u001b9x4\u001cm\u00077b7";
      m[13] = "^u\u0002\u0019mGHu\u0007C~P_>\u0004ErDNy\u0013R9V\u007f";
      m[14] = int.class;
      n[14] = "java/lang/Integer";
      m[15] = " \bhck(6\bm9x?!Cn?t+0\u0004y(?<\u0002";
      m[16] = "p6\u00070_e{9\u0016\u007f>kp2\u0012%";
      m[17] = "\u0019;J\u000fl\u000e\u00124[@\u000b\f\u0007?[\u000b0";
      m[18] = "ok`Tx1\u001aKk[i~{E`Pm$\u000f";
      m[19] = "7py\nY\b<\u007fhE:\u0005)rg.\u000f\u00078a{\u0002\u0018\n";
      m[20] = "\u0012\\&\u0002:N\u0012\\1^6A\b\u00171@6T\u000ffa\u001dg";
      m[21] = "R'jU\blR'}\t\u0004cHl}\u0017\u0004vO\u001d*N]2";
      m[22] = "DZ\u0007Oh8FDN0w6_M\u0012\u000fk8EN\u0003";
      m[23] = "2&_e%JG\u0006Tj4\u0005&\b_a0_R";
      m[24] = "\u0019\u0007fL&Tl'mC7\u001b\r)fH3Ay";
      m[25] = "\u001c'{\u00115\f\n'~K&\u001b\u001dl}M*\u000f\f+jZa\u001f\u0017";
      m[26] = "\n\u001b]v{*\u007f;Vyje\u001e5]rn?j";
      m[27] = boolean.class;
      n[27] = "java/lang/Boolean";
      m[28] = "8}(Vc}.}-\fpj96.\n|~(q9\u001d7F";
      m[29] = "m5VC\u0003d\u0018\u0015]L\u0012+y\u001bVG\u0016q\r";
      m[30] = "\u001ce0<n\u0015iE;3\u007fZ\bK08{\u0000|";
      m[31] = "4;Bh)&A\u001bIg8i \u0015Bl<3T";
      m[32] = "\u000f8:o3Bz\u00181`\"\r\u001b\u0016:k&Wo";
      m[33] = "k\\Pm2\u0012\u001e|[b#]\u007frPi'\u0007\u000b";
      m[34] = "\u00055N/\f*p\u0015E \u001de\u0011\u001bN+\u0019?e";
      m[35] = "Mt\u0015 F\rMt\u0002|J\u0002W?\u0002bJ\u0017PNY7\u0013";
      m[36] = "Za.\u00147\u0019Za9H;\u0016@*9V;\u0003G[m\u000fc";
      m[37] = "n\u0019Q\u000e|Ke\u0016@A\u0010Hk\u0014B\u000e<";
      m[38] = "Z`\u0016%^>[\u007f[{nl8f^t\u0003?J0H)\r\u0006\u0001r^+T8\u0007kW.n";
      m[39] = "&\f=\u0014D#j\u0016<U;3\u0017X:\u0006V?e\u0013x\u0005EY";
      m[40] = "\u0016.4y\u0011\tCy;hx\u001dK} \u007f/O\u0012/}-xO\u0014`.z\u0002\u001aCo?";
      m[41] = "x\u000f\u001f=>fy\u0010Rc\u000e7\u001a\tWlcgh_A1m^#\u001dW34`%\u0004^6\u000e";
      m[42] = "TC[\u000b|M\u0018YZJ\u0003\\e\u0017\\\u0019nQ\u0017\\\u001e\u001a}7";
      m[43] = "\u0012>fO^ER71_=T\f`9KTX5n9[P>\nymOW\u0004\u0014{'@=";
      m[44] = "8a.N=J9~c\u0010\r\u0019Zgf\u001f`K(1pBnrcsf@7LejoE\r";
      m[45] = "r+IW\u0015q$6\u0017@%s\u001b>EUWu\u007f%ASG\u001a";
      m[46] = "\tj(\u000e\rG\f'(\u0005qO\u0005d\tW\u0015S\u000e\u0018fE\u001bC\u0005j-\u0007\u0018Pc";
      m[47] = "{5'\u0014y\u001c}w6\u0002B\u0007Ah3W/W3>%\n!n~v&\u00010\u001czo)_B";
      m[48] = "J\u001d\"\u001f\n(\u0019@t\u00184w\u0019\u0004-\u001cXEMEvF\t\u0012K\u0000!\u001cF`O\u0019.B4-\f\u0014*\tF)\u0015\u001bt{";
      m[49] = "\u000fp\u0000C\u001d[\u001fnS\u000e,\n\u0003s\u0007\u001e{]]$_r\u0010\u0016Z/\tI]T\u001f}";
      m[50] = "\u001f\u0014\u0006[NW\u001e\u000bK\u0005~\u0005}\u0012N\n\u0013V\u000fDXW\u001doB\f[\\\f\u001dF\u0015T\u0002~";
      m[51] = "\u0014p6\b/LOw,\u0019J]Nz9\u0015\u001d\r\u0016'fyqTDf8\u0006*S^w";
      m[52] = "T/ik\u0003\u0006X64sh\u001aT.es\u0004(\u0003h4,W\u007fW-xyP\u001bPn9phFK+k.V@R\"n\u0014";
      m[53] = ",5+ne4*w:x^/\u0016h?-3\u007fd>)p=F{s*c5?wjw{^";
      m[54] = "&cbrs\u007fjyc3\fl\u0017`g;a<e6qfo\u0005.tgd6;(mna\f";
      m[55] = "W\u001c\u0016!^\u0018\u0002K\u001907\f\nO\u0002'`^S\u001d_{7^UR\f\"M\u000b\u0002]\u001d";
      m[56] = "Y\t\u0013e\u0000AI\u0017@(1\u001bY\u001b\u00103])\rZNm1\u0019QV\u001ao\u000e\u0010Q\u0001\u0002T";
      m[57] = "V\u0003\u00022yX\u0003T\r#\u0010L\u000bP\u00164G\u001eR\u0002Kd\u0010\u001eTM\u00181jK\u0003B\t";
      m[58] = "1\\#Jf\t8\\tR]S;ErG1aj\u0002)\u001bc6.]`ElIk\u0004,\u0010]";
      m[59] = "- -A\u001f4$'lz\u001bMza\"\u0017@?,w\u007f\u0019ytna}@Grwhxz";
      m[60] = "'D)?DY!\u00068)\u007fB\u001d\u0019=|\u0012\u0012oO+!\u001c+&\u0018/<\u001aT}\u001f5-\u007f";
      m[61] = "WeL\u001c*XVz\u0001B\u001a\f5c\u0004MwYG5\u0012\u0010y`\fw\u0004\u0012 ^\nn\r\u0017\u001a";
      m[62] = "PkKn3\u0010\u001d)\u000e<YN\u0001e\u001385|R!O`Y\u0016\b K2:\u0016T|\u0013_";
      m[63] = "E;\u0014{h3\u0016fB|Vl\u0016\"\u001bx:^Bc@ j\tD0\u0006ofy\u001a1\u0007#V6\u00032\u001cm$2\u001a=B\u001f";
      m[64] = "\u0018~1,\u000e{M)>=g{C<(:\u0006fB\f,)\u001dlI;Ay\u001fmC23}\u0006b\u001d@q(^zO-'v\u001ee$";
      m[65] = "b{J4 \u0001k|\u000b\u000f/x?'\td%\u0007#'\u001e2F\u00147>\u001fl9\b7)I\u000f";
      m[66] = "[jg~UsZu* e\"9l//\brK:9r\u0006K\u0006r:y\u00179\u0002k5'e";
      m[67] = "=]\u000ba=:p\u001fN3WdlSS7;V?\u0017\faW<e\u0016\u000b=4<9JSP";
      m[68] = ":]'\u0018?s6Dz\u0000To:\\+\u00008]k\u001ew^j\nhX'\u0000&xlA(^T5/L,\u0015&16Crgkr;G9\u0015ok4\u0019K^&s9\u001auX?z< ";
      m[69] = "j\"y~p7a>ka\u000b#\n j>fsxv|chJk8#fapu:ii\u000b";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1159161542856631L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1159161542856631L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1159161542856631L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 106;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 119;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 216;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 105;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 186;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 238;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 106;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 119;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 216;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dW_C0207",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dW" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
