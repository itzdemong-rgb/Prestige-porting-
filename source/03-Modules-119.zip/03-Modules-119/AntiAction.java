package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

public class AntiAction extends Module {
   private BooleanSetting d;
   private BooleanSetting a;
   private BooleanSetting c;
   private BooleanSetting e;
   private BooleanSetting f;
   private static final long k = 45065694967228L;
   private static final Object[] l = new Object[72];
   private static final String[] m = new String[72];

   @EventListener
   public void a(ItemUseEvent var1) {
      boolean var225;

      int var16;
      MinecraftClient var115;
      label184: {
         label187: {
            long var10001 = 104612798223984L ^ 87936909692971L;
            var10001 = 104612798223984L ^ 128076325543913L;
            var10001 = 104612798223984L ^ 97420751640451L;
            var10001 = 104612798223984L ^ 110138177411312L;
            var10001 = 104612798223984L ^ 15013522978305L;
            var10001 = 104612798223984L ^ 115419869048265L;
            var16 = Event.cReturningInt();
            BooleanSetting var21 = this.e;
            Boolean var22 = (Boolean)var21.aReturningObject();
            boolean var10000 = var22;
            int var149 = var16;
            boolean var148 = var10000;
            boolean var108 = var148;
            boolean var107 = var148;
            if (var149 != 0) {
               boolean var150 = var107;
               if (!var150) {
                  break label187;
               }

               Object[] var24 = new Object[]{Items.FIREWORK_ROCKET, 8519502184947L};
               boolean var151 = InventoryUtil.lReturningBoolean(var24);
               var108 = var151;
            }

            int var153 = var16;
            boolean var152 = var108;
            boolean var110 = var152;
            boolean var109 = var152;
            if (var153 != 0) {
               boolean var154 = var109;
               if (!var154) {
                  break label187;
               }

               Object[] var27 = new Object[]{18551992649307L};
               boolean var155 = RaycastUtil.aReturningBoolean(var27);
               var110 = var155;
            }

            int var157 = var16;
            boolean var156 = var110;
            boolean var114 = var156;
            boolean var111 = var156;
            if (var157 != 0) {
               boolean var158 = var111;
               if (var158) {
                  break label187;
               }

               int var160 = var16;
               MinecraftClient var159 = b;
               var115 = var159;
               MinecraftClient var112 = var159;
               if (var160 == 0) {
                  break label184;
               }

               MinecraftClient var161 = var112;
               MinecraftClient var113 = var161;
               MinecraftClient var31 = var113;
               ClientPlayerEntity var32 = var31.player;
               ItemStack var227 = var32.getOffHandStack();
               Item var34 = Items.CROSSBOW;
               ItemStack var33 = var227;
               boolean var162 = var33.isOf(var34);
               var114 = var162;
            }

            boolean var163 = var114;
            if (!var163) {
               Object[] var37 = new Object[0];
               ItemUseEvent var36 = var1;
               var36.aReturningVoid(var37);
               return;
            }
         }

         var115 = b;
      }

      MinecraftClient var39 = var115;
      HitResult var18 = var39.crosshairTarget;
      int var165 = var16;
      HitResult var164 = var18;
      HitResult var117 = var164;
      HitResult var116 = var164;
      if (var165 != 0) {
         boolean var166 = var116 instanceof BlockHitResult;
         if (!var166) {
            return;
         }

         HitResult var167 = var18;
         var117 = var167;
      }

      BlockHitResult var17 = (BlockHitResult)var117;
      int var168 = var16;
      if (var168 != 0) {
         BlockHitResult var43 = var17;
         BlockPos var228 = var43.getBlockPos();
         int var170 = var16;
         BlockPos var169 = var228;
         BlockPos var119 = var169;
         BlockPos var118 = var169;
         if (var170 != 0) {
            BlockPos var171 = var118;
            if (var171 == null) {
               return;
            }

            BlockHitResult var45 = var17;
            var119 = var45.getBlockPos();
         }

         int var129;
         label156: {
            byte var128;
            Object[] var46 = new Object[]{var119, Blocks.RESPAWN_ANCHOR, 90720632922225L};
            var225 = BlockUtil.bReturningBoolean(var46);
            int var173 = var16;
            byte var172 = ((byte)((var225) ? 1 : 0));
            var128 = var172;
            byte var120 = var172;
            label155:
            if (var173 != 0) {
               byte var174 = var120;
               if (var174 != 0) {
                  BooleanSetting var48 = this.d;
                  Boolean var49 = (Boolean)var48.aReturningObject();
                  byte var229 = ((byte)(((java.lang.Boolean)(var49)).booleanValue() ? 1 : 0));
                  int var176 = var16;
                  byte var175 = var229;
                  var128 = var175;
                  byte var121 = var175;
                  if (var176 == 0) {
                     break label155;
                  }

                  byte var177 = var121;
                  byte var122 = var177;
                  byte var178 = var122;
                  if (var178 != 0) {
                     MinecraftClient var52 = b;
                     ClientPlayerEntity var53 = var52.player;
                     byte var230 = ((byte)((var53.isSneaking()) ? 1 : 0));
                     int var180 = var16;
                     byte var179 = var230;
                     var128 = var179;
                     byte var123 = var179;
                     if (var180 == 0) {
                        break label155;
                     }

                     byte var181 = var123;
                     byte var124 = var181;
                     byte var182 = var124;
                     if (var182 == 0) {
                        Object[] var56 = new Object[]{Items.GLOWSTONE, 8519502184947L};
                        byte var231 = ((byte)((InventoryUtil.lReturningBoolean(var56)) ? 1 : 0));
                        int var184 = var16;
                        byte var183 = var231;
                        var128 = var183;
                        byte var125 = var183;
                        if (var184 == 0) {
                           break label155;
                        }

                        byte var185 = var125;
                        byte var126 = var185;
                        byte var186 = var126;
                        if (var186 != 0) {
                           BlockHitResult var59 = var17;
                           Object[] var60 = new Object[]{var59.getBlockPos(), 61419523816377L};
                           int var19 = BlockUtil.aReturningInt(var60);
                           int var188 = var16;
                           int var187 = var19;
                           var129 = var187;
                           int var127 = var187;
                           if (var188 == 0) {
                              break label156;
                           }

                           int var189 = var127;
                           if (var189 != 0) {
                              Object[] var63 = new Object[0];
                              ItemUseEvent var62 = var1;
                              var62.aReturningVoid(var63);
                           }
                        }
                     }
                  }
               }

               BlockHitResult var65 = var17;
               Object[] var66 = new Object[]{var65.getBlockPos(), Blocks.ENDER_CHEST, 90720632922225L};
               var128 = ((byte)((BlockUtil.bReturningBoolean(var66)) ? 1 : 0));
            }

            byte var226 = var128;
            var129 = var226;
         }

         int var139;
         int var191 = var16;
         int var190 = var129;
         var139 = var190;
         int var130 = var190;
         label138:
         if (var191 != 0) {
            int var192 = var130;
            if (var192 != 0) {
               BooleanSetting var68 = this.a;
               Boolean var69 = (Boolean)var68.aReturningObject();
               byte var232 = ((byte)(((java.lang.Boolean)(var69)).booleanValue() ? 1 : 0));
               int var194 = var16;
               byte var193 = var232;
               var139 = var193;
               byte var131 = var193;
               if (var194 == 0) {
                  break label138;
               }

               byte var195 = var131;
               byte var132 = var195;
               byte var196 = var132;
               if (var196 != 0) {
                  MinecraftClient var72 = b;
                  ClientPlayerEntity var73 = var72.player;
                  byte var233 = ((byte)((var73.isSneaking()) ? 1 : 0));
                  int var198 = var16;
                  byte var197 = var233;
                  var139 = var197;
                  byte var133 = var197;
                  if (var198 == 0) {
                     break label138;
                  }

                  byte var199 = var133;
                  byte var134 = var199;
                  byte var200 = var134;
                  label132:
                  if (var200 == 0) {
                     label190: {
                        MinecraftClient var76 = b;
                        ClientPlayerEntity var77 = var76.player;
                        Object[] var79 = new Object[]{var77.getMainHandStack(), 47661374638489L};
                        AntiAction var78 = this;
                        byte var234 = ((byte)((var78.aReturningBoolean(var79)) ? 1 : 0));
                        int var202 = var16;
                        byte var201 = var234;
                        byte var137 = var201;
                        byte var135 = var201;
                        if (var202 != 0) {
                           byte var203 = var135;
                           byte var136 = var203;
                           byte var204 = var136;
                           if (var204 != 0) {
                              break label190;
                           }

                           MinecraftClient var82 = b;
                           ClientPlayerEntity var83 = var82.player;
                           Object[] var85 = new Object[]{var83.getOffHandStack(), 47661374638489L};
                           AntiAction var84 = this;
                           byte var205 = ((byte)((var84.aReturningBoolean(var85)) ? 1 : 0));
                           var137 = var205;
                        }

                        int var207 = var16;
                        byte var206 = var137;
                        var139 = var206;
                        byte var138 = var206;
                        if (var207 == 0) {
                           break label138;
                        }

                        byte var208 = var138;
                        if (var208 == 0) {
                           break label132;
                        }
                     }

                     Object[] var89 = new Object[0];
                     ItemUseEvent var88 = var1;
                     var88.aReturningVoid(var89);
                  }
               }
            }

            Object[] var91 = new Object[]{Items.GLOWSTONE, 8519502184947L};
            var139 = (((InventoryUtil.lReturningBoolean(var91)) ? 1 : 0));
         }

         int var20 = var139;
         int var210 = var16;
         int var209 = var20;
         int var141 = var209;
         int var140 = var209;
         if (var210 != 0) {
            int var211 = var140;
            if (var211 == 0) {
               return;
            }

            var141 = (((var225) ? 1 : 0));
         }

         int var145;
         int var213 = var16;
         int var212 = var141;
         var145 = var212;
         int var142 = var212;
         label111:
         if (var213 != 0) {
            int var214 = var142;
            if (var214 != 0) {
               MinecraftClient var94 = b;
               ClientPlayerEntity var95 = var94.player;
               byte var235 = ((byte)((var95.isSneaking()) ? 1 : 0));
               int var216 = var16;
               byte var215 = var235;
               var145 = var215;
               byte var143 = var215;
               if (var216 == 0) {
                  break label111;
               }

               byte var217 = var143;
               byte var144 = var217;
               byte var218 = var144;
               if (var218 == 0) {
                  return;
               }
            }

            BooleanSetting var98 = this.c;
            Boolean var99 = (Boolean)var98.aReturningObject();
            byte var219 = ((byte)(((java.lang.Boolean)(var99)).booleanValue() ? 1 : 0));
            var145 = var219;
         }

         int var221 = var16;
         int var220 = var145;
         int var147 = var220;
         int var146 = var220;
         if (var221 != 0) {
            int var222 = var146;
            if (var222 == 0) {
               return;
            }

            BlockHitResult var102 = var17;
            Object[] var103 = new Object[]{var102.getBlockPos(), 64933905403520L};
            byte var223 = ((byte)((BlockUtil.eReturningBoolean(var103)) ? 1 : 0));
            var147 = var223;
         }

         int var224 = var147;
         if (var224 != 0) {
            Object[] var106 = new Object[0];
            ItemUseEvent var105 = var1;
            var105.aReturningVoid(var106);
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      ItemStack var4 = (ItemStack)var1[0];
      long var2 = (Long)var1[1];
      var2 = 45065694967228L ^ var2;
      long var5 = var2 ^ 12347231019083L;
      long var7 = var2 ^ 89047382457667L;
      long var9 = var2 ^ 19873200694169L;
      int var11 = Event.bReturningInt();
      ItemStack var12 = var4;
      byte var10000 = ((byte)((var12.isEmpty()) ? 1 : 0));
      int var67 = var11;
      byte var66 = var10000;
      byte var45 = var66;
      byte var44 = var66;
      if (var67 == 0) {
         byte var68 = var44;
         if (var68 != 0) {
            return false;
         }

         Object[] var15 = new Object[]{var4, var9};
         var45 = ((byte)((InventoryUtil.aReturningBoolean(var15)) ? 1 : 0));
      }

      int var70 = var11;
      byte var69 = var45;
      byte var51 = var69;
      byte var46 = var69;
      if (var70 == 0) {
         byte var71 = var46;
         if (var71 == 0) {
            Object[] var17 = new Object[]{var4, var5};
            var10000 = ((byte)((InventoryUtil.bReturningBoolean(var17)) ? 1 : 0));
            int var73 = var11;
            byte var72 = var10000;
            var51 = var72;
            byte var47 = var72;
            if (var73 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var51);
            }

            byte var74 = var47;
            byte var48 = var74;
            byte var75 = var48;
            label85:
            if (var75 == 0) {
               Object[] var20 = new Object[]{var4, var7};
               var10000 = ((byte)((InventoryUtil.o(var20)) ? 1 : 0));
               int var77 = var11;
               byte var76 = var10000;
               byte var52 = var76;
               byte var49 = var76;
               if (var77 == 0) {
                  byte var78 = var49;
                  byte var50 = var78;
                  byte var79 = var50;
                  if (var79 != 0) {
                     break label85;
                  }

                  Item var24 = Items.END_CRYSTAL;
                  ItemStack var23 = var4;
                  var52 = ((byte)((var23.isOf(var24)) ? 1 : 0));
               }

               int var81 = var11;
               byte var80 = var52;
               byte var64 = var80;
               byte var53 = var80;
               if (var81 == 0) {
                  byte var82 = var53;
                  if (var82 == 0) {
                     Item var27 = Items.OBSIDIAN;
                     ItemStack var26 = var4;
                     byte var107 = ((byte)((var26.isOf(var27)) ? 1 : 0));
                     int var84 = var11;
                     boolean var83 = dev.prestige.recovery.SourceSupport.asBoolean(var107);
                     byte var113 = ((byte)((var83) ? 1 : 0));
                     boolean var54 = var83;
                     if (var84 != 0) {
                        return dev.prestige.recovery.SourceSupport.asBoolean(var113);
                     }

                     boolean var85 = var54;
                     boolean var55 = var85;
                     boolean var86 = var55;
                     if (!var86) {
                        Item var31 = Items.CRYING_OBSIDIAN;
                        ItemStack var30 = var4;
                        var107 = ((byte)((var30.isOf(var31)) ? 1 : 0));
                        int var88 = var11;
                        boolean var87 = ((((int)(var107) & 1) != 0));
                        var113 = ((byte)((var87) ? 1 : 0));
                        boolean var56 = var87;
                        if (var88 != 0) {
                           return ((((int)(var113) & 1) != 0));
                        }

                        boolean var89 = var56;
                        boolean var57 = var89;
                        boolean var90 = var57;
                        if (!var90) {
                           Item var35 = Items.TOTEM_OF_UNDYING;
                           ItemStack var34 = var4;
                           var107 = ((byte)((var34.isOf(var35)) ? 1 : 0));
                           int var92 = var11;
                           boolean var91 = ((((int)(var107) & 1) != 0));
                           var113 = ((byte)((var91) ? 1 : 0));
                           boolean var58 = var91;
                           if (var92 != 0) {
                              return ((((int)(var113) & 1) != 0));
                           }

                           boolean var93 = var58;
                           boolean var59 = var93;
                           boolean var94 = var59;
                           if (!var94) {
                              Item var39 = Items.EXPERIENCE_BOTTLE;
                              ItemStack var38 = var4;
                              var107 = ((byte)((var38.isOf(var39)) ? 1 : 0));
                              int var96 = var11;
                              boolean var95 = ((((int)(var107) & 1) != 0));
                              var113 = ((byte)((var95) ? 1 : 0));
                              boolean var60 = var95;
                              if (var96 != 0) {
                                 return ((((int)(var113) & 1) != 0));
                              }

                              boolean var97 = var60;
                              boolean var61 = var97;
                              boolean var98 = var61;
                              if (!var98) {
                                 Item var43 = Items.GLOWSTONE;
                                 ItemStack var42 = var4;
                                 var107 = ((byte)((var42.isOf(var43)) ? 1 : 0));
                                 int var100 = var11;
                                 byte var99 = var107;
                                 var113 = var99;
                                 byte var62 = var99;
                                 if (var100 != 0) {
                                    return dev.prestige.recovery.SourceSupport.asBoolean(var113);
                                 }

                                 byte var101 = var62;
                                 byte var63 = var101;
                                 byte var102 = var63;
                                 if (var102 == 0) {
                                    return false;
                                 }
                              }
                           }
                        }
                     }
                  }

                  var64 = 1;
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var64);
            }
         }

         var51 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var51);
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 68074592746480L ^ 48788228613196L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var10 = b;
      HitResult var8 = var10.crosshairTarget;
      int var6 = var10000;
      int var45 = var6;
      HitResult var44 = var8;
      HitResult var35 = var44;
      HitResult var34 = var44;
      if (var45 == 0) {
         boolean var46 = var34 instanceof EntityHitResult;
         if (!var46) {
            return;
         }

         HitResult var47 = var8;
         var35 = var47;
      }

      EntityHitResult var7 = (EntityHitResult)var35;
      int var48 = var6;
      if (var48 == 0) {
         EntityHitResult var14 = var7;
         Entity var9 = var14.getEntity();
         int var50 = var6;
         Entity var49 = var9;
         Entity var37 = var49;
         Entity var36 = var49;
         if (var50 == 0) {
            boolean var51 = var36 instanceof PlayerEntity;
            if (!var51) {
               return;
            }

            Entity var52 = var9;
            var37 = var52;
         }

         PlayerEntity var66 = (PlayerEntity)var37;
         BooleanSetting var17 = this.f;
         Boolean var18 = (Boolean)var17.aReturningObject();
         boolean var67 = var18;
         int var54 = var6;
         boolean var53 = var67;
         boolean var39 = var53;
         boolean var38 = var53;
         if (var54 == 0) {
            boolean var55 = var38;
            if (!var55) {
               return;
            }

            MinecraftClient var20 = b;
            ClientPlayerEntity var21 = var20.player;
            Object[] var22 = new Object[]{var21.getMainHandStack(), 19476550655932L};
            boolean var56 = InventoryUtil.aReturningBoolean(var22);
            var39 = var56;
         }

         int var58 = var6;
         boolean var57 = var39;
         boolean var41 = var57;
         boolean var40 = var57;
         if (var58 == 0) {
            boolean var59 = var40;
            if (!var59) {
               return;
            }

            PlayerEntity var25 = var66;
            boolean var60 = var25.isUsingItem();
            var41 = var60;
         }

         int var62 = var6;
         boolean var61 = var41;
         boolean var43 = var61;
         boolean var42 = var61;
         if (var62 == 0) {
            boolean var63 = var42;
            if (!var63) {
               return;
            }

            PlayerEntity var28 = var66;
            ItemStack var68 = var28.getActiveItem();
            Item var30 = Items.SHIELD;
            ItemStack var29 = var68;
            boolean var64 = var29.isOf(var30);
            var43 = var64;
         }

         boolean var65 = var43;
         if (var65) {
            Object[] var33 = new Object[0];
            AttackInputEvent var32 = var1;
            var32.aReturningVoid(var33);
         }
      }
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 0;
            yield var15;
         }
         case 1 -> {
            byte var16 = 27;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 14;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 42;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 53;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 7;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 3;
            yield var27;
         }
         case 13 -> {
            byte var28 = 19;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 17;
            yield var30;
         }
         case 16 -> {
            byte var31 = 43;
            yield var31;
         }
         case 17 -> {
            byte var32 = 28;
            yield var32;
         }
         case 18 -> {
            byte var33 = 61;
            yield var33;
         }
         case 19 -> {
            byte var34 = 55;
            yield var34;
         }
         case 20 -> {
            byte var35 = 62;
            yield var35;
         }
         case 21 -> {
            byte var36 = 58;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 21;
            yield var38;
         }
         case 24 -> {
            byte var39 = 18;
            yield var39;
         }
         case 25 -> {
            byte var40 = 44;
            yield var40;
         }
         case 26 -> {
            byte var41 = 5;
            yield var41;
         }
         case 27 -> {
            byte var42 = 46;
            yield var42;
         }
         case 28 -> {
            byte var43 = 25;
            yield var43;
         }
         case 29 -> {
            byte var44 = 50;
            yield var44;
         }
         case 30 -> {
            byte var45 = 16;
            yield var45;
         }
         case 31 -> {
            byte var46 = 8;
            yield var46;
         }
         case 32 -> {
            byte var47 = 51;
            yield var47;
         }
         case 33 -> {
            byte var48 = 47;
            yield var48;
         }
         case 34 -> {
            byte var49 = 48;
            yield var49;
         }
         case 35 -> {
            byte var50 = 2;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 59;
            yield var52;
         }
         case 38 -> {
            byte var53 = 22;
            yield var53;
         }
         case 39 -> {
            byte var54 = 54;
            yield var54;
         }
         case 40 -> {
            byte var55 = 29;
            yield var55;
         }
         case 41 -> {
            byte var56 = 26;
            yield var56;
         }
         case 42 -> {
            byte var57 = 56;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 9;
            yield var59;
         }
         case 45 -> {
            byte var60 = 40;
            yield var60;
         }
         case 46 -> {
            byte var61 = 57;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 33;
            yield var63;
         }
         case 49 -> {
            byte var64 = 30;
            yield var64;
         }
         case 50 -> {
            byte var65 = 23;
            yield var65;
         }
         case 51 -> {
            byte var66 = 10;
            yield var66;
         }
         case 52 -> {
            byte var67 = 45;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 35;
            yield var69;
         }
         case 55 -> {
            byte var70 = 20;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 39;
            yield var72;
         }
         case 58 -> {
            byte var73 = 13;
            yield var73;
         }
         case 59 -> {
            byte var74 = 60;
            yield var74;
         }
         case 60 -> {
            byte var75 = 63;
            yield var75;
         }
         case 61 -> {
            byte var76 = 11;
            yield var76;
         }
         case 62 -> {
            byte var77 = 15;
            yield var77;
         }
         default -> 49;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "5\u0013cRMM#\u0013f\b^Z4Xe\u000eRN%\u001fr\u0019\u0019Y\t";
      l[1] = "44x~8z?;i1[w*6fZnu;%zvyx";
      l[2] = "\t^\u0019CJ|\u001f^\u001c\u0019Yk\b\u0015\u001f\u001fU\u007f\u0019R\b\b\u001em(";
      l[3] = int.class;
      m[3] = "java/lang/Integer";
      l[4] = ")0&5&n)01i*a3{1w*t4\ne/}";
      l[5] = ">JcF\u001c*>Jt\u001a\u0010%$\u0001t\u0004\u00100#p&_Hz";
      l[6] = "9-Z\u0010x=2\"K_\u0014>< I\u00108";
      l[7] = boolean.class;
      m[7] = "java/lang/Boolean";
      l[8] = "j2\u0014xMOj2\u0003$A@py\u0003:AUw\bSg\u0010";
      l[9] = "Fp&%9UFp1y5Z\\;1g5O[J`8m";
      l[10] = "N)\u0000tf\\N)\u0017(jSTb\u00176jFS\u0013Gc=\u0003";
      l[11] = "p*%~{\u0014p*2\"w\u001bja2<w\u000em\u0010`b/J";
      l[12] = "m\u0003lz6J{\u0003i %]lHj&)I}\u000f}1b^O";
      l[13] = "\u001e\u000b)X\u0007\u0019\u0015\u00048\u0017f\u0017\u001e\u000f<M";
      l[14] = ";?y6+{;?nj't!tnt'a&\u0005<.s%";
      l[15] = "\u0007OV_\u0007H\u0007OA\u0003\u000bG\u001d\u0004A\u001d\u000bR\u001au\u0013IZ\u0013";
      l[16] = "\u001b\u0018\u0007(\u001bP\u001b\u0018\u0010t\u0017_\u0001S\u0010j\u0017J\u0006\"B1O\u000b";
      l[17] = "\u0007_~y\n^r\u007fuv\u001b\u0011\u0013q~}\u001fKg";
      l[18] = void.class;
      m[18] = "java/lang/Void";
      l[19] = " $9Q<Z6$<\u000b/M!o?\r#Y0((\u001ahI+";
      l[20] = "I\u0003(un,<##z\u007fc]-(q{9)";
      l[21] = "}=&l&\u0011\b\u001d-c7^i\u0013&h3\u0004\u001d";
      l[22] = "&D\u0017>\u0017\u0012Sd\u001c1\u0006]2j\u0017:\u0002\u0007F";
      l[23] = "\u0014\u00103\b)P\u0002\u00106R:G\u0015[5T6S\u0004\u001c\"C}A\u001c";
      l[24] = "\u00130;TJ|f\u00100[[3\u0007\u001e;P_is";
      l[25] = "dZqSmc\u0011zz\\|,ptqWxv\u0004";
      l[26] = "\u000ex-\fc#{X&\u0003rl\u001aV-\bv6n";
      l[27] = "pN6\u0006\u0011}\u0005n=\t\u00002d`6\u0002\u0004h\u0010";
      l[28] = "d_pM=\u000ed_g\u00111\u0001~\u0014g\u000f1\u0014ye6QdQ";
      l[29] = "!Sj\u001e59!S}B96;\u0018}\\9#<i,\u0002lh";
      l[30] = "\u001b\u0010T[ Z\r\u0010Q\u00013M\u001a[R\u0007?Y\u000b\u001cE\u0010tIL";
      l[31] = "\u001e\"\u0011v\u0006rk\u0002\u001ay\u0017=\n\f\u0011r\u0013g~";
      l[32] = "\u0002d^_eO\u0002dI\u0003i@\u0018/I\u001diU\u001f^\u0019H>\u0013";
      l[33] = "DVAM\u0015)DVV\u0011\u0019&^\u001dV\u000f\u00193Yl\u0007PKx";
      l[34] = "\u0014>r'\u0004na\u001ey(\u0015!\u0000\u0010r#\u0011{t";
      l[35] = "Dk$N\u0012\u0017\u0019&yr\u0011zAgd\u0002C\u0018\u00056,MxCE#mI\u001a\u0007\u0014k\"r";
      l[36] = "4'f\u0010qD=\u007fd@\u000f\u0013\r{j\u0018>\u0017p8fB0y";
      l[37] = "sW$Mo%xO=^Rv{C$N\u0005( \u001e\u007f\"8&*\u001f}\\9jwR";
      l[38] = "aSazlU|\u0019lv\u0014Yc\u00048*C\r9Pa|\u0014T>\u0014.))U=\u000b\"";
      l[39] = "i(}\u0017=mtbp\u001bEak\u007f$G\u001262.|\u0010El6o2Dxm5p>";
      l[40] = "\f\u001dw)=%G\u0002kbL-Z\u0013z4 \u001f\b^$kLu\n\u0015a<.&\u000f\u0001xS";
      l[41] = "V\u0000o|?o\u001cA<{[w\u0000F7{7EP\u0005n![/P@,s9|UT5\u001c";
      l[42] = "\u0005\u001aFA\u007f:I\u0004\u0016[N!^\u0007LV'-g\tLF#K\u0004]R@!)WXFYN";
      l[43] = "\u001c]CKf!\u0015\u0005A\u001b\u0018w%\u0001OC)rXBC\u0019'\u001c";
      l[44] = "SG}f8\u0012]_\u007fyU\nc\u0011::e\u000f\u001c_\u007f}hc";
      l[45] = "-\u001b0_O\u00025\u001aw\u00012\u0005)\roY^7zI4\u00062[6\u001cuO_\u0010)\u0000>>";
      l[46] = "v_m={48\u0019~<\u0019:)\bb4Nmw_:X\"np\u0005b%h/#\u0002";
      l[47] = "t3\u0015\u00175\u001bt \u0007\u0017\r\u001a\u0018:\u0005\u00022\u0019yd\u0016Pap%a\r\u0014b\u0012vd\u0019\r\r";
      l[48] = "\u0011\u001cR]\u0011D\u001a\u0004KN,\u0017\u0019\bR^{IC]\u000f2FGHT\u000bLG\u000b\u0015\u0019";
      l[49] = "o\nF7|\u0007fRDg\u0002SV\n]k=S7TN9n:=\u000fVbi\u000b8PRo\u0002";
      l[50] = "r\u0013O_#bvC\u0015\u0015Ah\u0016\u0019\u0004B~hwG\u0017\u0010-\u0001+B\fT.cxG\u0018MA";
      l[51] = "S\u001fH\nZO\u000e\u001c\u000b\u001c(\u0014[\fV\tD&\u000fO\tQ\u0017qP\u001a\\TPHJL\u000f\u001e(";
      l[52] = "qMs-Bpg\u0015}:8`\u001eBj1\u0007`\u007f\u001cycT\t$A!mVtgM{c8";
      l[53] = "\u0019BjEP \u0012ZsVms\u0011VjF:'J\u00074\u0013mwN\u000b?\u0017\u0013v\u0002Vr";
      l[54] = "y%g\u000e2ar=~\u001d\u000f2q1g\rXl+m2aeb m>\u001fd.} ";
      l[55] = "\"/]&?(\"<O&\u0007$N&M38*/x^akCs}E%h! xQ<\u0007";
      l[56] = "~Z\u0012\t\u0001\fh\u0002\u001c\u001e{\u0018\u0011U\u000b\u0015D\u001cp\u000b\u0018G\u0017u,\u000e\u0003\u0003\u0014\u0017\u007f\u000b\u0017\u001a{";
      l[57] = ",Pa\u0005u\t,Cs\u0005M\u0006@Yq\u0010r\u000b!\u0007bB!b}\u0002y\u0006\"\u0000.\u0007m\u001fM";
      l[58] = "\u001cd?o\u0015\u000e\n<1xo\u001dsk&sP\u001e\u001255!\u0003wN0.e\u0000\u0015\u001d5:|o";
      l[59] = "AUD$/$\u001c\u0018\u0019\u0018,I\u001b\u0016\u0010',(E\u0005BtEt@\u001e\u0006w''E\n\u001f\u0018";
      l[60] = "XB,KI\"\u0012\u0003\u007fL-:\u000e\u0004tLA\b]@(\u0014-d\u0011\u0015nZ@/\u000e\t%+";
      l[61] = "f5w\u007fCsm-nl~ n!w|)~5|#\u0010\u0014p?}.n\u0015<b0";
      l[62] = "%ijt~U.qsgC\u0006-}jw\u0014Xv 7\u001b)V|!3e(\u001a!l";
      l[63] = "w\u000b\u000b>{\u001d9M\u0018?\u0019\u0013(\\\u00047NDv\u000f]['\u001c2O\u001b>`\u0011-L";
      l[64] = "pg\u0013\u000e\b`\u007foP]h4\"vH\u000b\u0004\u0006v5\u0017\\RQ\u007fcQRP?$p\u0017Vh";
      l[65] = "\u0004X&kL!\u000f@?xqr\fL&h&,S\u001as\u0004\u001b\"]\u0010\u007fz\u001an\u0000]";
      l[66] = "xI|\fk\u0012sQe\u001fVAp]|\u000f\u0001\u001f+\r%c<\u0011!\u0001%\u001d=]|L";
      l[67] = ">r\u0012K`\u0018t3AL\u0004\u0000h4JLh2;p\u0015\u001a\u0004^w%PZi\u0015h9\u001b+";
      l[68] = "qCg\u001d?\u0012:\\{VN\u001a'Mj\u0000\"(q\b7Xr\u007f \u000f:Vs\u0001!Cg\u001bNBwKq\b,\u0011r_hg";
      l[69] = "wU7\t>*|M.\u001a\u0003y\u007fA7\nT'.\u0014jfi).\u001dn\u0018hesP";
      l[70] = "zb\u000bf+\u0005zq\u0019f\u0013\u0007\u0016k\u001bs,\u0007w5\b!\u007fn+0\u0013e|\fx5\u0007|\u0013";
      l[71] = "zS\u0010H4qbRW\u0016Iv~EON%D-\u0000\u0016\u0014I..CTF+}+WM)";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(985055798253821L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(985055798253821L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(985055798253821L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 65;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 81;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 234;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 117;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 241;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 65;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 81;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 234;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dX_C0209",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
