package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.PlayerValidationEvent;
import dev.zprestige.prestige.api.events.BotDetectionEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityPositionS2CPacket;
import net.minecraft.world.GameMode;

public class AntiBot extends Module {
   private MultiModeSetting a;
   private IntSetting c;
   private IntSetting d;
   private IntSetting e;
   private static final UUID f;
   private Map g;
   private static final long k = 16664609838854L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Long[] p;
   private static final Map q;
   private static final Object[] r = new Object[71];
   private static final String[] s = new String[71];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public AntiBot() {
      super();
      long var10001 = 41988748930979L ^ 1884954661953L;

      this.g = new IdentityHashMap();
      IntSetting var10000 = this.e;
      Object[] var6 = new Object[]{invokeBinding1(this), 43459238656994L};
      IntSetting var5 = var10000;
      var5.aReturningIntSetting(var6);
      var10000 = this.d;
      Object[] var8 = new Object[]{invokeBinding2(this), 43459238656994L};
      IntSetting var7 = var10000;
      var7.aReturningIntSetting(var8);
      var10000 = this.c;
      Object[] var10 = new Object[]{invokeBinding3(this), 43459238656994L};
      IntSetting var9 = var10000;
      var9.aReturningIntSetting(var10);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 39370738545316L ^ 42193302524139L;
      var10001 = 39370738545316L ^ 109078214666442L;
      int var8 = Event.bReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var14 = new Object[]{"Packet", 71444480285294L};
      MultiModeSetting var13 = var10000;
      boolean var91 = var13.aReturningBoolean(var14);
      int var67 = var8;
      boolean var66 = var91;
      boolean var56 = var66;
      boolean var55 = var66;
      if (var67 == 0) {
         boolean var68 = var55;
         if (!var68) {
            return;
         }

         Object[] var17 = new Object[0];
         PacketReceiveEvent var16 = var1;
         boolean var69 = var16.aReturningVoid(var17) instanceof EntityPositionS2CPacket;
         var56 = var69;
      }

      boolean var70 = var56;
      if (var70) {
         MinecraftClient var19 = b;
         int var72 = var8;
         ClientWorld var71 = var19.world;
         ClientWorld var59 = var71;
         ClientWorld var57 = var71;
         if (var72 == 0) {
            ClientWorld var73 = var57;
            ClientWorld var58 = var73;
            ClientWorld var74 = var58;
            if (var74 == null) {
               return;
            }

            MinecraftClient var22 = b;
            ClientWorld var75 = var22.world;
            var59 = var75;
         }

         Object[] var25 = new Object[0];
         PacketReceiveEvent var24 = var1;
         EntityPositionS2CPacket var26 = (EntityPositionS2CPacket)var24.aReturningVoid(var25);
         int var28 = var26.entityId();
         ClientWorld var27 = var59;
         Entity var9 = var27.getEntityById(var28);
         int var77 = var8;
         Entity var76 = var9;
         Entity var61 = var76;
         Entity var60 = var76;
         if (var77 == 0) {
            Entity var78 = var60;
            if (var78 == null) {
               return;
            }

            var61 = var9;
         }

         int var80 = var8;
         Entity var79 = var61;
         Entity var63 = var79;
         Entity var62 = var79;
         if (var80 == 0) {
            boolean var81 = var62 instanceof PlayerEntity;
            if (!var81) {
               return;
            }

            Entity var82 = var9;
            var63 = var82;
         }

         PlayerEntity var10 = (PlayerEntity)var63;
         PlayerValidationTracker var92 = Prestige.i;
         Object[] var33 = new Object[0];
         PlayerValidationTracker var32 = var92;
         Set var93 = var32.aReturningSet(var33);
         Entity var35 = var9;
         Set var34 = var93;
         byte var94 = ((byte)((var34.contains(var35)) ? 1 : 0));
         int var84 = var8;
         byte var83 = var94;
         int var65 = var83;
         byte var64 = var83;
         if (var84 == 0) {
            byte var85 = var64;
            if (var85 != 0) {
               return;
            }

            IntSetting var37 = this.c;
            Integer var38 = (Integer)var37.aReturningObject();
            int var86 = var38;
            var65 = var86;
         }

         int var12;
         label43: {
            int var11 = var65;
            Map var95 = this.g;
            Integer var43 = 0;
            PlayerEntity var42 = var10;
            Map var41 = var95;
            Integer var44 = ((java.lang.Integer)(Object)(var41.getOrDefault(var42, var43)));
            var12 = var44 + 1;
            int var87 = var8;
            if (var87 == 0) {
               int var89 = var11;
               int var88 = var12;
               if (var88 < var89) {
                  break label43;
               }

               PlayerValidationTracker var96 = Prestige.i;
               Object[] var47 = new Object[]{var10, 6121707119183L};
               PlayerValidationTracker var46 = var96;
               var46.aReturningVoid(var47);
               PlayerEntity var49 = var10;
               Map var48 = this.g;
               var48.remove(var49);
            }

            int var90 = var8;
            if (var90 == 0) {
               return;
            }
         }

         Map var97 = this.g;
         int var51 = var12;
         Integer var54 = var51;
         PlayerEntity var53 = var10;
         Map var52 = var97;
         var52.put(var53, var54);
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      Map var4 = this.g;
      var4.clear();
   }

   @EventListener
   public void a(TickEvent var1) {
      int var4 = Event.bReturningInt();
      Map var5 = this.g;
      boolean var10000 = var5.isEmpty();
      int var13 = var4;
      boolean var12 = var10000;
      boolean var10 = var12;
      if (var13 == 0) {
         boolean var14 = var10;
         if (!var14) {
            Map var7 = this.g;
            Set var16 = var7.keySet();
            Predicate var9 = invokeBinding4();
            Set var8 = var16;
            boolean var15 = var8.removeIf(var9);
         }
      }
   }

   @EventListener
   public void a(BotDetectionEvent var1) {
      Object[] var5 = new Object[0];
      BotDetectionEvent var4 = var1;
      var4.aReturningVoid(var5);
   }

   @EventListener
   public void a(PlayerValidationEvent var1) {
      label110: {
         int var6;
         PlayerEntity var7;
         UUID var8;
         label111: {
            long var10001 = 96661570795421L ^ 25373329419763L;
            int var10000 = Event.cReturningInt();
            Object[] var13 = new Object[0];
            PlayerValidationEvent var12 = var1;
            var7 = var12.aReturningPlayerEntity(var13);
            var6 = var10000;
            PlayerEntity var14 = var7;
            var8 = var14.getUuid();
            MultiModeSetting var133 = this.a;
            Object[] var16 = new Object[]{"UUID", 71444480285294L};
            MultiModeSetting var15 = var133;
            byte var134 = ((byte)((var15.aReturningBoolean(var16)) ? 1 : 0));
            int var87 = var6;
            byte var86 = var134;
            byte var64 = var86;
            byte var63 = var86;
            if (var87 != 0) {
               byte var88 = var63;
               if (var88 == 0) {
                  break label111;
               }

               UUID var19 = f;
               UUID var18 = var8;
               byte var89 = ((byte)((var18.equals(var19)) ? 1 : 0));
               var64 = var89;
            }

            int var91 = var6;
            byte var90 = var64;
            int var66 = var90;
            byte var65 = var90;
            if (var91 != 0) {
               byte var92 = var65;
               if (var92 != 0) {
                  break label110;
               }

               UUID var22 = var8;
               int var93 = var22.version();
               var66 = var93;
            }

            byte var95 = 4;
            int var94 = var66;
            if (var94 != var95) {
               break label110;
            }
         }

         PlayerListEntry var69;
         label95: {
            MinecraftClient var27 = b;
            ClientPlayNetworkHandler var135 = var27.getNetworkHandler();
            int var97 = var6;
            ClientPlayNetworkHandler var96 = var135;
            ClientPlayNetworkHandler var68 = var96;
            ClientPlayNetworkHandler var67 = var96;
            if (var97 != 0) {
               ClientPlayNetworkHandler var98 = var67;
               if (var98 == null) {
                  var69 = null;
                  break label95;
               }

               MinecraftClient var29 = b;
               ClientPlayNetworkHandler var99 = var29.getNetworkHandler();
               var68 = var99;
            }

            UUID var32 = var8;
            ClientPlayNetworkHandler var31 = var68;
            PlayerListEntry var100 = var31.getPlayerListEntry(var32);
            var69 = var100;
         }

         PlayerListEntry var9;
         int var73;
         var9 = var69;
         MultiModeSetting var136 = this.a;
         Object[] var34 = new Object[]{"TabList", 71444480285294L};
         MultiModeSetting var33 = var136;
         byte var137 = ((byte)((var33.aReturningBoolean(var34)) ? 1 : 0));
         int var102 = var6;
         byte var101 = var137;
         var73 = var101;
         byte var70 = var101;
         label89:
         if (var102 != 0) {
            byte var103 = var70;
            if (var103 != 0) {
               PlayerEntity var36 = var7;
               long var138 = var36.age * 50L;
               IntSetting var37 = this.d;
               Integer var38 = (Integer)var37.aReturningObject();
               long var142;
               int var139 = (var142 = var138 - var38.intValue()) == 0L ? 0 : (var142 < 0L ? -1 : 1);
               int var105 = var6;
               int var104 = var139;
               var73 = var104;
               int var71 = var104;
               if (var105 == 0) {
                  break label89;
               }

               int var106 = var71;
               int var72 = var106;
               int var107 = var72;
               if (var107 >= 0) {
                  PlayerListEntry var108 = var9;
                  if (var108 == null) {
                     Object[] var43 = new Object[0];
                     PlayerValidationEvent var42 = var1;
                     var42.aReturningVoid(var43);
                     return;
                  }
               }
            }

            var136 = this.a;
            Object[] var46 = new Object[]{"Ping", 71444480285294L};
            MultiModeSetting var45 = var136;
            var73 = (((var45.aReturningBoolean(var46)) ? 1 : 0));
         }

         int var109 = var73;
         if (var109 != 0) {
            int var111 = var6;
            PlayerListEntry var110 = var9;
            PlayerListEntry var76 = var110;
            PlayerListEntry var74 = var110;
            if (var111 != 0) {
               PlayerListEntry var112 = var74;
               PlayerListEntry var75 = var112;
               PlayerListEntry var113 = var75;
               if (var113 == null) {
                  return;
               }

               var76 = var9;
            }

            byte var81;
            label75: {
               label74: {
                  PlayerListEntry var49 = var76;
                  GameMode var10 = var49.getGameMode();
                  int var116 = var6;
                  GameMode var115 = GameMode.SURVIVAL;
                  GameMode var114 = var10;
                  GameMode var79 = var114;
                  GameMode var80 = var115;
                  GameMode var77 = var114;
                  GameMode var78 = var115;
                  if (var116 != 0) {
                     GameMode var118 = var78;
                     GameMode var117 = var77;
                     if (var117 == var118) {
                        break label74;
                     }

                     GameMode var120 = GameMode.ADVENTURE;
                     GameMode var119 = var10;
                     var79 = var119;
                     var80 = var120;
                  }

                  GameMode var122 = var80;
                  GameMode var121 = var79;
                  if (var121 != var122) {
                     var81 = 0;
                     break label75;
                  }
               }

               byte var123 = 1;
               var81 = var123;
            }

            byte var11 = var81;
            int var125 = var6;
            byte var124 = var11;
            int var83 = var124;
            byte var82 = var124;
            if (var125 != 0) {
               byte var126 = var82;
               if (var126 == 0) {
                  return;
               }

               PlayerListEntry var54 = var9;
               int var127 = var54.getLatency();
               var83 = var127;
            }

            int var129 = var6;
            int var128 = var83;
            int var85 = var128;
            int var84 = var128;
            if (var129 != 0) {
               int var130 = var84;
               if (var130 != 0) {
                  return;
               }

               PlayerEntity var57 = var7;
               long var141 = var57.age * 50L;
               IntSetting var58 = this.e;
               Integer var59 = (Integer)var58.aReturningObject();
               long var143;
               int var131 = (var143 = var141 - var59.intValue()) == 0L ? 0 : (var143 < 0L ? -1 : 1);
               var85 = var131;
            }

            int var132 = var85;
            if (var132 >= 0) {
               Object[] var62 = new Object[0];
               PlayerValidationEvent var61 = var1;
               var61.aReturningVoid(var62);
            }
         }

         return;
      }

      Object[] var25 = new Object[0];
      PlayerValidationEvent var24 = var1;
      var24.aReturningVoid(var25);
   }

   private static boolean lambda$onTick$3(PlayerEntity var0) {
      int var3 = Event.bReturningInt();
      PlayerEntity var4 = var0;
      byte var10000 = ((byte)((var4.isAlive()) ? 1 : 0));
      int var9 = var3;
      byte var8 = var10000;
      byte var6 = var8;
      byte var5 = var8;
      if (var9 == 0) {
         byte var10 = var5;
         if (var10 != 0) {
            return false;
         }

         var6 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var6);
   }

   private boolean lambda$new$2(Integer var1) {
      long var10001 = 96216842600120L ^ 25805445342422L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Ping", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$1(Integer var1) {
      long var10001 = 22852349267520L ^ 92577163858990L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"TabList", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$0(Integer var1) {
      long var10001 = 12431718500665L ^ 83236649964375L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Packet", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   static {

      {

      f();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(82632445927006L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[7];
      String var15 = "\u00106 ä tQä\u00ad\rÆ\u0087(~\u0094¾\u0010Õ¸\u009c'F¦=:c\u0012¶bû¯#E\u0010N<2<Uóqc\r\n9Ñ\u0084\u0006V\u0010\u0010\u0085dÕK`¦è  \u0088\u0097´ Ñ+Q\u0010\u0099\u001f!\u0083g*¢hÇ\u0094\u00178\u001c}÷\u0019";
      int var17 = "\u00106 ä tQä\u00ad\rÆ\u0087(~\u0094¾\u0010Õ¸\u009c'F¦=:c\u0012¶bû¯#E\u0010N<2<Uóqc\r\n9Ñ\u0084\u0006V\u0010\u0010\u0085dÕK`¦è  \u0088\u0097´ Ñ+Q\u0010\u0099\u001f!\u0083g*¢hÇ\u0094\u00178\u001c}÷\u0019"
         .length();
      char var14 = 16;
      int var22 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var22, var22 + var14);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var11.doFinal(var23.getBytes("ISO-8859-1"));
            String var34 = b(var19).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var34;
                  if ((var22 += var14) >= var17) {
                     l = var18;
                     m = new String[7];
                     q = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(82632445927006L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     String var4 = "¯ipc¤ùV¦\u009bü³ÃË[\u008b%";
                     int var5 = "¯ipc¤ùV¦\u009bü³ÃË[\u008b%".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var38 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var38;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var43 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var41) {
                              case 0:
                                 var26[var10001] = var43;
                                 if (var2 >= var5) {
                                    o = var6;
                                    p = new Long[4];
                                    f = new UUID(0L, 0L);
                                    break;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var43;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "Óþ\u007f\u0015vygBÈúä\u0081©²\u009c3";
                                 var5 = "Óþ\u007f\u0015vygBÈúä\u0081©²\u009c3".length();
                                 var2 = 0;
                           }

                           int var32 = var2;
                           var2 += 8;
                           var7 = var4.substring(var32, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var38 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var41 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var22);
                  break;
               default:
                  var18[var16++] = var34;
                  if ((var22 += var14) < var17) {
                     var14 = var15.charAt(var22);
                     continue label54;
                  }

                  var15 = "æÝè,\u0018\u008d\u00ad¹ñ\u0098¡\u0098ù\nÌ \u0010\u00865bo\u0097_NZ\u001cüôÿ9ÙN3";
                  var17 = "æÝè,\u0018\u008d\u00ad¹ñ\u0098¡\u0098ù\nÌ \u0010\u00865bo\u0097_NZ\u001cüôÿ9ÙN3".length();
                  var14 = 16;
                  var22 = -1;
            }

            var23 = var15.substring(++var22, var22 + var14);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27303;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dY", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dY_C0211",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dY" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29648;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dY", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dY_C0211",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dY" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 25;
            yield var15;
         }
         case 1 -> {
            byte var16 = 37;
            yield var16;
         }
         case 2 -> {
            byte var17 = 4;
            yield var17;
         }
         case 3 -> {
            byte var18 = 42;
            yield var18;
         }
         case 4 -> {
            byte var19 = 3;
            yield var19;
         }
         case 5 -> {
            byte var20 = 61;
            yield var20;
         }
         case 6 -> {
            byte var21 = 26;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 55;
            yield var23;
         }
         case 9 -> {
            byte var24 = 17;
            yield var24;
         }
         case 10 -> {
            byte var25 = 39;
            yield var25;
         }
         case 11 -> {
            byte var26 = 46;
            yield var26;
         }
         case 12 -> {
            byte var27 = 51;
            yield var27;
         }
         case 13 -> {
            byte var28 = 43;
            yield var28;
         }
         case 14 -> {
            byte var29 = 24;
            yield var29;
         }
         case 15 -> {
            byte var30 = 52;
            yield var30;
         }
         case 16 -> {
            byte var31 = 0;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 35;
            yield var33;
         }
         case 19 -> {
            byte var34 = 45;
            yield var34;
         }
         case 20 -> {
            byte var35 = 7;
            yield var35;
         }
         case 21 -> {
            byte var36 = 20;
            yield var36;
         }
         case 22 -> {
            byte var37 = 63;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 48;
            yield var39;
         }
         case 25 -> {
            byte var40 = 12;
            yield var40;
         }
         case 26 -> {
            byte var41 = 50;
            yield var41;
         }
         case 27 -> {
            byte var42 = 47;
            yield var42;
         }
         case 28 -> {
            byte var43 = 8;
            yield var43;
         }
         case 29 -> {
            byte var44 = 53;
            yield var44;
         }
         case 30 -> {
            byte var45 = 15;
            yield var45;
         }
         case 31 -> {
            byte var46 = 28;
            yield var46;
         }
         case 32 -> {
            byte var47 = 32;
            yield var47;
         }
         case 33 -> {
            byte var48 = 30;
            yield var48;
         }
         case 34 -> {
            byte var49 = 27;
            yield var49;
         }
         case 35 -> {
            byte var50 = 1;
            yield var50;
         }
         case 36 -> {
            byte var51 = 23;
            yield var51;
         }
         case 37 -> {
            byte var52 = 58;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 16;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 5;
            yield var56;
         }
         case 42 -> {
            byte var57 = 6;
            yield var57;
         }
         case 43 -> {
            byte var58 = 40;
            yield var58;
         }
         case 44 -> {
            byte var59 = 36;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 22;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 38;
            yield var64;
         }
         case 50 -> {
            byte var65 = 14;
            yield var65;
         }
         case 51 -> {
            byte var66 = 57;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 60;
            yield var68;
         }
         case 54 -> {
            byte var69 = 54;
            yield var69;
         }
         case 55 -> {
            byte var70 = 33;
            yield var70;
         }
         case 56 -> {
            byte var71 = 9;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 10;
            yield var73;
         }
         case 59 -> {
            byte var74 = 31;
            yield var74;
         }
         case 60 -> {
            byte var75 = 18;
            yield var75;
         }
         case 61 -> {
            byte var76 = 59;
            yield var76;
         }
         case 62 -> {
            byte var77 = 56;
            yield var77;
         }
         default -> 49;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "}&)/\u001c_c.3`\u007fKg";
      r[1] = void.class;
      s[1] = "java/lang/Void";
      r[2] = "\u0016\u0018F\u000fK\u001d\u0000\u0018CUX\n\u0017S@ST\u001e\u0006\u0014WD\u001f\t9";
      r[3] = "{rM6Zv\u000eRF9K9o\\M2Oc\u001b";
      r[4] = "\u0014A-\u001579\u0002A(O$.\u0015\n+I(:\u0004M<^c->";
      r[5] = "+@hGe\u0001^`cHtN?nhCp\u0014K";
      r[6] = boolean.class;
      s[6] = "java/lang/Boolean";
      r[7] = "V\u001co?\u0004\"V\u001cxc\b-LWx}\b8K&*'\\|";
      r[8] = "S@3J-sMH)\u0005VSpe";
      r[9] = "X\u001d5\u001a\u0001(X\u001d\"F\r'BV\"X\r2E'w\u0000\\";
      r[10] = "+O5#P\u0012+O\"\u007f\\\u001d1\u0004\"a\\\b6up4\u000eO";
      r[11] = "F2\":vEM=3u\u0017KF67/";
      r[12] = int.class;
      s[12] = "java/lang/Integer";
      r[13] = "-3N\u000e\u0014T-3YR\u0018[7xYL\u0018N0\t\f\u0013M";
      r[14] = "w\u0011%7E?a\u0011 mV(vZ#kZ<g\u001d4|\u0011.V";
      r[15] = "\\TM7qj\\TZk}eF\u001fZu}pAn\n(,";
      r[16] = "'H\u001c\u0001w\u000e1H\u0019[d\u0019&\u0003\u001a]h\r7D\rJ#\u001f\u0005";
      r[17] = "$\u001bTno*Q;_a~e05Tjz?D";
      r[18] = "MR!I/c[R$\u0013<tL\u0019'\u00150`]^0\u0002{wo";
      r[19] = "$G\u000bN\u000e\u0014/H\u001a\u0001i\u0016:C\u001aJR";
      r[20] = "Bet5[U7E\u007f:J\u001aVKt1N@\"";
      r[21] = ",5g6f]:5bluJ-~ajy^<9v}2I\u0011";
      r[22] = "\u001d\u0018w5W*\u0016\u0017fz4'\u0003\u001ai\u0011\u0001%\u0012\tu=\u0016(";
      r[23] = ",\u0018yls\u001a2\u0010c#\u000e\n2";
      r[24] = "<\u0004PTVP\"\fJ\u001b\u001eP8\u0006R\\\u0017Kx5TP\u001cL5\u0004RP";
      r[25] = "\u0004 26?q\u0012 7l,f\u0005k4j r\u0014,#}kb\f,!v1/07!k1h\u0007 ";
      r[26] = "9WJ%M1/WO\u007f^&8\u001cLyR2)[[n\u0019 ;";
      r[27] = "\f\u0005;P]Ry%0_L\u001d\u0018+;THGl";
      r[28] = "^dZ\u000b\u0017\u0015^dMW\u001b\u001aD/MI\u001b\u000fC^\u0018\u0016B";
      r[29] = "\u001c\u000em\u000e\\ni.f\u0001M!\b m\nI{|";
      r[30] = "\u0002;[sGe\u0002;L/Kj\u0018pL1K\u007f\u001f\u0001\u001dj\u001d;";
      r[31] = "ao;ay>ao,=u1{$,#u$|U~}-`";
      r[32] = "!<\u0007^jL7<\u0002\u0004y[ w\u0001\u0002uO10\u0016\u0015>^!";
      r[33] = "cEb6\u001d\u0000\u0016ei9\fOwkb2\b\u0015\u0003";
      r[34] = ":J\u000b\u001d\f$:J\u001cA\u0000+ \u0001\u001c_\u0000>'pM\u0006X{";
      r[35] = "$\u0007$\u0012BIr\u0006&T=AtC\"\u000bQs$\u0001|S=\u0019aQ9\u001e\rJkF%l";
      r[36] = "\r\u001b1}5Y\u0003\u000b;zH\u0005^\rkp$7\t@6'H_]\u00016-(\u0010WNm\u0017";
      r[37] = "5\u0012hS.\u001c-\u00131XB\u0011U\u0016`R#\u0010k\u0014n\u0018'";
      r[38] = "\rEB~zO\u000fK\bz\u001a\u0018lM\u0003a \u0001VLGsjq\u0003A\u0004nbI\u0005NRt\u001a";
      r[39] = "C9{mN\t\u0000o|2!\u0018x`&|\u001b\u0001BabnQqDa,gGM\ni\"n!";
      r[40] = "pP6/`\u001c R=5\u000f\u0013\u0019X)+3I!\u0013==>y";
      r[41] = "^\u0002_\u001cf!X\r\t\u0006\u001ec\\\r\u0004\u0013sX_h\f\u001fw\"\r\u0017\u0001\\f)1T\u0004\\{\u007f\r\u001a\fRr\u0019";
      r[42] = "\"9r\u000fV)-2ulZk\u00007q\u0010J\u0010q58\t],?=6\u0000;";
      r[43] = "m@mVk\u000f=BfL\u0004\u0001\u0004HrR8Z<\u0003fD5j";
      r[44] = "<\u0002N\u0006p-2\u001e\nZ\n*8\u001d\u0013^f\u0018l\\M\u0003\n~k\u000bO\u0003gr$\f\u00129";
      r[45] = "\u0001i){6NQ}vmQFj(5z?\u0013\u000bfr4n/";
      r[46] = "~5kqMJl.qe3At0_rW]\u007fL1fK\u001c\"tzr]\u0011\u0012";
      r[47] = "?P$VZC#Y2\u0016aS<[%0Z\u0002`\u0001]W\u001c@g\u000ee\u001c\bVj>";
      r[48] = "\u0006\t\u0002o\t\f\u001fYGgf\u0010\bL^k\n\"U\f\u0000=fE\u0018H\u0002<^\u000e\f^\u000f\f\u0003M\t\r\u000f2\u001e\u0011\u0006\u0001>";
      r[49] = ")k,T$Kyi'NKG@5uVq^z41D;.;> C\"\u0014\u007f0w(";
      r[50] = "g\u0000\b\u007fs 3_H`N \tP\u0017q\u007f3`]\u0011+$IgY\u001a*4 j_@qN";
      r[51] = "eDI(@\"jONKWvoHL&-$u_\\wLj2\u0011\rK\u0012dzA\u000e*\\#4\u00102";
      r[52] = "M1SS\u001d\u0000_*IGc\u0014H,DT$\u0004!xDA_Z\u00193PWRjM1SS\u001d\u0000_*IGc";
      r[53] = "]\u0011\rb>~\u000b\u0010\u000f$Av\rU\u000b{-D]\u0019S!A/\u0007\u0018\u000ez}a\u000f\u0016\u0007\u001c";
      r[54] = "]/o\n34R$hi1`N\u0003n%3c[9p\u0015^2M4zU?|\nz+iarB*(\b/5\f{\u0014V!}\\xu\u0018f3\rD";
      r[55] = "\nzWm\u0004VYp@qv\u000bN\u007fPr\rf\b}IxJ\u0007F:\u0007)vZP3\\pJ\u0014X=U\u0016";
      r[56] = ".fZ]_\u0019 vPZ\"E}p\u0000PNw*=]\u0006\"\u0010mt\\\u0007\u001a[ybQ7";
      r[57] = "V\u00015S\u00190\u0019\u000bz\b#>\b\u0002!\u0002taSVxn\u001c>\u0019R\u007f\u000eS4V\t";
      r[58] = "\fx3!jg\u000074|PoP:9z<]\u0007vf$P7E(\"o`dO?>\u001dn`\u0007,$$`p\r+Y";
      r[59] = "c(\u0006m-`c|\u0002h\u00157\tq\u0006(/.3pB:e^4/[(j3b.Yn\u0015";
      r[60] = "]e\u001aP\rs\u000eo\rL\u007f=\rg\u000fJ\u0018%`-\tSCsXf\u001dENC";
      r[61] = "y\u0017\\pY\u0006w\u000b\u0018,#\nq\u0019\u0005#t].D^O@],\u0017\u000e6Y\ri\u001f";
      r[62] = "li~!\u001c0ng4%|g\ra?>F~7`{,\f\u000evjj+\u001542d=@";
      r[63] = "-slopm\"xk\f~93Czp\u001d;($ft%='r|\f";
      r[64] = "??\u0019fH\u0014?.Wf,L\u0006+Sz\u0016U<*\u0017h\\%??\u0019fH\u0014?.Wf,";
      r[65] = ",^,#1\f*Qz9I_$Rl;(R84/-9Z\u007fUajw\u000bC\bwc,R\u007fF\u007fm%4";
      r[66] = "?.o,i&0%hOo{=,nO\u007fr>.}u;|iE";
      r[67] = "=U\u0012$6kkT\u0010bIha\u0000\u00106\u001e88TNZy{xQDb2on\\";
      r[68] = "S\u0013\u001aq\tM\t\u001eYl`\u00146\u001c\u001eiZ\r\f\u001dZ{\u0010}QENm]\u001aS\u0007Zy`";
      r[69] = "pL\u001f]m1?FP\u0006W?.O\u000b\f\u0000`u\u001bQ`h??\u001fU\u0000'5pD";
      r[70] = "_$\u0007v\u0004\bP/\u0000\u0015\u0011LLOCj\u0019_\f.\r-W\u000e0p\u0003e\u0007\rQ>D+V1\u000f0\f{UPAwB*i";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(803814156552031L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(803814156552031L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(803814156552031L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 221;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 118;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 71;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 87;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 82;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 221;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 118;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 71;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dY_C0211",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dY" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AntiBot var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dY_C0211;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dY_C0211", "lambda$new$2", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AntiBot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AntiBot var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dY_C0211;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dY_C0211", "lambda$new$1", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AntiBot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AntiBot var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dY_C0211;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/dY_C0211", "lambda$new$0", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AntiBot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/dY_C0211", "lambda$onTick$3", "(Lnet/minecraft/entity/player/PlayerEntity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/player/PlayerEntity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
