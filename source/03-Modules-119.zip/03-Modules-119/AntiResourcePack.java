package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.util.PacketUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.common.ResourcePackStatusC2SPacket;
import net.minecraft.network.packet.c2s.common.ResourcePackStatusC2SPacket.Status;
import net.minecraft.network.packet.s2c.common.ResourcePackSendS2CPacket;

public class AntiResourcePack extends Module {
   private static final long k = 52284274785639L;
   private static final Object[] l = new Object[25];
   private static final String[] m = new String[25];

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 114396913904640L ^ 5361176332228L;
      int var6 = Event.cReturningInt();
      int var22 = var6;
      PacketReceiveEvent var21 = var1;
      PacketReceiveEvent var20 = var21;
      PacketReceiveEvent var19 = var21;
      if (var22 != 0) {
         Object[] var8 = new Object[0];
         PacketReceiveEvent var7 = var19;
         boolean var23 = var7.aReturningVoid(var8) instanceof ResourcePackSendS2CPacket;
         if (!var23) {
            return;
         }

         PacketReceiveEvent var24 = var1;
         var20 = var24;
      }

      Object[] var12 = new Object[0];
      PacketReceiveEvent var11 = var20;
      var11.aReturningVoid(var12);
      MinecraftClient var13 = b;
      ClientPlayerEntity var14 = var13.player;
      Object[] var15 = new Object[]{new ResourcePackStatusC2SPacket(var14.getUuid(), Status.ACCEPTED), 119757183937476L};
      PacketUtil.aReturningVoid(var15);
      MinecraftClient var16 = b;
      ClientPlayerEntity var17 = var16.player;
      Object[] var18 = new Object[]{new ResourcePackStatusC2SPacket(var17.getUuid(), Status.SUCCESSFULLY_LOADED), 119757183937476L};
      PacketUtil.aReturningVoid(var18);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 30;
            yield var15;
         }
         case 1 -> {
            byte var16 = 56;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 3;
            yield var18;
         }
         case 4 -> {
            byte var19 = 32;
            yield var19;
         }
         case 5 -> {
            byte var20 = 19;
            yield var20;
         }
         case 6 -> {
            byte var21 = 20;
            yield var21;
         }
         case 7 -> {
            byte var22 = 46;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 33;
            yield var28;
         }
         case 14 -> {
            byte var29 = 45;
            yield var29;
         }
         case 15 -> {
            byte var30 = 31;
            yield var30;
         }
         case 16 -> {
            byte var31 = 5;
            yield var31;
         }
         case 17 -> {
            byte var32 = 38;
            yield var32;
         }
         case 18 -> {
            byte var33 = 59;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 29;
            yield var35;
         }
         case 21 -> {
            byte var36 = 36;
            yield var36;
         }
         case 22 -> {
            byte var37 = 18;
            yield var37;
         }
         case 23 -> {
            byte var38 = 43;
            yield var38;
         }
         case 24 -> {
            byte var39 = 27;
            yield var39;
         }
         case 25 -> {
            byte var40 = 35;
            yield var40;
         }
         case 26 -> {
            byte var41 = 22;
            yield var41;
         }
         case 27 -> {
            byte var42 = 4;
            yield var42;
         }
         case 28 -> {
            byte var43 = 50;
            yield var43;
         }
         case 29 -> {
            byte var44 = 16;
            yield var44;
         }
         case 30 -> {
            byte var45 = 0;
            yield var45;
         }
         case 31 -> {
            byte var46 = 6;
            yield var46;
         }
         case 32 -> {
            byte var47 = 55;
            yield var47;
         }
         case 33 -> {
            byte var48 = 62;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 47;
            yield var50;
         }
         case 36 -> {
            byte var51 = 60;
            yield var51;
         }
         case 37 -> {
            byte var52 = 7;
            yield var52;
         }
         case 38 -> {
            byte var53 = 52;
            yield var53;
         }
         case 39 -> {
            byte var54 = 42;
            yield var54;
         }
         case 40 -> {
            byte var55 = 49;
            yield var55;
         }
         case 41 -> {
            byte var56 = 17;
            yield var56;
         }
         case 42 -> {
            byte var57 = 39;
            yield var57;
         }
         case 43 -> {
            byte var58 = 58;
            yield var58;
         }
         case 44 -> {
            byte var59 = 11;
            yield var59;
         }
         case 45 -> {
            byte var60 = 1;
            yield var60;
         }
         case 46 -> {
            byte var61 = 2;
            yield var61;
         }
         case 47 -> {
            byte var62 = 53;
            yield var62;
         }
         case 48 -> {
            byte var63 = 25;
            yield var63;
         }
         case 49 -> {
            byte var64 = 13;
            yield var64;
         }
         case 50 -> {
            byte var65 = 15;
            yield var65;
         }
         case 51 -> {
            byte var66 = 41;
            yield var66;
         }
         case 52 -> {
            byte var67 = 9;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 21;
            yield var69;
         }
         case 55 -> {
            byte var70 = 40;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 37;
            yield var72;
         }
         case 58 -> {
            byte var73 = 26;
            yield var73;
         }
         case 59 -> {
            byte var74 = 14;
            yield var74;
         }
         case 60 -> {
            byte var75 = 23;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 54;
            yield var77;
         }
         default -> 28;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u0006C@}',\u0006CW!+#\u001c\bW?+6\u001by\u0006k\u007fsLEX2967\u0014\ff}";
      l[1] = "q\u0002r6r6g\u0002wla!pItjm5a\u000ec}&'P";
      l[2] = int.class;
      m[2] = "java/lang/Integer";
      l[3] = "E;\u001bb\u001cLS;\u001e8\u000f[Dp\u001d>\u0003OU7\n)HX{";
      l[4] = "w%\u007f3\u0015\u0016|*n|v\u001bi'a\u0017C\u0019x4};T\u0014";
      l[5] = "a/\u0016d$Oa/\u00018(@{d\u0001&(U|\u0015U~\u007f";
      l[6] = "\u001fO\tA\u000e,\u0001G\u0013\u000eu\f<j";
      l[7] = "c+Ono\u0013c+X2c\u001cy`X,c\t~\u0011\bq2";
      l[8] = "\u0007] #\f\u0004\u0011]%y\u001f\u0013\u0006\u0016&\u007f\u0013\u0007\u0017Q1hX\u0016\u0007";
      l[9] = "\u0010\u0014Nl^*e4EcOe\u0004:NhK?p";
      l[10] = "cs2!t;cs%}x4y8%cx!~It: d";
      l[11] = "La\u0015U..9A\u001eZ?aXO\u0015Q;;,";
      l[12] = void.class;
      m[12] = "java/lang/Void";
      l[13] = "\rrn*\u007f3\u001brkpl$\f9hv`0\u001d~\u007fa+ Y";
      l[14] = "\u0010\u0011\u0006p\u001b#e1\r\u007f\nl\u0004?\u0006t\u000e6p";
      l[15] = "fk:9{Zmd+v\u001aTfo/,";
      l[16] = "v\u00156%U\u0016~\u0015 \u0019XHr\u000f0N\u000f\u0012'Rb\u0019_WuW?&WWc";
      l[17] = "\u001b~A\u0012\u001b%\\ySOw}M|MD\u001bO\u001d>\u0013\u001cw$\\cCL\u0010rNlD#";
      l[18] = "\u0015s}O\u001d*\u0010 |\u0001}uI'%\u0013*\"\u0017p}\u007fFeD{-B\u0001bV&";
      l[19] = "\u000e`*I2\u0003\b.2HQ\u000b0o%Pa\u001a@91]<b\u000fd&W3\u001dP?:JQ";
      l[20] = "J0\u0007\u0018r_\\|\u000fr`:\u0001~]BqJWjP\u001f\t\n];Y\u0012fCT:Mr";
      l[21] = " J !1\t(J6\u001d<W$P&Jk\rq\ru\u001d;H#\b)\"3H5";
      l[22] = "A\u0013#Dt&W_+.dC\u0002Ne\u0012v&R\u0018x@\u000f";
      l[23] = "\u001aS`tOz\u0019_a6#s Y?/\u001bfC\u001b>r\u0013\u001a\u001bYar_yYX<z#";
      l[24] = ">\rZVXGlW\u000e\u0014&_\u000f^N\n\u0016N\u007f\bZ\u0007K6?\u0002\u000b\u000eFYv\u000b\n\u001a&";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1083061839820107L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1083061839820107L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1083061839820107L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 165;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 67;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 118;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 226;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 241;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 120;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 165;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 67;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 118;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dZ_C0213",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dZ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
