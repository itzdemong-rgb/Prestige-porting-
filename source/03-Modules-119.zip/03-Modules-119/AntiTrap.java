package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Category;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.vehicle.AbstractBoatEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.SignEditorOpenS2CPacket;

public class AntiTrap extends Module {
   private static final String a;
   private static final String c;
   private static final String d;
   private static final String e;
   private static final String f;
   private MultiModeSetting g;
   private FloatSetting h;
   private BooleanSetting i;
   private BooleanSetting j;
   private BooleanSetting k;
   private static final long l = 5649774813068L;
   private static final String[] m;
   private static final String[] n;
   private static final Map o = new HashMap(13);
   private static final Object[] p = new Object[94];
   private static final String[] q = new String[94];

   public AntiTrap() {
      super("AntiTrap", "Hides entities commonly used to bait trap-TPAs (armor stands, minecarts, etc).", Category.Misc.ordinal());
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var6;
      boolean var56;
      long var10001 = 7675043032732L ^ 20520623091509L;
      var6 = Event.cReturningInt();
      BooleanSetting var15 = this.k;
      Boolean var16 = (Boolean)var15.aReturningObject();
      boolean var10000 = var16;
      int var60 = var6;
      boolean var59 = var10000;
      var56 = var59;
      boolean var53 = var59;
      label54:
      if (var60 != 0) {
         boolean var61 = var53;
         if (var61) {
            Object[] var19 = new Object[0];
            PacketReceiveEvent var18 = var1;
            var10000 = var18.aReturningVoid(var19) instanceof SignEditorOpenS2CPacket;
            int var63 = var6;
            boolean var62 = var10000;
            var56 = var62;
            boolean var54 = var62;
            if (var63 == 0) {
               break label54;
            }

            boolean var64 = var54;
            boolean var55 = var64;
            boolean var65 = var55;
            if (var65) {
               Object[] var23 = new Object[0];
               PacketReceiveEvent var22 = var1;
               var22.aReturningVoid(var23);
               return;
            }
         }

         BooleanSetting var25 = this.i;
         Boolean var26 = (Boolean)var25.aReturningObject();
         var56 = var26;
      }

      boolean var66 = var56;
      if (var66) {
         Object[] var28 = new Object[0];
         PacketReceiveEvent var27 = var1;
         Packet var8 = var27.aReturningVoid(var28);
         int var68 = var6;
         Packet var67 = var8;
         Packet var58 = var67;
         Packet var57 = var67;
         if (var68 != 0) {
            boolean var69 = var57 instanceof EntitySpawnS2CPacket;
            if (!var69) {
               return;
            }

            Packet var70 = var8;
            var58 = var70;
         }

         EntitySpawnS2CPacket var7 = (EntitySpawnS2CPacket)var58;
         int var71 = var6;
         if (var71 != 0) {
            MinecraftClient var32 = b;
            ClientPlayerEntity var72 = var32.player;
            if (var72 != null) {
               EntitySpawnS2CPacket var34 = var7;
               Object[] var36 = new Object[]{var34.getEntityType(), 22347390484905L};
               AntiTrap var35 = this;
               boolean var73 = var35.dReturningBoolean(var36);
               if (var73) {
                  EntitySpawnS2CPacket var38 = var7;
                  double var78 = var38.getX();
                  MinecraftClient var39 = b;
                  ClientPlayerEntity var40 = var39.player;
                  double var76 = var78 - var40.getX();
                  EntitySpawnS2CPacket var41 = var7;
                  double var79 = var41.getY();
                  MinecraftClient var42 = b;
                  ClientPlayerEntity var43 = var42.player;
                  double var10 = var79 - var43.getY();
                  EntitySpawnS2CPacket var44 = var7;
                  double var80 = var44.getZ();
                  MinecraftClient var45 = b;
                  ClientPlayerEntity var46 = var45.player;
                  double var12 = var80 - var46.getZ();
                  FloatSetting var47 = this.h;
                  Float var48 = (Float)var47.aReturningObject();
                  float var14 = var48;
                  int var74 = var6;
                  if (var74 != 0) {
                     double var81;
                     int var75 = (var81 = var76 * var76 + var10 * var10 + var12 * var12 - var14 * var14) == 0.0 ? 0 : (var81 < 0.0 ? -1 : 1);
                     if (var75 > 0) {
                        return;
                     }

                     Object[] var52 = new Object[0];
                     PacketReceiveEvent var51 = var1;
                     var51.aReturningVoid(var52);
                  }
               }
            }
         }
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      int var6;
      boolean var65;
      long var10001 = 103442648113079L ^ 82487458045685L;
      var6 = Event.cReturningInt();
      BooleanSetting var24 = this.k;
      Boolean var25 = (Boolean)var24.aReturningObject();
      boolean var10000 = var25;
      int var71 = var6;
      boolean var70 = var10000;
      var65 = var70;
      boolean var62 = var70;
      label67:
      if (var71 != 0) {
         boolean var72 = var62;
         if (var72) {
            MinecraftClient var27 = b;
            var10000 = var27.currentScreen instanceof AbstractSignEditScreen;
            int var74 = var6;
            boolean var73 = var10000;
            var65 = var73;
            boolean var63 = var73;
            if (var74 == 0) {
               break label67;
            }

            boolean var75 = var63;
            boolean var64 = var75;
            boolean var76 = var64;
            if (var76) {
               Object var31 = null;
               MinecraftClient var30 = b;
               var30.setScreen((Screen)var31);
            }
         }

         BooleanSetting var33 = this.j;
         Boolean var34 = (Boolean)var33.aReturningObject();
         var65 = var34;
      }

      boolean var77 = var65;
      if (var77) {
         int var79 = var6;
         MinecraftClient var78 = b;
         MinecraftClient var67 = var78;
         MinecraftClient var66 = var78;
         if (var79 != 0) {
            MinecraftClient var35 = var66;
            ClientWorld var80 = var35.world;
            if (var80 == null) {
               return;
            }

            MinecraftClient var81 = b;
            var67 = var81;
         }

         MinecraftClient var38 = var67;
         int var83 = var6;
         ClientPlayerEntity var82 = var38.player;
         Object var69 = var82;
         ClientPlayerEntity var68 = var82;
         if (var83 != 0) {
            ClientPlayerEntity var84 = var68;
            if (var84 == null) {
               return;
            }

            FloatSetting var40 = this.h;
            var69 = var40.aReturningObject();
         }

         Float var41 = (Float)var69;
         float var7 = var41;
         double var8 = var7 * var7;
         MinecraftClient var42 = b;
         ClientPlayerEntity var43 = var42.player;
         double var10 = var43.getX();
         MinecraftClient var44 = b;
         ClientPlayerEntity var45 = var44.player;
         double var12 = var45.getY();
         MinecraftClient var46 = b;
         ClientPlayerEntity var47 = var46.player;
         double var14 = var47.getZ();
         MinecraftClient var48 = b;
         ClientWorld var49 = var48.world;
         Iterable var50 = var49.getEntities();
         Iterator var16 = var50.iterator();

         while (true) {
            Iterator var51 = var16;
            boolean var85 = var51.hasNext();
            if (!var85) {
               break;
            }

            Iterator var52 = var16;
            Entity var17 = (Entity)var52.next();
            Object[] var54 = new Object[]{var17, 23162857783618L};
            AntiTrap var53 = this;
            boolean var86 = var53.aReturningBoolean(var54);
            if (var86) {
               Entity var56 = var17;
               double var18 = var56.getX() - var10;
               Entity var57 = var17;
               double var20 = var57.getY() - var12;
               Entity var58 = var17;
               double var22 = var58.getZ() - var14;
               int var87 = var6;
               if (var87 != 0) {
                  double var91;
                  int var88 = (var91 = var18 * var18 + var20 * var20 + var22 * var22 - var8) == 0.0 ? 0 : (var91 < 0.0 ? -1 : 1);
                  if (var88 > 0) {
                     continue;
                  }

                  Entity var61 = var17;
                  var61.discard();
               }

               int var89 = var6;
               if (var89 == 0) {
                  break;
               }
            }
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      Entity var4;
      long var5;
      int var7;
      byte var37;
      long var89;
      var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      var89 = 5649774813068L ^ var2;
      var5 = var89 ^ 88819989038240L;
      var7 = Event.bReturningInt();
      MultiModeSetting var10000 = this.g;
      short var10001 = 4948;
      long var10002 = 1137749727792476494L ^ var89;
      Object[] var9 = new Object[]{"Armor Stands", var5};
      MultiModeSetting var8 = var10000;
      byte var90 = ((byte)((var8.aReturningBoolean(var9)) ? 1 : 0));
      int var55 = var7;
      byte var54 = var90;
      var37 = var54;
      byte var34 = var54;
      label88:
      if (var55 == 0) {
         byte var56 = var34;
         if (var56 != 0) {
            byte var91 = ((byte)((var4 instanceof ArmorStandEntity) ? 1 : 0));
            int var58 = var7;
            byte var57 = var91;
            var37 = var57;
            byte var35 = var57;
            if (var58 != 0) {
               break label88;
            }

            byte var59 = var35;
            byte var36 = var59;
            byte var60 = var36;
            if (var60 != 0) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 27725;
         var10002 = 5896651946593734233L ^ var89;
         Object[] var15 = new Object[]{"Minecarts", var5};
         MultiModeSetting var14 = var10000;
         var37 = ((byte)((var14.aReturningBoolean(var15)) ? 1 : 0));
      }

      byte var41;
      int var62 = var7;
      byte var61 = var37;
      var41 = var61;
      byte var38 = var61;
      label81:
      if (var62 == 0) {
         byte var63 = var38;
         if (var63 != 0) {
            byte var93 = ((byte)((var4 instanceof AbstractMinecartEntity) ? 1 : 0));
            int var65 = var7;
            byte var64 = var93;
            var41 = var64;
            byte var39 = var64;
            if (var65 != 0) {
               break label81;
            }

            byte var66 = var39;
            byte var40 = var66;
            byte var67 = var40;
            if (var67 != 0) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 18737;
         var10002 = 1858914573746072366L ^ var89;
         Object[] var21 = new Object[]{"Item Frames", var5};
         MultiModeSetting var20 = var10000;
         var41 = ((byte)((var20.aReturningBoolean(var21)) ? 1 : 0));
      }

      byte var45;
      int var69 = var7;
      byte var68 = var41;
      var45 = var68;
      byte var42 = var68;
      label74:
      if (var69 == 0) {
         byte var70 = var42;
         if (var70 != 0) {
            byte var95 = ((byte)((var4 instanceof ItemFrameEntity) ? 1 : 0));
            int var72 = var7;
            byte var71 = var95;
            var45 = var71;
            byte var43 = var71;
            if (var72 != 0) {
               break label74;
            }

            byte var73 = var43;
            byte var44 = var73;
            byte var74 = var44;
            if (var74 != 0) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 1035;
         var10002 = 3929304675629901340L ^ var89;
         Object[] var27 = new Object[]{"Boats", var5};
         MultiModeSetting var26 = var10000;
         var45 = ((byte)((var26.aReturningBoolean(var27)) ? 1 : 0));
      }

      byte var49;
      int var76 = var7;
      byte var75 = var45;
      var49 = var75;
      byte var46 = var75;
      label67:
      if (var76 == 0) {
         byte var77 = var46;
         if (var77 != 0) {
            byte var97 = ((byte)((var4 instanceof AbstractBoatEntity) ? 1 : 0));
            int var79 = var7;
            byte var78 = var97;
            var49 = var78;
            byte var47 = var78;
            if (var79 != 0) {
               break label67;
            }

            byte var80 = var47;
            byte var48 = var80;
            byte var81 = var48;
            if (var81 != 0) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 17585;
         var10002 = 4358784391076144803L ^ var89;
         Object[] var33 = new Object[]{"End Crystals", var5};
         MultiModeSetting var32 = var10000;
         var49 = ((byte)((var32.aReturningBoolean(var33)) ? 1 : 0));
      }

      int var83 = var7;
      byte var82 = var49;
      byte var53 = var82;
      byte var50 = var82;
      if (var83 == 0) {
         byte var84 = var50;
         if (var84 != 0) {
            boolean var99 = var4 instanceof EndCrystalEntity;
            int var86 = var7;
            boolean var85 = var99;
            boolean var108 = var85;
            boolean var51 = var85;
            if (var86 != 0) {
               return var108;
            }

            boolean var87 = var51;
            boolean var52 = var87;
            boolean var88 = var52;
            if (var88) {
               return true;
            }
         }

         var53 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var53);
   }

   private boolean dReturningBoolean(Object[] var1) {
      EntityType var4 = (EntityType)var1[0];
      long var2 = (Long)var1[1];
      var2 = 5649774813068L ^ var2;
      long var5 = var2 ^ 68324247998277L;
      long var7 = var2 ^ 8509616868371L;
      long var9 = var2 ^ 89653923923019L;
      int var11 = Event.bReturningInt();
      MultiModeSetting var10000 = this.g;
      short var10001 = 7586;
      long var10002 = 6008926961019141976L ^ var2;
      Object[] var13 = new Object[]{"Armor Stands", var9};
      MultiModeSetting var12 = var10000;
      byte var101 = ((byte)((var12.aReturningBoolean(var13)) ? 1 : 0));
      int var63 = var11;
      byte var62 = var101;
      byte var43 = var62;
      byte var42 = var62;
      if (var63 == 0) {
         byte var64 = var42;
         if (var64 != 0) {
            EntityType var66 = EntityType.ARMOR_STAND;
            EntityType var65 = var4;
            if (var65 == var66) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 12201;
         var10002 = 1046538330386959703L ^ var2;
         Object[] var18 = new Object[]{"Minecarts", var9};
         MultiModeSetting var17 = var10000;
         var43 = ((byte)((var17.aReturningBoolean(var18)) ? 1 : 0));
      }

      byte var47;
      int var68 = var11;
      byte var67 = var43;
      var47 = var67;
      byte var44 = var67;
      label83:
      if (var68 == 0) {
         byte var69 = var44;
         if (var69 != 0) {
            Object[] var21 = new Object[]{var4, var7};
            AntiTrap var20 = this;
            byte var103 = ((byte)((var20.eReturningBoolean(var21)) ? 1 : 0));
            int var71 = var11;
            byte var70 = var103;
            var47 = var70;
            byte var45 = var70;
            if (var71 != 0) {
               break label83;
            }

            byte var72 = var45;
            byte var46 = var72;
            byte var73 = var46;
            if (var73 != 0) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 10273;
         var10002 = 6761515547015154369L ^ var2;
         Object[] var26 = new Object[]{"Item Frames", var9};
         MultiModeSetting var25 = var10000;
         var47 = ((byte)((var25.aReturningBoolean(var26)) ? 1 : 0));
      }

      int var75 = var11;
      byte var74 = var47;
      byte var55 = var74;
      byte var48 = var74;
      if (var75 == 0) {
         byte var76 = var48;
         if (var76 != 0) {
            int var79 = var11;
            EntityType var78 = EntityType.ITEM_FRAME;
            EntityType var77 = var4;
            EntityType var53 = var77;
            EntityType var54 = var78;
            EntityType var49 = var77;
            EntityType var50 = var78;
            if (var79 == 0) {
               EntityType var81 = var50;
               EntityType var80 = var49;
               EntityType var51 = var80;
               EntityType var52 = var81;
               EntityType var83 = var52;
               EntityType var82 = var51;
               if (var82 == var83) {
                  return true;
               }

               EntityType var85 = EntityType.GLOW_ITEM_FRAME;
               EntityType var84 = var4;
               var53 = var84;
               var54 = var85;
            }

            EntityType var87 = var54;
            EntityType var86 = var53;
            if (var86 == var87) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 9640;
         var10002 = 27843532787222357L ^ var2;
         Object[] var33 = new Object[]{"Boats", var9};
         MultiModeSetting var32 = var10000;
         var55 = ((byte)((var32.aReturningBoolean(var33)) ? 1 : 0));
      }

      byte var59;
      int var89 = var11;
      byte var88 = var55;
      var59 = var88;
      byte var56 = var88;
      label64:
      if (var89 == 0) {
         byte var90 = var56;
         if (var90 != 0) {
            Object[] var36 = new Object[]{var4, var5};
            AntiTrap var35 = this;
            byte var106 = ((byte)((var35.fReturningBoolean(var36)) ? 1 : 0));
            int var92 = var11;
            byte var91 = var106;
            var59 = var91;
            byte var57 = var91;
            if (var92 != 0) {
               break label64;
            }

            byte var93 = var57;
            byte var58 = var93;
            byte var94 = var58;
            if (var94 != 0) {
               return true;
            }
         }

         var10000 = this.g;
         var10001 = 5069;
         var10002 = 5368696612737003835L ^ var2;
         Object[] var41 = new Object[]{"End Crystals", var9};
         MultiModeSetting var40 = var10000;
         var59 = ((byte)((var40.aReturningBoolean(var41)) ? 1 : 0));
      }

      int var96 = var11;
      byte var95 = var59;
      byte var61 = var95;
      byte var60 = var95;
      if (var96 == 0) {
         byte var97 = var60;
         if (var97 != 0) {
            EntityType var99 = EntityType.END_CRYSTAL;
            EntityType var98 = var4;
            if (var98 == var99) {
               return true;
            }
         }

         var61 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var61);
   }

   private boolean eReturningBoolean(Object[] var1) {
      EntityType var4 = (EntityType)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 5649774813068L ^ var2;
      int var5 = Event.cReturningInt();
      int var33 = var5;
      EntityType var32 = EntityType.MINECART;
      EntityType var31 = var4;
      EntityType var8 = var31;
      EntityType var9 = var32;
      EntityType var6 = var31;
      EntityType var7 = var32;
      if (var33 != 0) {
         EntityType var35 = var7;
         EntityType var34 = var6;
         if (var34 == var35) {
            return true;
         }

         EntityType var37 = EntityType.CHEST_MINECART;
         EntityType var36 = var4;
         var8 = var36;
         var9 = var37;
      }

      int var40 = var5;
      EntityType var39 = var9;
      EntityType var38 = var8;
      EntityType var12 = var38;
      EntityType var13 = var39;
      EntityType var10 = var38;
      EntityType var11 = var39;
      if (var40 != 0) {
         EntityType var42 = var11;
         EntityType var41 = var10;
         if (var41 == var42) {
            return true;
         }

         EntityType var44 = EntityType.COMMAND_BLOCK_MINECART;
         EntityType var43 = var4;
         var12 = var43;
         var13 = var44;
      }

      int var47 = var5;
      EntityType var46 = var13;
      EntityType var45 = var12;
      EntityType var16 = var45;
      EntityType var17 = var46;
      EntityType var14 = var45;
      EntityType var15 = var46;
      if (var47 != 0) {
         EntityType var49 = var15;
         EntityType var48 = var14;
         if (var48 == var49) {
            return true;
         }

         EntityType var51 = EntityType.FURNACE_MINECART;
         EntityType var50 = var4;
         var16 = var50;
         var17 = var51;
      }

      int var54 = var5;
      EntityType var53 = var17;
      EntityType var52 = var16;
      EntityType var20 = var52;
      EntityType var21 = var53;
      EntityType var18 = var52;
      EntityType var19 = var53;
      if (var54 != 0) {
         EntityType var56 = var19;
         EntityType var55 = var18;
         if (var55 == var56) {
            return true;
         }

         EntityType var58 = EntityType.HOPPER_MINECART;
         EntityType var57 = var4;
         var20 = var57;
         var21 = var58;
      }

      int var61 = var5;
      EntityType var60 = var21;
      EntityType var59 = var20;
      EntityType var24 = var59;
      EntityType var25 = var60;
      EntityType var22 = var59;
      EntityType var23 = var60;
      if (var61 != 0) {
         EntityType var63 = var23;
         EntityType var62 = var22;
         if (var62 == var63) {
            return true;
         }

         EntityType var65 = EntityType.SPAWNER_MINECART;
         EntityType var64 = var4;
         var24 = var64;
         var25 = var65;
      }

      int var68 = var5;
      EntityType var67 = var25;
      EntityType var66 = var24;
      EntityType var28 = var66;
      EntityType var29 = var67;
      EntityType var26 = var66;
      EntityType var27 = var67;
      if (var68 != 0) {
         EntityType var70 = var27;
         EntityType var69 = var26;
         if (var69 == var70) {
            return true;
         }

         EntityType var72 = EntityType.TNT_MINECART;
         EntityType var71 = var4;
         var28 = var71;
         var29 = var72;
      }

      EntityType var74 = var29;
      EntityType var73 = var28;
      return var73 == var74;
   }

   private boolean fReturningBoolean(Object[] var1) {
      EntityType var2 = (EntityType)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 5649774813068L ^ var3;
      int var5 = Event.bReturningInt();
      int var85 = var5;
      EntityType var84 = EntityType.OAK_BOAT;
      EntityType var83 = var2;
      EntityType var8 = var83;
      EntityType var9 = var84;
      EntityType var6 = var83;
      EntityType var7 = var84;
      if (var85 == 0) {
         EntityType var87 = var7;
         EntityType var86 = var6;
         if (var86 == var87) {
            return true;
         }

         EntityType var89 = EntityType.SPRUCE_BOAT;
         EntityType var88 = var2;
         var8 = var88;
         var9 = var89;
      }

      int var92 = var5;
      EntityType var91 = var9;
      EntityType var90 = var8;
      EntityType var12 = var90;
      EntityType var13 = var91;
      EntityType var10 = var90;
      EntityType var11 = var91;
      if (var92 == 0) {
         EntityType var94 = var11;
         EntityType var93 = var10;
         if (var93 == var94) {
            return true;
         }

         EntityType var96 = EntityType.BIRCH_BOAT;
         EntityType var95 = var2;
         var12 = var95;
         var13 = var96;
      }

      int var99 = var5;
      EntityType var98 = var13;
      EntityType var97 = var12;
      EntityType var16 = var97;
      EntityType var17 = var98;
      EntityType var14 = var97;
      EntityType var15 = var98;
      if (var99 == 0) {
         EntityType var101 = var15;
         EntityType var100 = var14;
         if (var100 == var101) {
            return true;
         }

         EntityType var103 = EntityType.JUNGLE_BOAT;
         EntityType var102 = var2;
         var16 = var102;
         var17 = var103;
      }

      int var106 = var5;
      EntityType var105 = var17;
      EntityType var104 = var16;
      EntityType var20 = var104;
      EntityType var21 = var105;
      EntityType var18 = var104;
      EntityType var19 = var105;
      if (var106 == 0) {
         EntityType var108 = var19;
         EntityType var107 = var18;
         if (var107 == var108) {
            return true;
         }

         EntityType var110 = EntityType.ACACIA_BOAT;
         EntityType var109 = var2;
         var20 = var109;
         var21 = var110;
      }

      int var113 = var5;
      EntityType var112 = var21;
      EntityType var111 = var20;
      EntityType var24 = var111;
      EntityType var25 = var112;
      EntityType var22 = var111;
      EntityType var23 = var112;
      if (var113 == 0) {
         EntityType var115 = var23;
         EntityType var114 = var22;
         if (var114 == var115) {
            return true;
         }

         EntityType var117 = EntityType.DARK_OAK_BOAT;
         EntityType var116 = var2;
         var24 = var116;
         var25 = var117;
      }

      int var120 = var5;
      EntityType var119 = var25;
      EntityType var118 = var24;
      EntityType var28 = var118;
      EntityType var29 = var119;
      EntityType var26 = var118;
      EntityType var27 = var119;
      if (var120 == 0) {
         EntityType var122 = var27;
         EntityType var121 = var26;
         if (var121 == var122) {
            return true;
         }

         EntityType var124 = EntityType.MANGROVE_BOAT;
         EntityType var123 = var2;
         var28 = var123;
         var29 = var124;
      }

      int var127 = var5;
      EntityType var126 = var29;
      EntityType var125 = var28;
      EntityType var32 = var125;
      EntityType var33 = var126;
      EntityType var30 = var125;
      EntityType var31 = var126;
      if (var127 == 0) {
         EntityType var129 = var31;
         EntityType var128 = var30;
         if (var128 == var129) {
            return true;
         }

         EntityType var131 = EntityType.CHERRY_BOAT;
         EntityType var130 = var2;
         var32 = var130;
         var33 = var131;
      }

      int var134 = var5;
      EntityType var133 = var33;
      EntityType var132 = var32;
      EntityType var36 = var132;
      EntityType var37 = var133;
      EntityType var34 = var132;
      EntityType var35 = var133;
      if (var134 == 0) {
         EntityType var136 = var35;
         EntityType var135 = var34;
         if (var135 == var136) {
            return true;
         }

         EntityType var138 = EntityType.PALE_OAK_BOAT;
         EntityType var137 = var2;
         var36 = var137;
         var37 = var138;
      }

      int var141 = var5;
      EntityType var140 = var37;
      EntityType var139 = var36;
      EntityType var40 = var139;
      EntityType var41 = var140;
      EntityType var38 = var139;
      EntityType var39 = var140;
      if (var141 == 0) {
         EntityType var143 = var39;
         EntityType var142 = var38;
         if (var142 == var143) {
            return true;
         }

         EntityType var145 = EntityType.PALE_OAK_CHEST_BOAT;
         EntityType var144 = var2;
         var40 = var144;
         var41 = var145;
      }

      int var148 = var5;
      EntityType var147 = var41;
      EntityType var146 = var40;
      EntityType var44 = var146;
      EntityType var45 = var147;
      EntityType var42 = var146;
      EntityType var43 = var147;
      if (var148 == 0) {
         EntityType var150 = var43;
         EntityType var149 = var42;
         if (var149 == var150) {
            return true;
         }

         EntityType var152 = EntityType.BAMBOO_RAFT;
         EntityType var151 = var2;
         var44 = var151;
         var45 = var152;
      }

      int var155 = var5;
      EntityType var154 = var45;
      EntityType var153 = var44;
      EntityType var48 = var153;
      EntityType var49 = var154;
      EntityType var46 = var153;
      EntityType var47 = var154;
      if (var155 == 0) {
         EntityType var157 = var47;
         EntityType var156 = var46;
         if (var156 == var157) {
            return true;
         }

         EntityType var159 = EntityType.OAK_CHEST_BOAT;
         EntityType var158 = var2;
         var48 = var158;
         var49 = var159;
      }

      int var162 = var5;
      EntityType var161 = var49;
      EntityType var160 = var48;
      EntityType var52 = var160;
      EntityType var53 = var161;
      EntityType var50 = var160;
      EntityType var51 = var161;
      if (var162 == 0) {
         EntityType var164 = var51;
         EntityType var163 = var50;
         if (var163 == var164) {
            return true;
         }

         EntityType var166 = EntityType.SPRUCE_CHEST_BOAT;
         EntityType var165 = var2;
         var52 = var165;
         var53 = var166;
      }

      int var169 = var5;
      EntityType var168 = var53;
      EntityType var167 = var52;
      EntityType var56 = var167;
      EntityType var57 = var168;
      EntityType var54 = var167;
      EntityType var55 = var168;
      if (var169 == 0) {
         EntityType var171 = var55;
         EntityType var170 = var54;
         if (var170 == var171) {
            return true;
         }

         EntityType var173 = EntityType.BIRCH_CHEST_BOAT;
         EntityType var172 = var2;
         var56 = var172;
         var57 = var173;
      }

      int var176 = var5;
      EntityType var175 = var57;
      EntityType var174 = var56;
      EntityType var60 = var174;
      EntityType var61 = var175;
      EntityType var58 = var174;
      EntityType var59 = var175;
      if (var176 == 0) {
         EntityType var178 = var59;
         EntityType var177 = var58;
         if (var177 == var178) {
            return true;
         }

         EntityType var180 = EntityType.JUNGLE_CHEST_BOAT;
         EntityType var179 = var2;
         var60 = var179;
         var61 = var180;
      }

      int var183 = var5;
      EntityType var182 = var61;
      EntityType var181 = var60;
      EntityType var64 = var181;
      EntityType var65 = var182;
      EntityType var62 = var181;
      EntityType var63 = var182;
      if (var183 == 0) {
         EntityType var185 = var63;
         EntityType var184 = var62;
         if (var184 == var185) {
            return true;
         }

         EntityType var187 = EntityType.ACACIA_CHEST_BOAT;
         EntityType var186 = var2;
         var64 = var186;
         var65 = var187;
      }

      int var190 = var5;
      EntityType var189 = var65;
      EntityType var188 = var64;
      EntityType var68 = var188;
      EntityType var69 = var189;
      EntityType var66 = var188;
      EntityType var67 = var189;
      if (var190 == 0) {
         EntityType var192 = var67;
         EntityType var191 = var66;
         if (var191 == var192) {
            return true;
         }

         EntityType var194 = EntityType.DARK_OAK_CHEST_BOAT;
         EntityType var193 = var2;
         var68 = var193;
         var69 = var194;
      }

      int var197 = var5;
      EntityType var196 = var69;
      EntityType var195 = var68;
      EntityType var72 = var195;
      EntityType var73 = var196;
      EntityType var70 = var195;
      EntityType var71 = var196;
      if (var197 == 0) {
         EntityType var199 = var71;
         EntityType var198 = var70;
         if (var198 == var199) {
            return true;
         }

         EntityType var201 = EntityType.MANGROVE_CHEST_BOAT;
         EntityType var200 = var2;
         var72 = var200;
         var73 = var201;
      }

      int var204 = var5;
      EntityType var203 = var73;
      EntityType var202 = var72;
      EntityType var76 = var202;
      EntityType var77 = var203;
      EntityType var74 = var202;
      EntityType var75 = var203;
      if (var204 == 0) {
         EntityType var206 = var75;
         EntityType var205 = var74;
         if (var205 == var206) {
            return true;
         }

         EntityType var208 = EntityType.CHERRY_CHEST_BOAT;
         EntityType var207 = var2;
         var76 = var207;
         var77 = var208;
      }

      int var211 = var5;
      EntityType var210 = var77;
      EntityType var209 = var76;
      EntityType var80 = var209;
      EntityType var81 = var210;
      EntityType var78 = var209;
      EntityType var79 = var210;
      if (var211 == 0) {
         EntityType var213 = var79;
         EntityType var212 = var78;
         if (var212 == var213) {
            return true;
         }

         EntityType var215 = EntityType.BAMBOO_CHEST_RAFT;
         EntityType var214 = var2;
         var80 = var214;
         var81 = var215;
      }

      EntityType var217 = var81;
      EntityType var216 = var80;
      return var216 == var217;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(104353116613764L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[17];
      String var6 = "P5ísRÂF¼ß\u009dt\u00880¨Ï\\©\u0096\u001d¸U!·\u0016FÎÍ\u0010Á\u00066Ì \u0083¯O´\r\u0013Å¯>£e»\u0085 ¼¿s,G6x²\u0081jsf@þ\u001fëÜ\u0012 9â\u001b¾©Ï®=wM\u008e\u008bÔ:Æ\u0092ú·Õ\u0005êûÓ´'\u001fVã\tfÈl\u0010?=ô#Ó\u00ad6\u0003w\u000f\u0012:t%e« \u0081ø\u0010\u009fp\u001aÔ1¤Í\u0086xv\u0091¨VÃ·?\u0086\u001e\u0096o´@$w7\u0088~Ui\u0080\u001eZ\u0011mR\u0011b\u0095\u0005õ3\u0092 [©\\Î¾yF\u00ad\u0010WøÙ\u0094â\u0094Ä\u0086Õ\u0011\rb³\u001dõ\u0084e)\u0004\u0099\u0085\u00837¯5A\u001d\u009fè6¹\téh²ç² \u0006h\u00019l ´Å\u0005\u0098»\u0018Ë\"Ýg\u008aÅIÚÅ\u001eËé>\u0095%¡\u0018Æ×dhQ-|hv{\u0080#m\u0096¦wªB¬¶\u00157\u001ab\u0006â7Û\u000eã!å\u0004¾Üýg-È n\n\u009a\u0090®\u000f\nfÊ\u0000¥B\u0011XÑ\rk2½øx\u0095\u009e\u0019-d&0\u0081zÇô ì7cÁ(ðï4hjº\\º\u0001\u001dÏ|\u007f½ü[Yî÷Z\u0091áA-\u008a\u0011Ç\u0018\u001c\u009c[\u0001dq%É\u0010\u0098N\u0094!x³¡\u000fw\u0003ÕØÒ\u0004Þ ¬ZªÈd~\u0092\b\u000bÀZiKvf\u001f\u0088áiX>ü\u0092bH6V¦\u0082¡cà\u0018&å\u0080Ê<`\u0011ps\u009c¬dm<J\u000e|x«\u0001\u001b\u0095Ô«\u0018%7ç}KbuL9Õ\u0089`8ÍÔ)\u008eC\u0012\u0092¹òåþ\u0010Ð Í\u0080K\u0013¹\tF\u009bÑ³:rq_\u0010\u008b#)'\u000fc©Tc\u00938\u0087q\u00968\u009c H\u0006ÀJ Aw&ß/HÖRéªLZ\u0082\u009e¼\nñg\u0014\u008fÒÝ\u001cXP\u0090\u001a";
      int var8 = "P5ísRÂF¼ß\u009dt\u00880¨Ï\\©\u0096\u001d¸U!·\u0016FÎÍ\u0010Á\u00066Ì \u0083¯O´\r\u0013Å¯>£e»\u0085 ¼¿s,G6x²\u0081jsf@þ\u001fëÜ\u0012 9â\u001b¾©Ï®=wM\u008e\u008bÔ:Æ\u0092ú·Õ\u0005êûÓ´'\u001fVã\tfÈl\u0010?=ô#Ó\u00ad6\u0003w\u000f\u0012:t%e« \u0081ø\u0010\u009fp\u001aÔ1¤Í\u0086xv\u0091¨VÃ·?\u0086\u001e\u0096o´@$w7\u0088~Ui\u0080\u001eZ\u0011mR\u0011b\u0095\u0005õ3\u0092 [©\\Î¾yF\u00ad\u0010WøÙ\u0094â\u0094Ä\u0086Õ\u0011\rb³\u001dõ\u0084e)\u0004\u0099\u0085\u00837¯5A\u001d\u009fè6¹\téh²ç² \u0006h\u00019l ´Å\u0005\u0098»\u0018Ë\"Ýg\u008aÅIÚÅ\u001eËé>\u0095%¡\u0018Æ×dhQ-|hv{\u0080#m\u0096¦wªB¬¶\u00157\u001ab\u0006â7Û\u000eã!å\u0004¾Üýg-È n\n\u009a\u0090®\u000f\nfÊ\u0000¥B\u0011XÑ\rk2½øx\u0095\u009e\u0019-d&0\u0081zÇô ì7cÁ(ðï4hjº\\º\u0001\u001dÏ|\u007f½ü[Yî÷Z\u0091áA-\u008a\u0011Ç\u0018\u001c\u009c[\u0001dq%É\u0010\u0098N\u0094!x³¡\u000fw\u0003ÕØÒ\u0004Þ ¬ZªÈd~\u0092\b\u000bÀZiKvf\u001f\u0088áiX>ü\u0092bH6V¦\u0082¡cà\u0018&å\u0080Ê<`\u0011ps\u009c¬dm<J\u000e|x«\u0001\u001b\u0095Ô«\u0018%7ç}KbuL9Õ\u0089`8ÍÔ)\u008eC\u0012\u0092¹òåþ\u0010Ð Í\u0080K\u0013¹\tF\u009bÑ³:rq_\u0010\u008b#)'\u000fc©Tc\u00938\u0087q\u00968\u009c H\u0006ÀJ Aw&ß/HÖRéªLZ\u0082\u009e¼\nñg\u0014\u008fÒÝ\u001cXP\u0090\u001a"
         .length();
      char var5 = ' ';
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     m = var9;
                     n = new String[17];
                     e = "Boats";
                     f = "End Crystals";
                     a = "Armor Stands";
                     c = "Minecarts";
                     d = "Item Frames";
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "\u008c¹°¶«\u0098µ\u001dE¿ä¨r\u0099\u008c\u0015\u0080þ6ì\u0018\u0012\u0097þÍS$ÆáÊ\u001fz \u0093\u0017M*@°\u0000a+qi_ÇÝ²RÆ1\u000eºÛ\u0093µeüÝò\u0085÷\"°ò";
                  var8 = "\u008c¹°¶«\u0098µ\u001dE¿ä¨r\u0099\u008c\u0015\u0080þ6ì\u0018\u0012\u0097þÍS$ÆáÊ\u001fz \u0093\u0017M*@°\u0000a+qi_ÇÝ²RÆ1\u000eºÛ\u0093µeüÝò\u0085÷\"°ò"
                     .length();
                  var5 = ' ';
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 15573;
      if (n[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])o.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               o.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d0", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = m[var5].getBytes("ISO-8859-1");
         n[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return n[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d0",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d0" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 6;
            yield var15;
         }
         case 1 -> {
            byte var16 = 25;
            yield var16;
         }
         case 2 -> {
            byte var17 = 62;
            yield var17;
         }
         case 3 -> {
            byte var18 = 22;
            yield var18;
         }
         case 4 -> {
            byte var19 = 16;
            yield var19;
         }
         case 5 -> {
            byte var20 = 59;
            yield var20;
         }
         case 6 -> {
            byte var21 = 15;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 35;
            yield var23;
         }
         case 9 -> {
            byte var24 = 5;
            yield var24;
         }
         case 10 -> {
            byte var25 = 12;
            yield var25;
         }
         case 11 -> {
            byte var26 = 9;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 41;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 37;
            yield var30;
         }
         case 16 -> {
            byte var31 = 14;
            yield var31;
         }
         case 17 -> {
            byte var32 = 63;
            yield var32;
         }
         case 18 -> {
            byte var33 = 50;
            yield var33;
         }
         case 19 -> {
            byte var34 = 54;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 45;
            yield var36;
         }
         case 22 -> {
            byte var37 = 1;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 7;
            yield var39;
         }
         case 25 -> {
            byte var40 = 52;
            yield var40;
         }
         case 26 -> {
            byte var41 = 0;
            yield var41;
         }
         case 27 -> {
            byte var42 = 8;
            yield var42;
         }
         case 28 -> {
            byte var43 = 34;
            yield var43;
         }
         case 29 -> {
            byte var44 = 55;
            yield var44;
         }
         case 30 -> {
            byte var45 = 56;
            yield var45;
         }
         case 31 -> {
            byte var46 = 28;
            yield var46;
         }
         case 32 -> {
            byte var47 = 4;
            yield var47;
         }
         case 33 -> {
            byte var48 = 13;
            yield var48;
         }
         case 34 -> {
            byte var49 = 23;
            yield var49;
         }
         case 35 -> {
            byte var50 = 17;
            yield var50;
         }
         case 36 -> {
            byte var51 = 11;
            yield var51;
         }
         case 37 -> {
            byte var52 = 26;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 30;
            yield var54;
         }
         case 40 -> {
            byte var55 = 49;
            yield var55;
         }
         case 41 -> {
            byte var56 = 18;
            yield var56;
         }
         case 42 -> {
            byte var57 = 31;
            yield var57;
         }
         case 43 -> {
            byte var58 = 46;
            yield var58;
         }
         case 44 -> {
            byte var59 = 2;
            yield var59;
         }
         case 45 -> {
            byte var60 = 39;
            yield var60;
         }
         case 46 -> {
            byte var61 = 57;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 53;
            yield var63;
         }
         case 49 -> {
            byte var64 = 10;
            yield var64;
         }
         case 50 -> {
            byte var65 = 21;
            yield var65;
         }
         case 51 -> {
            byte var66 = 44;
            yield var66;
         }
         case 52 -> {
            byte var67 = 42;
            yield var67;
         }
         case 53 -> {
            byte var68 = 27;
            yield var68;
         }
         case 54 -> {
            byte var69 = 51;
            yield var69;
         }
         case 55 -> {
            byte var70 = 24;
            yield var70;
         }
         case 56 -> {
            byte var71 = 32;
            yield var71;
         }
         case 57 -> {
            byte var72 = 20;
            yield var72;
         }
         case 58 -> {
            byte var73 = 36;
            yield var73;
         }
         case 59 -> {
            byte var74 = 38;
            yield var74;
         }
         case 60 -> {
            byte var75 = 29;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 33;
            yield var77;
         }
         default -> 3;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = "\\NfJ3\u001bJNc\u0010 \f]\u0005`\u0016,\u0018LBw\u0001g\n}";
      p[1] = int.class;
      q[1] = "java/lang/Integer";
      p[2] = "G\f|en>Q\fy?})FGz9q=W\u0000m.:*m";
      p[3] = "ucO;G/\u0000CD4V`aMO?R:\u0015";
      p[4] = boolean.class;
      q[4] = "java/lang/Boolean";
      p[5] = "S\u0018f[*|E\u0018c\u00019kRS`\u00075\u007fC\u0014w\u0010~h\u0007";
      p[6] = "\\\u001f\"*~\u0012W\u00103e\u001d\u001fB\u001d<\u000e(\u001dS\u000e \"?\u0010";
      p[7] = "b(.Gl&b(9\u001b`)xc9\u0005`<\u007f\u0012m]7";
      p[8] = double.class;
      q[8] = "java/lang/Double";
      p[9] = "B\u0019!fs/B\u00196:\u007f XR6$\u007f5_#g~.r";
      p[10] = "'\u000f}p-\u001c'\u000fj,!\u0013=Dj2!\u0006:58lyL";
      p[11] = ")\\ \rl&\"S1B\u0000%,Q3\r,";
      p[12] = "\u0019pe\u0006{\f\u000fp`\\h\u001b\u0018;cZd\u000f\t|tM/\u0018;";
      p[13] = "h7`\u00005\u0004c8qOT\nh3u\u0015";
      p[14] = "M{8\u0004\tkM{/X\u0005dW0/F\u0005qPA\u007f\u001bT";
      p[15] = "QSGNpkZ\\V\u0001\u0018kTSE";
      p[16] = float.class;
      q[16] = "java/lang/Float";
      p[17] = "\"NJ1Du4NOkWb#\u0005Lm[v2B[z\u0010g\"";
      p[18] = "Y\u0004z\u0015&n,$q\u001a7!M*z\u00113{9";
      p[19] = "jPAN]ejPV\u0012Qjp\u001bV\fQ\u007fwj\u0007U\t:";
      p[20] = "\u001d\u0018(\f\u0001\u0003h8#\u0003\u0010L\t6(\b\u0014\u0016}";
      p[21] = void.class;
      q[21] = "java/lang/Void";
      p[22] = "\u0005h\u0005\u001d\u0007'pH\u000e\u0012\u0016h\u0011F\u0005\u0019\u00122e";
      p[23] = "\u0006\u001ci\u00108\bs<b\u001f)G\u00122i\u0014-\u001df";
      p[24] = "4CG\u0001\u001er4CP]\u0012}.\bPC\u0012h)y\u0002\u001dJ,";
      p[25] = "\"F\u0005~$X)I\u00141C@-U\u0012}fQ";
      p[26] = "i,;oU'w$! 2&f?,z\u0014 ";
      p[27] = "F[(\u000fL1F[?S@>\\\u0010?M@+[ah\u0012\u0016";
      p[28] = "w.\\ W#w.K|[,meKb[9j\u0014\u001e=\u0002";
      p[29] = "k\u0007Eg\u001a'\u001e'Nh\u000bh\u007f)Ec\u000f2\u000b";
      p[30] = "\u0014\b\u001d\u001essa(\u0016\u0011b<\u0000&\u001d\u001afft";
      p[31] = "r.5Ol\u0010s!*U]\u0005I(&\u00071Q9>1\u0000mlrru\u0006;\u00116/r\u0003]";
      p[32] = "}W0\u007f=@=W#z_M\"K8n\b\u001e\u007f\u001ad<_\u001d2J!`<]2Y$";
      p[33] = "7$)X3=mk5\bT7:e)P8\u0005m\"r\u000ekRi 4M,m<zsFT";
      p[34] = "5&<\u00157)u&/\u0010U$j:4\u0004\u0002p;khQUtz;-\n64z((";
      p[35] = "<\u0013G;R\u0005mQCa1\u000fo\u0011E<]=;T\u001ce\u0000j<\u001cI&S\t|\u001cZ#1";
      p[36] = "<q@2\rA5z_<mF4pE=:\u0011j \u001cQ\u000fCj,S8\u0006\u0013d ";
      p[37] = "|\u0005J\u00174\u0019yVC\u001aN\u001fp\u0019Px\u007f\u0013lWFGw\u0006#\u0005,";
      p[38] = "-mc\\4\u000f|/g\u0006W\u0005~oa[;7**8\u0003i`-*|F/_xp;MW";
      p[39] = "\u0002SK\u001cI>N\u0015[&\u001bCW\u0007\u001eJO3A\u0010\u0019\u0016r.I\u001cEW\u0003#PPC&";
      p[40] = "aAplEy!Aci't>]x}p$f\t$\u0011\u0019k3M~rYk H";
      p[41] = "|P\u0010e\"\u0003&\u001f\f5E\tq\u0011\u0010m);&VK3ul\"T\rp=Sw\u000eJ{E";
      p[42] = "b)\u0002O&O\")\u0011JDB=5\n^\u0013\u0012de^2z]0%\fQ:]# ";
      p[43] = "\u0011myAL1@/}\u001b/;Bo{FC\t\u0016*\"\u001e\u0012^\u0011*f[WaDp!P/";
      p[44] = "\\Q\u0004#5K\u001cQ\u0017&WF\u0003M\f2\u0000\u0015^\u001cQ`W\u0016\u0013L\u0015<4V\u0013_\u0010";
      p[45] = "b7Pgg\u0012\"7Cb\u0005\u001f=+XvRL`z\u0006 \u0005O-*Axf\u000f-9D";
      p[46] = "mao\u001b@M-a|\u001e\"@2}g\nu\u0010k-8f\u001c_?ma\u0005\\_,h";
      p[47] = "5\u0015\u0000onKu\u0015\u0013j\fFj\t\b~[\u00163XW\u00122Yg\u0019\u000eqrYt\u001c";
      p[48] = "\u0016Nq\u001a\n\u000fVNb\u001fh\u0002IRy\u000b?Q\u0014\u0003%WhRYS`\u0005\u000b\u0012Y@e";
      p[49] = "F\u0005#\u00138A\u0006\u00050\u0016ZL\u0019\u0019+\u0002\r\u001cAOqndS\u0014\t-\r$S\u0007\f";
      p[50] = ".\u007fEc\u0010[n\u007fVfrVqcMr%\u0006(>\u0011\u001eLI|sK}\fIov";
      p[51] = "!:m5kO(1r;\u000bH);h:\\\u001fvf3Vi\\-+|;sH8.";
      p[52] = "CvsHG5\u00199o\u0018 ?N7s@L\r\u0019p(\u001d\u0019Z\u001drn]XeH()V ";
      p[53] = "y24g#\u001a92'bA\u0017&.<v\u0016D{\u007fb\"AG6/%x\"\u00076< ";
      p[54] = "ELmo&(\u0005L~jD%\u001aPe~\u0013vG\u00018\"Du\nQ|p'5\nBy";
      p[55] = "\u0006smh6yFs~mTtYoey\u0003'\u0004>8-T$In|w7dI}y";
      p[56] = "P\u0001XTY,\u0010\u0001KQ;!\u000f\u001dPElrRL\r\u0018;q\u001f\u001cIKX1\u001f\u000fL";
      p[57] = "VG3XB][\\uE2W\u0006Zm_^eQ\u001d6\u0001\r2U\u001fpBJ\r\u0000E7I2";
      p[58] = "i&`\"\u0010o)&s'rb6:h3%1kk4nr2&;q=\u0011r&(t";
      p[59] = "M\u00199z}\u0002\u0001_)@,\u007fEOj=?O\u0006K&9F";
      p[60] = "\u0005K\b3ypLM\f&\u0013{<O\u001bn\u007f/LY\fi#\u0012\u0007\u0015HouoCHOj\u0013";
      p[61] = "K/hF\u0016(\u001aml\u001cu\"\u0018-jA\u0019\u0010Lh3\u0019IGKhw\\\rx\u001e20Wu";
      p[62] = "/MN+k1u\u0002R{\f;\"\fN#`\ttI\u0012{6^\"\n^'}//\u0013\u0012!\f";
      p[63] = "+kT4{\u007fkkG1\u0019rtw\\%N!)&\u0001u\u0019\"dvE+zbde@";
      p[64] = "[\n\u001d@o\u007f\u0006S\u0013R\u001fy\f\u0004\u001cCvu5\n\u001cSr\u0013P]@\u0017yn\u0014\u0000G\u0012\u001f";
      p[65] = "m\u0014@,}W!RP\u0016-*eB\u0013k?\u001a&F_oF";
      p[66] = "2R8]X`3]'Giu\t\f:\u0017\u0002%6H?MP\u001c5JzFP#qO \u0014i";
      p[67] = "IyN+\u00134\u001d X&+#y-J=\u0015 F%_rGJ";
      p[68] = "\u0002z\u0005(8g\u0003u\u001a2\tv9|\u0016`e&Ij\u0001g9\u001b\u0002&EaofF{Bd\t";
      p[69] = "1j!\u0001Vtqj2\u00044ynv)\u0010c*3&sG4)~w0\u001eWi~d5";
      p[70] = "\u0002\u001b\u000e\u0014!f\u000b\u0010\u0011\u001aAa\n\u001a\u000b\u001b\u00166TMSw|nU\u0017\u001f\u0018qu\u0013\n";
      p[71] = "@e7W\u001e5\u0000e$R|8\u001fy?F+kB(a\u0013|h\u000fx&H\u001f(\u000fk#";
      p[72] = "L\nT?\u0012^\f\nG:pS\u0013\u0016\\.'\u0000NG\u0000}p\u0003\u0003\u0017E \u0013C\u0003\u0004@";
      p[73] = "\b\\{\u0003)9H\\h\u0006K4W@s\u0012\u001cg\n\u0010)DKdGAj\u001c($GRo";
      p[74] = "bD=K`Xo_{V\u0010R2YcL|`e\u001e8\u0012 7a\u001c~Qh\b4F9Z\u0010";
      p[75] = "_+E|\n:ZxLqp:W<e~\u0000&>|\u001d+I<C8@,LZ";
      p[76] = "FOaW~F\u0006OrR\u001cK\u0019SiFK\u0018D\u00024\u0015\u001c\u001b\tRpH\u007f[\tAu";
      p[77] = "6\f\"/\u0005?7\u0003=54/\r\n1gX~}\u001c&`\u0004C6PbfR>r\rec4";
      p[78] = "\u0016+=Jb^\u0017$\"PSL--.\u0002?\u001f];9\u0005c\"\u0016w}\u00035_R*z\u0006S";
      p[79] = "\u0011z50TUQz&56XNf=!a\u000b\u00137`v6\b^g$/UH^t!";
      p[80] = "~$>B`w>$-G\u0002z!86SU)|ik\u0005\u0002*19/]aj1**";
      p[81] = "]NF\u0002IB\u001dNU\u0007+O\u0002RN\u0013|\u001fZ\u0004\u0013\u007f\u0015P\u000fBH\u001cUP\u001cG";
      p[82] = "/\u0011\u000f\u0016Z\u0011u\u001cHKj\u00123\u001f\t\u001f\u0016\u00145r\u0012\u001a\f\u001c5\u0012\u0017I\u0005\u0011O";
      p[83] = "\u0004H[\u0016\bN\rCD\u0018hB\u0000XZ\u0012\u0004pT\u0019\u0002JhE\u0006\u001b\u000b\u0007\u0001LV\u0015\u0007u\u0005]\u001dGK\u0004\bDQA:";
      p[84] = "!gD<Z\u001fagW98\u0012~{L-oA#*\u0012z8BnzU#[\u0002niP";
      p[85] = "@\u00131J^`\u0013\u00068\b33M\u000e!Om4M\u0014%3Y>P\n3Y_$[\u0004H";
      p[86] = "LV\\\u0018d\u001dAM\u001a\u0005\u0014\u0017\u001cK\u0002\u001fx%K\fYB-rO\u000e\u001f\u0002lM\u001aTX\t\u0014";
      p[87] = "F-to\u0006*\u0006-gjd'\u00191|~3tD`!/dw\t0ep\u00077\t#`";
      p[88] = "\u001d1\u001akQ\t]1\tn3\u0004B-\u0012zdT\u001bqH\u0016\r\u001bO=\u0014uM\u001b\\8";
      p[89] = "\u007fu{{\t\u0018*!v7j\u0013\u0014x-s\u0006Gdn:tZzxy~*\u001a\u001c{&y(j";
      p[90] = "\u0005$\u001f$\n\u0013E$\f!h\u001eZ8\u00175?M\u0007iJ`hNJ9\u000e;\u000b\u000eJ*\u000b";
      p[91] = "l\f_p?%,\fLu](3\u0010Wa\nxkG\r\rc7>\u0000Qn#7-\u0005";
      p[92] = "\u00078zT~9G8iQ\u001c4X$rEKd\u0000u,)\"+U4tJb+F1";
      p[93] = "\u0001:$F\u0018\u0000\u001b.1Ch\b\u000e<!\\\u0004:Zpx\u0002Rm\u0003#=[X\u000fY.z\u0006h";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(947749938244645L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(947749938244645L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(947749938244645L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 119;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 231;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 112;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 101;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 111;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 36;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 119;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 231;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 112;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d0",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d0" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
