package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.AttackTargetUpdateEvent;
import dev.zprestige.prestige.client.modules.state.AutoAnchorState;
import dev.zprestige.prestige.api.util.ExpiringValue;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.util.ExplosionDamageUtil;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.InteractionUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.SlotReservation;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.modules.state.AnchorPlacementPlan;
import dev.zprestige.prestige.client.modules.state.AnchorPlacementEvaluation;
import dev.zprestige.prestige.client.modules.state.AnchorPlacementPoint;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.util.Easing;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class AutoAnchor extends Module implements RotationSource {
   private FloatSetting a;
   private FloatSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private BooleanSetting f;
   private ModeSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private MinMaxSetting j;
   private MinMaxSetting k;
   private MinMaxSetting l;
   private BooleanSetting m;
   private BooleanSetting n;
   private ColorSetting o;
   private ColorSetting p;
   private ColorSetting q;
   private static final float r = 12.0F;
   private static final float s = 60.0F;
   private static final float t = 200.0F;
   private static final float u = 6.0F;
   private static final float v = 3.0F;
   private static final float w = 1.0F;
   private static final float x = 3.0F;
   private static final long y;
   private static final Direction[] z;
   private static final int[][] A;
   public static boolean B;
   private AutoAnchorState C;
   private ElapsedTimer D;
   private ElapsedTimer E;
   private ElapsedTimer F;
   private ElapsedTimer G;
   private int H;
   private static final int I;
   private HashMap J;
   private long K;
   private static final long L;
   private long M;
   private PlayerEntity N;
   private BlockPos O;
   private BlockPos P;
   private Vec3d Q;
   private Vec3d R;
   private Vec3d S;
   private float T;
   private int U;
   private volatile long V;
   private long W;
   private int X;
   private PlayerEntity Y;
   private BlockPos Z;
   private BlockPos aa;
   private Vec3d ab;
   private BlockPos ac;
   private BlockPos ad;
   private Vec3d ae;
   private BlockPos af;
   private int ag;
   private Vec3d ah;
   private List ai;
   private static final float aj = 180.0F;
   private static final double ak = 900.0;
   private static final float al = 0.6F;
   private static final float am = 0.4F;
   private ExpiringValue an;
   private ExpiringValue ao;
   private ExpiringValue ap;
   private BlockPos aq;
   private BlockPos ar;
   private BlockPos as;
   private ElapsedTimer at;
   private static final long bb = 2444992509633L;
   private static final String[] hb;
   private static final String[] ib;
   private static final Map jb = new HashMap(13);
   private static final long[] kb;
   private static final Integer[] lb;
   private static final Map mb;
   private static final long[] nb;
   private static final Long[] ob;
   private static final Map pb;
   private static final Object[] wb = new Object[382];
   private static final String[] xb = new String[382];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;

   public AutoAnchor() {
      super();
      long var10001 = 56495978138707L ^ 90621144038266L;
      var10001 = 56495978138707L ^ 25142729101075L;
      var10001 = 56495978138707L ^ 103319773126551L;
      var10001 = 56495978138707L ^ 86047486780232L;

      this.C = AutoAnchorState.IDLE;
      this.D = new ElapsedTimer(106698256430889L);
      this.E = new ElapsedTimer(106698256430889L);
      this.F = new ElapsedTimer(106698256430889L);
      this.G = new ElapsedTimer(106698256430889L);
      this.J = new HashMap();
      this.ag = -1;
      this.ai = new ArrayList();
      this.an = new ExpiringValue(180.0F, false, Easing.SINE_IN_OUT, 137591480872731L);
      this.ao = new ExpiringValue(180.0F, false, Easing.SINE_IN_OUT, 137591480872731L);
      this.ap = new ExpiringValue(180.0F, false, Easing.SINE_IN_OUT, 137591480872731L);
      this.at = new ElapsedTimer(106698256430889L);
      ColorSetting var10000 = this.q;
      Object[] var12 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var11 = var10000;
      var11.aReturningColorSetting(var12);
      var10000 = this.p;
      Object[] var14 = new Object[]{invokeBinding2(this), 41489415177024L};
      ColorSetting var13 = var10000;
      var13.aReturningColorSetting(var14);
      var10000 = this.o;
      Object[] var16 = new Object[]{invokeBinding3(this), 41489415177024L};
      ColorSetting var15 = var10000;
      var15.aReturningColorSetting(var16);
      ModeSetting var21 = this.g;
      Object[] var18 = new Object[]{invokeBinding4(this), 121607650890692L};
      ModeSetting var17 = var21;
      var17.aReturningModeSetting(var18);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 1771555009043L;
      long var6 = var2 ^ 38266410274184L;
      Object[] var9 = new Object[]{var4};
      AutoAnchor var8 = this;
      var8.A(var9);
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var6};
      RotationManager var10 = var10000;
      var10.dReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var8;
      RotationManager var40;
      label30: {
         long var4;
         AutoAnchor var39;
         long var2 = (Long)var1[0];
         var4 = var2 ^ 53418045767182L;
         long var6 = var2 ^ 18941404224204L;
         var8 = var2 ^ 64097829662901L;
         long var10 = var2 ^ 43943734930567L;
         long var12 = var2 ^ 53140845788220L;
         int var14 = Event.bReturningInt();
         int var42 = var14;
         AutoAnchor var41 = this;
         var39 = var41;
         AutoAnchor var34 = var41;
         label29:
         if (var42 == 0) {
            // int var43 = var34.ag;
            if (var43 != var44) {
               int var46 = var14;
               AutoAnchor var45 = this;
               var39 = var45;
               AutoAnchor var35 = var45;
               if (var46 != 0) {
                  break label29;
               }

               AutoAnchor var47 = var35;
               AutoAnchor var36 = var47;
               BooleanSetting var17 = var36.i;
               Boolean var18 = (Boolean)var17.aReturningObject();
               boolean var48 = var18;
               if (var48) {
                  int var50 = var14;
                  RotationManager var49 = Prestige.o;
                  var40 = var49;
                  RotationManager var37 = var49;
                  if (var50 != 0) {
                     break label30;
                  }

                  RotationManager var51 = var37;
                  RotationManager var38 = var51;
                  Object[] var22 = new Object[0];
                  RotationManager var21 = var38;
                  boolean var52 = var21.fReturningBoolean(var22);
                  if (var52) {
                     RotationManager var10000 = Prestige.o;
                     int var10001 = this.ag;
                     Object[] var10004 = new Object[]{null, var10};
                     var10004[0] = var10001;
                     Object[] var25 = var10004;
                     RotationManager var24 = var10000;
                     var24.hReturningVoid(var25);
                     Object[] var26 = new Object[]{this, var6};
                     SlotReservation.aReturningVoid(var26);
                     this.ag = -1;
                  }
               }
            }

            Object[] var29 = new Object[]{var12};
            AutoAnchor var28 = this;
            var28.y(var29);
            var39 = this;
         }

         Object[] var31 = new Object[]{var4};
         AutoAnchor var30 = var39;
         var30.A(var31);
         var40 = Prestige.o;
      }

      Object[] var33 = new Object[]{this, var8};
      RotationManager var32 = var40;
      var32.eReturningVoid(var33);
   }

   @Override
   public int a() {
      return 20;
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      long var10001 = 57789383794105L ^ 34440176433877L;
      Object[] var7 = new Object[]{48230767929196L};
      AutoAnchor var6 = this;
      var6.A(var7);
      List var8 = this.ai;
      var8.clear();
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      AutoAnchorState var7 = AutoAnchorState.IDLE;
      AutoAnchorState var6 = this.C;
      if (var6 != var7) {
         Object[] var5 = new Object[0];
         AttackInputEvent var4 = var1;
         var4.aReturningVoid(var5);
      }
   }

   @EventListener
   public void a(AttackTargetUpdateEvent var1) {
      AutoAnchorState var7 = AutoAnchorState.IDLE;
      AutoAnchorState var6 = this.C;
      if (var6 != var7) {
         Object[] var5 = new Object[0];
         AttackTargetUpdateEvent var4 = var1;
         var4.aReturningVoid(var5);
      }
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      AutoAnchorState var7 = AutoAnchorState.IDLE;
      AutoAnchorState var6 = this.C;
      if (var6 != var7) {
         Object[] var5 = new Object[0];
         ItemUseEvent var4 = var1;
         var4.aReturningVoid(var5);
      }
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      Object[] var5 = new Object[0];
      PlayerUpdateEvent var4 = var1;
      EventPhase var10000 = var4.aReturningEventPhase(var5);
      EventPhase var11 = EventPhase.PRE;
      EventPhase var10 = var10000;
      if (var10 == var11) {
         MinecraftClient var6 = b;
         ClientPlayerEntity var12 = var6.player;
         if (var12 != null) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            this.ah = var9.getEyePos();
         }
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.bReturningInt();
      Object[] var8 = new Object[0];
      PacketReceiveEvent var7 = var1;
      Packet var6 = var7.aReturningVoid(var8);
      int var4 = var10000;
      int var24 = var4;
      Packet var23 = var6;
      Packet var20 = var23;
      Packet var19 = var23;
      if (var24 == 0) {
         boolean var25 = var19 instanceof BlockUpdateS2CPacket;
         if (!var25) {
            return;
         }

         Packet var26 = var6;
         var20 = var26;
      }

      BlockUpdateS2CPacket var5 = (BlockUpdateS2CPacket)var20;
      this.V = this.V + /* /*DECRYPT:dev.zprestige.prestige.d1:5:8644:6525207996191914566*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.modules.AutoAnchor_8644";
      BlockUpdateS2CPacket var11 = var5;
      BlockState var33 = var11.getState();
      int var28 = var4;
      BlockState var27 = var33;
      BlockState var22 = var27;
      BlockState var21 = var27;
      if (var28 == 0) {
         BlockState var29 = var21;
         if (var29 == null) {
            return;
         }

         BlockUpdateS2CPacket var13 = var5;
         BlockState var30 = var13.getState();
         var22 = var30;
      }

      BlockState var15 = var22;
      Block var34 = var15.getBlock();
      Block var32 = Blocks.RESPAWN_ANCHOR;
      Block var31 = var34;
      if (var31 != var32) {
         List var35 = this.ai;
         BlockUpdateS2CPacket var16 = var5;
         BlockPos var18 = var16.getPos();
         List var17 = var35;
         var17.remove(var18);
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 86224347912705L ^ 33446737040283L;
      var10001 = 86224347912705L ^ 130719441553154L;
      var10001 = 86224347912705L ^ 24785262210236L;
      var10001 = 86224347912705L ^ 136885234946151L;
      int var12 = Event.cReturningInt();
      BooleanSetting var21 = this.n;
      Boolean var22 = (Boolean)var21.aReturningObject();
      boolean var90 = var22;
      if (var90) {
         int var92 = var12;
         MinecraftClient var91 = b;
         MinecraftClient var69 = var91;
         MinecraftClient var67 = var91;
         if (var92 != 0) {
            MinecraftClient var93 = var67;
            MinecraftClient var68 = var93;
            MinecraftClient var24 = var68;
            ClientPlayerEntity var94 = var24.player;
            if (var94 == null) {
               return;
            }

            MinecraftClient var95 = b;
            var69 = var95;
         }

         MinecraftClient var27 = var69;
         ClientWorld var96 = var27.world;
         if (var96 != null) {
            Object[] var29 = new Object[]{87964273183130L};
            float var13 = bReturningFloat(var29);
            PlayerEntity var97 = this.Y;
            byte var70;
            if (var97 != null) {
               byte var98 = 1;
               var70 = var98;
            } else {
               var70 = 0;
            }

            byte var14 = var70;
            byte var99 = var14;
            if (var99 != 0) {
               PlayerEntity var31 = this.Y;
               this.aq = var31.getBlockPos();
            }

            BlockPos var76;
            label111: {
               AutoAnchor var75;
               label110: {
                  ExpiringValue var10000 = this.an;
                  Object[] var10004 = new Object[]{null, null, 97725255202493L};
                  var10004[1] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var14));
                  var10004[0] = var10000;
                  Object[] var33 = var10004;
                  float var15 = cReturningFloat(var33);
                  float var150;
                  int var100 = (var150 = var15 - 0.01F) == 0.0F ? 0 : (var150 < 0.0F ? -1 : 1);
                  if (var100 > 0) {
                     int var102 = var12;
                     BlockPos var101 = this.aq;
                     var76 = var101;
                     BlockPos var71 = var101;
                     if (var102 == 0) {
                        break label111;
                     }

                     BlockPos var103 = var71;
                     BlockPos var72 = var103;
                     BlockPos var104 = var72;
                     if (var104 != null) {
                        int var106 = var12;
                        AutoAnchor var105 = this;
                        var75 = var105;
                        AutoAnchor var73 = var105;
                        if (var106 == 0) {
                           break label110;
                        }

                        AutoAnchor var107 = var73;
                        AutoAnchor var74 = var107;
                        ColorSetting var37 = var74.q;
                        Color var138 = (Color)var37.aReturningObject();
                        Object[] var10005 = new Object[]{null, null, null, 55064574888550L};
                        var10005[2] = var13;
                        var10005[1] = var15;
                        var10005[0] = var138;
                        Object[] var38 = var10005;
                        Color var16 = aReturningColor(var38);
                        Color var39 = var16;
                        int var108 = var39.getAlpha();
                        if (var108 > 0) {
                           Object[] var41 = new Object[]{var1, this.aq, var16, 62160361348355L};
                           AutoAnchor var40 = this;
                           var40.jReturningVoid(var41);
                        }
                     }
                  }

                  var75 = this;
               }

               var76 = var75.Z;
            }

            BlockPos var109 = var76;
            byte var77;
            if (var109 != null) {
               byte var110 = 1;
               var77 = var110;
            } else {
               var77 = 0;
            }

            byte var136 = var77;
            byte var111 = var136;
            if (var111 != 0) {
               this.ar = this.Z;
            }

            byte var86;
            label99: {
               label98: {
                  AutoAnchor var85;
                  label123: {
                     BlockPos var84;
                     label124: {
                        AutoAnchor var82;
                        label95: {
                           ExpiringValue var139 = this.ao;
                           Object[] var146 = new Object[]{null, null, 97725255202493L};
                           var146[1] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var136));
                           var146[0] = var139;
                           Object[] var45 = var146;
                           float var17 = cReturningFloat(var45);
                           float var151;
                           int var112 = (var151 = var17 - 0.01F) == 0.0F ? 0 : (var151 < 0.0F ? -1 : 1);
                           if (var112 > 0) {
                              int var114 = var12;
                              BlockPos var113 = this.ar;
                              var84 = var113;
                              BlockPos var78 = var113;
                              if (var114 == 0) {
                                 break label124;
                              }

                              BlockPos var115 = var78;
                              BlockPos var79 = var115;
                              BlockPos var116 = var79;
                              if (var116 != null) {
                                 int var118 = var12;
                                 AutoAnchor var117 = this;
                                 var82 = var117;
                                 AutoAnchor var80 = var117;
                                 if (var118 == 0) {
                                    break label95;
                                 }

                                 AutoAnchor var119 = var80;
                                 AutoAnchor var81 = var119;
                                 ColorSetting var49 = var81.o;
                                 Color var140 = (Color)var49.aReturningObject();
                                 Object[] var148 = new Object[]{null, null, null, 55064574888550L};
                                 var148[2] = var13;
                                 var148[1] = var17;
                                 var148[0] = var140;
                                 Object[] var50 = var148;
                                 Color var18 = aReturningColor(var50);
                                 Color var51 = var18;
                                 int var120 = var51.getAlpha();
                                 if (var120 > 0) {
                                    Object[] var53 = new Object[]{var1, this.ar, var18, 62160361348355L};
                                    AutoAnchor var52 = this;
                                    var52.jReturningVoid(var53);
                                 }
                              }
                           }

                           var82 = this;
                        }

                        int var122 = var12;
                        AutoAnchor var121 = var82;
                        var85 = var121;
                        AutoAnchor var83 = var121;
                        if (var122 == 0) {
                           break label123;
                        }

                        BlockPos var123 = var83.ac;
                        var84 = var123;
                     }

                     BlockPos var124 = var84;
                     if (var124 == null) {
                        break label98;
                     }

                     var85 = this;
                  }

                  AutoAnchorState var126 = AutoAnchorState.SAFE_COVER;
                  AutoAnchorState var125 = var85.C;
                  if (var125 == var126) {
                     byte var127 = 1;
                     var86 = var127;
                     break label99;
                  }
               }

               var86 = 0;
            }

            byte var137 = var86;
            byte var128 = var137;
            if (var128 != 0) {
               this.as = this.ac;
            }

            ExpiringValue var141 = this.ap;
            Object[] var147 = new Object[]{null, null, 97725255202493L};
            var147[1] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var137));
            var147[0] = var141;
            Object[] var58 = var147;
            float var19 = cReturningFloat(var58);
            float var152;
            int var129 = (var152 = var19 - 0.01F) == 0.0F ? 0 : (var152 < 0.0F ? -1 : 1);
            if (var129 > 0) {
               int var131 = var12;
               BlockPos var130 = this.as;
               Object var89 = var130;
               BlockPos var87 = var130;
               if (var131 != 0) {
                  BlockPos var132 = var87;
                  BlockPos var88 = var132;
                  BlockPos var133 = var88;
                  if (var133 == null) {
                     return;
                  }

                  ColorSetting var61 = this.p;
                  Object var134 = var61.aReturningObject();
                  var89 = var134;
               }

               Color var142 = (Color)var89;
               Object[] var149 = new Object[]{null, null, null, 55064574888550L};
               var149[2] = var13;
               var149[1] = var19;
               var149[0] = var142;
               Object[] var63 = var149;
               Color var20 = aReturningColor(var63);
               Color var64 = var20;
               int var135 = var64.getAlpha();
               if (var135 > 0) {
                  Object[] var66 = new Object[]{var1, this.as, var20, 62160361348355L};
                  AutoAnchor var65 = this;
                  var65.jReturningVoid(var66);
               }
            }

            return;
         }
      }
   }

   private static float bReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 2444992509633L ^ var1;
      double var3 = System.currentTimeMillis() / 900.0 * (Math.PI * 2);
      return 0.5F + 0.5F * (float)Math.sin(var3);
   }

   private static float cReturningFloat(Object[] var0) {
      ExpiringValue var4 = (ExpiringValue)var0[0];
      boolean var1 = (Boolean)var0[1];
      long var2 = (Long)var0[2];
      var2 = 2444992509633L ^ var2;
      long var5 = var2 ^ 54350111600688L;
      long var7 = var2 ^ 34090469513297L;
      int var9 = Event.bReturningInt();
      int var21 = var9;
      ExpiringValue var20 = var4;
      ExpiringValue var19 = var20;
      ExpiringValue var18 = var20;
      if (var21 == 0) {
         Object[] var11 = new Object[0];
         ExpiringValue var10 = var18;
         boolean var10000 = var10.aReturningBoolean(var11);
         boolean var23 = var1;
         boolean var22 = var10000;
         if (var22 != var23) {
            Object[] var10004 = new Object[]{null, var5};
            var10004[0] = var1;
            Object[] var14 = var10004;
            ExpiringValue var13 = var4;
            var13.aReturningVoid(var14);
         }

         var19 = var4;
      }

      Object[] var17 = new Object[]{var7};
      ExpiringValue var16 = var19;
      return var16.aReturningFloat(var17);
   }

   private static int aReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      float var2 = (Float)var0[1];
      float var5 = (Float)var0[2];
      long var3 = (Long)var0[3];
      var3 = 2444992509633L ^ var3;
      float var7 = var1 * var2 * (0.6F + 0.4F * var5);
      int var6 = Math.round(var7);
      byte var10000 = 0;
      short var10001 = 16780;
      long var10002 = 6983639963255910091L ^ var3;
      var10001 = 255;
      int var9 = var6;
      int var11 = Math.min(255, var9);
      return Math.max(0, var11);
   }

   private static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var3 = (Float)var0[1];
      float var2 = (Float)var0[2];
      long var4 = (Long)var0[3];
      var4 = 2444992509633L ^ var4;
      long var6 = var4 ^ 1316562043840L;
      Color var8 = var1;
      int var10002 = var8.getRed();
      Color var9 = var1;
      int var10003 = var9.getGreen();
      Color var10 = var1;
      int var10004 = var10.getBlue();
      Color var11 = var1;
      int var10005 = var11.getAlpha();
      Object[] var10010 = new Object[]{null, null, null, var6};
      var10010[2] = var2;
      var10010[1] = var3;
      var10010[0] = var10005;
      Object[] var12 = var10010;
      return new Color(var10002, var10003, var10004, aReturningInt(var12));
   }

   private void jReturningVoid(Object[] var1) {
      Render3DEvent var5 = (Render3DEvent)var1[0];
      BlockPos var2 = (BlockPos)var1[1];
      Color var6 = (Color)var1[2];
      long var3 = (Long)var1[3];
      var3 = 2444992509633L ^ var3;
      long var7 = var3 ^ 99834763459526L;
      RenderContext var10000 = var5.b;
      MeshBufferManager var10001 = var5.a;
      BlockPos var9 = var2;
      float var10002 = var9.getX();
      BlockPos var10 = var2;
      float var10003 = var10.getY();
      BlockPos var11 = var2;
      float var10004 = var11.getZ();
      BlockPos var12 = var2;
      float var10005 = var12.getX() + 1.0F;
      BlockPos var13 = var2;
      float var10006 = var13.getY() + 1.0F;
      BlockPos var14 = var2;
      float var10007 = var14.getZ() + 1.0F;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var6, var7};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var10003;
      var10011[2] = var10002;
      var10011[1] = var10001;
      var10011[0] = var10000;
      Object[] var15 = var10011;
      ShapeRenderer.gReturningVoid(var15);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 114834121695792L ^ 58300399912556L;
      var10001 = 114834121695792L ^ 21708404509615L;
      var10001 = 114834121695792L ^ 25231457448996L;
      var10001 = 114834121695792L ^ 74135235069806L;
      var10001 = 114834121695792L ^ 137009311421335L;
      var10001 = 114834121695792L ^ 137708373570770L;
      var10001 = 114834121695792L ^ 23727219271019L;
      int var10000 = Event.cReturningInt();
      this.K = this.K + /* /*DECRYPT:dev.zprestige.prestige.d1:6:5352:5020473390585417576*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.modules.AutoAnchor_5352";
      int var18 = var10000;
      HashMap var19 = this.J;
      byte var190 = ((byte)((var19.isEmpty()) ? 1 : 0));
      int var123 = var18;
      boolean var122 = dev.prestige.recovery.SourceSupport.asBoolean(var190);
      boolean var83 = var122;
      if (var123 != 0) {
         boolean var124 = var83;
         if (!var124) {
            HashMap var21 = this.J;
            Set var191 = var21.entrySet();
            Predicate var23 = invokeBinding7(this);
            Set var22 = var191;
            boolean var125 = var22.removeIf(var23);
         }
      }

      byte var94;
      label162: {
         boolean var95;
         label152: {
            label163: {
               int var127 = var18;
               MinecraftClient var126 = b;
               MinecraftClient var86 = var126;
               MinecraftClient var85 = var126;
               if (var127 != 0) {
                  MinecraftClient var25 = var85;
                  ClientPlayerEntity var128 = var25.player;
                  if (var128 == null) {
                     break label163;
                  }

                  MinecraftClient var129 = b;
                  var86 = var129;
               }

               int var131 = var18;
               MinecraftClient var130 = var86;
               MinecraftClient var88 = var130;
               MinecraftClient var87 = var130;
               if (var131 != 0) {
                  MinecraftClient var28 = var87;
                  ClientWorld var132 = var28.world;
                  if (var132 == null) {
                     break label163;
                  }

                  MinecraftClient var133 = b;
                  var88 = var133;
               }

               int var135 = var18;
               MinecraftClient var134 = var88;
               MinecraftClient var90 = var134;
               MinecraftClient var89 = var134;
               if (var135 != 0) {
                  MinecraftClient var31 = var89;
                  Screen var136 = var31.currentScreen;
                  if (var136 != null) {
                     break label163;
                  }

                  MinecraftClient var137 = b;
                  var90 = var137;
               }

               MinecraftClient var34 = var90;
               var190 = ((byte)((var34.isWindowFocused()) ? 1 : 0));
               int var139 = var18;
               byte var138 = var190;
               var94 = var138;
               byte var91 = var138;
               if (var139 == 0) {
                  break label162;
               }

               byte var140 = var91;
               if (var140 != 0) {
                  MinecraftClient var36 = b;
                  ClientPlayerEntity var37 = var36.player;
                  boolean var193 = var37.isUsingItem();
                  int var142 = var18;
                  boolean var141 = var193;
                  var95 = var141;
                  boolean var92 = var141;
                  if (var142 == 0) {
                     break label152;
                  }

                  boolean var143 = var92;
                  boolean var93 = var143;
                  boolean var144 = var93;
                  if (!var144) {
                     var95 = AutoObbyCrystal.R;
                     break label152;
                  }
               }
            }

            var94 = 0;
            break label162;
         }

         boolean var145 = var95;
         if (var145) {
            int var147 = var18;
            AutoAnchor var146 = this;
            AutoAnchor var98 = var146;
            AutoAnchor var96 = var146;
            if (var147 != 0) {
               AutoAnchor var148 = var96;
               AutoAnchor var97 = var148;
               AutoAnchorState var150 = AutoAnchorState.IDLE;
               AutoAnchorState var149 = var97.C;
               if (var149 != var150) {
                  Object[] var43 = new Object[]{22999824511399L};
                  AutoAnchor var42 = this;
                  var42.z(var43);
               }

               var98 = this;
            }

            Object[] var46 = new Object[]{47399583229278L};
            AutoAnchor var45 = var98;
            var45.y(var46);
            B = dev.prestige.recovery.SourceSupport.asBoolean(0);
            return;
         }

         int var153 = var18;
         AutoAnchorState var152 = AutoAnchorState.IDLE;
         AutoAnchorState var151 = this.C;
         AutoAnchorState var107 = var151;
         AutoAnchorState var108 = var152;
         AutoAnchorState var99 = var151;
         AutoAnchorState var100 = var152;
         if (var153 != 0) {
            AutoAnchor var106;
            label123: {
               AutoAnchorState var155 = var100;
               AutoAnchorState var154 = var99;
               label122:
               if (var154 != var155) {
                  int var157 = var18;
                  AutoAnchor var156 = this;
                  AutoAnchor var105 = var156;
                  AutoAnchor var101 = var156;
                  if (var157 != 0) {
                     AutoAnchor var158 = var101;
                     AutoAnchor var102 = var158;
                     Object[] var50 = new Object[]{23426323994338L};
                     AutoAnchor var49 = var102;
                     boolean var159 = var49.hReturningVoid(var50);
                     if (var159) {
                        int var161 = var18;
                        AutoAnchor var160 = this;
                        var106 = var160;
                        AutoAnchor var103 = var160;
                        if (var161 == 0) {
                           break label123;
                        }

                        AutoAnchor var162 = var103;
                        AutoAnchor var104 = var162;
                        Object[] var54 = new Object[]{138420545505115L};
                        AutoAnchor var53 = var104;
                        boolean var163 = var53.iReturningVoid(var54);
                        if (!var163) {
                           break label122;
                        }
                     }

                     AutoAnchor var164 = this;
                     var105 = var164;
                  }

                  Object[] var58 = new Object[]{22999824511399L};
                  AutoAnchor var57 = var105;
                  var57.z(var58);
               }

               var106 = this;
            }

            var108 = AutoAnchorState.IDLE;
            var107 = var106.C;
         }

         AutoAnchor var120;
         label111: {
            label110: {
               Object var119;
               label164: {
                  int var167 = var18;
                  AutoAnchorState var166 = var108;
                  AutoAnchorState var165 = var107;
                  AutoAnchorState var115 = var165;
                  AutoAnchorState var116 = var166;
                  AutoAnchorState var109 = var165;
                  AutoAnchorState var110 = var166;
                  if (var167 != 0) {
                     AutoAnchor var113;
                     label106: {
                        AutoAnchorState var169 = var110;
                        AutoAnchorState var168 = var109;
                        if (var168 != var169) {
                           int var171 = var18;
                           AutoAnchor var170 = this;
                           var113 = var170;
                           AutoAnchor var111 = var170;
                           if (var171 == 0) {
                              break label106;
                           }

                           AutoAnchor var172 = var111;
                           AutoAnchor var112 = var172;
                           ElapsedTimer var194 = var112.G;
                           Object[] var10004 = new Object[]{null, 139098136696340L};
                           var10004[0] = 200.0F;
                           Object[] var62 = var10004;
                           ElapsedTimer var61 = var194;
                           boolean var173 = var61.aReturningBoolean(var62);
                           if (var173) {
                              Object[] var65 = new Object[]{22999824511399L};
                              AutoAnchor var64 = this;
                              var64.z(var65);
                           }
                        }

                        var113 = this;
                     }

                     int var175 = var18;
                     AutoAnchorState var174 = var113.C;
                     var119 = var174;
                     AutoAnchorState var114 = var174;
                     if (var175 == 0) {
                        break label164;
                     }

                     AutoAnchorState var177 = AutoAnchorState.IDLE;
                     AutoAnchorState var176 = var114;
                     var115 = var176;
                     var116 = var177;
                  }

                  AutoAnchorState var179 = var116;
                  AutoAnchorState var178 = var115;
                  if (var178 == var179) {
                     Object[] var69 = new Object[]{47399583229278L};
                     AutoAnchor var68 = this;
                     var68.y(var69);
                     Object[] var71 = new Object[]{136126953515423L};
                     AutoAnchor var70 = this;
                     var70.u(var71);
                     int var180 = var18;
                     if (var180 != 0) {
                        break label110;
                     }
                  }

                  int var182 = var18;
                  AutoAnchor var181 = this;
                  var120 = var181;
                  AutoAnchor var117 = var181;
                  if (var182 == 0) {
                     break label111;
                  }

                  AutoAnchor var183 = var117;
                  AutoAnchor var118 = var183;
                  BooleanSetting var74 = var118.h;
                  Object var184 = var74.aReturningObject();
                  var119 = var184;
               }

               Boolean var76 = (Boolean)var119;
               boolean var185 = var76;
               if (!var185) {
                  RotationManager var195 = Prestige.o;
                  Object[] var78 = new Object[0];
                  RotationManager var77 = var195;
                  boolean var186 = var77.fReturningBoolean(var78);
                  if (var186) {
                     return;
                  }

                  Object[] var82 = new Object[]{102765576103004L};
                  AutoAnchor var81 = this;
                  var81.kReturningVoid(var82);
               }
            }

            var120 = this;
         }

         AutoAnchorState var188 = AutoAnchorState.IDLE;
         AutoAnchorState var187 = var120.C;
         byte var121;
         if (var187 != var188) {
            byte var189 = 1;
            var121 = var189;
         } else {
            var121 = 0;
         }

         B = dev.prestige.recovery.SourceSupport.asBoolean(var121);
         return;
      }

      B = dev.prestige.recovery.SourceSupport.asBoolean(var94);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 96627545688516L;
      long var6 = var2 ^ 138426539507609L;
      long var8 = var2 ^ 44646484695495L;
      long var10 = var2 ^ 77379818547405L;
      long var12 = var2 ^ 125156559193511L;
      long var14 = var2 ^ 34946022913716L;
      long var16 = var2 ^ 93958150853793L;
      long var18 = var2 ^ 95168056090189L;
      long var20 = var2 ^ 101783648619701L;
      int var22 = Event.bReturningInt();
      BooleanSetting var25 = this.h;
      Boolean var26 = (Boolean)var25.aReturningObject();
      boolean var112 = var26;
      if (!var112) {
         return null;
      }

      int var114 = var22;
      MinecraftClient var113 = b;
      MinecraftClient var88 = var113;
      MinecraftClient var87 = var113;
      if (var114 == 0) {
         MinecraftClient var28 = var87;
         ClientPlayerEntity var115 = var28.player;
         if (var115 == null) {
            return null;
         }

         MinecraftClient var116 = b;
         var88 = var116;
      }

      int var118 = var22;
      MinecraftClient var117 = var88;
      MinecraftClient var90 = var117;
      MinecraftClient var89 = var117;
      if (var118 == 0) {
         MinecraftClient var31 = var89;
         ClientWorld var119 = var31.world;
         if (var119 == null) {
            return null;
         }

         MinecraftClient var120 = b;
         var90 = var120;
      }

      int var122 = var22;
      MinecraftClient var121 = var90;
      MinecraftClient var92 = var121;
      MinecraftClient var91 = var121;
      if (var122 == 0) {
         MinecraftClient var34 = var91;
         Screen var123 = var34.currentScreen;
         if (var123 != null) {
            return null;
         }

         MinecraftClient var124 = b;
         var92 = var124;
      }

      MinecraftClient var37 = var92;
      int var10000 = (((var37.isWindowFocused()) ? 1 : 0));
      int var126 = var22;
      boolean var125 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var94 = var125;
      boolean var93 = var125;
      if (var126 == 0) {
         boolean var127 = var93;
         if (!var127) {
            return null;
         }

         MinecraftClient var39 = b;
         ClientPlayerEntity var40 = var39.player;
         boolean var128 = var40.isUsingItem();
         var94 = var128;
      }

      boolean var129 = var94;
      if (!var129) {
         int var131 = var22;
         AutoAnchor var130 = this;
         AutoAnchor var96 = var130;
         AutoAnchor var95 = var130;
         if (var131 == 0) {
            AutoAnchorState var133 = AutoAnchorState.IDLE;
            AutoAnchorState var132 = var95.C;
            if (var132 == var133) {
               return null;
            }

            AutoAnchor var134 = this;
            var96 = var134;
         }

         int var136 = var22;
         AutoAnchor var135 = var96;
         AutoAnchor var98 = var135;
         AutoAnchor var97 = var135;
         if (var136 == 0) {
            BlockPos var137 = var97.Z;
            if (var137 == null) {
               return null;
            }

            AutoAnchor var138 = this;
            var98 = var138;
         }

         PlayerEntity var139 = var98.Y;
         if (var139 != null) {
            int var141 = var22;
            boolean var140 = AutoObbyCrystal.R;
            boolean var100 = var140;
            boolean var99 = var140;
            if (var141 == 0) {
               boolean var142 = var99;
               if (var142) {
                  return null;
               }

               RotationManager var166 = Prestige.o;
               Object[] var51 = new Object[0];
               RotationManager var50 = var166;
               var100 = var50.fReturningBoolean(var51);
            }

            AutoAnchor var104;
            label140: {
               int var144 = var22;
               boolean var143 = var100;
               boolean var103 = var143;
               boolean var101 = var143;
               if (var144 == 0) {
                  boolean var145 = var101;
                  if (var145) {
                     return null;
                  }

                  int var147 = var22;
                  AutoAnchor var146 = this;
                  var104 = var146;
                  AutoAnchor var102 = var146;
                  if (var147 != 0) {
                     break label140;
                  }

                  Object[] var55 = new Object[]{var16};
                  AutoAnchor var54 = var102;
                  boolean var148 = var54.dReturningBoolean(var55);
                  var103 = var148;
               }

               boolean var149 = var103;
               if (!var149) {
                  return null;
               }

               var104 = this;
            }

            Object[] var59 = new Object[]{var12};
            AutoAnchor var58 = var104;
            Vec3d var23 = var58.aReturningVec3d(var59);
            int var151 = var22;
            AutoAnchor var150 = this;
            AutoAnchor var106 = var150;
            AutoAnchor var105 = var150;
            if (var151 == 0) {
               Object[] var61 = new Object[]{var23, var4};
               AutoAnchor var60 = var105;
               boolean var152 = var60.aReturningBoolean(var61);
               if (!var152) {
                  Vec3d var154 = var23;
                  if (var154 == null) {
                     Object[] var67 = new Object[]{var14};
                     AutoAnchor var66 = this;
                     var66.eReturningBoolean(var67);
                     return null;
                  }

                  RotationManager var167 = Prestige.o;
                  Object[] var70 = new Object[]{var23, var10};
                  RotationManager var69 = var167;
                  Rotation var24 = var69.aReturningdx_C0210(var70);
                  Object[] var71 = new Object[]{var24, var23, var20};
                  var24 = RotationUtil.dReturningdx_C0210(var71);
                  Object[] var73 = new Object[0];
                  Rotation var72 = var24;
                  float var168 = var72.aReturningFloat(var73);
                  MinecraftClient var74 = b;
                  ClientPlayerEntity var75 = var74.player;
                  float var169 = var168 - var75.getYaw();
                  Object[] var10003 = new Object[]{null, var6};
                  var10003[0] = var169;
                  Object[] var76 = var10003;
                  float var77 = RotationUtil.bReturningFloat(var76);
                  float var171;
                  var10000 = (var171 = Math.abs(var77) - 60.0F) == 0.0F ? 0 : (var171 < 0.0F ? -1 : 1);
                  int var156 = var22;
                  int var155 = var10000;
                  int var109 = var155;
                  int var107 = var155;
                  if (var156 == 0) {
                     int var157 = var107;
                     if (var157 >= 0) {
                        Object[] var80 = new Object[]{var8};
                        AutoAnchor var79 = this;
                        var79.z(var80);
                        return null;
                     }

                     int var159 = var22;
                     Rotation var158 = var24;
                     Rotation var110 = var158;
                     Rotation var108 = var158;
                     if (var159 != 0) {
                        return var110;
                     }

                     Object[] var83 = new Object[0];
                     Rotation var82 = var108;
                     byte var160 = ((byte)((var82.aReturningBoolean(var83)) ? 1 : 0));
                     var109 = var160;
                  }

                  int var161 = var109;
                  if (var161 == 0) {
                     Object[] var86 = new Object[]{var24, var18};
                     AutoAnchor var85 = this;
                     var85.lReturningVoid(var86);
                     AutoAnchorState var163 = AutoAnchorState.IDLE;
                     AutoAnchorState var162 = this.C;
                     Rotation var111;
                     if (var162 == var163) {
                        Object var164 = null;
                        var111 = (Rotation)var164;
                     } else {
                        var111 = var24;
                     }

                     return var111;
                  }

                  return var24;
               }

               AutoAnchor var153 = this;
               var106 = var153;
            }

            Object[] var65 = new Object[]{var8};
            AutoAnchor var64 = var106;
            var64.z(var65);
            return null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 58129803637561L;
      long var6 = var2 ^ 132648678484828L;
      long var8 = var2 ^ 83170651202362L;
      long var10 = var2 ^ 52669794945775L;
      long var12 = var2 ^ 20804628791130L;
      long var14 = var2 ^ 137401331256393L;
      long var16 = var2 ^ 59699692449372L;
      long var18 = var2 ^ 59037394658480L;
      int var20 = Event.cReturningInt();
      int var50 = var20;
      AutoAnchor var49 = this;
      AutoAnchor var44 = var49;
      AutoAnchor var43 = var49;
      if (var50 != 0) {
         Object[] var24 = new Object[]{var16};
         AutoAnchor var23 = var43;
         boolean var51 = var23.dReturningBoolean(var24);
         if (!var51) {
            return;
         }

         var44 = this;
      }

      Object[] var28 = new Object[]{var12};
      AutoAnchor var27 = var44;
      Vec3d var21 = var27.aReturningVec3d(var28);
      int var53 = var20;
      AutoAnchor var52 = this;
      AutoAnchor var46 = var52;
      AutoAnchor var45 = var52;
      if (var53 != 0) {
         Object[] var30 = new Object[]{var21, var4};
         AutoAnchor var29 = var45;
         boolean var54 = var29.aReturningBoolean(var30);
         if (!var54) {
            int var57 = var20;
            Vec3d var56 = var21;
            Vec3d var48 = var56;
            Vec3d var47 = var56;
            if (var57 != 0) {
               Vec3d var58 = var47;
               if (var58 == null) {
                  Object[] var37 = new Object[]{var14};
                  AutoAnchor var36 = this;
                  var36.eReturningBoolean(var37);
                  return;
               }

               var48 = var21;
            }

            Object[] var39 = new Object[]{var48, var6};
            Rotation var22 = RotationUtil.aReturningdx_C0210(var39);
            Object[] var40 = new Object[]{var22, var10};
            RotationUtil.aReturningVoid(var40);
            Object[] var42 = new Object[]{var22, var18};
            AutoAnchor var41 = this;
            var41.lReturningVoid(var42);
            return;
         }

         AutoAnchor var55 = this;
         var46 = var55;
      }

      Object[] var34 = new Object[]{var8};
      AutoAnchor var33 = var46;
      var33.z(var34);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 30981886726267L;
      int var6 = Event.bReturningInt();
      AutoAnchorState var7 = this.C;
      int var10000 = var7.ordinal();
      int var19 = var6;
      int var18 = var10000;
      int var16 = var18;
      int var15 = var18;
      if (var19 == 0) {
         int var20 = var15;
         switch (var20) {
            case 1:
               var16 = 1;
               break;
            case 2:
               ElapsedTimer var28 = this.D;
               Object[] var10 = new Object[]{this.j, var4};
               ElapsedTimer var9 = var28;
               return var9.bReturningBoolean(var10);
            case 3:
               ElapsedTimer var27 = this.E;
               Object[] var12 = new Object[]{this.k, var4};
               ElapsedTimer var11 = var27;
               return var11.bReturningBoolean(var12);
            case 4:
               ElapsedTimer var26 = this.F;
               Object[] var14 = new Object[]{this.l, var4};
               ElapsedTimer var13 = var26;
               return var13.bReturningBoolean(var14);
            default:
               return false;
         }
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var16);
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 61190024127171L;
      int var6 = Event.cReturningInt();
      int var15 = var6;
      AutoAnchor var14 = this;
      AutoAnchor var12 = var14;
      AutoAnchor var11 = var14;
      if (var15 != 0) {
         AutoAnchorState var7 = var11.C;
         int var16 = var7.ordinal();
         switch (var16) {
            case 1:
               AutoAnchor var17 = this;
               var12 = var17;
               break;
            case 2:
               return this.ae;
            case 3:
            case 4:
               Object[] var10 = new Object[]{this.Z, var4};
               return InteractionUtil.bReturningVec3d(var10);
            default:
               return null;
         }
      }

      return var12.ab;
   }

   private boolean aReturningBoolean(Object[] var1) {
      Vec3d var4 = (Vec3d)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 2444992509633L ^ var2;
      int var5 = Event.cReturningInt();
      int var28 = var5;
      Vec3d var27 = var4;
      Vec3d var19 = var27;
      Vec3d var18 = var27;
      if (var28 != 0) {
         Vec3d var29 = var18;
         if (var29 == null) {
            return false;
         }

         MinecraftClient var8 = b;
         ClientPlayerEntity var9 = var8.player;
         var19 = var9.getEyePos();
      }

      Vec3d var11 = var4;
      Vec3d var10 = var19;
      double var44;
      int var42 = (var44 = var10.distanceTo(var11) - 4.4) == 0.0 ? 0 : (var44 < 0.0 ? -1 : 1);
      int var31 = var5;
      int var30 = var42;
      int var25 = var30;
      int var20 = var30;
      if (var31 != 0) {
         int var32 = var20;
         if (var32 <= 0) {
            int var34 = var5;
            Vec3d var33 = this.ah;
            Vec3d var23 = var33;
            Vec3d var21 = var33;
            if (var34 != 0) {
               Vec3d var35 = var21;
               Vec3d var22 = var35;
               Vec3d var36 = var22;
               if (var36 == null) {
                  return false;
               }

               Vec3d var37 = this.ah;
               var23 = var37;
            }

            Vec3d var17 = var4;
            Vec3d var16 = var23;
            double var45;
            int var43 = (var45 = var16.distanceTo(var17) - 4.4) == 0.0 ? 0 : (var45 < 0.0 ? -1 : 1);
            int var39 = var5;
            int var38 = var43;
            var25 = var38;
            int var24 = var38;
            if (var39 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var25);
            }

            int var40 = var24;
            if (var40 <= 0) {
               return false;
            }
         }

         var25 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var25);
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 58732947741106L;
      int var6 = Event.bReturningInt();
      int var10000 = ++this.H;
      int var13 = var6;
      int var12 = var10000;
      int var11 = var12;
      int var10 = var12;
      if (var13 == 0) {
         byte var15 = 3;
         int var14 = var10;
         if (var14 >= var15) {
            Object[] var9 = new Object[]{var4};
            AutoAnchor var8 = this;
            var8.z(var9);
            return true;
         }

         var11 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var11);
   }

   private void lReturningVoid(Object[] var1) {
      Rotation var4;
      long var5;
      label29: {
         long var11;
         int var13;
         label28: {
            long var9;
            label27: {
               var4 = (Rotation)var1[0];
               long var2 = (Long)var1[1];
               var2 = 2444992509633L ^ var2;
               var5 = var2 ^ 2788814396332L;
               long var7 = var2 ^ 5934199570443L;
               var9 = var2 ^ 17822847465058L;
               var11 = var2 ^ 83871132563039L;
               var13 = Event.bReturningInt();
               int var30 = var13;
               AutoAnchor var29 = this;
               AutoAnchor var28 = var29;
               AutoAnchor var27 = var29;
               if (var30 == 0) {
                  AutoAnchorState var14 = var27.C;
                  int var31 = var14.ordinal();
                  switch (var31) {
                     case 1:
                        AutoAnchor var32 = this;
                        var28 = var32;
                        break;
                     case 2:
                        break label27;
                     case 3:
                        break label28;
                     case 4:
                        break label29;
                     default:
                        return;
                  }
               }

               Object[] var18 = new Object[]{var4, var7};
               AutoAnchor var17 = var28;
               var17.mReturningVoid(var18);
               int var33 = var13;
               if (var33 == 0) {
                  return;
               }
            }

            Object[] var20 = new Object[]{var4, var9};
            AutoAnchor var19 = this;
            var19.o(var20);
            int var34 = var13;
            if (var34 == 0) {
               return;
            }
         }

         Object[] var23 = new Object[]{var4, var11};
         AutoAnchor var22 = this;
         var22.q(var23);
         int var35 = var13;
         if (var35 == 0) {
            return;
         }
      }

      Object[] var26 = new Object[]{var4, var5};
      AutoAnchor var25 = this;
      var25.s(var26);
   }

   private void mReturningVoid(Object[] var1) {
      long var25;
      AutoAnchor var97;
      label85: {
         Rotation var2 = (Rotation)var1[0];
         long var3 = (Long)var1[1];
         var3 = 2444992509633L ^ var3;
         long var5 = var3 ^ 92999869118630L;
         long var7 = var3 ^ 67178278508119L;
         long var9 = var3 ^ 62854596165024L;
         long var11 = var3 ^ 125781724863925L;
         long var13 = var3 ^ 65227697631007L;
         long var15 = var3 ^ 51057715180368L;
         long var17 = var3 ^ 83713790503154L;
         long var19 = var3 ^ 135184469075488L;
         long var21 = var3 ^ 31130648561769L;
         long var23 = var3 ^ 80740936146470L;
         var25 = var3 ^ 135723955685249L;
         long var27 = var3 ^ 98384999085325L;
         long var29 = var3 ^ 73227386925353L;
         long var31 = var3 ^ 92467468424197L;
         int var33 = Event.cReturningInt();
         Object[] var36 = new Object[]{this.Z, Blocks.RESPAWN_ANCHOR, var7};
         int var10000 = (((BlockUtil.bReturningBoolean(var36)) ? 1 : 0));
         int var111 = var33;
         boolean var110 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
         boolean var96 = var110;
         boolean var94 = var110;
         if (var111 != 0) {
            boolean var112 = var94;
            if (var112) {
               Object[] var39 = new Object[]{var13};
               AutoAnchor var38 = this;
               var38.nReturningVoid(var39);
               return;
            }

            int var114 = var33;
            AutoAnchor var113 = this;
            var97 = var113;
            AutoAnchor var95 = var113;
            if (var114 == 0) {
               break label85;
            }

            Object[] var41 = new Object[]{var95.Z, var5};
            boolean var115 = BlockUtil.eReturningBoolean(var41);
            var96 = var115;
         }

         boolean var116 = var96;
         if (!var116) {
            Object[] var45 = new Object[]{Items.RESPAWN_ANCHOR, var9};
            Integer var34 = InventoryUtil.aReturningBoxedInteger(var45);
            int var117 = var33;
            if (var117 != 0) {
               Integer var118 = var34;
               if (var118 != null) {
                  Object[] var51 = new Object[]{var2, var19};
                  AutoAnchor var50 = this;
                  BlockHitResult var35 = var50.aReturningBlockHitResult(var51);
                  int var119 = var33;
                  if (var119 != 0) {
                     int var103;
                     label96: {
                        BlockHitResult var120 = var35;
                        if (var120 != null) {
                           BlockHitResult var53 = var35;
                           BlockPos var142 = var53.getBlockPos();
                           BlockPos var55 = this.aa;
                           BlockPos var54 = var142;
                           var10000 = (((var54.equals(var55)) ? 1 : 0));
                           int var122 = var33;
                           boolean var121 = ((((int)(var10000) & 1) != 0));
                           boolean var98 = var121;
                           if (var122 == 0) {
                              return;
                           }

                           boolean var123 = var98;
                           boolean var99 = var123;
                           boolean var124 = var99;
                           if (var124) {
                              BlockHitResult var58 = var35;
                              BlockPos var144 = var58.getBlockPos();
                              BlockHitResult var59 = var35;
                              Direction var61 = var59.getSide();
                              BlockPos var60 = var144;
                              BlockPos var145 = var60.offset(var61);
                              BlockPos var63 = this.Z;
                              BlockPos var62 = var145;
                              var10000 = (((var62.equals(var63)) ? 1 : 0));
                              int var126 = var33;
                              byte var125 = ((byte)(var10000));
                              var103 = var125;
                              byte var100 = var125;
                              if (var126 == 0) {
                                 break label96;
                              }

                              byte var127 = var100;
                              byte var101 = var127;
                              byte var128 = var101;
                              if (var128 != 0) {
                                 this.H = 0;
                                 var103 = this.ag;
                                 break label96;
                              }
                           }
                        }

                        Object[] var67 = new Object[]{var17};
                        AutoAnchor var66 = this;
                        boolean var129 = var66.eReturningBoolean(var67);
                        return;
                     }

                     label89: {
                        int var132 = var33;
                        // int var130 = var103;
                        int var107 = var130;
                        int var108 = var131;
                        int var104 = var130;
                        byte var105 = var131;
                        if (var132 != 0) {
                           byte var134 = var105;
                           int var133 = var104;
                           if (var133 == var134) {
                              Object[] var70 = new Object[]{this, var27};
                              this.ag = SlotReservation.aReturningInt(var70);
                           }

                           Object[] var72 = new Object[]{var29};
                           var10000 = InventoryUtil.aReturningInt(var72);
                           int var136 = var33;
                           int var135 = var10000;
                           int var106 = var135;
                           if (var136 == 0) {
                              break label89;
                           }

                           Integer var73 = var34;
                           int var138 = var73;
                           int var137 = var106;
                           var107 = var137;
                           var108 = var138;
                        }

                        int var140 = var108;
                        int var139 = var107;
                        if (var139 != var140) {
                           Integer var75 = var34;
                           var10000 = var75;
                           Object[] var10003 = new Object[]{null, var15};
                           var10003[0] = var10000;
                           Object[] var76 = var10003;
                           InventoryUtil.aReturningVoid(var76);
                           RotationManager var149 = Prestige.o;
                           Object[] var78 = new Object[]{true};
                           RotationManager var77 = var149;
                           var77.fReturningVoid(var78);
                           ElapsedTimer var150 = this.G;
                           Object[] var80 = new Object[]{var23};
                           ElapsedTimer var79 = var150;
                           var79.aReturningVoid(var80);
                           return;
                        }

                        Object[] var83 = new Object[]{var35, var11};
                        AutoAnchor var82 = this;
                        var82.t(var83);
                        BlockPos var85 = this.Z;
                        List var84 = this.ai;
                        boolean var109 = var84.add(var85);
                     }

                     ElapsedTimer var151 = this.D;
                     Object[] var87 = new Object[]{var23};
                     ElapsedTimer var86 = var151;
                     var86.aReturningVoid(var87);
                     MinMaxSetting var152 = this.j;
                     Object[] var89 = new Object[]{var21};
                     MinMaxSetting var88 = var152;
                     var88.bReturningVoid(var89);
                     Object[] var91 = new Object[]{var13};
                     AutoAnchor var90 = this;
                     var90.nReturningVoid(var91);
                     ElapsedTimer var153 = this.G;
                     Object[] var93 = new Object[]{var23};
                     ElapsedTimer var92 = var153;
                     var92.aReturningVoid(var93);
                     return;
                  }

                  return;
               }

               short var10001 = 12560;
               long var10002 = 2682580471313790626L ^ var3;
               Object[] var48 = new Object[]{"No respawn anchor in hotbar.", var31};
               AutoAnchor var47 = this;
               var47.x(var48);
            }

            return;
         }

         var97 = this;
      }

      Object[] var44 = new Object[]{var25};
      AutoAnchor var43 = var97;
      var43.z(var44);
   }

   private void nReturningVoid(Object[] var1) {
      label25: {
         AutoAnchor var10;
         long var2 = (Long)var1[0];
         long var10000 = 2444992509633L ^ var2;
         int var4 = Event.bReturningInt();
         int var12 = var4;
         AutoAnchor var11 = this;
         var10 = var11;
         AutoAnchor var7 = var11;
         label24:
         if (var12 == 0) {
            BooleanSetting var5 = var7.f;
            Boolean var6 = (Boolean)var5.aReturningObject();
            boolean var13 = var6;
            if (var13) {
               int var15 = var4;
               AutoAnchor var14 = this;
               var10 = var14;
               AutoAnchor var8 = var14;
               if (var15 != 0) {
                  break label24;
               }

               AutoAnchor var16 = var8;
               AutoAnchor var9 = var16;
               BlockPos var17 = var9.ac;
               if (var17 != null) {
                  this.C = AutoAnchorState.SAFE_COVER;
                  int var18 = var4;
                  if (var18 == 0) {
                     break label25;
                  }
               }
            }

            AutoAnchor var19 = this;
            var10 = var19;
         }

         var10.C = AutoAnchorState.CHARGE_ANCHOR;
      }

      this.H = 0;
   }

   private void o(Object[] var1) {
      long var21;
      AutoAnchor var99;
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 2444992509633L ^ var2;
      long var5 = var2 ^ 122746069864521L;
      long var7 = var2 ^ 9896520695296L;
      long var9 = var2 ^ 72314994544335L;
      long var11 = var2 ^ 101425308182607L;
      long var13 = var2 ^ 48904179944393L;
      long var15 = var2 ^ 83747958260580L;
      long var17 = var2 ^ 113480730536924L;
      long var19 = var2 ^ 96523111417664L;
      var21 = var2 ^ 94879370780730L;
      long var23 = var2 ^ 65145281676601L;
      long var25 = var2 ^ 98351514689179L;
      int var27 = Event.cReturningInt();
      int var117 = var27;
      AutoAnchor var116 = this;
      var99 = var116;
      AutoAnchor var94 = var116;
      label96:
      if (var117 != 0) {
         BlockPos var118 = var94.ac;
         if (var118 != null) {
            int var120 = var27;
            AutoAnchor var119 = this;
            var99 = var119;
            AutoAnchor var95 = var119;
            if (var120 == 0) {
               break label96;
            }

            AutoAnchor var121 = var95;
            AutoAnchor var96 = var121;
            BlockPos var122 = var96.ad;
            label103:
            if (var122 != null) {
               int var124 = var27;
               AutoAnchor var123 = this;
               AutoAnchor var100 = var123;
               AutoAnchor var97 = var123;
               if (var124 != 0) {
                  AutoAnchor var125 = var97;
                  AutoAnchor var98 = var125;
                  Vec3d var126 = var98.ae;
                  if (var126 == null) {
                     break label103;
                  }

                  var100 = this;
               }

               Object[] var39 = new Object[]{var100.ac, var9};
               int var10000 = (((BlockUtil.eReturningBoolean(var39)) ? 1 : 0));
               int var129 = var27;
               boolean var128 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
               boolean var102 = var128;
               boolean var101 = var128;
               if (var129 != 0) {
                  boolean var130 = var101;
                  if (var130) {
                     Object[] var42 = new Object[]{var21};
                     AutoAnchor var41 = this;
                     var41.p(var42);
                     return;
                  }

                  ModeSetting var44 = this.g;
                  String var159 = (String)var44.aReturningObject();
                  short var10001 = 22569;
                  long var10002 = 6146010266402580977L ^ var2;
                  String var46 = "Glowstone";
                  String var45 = var159;
                  var102 = var45.equals(var46);
               }

               boolean var131 = var102;
               Block var103;
               if (var131) {
                  Block var132 = Blocks.GLOWSTONE;
                  var103 = var132;
               } else {
                  var103 = Blocks.OBSIDIAN;
               }

               Block var28 = var103;
               Block var48 = var28;
               Object[] var49 = new Object[]{var48.asItem(), var13};
               Integer var29 = InventoryUtil.aReturningBoxedInteger(var49);
               int var133 = var27;
               if (var133 != 0) {
                  Integer var134 = var29;
                  if (var134 != null) {
                     Object[] var55 = new Object[]{var4, var5};
                     AutoAnchor var54 = this;
                     BlockHitResult var30 = var54.aReturningBlockHitResult(var55);
                     int var135 = var27;
                     if (var135 != 0) {
                        int var109;
                        label127: {
                           BlockHitResult var136 = var30;
                           if (var136 != null) {
                              BlockHitResult var57 = var30;
                              BlockPos var160 = var57.getBlockPos();
                              BlockPos var59 = this.ad;
                              BlockPos var58 = var160;
                              var10000 = (((var58.equals(var59)) ? 1 : 0));
                              int var138 = var27;
                              boolean var137 = ((((int)(var10000) & 1) != 0));
                              boolean var104 = var137;
                              if (var138 == 0) {
                                 return;
                              }

                              boolean var139 = var104;
                              boolean var105 = var139;
                              boolean var140 = var105;
                              if (var140) {
                                 BlockHitResult var62 = var30;
                                 BlockPos var162 = var62.getBlockPos();
                                 BlockHitResult var63 = var30;
                                 Direction var65 = var63.getSide();
                                 BlockPos var64 = var162;
                                 BlockPos var163 = var64.offset(var65);
                                 BlockPos var67 = this.ac;
                                 BlockPos var66 = var163;
                                 var10000 = (((var66.equals(var67)) ? 1 : 0));
                                 int var142 = var27;
                                 byte var141 = ((byte)(var10000));
                                 var109 = var141;
                                 byte var106 = var141;
                                 if (var142 == 0) {
                                    break label127;
                                 }

                                 byte var143 = var106;
                                 byte var107 = var143;
                                 byte var144 = var107;
                                 if (var144 != 0) {
                                    this.H = 0;
                                    var109 = this.ag;
                                    break label127;
                                 }
                              }
                           }

                           Object[] var71 = new Object[]{var25};
                           AutoAnchor var70 = this;
                           boolean var145 = var70.eReturningBoolean(var71);
                           return;
                        }

                        int var115;
                        label115: {
                           int var148 = var27;
                           // int var146 = var109;
                           int var113 = var146;
                           int var114 = var147;
                           int var110 = var146;
                           byte var111 = var147;
                           if (var148 != 0) {
                              byte var150 = var111;
                              int var149 = var110;
                              if (var149 == var150) {
                                 Object[] var74 = new Object[]{this, var15};
                                 this.ag = SlotReservation.aReturningInt(var74);
                              }

                              Object[] var76 = new Object[]{var19};
                              var10000 = InventoryUtil.aReturningInt(var76);
                              int var152 = var27;
                              int var151 = var10000;
                              var115 = var151;
                              int var112 = var151;
                              if (var152 == 0) {
                                 break label115;
                              }

                              Integer var77 = var29;
                              int var154 = var77;
                              int var153 = var112;
                              var113 = var153;
                              var114 = var154;
                           }

                           int var156 = var114;
                           int var155 = var113;
                           if (var155 == var156) {
                              Object[] var87 = new Object[]{var30, var17};
                              AutoAnchor var86 = this;
                              var86.t(var87);
                              ElapsedTimer var166 = this.E;
                              Object[] var89 = new Object[]{var11};
                              ElapsedTimer var88 = var166;
                              var88.aReturningVoid(var89);
                              MinMaxSetting var167 = this.k;
                              Object[] var91 = new Object[]{var7};
                              MinMaxSetting var90 = var167;
                              var90.bReturningVoid(var91);
                              this.C = AutoAnchorState.CHARGE_ANCHOR;
                              this.H = 0;
                              ElapsedTimer var168 = this.G;
                              Object[] var93 = new Object[]{var11};
                              ElapsedTimer var92 = var168;
                              var92.aReturningVoid(var93);
                              return;
                           }

                           Integer var79 = var29;
                           int var157 = var79;
                           var115 = var157;
                        }

                        Object[] var10003 = new Object[]{null, var23};
                        var10003[0] = var115;
                        Object[] var81 = var10003;
                        InventoryUtil.aReturningVoid(var81);
                        RotationManager var169 = Prestige.o;
                        Object[] var83 = new Object[]{true};
                        RotationManager var82 = var169;
                        var82.fReturningVoid(var83);
                        ElapsedTimer var170 = this.G;
                        Object[] var85 = new Object[]{var11};
                        ElapsedTimer var84 = var170;
                        var84.aReturningVoid(var85);
                        return;
                     }

                     return;
                  }

                  Object[] var52 = new Object[]{var21};
                  AutoAnchor var51 = this;
                  var51.p(var52);
               }

               return;
            }
         }

         AutoAnchor var127 = this;
         var99 = var127;
      }

      Object[] var38 = new Object[]{var21};
      AutoAnchor var37 = var99;
      var37.p(var38);
   }

   private void p(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 9128897347252L;
      this.C = AutoAnchorState.CHARGE_ANCHOR;
      this.H = 0;
      ElapsedTimer var10000 = this.G;
      Object[] var7 = new Object[]{var4};
      ElapsedTimer var6 = var10000;
      var6.aReturningVoid(var7);
   }

   private void q(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 2444992509633L ^ var2;
      long var5 = var2 ^ 127797920456707L;
      long var7 = var2 ^ 123180017241076L;
      long var9 = var2 ^ 65179279436769L;
      long var11 = var2 ^ 62544881237982L;
      long var13 = var2 ^ 113583097791748L;
      long var15 = var2 ^ 5503169420966L;
      long var17 = var2 ^ 56974797017204L;
      long var19 = var2 ^ 93949321838141L;
      long var21 = var2 ^ 329002969202L;
      long var23 = var2 ^ 17976151524185L;
      long var25 = var2 ^ 79434775988050L;
      long var27 = var2 ^ 12901958616957L;
      long var29 = var2 ^ 32140017295953L;
      int var31 = Event.bReturningInt();
      Object[] var35 = new Object[]{this.Z, Blocks.RESPAWN_ANCHOR, var5};
      int var10000 = (((BlockUtil.bReturningBoolean(var35)) ? 1 : 0));
      int var95 = var31;
      byte var94 = (byte)var10000;
      int var84 = var94;
      byte var83 = var94;
      if (var95 == 0) {
         byte var96 = var83;
         if (var96 == 0) {
            Object[] var38 = new Object[]{var15};
            AutoAnchor var37 = this;
            var37.eReturningBoolean(var38);
            return;
         }

         Object[] var41 = new Object[]{this.Z, var11};
         AutoAnchor var40 = this;
         var84 = var40.cReturningInt(var41);
      }

      int var32 = var84;
      int var97 = var31;
      if (var97 == 0) {
         int var98 = var32;
         if (var98 <= 0) {
            Object[] var46 = new Object[]{Items.GLOWSTONE, var7};
            Integer var33 = InventoryUtil.aReturningBoxedInteger(var46);
            int var99 = var31;
            if (var99 == 0) {
               Integer var100 = var33;
               if (var100 != null) {
                  Object[] var52 = new Object[]{var4, var17};
                  AutoAnchor var51 = this;
                  BlockHitResult var34 = var51.aReturningBlockHitResult(var52);
                  int var101 = var31;
                  if (var101 == 0) {
                     BlockHitResult var102 = var34;
                     label61:
                     if (var102 != null) {
                        BlockHitResult var54 = var34;
                        BlockPos var120 = var54.getBlockPos();
                        BlockPos var56 = this.Z;
                        BlockPos var55 = var120;
                        var10000 = (((var55.equals(var56)) ? 1 : 0));
                        int var104 = var31;
                        byte var103 = ((byte)(var10000));
                        int var87 = var103;
                        byte var85 = var103;
                        if (var104 == 0) {
                           byte var105 = var85;
                           byte var86 = var105;
                           byte var106 = var86;
                           if (var106 == 0) {
                              break label61;
                           }

                           this.H = 0;
                           var87 = this.ag;
                        }

                        int var93;
                        label78: {
                           int var109 = var31;
                           // int var107 = var87;
                           int var91 = var107;
                           int var92 = var108;
                           int var88 = var107;
                           byte var89 = var108;
                           if (var109 == 0) {
                              byte var111 = var89;
                              int var110 = var88;
                              if (var110 == var111) {
                                 Object[] var63 = new Object[]{this, var23};
                                 this.ag = SlotReservation.aReturningInt(var63);
                              }

                              Object[] var65 = new Object[]{var27};
                              var10000 = InventoryUtil.aReturningInt(var65);
                              int var113 = var31;
                              int var112 = var10000;
                              var93 = var112;
                              int var90 = var112;
                              if (var113 != 0) {
                                 break label78;
                              }

                              Integer var66 = var33;
                              int var115 = var66;
                              int var114 = var90;
                              var91 = var114;
                              var92 = var115;
                           }

                           int var117 = var92;
                           int var116 = var91;
                           if (var116 == var117) {
                              Object[] var76 = new Object[]{var34, var9};
                              AutoAnchor var75 = this;
                              var75.t(var76);
                              ElapsedTimer var123 = this.F;
                              Object[] var78 = new Object[]{var21};
                              ElapsedTimer var77 = var123;
                              var77.aReturningVoid(var78);
                              MinMaxSetting var124 = this.l;
                              Object[] var80 = new Object[]{var19};
                              MinMaxSetting var79 = var124;
                              var79.bReturningVoid(var80);
                              Object[] var82 = new Object[]{var25};
                              AutoAnchor var81 = this;
                              var81.r(var82);
                              return;
                           }

                           Integer var68 = var33;
                           int var118 = var68;
                           var93 = var118;
                        }

                        Object[] var10003 = new Object[]{null, var13};
                        var10003[0] = var93;
                        Object[] var70 = var10003;
                        InventoryUtil.aReturningVoid(var70);
                        RotationManager var125 = Prestige.o;
                        Object[] var72 = new Object[]{true};
                        RotationManager var71 = var125;
                        var71.fReturningVoid(var72);
                        ElapsedTimer var126 = this.G;
                        Object[] var74 = new Object[]{var21};
                        ElapsedTimer var73 = var126;
                        var73.aReturningVoid(var74);
                        return;
                     }

                     Object[] var60 = new Object[]{var15};
                     AutoAnchor var59 = this;
                     var59.eReturningBoolean(var60);
                  }

                  return;
               }

               short var10001 = 18864;
               long var10002 = 4041742948618287188L ^ var2;
               Object[] var49 = new Object[]{"No glowstone in hotbar.", var29};
               AutoAnchor var48 = this;
               var48.x(var49);
            }

            return;
         }

         Object[] var44 = new Object[]{var25};
         AutoAnchor var43 = this;
         var43.r(var44);
      }
   }

   private void r(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 81686107331041L;
      this.C = AutoAnchorState.DETONATE;
      this.H = 0;
      ElapsedTimer var10000 = this.G;
      Object[] var7 = new Object[]{var4};
      ElapsedTimer var6 = var10000;
      var6.aReturningVoid(var7);
   }

   private void s(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 2444992509633L ^ var2;
      long var5 = var2 ^ 122908005624946L;
      long var7 = var2 ^ 64827481148912L;
      long var9 = var2 ^ 129232019031570L;
      long var11 = var2 ^ 129934743245357L;
      long var13 = var2 ^ 75824242249204L;
      long var15 = var2 ^ 45643547076855L;
      long var17 = var2 ^ 83356074111829L;
      long var19 = var2 ^ 137576087502215L;
      long var21 = var2 ^ 58866176491060L;
      long var23 = var2 ^ 86320475030913L;
      long var25 = var2 ^ 137010693774374L;
      long var27 = var2 ^ 123767229906511L;
      long var29 = var2 ^ 92314836586402L;
      int var31 = Event.cReturningInt();
      Object[] var37 = new Object[]{this.Z, Blocks.RESPAWN_ANCHOR, var7};
      int var10000 = (((BlockUtil.bReturningBoolean(var37)) ? 1 : 0));
      int var146 = var31;
      byte var145 = (byte)var10000;
      int var117 = var145;
      byte var116 = var145;
      if (var146 != 0) {
         byte var147 = var116;
         if (var147 == 0) {
            Object[] var40 = new Object[]{var17};
            AutoAnchor var39 = this;
            var39.eReturningBoolean(var40);
            return;
         }

         Object[] var43 = new Object[]{this.Z, var11};
         AutoAnchor var42 = this;
         var117 = var42.cReturningInt(var43);
      }

      int var32 = var117;
      int var148 = var31;
      if (var148 != 0) {
         int var149 = var32;
         if (var149 > 0) {
            AutoAnchor var126;
            int var127;
            label120: {
               AutoAnchor var125;
               int var151 = var31;
               AutoAnchor var150 = this;
               var125 = var150;
               AutoAnchor var118 = var150;
               label119:
               if (var151 != 0) {
                  PlayerEntity var152 = var118.Y;
                  if (var152 != null) {
                     int var154 = var31;
                     AutoAnchor var153 = this;
                     var125 = var153;
                     AutoAnchor var119 = var153;
                     if (var154 == 0) {
                        break label119;
                     }

                     AutoAnchor var155 = var119;
                     AutoAnchor var120 = var155;
                     PlayerEntity var50 = var120.Y;
                     byte var157 = 2;
                     int var156 = var50.hurtTime;
                     if (var156 > var157) {
                        ElapsedTimer var198 = this.G;
                        Object[] var53 = new Object[]{var23};
                        ElapsedTimer var52 = var198;
                        var52.aReturningVoid(var53);
                        int var10001 = this.X + 1;
                        int var160 = var31;
                        int var159 = var10001;
                        AutoAnchor var158 = this;
                        var126 = var158;
                        var127 = var159;
                        AutoAnchor var121 = var158;
                        int var122 = var159;
                        if (var160 == 0) {
                           break label120;
                        }

                        int var162 = var122;
                        AutoAnchor var161 = var121;
                        AutoAnchor var123 = var161;
                        int var124 = var162;
                        var10000 = var123.X = var124;
                        short var209 = 2388;
                        long var10002 = 4530385551906718262L ^ var2;
                        byte var164 = 12;
                        int var163 = var10000;
                        if (var163 <= var164) {
                           return;
                        }
                     }
                  }

                  var125 = this;
               }

               var127 = 0;
               var126 = var125;
            }

            var126.X = var127;
            ExplosionDamageUtil var200 = Prestige.f;
            MinecraftClient var57 = b;
            BlockPos var58 = this.Z;
            Object[] var60 = new Object[]{var57.player, var58.toCenterPos(), var21};
            ExplosionDamageUtil var59 = var200;
            double var33 = var59.kReturningVoid(var60);
            MinecraftClient var61 = b;
            ClientPlayerEntity var62 = var61.player;
            float var201 = var62.getHealth();
            MinecraftClient var63 = b;
            ClientPlayerEntity var64 = var63.player;
            float var35 = var201 + var64.getAbsorptionAmount();
            FloatSetting var65 = this.d;
            Float var66 = (Float)var65.aReturningObject();
            double var213;
            var10000 = (var213 = var33 - var66.floatValue()) == 0.0 ? 0 : (var213 < 0.0 ? -1 : 1);
            int var166 = var31;
            int var165 = var10000;
            int var129 = var165;
            int var128 = var165;
            if (var166 != 0) {
               int var167 = var128;
               if (var167 > 0) {
                  HashMap var208 = this.J;
                  BlockPos var68 = this.Z;
                  BlockPos var211 = var68.toImmutable();
                  long var69 = this.K;
                  Long var73 = var69;
                  BlockPos var72 = var211;
                  HashMap var71 = var208;
                  var71.put(var72, var73);
                  Object[] var75 = new Object[]{var25};
                  AutoAnchor var74 = this;
                  var74.z(var75);
                  return;
               }

               BooleanSetting var77 = this.e;
               Boolean var78 = (Boolean)var77.aReturningObject();
               var129 = ((((java.lang.Boolean)(var78)).booleanValue() ? 1 : 0));
            }

            int var133;
            int var169 = var31;
            int var168 = var129;
            var133 = var168;
            int var130 = var168;
            label107:
            if (var169 != 0) {
               int var170 = var130;
               if (var170 != 0) {
                  double var214;
                  var10000 = (var214 = var33 - (var35 - 1.0F)) == 0.0 ? 0 : (var214 < 0.0 ? -1 : 1);
                  int var172 = var31;
                  int var171 = var10000;
                  var133 = var171;
                  int var131 = var171;
                  if (var172 == 0) {
                     break label107;
                  }

                  int var173 = var131;
                  int var132 = var173;
                  int var174 = var132;
                  if (var174 >= 0) {
                     Object[] var83 = new Object[]{var25};
                     AutoAnchor var82 = this;
                     var82.z(var83);
                     return;
                  }
               }

               Object[] var85 = new Object[]{Items.GLOWSTONE, var5};
               var133 = (((InventoryUtil.lReturningBoolean(var85)) ? 1 : 0));
            }

            int var139;
            label100: {
               AutoAnchor var138;
               label129: {
                  int var176 = var31;
                  int var175 = var133;
                  int var137 = var175;
                  int var134 = var175;
                  if (var176 != 0) {
                     int var177 = var134;
                     if (var177 == 0) {
                        Object[] var102 = new Object[]{var4, var19};
                        AutoAnchor var101 = this;
                        BlockHitResult var197 = var101.aReturningBlockHitResult(var102);
                        int var189 = var31;
                        if (var189 != 0) {
                           BlockHitResult var190 = var197;
                           if (var190 != null) {
                              BlockHitResult var104 = var197;
                              BlockPos var206 = var104.getBlockPos();
                              BlockPos var106 = this.Z;
                              BlockPos var105 = var206;
                              boolean var207 = var105.equals(var106);
                              int var192 = var31;
                              boolean var191 = var207;
                              boolean var142 = var191;
                              if (var192 == 0) {
                                 return;
                              }

                              boolean var193 = var142;
                              boolean var143 = var193;
                              boolean var194 = var143;
                              if (var194) {
                                 this.H = 0;
                                 Object[] var113 = new Object[]{var197, var9};
                                 AutoAnchor var112 = this;
                                 var112.t(var113);
                                 Object[] var115 = new Object[]{var25};
                                 AutoAnchor var114 = this;
                                 var114.z(var115);
                                 return;
                              }
                           }

                           Object[] var110 = new Object[]{var17};
                           AutoAnchor var109 = this;
                           boolean var195 = var109.eReturningBoolean(var110);
                        }

                        return;
                     }

                     int var179 = var31;
                     AutoAnchor var178 = this;
                     var138 = var178;
                     AutoAnchor var135 = var178;
                     if (var179 == 0) {
                        break label129;
                     }

                     AutoAnchor var180 = var135;
                     AutoAnchor var136 = var180;
                     int var181 = var136.ag;
                     var137 = var181;
                  }

                  // int var182 = var137;
                  if (var182 != var183) {
                     int var184 = this.ag;
                     var139 = var184;
                     break label100;
                  }

                  var138 = this;
               }

               Object[] var91 = new Object[]{var27};
               AutoAnchor var90 = var138;
               var139 = var90.dReturningInt(var91);
            }

            int var36 = var139;
            int var186 = var31;
            int var185 = var36;
            int var141 = var185;
            int var140 = var185;
            if (var186 != 0) {
               // int var187 = var140;
               if (var187 == var188) {
                  short var210 = 21884;
                  long var212 = 1718574966464776552L ^ var2;
                  Object[] var94 = new Object[]{"No non-glowstone slot to detonate with.", var29};
                  AutoAnchor var93 = this;
                  var93.x(var94);
                  return;
               }

               var141 = var36;
            }

            Object[] var10003 = new Object[]{null, var15};
            var10003[0] = var141;
            Object[] var96 = var10003;
            InventoryUtil.aReturningVoid(var96);
            RotationManager var204 = Prestige.o;
            Object[] var98 = new Object[]{true};
            RotationManager var97 = var204;
            var97.fReturningVoid(var98);
            ElapsedTimer var205 = this.G;
            Object[] var100 = new Object[]{var23};
            ElapsedTimer var99 = var205;
            var99.aReturningVoid(var100);
            return;
         }

         Object[] var46 = new Object[]{var13};
         AutoAnchor var45 = this;
         var45.p(var46);
      }
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      int var15;
      do {
         short var10001 = 26590;
         long var10002 = 1261404575693513781L ^ var2;
         byte var12 = 9;
         int var11 = var5;
         if (var11 >= var12) {
            break;
         }

         MinecraftClient var6 = b;
         ClientPlayerEntity var7 = var6.player;
         PlayerInventory var17 = var7.getInventory();
         int var9 = var5;
         PlayerInventory var8 = var17;
         ItemStack var10 = var8.getStack(var9);
         Item var18 = var10.getItem();
         Item var14 = Items.GLOWSTONE;
         Item var13 = var18;
         if (var13 != var14) {
            return var5;
         }

         var5++;
         var15 = var4;
      } while (var15 == 0);

      return -1;
   }

   private void t(Object[] var1) {
      BlockHitResult var4 = (BlockHitResult)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 2444992509633L ^ var2;
      MinecraftClient var6 = b;
      MinecraftClient var7 = b;
      BlockHitResult var11 = var4;
      Hand var10 = Hand.MAIN_HAND;
      ClientPlayerEntity var9 = var7.player;
      ClientPlayerInteractionManager var8 = var6.interactionManager;
      ActionResult var12 = var8.interactBlock(var9, var10, var11);
      boolean var5 = var12.isAccepted();
      RotationManager var19 = Prestige.o;
      Object[] var14 = new Object[]{true};
      RotationManager var13 = var19;
      var13.fReturningVoid(var14);
      boolean var18 = var5;
      if (var18) {
         MinecraftClient var15 = b;
         Hand var17 = Hand.MAIN_HAND;
         ClientPlayerEntity var16 = var15.player;
         var16.swingHand(var17);
      }
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 2444992509633L ^ var2;
      long var5 = var2 ^ 32021836948667L;
      int var10000 = Event.bReturningInt();
      Object[] var10 = new Object[]{var4, var5};
      HitResult var8 = RotationUtil.aReturningHitResult(var10);
      int var7 = var10000;
      int var15 = var7;
      HitResult var14 = var8;
      HitResult var12 = var14;
      HitResult var11 = var14;
      if (var15 == 0) {
         boolean var16 = var11 instanceof BlockHitResult;
         if (!var16) {
            return null;
         }

         HitResult var17 = var8;
         var12 = var17;
      }

      return (BlockHitResult)var12;
   }

   private void u(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 114834346003502L;
      long var6 = var2 ^ 110466373786966L;
      long var8 = var2 ^ 12683554739084L;
      long var10 = var2 ^ 11254074073361L;
      long var12 = var2 ^ 104464727471966L;
      long var14 = var2 ^ 100426342874149L;
      long var16 = var2 ^ 113989800403186L;
      long var18 = var2 ^ 70039388991055L;
      int var10000 = Event.cReturningInt();
      Object[] var26 = new Object[]{var18};
      PlayerEntity var21 = EntityUtil.aReturningPlayerEntity(var26);
      int var20 = var10000;
      int var104 = var20;
      if (var104 != 0) {
         PlayerEntity var105 = var21;
         label81:
         if (var105 != null) {
            PlayerEntity var28 = var21;
            byte var145 = ((byte)((var28.isAlive()) ? 1 : 0));
            int var107 = var20;
            byte var106 = var145;
            int var80 = var106;
            byte var78 = var106;
            if (var107 != 0) {
               byte var108 = var78;
               byte var79 = var108;
               byte var109 = var79;
               if (var109 == 0) {
                  break label81;
               }

               MinecraftClient var31 = b;
               PlayerEntity var33 = var21;
               ClientPlayerEntity var32 = var31.player;
               float var146 = var32.distanceTo((Entity)var33);
               FloatSetting var34 = this.a;
               Float var35 = (Float)var34.aReturningObject();
               float var154;
               int var110 = (var154 = var146 - var35) == 0.0F ? 0 : (var154 < 0.0F ? -1 : 1);
               var80 = var110;
            }

            AutoAnchor var85;
            PlayerEntity var86;
            label96: {
               int var112 = var20;
               int var111 = var80;
               int var84 = var111;
               int var81 = var111;
               if (var112 != 0) {
                  int var113 = var81;
                  if (var113 > 0) {
                     break label81;
                  }

                  int var116 = var20;
                  PlayerEntity var115 = var21;
                  AutoAnchor var114 = this;
                  var85 = var114;
                  var86 = var115;
                  AutoAnchor var82 = var114;
                  PlayerEntity var83 = var115;
                  if (var116 == 0) {
                     break label96;
                  }

                  Object[] var42 = new Object[]{var83, var14};
                  AutoAnchor var41 = var82;
                  byte var117 = ((byte)((var41.jReturningBoolean(var42)) ? 1 : 0));
                  var84 = var117;
               }

               int var118 = var84;
               if (var118 != 0) {
                  return;
               }

               var86 = var21;
               var85 = this;
            }

            label71: {
               AutoAnchor var103;
               label106: {
                  var85.Y = var86;
                  long var22 = this.V;
                  Object[] var45 = new Object[]{var6};
                  AutoAnchor var44 = this;
                  AnchorPlacementPlan var24 = var44.aReturninggb_C0328(var45);
                  int var120 = var20;
                  AnchorPlacementPlan var119 = var24;
                  AnchorPlacementPlan var89 = var119;
                  AnchorPlacementPlan var87 = var119;
                  if (var120 != 0) {
                     AnchorPlacementPlan var121 = var87;
                     if (var121 == null) {
                        long var155;
                        int var122 = (var155 = var22 - this.V) == 0L ? 0 : (var155 < 0L ? -1 : 1);
                        if (!((var122) != 0)) {
                           Object[] var10005 = new Object[]{null, null, var8};
                           var10005[1] = var22;
                           var10005[0] = var21;
                           Object[] var49 = var10005;
                           AutoAnchor var48 = this;
                           var48.v(var49);
                        }

                        this.Y = null;
                        return;
                     }

                     Object[] var52 = new Object[]{var4};
                     AutoAnchor var51 = this;
                     var51.w(var52);
                     this.Z = var24.recoveryAccess_read_a();
                     this.aa = var24.recoveryAccess_read_b();
                     this.ab = var24.recoveryAccess_read_c();
                     this.ac = var24.recoveryAccess_read_e();
                     this.ad = var24.recoveryAccess_read_f();
                     this.ae = var24.recoveryAccess_read_g();
                     int var124 = var20;
                     AutoAnchor var123 = this;
                     var103 = var123;
                     AutoAnchor var88 = var123;
                     if (var124 == 0) {
                        break label106;
                     }

                     PlayerEntity var53 = this.Y;
                     var88.af = var53.getBlockPos();
                     AnchorPlacementPlan var125 = var24;
                     var89 = var125;
                  }

                  boolean var126 = var89.recoveryAccess_read_d();
                  if (var126) {
                     AutoAnchor var101;
                     AutoAnchorState var102;
                     label61: {
                        Object[] var56 = new Object[]{this.Z, var16};
                        AutoAnchor var55 = this;
                        int var25 = var55.cReturningInt(var56);
                        BooleanSetting var57 = this.f;
                        Boolean var58 = (Boolean)var57.aReturningObject();
                        byte var10001 = ((byte)(((java.lang.Boolean)(var58)).booleanValue() ? 1 : 0));
                        int var129 = var20;
                        byte var128 = var10001;
                        AutoAnchor var127 = this;
                        AutoAnchor var97 = var127;
                        int var98 = var128;
                        AutoAnchor var90 = var127;
                        byte var91 = var128;
                        if (var129 != 0) {
                           byte var131 = var91;
                           AutoAnchor var130 = var90;
                           AutoAnchor var96 = var130;
                           AutoAnchor var92 = var130;
                           if (var131 != 0) {
                              AutoAnchor var132 = var92;
                              AutoAnchor var93 = var132;
                              BlockPos var134 = this.ac;
                              AutoAnchor var133 = var93;
                              var96 = var133;
                              AutoAnchor var94 = var133;
                              if (var134 != null) {
                                 AutoAnchor var135 = var94;
                                 AutoAnchor var95 = var135;
                                 AutoAnchorState var137 = AutoAnchorState.SAFE_COVER;
                                 AutoAnchor var136 = var95;
                                 var101 = var136;
                                 var102 = var137;
                                 break label61;
                              }
                           }

                           var98 = var25;
                           var97 = var96;
                        }

                        int var139 = var98;
                        AutoAnchor var138 = var97;
                        AutoAnchor var100 = var138;
                        AutoAnchor var99 = var138;
                        if (var139 > 0) {
                           AutoAnchorState var141 = AutoAnchorState.DETONATE;
                           AutoAnchor var140 = var99;
                           var101 = var140;
                           var102 = var141;
                        } else {
                           var102 = AutoAnchorState.CHARGE_ANCHOR;
                           var101 = var100;
                        }
                     }

                     var101.C = var102;
                     int var142 = var20;
                     if (var142 != 0) {
                        break label71;
                     }
                  }

                  AutoAnchor var143 = this;
                  var103 = var143;
               }

               var103.C = AutoAnchorState.PLACE_ANCHOR;
            }

            this.H = 0;
            ElapsedTimer var147 = this.G;
            Object[] var65 = new Object[]{var12};
            ElapsedTimer var64 = var147;
            var64.aReturningVoid(var65);
            ElapsedTimer var148 = this.D;
            Object[] var67 = new Object[]{var12};
            ElapsedTimer var66 = var148;
            var66.aReturningVoid(var67);
            MinMaxSetting var149 = this.j;
            Object[] var69 = new Object[]{var10};
            MinMaxSetting var68 = var149;
            var68.bReturningVoid(var69);
            ElapsedTimer var150 = this.E;
            Object[] var71 = new Object[]{var12};
            ElapsedTimer var70 = var150;
            var70.aReturningVoid(var71);
            MinMaxSetting var151 = this.k;
            Object[] var73 = new Object[]{var10};
            MinMaxSetting var72 = var151;
            var72.bReturningVoid(var73);
            ElapsedTimer var152 = this.F;
            Object[] var75 = new Object[]{var12};
            ElapsedTimer var74 = var152;
            var74.aReturningVoid(var75);
            MinMaxSetting var153 = this.l;
            Object[] var77 = new Object[]{var10};
            MinMaxSetting var76 = var153;
            var76.bReturningVoid(var77);
            return;
         }

         Object[] var39 = new Object[]{var4};
         AutoAnchor var38 = this;
         var38.w(var39);
      }
   }

   private Vec3d bReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 89369987858553L;
      Object[] var15 = new Object[]{this.Y, var4};
      Vec3d var7 = RaycastUtil.aReturningVec3d(var15);
      int var10000 = Event.bReturningInt();
      PlayerEntity var16 = this.Y;
      Vec3d var8 = var16.getVelocity();
      int var6 = var10000;
      Vec3d var17 = var8;
      double var72;
      var10000 = (var72 = var17.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var72 < 0.0 ? -1 : 1);
      int var54 = var6;
      int var53 = var10000;
      int var46 = var53;
      int var45 = var53;
      if (var54 == 0) {
         int var55 = var45;
         if (var55 < 0) {
            return var7;
         }

         var46 = 0;
      }

      int var9 = var46;
      MinecraftClient var20 = b;
      ClientPlayerEntity var21 = var20.player;
      ClientPlayNetworkHandler var68 = var21.networkHandler;
      PlayerEntity var22 = this.Y;
      UUID var24 = var22.getUuid();
      ClientPlayNetworkHandler var23 = var68;
      PlayerListEntry var10 = var23.getPlayerListEntry(var24);
      PlayerListEntry var56 = var10;
      if (var56 != null) {
         byte var69 = 0;
         PlayerListEntry var25 = var10;
         int var27 = var25.getLatency();
         var9 = Math.max(0, var27);
      }

      float var70 = 3.0F + var9 / 50.0F * 1.0F;
      float var30 = 20.0F;
      float var29 = 0.0F;
      float var28 = var70;
      float var11 = MathHelper.clamp(var28, var29, var30);
      Vec3d var31 = var8;
      double var10002 = var31.x * var11;
      Vec3d var32 = var8;
      Vec3d var12 = new Vec3d(var10002, 0.0, var32.z * var11);
      double var13 = 3.0;
      int var58 = var6;
      Vec3d var57 = var12;
      Vec3d var52 = var57;
      Vec3d var47 = var57;
      if (var58 == 0) {
         Vec3d var33 = var47;
         double var73;
         int var59 = (var73 = var33.lengthSquared() - var13 * var13) == 0.0 ? 0 : (var73 < 0.0 ? -1 : 1);
         if (var59 > 0) {
            int var61 = var6;
            Vec3d var60 = var12;
            Vec3d var50 = var60;
            Vec3d var48 = var60;
            Vec3d var51;
            if (var61 == 0) {
               Vec3d var62 = var48;
               Vec3d var49 = var62;
               Vec3d var36 = var49;
               double var74;
               int var63 = (var74 = var36.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var74 < 0.0 ? -1 : 1);
               if (var63 > 0) {
                  Vec3d var38 = var12;
                  Vec3d var71 = var38.normalize();
                  double var40 = var13;
                  Vec3d var39 = var71;
                  Vec3d var64 = var39.multiply(var40);
                  var51 = var64;
               } else {
                  var51 = Vec3d.ZERO;
               }
            } else {
               Vec3d var65 = var50;
               var51 = var65;
            }

            var12 = var51;
         }

         Vec3d var44 = var12;
         Vec3d var43 = var7;
         var52 = var43.add(var44);
      }

      return var52;
   }

   private AnchorPlacementPlan aReturninggb_C0328(Object[] var1) {
      dev.zprestige.prestige.client.modules.state.AnchorPlacementPlan var193;
      dev.zprestige.prestige.client.modules.state.AnchorPlacementEvaluation var194;
      net.minecraft.util.math.Vec3d var196;
      net.minecraft.util.math.Vec3d var197;
      dev.zprestige.prestige.client.modules.AutoAnchor var199;
      double var203;
      double var207;
      double var211;

      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 104566697614002L;
      long var6 = var2 ^ 113810572643596L;
      long var8 = var2 ^ 80320110773443L;
      long var10 = var2 ^ 40372291041865L;
      long var12 = var2 ^ 61926487969032L;
      long var14 = var2 ^ 80301558153039L;
      long var16 = var2 ^ 48084382108820L;
      long var18 = var2 ^ 115483701410824L;
      long var20 = var2 ^ 109678420120780L;
      long var22 = var2 ^ 103545277342512L;
      long var24 = var2 ^ 72876772403068L;
      long var26 = var2 ^ 114369603659428L;
      long var28 = var2 ^ 119183080680192L;
      long var30 = var2 ^ 49369244423620L;
      long var32 = var2 ^ 65377607405596L;
      long var34 = var2 ^ 93737743618395L;
      MinecraftClient var76 = b;
      ClientPlayerEntity var77 = var76.player;
      Vec3d var37 = var77.getEyePos();
      Object[] var78 = new Object[]{this.Y, var26};
      Vec3d var38 = RaycastUtil.aReturningVec3d(var78);
      Object[] var80 = new Object[]{var32};
      AutoAnchor var79 = this;
      Vec3d var39 = var79.bReturningVec3d(var80);
      Vec3d var82 = var38;
      Vec3d var81 = var39;
      Vec3d var40 = var81.subtract(var82);
      int var10000 = Event.cReturningInt();
      MinecraftClient var83 = b;
      ClientPlayerEntity var84 = var83.player;
      float var10001 = var84.getHealth();
      MinecraftClient var85 = b;
      ClientPlayerEntity var86 = var85.player;
      float var41 = var10001 + var86.getAbsorptionAmount();
      Object[] var88 = new Object[]{var37, var38, var39, var16};
      AutoAnchor var87 = this;
      List var42 = var87.bReturningList(var88);
      Comparator var90 = invokeBinding8();
      List var89 = var42;
      var89.sort(var90);
      int var36 = var10000;
      AnchorPlacementPlan var43 = null;
      double var44 = -Double.MAX_VALUE;
      int var191 = 25019;
      long var213 = 7256756332017578909L ^ var2;
      int var46 = Integer.MAX_VALUE;
      ModeSetting var91 = this.g;
      String var192 = (String)var91.aReturningObject();
      short var214 = 28446;
      long var10002 = 3215383144098916932L ^ var2;
      String var93 = "Glowstone";
      String var92 = var192;
      Block var47 = var92.equals(var93) ? Blocks.GLOWSTONE : Blocks.OBSIDIAN;
      Block var95 = var47;
      BlockState var48 = var95.getDefaultState();
      Block var96 = var47;
      Object[] var97 = new Object[]{var96.asItem(), var14};
      int var49 = InventoryUtil.aReturningBoxedInteger(var97) != null ? 1 : 0;
      List var99 = var42;
      Iterator var50 = var99.iterator();

      while (true) {
         Iterator var100 = var50;
         label247:
         if (var100.hasNext()) {
            Iterator var101 = var50;
            AnchorPlacementEvaluation var51 = (AnchorPlacementEvaluation)var101.next();
            var193 = var43;
            if (var36 == 0) {
               break;
            }

            label244: {
               if (var43 != null) {
                  var194 = var51;
                  if (var36 == 0) {
                     break label244;
                  }

                  double var195 = var51.recoveryAccess_read_s();
                  int var215 = var51.recoveryAccess_read_p();
                  Object[] var10006 = new Object[]{null, null, null, null, var4};
                  var10006[3] = var46;
                  var10006[2] = var44;
                  var10006[1] = var215;
                  var10006[0] = var195;
                  Object[] var104 = var10006;
                  if (!fReturningBoolean(var104)) {
                     break label247;
                  }
               }

               var194 = var51;
            }

            Vec3d var52;
            Vec3d var53;
            label236: {
               BlockPos var107 = var194.recoveryAccess_read_h();
               var52 = var107.toCenterPos();
               Object[] var108 = new Object[]{var51.recoveryAccess_read_h(), var6};
               var53 = InteractionUtil.bReturningVec3d(var108);
               if (var51.recoveryAccess_read_k()) {
                  var196 = var53;
                  if (var36 == 0) {
                     break label236;
                  }

                  if (var53 == null) {
                     continue;
                  }
               }

               var196 = var53;
            }

            label230: {
               if (var36 != 0) {
                  if (var196 != null) {
                     var197 = var53;
                     break label230;
                  }

                  var196 = var52;
               }

               double var116 = 0.5;
               Vec3d var113 = var196;
               var197 = var113.add(var114, var116, var118);
            }

            label254: {
               Vec3d var54 = var197;
               Vec3d var121 = var54;
               Vec3d var120 = var37;
               double var223;
               var191 = (var223 = var120.squaredDistanceTo(var121) - 19.360000000000003) == 0.0 ? 0 : (var223 < 0.0 ? -1 : 1);
               if (var36 != 0) {
                  if (var191 > 0) {
                     continue;
                  }

                  var199 = this;
                  if (var36 == 0) {
                     break label254;
                  }

                  BooleanSetting var123 = this.h;
                  Boolean var124 = (Boolean)var123.aReturningObject();
                  var191 = ((((java.lang.Boolean)(var124)).booleanValue() ? 1 : 0));
               }

               if (var191 != 0) {
                  Object[] var126 = new Object[]{var54, var12};
                  Rotation var55 = RotationUtil.aReturningdx_C0210(var126);
                  Object[] var128 = new Object[0];
                  Rotation var127 = var55;
                  float var200 = var127.aReturningFloat(var128);
                  MinecraftClient var129 = b;
                  ClientPlayerEntity var130 = var129.player;
                  float var201 = var200 - var130.getYaw();
                  Object[] var10003 = new Object[]{null, var22};
                  var10003[0] = var201;
                  Object[] var131 = var10003;
                  float var132 = RotationUtil.bReturningFloat(var131);
                  if (Math.abs(var132) >= 60.0F) {
                     continue;
                  }
               }

               var199 = this;
            }

            Object[] var135 = new Object[]{var51, var52, var40, var8};
            AutoAnchor var134 = var199;
            double var189 = var134.bReturningDouble(var135);
            double var202 = var189;
            if (var36 != 0) {
               FloatSetting var136 = this.c;
               Float var137 = (Float)var136.aReturningObject();
               if (var189 < var137.floatValue()) {
                  continue;
               }

               Object[] var10005 = new Object[]{null, null, null, var18};
               var10005[2] = 0.0;
               var10005[1] = var189;
               var10005[0] = var51;
               Object[] var140 = var10005;
               var202 = cReturningDouble(var140);
            }

            label216: {
               double var57 = var202;
               if (var43 != null) {
                  var203 = var57;
                  if (var36 == 0) {
                     break label216;
                  }

                  int var216 = var51.recoveryAccess_read_p();
                  Object[] var221 = new Object[]{null, null, null, null, var4};
                  var221[3] = var46;
                  var221[2] = var44;
                  var221[1] = var216;
                  var221[0] = var57;
                  Object[] var142 = var221;
                  if (!fReturningBoolean(var142)) {
                     continue;
                  }
               }

               ExplosionDamageUtil var204 = Prestige.f;
               MinecraftClient var145 = b;
               Object[] var147 = new Object[]{var145.player, var52, var24};
               ExplosionDamageUtil var146 = var204;
               var203 = var146.kReturningVoid(var147);
            }

            double var59;
            label210: {
               var59 = var203;
               BooleanSetting var148 = this.e;
               Boolean var149 = (Boolean)var148.aReturningObject();
               byte var205 = ((byte)(((java.lang.Boolean)(var149)).booleanValue() ? 1 : 0));
               if (var36 != 0) {
                  if (var205 == 0) {
                     break label210;
                  }

                  double var224;
                  var205 = (byte)((var224 = var59 - var41 * 2.0F) == 0.0 ? 0 : (var224 < 0.0 ? -1 : 1));
               }

               if (var205 >= 0) {
                  continue;
               }
            }

            BlockPos var61;
            BlockPos var62;
            Vec3d var63;
            double var64;
            label204: {
               label256: {
                  var61 = null;
                  var62 = null;
                  var63 = null;
                  var64 = var59;
                  BooleanSetting var152 = this.f;
                  Boolean var153 = (Boolean)var152.aReturningObject();
                  var191 = ((((java.lang.Boolean)(var153)).booleanValue() ? 1 : 0));
                  if (var36 != 0) {
                     if (var191 == 0) {
                        break label256;
                     }

                     var191 = var49;
                  }

                  label257: {
                     if (var36 != 0) {
                        if (var191 == 0) {
                           break label256;
                        }

                        var207 = var59;
                        if (var36 == 0) {
                           break label257;
                        }

                        double var225;
                        var191 = (var225 = var59 - 6.0) == 0.0 ? 0 : (var225 < 0.0 ? -1 : 1);
                     }

                     if (var191 <= 0) {
                        break label256;
                     }

                     var207 = var59;
                  }

                  double var66 = var207;
                  int[][] var68 = A;
                  int var69 = var68.length;
                  while (var70 < var69) {
                     int[] var71 = var68[var70];
                     int var217 = var71[0];
                     int var219 = var71[1];
                     int var161 = var71[2];
                     int var160 = var219;
                     int var159 = var217;
                     BlockPos var158 = var51.recoveryAccess_read_h();
                     BlockPos var72 = var158.add(var159, var160, var161);
                     label182:
                     if (var36 != 0) {
                        Object[] var162 = new Object[]{var72, var10};
                        var191 = (((BlockUtil.eReturningBoolean(var162)) ? 1 : 0));
                        if (var36 == 0) {
                           break label204;
                        }

                        if (var191 == 0) {
                           Object[] var165 = new Object[]{var72, var30};
                           if (!BlockUtil.gReturningBoolean(var165)) {
                              Object[] var169 = new Object[]{var72, var37, var34};
                              AutoAnchor var168 = this;
                              AnchorPlacementPoint var73 = var168.aReturninggd_C0332(var169);
                              if (var73 != null) {
                                 ExplosionDamageUtil var209 = Prestige.f;
                                 MinecraftClient var171 = b;
                                 Object[] var173 = new Object[]{var171.player, var52, var72, var48, var28};
                                 ExplosionDamageUtil var172 = var209;
                                 double var74 = var172.lReturningVoid(var173);
                                 if (var36 == 0) {
                                    break label182;
                                 }

                                 label175:
                                 if (!(var74 >= var66)) {
                                    double var210 = var59 - var74;
                                    if (var36 != 0) {
                                       if (var210 < 2.0) {
                                          break label175;
                                       }

                                       var210 = var74;
                                    }

                                    var66 = var210;
                                    var61 = var72;
                                    var62 = var73.recoveryAccess_read_t();
                                    var63 = var73.recoveryAccess_read_u();
                                 }
                              }
                           }
                        }

                        var70++;
                     }

                     if (var36 == 0) {
                        break;
                     }
                  }

                  if (var61 != null) {
                     var64 = var66;
                  }
               }

               FloatSetting var178 = this.d;
               Float var179 = (Float)var178.aReturningObject();
               double var226;
               var191 = (var226 = var64 - var179.floatValue()) == 0.0 ? 0 : (var226 < 0.0 ? -1 : 1);
            }

            if (var36 != 0) {
               if (var191 > 0) {
                  continue;
               }

               BooleanSetting var181 = this.e;
               Boolean var182 = (Boolean)var181.aReturningObject();
               var191 = ((((java.lang.Boolean)(var182)).booleanValue() ? 1 : 0));
            }

            label159: {
               label158: {
                  if (var36 != 0) {
                     if (var191 == 0) {
                        break label158;
                     }

                     var211 = var64;
                     if (var36 == 0) {
                        break label159;
                     }

                     double var227;
                     var191 = (var227 = var64 - (var41 - 1.0F)) == 0.0 ? 0 : (var227 < 0.0 ? -1 : 1);
                  }

                  if (var191 >= 0) {
                     continue;
                  }
               }

               Object[] var220 = new Object[]{null, null, null, var18};
               var220[2] = var64;
               var220[1] = var189;
               var220[0] = var51;
               Object[] var186 = var220;
               var211 = cReturningDouble(var186);
            }

            label149: {
               double var190 = var211;
               int var218 = var51.recoveryAccess_read_p();
               Object[] var222 = new Object[]{null, null, null, null, var20};
               var222[3] = var46;
               var222[2] = var44;
               var222[1] = var218;
               var222[0] = var190;
               Object[] var187 = var222;
               var191 = (((gReturningBoolean(var187)) ? 1 : 0));
               if (var36 != 0) {
                  if (var191 == 0) {
                     break label149;
                  }

                  var44 = var190;
                  var191 = var51.recoveryAccess_read_p();
               }

               var46 = var191;
               var43 = new AnchorPlacementPlan(var51.recoveryAccess_read_h(), var51.recoveryAccess_read_i(), var51.recoveryAccess_read_j(), var51.recoveryAccess_read_k(), var61, var62, var63);
            }

            if (var36 != 0) {
               continue;
            }
         }

         var193 = var43;
         break;
      }

      return var193;
   }

   private List bReturningList(Object[] var1) {
      Vec3d var3 = (Vec3d)var1[0];
      Vec3d var4 = (Vec3d)var1[1];
      Vec3d var2 = (Vec3d)var1[2];
      long var5 = (Long)var1[3];
      var5 = 2444992509633L ^ var5;
      long var7 = var5 ^ 14521963626524L;
      long var9 = var5 ^ 110746692169453L;
      long var11 = var5 ^ 106147595027738L;
      long var13 = var5 ^ 51523065650514L;
      long var15 = var5 ^ 5928869818257L;
      long var17 = var5 ^ 44393351639344L;
      long var19 = var5 ^ 137180257331982L;
      long var21 = var5 ^ 58464816810735L;
      long var23 = var5 ^ 103599144854399L;
      ArrayList var26 = new ArrayList();
      int var10000 = Event.cReturningInt();
      PlayerEntity var55 = this.Y;
      BlockPos var27 = var55.getBlockPos();
      int var25 = var10000;
      Mutable var28 = new Mutable();
      Object[] var56 = new Object[]{Items.RESPAWN_ANCHOR, var11};
      Integer var188 = InventoryUtil.aReturningBoxedInteger(var56);
      byte var140;
      if (var188 != null) {
         byte var189 = 1;
         var140 = var189;
      } else {
         var140 = 0;
      }

      byte var29 = var140;
      Object[] var58 = new Object[]{Items.GLOWSTONE, var11};
      Integer var190 = InventoryUtil.aReturningBoxedInteger(var58);
      byte var141;
      if (var190 != null) {
         byte var191 = 1;
         var141 = var191;
      } else {
         var141 = 0;
      }

      byte var30 = var141;
      Object[] var61 = new Object[]{var13};
      AutoAnchor var60 = this;
      var10000 = var60.dReturningInt(var61);
      int var193 = var25;
      int var192 = var10000;
      int var143 = var192;
      int var142 = var192;
      if (var193 != 0) {
         // int var194 = var142;
         if (var194 == var195) {
            return var26;
         }

         short var281 = 28453;
         long var10001 = 7816405482094348113L ^ var5;
         var143 = -5;
      }

      int var32 = var143;

      while (true) {
         int var144 = var32;

         label231:
         while (true) {
            byte var197 = 5;
            int var196 = var144;
            if (var196 > var197) {
               return var26;
            }

            int var33 = -1;

            label228:
            while (true) {
               int var145 = var33;

               label226:
               while (true) {
                  byte var199 = 1;
                  int var198 = var145;
                  if (var198 > var199) {
                     break label228;
                  }

                  int var282 = 196;
                  long var288 = 3372522083791120566L ^ var5;
                  int var201 = var25;
                  byte var200 = -5;
                  var144 = var200;
                  byte var146 = var200;
                  if (var201 == 0) {
                     continue label231;
                  }

                  int var34 = var146;

                  int var275;
                  do {
                     byte var203 = 5;
                     int var202 = var34;
                     if (var202 > var203) {
                        break;
                     }

                     BlockPos var64 = var27;
                     int var289 = var64.getX() + var32;
                     BlockPos var65 = var27;
                     int var10002 = var65.getY() + var33;
                     BlockPos var66 = var27;
                     int var70 = var66.getZ() + var34;
                     int var69 = var10002;
                     int var68 = var289;
                     Mutable var67 = var28;
                     var67.set(var68, var69, var70);
                     Mutable var71 = var28;
                     double var291 = var71.getX() + 0.5;
                     Mutable var72 = var28;
                     double var10003 = var72.getY() + 0.5;
                     Mutable var73 = var28;
                     Vec3d var35 = new Vec3d(var291, var10003, var73.getZ() + 0.5);
                     Vec3d var75 = var35;
                     Vec3d var74 = var3;
                     double var36 = var74.squaredDistanceTo(var75);
                     double var292;
                     var282 = (var292 = var36 - 21.159999999999997) == 0.0 ? 0 : (var292 < 0.0 ? -1 : 1);
                     int var205 = var25;
                     int var204 = var282;
                     var145 = var204;
                     int var147 = var204;
                     if (var205 == 0) {
                        continue label226;
                     }

                     label240: {
                        int var207 = var25;
                        int var206 = var147;
                        int var149 = var206;
                        int var148 = var206;
                        if (var207 != 0) {
                           int var208 = var148;
                           if (var208 > 0) {
                              break label240;
                           }

                           HashMap var77 = this.J;
                           var149 = (((var77.isEmpty()) ? 1 : 0));
                        }

                        int var153;
                        int var210 = var25;
                        int var209 = var149;
                        var153 = var209;
                        int var150 = var209;
                        label214:
                        if (var210 != 0) {
                           int var211 = var150;
                           if (var211 == 0) {
                              Mutable var80 = var28;
                              HashMap var79 = this.J;
                              byte var284 = ((byte)((var79.containsKey(var80)) ? 1 : 0));
                              int var213 = var25;
                              byte var212 = var284;
                              var153 = var212;
                              byte var151 = var212;
                              if (var213 == 0) {
                                 break label214;
                              }

                              byte var214 = var151;
                              byte var152 = var214;
                              byte var215 = var152;
                              if (var215 != 0) {
                                 break label240;
                              }
                           }

                           Object[] var83 = new Object[]{var28, Blocks.RESPAWN_ANCHOR, var9};
                           var153 = (((BlockUtil.bReturningBoolean(var83)) ? 1 : 0));
                        }

                        int var38;
                        Object var39;
                        BlockPos var40;
                        Vec3d var41;
                        label241: {
                           var38 = var153;
                           var40 = null;
                           var41 = null;
                           int var217 = var25;
                           int var216 = var38;
                           int var155 = var216;
                           int var154 = var216;
                           if (var217 != 0) {
                              int var218 = var154;
                              if (var218 != 0) {
                                 Mutable var85 = var28;
                                 var39 = var85.toImmutable();
                                 int var219 = var25;
                                 if (var219 != 0) {
                                    break label241;
                                 }
                              }

                              byte var220 = var29;
                              var155 = var220;
                           }

                           int var222 = var25;
                           int var221 = var155;
                           int var157 = var221;
                           int var156 = var221;
                           if (var222 != 0) {
                              int var223 = var156;
                              if (var223 == 0) {
                                 break label240;
                              }

                              var157 = var30;
                           }

                           int var225 = var25;
                           int var224 = var157;
                           int var159 = var224;
                           int var158 = var224;
                           if (var225 != 0) {
                              int var226 = var158;
                              if (var226 == 0) {
                                 break label240;
                              }

                              BooleanSetting var89 = this.m;
                              Boolean var90 = (Boolean)var89.aReturningObject();
                              byte var227 = ((byte)(((java.lang.Boolean)(var90)).booleanValue() ? 1 : 0));
                              var159 = var227;
                           }

                           int var229 = var25;
                           int var228 = var159;
                           int var161 = var228;
                           int var160 = var228;
                           if (var229 != 0) {
                              int var230 = var160;
                              if (var230 != 0) {
                                 break label240;
                              }

                              Object[] var93 = new Object[]{var28, var7};
                              byte var231 = ((byte)((BlockUtil.eReturningBoolean(var93)) ? 1 : 0));
                              var161 = var231;
                           }

                           Object var166;
                           label242: {
                              int var233 = var25;
                              int var232 = var161;
                              int var165 = var232;
                              int var162 = var232;
                              if (var233 != 0) {
                                 int var234 = var162;
                                 if (var234 != 0) {
                                    break label240;
                                 }

                                 int var236 = var25;
                                 Mutable var235 = var28;
                                 var166 = var235;
                                 Mutable var163 = var235;
                                 if (var236 == 0) {
                                    break label242;
                                 }

                                 Mutable var237 = var163;
                                 Mutable var164 = var237;
                                 Object[] var97 = new Object[]{var164, var15};
                                 byte var238 = ((byte)((BlockUtil.gReturningBoolean(var97)) ? 1 : 0));
                                 var165 = var238;
                              }

                              int var239 = var165;
                              if (var239 != 0) {
                                 break label240;
                              }

                              Mutable var99 = var28;
                              var166 = var99.toImmutable();
                           }

                           var39 = var166;
                           Object[] var101 = new Object[]{var39, var3, var19};
                           AutoAnchor var100 = this;
                           AnchorPlacementPoint var42 = var100.aReturninggd_C0332(var101);
                           int var241 = var25;
                           AnchorPlacementPoint var240 = var42;
                           AnchorPlacementPoint var168 = var240;
                           AnchorPlacementPoint var167 = var240;
                           if (var241 != 0) {
                              AnchorPlacementPoint var242 = var167;
                              if (var242 == null) {
                                 break label240;
                              }

                              var168 = var42;
                           }

                           var40 = var168.recoveryAccess_read_t();
                           var41 = var42.recoveryAccess_read_u();
                        }

                        int var244 = var25;
                        int var243 = var38;
                        int var170 = var243;
                        int var169 = var243;
                        int var171;
                        if (var244 != 0) {
                           int var245 = var169;
                           if (var245 != 0) {
                              Object[] var105 = new Object[]{var39, var17};
                              AutoAnchor var104 = this;
                              int var246 = var104.cReturningInt(var105);
                              var171 = var246;
                           } else {
                              var171 = 0;
                           }
                        } else {
                           int var247 = var170;
                           var171 = var247;
                        }

                        int var279;
                        label244: {
                           var279 = var171;
                           int var249 = var25;
                           int var248 = var38;
                           int var173 = var248;
                           int var172 = var248;
                           if (var249 != 0) {
                              int var250 = var172;
                              if (var250 == 0) {
                                 break label244;
                              }

                              var173 = var279;
                           }

                           int var252 = var25;
                           int var251 = var173;
                           int var175 = var251;
                           int var174 = var251;
                           if (var252 != 0) {
                              int var253 = var174;
                              if (var253 > 0) {
                                 break label244;
                              }

                              var175 = var30;
                           }

                           int var254 = var175;
                           if (var254 == 0) {
                              break label240;
                           }
                        }

                        Object[] var109 = new Object[]{var4, var35, var23};
                        double var43 = aReturningDouble(var109);
                        Object[] var110 = new Object[]{var2, var35, var23};
                        double var45 = aReturningDouble(var110);
                        double var113 = var45;
                        double var111 = var43;
                        double var47 = Math.max(var111, var113);
                        int var257 = var25;
                        double var255 = var47;
                        double var178 = var255;
                        double var176 = var255;
                        if (var257 != 0) {
                           FloatSetting var115 = this.c;
                           Float var116 = (Float)var115.aReturningObject();
                           double var293;
                           int var258 = (var293 = var176 - var116.floatValue()) == 0.0 ? 0 : (var293 < 0.0 ? -1 : 1);
                           if (var258 < 0) {
                              break label240;
                           }

                           double var119 = var36;
                           var178 = Math.sqrt(var119);
                        }

                        double var49 = var178;
                        Object var121 = var39;
                        var282 = ((BlockPos)var121).getY();
                        int var260 = var25;
                        int var259 = var282;
                        int var181 = var259;
                        int var180 = var259;
                        int var182;
                        if (var260 != 0) {
                           BlockPos var122 = var27;
                           int var262 = var122.getY();
                           int var261 = var180;
                           if (var261 == var262) {
                              byte var263 = 1;
                              var182 = var263;
                           } else {
                              var182 = 0;
                           }
                        } else {
                           int var264 = var181;
                           var182 = var264;
                        }

                        int var51;
                        int var187;
                        label151: {
                           label245: {
                              var51 = var182;
                              int var266 = var25;
                              int var265 = var51;
                              int var184 = var265;
                              int var183 = var265;
                              if (var266 != 0) {
                                 int var267 = var183;
                                 if (var267 == 0) {
                                    break label245;
                                 }

                                 Object var126 = var39;
                                 var282 = ((BlockPos)var126).getX();
                                 BlockPos var127 = var27;
                                 int var128 = var282 - var127.getX();
                                 var282 = Math.abs(var128);
                                 Object var129 = var39;
                                 int var290 = ((BlockPos)var129).getZ();
                                 BlockPos var130 = var27;
                                 int var131 = var290 - var130.getZ();
                                 int var133 = Math.abs(var131);
                                 int var132 = var282;
                                 int var268 = Math.max(var132, var133);
                                 var184 = var268;
                              }

                              int var270 = var25;
                              int var269 = var184;
                              int var186 = var269;
                              int var185 = var269;
                              if (var270 == 0) {
                                 int var274 = var186;
                                 var187 = var274;
                                 break label151;
                              }

                              byte var272 = 1;
                              int var271 = var185;
                              if (var271 == var272) {
                                 byte var273 = 1;
                                 var187 = var273;
                                 break label151;
                              }
                           }

                           var187 = 0;
                        }

                        int var52 = var187;
                        Object[] var10009 = new Object[]{null, null, null, null, null, null, null, var21};
                        var10009[6] = var279;
                        var10009[5] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var38));
                        var10009[4] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var52));
                        var10009[3] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var51));
                        var10009[2] = var49;
                        var10009[1] = 0.0;
                        var10009[0] = var47;
                        Object[] var137 = var10009;
                        double var53 = dReturningDouble(var137);
                        AnchorPlacementEvaluation var139 = new AnchorPlacementEvaluation(
                           (BlockPos)var39, var40, var41, dev.prestige.recovery.SourceSupport.asBoolean(var38), var279, var49, dev.prestige.recovery.SourceSupport.asBoolean(var51), dev.prestige.recovery.SourceSupport.asBoolean(var52), var31, var43, var45, var53
                        );
                        ArrayList var138 = var26;
                        var138.add(var139);
                     }

                     var34++;
                     var31++;
                     var275 = var25;
                  } while (var275 != 0);

                  var33++;
                  int var276 = var25;
                  if (var276 == 0) {
                     break label228;
                  }
                  break;
               }
            }

            var32++;
            int var277 = var25;
            if (var277 == 0) {
               return var26;
            }
            break;
         }
      }
   }

   private AnchorPlacementPoint aReturninggd_C0332(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 2444992509633L ^ var3;
      BlockPos var7 = null;
      Vec3d var8 = null;
      int var64 = Event.cReturningInt();
      double var9 = Double.MAX_VALUE;
      Direction[] var11 = z;
      int var12 = var11.length;
      int var6 = var64;
      while (true) {
         int var50 = var12;
         int var49 = var13;
         if (var49 < var50) {
            Direction var14 = var11[var13];
            Direction var21 = var14;
            BlockPos var20 = var2;
            BlockPos var15 = var20.offset(var21);
            int var51 = var6;
            if (var51 == 0) {
               break;
            }

            label41: {
               MinecraftClient var22 = b;
               BlockPos var24 = var15;
               ClientWorld var23 = var22.world;
               BlockState var25 = var23.getBlockState(var24);
               boolean var52 = var25.isReplaceable();
               if (!var52) {
                  Direction var28 = var14;
                  Direction var16 = var28.getOpposite();
                  BlockPos var29 = var15;
                  Vec3d var65 = var29.toCenterPos();
                  Direction var30 = var16;
                  double var10001 = var30.getOffsetX() * 0.5;
                  Direction var31 = var16;
                  double var10002 = var31.getOffsetY() * 0.5;
                  Direction var32 = var16;
                  double var38 = var32.getOffsetZ() * 0.5;
                  double var36 = var10002;
                  double var34 = var10001;
                  Vec3d var33 = var65;
                  Vec3d var17 = var33.add(var34, var36, var38);
                  Vec3d var41 = var17;
                  Vec3d var40 = var5;
                  double var18 = var40.squaredDistanceTo(var41);
                  int var53 = var6;
                  if (var53 == 0) {
                     break label41;
                  }

                  double var66;
                  int var54 = (var66 = var18 - 18.0625) == 0.0 ? 0 : (var66 < 0.0 ? -1 : 1);
                  label38:
                  if (var54 <= 0) {
                     int var57 = var6;
                     double var55 = var18;
                     double var46 = var55;
                     double var42 = var55;
                     if (var57 != 0) {
                        double var58 = var42;
                        double var44 = var58;
                        double var67;
                        int var60 = (var67 = var44 - var9) == 0.0 ? 0 : (var67 < 0.0 ? -1 : 1);
                        if (var60 >= 0) {
                           break label38;
                        }

                        var46 = var18;
                     }

                     var9 = var46;
                     var7 = var15;
                     var8 = var17;
                  }
               }

               var13++;
            }

            int var61 = var6;
            if (var61 != 0) {
               continue;
            }
         }

         BlockPos var62 = var7;
         if (var62 == null) {
            return null;
         }
         break;
      }

      return new AnchorPlacementPoint(var7, var8);
   }

   private static double aReturningDouble(Object[] var0) {
      Vec3d var3 = (Vec3d)var0[0];
      Vec3d var4 = (Vec3d)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 2444992509633L ^ var1;
      int var31 = Event.cReturningInt();
      Vec3d var13 = var4;
      Vec3d var12 = var3;
      double var6 = var12.distanceTo(var13);
      int var5 = var31;
      int var29 = var5;
      double var27 = 10.0;
      double var25 = var6;
      double var21 = var25;
      double var23 = var27;
      double var17 = var25;
      double var19 = var27;
      if (var29 != 0) {
         double var32;
         int var30 = (var32 = var17 - var19) == 0.0 ? 0 : (var32 < 0.0 ? -1 : 1);
         if (var30 > 0) {
            return 0.0;
         }

         var23 = var6 / 10.0;
         var21 = 1.0;
      }

      double var8 = var21 - var23;
      double var10 = ((var8 * var8 + var8) * 0.5 * 7.0 * 10.0 + 1.0) * 1.5;
      float var16 = (float)var10;
      return Math.nextUp(var16);
   }

   private double bReturningDouble(Object[] var1) {
      Vec3d var2;
      Vec3d var5;
      AnchorPlacementEvaluation var6;
      long var7;
      int var9;
      double var54;
      label43: {
         var6 = (AnchorPlacementEvaluation)var1[0];
         var5 = (Vec3d)var1[1];
         var2 = (Vec3d)var1[2];
         long var3 = (Long)var1[3];
         var3 = 2444992509633L ^ var3;
         var7 = var3 ^ 10386529228158L;
         var9 = Event.bReturningInt();
         Vec3d var12 = var2;
         double var90;
         int var10000 = (var90 = var12.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var90 < 0.0 ? -1 : 1);
         int var65 = var9;
         int var64 = var10000;
         int var45 = var64;
         int var42 = var64;
         if (var65 == 0) {
            int var66 = var42;
            if (var66 < 0) {
               ExplosionDamageUtil var88 = Prestige.f;
               Object[] var15 = new Object[]{this.Y, var5, var7};
               ExplosionDamageUtil var14 = var88;
               return var14.kReturningVoid(var15);
            }

            int var69 = var9;
            double var67 = var6.recoveryAccess_read_r();
            var54 = var67;
            double var43 = var67;
            if (var69 != 0) {
               break label43;
            }

            double var91;
            int var70 = (var91 = var43 - var6.recoveryAccess_read_q()) == 0.0 ? 0 : (var91 < 0.0 ? -1 : 1);
            var45 = var70;
         }

         int var71 = var45;
         if (var71 > 0) {
            ExplosionDamageUtil var87 = Prestige.f;
            Vec3d var19 = var2;
            Vec3d var18 = var5;
            Object[] var21 = new Object[]{this.Y, var18.subtract(var19), var7};
            ExplosionDamageUtil var20 = var87;
            double var10 = var20.kReturningVoid(var21);
            int var76 = var9;
            double var74 = var10;
            double var72 = var6.recoveryAccess_read_q();
            double var50 = var72;
            double var52 = var74;
            double var46 = var72;
            double var48 = var74;
            if (var76 == 0) {
               double var92;
               int var77 = (var92 = var46 - var48) == 0.0 ? 0 : (var92 < 0.0 ? -1 : 1);
               if (var77 <= 0) {
                  return var10;
               }

               ExplosionDamageUtil var10001 = Prestige.f;
               Object[] var25 = new Object[]{this.Y, var5, var7};
               ExplosionDamageUtil var24 = var10001;
               var52 = var24.kReturningVoid(var25);
               var50 = var10;
            }

            double var28 = var52;
            double var26 = var50;
            return Math.max(var26, var28);
         }

         ExplosionDamageUtil var86 = Prestige.f;
         Object[] var31 = new Object[]{this.Y, var5, var7};
         ExplosionDamageUtil var30 = var86;
         var54 = var30.kReturningVoid(var31);
      }

      double var85 = var54;
      int var82 = var9;
      double var80 = var85;
      double var78 = var6.recoveryAccess_read_r();
      double var60 = var78;
      double var62 = var80;
      double var56 = var78;
      double var58 = var80;
      if (var82 == 0) {
         double var93;
         int var83 = (var93 = var56 - var58) == 0.0 ? 0 : (var93 < 0.0 ? -1 : 1);
         if (var83 <= 0) {
            return var85;
         }

         ExplosionDamageUtil var89 = Prestige.f;
         Vec3d var35 = var2;
         Vec3d var34 = var5;
         Object[] var37 = new Object[]{this.Y, var34.subtract(var35), var7};
         ExplosionDamageUtil var36 = var89;
         var62 = var36.kReturningVoid(var37);
         var60 = var85;
      }

      double var40 = var62;
      double var38 = var60;
      return Math.max(var38, var40);
   }

   private static double cReturningDouble(Object[] var0) {
      AnchorPlacementEvaluation var1 = (AnchorPlacementEvaluation)var0[0];
      double var2 = (Double)var0[1];
      double var4 = (Double)var0[2];
      long var6 = (Long)var0[3];
      var6 = 2444992509633L ^ var6;
      long var8 = var6 ^ 131528120040051L;
      double var10002 = var1.recoveryAccess_read_m();
      boolean var10003 = var1.recoveryAccess_read_n();
      boolean var10004 = var1.recoveryAccess_read_o();
      boolean var10005 = var1.recoveryAccess_read_k();
      int var10006 = var1.recoveryAccess_read_l();
      Object[] var10009 = new Object[]{null, null, null, null, null, null, null, var8};
      var10009[6] = var10006;
      var10009[5] = var10005;
      var10009[4] = var10004;
      var10009[3] = var10003;
      var10009[2] = var10002;
      var10009[1] = var4;
      var10009[0] = var2;
      Object[] var10 = var10009;
      return dReturningDouble(var10);
   }

   private static double dReturningDouble(Object[] var0) {
      double var3 = (Double)var0[0];
      double var5 = (Double)var0[1];
      double var7 = (Double)var0[2];
      boolean var12 = (Boolean)var0[3];
      boolean var2 = (Boolean)var0[4];
      boolean var1 = (Boolean)var0[5];
      int var11 = (Integer)var0[6];
      long var9 = (Long)var0[7];
      long var10000 = 2444992509633L ^ var9;
      int var43 = Event.cReturningInt();
      double var14 = var3 - 0.6 * var5 - 0.15 * var7 - 0.15 * var7 * var7;
      int var13 = var43;
      int var33 = var13;
      boolean var32 = var12;
      boolean var25 = var32;
      boolean var24 = var32;
      if (var33 != 0) {
         boolean var34 = var24;
         if (var34) {
            var14 += 4.0;
         }

         var25 = var2;
      }

      int var36 = var13;
      boolean var35 = var25;
      boolean var27 = var35;
      boolean var26 = var35;
      if (var36 != 0) {
         boolean var37 = var26;
         if (var37) {
            var14 += 3.5;
         }

         var27 = var1;
      }

      boolean var38 = var27;
      if (var38) {
         double var22 = 1.0 - var7 / 4.4;
         double var16 = Math.max(var20, var22);
         double var44 = var14 + 5.0 * var16;
         int var41 = var13;
         double var39 = var44;
         double var30 = var39;
         double var28 = var39;
         if (var41 == 0) {
            return var30;
         }

         var14 = var28;
         int var42 = var11;
         if (var42 > 0) {
            var14 += 6.0 * var16;
         }
      }

      return var14;
   }

   private static boolean fReturningBoolean(Object[] var0) {
      double var6 = (Double)var0[0];
      int var5 = (Integer)var0[1];
      double var3 = (Double)var0[2];
      int var8 = (Integer)var0[3];
      long var1 = (Long)var0[4];
      long var10000 = 2444992509633L ^ var1;
      int var9 = Event.cReturningInt();
      double var32;
      int var30 = (var32 = var6 - var3) == 0.0 ? 0 : (var32 < 0.0 ? -1 : 1);
      int var18 = var9;
      int var17 = var30;
      int var15 = var17;
      int var10 = var17;
      if (var18 != 0) {
         int var19 = var10;
         if (var19 > 0) {
            return true;
         }

         double var33;
         int var31 = (var33 = var6 - var3) == 0.0 ? 0 : (var33 < 0.0 ? -1 : 1);
         int var21 = var9;
         int var20 = var31;
         int var13 = var20;
         int var11 = var20;
         if (var21 != 0) {
            int var22 = var11;
            int var12 = var22;
            int var23 = var12;
            if (var23 != 0) {
               return false;
            }

            var13 = var5;
         }

         int var25 = var9;
         int var24 = var13;
         var15 = var24;
         int var14 = var24;
         if (var25 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var15);
         }

         int var27 = var8;
         int var26 = var14;
         return var26 < var27;
      } else {
         return dev.prestige.recovery.SourceSupport.asBoolean(var15);
      }
   }

   private static boolean gReturningBoolean(Object[] var0) {
      double var4 = (Double)var0[0];
      int var1 = (Integer)var0[1];
      double var2 = (Double)var0[2];
      int var6 = (Integer)var0[3];
      long var7 = (Long)var0[4];
      long var10000 = 2444992509633L ^ var7;
      int var9 = Event.cReturningInt();
      double var32;
      int var30 = (var32 = var4 - var2) == 0.0 ? 0 : (var32 < 0.0 ? -1 : 1);
      int var18 = var9;
      int var17 = var30;
      int var15 = var17;
      int var10 = var17;
      if (var18 != 0) {
         int var19 = var10;
         if (var19 > 0) {
            return true;
         }

         double var33;
         int var31 = (var33 = var4 - var2) == 0.0 ? 0 : (var33 < 0.0 ? -1 : 1);
         int var21 = var9;
         int var20 = var31;
         int var13 = var20;
         int var11 = var20;
         if (var21 != 0) {
            int var22 = var11;
            int var12 = var22;
            int var23 = var12;
            if (var23 != 0) {
               return false;
            }

            var13 = var1;
         }

         int var25 = var9;
         int var24 = var13;
         var15 = var24;
         int var14 = var24;
         if (var25 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var15);
         }

         int var27 = var6;
         int var26 = var14;
         return var26 < var27;
      } else {
         return dev.prestige.recovery.SourceSupport.asBoolean(var15);
      }
   }

   private int cReturningInt(Object[] var1) {
      BlockPos var4 = (BlockPos)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 2444992509633L ^ var2;
      int var22 = Event.bReturningInt();
      MinecraftClient var7 = b;
      BlockPos var9 = var4;
      ClientWorld var8 = var7.world;
      BlockState var6 = var8.getBlockState(var9);
      int var5 = var22;
      Block var11 = Blocks.RESPAWN_ANCHOR;
      BlockState var10 = var6;
      byte var23 = ((byte)((var10.isOf(var11)) ? 1 : 0));
      int var20 = var5;
      byte var19 = var23;
      int var18 = var19;
      byte var17 = var19;
      if (var20 == 0) {
         byte var21 = var17;
         if (var21 == 0) {
            return 0;
         }

         IntProperty var15 = Properties.CHARGES;
         BlockState var14 = var6;
         Integer var16 = (Integer)var14.get((Property)var15);
         var18 = var16;
      }

      return var18;
   }

   private boolean h(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 85458463466215L;
      int var6 = Event.cReturningInt();
      int var28 = var6;
      PlayerEntity var27 = this.Y;
      PlayerEntity var19 = var27;
      PlayerEntity var18 = var27;
      if (var28 != 0) {
         PlayerEntity var29 = var18;
         if (var29 == null) {
            return false;
         }

         PlayerEntity var30 = this.Y;
         var19 = var30;
      }

      PlayerEntity var9 = var19;
      byte var10000 = ((byte)((var9.isAlive()) ? 1 : 0));
      int var32 = var6;
      byte var31 = var10000;
      int var21 = var31;
      byte var20 = var31;
      if (var32 != 0) {
         byte var33 = var20;
         if (var33 == 0) {
            return false;
         }

         MinecraftClient var11 = b;
         PlayerEntity var13 = this.Y;
         ClientPlayerEntity var12 = var11.player;
         float var45;
         int var34 = (var45 = var12.distanceTo((Entity)var13) - 12.0F) == 0.0F ? 0 : (var45 < 0.0F ? -1 : 1);
         var21 = var34;
      }

      int var36 = var6;
      int var35 = var21;
      int var23 = var35;
      int var22 = var35;
      if (var36 != 0) {
         int var37 = var22;
         if (var37 > 0) {
            return false;
         }

         PlayerValidationTracker var44 = Prestige.i;
         Object[] var17 = new Object[]{this.Y, var4};
         PlayerValidationTracker var16 = var44;
         byte var38 = ((byte)((var16.aReturningBoolean(var17)) ? 1 : 0));
         var23 = var38;
      }

      int var40 = var6;
      int var39 = var23;
      int var25 = var39;
      int var24 = var39;
      if (var40 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var25);
      } else {
         int var41 = var24;
         if (var41 != 0) {
            byte var46 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var46);
         } else {
            return false;
         }
      }
   }

   private boolean i(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 2444992509633L ^ var2;
      int var4 = Event.bReturningInt();
      int var35 = var4;
      AutoAnchor var34 = this;
      AutoAnchor var28 = var34;
      AutoAnchor var27 = var34;
      if (var35 == 0) {
         BlockPos var36 = var27.af;
         if (var36 == null) {
            return false;
         }

         AutoAnchor var37 = this;
         var28 = var37;
      }

      int var39 = var4;
      PlayerEntity var38 = var28.Y;
      PlayerEntity var30 = var38;
      PlayerEntity var29 = var38;
      if (var39 == 0) {
         PlayerEntity var40 = var29;
         if (var40 == null) {
            return false;
         }

         var30 = this.Y;
      }

      PlayerEntity var13 = var30;
      BlockPos var5 = var13.getBlockPos();
      BlockPos var14 = var5;
      int var47 = var14.getX();
      BlockPos var15 = this.af;
      int var16 = var47 - var15.getX();
      int var6 = Math.abs(var16);
      BlockPos var17 = var5;
      int var48 = var17.getY();
      BlockPos var18 = this.af;
      int var19 = var48 - var18.getY();
      int var7 = Math.abs(var19);
      BlockPos var20 = var5;
      int var49 = var20.getZ();
      BlockPos var21 = this.af;
      int var22 = var49 - var21.getZ();
      int var8 = Math.abs(var22);
      int var24 = var8;
      int var23 = var7;
      int var26 = Math.max(var23, var24);
      int var25 = var6;
      int var50 = Math.max(var25, var26);
      int var42 = var4;
      int var41 = var50;
      int var32 = var41;
      int var31 = var41;
      int var33;
      if (var42 == 0) {
         byte var44 = 1;
         int var43 = var31;
         if (var43 > var44) {
            byte var45 = 1;
            var33 = var45;
         } else {
            var33 = 0;
         }
      } else {
         int var46 = var32;
         var33 = var46;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var33);
   }

   private boolean jReturningBoolean(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 2444992509633L ^ var3;
      long var5 = var3 ^ 95816947550167L;
      long var7 = var3 ^ 77147811523714L;
      int var9 = Event.bReturningInt();
      long var133;
      int var10000 = (var133 = this.V - this.W) == 0L ? 0 : (var133 < 0L ? -1 : 1);
      int var81 = var9;
      int var80 = var10000;
      int var56 = var80;
      int var55 = var80;
      if (var81 == 0) {
         int var82 = var55;
         if (var82 != 0) {
            return false;
         }

         long var134;
         var56 = (var134 = this.K - this.M) == 0L ? 0 : (var134 < 0L ? -1 : 1);
      }

      int var84 = var9;
      int var83 = var56;
      int var58 = var83;
      int var57 = var83;
      if (var84 == 0) {
         int var85 = var57;
         if (var85 < 0) {
            PlayerEntity var87 = var2;
            PlayerEntity var86 = this.N;
            if (var86 == var87) {
               MinecraftClient var15 = b;
               ClientPlayerEntity var16 = var15.player;
               BlockPos var127 = var16.getBlockPos();
               BlockPos var18 = this.O;
               BlockPos var17 = var127;
               byte var128 = ((byte)((var17.equals(var18)) ? 1 : 0));
               int var90 = var9;
               byte var89 = var128;
               byte var62 = var89;
               byte var59 = var89;
               if (var90 == 0) {
                  byte var91 = var59;
                  if (var91 != 0) {
                     PlayerEntity var20 = var2;
                     BlockPos var129 = var20.getBlockPos();
                     BlockPos var22 = this.P;
                     BlockPos var21 = var129;
                     var128 = ((byte)((var21.equals(var22)) ? 1 : 0));
                     int var93 = var9;
                     byte var92 = var128;
                     var62 = var92;
                     byte var60 = var92;
                     if (var93 != 0) {
                        return dev.prestige.recovery.SourceSupport.asBoolean(var62);
                     }

                     byte var94 = var60;
                     byte var61 = var94;
                     byte var95 = var61;
                     if (var95 != 0) {
                        int var97 = var9;
                        Vec3d var96 = this.Q;
                        Vec3d var64 = var96;
                        Vec3d var63 = var96;
                        if (var97 == 0) {
                           Vec3d var98 = var63;
                           if (var98 == null) {
                              return false;
                           }

                           MinecraftClient var26 = b;
                           ClientPlayerEntity var27 = var26.player;
                           Vec3d var99 = var27.getEyePos();
                           var64 = var99;
                        }

                        int var101 = var9;
                        Vec3d var100 = var64;
                        Vec3d var66 = var100;
                        Vec3d var65 = var100;
                        if (var101 == 0) {
                           Vec3d var30 = this.Q;
                           Vec3d var29 = var65;
                           boolean var102 = var29.equals(var30);
                           if (!var102) {
                              return false;
                           }

                           var66 = this.R;
                        }

                        int var104 = var9;
                        Vec3d var103 = var66;
                        Vec3d var68 = var103;
                        Vec3d var67 = var103;
                        if (var104 == 0) {
                           Vec3d var105 = var67;
                           if (var105 == null) {
                              return false;
                           }

                           Object[] var34 = new Object[]{var2, var5};
                           Vec3d var106 = RaycastUtil.aReturningVec3d(var34);
                           var68 = var106;
                        }

                        int var108 = var9;
                        Vec3d var107 = var68;
                        Vec3d var70 = var107;
                        Vec3d var69 = var107;
                        if (var108 == 0) {
                           Vec3d var37 = this.R;
                           Vec3d var36 = var69;
                           boolean var109 = var36.equals(var37);
                           if (!var109) {
                              return false;
                           }

                           var70 = this.S;
                        }

                        int var111 = var9;
                        Vec3d var110 = var70;
                        Vec3d var72 = var110;
                        Vec3d var71 = var110;
                        if (var111 == 0) {
                           Vec3d var112 = var71;
                           if (var112 == null) {
                              return false;
                           }

                           PlayerEntity var41 = var2;
                           Vec3d var113 = var41.getVelocity();
                           var72 = var113;
                        }

                        Vec3d var44 = this.S;
                        Vec3d var43 = var72;
                        var128 = ((byte)((var43.equals(var44)) ? 1 : 0));
                        int var115 = var9;
                        byte var114 = var128;
                        int var74 = var114;
                        byte var73 = var114;
                        if (var115 == 0) {
                           byte var116 = var73;
                           if (var116 == 0) {
                              return false;
                           }

                           MinecraftClient var47 = b;
                           ClientPlayerEntity var48 = var47.player;
                           float var132 = var48.getYaw();
                           float var50 = this.T;
                           float var49 = var132;
                           var74 = Float.compare(var49, var50);
                        }

                        int var118 = var9;
                        int var117 = var74;
                        int var76 = var117;
                        int var75 = var117;
                        if (var118 == 0) {
                           int var119 = var75;
                           if (var119 != 0) {
                              return false;
                           }

                           var76 = this.U;
                        }

                        int var121 = var9;
                        int var120 = var76;
                        int var78 = var120;
                        int var77 = var120;
                        int var79;
                        if (var121 == 0) {
                           Object[] var54 = new Object[]{var7};
                           AutoAnchor var53 = this;
                           int var123 = var53.eReturningInt(var54);
                           int var122 = var77;
                           if (var122 == var123) {
                              byte var124 = 1;
                              var79 = var124;
                           } else {
                              var79 = 0;
                           }
                        } else {
                           int var125 = var78;
                           var79 = var125;
                        }

                        return dev.prestige.recovery.SourceSupport.asBoolean(var79);
                     }
                  }

                  var62 = 0;
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var62);
            }
         }

         byte var88 = 0;
         var58 = var88;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var58);
   }

   private void v(Object[] var1) {
      PlayerEntity var6 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      long var4 = (Long)var1[2];
      var4 = 2444992509633L ^ var4;
      long var7 = var4 ^ 8771760236670L;
      long var9 = var4 ^ 25241881330475L;
      this.N = var6;
      MinecraftClient var11 = b;
      ClientPlayerEntity var12 = var11.player;
      BlockPos var13 = var12.getBlockPos();
      this.O = var13.toImmutable();
      PlayerEntity var14 = var6;
      BlockPos var15 = var14.getBlockPos();
      this.P = var15.toImmutable();
      MinecraftClient var16 = b;
      ClientPlayerEntity var17 = var16.player;
      this.Q = var17.getEyePos();
      Object[] var18 = new Object[]{var6, var7};
      this.R = RaycastUtil.aReturningVec3d(var18);
      PlayerEntity var19 = var6;
      this.S = var19.getVelocity();
      MinecraftClient var20 = b;
      ClientPlayerEntity var21 = var20.player;
      this.T = var21.getYaw();
      Object[] var23 = new Object[]{var9};
      AutoAnchor var22 = this;
      this.U = var22.eReturningInt(var23);
      this.W = var2;
      this.M = this.K + invokeBinding9(27858, 3538599351382822208L ^ var4);
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      FloatSetting var8 = this.a;
      Float var9 = (Float)var8.aReturningObject();
      float var10 = var9;
      int var5 = Float.floatToIntBits(var10);
      int var10000 = 28168;
      long var10001 = 5589077793832863510L ^ var2;
      var10000 = 31 * var5;
      FloatSetting var11 = this.c;
      Float var12 = (Float)var11.aReturningObject();
      float var13 = var12;
      var5 = var10000 + Float.floatToIntBits(var13);
      int var60 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var60 = 31 * var5;
      FloatSetting var14 = this.d;
      Float var15 = (Float)var14.aReturningObject();
      float var16 = var15;
      var5 = var60 + Float.floatToIntBits(var16);
      int var62 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var62 = 31 * var5;
      BooleanSetting var17 = this.e;
      Boolean var18 = (Boolean)var17.aReturningObject();
      boolean var19 = var18;
      var5 = var62 + Boolean.hashCode(var19);
      int var64 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var64 = 31 * var5;
      BooleanSetting var20 = this.f;
      Boolean var21 = (Boolean)var20.aReturningObject();
      boolean var22 = var21;
      var5 = var64 + Boolean.hashCode(var22);
      int var66 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var66 = 31 * var5;
      ModeSetting var23 = this.g;
      String var24 = (String)var23.aReturningObject();
      var5 = var66 + var24.hashCode();
      int var68 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var68 = 31 * var5;
      BooleanSetting var25 = this.h;
      Boolean var26 = (Boolean)var25.aReturningObject();
      boolean var27 = var26;
      var5 = var68 + Boolean.hashCode(var27);
      int var70 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var70 = 31 * var5;
      BooleanSetting var28 = this.m;
      Boolean var29 = (Boolean)var28.aReturningObject();
      boolean var30 = var29;
      var5 = var70 + Boolean.hashCode(var30);
      int var72 = 27468;
      var10001 = 8077346824752661084L ^ var2;
      var72 = 31 * var5;
      MinecraftClient var31 = b;
      ClientPlayerEntity var32 = var31.player;
      float var88 = var32.getHealth();
      MinecraftClient var33 = b;
      ClientPlayerEntity var34 = var33.player;
      float var35 = var88 + var34.getAbsorptionAmount();
      var5 = var72 + Float.floatToIntBits(var35);
      var72 = Event.bReturningInt();
      int var4 = var72;

      int var43;
      while (true) {
         byte var89 = 50;
         long var10002 = 7343539711969159463L ^ var2;
         byte var45 = 9;
         int var44 = var6;
         if (var44 < var45) {
            MinecraftClient var36 = b;
            ClientPlayerEntity var37 = var36.player;
            PlayerInventory var75 = var37.getInventory();
            int var39 = var6;
            PlayerInventory var38 = var75;
            ItemStack var7 = var38.getStack(var39);
            int var76 = 27468;
            var10001 = 8077346824752661084L ^ var2;
            var76 = 31 * var5;
            ItemStack var40 = var7;
            var5 = var76 + var40.getItem().hashCode();
            int var78 = 27468;
            var10001 = 8077346824752661084L ^ var2;
            var78 = 31 * var5;
            ItemStack var41 = var7;
            var78 += var41.getCount();
            int var47 = var4;
            int var46 = var78;
            var43 = var46;
            int var42 = var46;
            if (var47 != 0) {
               break;
            }

            var5 = var42;
            var6++;
            int var48 = var4;
            if (var48 == 0) {
               continue;
            }
         }

         var43 = var5;
         break;
      }

      return var43;
   }

   private void w(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      this.M = invokeBinding10(22196, 3368251909018413185L ^ var2);
      this.N = null;
      this.O = null;
      this.P = null;
      this.Q = null;
      this.R = null;
      this.S = null;
      this.T = 0.0F;
      this.U = 0;
      this.W = this.V;
   }

   private void x(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 2444992509633L ^ var2;
      long var5 = var2 ^ 78314081469174L;
      long var7 = var2 ^ 34423905090786L;
      long var9 = var2 ^ 49824646407493L;
      long var11 = var2 ^ 94729014241857L;
      int var13 = Event.bReturningInt();
      int var26 = var13;
      AutoAnchor var25 = this;
      AutoAnchor var24 = var25;
      AutoAnchor var23 = var25;
      if (var26 == 0) {
         ElapsedTimer var10000 = var23.at;
         Object[] var10004 = new Object[]{null, var5};
         var10004[0] = 3000.0F;
         Object[] var15 = var10004;
         ElapsedTimer var14 = var10000;
         boolean var27 = var14.aReturningBoolean(var15);
         if (var27) {
            Object[] var17 = new Object[]{this, var4, NotificationType.ERROR, var11};
            ModuleNotificationsWidget.s(var17);
            var10000 = this.at;
            Object[] var19 = new Object[]{var7};
            ElapsedTimer var18 = var10000;
            var18.aReturningVoid(var19);
         }

         var24 = this;
      }

      Object[] var22 = new Object[]{var9};
      AutoAnchor var21 = var24;
      var21.z(var22);
   }

   private void y(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 38859630907441L;
      long var6 = var2 ^ 115247817365225L;
      int var8 = Event.cReturningInt();
      // int var33 = this.ag;
      if (var33 != var34) {
         MinecraftClient var10 = b;
         ClientPlayerEntity var35 = var10.player;
         if (var35 == null) {
            Object[] var11 = new Object[]{this, var4};
            SlotReservation.aReturningVoid(var11);
            this.ag = -1;
         } else {
            Object[] var13 = new Object[]{this};
            int var10000 = (((SlotReservation.aReturningBoolean(var13)) ? 1 : 0));
            int var37 = var8;
            boolean var36 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
            boolean var28 = var36;
            boolean var27 = var36;
            if (var37 != 0) {
               boolean var38 = var27;
               if (!var38) {
                  this.ag = -1;
                  return;
               }

               RotationManager var47 = Prestige.o;
               Object[] var17 = new Object[0];
               RotationManager var16 = var47;
               var28 = var16.fReturningBoolean(var17);
            }

            AutoAnchor var32;
            label42: {
               int var40 = var8;
               boolean var39 = var28;
               boolean var31 = var39;
               boolean var29 = var39;
               if (var40 != 0) {
                  boolean var41 = var29;
                  if (var41) {
                     return;
                  }

                  int var43 = var8;
                  AutoAnchor var42 = this;
                  var32 = var42;
                  AutoAnchor var30 = var42;
                  if (var43 == 0) {
                     break label42;
                  }

                  BooleanSetting var19 = var30.i;
                  Boolean var20 = (Boolean)var19.aReturningObject();
                  boolean var44 = var20;
                  var31 = var44;
               }

               boolean var45 = var31;
               if (var45) {
                  var10000 = this.ag;
                  Object[] var10003 = new Object[]{null, var6};
                  var10003[0] = var10000;
                  Object[] var22 = var10003;
                  InventoryUtil.aReturningVoid(var22);
                  RotationManager var49 = Prestige.o;
                  Object[] var24 = new Object[]{true};
                  RotationManager var23 = var49;
                  var23.fReturningVoid(var24);
               }

               Object[] var26 = new Object[]{this, var4};
               SlotReservation.aReturningVoid(var26);
               var32 = this;
            }

            var32.ag = -1;
         }
      }
   }

   private void z(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 8063307027478L;
      long var6 = var2 ^ 67956178707000L;
      Object[] var9 = new Object[]{var6};
      AutoAnchor var8 = this;
      var8.y(var9);
      Object[] var11 = new Object[]{var4};
      AutoAnchor var10 = this;
      var10.w(var11);
      this.C = AutoAnchorState.IDLE;
      this.Y = null;
      this.Z = null;
      this.aa = null;
      this.ab = null;
      this.ac = null;
      this.ad = null;
      this.ae = null;
      this.af = null;
      this.H = 0;
      this.X = 0;
      B = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void A(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2444992509633L ^ var2;
      long var4 = var2 ^ 62001797235421L;
      long var6 = var2 ^ 36380183277492L;
      long var8 = var2 ^ 16567996234157L;
      Object[] var11 = new Object[]{var4};
      AutoAnchor var10 = this;
      var10.w(var11);
      this.C = AutoAnchorState.IDLE;
      this.Y = null;
      this.Z = null;
      this.aa = null;
      this.ab = null;
      this.ac = null;
      this.ad = null;
      this.ae = null;
      this.af = null;
      this.ag = -1;
      this.H = 0;
      ElapsedTimer var10000 = this.D;
      Object[] var13 = new Object[]{var8};
      ElapsedTimer var12 = var10000;
      var12.aReturningVoid(var13);
      var10000 = this.E;
      Object[] var15 = new Object[]{var8};
      ElapsedTimer var14 = var10000;
      var14.aReturningVoid(var15);
      var10000 = this.F;
      Object[] var17 = new Object[]{var8};
      ElapsedTimer var16 = var10000;
      var16.aReturningVoid(var17);
      var10000 = this.G;
      Object[] var19 = new Object[]{var8};
      ElapsedTimer var18 = var10000;
      var18.aReturningVoid(var19);
      B = dev.prestige.recovery.SourceSupport.asBoolean(0);
      ExpiringValue var30 = this.an;
      Object[] var21 = new Object[]{var6};
      ExpiringValue var20 = var30;
      var20.bReturningVoid(var21);
      ExpiringValue var31 = this.ao;
      Object[] var23 = new Object[]{var6};
      ExpiringValue var22 = var31;
      var22.bReturningVoid(var23);
      ExpiringValue var32 = this.ap;
      Object[] var25 = new Object[]{var6};
      ExpiringValue var24 = var32;
      var24.bReturningVoid(var25);
      this.aq = null;
      this.ar = null;
      this.as = null;
   }

   private static int lambda$search$5(AnchorPlacementEvaluation var0, AnchorPlacementEvaluation var1) {
      int var10000 = Event.bReturningInt();
      double var8 = var0.recoveryAccess_read_s();
      double var6 = var1.recoveryAccess_read_s();
      int var5 = Double.compare(var6, var8);
      int var4 = var10000;
      int var18 = var4;
      int var17 = var5;
      int var15 = var17;
      int var14 = var17;
      if (var18 == 0) {
         int var19 = var14;
         if (var19 != 0) {
            return var5;
         }

         var15 = var0.recoveryAccess_read_p();
      }

      int var13 = var1.recoveryAccess_read_p();
      int var12 = var15;
      return Integer.compare(var12, var13);
   }

   private boolean lambda$onTick$4(Entry var1) {
      int var4 = Event.cReturningInt();
      long var10000 = this.K;
      Entry var5 = var1;
      Long var6 = (Long)var5.getValue();
      long var15;
      int var14 = (var15 = var10000 - var6 - /* /*DECRYPT:dev.zprestige.prestige.d1:11:6179:7088165578794042272*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.modules.AutoAnchor_6179") == 0L ? 0 : (var15 < 0L ? -1 : 1);
      int var11 = var4;
      int var10 = var14;
      int var8 = var10;
      int var7 = var10;
      if (var11 != 0) {
         int var12 = var7;
         if (var12 <= 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private boolean lambda$new$3(Color var1) {
      BooleanSetting var4 = this.n;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.n;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.f;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$1(Color var1) {
      BooleanSetting var4 = this.n;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(String var1) {
      BooleanSetting var4 = this.f;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(130371169586997L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[5];
      String var26 = "\u008c¦\u0082mû\u0019\u008f²£\u001fËlì}FÜ3âÌP\u0094\u0017¼1úÜ\u0093=îI\u0003»(üº,ý|B\u0014~µ´¿`U\u0086f)F\u0085H_~\u001c\u000bÔJ\u0004£c,Z\r\u0017fuÓÈùÎ«Ñ@\u009dUõê©\u008e®\u008dIY»Ó\u001d;\u0003 X\u0000|\u0002]\u000bX\u001dôZ·[\u001cûÝÙ@\u008d5]\u008c,\u0096&¯2\bR¹ûòÆèë\u009f\u001eùôè\u0088f\u0000Ì\u008c\u0001\u0085üÂ";
      int var28 = "\u008c¦\u0082mû\u0019\u008f²£\u001fËlì}FÜ3âÌP\u0094\u0017¼1úÜ\u0093=îI\u0003»(üº,ý|B\u0014~µ´¿`U\u0086f)F\u0085H_~\u001c\u000bÔJ\u0004£c,Z\r\u0017fuÓÈùÎ«Ñ@\u009dUõê©\u008e®\u008dIY»Ó\u001d;\u0003 X\u0000|\u0002]\u000bX\u001dôZ·[\u001cûÝÙ@\u008d5]\u008c,\u0096&¯2\bR¹ûòÆèë\u009f\u001eùôè\u0088f\u0000Ì\u008c\u0001\u0085üÂ"
         .length();
      char var25 = ' ';
      int var34 = -1;

      label81:
      while (true) {
         String var35 = var26.substring(++var34, var34 + var25);
         int var10001 = -1;

         while (true) {
            byte[] var30 = var22.doFinal(var35.getBytes("ISO-8859-1"));
            String var53 = b(var30).intern();
            switch (var10001) {
               case 0:
                  var29[var27++] = var53;
                  if ((var34 += var25) >= var28) {
                     hb = var29;
                     ib = new String[5];
                     mb = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(130371169586997L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[14];
                     String var15 = "jR^ÙY\u000bh\u0016\u008d¾\u0080#ôW\u00140\u00999B4'k\u0011vÐ\u009a«J(\u0004ý=~\u0018\u0014\u0095\u001d6\u0016'\u0006~ÿÆ¤\u0098ýxO0¤eÈïÏñXB /5U\u0016?`F\u0000zJ\u0012\u000e!ïÓ°\\0\u0005%ý6ø\u0013=»\u0004ÜÃg%ë\u0099\u009e§\u00125";
                     int var16 = "jR^ÙY\u000bh\u0016\u008d¾\u0080#ôW\u00140\u00999B4'k\u0011vÐ\u009a«J(\u0004ý=~\u0018\u0014\u0095\u001d6\u0016'\u0006~ÿÆ¤\u0098ýxO0¤eÈïÏñXB /5U\u0016?`F\u0000zJ\u0012\u000e!ïÓ°\\0\u0005%ý6ø\u0013=»\u0004ÜÃg%ë\u0099\u009e§\u00125"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var38 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var38[var10001] = var68;
                                 if (var13 >= var16) {
                                    kb = var17;
                                    lb = new Integer[14];
                                    I = 3;
                                    pb = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(130371169586997L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[7];
                                    String var4 = " *Ë\u000bT\u0096*)° \"ño¬«oº\u001a2¥Qî\u0099-C\u0095\u0082Åð1OÒ\u008c¢&n\u0098Ê%L";
                                    int var5 = " *Ë\u000bT\u0096*)° \"ño¬«oº\u001a2¥Qî\u0099-C\u0095\u0082Åð1OÒ\u008c¢&n\u0098Ê%L".length();
                                    label47:
                                    while (true) {
                                       int var48 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var48, var2).getBytes("ISO-8859-1");
                                       long[] var40 = var6;
                                       var48 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var40[var48] = var68;
                                                if (var2 >= var5) {
                                                   nb = var6;
                                                   ob = new Long[7];
                                                   y = /* /*DECRYPT:dev.zprestige.prestige.d1:12:17647:4707004258840436586*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.modules.AutoAnchor_17647";
                                                   L = /* /*DECRYPT:dev.zprestige.prestige.d1:13:8807:302790967913953761*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.modules.AutoAnchor_8807";
                                                   z = Direction.values();
                                                   byte var41 = 50;
                                                   long var51 = 7343430346100205278L;
                                                   A = new int[][]{
                                                      {-1, 0, 0}, {1, 0, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, -1}, {-1, 0, 1}, {1, 0, -1}, {1, 0, 1}, {0, 1, 0}
                                                   };
                                                   break;
                                                }
                                                break;
                                             default:
                                                var40[var48] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "z\u0011\u001a0\u0090\u0003}\u0099\u0007\u008b\u0098â\u0095X\u0089c";
                                                var5 = "z\u0011\u001a0\u0090\u0003}\u0099\u0007\u008b\u0098â\u0095X\u0089c".length();
                                                var2 = 0;
                                          }

                                          int var50 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var50, var2).getBytes("ISO-8859-1");
                                          var40 = var6;
                                          var48 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var38[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "\u0012^\u0014\u009b\u0015Ë=ì;\f´nì¿ÐI";
                                 var16 = "\u0012^\u0014\u009b\u0015Ë=ì;\f´nì¿ÐI".length();
                                 var13 = 0;
                           }

                           int var47 = var13;
                           var13 += 8;
                           var18 = var15.substring(var47, var13).getBytes("ISO-8859-1");
                           var38 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var25 = var26.charAt(var34);
                  break;
               default:
                  var29[var27++] = var53;
                  if ((var34 += var25) < var28) {
                     var25 = var26.charAt(var34);
                     continue label81;
                  }

                  var26 = "ù\u0098\u0090¼:\u0013\u000e\u0007\u001c÷ÃÞ\u0001!\u0094¯b´!¿×Y¦ÛïM+bY:I\u0083ã\u0012íÀè\u008fþí\u0090A|y\b8S_mDOáÄ\u0012Ù\u0084\u0018\u009fA9Àl¡hí\u001d\u0086¥Âäæ \u001e\u000fe\u008c÷\u0083ÕuÎ";
                  var28 = "ù\u0098\u0090¼:\u0013\u000e\u0007\u001c÷ÃÞ\u0001!\u0094¯b´!¿×Y¦ÛïM+bY:I\u0083ã\u0012íÀè\u008fþí\u0090A|y\b8S_mDOáÄ\u0012Ù\u0084\u0018\u009fA9Àl¡hí\u001d\u0086¥Âäæ \u001e\u000fe\u008c÷\u0083ÕuÎ"
                     .length();
                  var25 = '8';
                  var34 = -1;
            }

            var35 = var26.substring(++var34, var34 + var25);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29079;
      if (ib[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])jb.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               jb.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d1", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = hb[var5].getBytes("ISO-8859-1");
         ib[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return ib[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d1",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 26340;
      if (lb[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = kb[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])mb.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               mb.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d1", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         lb[var3] = var15;
      }

      return lb[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d1",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 7040;
      if (ob[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = nb[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])pb.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               pb.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d1", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         ob[var3] = var15;
      }

      return ob[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d1",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = xb[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = wb[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 7;
            yield var15;
         }
         case 1 -> {
            byte var16 = 55;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 9;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 22;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 15;
            yield var24;
         }
         case 10 -> {
            byte var25 = 28;
            yield var25;
         }
         case 11 -> {
            byte var26 = 59;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 14;
            yield var29;
         }
         case 15 -> {
            byte var30 = 27;
            yield var30;
         }
         case 16 -> {
            byte var31 = 53;
            yield var31;
         }
         case 17 -> {
            byte var32 = 5;
            yield var32;
         }
         case 18 -> {
            byte var33 = 25;
            yield var33;
         }
         case 19 -> {
            byte var34 = 43;
            yield var34;
         }
         case 20 -> {
            byte var35 = 29;
            yield var35;
         }
         case 21 -> {
            byte var36 = 58;
            yield var36;
         }
         case 22 -> {
            byte var37 = 4;
            yield var37;
         }
         case 23 -> {
            byte var38 = 40;
            yield var38;
         }
         case 24 -> {
            byte var39 = 44;
            yield var39;
         }
         case 25 -> {
            byte var40 = 20;
            yield var40;
         }
         case 26 -> {
            byte var41 = 56;
            yield var41;
         }
         case 27 -> {
            byte var42 = 61;
            yield var42;
         }
         case 28 -> {
            byte var43 = 32;
            yield var43;
         }
         case 29 -> {
            byte var44 = 2;
            yield var44;
         }
         case 30 -> {
            byte var45 = 49;
            yield var45;
         }
         case 31 -> {
            byte var46 = 62;
            yield var46;
         }
         case 32 -> {
            byte var47 = 8;
            yield var47;
         }
         case 33 -> {
            byte var48 = 45;
            yield var48;
         }
         case 34 -> {
            byte var49 = 0;
            yield var49;
         }
         case 35 -> {
            byte var50 = 50;
            yield var50;
         }
         case 36 -> {
            byte var51 = 18;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 63;
            yield var53;
         }
         case 39 -> {
            byte var54 = 10;
            yield var54;
         }
         case 40 -> {
            byte var55 = 3;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 21;
            yield var58;
         }
         case 44 -> {
            byte var59 = 11;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 36;
            yield var61;
         }
         case 47 -> {
            byte var62 = 19;
            yield var62;
         }
         case 48 -> {
            byte var63 = 35;
            yield var63;
         }
         case 49 -> {
            byte var64 = 6;
            yield var64;
         }
         case 50 -> {
            byte var65 = 31;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 42;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 37;
            yield var69;
         }
         case 55 -> {
            byte var70 = 52;
            yield var70;
         }
         case 56 -> {
            byte var71 = 47;
            yield var71;
         }
         case 57 -> {
            byte var72 = 26;
            yield var72;
         }
         case 58 -> {
            byte var73 = 54;
            yield var73;
         }
         case 59 -> {
            byte var74 = 38;
            yield var74;
         }
         case 60 -> {
            byte var75 = 30;
            yield var75;
         }
         case 61 -> {
            byte var76 = 17;
            yield var76;
         }
         case 62 -> {
            byte var77 = 13;
            yield var77;
         }
         default -> 39;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            xb[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      wb[0] = "v@\u000fz_/v@\u0018&S l\u000b\u00188S5kzJf\u0004\u007f";
      wb[1] = boolean.class;
      xb[1] = "java/lang/Boolean";
      wb[2] = "z\u0019\u001bQJyl\u0019\u001e\u000bYn{R\u001d\rUzj\u0015\n\u001a\u001em/";
      wb[3] = "mG\f~`afH\u001d1\u0003lsE\u0012Z6nbV\u000ev!c";
      wb[4] = "tQNh\u00040tQY4\b?n\u001aY*\b*ik\twY";
      wb[5] = "GDl^A'GD{\u0002M(]\u000f{\u001cM=Z~.C\u001a";
      wb[6] = "9\u0019i~pS/\u0019l$cD8Ro\"oP)\u0015x5$G$";
      wb[7] = "\u0019P4MYblp?BH-\r~4ILwy";
      wb[8] = void.class;
      xb[8] = "java/lang/Void";
      wb[9] = "\u0015\u0010D\u0013Zd\u0015\u0010SOVk\u000f[SQV~\b*\u0007\t\u0001";
      wb[10] = "I\bw@R\\I\b`\u001c^SSC`\u0002^FT22\\\t\r";
      wb[11] = "4\u000fV\u0019u(\"\u000fSCf?5DPEj+$\u0003GR!;<\u0003EY{v\u0000\u0018ED{17\u000f";
      wb[12] = "w\u000ex\u0004'4w\u000eoX+;mEoF+.j4?\u0013|h";
      wb[13] = "\u0002:u?\u0011{\u0014:pe\u0002l\u0003qsc\u000ex\u00126dtEo*";
      wb[14] = "xmNP\u0011c\rME_\u0000,lCNT\u0004v\u0018";
      wb[15] = "\\j\u0012%kG\\j\u0005ygHF!\u0005gg]APT92\u0018";
      wb[16] = ";\u0016mq\u0014-;\u0016z-\u0018\"!]z3\u00187&,+mM|";
      wb[17] = "^\bPk\u0010M^\bG7\u001cBDCG)\u001cWC2\u0016vN\u001c";
      wb[18] = "wU\\UX wUK\tT/m\u001eK\u0017T:jo\u001aH\u0000y";
      wb[19] = "<\u0010;\u0002h\u0003*\u0010>X{\u0014=[=^w\u0000,\u001c*I<\u00107";
      wb[20] = "~NS>\u0007;\u000bnX1\u0016tj`S:\u0012.\u001e";
      wb[21] = "\u000el;0H4\u0018l>j[#\u000f'=lW7\u001e`*{\u001c%/";
      wb[22] = int.class;
      xb[22] = "java/lang/Integer";
      wb[23] = "v1=|MQ\u0003\u00116s\\\u001eb\u001f=xXD\u0016";
      wb[24] = "w\u001e7XF\u0003|\u0011&\u0017!\u0001i\u001a&\\\u001a";
      wb[25] = "\u001bvtjx\u001c\rvq0k\u000b\u001a=r6g\u001f\u000bze!,\n&";
      wb[26] = "M=\u0017\u001e\u0000W8\u001d\u001c\u0011\u0011\u0018Y\u0013\u0017\u001a\u0015B-";
      wb[27] = "R!\u000bcB[Y.\u001a,#UR%\u001ev";
      wb[28] = "\"\"#BqbW\u0002(M`-6\f#FdwB";
      wb[29] = "?\u0002Rd\u0011nJ\"Yk\u0000!+,R`\u0004{_";
      wb[30] = "{\u000b\u0007\u000f\u0003h\u000e+\f\u0000\u0012'o%\u0007\u000b\u0016}\u001b";
      wb[31] = "\u0013\u00069ys-f&2vbb\u0007(9}f8s";
      wb[32] = "c\u0003jAruu\u0003o\u001babbHl\u001dmvs\u000f{\n&dk";
      wb[33] = "\"{ov~uW[dyo:6Uork`B";
      wb[34] = "\u0004\u0016;\u0013\u00038q60\u001c\u0012w\u00108;\u0017\u0016-d";
      wb[35] = "\b\u001f\t/9^}?\u0002 (\u0011\u001c1\t+,Kh";
      wb[36] = "^\u000fZ\r\u00045^\u000fMQ\b:DDMO\b/C5\u001f\u001bYn";
      wb[37] = "=\u0002KR:N=\u0002\\\u000e6A'I\\\u00106T 8\u000eKn\u0015";
      wb[38] = "W\u0004J\u0019\u0013@I\fPVq\\N\u0011";
      wb[39] = "D`u}l\u000f1@~r}@PNuyy\u001a$";
      wb[40] = "qv=(}D\u0004V6'l\u000beX=,hQ\u0011";
      wb[41] = "K\u0014R#>\u000e]\u0014Wy-\u0019J_T\u007f!\r[\u0018Chj\u0018a";
      wb[42] = "`SV3iz\u0015s]<x5t}V7|o\u0000";
      wb[43] = "\u001d\u0004\u0010 p%\u001d\u0004\u0007||*\u0007O\u0007b|?\u0000>V:.";
      wb[44] = double.class;
      xb[44] = "java/lang/Double";
      wb[45] = "*\toW{\"<\tj\rh5+Bi\u000bd!:\u0005~\u001c/6\f";
      wb[46] = "8\u001ch\u0014I\u0011M<c\u001bX^,2h\u0010\\\u0004X";
      wb[47] = "{`(\"\u001c\u0012\u000e@#-\r]oN(&\t\u0007\u001b";
      wb[48] = "\bXI\u0017'\u0015\u001eXLM4\u0002\t\u0013OK8\u0016\u0018TX\\s\u0001\u0014";
      wb[49] = "\u000eG2\u0002IG{g9\rX\b\u001ai2\u0006\\Rn";
      wb[50] = "6>\u000b)\u00187C\u001e\u0000&\tx\"\u0010\u000b-\r\"V";
      wb[51] = "\u00009[#5ku\u0019P,$$\u0014\u0017[' ~`";
      wb[52] = "c\u0004X\u000eu.\u0016$S\u0001daw*X\n`;\u0003";
      wb[53] = "&\u0003\u0017E\u0016;-\f\u0006\nu68\n";
      wb[54] = "-\u0002\u0004/[\u0005&\r\u0015`&\u00104\u0017\u0017#";
      wb[55] = long.class;
      xb[55] = "java/lang/Long";
      wb[56] = "jCR^:#jCE\u00026,p\bE\u001c69wy\u0017Fb}";
      wb[57] = "\u0014\r\u0015?\u001b`\n\u0005\u000fp`@7(";
      wb[58] = "qa\u001b9^$ga\u001ecM3p*\u001deA'am\nr\n7&";
      wb[59] = "\u000f_:%\fVz\u007f1*\u001d\u0019\u001bq:!\u0019Co";
      wb[60] = "=B1\\;K=B&\u00007D'\t&\u001e7Q xsFf";
      wb[61] = "}\u001dLXwh}\u001d[\u0004{ggV[\u001a{r`'\u000eE.";
      wb[62] = " E\u0002\u0007}[ E\u0015[qT:\u000e\u0015EqA=\u007fE\u001c#\u0000";
      wb[63] = float.class;
      xb[63] = "java/lang/Float";
      wb[64] = "68Mv#\b 8H,0\u001f7sK*<\u000b&4\\=w\u0019*";
      wb[65] = "a9.=a9\u0014\u0019%2pvu\u0017.9t,\u0001";
      wb[66] = "\u0001~lkynt^gdh!\u0015Plol{a";
      wb[67] = "\u0010$\u0013~\u0019^\u001b+\u00021u]\u0015)\u0000~Y";
      wb[68] = "v\f>\u0004G]\u0003,5\u000bV\u0012b\">\u0000RH\u0016";
      wb[69] = "c{+CJ,\u0016[ L[cwU+G_9\u0003";
      wb[70] = ".Iw]6Z8Ir\u0007%M/\u0002q\u0001)Y>Ef\u0016bN\f";
      wb[71] = "l!m67)\u0019\u0001f9&fx\u000fm2\"<\f";
      wb[72] = "\u0012eD83PgEO7\"\u001f\u0006KD<&Er";
      wb[73] = ")\u0006.\u0016>\n\\&%\u0019/E=(.\u0012+\u001fI";
      wb[74] = "N*o\u0016)\t;\nd\u00198FZ\u0004o\u0012<\u001c.";
      wb[75] = "F/:C\u0013^3\u000f1L\u0002\u0011R\u0001:G\u0006K&";
      wb[76] = "!r-{P-TR&tAb5\\-\u007fE8A";
      wb[77] = "\u0018\rC%q#\u0018\rTy},\u0002FTg}9\u00057\u00058/rR\u000b[jo9)Z\u00048%";
      wb[78] = "X6`h\u000fz-\u0016kg\u001e5L\u0018`l\u001ao8";
      wb[79] = "\u0014\bOrrma(D}c\"\u0000&Ovgxt";
      wb[80] = "N\u000bF6]JX\u000bClN]O@@jBI^\u0007W}\t]N";
      wb[81] = "\u007f\u0018-\rV\u0011a\u00107B0\u0005f\u0011\u0016\r\b";
      wb[82] = "\u001c\"q\u0007\u000f1i\u0002z\b\u001e~\b\fq\u0003\u001a$|";
      wb[83] = "PT\u001a\u001b\u001b>[[\u000bTs>UT\u0018";
      wb[84] = "KWN!<t>wE.-;_yN%)a+";
      wb[85] = "dM61\u001bU\u0011m=>\n\u001apc65\u000e@\u0004";
      wb[86] = "0fEf8\u0019EFNi)V$HEb-\fP";
      wb[87] = "4d8{-I\"d=!>^5/>'2J$h)0y[i";
      wb[88] = "{k[\u001fI\u0019\u000eKP\u0010XVoE[\u001b\\\f\u001b";
      wb[89] = "s\u0010l\u000es4s\u0010{R\u007f;i[{L\u007f.n*,\u0013)";
      wb[90] = "i\u0000{\u0012\u0011\u000bi\u0000lN\u001d\u0004sKlP\u001d\u0011t:9\u000fD";
      wb[91] = "x\u0016m)N\u0000\r6f&_Ol8m-[\u0015\u0018";
      wb[92] = "m\u0006F\u000eRq\u0018&M\u0001C>y(F\nGd\r";
      wb[93] = "\u0007e\u000f\u000e\u0001WrE\u0004\u0001\u0010\u0018\u0013K\u000f\n\u0014Bg";
      wb[94] = "o\u0016`<\u000bD\u001a6k3\u001a\u000b{8`8\u001eQ\u000f";
      wb[95] = "_.|IU2*\u000ewFD}K\u0000|M@'?";
      wb[96] = "}&7+1vc.-dLfc";
      wb[97] = "\u0011XP}FT\u000fPJ2\u000eT\u0015ZRu\u0007OUiTy\fH\u0018XRy";
      wb[98] = "\u001e*\u000eh6)k\n\u0005g'f\n\u0004\u000el#<~";
      wb[99] = "AO;0l\u00184o0?}WUa;4y\r!";
      wb[100] = "G8I\u0004}\u00012\u0018B\u000blNS\u0016I\u0000h\u0014'";
      wb[101] = "'D(6+XRd#9:\u00173j(2>MG";
      wb[102] = "{{F[SoptW\u00149ldx\\_";
      wb[103] = "\u001dnK&Xt\u001dn\\zT{\u0007%\\dTn\u0000T\r>\r-";
      wb[104] = "qgm6>Jqgzj2Ek,zt2Pl]+/e\u001a";
      wb[105] = "uUy5Ax~Zhz,{rDn&\u000evsQ";
      wb[106] = "}<\fO{0}<\u001b\u0013w?gw\u001b\rw*`\u0006JV\"h";
      wb[107] = "R%\u000esP\u001dR%\u0019/\\\u0012Hn\u00191\\\u0007O\u001fHj\bL";
      wb[108] = "a\u0016 G/L\u00146+H>\u0003u8 C:Y\u0001";
      wb[109] = "\u001d\u001a\b<,\u0019h:\u00033=V\t4\b89\f}";
      wb[110] = "\u0015_CV!/\u0003_F\f28\u0014\u0014E\n>,\u0005SR\u001du8\u0013";
      wb[111] = "\u000fm-Z=[\u0019m(\u0000.L\u000e&+\u0006\"X\u001fa<\u0011iM>";
      wb[112] = "\u001eYL4HIkyG;Y\u0006\nwL0]\\~";
      wb[113] = "\u0007i`\u0012X\u001e\u0007iwNT\u0011\u001d\"wPT\u0004\u001aS%\u000e\f@";
      wb[114] = "\nlyp\r$\u007fLr\u007f\u001ck\u001eByt\u00181j";
      wb[115] = "Iu\u001d`\u0019\u000f<U\u0016o\b@][\u001dd\f\u001a)";
      wb[116] = ".~e`&v8~`:5a/5c<9u>rt+rg/";
      wb[117] = "EUq*\u001e[0uz%\u000f\u0014Q{q.\u000bN%";
      wb[118] = ".\u000bN>\u000bb[+E1\u001a-:%N:\u001ewN";
      wb[119] = "\u00175Dba-\u00175S>m\"\r~S m7\n\u000f\u0002z>r";
      wb[120] = "\u0004P\u001cLfX\u0012P\u0019\u0016uO\u0005\u001b\u001a\u0010y[\u0014\\\r\u00072J\u0004";
      wb[121] = "}kkw\u0004\u0015\bK`x\u0015ZiEks\u0011\u0000\u001d";
      wb[122] = "AMnL\u001c\u0002AMy\u0010\u0010\r[\u0006y\u000e\u0010\u0018\\w(WH]";
      wb[123] = "\u0019dt}r;lD\u007frct\rJtyg.y";
      wb[124] = "AF8{m%4f3t|jUh8\u007fx0!";
      wb[125] = "e\u001a!q&%{\u0012;>K?b\u000b6bi$`\t";
      wb[126] = "p?.9rcn74v\u0015b\u007f,9,3d";
      wb[127] = "\"\tTTz5W)_[kz6'TPo B";
      wb[128] = "u\u0006$NHF~\t5\u00015^m\u000e<H";
      wb[129] = "@dbO5nVdg\u0015&yA/d\u0013*mPhs\u0004a}\u0016";
      wb[130] = "\u001c)U!nGi\t^.\u007f\b\b\u0007U%{R|";
      wb[131] = "-\u0014$WA\u0015X4/XPZ9:$ST\u0000M";
      wb[132] = "t\u0016\u001f]u\u0011\u00016\u0014Rd^`8\u001fY`\u0004\u0014";
      wb[133] = "\u001b\u0013\u0003}npn3\br\u007f?\u000f=\u0003y{e{";
      wb[134] = "o-^\u0004!r\u001a\rU\u000b0={\u0003^\u00004g\u000f";
      wb[135] = "\u0019\u0010MXU)l0FWDf\r>M\\@<y";
      wb[136] = "17^KB+D\u0017UDSd%\u0019^OW>Q";
      wb[137] = "c,\u0016I9#\u0016\f\u001dF(lw\u0002\u0016M,6\u0003";
      wb[138] = "xOK-\u001f:eZ\u0013\u000f^7}\\";
      wb[139] = "\u001d?Bi$(h\u001fIf5g\t\u0011Bm1=}";
      wb[140] = "\u001d^P\u0019?I\u000b^UC,^\u001c\u0015VE J\rRARkX\u001f";
      wb[141] = "\u001cr#F ViR(I1\u0019\b\\#B5C|";
      wb[142] = "XL\u001c\u0002AXXL\u000b^MWB\u0007\u000b@MBEvY\u001a\u001a\u0000";
      wb[143] = "yvvtJ-yva(F\"c=a6F7dL3m\u001e}";
      wb[144] = "<{Qbw\u0011I[Zmf^(UQfb\u0004\\";
      wb[145] = "Y\rs\u00132]O\rvI!JXFuO-^I\u0001bXfZ";
      wb[146] = "u8\u0004n)kc8\u00014:|ts\u000226he4\u0015%}z";
      wb[147] = "f9I/?{\u0013\u0019B .4r\u0017I+*n\u0006";
      wb[148] = "4\u0017M$\nhA7F+\u001b' 9M \u001f}T";
      wb[149] = "\u001dX\\cS:hxWlBu\tv\\gF/}";
      wb[150] = "\u000ee\bL\f\u0004{E\u0003C\u001dK\u001aK\bH\u0019\u0011n";
      wb[151] = "3::\u0012\u001bo85+]yl7<";
      wb[152] = "Npc\u001c=A;Ph\u0013,\u000eZ^c\u0018(T.";
      wb[153] = "k1t \u0003\"\u001e\u0011\u007f/\u0012m\u007f\u001ft$\u00167\u000b";
      wb[154] = "-w)he(3\u007f3'\u0006<72\u001ag?/>";
      wb[155] = "F^\u0012$\u0017\u000f3~\u0019+\u0006@Rp\u0012 \u0002\u001a&";
      wb[156] = "e\u0013\n\u001b\"s\u00103\u0001\u00143<q=\n\u001f7f\u0005";
      wb[157] = "\u0003F<NV\u0013\u0015F9\u0014E\u0004\u0002\r:\u0012I\u0010\u0013J-\u0005\u0002\u0007\u0011";
      wb[158] = "f$Nu\\k\u0013\u0004EzM$r\nNqI~\u0006";
      wb[159] = "6UvE\u0015D\u0000pvE\u0002\u0018\f\u007fl\u000e\u0002\u0006\fjk\u007fSYX)#";
      wb[160] = "\u0012\u0015H{Zzg5CtK5\u0006;H\u007fOor";
      wb[161] = "r\u0004\u0012\u001fB$r\u0004\u0005CN+hO\u0005]N>o>T\u0002\u0016";
      wb[162] = "{S\u0003Cx\t\u000es\bLiFo}\u0003Gm\u001c\u001b";
      wb[163] = "g,X\u001fDc\u0012\fS\u0010U,s\u0002X\u001bQv\u0007";
      wb[164] = "\u0011R!~3mdr*q\"\"\u0005|!z&xq";
      wb[165] = "d]\u001fZ\u0016\u0007\u0011}\u0014U\u0007Hps\u001f^\u0003\u0012\u0004";
      wb[166] = "\u0011u>Q9!dU5^(n\u0005[>U,4q";
      wb[167] = "m\u0016\u007fWI/{\u0016z\rZ8l]y\u000bV,}\u001an\u001c\u001d;@";
      wb[168] = "nU{?\u0004I\u001bup0\u0015\u0006z{{;\u0011\\\u000e";
      wb[169] = "Sj%\u000e-\u0014Ej T>\u0003R!#R2\u0017Cf4Ey\u0000z";
      wb[170] = "*\u0003Q5{g_#Z:j(>-Q1nrJ";
      wb[171] = "m){\nTjda*\u0002\u0014\u000b1y6:\u0000jha#J\u0012yetFT\u000f7%u6F\u001c:0\u0010([Rz1`:H_oT";
      wb[172] = ",\r\u0018\u000fs+k\u000e\r\u0013yMp\u0012\u0014\u000e{!BFQP!q\u0015EPTx*$OVSs4\u0015EQQe5$F\u0012\r!*\u0015";
      wb[173] = "xE\u00131\u0002P)_\u00191yMG\u0004\u0004e\bK.SGv@L";
      wb[174] = "\blLk\u0003}\u0018r\u001a<s#\u0000}\u0014;$tY-Los'\u000eo\u001b0\u0015=\u0013p@";
      wb[175] = "&\u0002DD?\u0006c@QEU\u0005\u001fE\u0007P-SpFYK/\u0017\u001fD\n_e\u000b.GR\u001fh\u0011\u001f";
      wb[176] = "M\fj\u00171k\bN\u007f\u0016[ktK)\u0003#>\u001bHw\u0018!zt\fh\u00130>\fAtLe\u0001";
      wb[177] = "d\u0012]\n\u0003\u001ft\b\u0000[}_z\u0010\u001dcGIe\tQ]\u0012HmVPcC\u001e![\u0000_MK&Pa";
      wb[178] = "7\u00115C\u000f4lHqAc2\u000bJxL\u001badI&W\u0019%\u000bOs\u0001R?7A&\u0006Y^";
      wb[179] = "\u0018?ME\u00077^$^\t\u001c\n@'cQ\u0003vP\\S[\u000b6K8^K\u0017\n";
      wb[180] = "\u0004\u0002\b\u0007V/\\Z\f\u001e4uWOR\u0010XG\u0000\u000f\u000fN\t\u0010PO\u0003\bN|\u000bUKN4";
      wb[181] = "|(`>\u0013\\ab1f}M\u0007cl(\u0005\u001bh`23\u0007_\u0007%2)ANc(\"5}";
      wb[182] = "Bf\u001eG%e\u000fzA\u0012\u001axSj\u001fKvJ\u0007.E\u0013\u001a`Nn\u001fN bBpE,";
      wb[183] = "\u0005\u001f\u0019;?aY\u000fLl}]R\u0006\u000elf&?\u001dB5{fT\u0002\by;]B\u0010\u00039h9O\u0000\u001f\u0005";
      wb[184] = "h,pXS/0ttA1u;a*O]Gh%q\u00121)il2\u0018Wb)g5W1";
      wb[185] = "@\u000f]pn\u0012\u0003\u0001\f+~/\u0013?\bx\u007fWEP\u000b&dU\u0001?\rs2\u001e\u001b\u0003\u0003&5\u0015z";
      wb[186] = "t]d\bg\rbJfP\u001eX\u0004\b.\u001ff\u000ek\u000bp\u0004dJ\u0004Np\u001e\"[`C`\u0002\u001e";
      wb[187] = "\b=9>DrSy29_OTo)$X#f;h\u007f\u0001t1;j5G\u007fWp*>@01;j5G\u007fWp*>@01;j5G\u007fWp*>@01;j5G\u007fWp*>@01";
      wb[188] = ".\u001f!\u0007\u001a<iL(\u0000'bpJ}\u0011p1!\u001f)}\u00184)]$M_g Z";
      wb[189] = "RTd}\u0005\u0003\u0019Sd2F>\u000eY~m\u001fR<\r:7F\u0002kZc1\t[\u001bHp<\u001c>";
      wb[190] = "!`\u0006;Q/d\"\u0013:;.\u0018'E/Czw$\u001b4A>\u0018a\u0004&['\"c\b8\u0001E";
      wb[191] = "\u0001<\u0001\\\u0019\bD~\u0014]s\u000e8{BH\u000b]Wx\u001cS\t\u00198.\u0012\u0005\u0002\u0007H<\u0001\b\u0017b";
      wb[192] = "U'(^\u001eeK6/\u0007uo+`d\u0010\r9Dc:\u000b\u000f}++;\u001a\u0013\u007f\u0017=,\u0018K\u0006";
      wb[193] = "D\u007f#\u001e\u000b>\u000fx#QH\u0003\u0018r9\u000e\u0011o*&}TH8}q$R\u0007f\rc7_\u0012\u0003";
      wb[194] = "HjX\b>)\r(M\tT,q-\u001b\u001c,|\u001e.E\u0007.8qkE\u001dh)\u0015fU\u0001T";
      wb[195] = "\u0019|dV%M\u001cd|W)+Fkr\t%Gt9?Qs+[{p\u0002<ZLed\rB";
      wb[196] = "*\u0017=\u001cn\u001bz\u0014e\\qa}\u0016`Nb=t3a[T\u0000o\t\u0007\u001e!\u0010kBaUa\u001bl\r\u0007I\u007f]b\u0017w[lPwr";
      wb[197] = "\u001a[t}'zWG+(\u0018g\u000bWuqtU_\u0013/'\u0018~\u0016J~)`3\n\u0015+\u0016";
      wb[198] = "/8\f:XLjz\u0019;2\\\u0016\u007fO.J\u0019y|\u00115H]\u0016zDc\u0003G*t\u0011d\b&";
      wb[199] = "q\u007fa{\u0011 pvwg\u0001R\"qtz\u0006;.Hzz\u0016?Hk|nW8,flrk";
      wb[200] = "\u000bn7I+!\u001bpa\u001e[\u007f\u0003\u007fo\u0019\f(Z+4L[{\rm`\u0012=a\u0010r;";
      wb[201] = "+(G6tz=?En\r/[}\r!uy4~S:w=[\u007f\u0003!uv=4C*r9[";
      wb[202] = "\u000eyF\u0011\r9\u000fpP\r\u001dKWyO\u0014<,[}4\t\u0018;\u000bzP\u0004\b'7~UH\u0006.GlFE\u0013K";
      wb[203] = "]_\u0003 Q]T\u0017R(\u0011<\u0001\u0007X\u0010\u0005]X\u0017[`\u0017NU\u0002>~\n\u0000\u0015\u0003Nl\u0019\r\u0000fPqWM\u0001\u0016BbZXd";
      wb[204] = "D%\\;\u00147\u001c{_s\u0018J\u0018s\u001aj\u001d&*#V2GJ\u0000q\u00166\u0010.\ra\n\n";
      wb[205] = "\rl$\u0000B3\r;a\f?=h:o\fGo\u000791\u0017E+h|1\r\u0003:\fq!\u0011?";
      wb[206] = "y|Y8=T<=\u0004z)0%/H*%\\\u0017x\u0004u{0yyF,:T{,K++0y\u007fO)-M|=X' 0";
      wb[207] = "qW OBLr\u0001}N\u007f]hW$A(\t2\u0003|\u0014\u007fKtD+S\u000e\\jP$";
      wb[208] = "Afk\u0010+UQ|6AU\u0007TrW\u001bd^A%<\u0004.\u0012\u0001\u001e*\u0016%RRz'\u00069n";
      wb[209] = "H-#oE|\u0010u'v'&\u001b`yxK\u0014H$' 'zIma/A1\tff`'";
      wb[210] = "\u0011\u0006~*\u0015\u000eAXc{,V\u0017\u001asp@dC^**\u00173\u0011\u0006~*\u0015\u000eAXc{,";
      wb[211] = "\u001b\u007f'5C3G\u007f.9\u001dTN`b[\u00120\\`\u001egJdX6ux\u0000(\u0018\r";
      wb[212] = "R$\u001bk_\u0019\u001f8D>`\u0004C(\u001ag\f6\u0017l@9`\u001c^,\u001abZ\u001eR2@\u0000\u001c\u0011O?ExQ\r\u0010jz";
      wb[213] = "\u0019Y0:\u0012\u000eN\u001a#r\u0015gJ!ez\u0004\u001f\u001cNf$\u001f\u001dX!#$\u0005[IE.4\u0019g";
      wb[214] = "RB\u0014D\\Y[\nEL\u001c8\u000e\u0012Yt\u001bH\u0013\u001bKN\u0019D\rA)\t\u0016@\u000b\u0019\u0013\u000b\u001a^Q{T\u0004\u001eX\tAV\b\u0000\u0002k";
      wb[215] = ".pb8F)e,9aOU{z#\u0018N-t~_?Kier/-Xdp\u0017";
      wb[216] = "V/^s\t%\u000ewZjk\u007f\u0005b\u0004d\u0007MS'Y?[\u001aRg\u0003xZg\u0014|\u0007qW\u001a";
      wb[217] = "\u000bR\u0013TZ+\u000f\u001dIZ\nOHAHWN\"sB-\tN!@BK\\KvON-M_?\u000eFI@O#2";
      wb[218] = "t>91u\",f=(\u0017x'sc&{Jq1?|+\u001ds0r9'{8py>h\u001d";
      wb[219] = "T\u0000\u001f~h\u001dD\u001aB/\u0016GQ\u0015Y~jAWx\u0019y{MGI\u0019}i\u0017Lx";
      wb[220] = "N.p\u001d\u0003K\u000ble\u001ciBwi3\t\u0011\u001e\u0018jm\u0012\u0013Zwl8DX@KbmCS!";
      wb[221] = "\u001aj4N\u00114Jil\u000e\u000eNHhk\r\b4N\u000f7J\u00106\u0013i|\n\u001b1\\\u000f7J\u00106\u0013i|\n\u001b1\\\u000f`\u0014]?F\u007fr\u0007P*#";
      wb[222] = "JK\u0005\t3sJA\u001d\u0018/L\u0018zEQ#4N\u0015F\u000f86\nzEQ)%\u0010EE[14\fz";
      wb[223] = "i5|]\u0000Uh<=\u0018y[\u0004uw\u0014\u0001\rkv)\u000f\u0003I\u0004p|YHS8~)^C2";
      wb[224] = "j;.2*Jcs\u007f:j+:hh\u0002)\u0014\"z#dbT)}l\u0002)\u0014\"z#dbT)}l\u0002";
      wb[225] = "\u0019\u0005pQ<ED\tp\u0010h8K\u0010(WjBMw0_{XBM2Se\u0002 \n=WcZ\u001a\b1I98N\u0016q^fH\\\u0005|K\u0003";
      wb[226] = "[\u0015`\u0014]3\u0012\u0000r\u001a3?\r\fn\u0019_\rZ@?@3dQJ~\u001c\f<\tNg~\fbX\n3NK1Q\r\u000eNY#Z\u00163\u0011Jc\u001fpiF]5QIn\u0014\u000eZ";
      wb[227] = "\u0013KBT\u0000\u000bV\tWUj\u0006*\f\u0001@\u0012^E\u000f_[\u0010\u001a*\t\n\r[\u0000\u0016\u0007_\nPa";
      wb[228] = "<P3T'Ty\u0012&UML\u0005\u0017p@5\u0001j\u0014.[7E\u0005\u0012{\r|_9\u001c.\nw>";
      wb[229] = "q'\u001457Kte\u0003;:6-w\u00136?Z\u001f ^ki6&{S'=F4h^2X";
      wb[230] = "t\u0019t1\u0000U}Q%9@47G4gV4t\u001f8y\nR?_3~E4#Aup_D1Rxe:";
      wb[231] = "\u0018Z)|t)L]-;\n#t\u001cf7ru\u001b\u001f8,p1tGg4z$HH'}3J";
      wb[232] = "{=brF7 d&p*=Gf/}Rb(eqfP&Gc$0\u001b<{mq7\u0010]";
      wb[233] = "p/\u001f\u0006:\t83\u0012\u0016<r OYXs\nu Z\u0006h\b1O\u001e\u0019c\u0019u7S\u0005<LJ";
      wb[234] = "VS\ny\u0010\b\u0013\u0011\u001fxz\u001fo\u0014Im\u0002]\u0000\u0017\u0017v\u0000\u0019o\u0011B K\u0003S\u001f\u0017'@b";
      wb[235] = "-}\u0001H\u000b8h?\u0014Ia-\u0014:B\\\u0019m{9\u001cG\u001b)\u0014?I\u0011P3(1\u001c\u0016[R";
      wb[236] = "|Mk^U\u0018b\\l\u0007>\u0011\u0002\n'\u0010FDm\ty\u000bD\u0000\u0002\b)\u0010FKdCi\u001bA\u0004\u0002";
      wb[237] = "\u0015>\u001f@\u0011\fD$\u0015@j\u001e*|@\u001bT\nE$K\u0000\u0012\u001c";
      wb[238] = "\u00035O\u001a\"G\u001e\u007f\u001eBLVx~C\f4\u0000\u0017}\u001d\u00176Dx+\u0013A=Z\b9\u0000L(?";
      wb[239] = "Y:f\u000f|5\u0001deGpH\u0005l ^u$7<b\u0000-HY:.Xj,[o#_{H";
      wb[240] = "f\u0003Y^lG#AL_\u0006D_E\u001b\u0003g\u001d#\u0003DI=-eO\u0013Z6Q#\u0010Y\u0000\u0006";
      wb[241] = "J\u0016\u0002\u000f\u0002YK\u001fCJ{T'\u0003Y\u000b\n[W\u0011J\u0006\u001f>";
      wb[242] = "'\r\u0010^0~j\u0011O\u000b\u000fk\"\u0000\u0018Qt\u00069LAL4m&\u0006\r\f\u000f{4\rM_kv$\u0011q";
      wb[243] = "\u0014\r\u0002\u0000\u00168Q[\u0017\u0000tiN\n\u000bQ#>\u0010YV=ObA\r\u0001T\u0006wS\u0003";
      wb[244] = "\u0018o\u001djD^@7\u0019s&\u000fG3CvqZ\u0017b\u001b\u001a\u001f_K,X~Z\u001e\u0016nL";
      wb[245] = "F)4{/c\u001d3|=UjA)ec9X\u0015m=:o\u000fF)4{/c\u001d3|=U";
      wb[246] = "\u001cu5VM*Y7 W')%2vB_\u007fJ1(Y];%0%TG=\u0018b}\f\u001c&%";
      wb[247] = "{\u0006l\u0015J\u0012>Dy\u0014 \u0019BA/\u0001XG-Bq\u001aZ\u0003B\u0007q\u0000\u001c\u0012&\na\u001c ";
      wb[248] = "5\u0003*6I)nZn4%-\tXg9]|f[9\"_8\t]lt\u0014\"5S9s\u001fC";
      wb[249] = ";\u000e8\u000f$:`W|\rH>\u0007Uu\u00000ohV+\u001b2+\u0007\u0013+\u0001t:c\u001e;\u001dH";
      wb[250] = "\t*\u001b5\u001f\u0006Rs_7s\u00015qV:\u000bSZr\b!\t\u00175t]wB\r\tz\bpIl";
      wb[251] = "Jg\u001ef+\u001a\u000f%\u000bgA\u001es ]r9O\u001c#\u0003i;\u000bsf\u0003s}\u001a\u0017k\u0013oA";
      wb[252] = "\u0011\u0013KFf!IKO_\u0004{B^\u0011QhI\u0011\u001bI\n\u0004!\u0017\u001a\u000b\u000b4fD\u0013\f6:$\u0013\u0013\u0010\n4q\u0014\u0018q";
      wb[253] = "h]\r\u000e\u001bK8\u0003\u0010_\"\u0013nA\u0000TN!:\u0005Y\u000f\u0012vm\\\\BG\u0006\u007fOQW\"";
      wb[254] = "'(\u0019\rx6bj\f\f\u00127\u001eoZ\u0019jcql\u0004\u0002h'\u001emT\u0019jlx&\u0014\u0012m#\u001e";
      wb[255] = "9N\f;batRSn]|(B\r71N|\u0006Wj]e5_\u0006o%()\u0000SP i=^\u000fj\"e#\u0004m";
      wb[256] = "RJ4\u0006g\f\u0019M4I$1\u000eG.\u0016}]<\u0013jL$\tkD3JkT\u001bV G~1";
      wb[257] = "e=\f\u0011U$ejI\u001d((\u0000kG\u001dPxoh\u0019\u0006R<\u0000-\u0019\u001c\u0014-d \t\u0000(";
      wb[258] = "\u0010D )#tWG55)\u0012L[,(+~~\nmts.)K?8pxMF/$L";
      wb[259] = "~ %l)\td=:7N\ny3:`\"8$tj6N\u0017i11y?\u0000w%>\u0007";
      wb[260] = "\u0005(q{lV\u0000t?;=/U\u0014uq'W\u0003{v/<UG\u0014207D\u0003l\u007f,h\u0011<";
      wb[261] = "w{(\u001dC\u007f=h(\u0011\u0007O(\u007f0\u0017\u0019#\u001a+uLF~Mx0F\u00015!#*\u000eGO";
      wb[262] = "*A\u007f.#.h];q0Oh&9\";7,I:| 5h&<)v~r\u001a2|qu\u0013";
      wb[263] = "Dgr&X\u001f\u000f;)\u007fQc\u0011m3\u0005P\u001e\u0013\u0000!.\b\u0012\u001bp3=\u0005\u0007~";
      wb[264] = "\n\u007f\u001bQ:3R!\u0018\u00196NV)]\u00003\"d}\u0011_e~38Q\u0001?qKuM^jN";
      wb[265] = "f3D8;V+/\u001bm\u0004Kw?E4hy#{\u001cb\u0004Rj\"Nl|\u001fv}\u001bSx^{(\u001a+5B$}%";
      wb[266] = "FI'HT)\u0012J-WEF\u0015#|\u001dI>CL\u007fCR<\u0007#}@\u0002$\u001eA-\u0012\t8\u0015#";
      wb[267] = "\u0017)\u0016pT \u00121\u000eqXFH>\u0000/T*zlMs\fFC2@>V6Q!M+3";
      wb[268] = "t\u007f78YR+lw}?\n)i.eS8}*q2\u0007o/u#?\u0006R\u007f+>n?";
      wb[269] = "^\u0014\u0013hp\u0012YF@\u0007$FEL\u001ak\u0016\u0011\u0002\u0012C:AVV\\Am%[F@}";
      wb[270] = "I\u0013C ;{\u001fM_\u007f-\u0015\u001bW]a&s\fvF~&P\u0011NCz0\u0015I\u0010C$\"u\u000fAVp*\u0015";
      wb[271] = "Z\t-{M>J\u0013p*3\u007fN\u0014vl^\u0005A@!k\bn^\nm+3xL\u0001-xWu\\\u001d\u0011";
      wb[272] = "!0U{z#f3@gpE}/Yzr)Ox\u001b -y\u0018(Je~\"~2Wz%E";
      wb[273] = "J\u001f(V`-\u000fI=V\u0002|\u0010\u0018!\u0007U+NHxk;kOE(\u000ebl\u0003\u001f8";
      wb[274] = "kOyp_\u0001.\rlq5\u0006R\b:dMT=\u000bd\u007fO\u0010R]j)D\u000e\"Oy$Qk";
      wb[275] = "`#_^\u0005\u000e*0_RA>?'GT_R\rs\u0002\u000f\u0000\u000eZsIDYQ<4JQE[Z";
      wb[276] = "O'zL\u0017?M3*\u001f\u000bR\u00110&\u0012);\u0011*-}Nh\u0011h)\u001d\b9\u0004<!}";
      wb[277] = "7E*f1<r\u0007?g[?\u000e\u0002ir#ia\u00017i!-\u000eD7sg<jI'o[";
      wb[278] = "D>BytYMv\u0013q48\u0006~\u00055NE\r\u007f\u001f+tG\u0001aEI3H\u0005g\u001ds1D\u001b=\u007f";
      wb[279] = "\u001d$|u\u000b\u0000\u0000n--e\u0011fopc\u001dG\tl.x\u001f\u0003fj{.T\u0019Zd.)_x";
      wb[280] = "`>\u0014Hf[ivE@&:?jY\u0004\u0001BY>\u0016\t$\n?uV\u0002#EY>\u0016\t$\n?uV\u0002#EY";
      wb[281] = "}v\u0013\u001e\u0001q6*HG\b\r(|R-\u0000aG\u007fOK\u001ch7m\\F\t\r";
      wb[282] = "(z\u0004\rX\u001fc}\u0004B\u001b\"tw\u001e\u001dBNF#ZE\u001b\u0018\u0011p\u001eLZX}+\u0004\u0004\u001c\"";
      wb[283] = "V,M\u001eL7\u0006rPOutT(]N\u000e\n\u0006vE\u0019Ed@v_FE\n";
      wb[284] = "Z=w\u000f\u001d,\u0002es\u0016\u007fv\tp-\u0018\u0013D_7p@F\u0013\u0018|,\u0014@kU`sA\u007f";
      wb[285] = "+#I3\u0017wna\\2}w\u0012d\n'\u0005\"}gT<\u0007f\u0012f\u0004'\u0005-t-D,\u0002b\u0012";
      wb[286] = "I\u0012H)\u0007C\u0012\b\u0000o}JN\u0012\u00191\u0011x\u001aVChE/M\u000fE'\u0018__\u001cH2}";
      wb[287] = "I \u0006\u0006l\u0000\u000f;\u0002\u000fa}\u00164\u001d\u001d:\u0011$d]Fm}\u001d8]\f8\r\u000f+P\u0019]G\t3^\u001a;B\u0011+_\u0016]";
      wb[288] = "\u0000,\u001eo\u007fVEn\u000bn\u0015V9k]{m\u0003Vh\u0003`oG9-\u001cru^\u0003/\u0010l/<";
      wb[289] = "Q\u0011\u000b*\u0011U\u001c\rT\u007f.H@\u001d\n&Bz\u0014YP|.Q]\u0000\u0001~V\u001cA_TAS]U\u0001\b{QQK[j";
      wb[290] = "6\u0003eP\u0002BsApQhA\u000fD&D\u0010\u0017`Gx_\u0012S\u000fEp\b\u0001Ds\u000e,SXM\u000f";
      wb[291] = "\u0011\u00056q\u0005/I\u000e-7\u0013@K5l~\u000e8\u0017Zo \u0015:S5*?\u0007 J\u000f(3\u0019z(";
      wb[292] = "_(C;p_\u00124\u001cnOBN$B7#p\u001a`\u0018hO[S9Io7\u0016Of\u001cP3WB3\u001d(~K\u001df\"";
      wb[293] = "NctR'.\u0005?/\u000b.R\u001bi5t1?\u0019bIU*n\u0005a9G9c\u0010\u0004";
      wb[294] = "fd\u000b\u001e\u001f\u001e><\u000f\u0007}D5)Q\t\u0011vfl\bS}\\7%\r\u0004\u0019Q'91";
      wb[295] = "\u001d:/t5_[!<8.b\\$0\u0005+S\u0014 wn4\u0019X`LgxR]b'x2\u001e\u001dY.4y\u001b\u001f21~5[$";
      wb[296] = "c\u00010\u0019\u0017\" \u000faB\u0007\u001f31e\u0011\u0006gf^fO\u001de\"1`\u001aK.8\rnOL%Y";
      wb[297] = "jYh\u0018wDzG>O\u0007\u001abH0HPN8\u001ci\u001e\u0007\u001elZ?Ca\u0004qEd";
      wb[298] = "\u001e;\u0000\b<`J<\u0004OBjr}OC:<\u001d~\u0011X8xrxD\u000esbNv\u0011\tx\u0003";
      wb[299] = "\u0006PB#\u0013\u0001\u0002\u001f\u0018-CeX@|%HUF\u0015\u0017:\u0002\u0019\u0006.E9G\u0001UJAv\u001d\u000f\u0005.";
      wb[300] = "IKiWM\u0011HB(\u00124\u001f$\u000bb\u001eLIK\b<\u0005N\r$\n/WSLBU-\u001eJ\u0016$";
      wb[301] = "3\u0010\u0012\u0004h\u007f2\u0019SA\u0011s^\u0005I\u0000`}.\u0017Z\ru\u0018";
      wb[302] = "fJYp^)x\u000eI=?9\u0006\t\u0015|Gli\nKgE(\u0006OK}\u00039bB[a?";
      wb[303] = "g\r0dE6*\u0011o1z z\u00105c-w @i\u000f\u0007>c\u001d35\u00052}G";
      wb[304] = "hP\u0018(~W-\u0006\r(\u001c\u00062W\u0011yKQl\u0000I\u0015\"YiJ\u0017*z\u0001mS";
      wb[305] = "\u0005\t@\\Nq@KU]$R<N\u0003H\\$SM]S^`<K\b\u0005\u0015z\u0000E]\u0002\u001e\u001b";
      wb[306] = "Xn\u0012)w\u0011\u001d,\u0007(\u001d\u0005a)Q=eD\u000e*\u000f&g\u0000a,Zp,\u001a]\"\u000fw'{";
      wb[307] = "b~O>\u00020bz]d\t\u00018yY\u0013\u0005q$\u0010_:\u0018=2tR*\u0004\u0001";
      wb[308] = "\u0011-!\u000bl\u0010N>aN\nHL;8Vfz\u0018xg\u000e5-K;iNpA\u0010!!\b\n";
      wb[309] = "\fF\u0010J\b\u0000I\u0004\u0005Kb\u000e5\u0001S^\u001aUZ\u0002\rE\u0018\u00115\u0004X\u0013S\u000b\t\n\r\u0014Xj";
      wb[310] = "\r \u001a\u0000\u000f\u0019\u00131\u001dYd\u0016sgVN\u001cE\u001cd\bU\u001e\u0001s,\tD\u0002\u0003O:\u001eFZz";
      wb[311] = "[S;vh\t\u001e\u0011.w\u0002\nb\u0014xbz\\\r\u0017&yx\u0018b\u001f#j8\u0005_@0*}c";
      wb[312] = "/[\u0018^LS/\f]R1ZJ\rSRI\u000f%\u000e\rIKKJK\rS\rZ.F\u001dO1";
      wb[313] = "{Jx6P\u001a/M|q.\u001d\u0017\f7}VFx\u000fifT\u0002\u0017Ji|\u0012\u0013sGy`.";
      wb[314] = ".>WV\u001a/k|BWp5\u0017y\u0014B\bzxzJY\n>\u0017|\u001f\u000fA$+rJ\bJE";
      wb[315] = "0@x~\"%z\u001a9-aYb\u007f< h!4\u0010?~s#p\u007f<.f60\u0003vt'es\u007f";
      wb[316] = "\u000f#FlU*T9\u000e*/#\b#\u0017tC\u0011YaJ.\u001fF\u0019/\u0016x\u0010>T3I-/";
      wb[317] = "e?\u0006\u0005\u001d%5<^E\u0002_2>[W\u0011\u00015>ASmfc+D\u000e\u000b-# CAm";
      wb[318] = "B2yO]d\u001a9b\tK\u000b\u001f\u0002#@VsDm \u001eMq\u0000\u0002e\u0001_k\u00198g\rA1{";
      wb[319] = "s\t\u001c@\u0002k#W\u0001\u0011;3u\u0015\u0011\u001aW\u0001!QHC\u0007Vv\bM\f^&d\u001b@\u0019;";
      wb[320] = "y\u0005\"\u0006\u0001~zS\u007f\u0007<o`\u0005&\bk11P{dD|\u007f\u0003<\u0015Sbk\f";
      wb[321] = "w\u0018\u000e\u0014> ,AJ\u0016R#KCC\u001b*u$@\u001d\u0000(1K\b\u001c\u001143w\u001e\u000b\u0013lJ";
      wb[322] = ":-=is~\u007fo(h\u0019y\u0003j~}a+li fco\u0003, |%~g!0`\u0019";
      wb[323] = "U5VJ!r\u0018)\t\u001f\u001eoD9WFr]\u0010}\f\u0018\u001ewY=WC$uU#\r!czQ%U\u001bavO\u007f7\\nrI'\r^bl\u0013EKQ\u007fa\u0016=\u0006M 4)";
      wb[324] = "t@qayp/Z9'\u0003ys@ yoK'\u0004x 2\u001cp]|oflbNqz\u0003r\u007f\u00001{s`l\r$\u001em}\"M%n\u007fn/X@t\u007f-aF,/ee'<";
      wb[325] = "8^v\n4\u0016}\u001cc\u000b^\u0019\u0001\u00195\u001e&Cn\u001ak\u0005$\u0007\u0001\u001c>So\u001d=\u0012kTd|";
      wb[326] = "a\u001e\u0014`#rn^])M%fK\u001ey7#\u0001@\u0007,<+qR\u0014!)NoOZa(>}\\WtM `\u0012\u0017u=2s\u001f\u0002\u0010";
      wb[327] = "o\u0002p!ns*@e \u0004{VE35|&9Fm.~bV\u0003m48s2\u000e}(\u0004";
      wb[328] = "$mhC\u0010ha/}Bzz\u001d*+W\u0002=r)uL\u0000y\u001d/ \u001aKc!!u\u001d@\u0002";
      wb[329] = "_tr^8c\u0018wgB2\u0005\u0003k~_0i1<=\u000fj?flm@<b\u0000vp_g\u0005\u001bir\u0003=a\u0016yn?";
      wb[330] = "\fE%7.\u0004\u0016X:lI\u0007\u000bV:;%5W\u0017d`I[\u0014Z;3/\u001c\u0017O'9I";
      wb[331] = "[o<_!G\u00135'R\u001d\u001cjliLeI\u0005o7Wg\rjib\u0001,\u0017Vg7\u0006'v";
      wb[332] = "#\f\u0002\u0019\\8=\u001d\u0005@72]KNWOd2H\u0010LM ]NE\u001a\u0006:a@\u0010\u001d\r[";
      wb[333] = "c_y\u0007\u0013i?O,PQU9VhYe25R\u0013WOi(ZcE\\d=?";
      wb[334] = "9\t\u00165\u0012#z\u0007Gn\u0002\u001ej9C=\u0003f<V@c\u0018dx9A3\u0003f3_\ns\ba|9";
      wb[335] = "\u001ds\u0007%yPFiOc\u0003Y\u001asV=okN7\u000ek8<\u001co[g:\u0001L1F6\u0003V\u000b>I o\r\u0011v\u000fZ";
      wb[336] = "jp\tr-N/2\u001csGMS7Jf?\u001b<4\u0014}=_Sq\u000bo'Fis\u0007q}$";
      wb[337] = "Z>s_;Z^ydE<8\u00078xB#Q\u0004BzByI\u00052hQt\\`";
      wb[338] = "\"M$GR[g\u000f1F8X\u001b\ngS@\u000et\t9HBJ\u001b_7\u001eITkM$\u0013\\1";
      wb[339] = "^\u0011xcI,\u001bSmb#*gV;w[y\bUelY=g\u0010ev\u001f,\u0003\u001duj#";
      wb[340] = "%\u0010qHMq`RdI'{\u001cW2\\_$sTlG]`\u001c\u0011l]\u001bqx\u001c|A'";
      wb[341] = "`B\bU_a%\u0014\u001dU=;6T\u0005\u000fQ\tb\u0015[Y=#4XY\u0002Y.$De";
      wb[342] = "9G#<j\u000b6\u0007ju\u0004V?\u000b\u000f%`J4w?-8F<\u0007->5SY";
      wb[343] = "T\u001d3qo\u007fT\u0019!+dN\b\u001e.f\u0005,_C'!n3\u0015\u000fg\u001a";
      wb[344] = "K\u0010cp\u000er\r\u000bp<\u0015O\u001f\u0015|{\u0003\u0014\u001f\u000f\u00008\fq\u0016\u0019d<C+\u0018I\u0000";
      wb[345] = "\u0010\u001dJfH#S\u0013\u001b=X\u001eC-\u001fnYf\u0015B\u001c0BdQ-Y0X\"@IT D\u001e";
      wb[346] = "e)\fu\u0019Zu3Q$g\nx<Yfg_&m\u0001}[Qsj\n\u001c";
      wb[347] = "ep\u0010TRN(lO\u0001mXxm\u0015S:\u000f\"=K?\u0010Fa`\u0013\u0005\u0012J\u007f:";
      wb[348] = "\u001e`\nMs/N>\u0017\u001cJw\u0018|\u0007\u0017&EL8^Nw\u0012\u001ba[\u0001/b\trV\u0014J";
      wb[349] = ".%<\u0013\u0013zv{?[\u001f\u0007rszB\u001ak@$:\u001fD:\u0017tz\u0013\u0002}{/`[D\u0007";
      wb[350] = "d?\u0012Kf_z.\u0015\u0012\rU\u001ax^\u0005u\u0003u{\u0000\u001ewG\u001axSJjBu>\f\u00174E\u001a";
      wb[351] = "WD$ D-\u0012\u00061!.<n\u0003g4Vx\u0001\u00009/T<n\u0006ly\u001f&R\b9~\u0014G";
      wb[352] = "y]p~0S<\u001fe\u007fZH@\u001a3j\"\u0006/\u0019mq B@\u001f8'kX|\u0011m `9";
      wb[353] = "<ArO'uy\u0017gOE$fF{\u001e\u0012s9\u001b r|3fBc\u000f4:6\u001a'";
      wb[354] = "\t6O\u0011`\u0006R,\u0007W\u001a\u000f\u000e6\u001e\tv=ZrDP!j\r+B\u001f\u007f\u001a\u001f8O\n\u001a";
      wb[355] = "\u00134\"hzW\u0017q!t\"hG\r&>l\u0010\u0017b%`w\u0012S\r#5!YI1-`&R(";
      wb[356] = "f=2\"5\u0019ouc*ux6nt\u0012a\u0019cujbs\nn`\u000f|nD.a\u007fn}I;\u0004";
      wb[357] = "\u0018vH7\u007f.]4]6\u0015(!1\u000b#m{N2U8o?!wJ*u&\u001buF4/D";
      wb[358] = "\rvlx2aH4yyXm41/l 4[2qw\"p44$!ij\b:q&b\u000b";
      wb[359] = "%a\n\u000b\bc,)[\u0003H\u0002g9Q;Ord8U\u0001M~zb7FBz|:\rDNd&X";
      wb[360] = "=\u0010f)2>?\u00046z.Sy\t8e?\u0014i`e\"6ln\u0000#s#8f`fhhbg\rd|81{`";
      wb[361] = "6nJ_C?mt\u0002\u0019961n\u001bGU\u0004e*A\u001e\u0005S2sGQ\\# `JD9";
      wb[362] = "2Myn!`j\u0013z&-\u001de\u0017.;#J5LxbOsjJ2:?ayG'";
      wb[363] = ";~GY=9}eT\u0015&\u0004izBT(edfgE0\u0004`,\u0014Qzo\u007ffX\u0011Aymm\u0018B%t}q$";
      wb[364] = "cp&;\"h(w&taU?}<+89\r)xrgnZ~!w.0*l2z;U4q|::%&bq/_;;,1./)(!$Kf5<`=v-2</~K";
      wb[365] = "\f\u0007PL-\u0016IEEMG\u00005@\u0013X?CZCMC=\u00075E\u0018\u0015v\u001d\tKM\u0012}|";
      wb[366] = "V&(\u0019\\G\fvq\u001a\u001a#\u0006M(\u0012WZT&7X\u001b\u001ao";
      wb[367] = "z,P\u0011vl\"tT\b\u00146)a\n\u0006x\u0004y\"QP\u0014izq\b]n9-$\t\u001a\u0014j{l\u0012Qr!;g\u0015\u001e\u0014";
      wb[368] = "9E\u000fpW\u0007'\u0001\u001f=6\u0014Y\u0006C|NB6\u0005\u001dgL\u0006Y\u0003H1\u0007\u001ce\r\u001d6\f}";
      wb[369] = "\u0001\u0013WTTRZ\t\u001f\u0012.S\u0012\u0012\u000fOU>\t^VR\u0015U\u0016\u0014\u001a\u0012.C\u0004\u001fZAJN\u0014\u0003f";
      wb[370] = "o~5O\u0019p>d?ObkP9:\t\u001c`:bcM\u001e";
      wb[371] = "RBA;K\r\u001f^\u001ent\u001bO_D<#L\u0015\u000f\u001bP\b\u0005OY\u001f(E\u0019\u0010\f";
      wb[372] = "*H!,_\u001fo\n4-5\u0017\u0013\u000fb8MJ|\f<#O\u000e\u0013\niu\u0004\u0014/\u0004<r\u000fu";
      wb[373] = "\u000f$e^j\u0018[#a\u0019\u0014\u0012cb*\u0015lD\fat\u000en\u0000c7zXe\u001e\u0013%iUp{";
      wb[374] = "r$\u00125J\u0007:-Bm\u000ez.0\u000f<Q\u0016\u001cmHf\u000ez!!B#L\u0016z;\ne6C9-\u00123P\u0004:8\u000e96";
      wb[375] = "@;b\u0019\"/\u0005yw\u0018H.y|!\r0z\u0016\u007f\u007f\u00162>y)q@9 \t;bM,E";
      wb[376] = "o\u0006\t7\u0005,qB\u0019zd?\u000fEE;\u001ci`F\u001b \u001e-\u000f\u0003\u001b:X<k\u000e\u000b&d";
      wb[377] = "Rr>\u0012\u0005\u000f\u0001vbM\u0006v\u0001O;\u001a\u0019\u000eW 8D\u0002\f\u0013O9\u0010RG\u00062aNQ\u000f\nO";
      wb[378] = "j{m?#Z/9x>IIS<.+1\u000f<?p03KS9%fxQo7pas0";
      wb[379] = "FN\u000bA\u0007RC\u000f\u0013TO;\u0012\u0016\u0001@QlFLU\u0014\u0002;FM\u0010G\\\u0000\u001c\u0017\fU\u0006";
      wb[380] = "a?\u001a1/y$}\u000f0EzXxY%=,7{\u0007>?hX?\u00185., r\u0004j{\u0013";
      wb[381] = "4e\u0003y8zq'\u0016xRz\r\"@m*/b!\u001ev(k\r`\t ;n6p\u0013}j\u0010";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = wb[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(xb[var4]);
            wb[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = wb[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = xb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            wb[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  wb[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1955712878511445L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = wb[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = xb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  wb[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1955712878511445L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        wb[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1955712878511445L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 205;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 227;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 240;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 73;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 246;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 121;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 205;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 227;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 240;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d1",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoAnchor var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d1;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d1", "lambda$new$3", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoAnchor var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d1;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d1", "lambda$new$2", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoAnchor var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d1;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d1", "lambda$new$1", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoAnchor var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d1;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d1", "lambda$new$0", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static long invokeBinding5(int var0, long var1) {
         MethodHandle var7 = bindingCache5;
         MethodHandle var6 = bindingCache5;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache5 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Predicate invokeBinding7(AutoAnchor var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d1;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d1", "lambda$onTick$4", "(Ljava/util/Map$Entry;)Z"),
                  SourceSupport.methodType("(Ljava/util/Map$Entry;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Comparator invokeBinding8() {
         MethodHandle var4 = bindingCache8;
         MethodHandle var3 = bindingCache8;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "compare",
                  SourceSupport.methodType("()Ljava/util/Comparator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)I", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/d1",
                     "lambda$search$5",
                     "(Ldev/zprestige/prestige/gc_C0330;Ldev/zprestige/prestige/gc_C0330;)I"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gc_C0330;Ldev/zprestige/prestige/gc_C0330;)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Comparator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static long invokeBinding9(int var0, long var1) {
         MethodHandle var7 = bindingCache9;
         MethodHandle var6 = bindingCache9;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache9 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding11(int var0, long var1) {
         MethodHandle var7 = bindingCache11;
         MethodHandle var6 = bindingCache11;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache11 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding12(int var0, long var1) {
         MethodHandle var7 = bindingCache12;
         MethodHandle var6 = bindingCache12;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache12 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding13(int var0, long var1) {
         MethodHandle var7 = bindingCache13;
         MethodHandle var6 = bindingCache13;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache13 = d(MethodHandles.lookup(), "m", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
