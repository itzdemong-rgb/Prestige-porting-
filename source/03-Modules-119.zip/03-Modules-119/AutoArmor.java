package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.util.EquipmentSlotSwitchMap;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class AutoArmor extends Module {
   private ModeSetting a;
   private BindSetting f;
   private BooleanSetting d;
   private IntSetting c;
   private ElapsedTimer e;
   private static final EquipmentSlot[] g;
   private static final long k = 140083216759171L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[129];
   private static final String[] s = new String[129];

   public AutoArmor() {
      super();
      long var10001 = 45243875384843L ^ 79356880939298L;

      this.e = new ElapsedTimer(106698256430889L);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 121553612218119L ^ 102635364542788L;
      var10001 = 121553612218119L ^ 17657296734483L;
      var10001 = 121553612218119L ^ 79681093498631L;
      var10001 = 121553612218119L ^ 37592767152291L;
      int var12 = Event.cReturningInt();
      int var39 = var12;
      MinecraftClient var38 = b;
      MinecraftClient var35 = var38;
      MinecraftClient var34 = var38;
      if (var39 != 0) {
         MinecraftClient var17 = var34;
         ClientPlayerEntity var40 = var17.player;
         if (var40 == null) {
            return;
         }

         MinecraftClient var41 = b;
         var35 = var41;
      }

      MinecraftClient var20 = var35;
      ClientWorld var42 = var20.world;
      if (var42 != null) {
         ElapsedTimer var10000 = this.e;
         IntSetting var22 = this.c;
         Integer var23 = (Integer)var22.aReturningObject();
         float var57 = var23.intValue();
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var57;
         Object[] var25 = var10004;
         ElapsedTimer var24 = var10000;
         boolean var52 = var24.aReturningBoolean(var25);
         int var44 = var12;
         boolean var43 = var52;
         boolean var37 = var43;
         boolean var36 = var43;
         if (var44 != 0) {
            boolean var45 = var36;
            if (!var45) {
               return;
            }

            Object[] var28 = new Object[]{56993403467331L};
            AutoArmor var27 = this;
            var37 = var27.dReturningBoolean(var28);
         }

         boolean var46 = var37;
         if (var46) {
            EquipmentSlot[] var13 = g;
            int var14 = var13.length;
            int var51;
            do {
               int var48 = var14;
               int var47 = var15;
               if (var47 >= var48) {
                  break;
               }

               EquipmentSlot var16 = var13[var15];
               int var49 = var12;
               if (var49 != 0) {
                  Object[] var30 = new Object[]{var16, 84378263281572L};
                  AutoArmor var29 = this;
                  boolean var50 = var29.aReturningBoolean(var30);
                  if (var50) {
                     var10000 = this.e;
                     Object[] var33 = new Object[]{42835128969216L};
                     ElapsedTimer var32 = var10000;
                     var32.aReturningVoid(var33);
                     return;
                  }

                  var15++;
               }

               var51 = var12;
            } while (var51 != 0);
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      EquipmentSlot var2;
      long var5;
      long var7;
      long var9;
      long var11;
      long var13;
      int var15;
      ItemStack var16;
      boolean var78;
      long var171;
      label150: {
         ItemStack var77;
         label149: {
            var2 = (EquipmentSlot)var1[0];
            long var3 = (Long)var1[1];
            var171 = 140083216759171L ^ var3;
            var5 = var171 ^ 129968587328734L;
            var7 = var171 ^ 91851132162637L;
            var9 = var171 ^ 127842958519314L;
            var11 = var171 ^ 21867863676256L;
            var13 = var171 ^ 94677976881714L;
            int var10000 = Event.cReturningInt();
            MinecraftClient var23 = b;
            EquipmentSlot var25 = var2;
            ClientPlayerEntity var24 = var23.player;
            var16 = var24.getEquippedStack(var25);
            var15 = var10000;
            EquipmentSlot var109 = EquipmentSlot.CHEST;
            EquipmentSlot var108 = var2;
            if (var108 == var109) {
               ItemStack var26 = var16;
               boolean var173 = var26.isEmpty();
               int var111 = var15;
               boolean var110 = var173;
               var78 = var110;
               boolean var73 = var110;
               if (var111 == 0) {
                  break label150;
               }

               boolean var112 = var73;
               boolean var74 = var112;
               boolean var113 = var74;
               if (!var113) {
                  int var115 = var15;
                  ItemStack var114 = var16;
                  var77 = var114;
                  ItemStack var75 = var114;
                  if (var115 == 0) {
                     break label149;
                  }

                  ItemStack var116 = var75;
                  ItemStack var76 = var116;
                  ItemStack var30 = var76;
                  Item var174 = var30.getItem();
                  Item var118 = Items.ELYTRA;
                  Item var117 = var174;
                  if (var117 == var118) {
                     return false;
                  }
               }
            }

            var77 = var16;
         }

         ItemStack var33 = var77;
         var78 = var33.isEmpty();
      }

      int var85;
      label139: {
         ItemStack var84;
         label153: {
            boolean var83;
            int var120 = var15;
            boolean var119 = var78;
            var83 = var119;
            boolean var79 = var119;
            label137:
            if (var120 != 0) {
               boolean var121 = var79;
               if (!var121) {
                  Object[] var35 = new Object[]{var16, Enchantments.BINDING_CURSE, var9};
                  boolean var175 = eReturningBoolean(var35);
                  int var123 = var15;
                  boolean var122 = var175;
                  var83 = var122;
                  boolean var80 = var122;
                  if (var123 == 0) {
                     break label137;
                  }

                  boolean var124 = var80;
                  boolean var81 = var124;
                  boolean var125 = var81;
                  if (var125) {
                     return false;
                  }
               }

               int var127 = var15;
               ItemStack var126 = var16;
               var84 = var126;
               ItemStack var82 = var126;
               if (var127 == 0) {
                  break label153;
               }

               ItemStack var39 = var82;
               boolean var128 = var39.isEmpty();
               var83 = var128;
            }

            boolean var129 = var83;
            if (var129) {
               // var85 = var130;
               break label139;
            }

            var84 = var16;
         }

         Object[] var42 = new Object[]{var84, var5};
         var85 = cReturningInt(var42);
      }

      int var17 = var85;
      int var18 = -1;
      int var19 = var17;
      int var103;
      while (true) {
         short var10001 = 29356;
         long var10002 = 2936141289739447053L ^ var171;
         byte var132 = 36;
         int var131 = var20;
         if (var131 < var132) {
            label119: {
               label155: {
                  MinecraftClient var43 = b;
                  ClientPlayerEntity var44 = var43.player;
                  PlayerInventory var176 = var44.getInventory();
                  int var46 = var20;
                  PlayerInventory var45 = var176;
                  ItemStack var21 = var45.getStack(var46);
                  int var134 = var15;
                  ItemStack var133 = var21;
                  ItemStack var89 = var133;
                  ItemStack var86 = var133;
                  if (var134 != 0) {
                     ItemStack var47 = var86;
                     byte var177 = ((byte)((var47.isEmpty()) ? 1 : 0));
                     int var136 = var15;
                     byte var135 = var177;
                     var103 = var135;
                     byte var87 = var135;
                     if (var136 == 0) {
                        break;
                     }

                     byte var137 = var87;
                     byte var88 = var137;
                     byte var138 = var88;
                     if (var138 != 0) {
                        break label155;
                     }

                     var89 = var21;
                  }

                  ItemStack var50 = var89;
                  Object[] var51 = new Object[]{var50.getItem(), var11};
                  EquipmentSlot var178 = aReturningEquipmentSlot(var51);
                  int var140 = var15;
                  EquipmentSlot var139 = var178;
                  Object var91 = var139;
                  EquipmentSlot var90 = var139;
                  if (var140 != 0) {
                     EquipmentSlot var142 = var2;
                     EquipmentSlot var141 = var90;
                     if (var141 != var142) {
                        break label155;
                     }

                     BooleanSetting var54 = this.d;
                     var91 = var54.aReturningObject();
                  }

                  int var97;
                  Boolean var55 = (Boolean)var91;
                  byte var179 = ((byte)(((java.lang.Boolean)(var55)).booleanValue() ? 1 : 0));
                  int var144 = var15;
                  byte var143 = var179;
                  var97 = var143;
                  byte var92 = var143;
                  label106:
                  if (var144 != 0) {
                     byte var145 = var92;
                     if (var145 != 0) {
                        Object[] var57 = new Object[]{var21, Enchantments.BINDING_CURSE, var9};
                        byte var180 = ((byte)((eReturningBoolean(var57)) ? 1 : 0));
                        int var147 = var15;
                        byte var146 = var180;
                        byte var95 = var146;
                        byte var93 = var146;
                        if (var147 != 0) {
                           byte var148 = var93;
                           byte var94 = var148;
                           byte var149 = var94;
                           if (var149 != 0) {
                              break label155;
                           }

                           Object[] var60 = new Object[]{var21, Enchantments.VANISHING_CURSE, var9};
                           byte var150 = ((byte)((eReturningBoolean(var60)) ? 1 : 0));
                           var95 = var150;
                        }

                        int var152 = var15;
                        byte var151 = var95;
                        var97 = var151;
                        byte var96 = var151;
                        if (var152 == 0) {
                           break label106;
                        }

                        byte var153 = var96;
                        if (var153 != 0) {
                           break label155;
                        }
                     }

                     Object[] var63 = new Object[]{var21, var5};
                     var97 = cReturningInt(var63);
                  }

                  int var22 = var97;
                  int var154 = var15;
                  if (var154 == 0) {
                     break label119;
                  }

                  int var156 = var19;
                  int var155 = var22;
                  if (var155 > var156) {
                     int var102;
                     label91: {
                        var19 = var22;
                        var10001 = 5342;
                        var10002 = 94370806492892534L ^ var171;
                        int var159 = var15;
                        byte var158 = 9;
                        int var157 = var20;
                        int var100 = var157;
                        int var101 = var158;
                        int var98 = var157;
                        byte var99 = var158;
                        if (var159 != 0) {
                           byte var161 = var99;
                           int var160 = var98;
                           if (var160 >= var161) {
                              var102 = var20;
                              break label91;
                           }

                           short var181 = 26333;
                           long var183 = 8907898373300813690L ^ var171;
                           int var163 = var20;
                           byte var162 = 36;
                           var100 = var162;
                           var101 = var163;
                        }

                        int var164 = var100 + var101;
                        var102 = var164;
                     }

                     var18 = var102;
                  }
               }

               var20++;
            }

            int var165 = var15;
            if (var165 != 0) {
               continue;
            }
         }

         var103 = var18;
         break;
      }

      int var168 = var15;
      // int var166 = var103;
      int var106 = var166;
      byte var107 = var167;
      int var104 = var166;
      byte var105 = var167;
      if (var168 != 0) {
         byte var170 = var105;
         int var169 = var104;
         if (var169 == var170) {
            return false;
         }

         Object[] var69 = new Object[]{var2, var7};
         var20 = aReturningInt(var69);
         Object[] var10005 = new Object[]{null, null, SlotActionType.PICKUP, var13};
         var10005[1] = 0;
         var10005[0] = var18;
         Object[] var70 = var10005;
         InventoryUtil.eReturningBoolean(var70);
         var10005 = new Object[]{null, null, SlotActionType.PICKUP, var13};
         var10005[1] = 0;
         var10005[0] = var20;
         Object[] var71 = var10005;
         InventoryUtil.eReturningBoolean(var71);
         var107 = 0;
         var106 = var18;
      }

      Object[] var186 = new Object[]{null, null, SlotActionType.PICKUP, var13};
      var186[1] = Integer.valueOf(var107);
      var186[0] = var106;
      Object[] var72 = var186;
      InventoryUtil.eReturningBoolean(var72);
      return true;
   }

   private boolean dReturningBoolean(Object[] var1) {
      int var4;
      int var35;
      long var2 = (Long)var1[0];
      var2 = 140083216759171L ^ var2;
      int var10000 = Event.bReturningInt();
      ModeSetting var8 = this.a;
      String var5 = (String)var8.aReturningObject();
      var4 = var10000;
      // String var9 = var5;
      var10000 = var9.hashCode();
      int var44 = var4;
      int var43 = var10000;
      var35 = var43;
      int var30 = var43;
      label58:
      if (var44 == 0) {
         int var45 = var30;
         switch (var45) {
            case -16631492:
               short var10001 = 27571;
               long var10002 = 5041976959192329143L ^ var2;
               String var12 = "Inventory";
               String var11 = var5;
               byte var73 = ((byte)((var11.equals(var12)) ? 1 : 0));
               int var47 = var4;
               byte var46 = var73;
               var35 = var46;
               byte var31 = var46;
               if (var47 != 0) {
                  break label58;
               }

               byte var48 = var31;
               byte var32 = var48;
               byte var49 = var32;
               if (var49 == 0) {
                  break;
               }

               var6 = 0;
               int var50 = var4;
               if (var50 == 0) {
                  break;
               }
            case 849613564:
               short var77 = 24305;
               long var78 = 5548113202423586551L ^ var2;
               String var16 = "Keybind";
               String var15 = var5;
               byte var74 = ((byte)((var15.equals(var16)) ? 1 : 0));
               int var52 = var4;
               byte var51 = var74;
               var35 = var51;
               byte var33 = var51;
               if (var52 != 0) {
                  break label58;
               }

               byte var53 = var33;
               byte var34 = var53;
               byte var54 = var34;
               if (var54 != 0) {
                  var6 = 1;
               }
         }

         var35 = var6;
      }

      int var56 = var4;
      int var55 = var35;
      int var37 = var55;
      int var36 = var55;
      int var42;
      if (var56 == 0) {
         int var57 = var36;
         switch (var57) {
            case 0:
               MinecraftClient var20 = b;
               byte var58 = ((byte)((var20.currentScreen instanceof InventoryScreen) ? 1 : 0));
               var42 = var58;
               break;
            case 1:
               int var41;
               BindSetting var22 = this.f;
               Integer var23 = (Integer)var22.aReturningObject();
               int var7 = var23;
               int var61 = var4;
               int var60 = var7;
               var41 = var60;
               int var38 = var60;
               label41:
               if (var61 == 0) {
                  // int var62 = var38;
                  if (var62 != var63) {
                     MinecraftClient var25 = b;
                     Window var26 = var25.getWindow();
                     long var75 = var26.getHandle();
                     int var29 = var7;
                     long var27 = var75;
                     var10000 = GLFW.glfwGetKey(var27, var29);
                     int var65 = var4;
                     int var64 = var10000;
                     var41 = var64;
                     int var39 = var64;
                     if (var65 != 0) {
                        break label41;
                     }

                     int var66 = var39;
                     int var40 = var66;
                     byte var68 = 1;
                     int var67 = var40;
                     if (var67 == var68) {
                        byte var69 = 1;
                        var42 = var69;
                        break;
                     }
                  }

                  var41 = 0;
               }

               int var70 = var41;
               var42 = var70;
               break;
            default:
               var42 = 1;
         }
      } else {
         int var59 = var37;
         var42 = var59;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var42);
   }

   private static int aReturningInt(Object[] var0) {
      EquipmentSlot var3 = (EquipmentSlot)var0[0];
      long var1 = (Long)var0[1];
      var1 = 140083216759171L ^ var1;
      int var4 = Event.cReturningInt();
      EquipmentSlot var5 = var3;
      int var10000 = EquipmentSlotSwitchMap.a[var5.ordinal()];
      int var10 = var4;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      if (var10 != 0) {
         int var11 = var6;
         switch (var11) {
            case 1:
               var7 = 5;
               break;
            case 2:
               short var19 = 20697;
               long var21 = 5147446591160689330L ^ var1;
               return 6;
            case 3:
               short var18 = 25120;
               long var20 = 3579105648919842893L ^ var1;
               return 7;
            case 4:
               short var17 = 23937;
               long var10001 = 493181523671560161L ^ var1;
               return 8;
            default:
               return -1;
         }
      }

      return var7;
   }

   private static EquipmentSlot aReturningEquipmentSlot(Object[] var0) {
      Item var1 = (Item)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 140083216759171L ^ var2;
      int var4 = Event.bReturningInt();
      int var103 = var4;
      Item var102 = Items.NETHERITE_HELMET;
      Item var101 = var1;
      Item var7 = var101;
      Item var8 = var102;
      Item var5 = var101;
      Item var6 = var102;
      if (var103 == 0) {
         Item var105 = var6;
         Item var104 = var5;
         if (var104 == var105) {
            return EquipmentSlot.HEAD;
         }

         Item var107 = Items.DIAMOND_HELMET;
         Item var106 = var1;
         var7 = var106;
         var8 = var107;
      }

      int var110 = var4;
      Item var109 = var8;
      Item var108 = var7;
      Item var11 = var108;
      Item var12 = var109;
      Item var9 = var108;
      Item var10 = var109;
      if (var110 == 0) {
         Item var112 = var10;
         Item var111 = var9;
         if (var111 == var112) {
            return EquipmentSlot.HEAD;
         }

         Item var114 = Items.IRON_HELMET;
         Item var113 = var1;
         var11 = var113;
         var12 = var114;
      }

      int var117 = var4;
      Item var116 = var12;
      Item var115 = var11;
      Item var15 = var115;
      Item var16 = var116;
      Item var13 = var115;
      Item var14 = var116;
      if (var117 == 0) {
         Item var119 = var14;
         Item var118 = var13;
         if (var118 == var119) {
            return EquipmentSlot.HEAD;
         }

         Item var121 = Items.GOLDEN_HELMET;
         Item var120 = var1;
         var15 = var120;
         var16 = var121;
      }

      int var124 = var4;
      Item var123 = var16;
      Item var122 = var15;
      Item var19 = var122;
      Item var20 = var123;
      Item var17 = var122;
      Item var18 = var123;
      if (var124 == 0) {
         Item var126 = var18;
         Item var125 = var17;
         if (var125 == var126) {
            return EquipmentSlot.HEAD;
         }

         Item var128 = Items.CHAINMAIL_HELMET;
         Item var127 = var1;
         var19 = var127;
         var20 = var128;
      }

      int var131 = var4;
      Item var130 = var20;
      Item var129 = var19;
      Item var23 = var129;
      Item var24 = var130;
      Item var21 = var129;
      Item var22 = var130;
      if (var131 == 0) {
         Item var133 = var22;
         Item var132 = var21;
         if (var132 == var133) {
            return EquipmentSlot.HEAD;
         }

         Item var135 = Items.LEATHER_HELMET;
         Item var134 = var1;
         var23 = var134;
         var24 = var135;
      }

      int var138 = var4;
      Item var137 = var24;
      Item var136 = var23;
      Item var27 = var136;
      Item var28 = var137;
      Item var25 = var136;
      Item var26 = var137;
      if (var138 == 0) {
         Item var140 = var26;
         Item var139 = var25;
         if (var139 == var140) {
            return EquipmentSlot.HEAD;
         }

         Item var142 = Items.TURTLE_HELMET;
         Item var141 = var1;
         var27 = var141;
         var28 = var142;
      }

      int var145 = var4;
      Item var144 = var28;
      Item var143 = var27;
      Item var31 = var143;
      Item var32 = var144;
      Item var29 = var143;
      Item var30 = var144;
      if (var145 == 0) {
         Item var147 = var30;
         Item var146 = var29;
         if (var146 == var147) {
            return EquipmentSlot.HEAD;
         }

         var32 = Items.NETHERITE_CHESTPLATE;
         var31 = var1;
      }

      int var150 = var4;
      Item var149 = var32;
      Item var148 = var31;
      Item var35 = var148;
      Item var36 = var149;
      Item var33 = var148;
      Item var34 = var149;
      if (var150 == 0) {
         Item var152 = var34;
         Item var151 = var33;
         if (var151 == var152) {
            return EquipmentSlot.CHEST;
         }

         Item var154 = Items.DIAMOND_CHESTPLATE;
         Item var153 = var1;
         var35 = var153;
         var36 = var154;
      }

      int var157 = var4;
      Item var156 = var36;
      Item var155 = var35;
      Item var39 = var155;
      Item var40 = var156;
      Item var37 = var155;
      Item var38 = var156;
      if (var157 == 0) {
         Item var159 = var38;
         Item var158 = var37;
         if (var158 == var159) {
            return EquipmentSlot.CHEST;
         }

         Item var161 = Items.IRON_CHESTPLATE;
         Item var160 = var1;
         var39 = var160;
         var40 = var161;
      }

      int var164 = var4;
      Item var163 = var40;
      Item var162 = var39;
      Item var43 = var162;
      Item var44 = var163;
      Item var41 = var162;
      Item var42 = var163;
      if (var164 == 0) {
         Item var166 = var42;
         Item var165 = var41;
         if (var165 == var166) {
            return EquipmentSlot.CHEST;
         }

         Item var168 = Items.GOLDEN_CHESTPLATE;
         Item var167 = var1;
         var43 = var167;
         var44 = var168;
      }

      int var171 = var4;
      Item var170 = var44;
      Item var169 = var43;
      Item var47 = var169;
      Item var48 = var170;
      Item var45 = var169;
      Item var46 = var170;
      if (var171 == 0) {
         Item var173 = var46;
         Item var172 = var45;
         if (var172 == var173) {
            return EquipmentSlot.CHEST;
         }

         Item var175 = Items.CHAINMAIL_CHESTPLATE;
         Item var174 = var1;
         var47 = var174;
         var48 = var175;
      }

      int var178 = var4;
      Item var177 = var48;
      Item var176 = var47;
      Item var51 = var176;
      Item var52 = var177;
      Item var49 = var176;
      Item var50 = var177;
      if (var178 == 0) {
         Item var180 = var50;
         Item var179 = var49;
         if (var179 == var180) {
            return EquipmentSlot.CHEST;
         }

         Item var182 = Items.LEATHER_CHESTPLATE;
         Item var181 = var1;
         var51 = var181;
         var52 = var182;
      }

      int var185 = var4;
      Item var184 = var52;
      Item var183 = var51;
      Item var55 = var183;
      Item var56 = var184;
      Item var53 = var183;
      Item var54 = var184;
      if (var185 == 0) {
         Item var187 = var54;
         Item var186 = var53;
         if (var186 == var187) {
            return EquipmentSlot.CHEST;
         }

         var56 = Items.NETHERITE_LEGGINGS;
         var55 = var1;
      }

      int var190 = var4;
      Item var189 = var56;
      Item var188 = var55;
      Item var59 = var188;
      Item var60 = var189;
      Item var57 = var188;
      Item var58 = var189;
      if (var190 == 0) {
         Item var192 = var58;
         Item var191 = var57;
         if (var191 == var192) {
            return EquipmentSlot.LEGS;
         }

         Item var194 = Items.DIAMOND_LEGGINGS;
         Item var193 = var1;
         var59 = var193;
         var60 = var194;
      }

      int var197 = var4;
      Item var196 = var60;
      Item var195 = var59;
      Item var63 = var195;
      Item var64 = var196;
      Item var61 = var195;
      Item var62 = var196;
      if (var197 == 0) {
         Item var199 = var62;
         Item var198 = var61;
         if (var198 == var199) {
            return EquipmentSlot.LEGS;
         }

         Item var201 = Items.IRON_LEGGINGS;
         Item var200 = var1;
         var63 = var200;
         var64 = var201;
      }

      int var204 = var4;
      Item var203 = var64;
      Item var202 = var63;
      Item var67 = var202;
      Item var68 = var203;
      Item var65 = var202;
      Item var66 = var203;
      if (var204 == 0) {
         Item var206 = var66;
         Item var205 = var65;
         if (var205 == var206) {
            return EquipmentSlot.LEGS;
         }

         Item var208 = Items.GOLDEN_LEGGINGS;
         Item var207 = var1;
         var67 = var207;
         var68 = var208;
      }

      int var211 = var4;
      Item var210 = var68;
      Item var209 = var67;
      Item var71 = var209;
      Item var72 = var210;
      Item var69 = var209;
      Item var70 = var210;
      if (var211 == 0) {
         Item var213 = var70;
         Item var212 = var69;
         if (var212 == var213) {
            return EquipmentSlot.LEGS;
         }

         Item var215 = Items.CHAINMAIL_LEGGINGS;
         Item var214 = var1;
         var71 = var214;
         var72 = var215;
      }

      int var218 = var4;
      Item var217 = var72;
      Item var216 = var71;
      Item var75 = var216;
      Item var76 = var217;
      Item var73 = var216;
      Item var74 = var217;
      if (var218 == 0) {
         Item var220 = var74;
         Item var219 = var73;
         if (var219 == var220) {
            return EquipmentSlot.LEGS;
         }

         Item var222 = Items.LEATHER_LEGGINGS;
         Item var221 = var1;
         var75 = var221;
         var76 = var222;
      }

      int var225 = var4;
      Item var224 = var76;
      Item var223 = var75;
      Item var79 = var223;
      Item var80 = var224;
      Item var77 = var223;
      Item var78 = var224;
      if (var225 == 0) {
         Item var227 = var78;
         Item var226 = var77;
         if (var226 == var227) {
            return EquipmentSlot.LEGS;
         }

         var80 = Items.NETHERITE_BOOTS;
         var79 = var1;
      }

      int var230 = var4;
      Item var229 = var80;
      Item var228 = var79;
      Item var83 = var228;
      Item var84 = var229;
      Item var81 = var228;
      Item var82 = var229;
      if (var230 == 0) {
         Item var232 = var82;
         Item var231 = var81;
         if (var231 == var232) {
            return EquipmentSlot.FEET;
         }

         Item var234 = Items.DIAMOND_BOOTS;
         Item var233 = var1;
         var83 = var233;
         var84 = var234;
      }

      int var237 = var4;
      Item var236 = var84;
      Item var235 = var83;
      Item var87 = var235;
      Item var88 = var236;
      Item var85 = var235;
      Item var86 = var236;
      if (var237 == 0) {
         Item var239 = var86;
         Item var238 = var85;
         if (var238 == var239) {
            return EquipmentSlot.FEET;
         }

         Item var241 = Items.IRON_BOOTS;
         Item var240 = var1;
         var87 = var240;
         var88 = var241;
      }

      int var244 = var4;
      Item var243 = var88;
      Item var242 = var87;
      Item var91 = var242;
      Item var92 = var243;
      Item var89 = var242;
      Item var90 = var243;
      if (var244 == 0) {
         Item var246 = var90;
         Item var245 = var89;
         if (var245 == var246) {
            return EquipmentSlot.FEET;
         }

         Item var248 = Items.GOLDEN_BOOTS;
         Item var247 = var1;
         var91 = var247;
         var92 = var248;
      }

      int var251 = var4;
      Item var250 = var92;
      Item var249 = var91;
      Item var95 = var249;
      Item var96 = var250;
      Item var93 = var249;
      Item var94 = var250;
      if (var251 == 0) {
         Item var253 = var94;
         Item var252 = var93;
         if (var252 == var253) {
            return EquipmentSlot.FEET;
         }

         Item var255 = Items.CHAINMAIL_BOOTS;
         Item var254 = var1;
         var95 = var254;
         var96 = var255;
      }

      int var258 = var4;
      Item var257 = var96;
      Item var256 = var95;
      Item var99 = var256;
      Item var100 = var257;
      Item var97 = var256;
      Item var98 = var257;
      if (var258 == 0) {
         Item var260 = var98;
         Item var259 = var97;
         if (var259 == var260) {
            return EquipmentSlot.FEET;
         }

         Item var262 = Items.LEATHER_BOOTS;
         Item var261 = var1;
         var99 = var261;
         var100 = var262;
      }

      Item var264 = var100;
      Item var263 = var99;
      return var263 != var264 ? null : EquipmentSlot.FEET;
   }

   private static int cReturningInt(Object[] var0) {
      ItemStack var1 = (ItemStack)var0[0];
      long var2 = (Long)var0[1];
      var2 = 140083216759171L ^ var2;
      long var4 = var2 ^ 119091086542987L;
      long var6 = var2 ^ 59827555961644L;
      ItemStack var9 = var1;
      Object[] var10 = new Object[]{var9.getItem(), var4};
      int var10000 = dReturningInt(var10);
      short var10001 = 29005;
      long var10002 = 7080255711719103920L ^ var2;
      int var8 = var10000 * 100;
      Object[] var11 = new Object[]{var1, Enchantments.PROTECTION, var6};
      var8 += eReturningInt(var11) * 5;
      Object[] var12 = new Object[]{var1, Enchantments.BLAST_PROTECTION, var6};
      var8 += eReturningInt(var12) * 3;
      Object[] var13 = new Object[]{var1, Enchantments.PROJECTILE_PROTECTION, var6};
      var8 += eReturningInt(var13) * 3;
      Object[] var14 = new Object[]{var1, Enchantments.FIRE_PROTECTION, var6};
      var8 += eReturningInt(var14) * 2;
      Object[] var15 = new Object[]{var1, Enchantments.THORNS, var6};
      var8 += eReturningInt(var15) * 2;
      Object[] var16 = new Object[]{var1, Enchantments.MENDING, var6};
      var8 += eReturningInt(var16) * 3;
      Object[] var17 = new Object[]{var1, Enchantments.UNBREAKING, var6};
      var8 += eReturningInt(var17) * 1;
      Object[] var18 = new Object[]{var1, Enchantments.FEATHER_FALLING, var6};
      var8 += eReturningInt(var18) * 3;
      Object[] var19 = new Object[]{var1, Enchantments.DEPTH_STRIDER, var6};
      var8 += eReturningInt(var19) * 1;
      Object[] var20 = new Object[]{var1, Enchantments.SOUL_SPEED, var6};
      var8 += eReturningInt(var20) * 1;
      Object[] var21 = new Object[]{var1, Enchantments.AQUA_AFFINITY, var6};
      var8 += eReturningInt(var21) * 1;
      Object[] var22 = new Object[]{var1, Enchantments.RESPIRATION, var6};
      var8 += eReturningInt(var22) * 1;
      Object[] var23 = new Object[]{var1, Enchantments.SWIFT_SNEAK, var6};
      return var8 + eReturningInt(var23) * 2;
   }

   private static int dReturningInt(Object[] var0) {
      long var261;
      label223: {
         Item var1 = (Item)var0[0];
         var261 = (Long)var0[1];
         var261 = 140083216759171L ^ var261;
         int var4 = Event.cReturningInt();
         int var103 = var4;
         Item var102 = Items.NETHERITE_HELMET;
         Item var101 = var1;
         Item var7 = var101;
         Item var8 = var102;
         Item var5 = var101;
         Item var6 = var102;
         if (var103 != 0) {
            Item var105 = var6;
            Item var104 = var5;
            if (var104 == var105) {
               break label223;
            }

            Item var107 = Items.NETHERITE_CHESTPLATE;
            Item var106 = var1;
            var7 = var106;
            var8 = var107;
         }

         int var110 = var4;
         Item var109 = var8;
         Item var108 = var7;
         Item var11 = var108;
         Item var12 = var109;
         Item var9 = var108;
         Item var10 = var109;
         if (var110 != 0) {
            Item var112 = var10;
            Item var111 = var9;
            if (var111 == var112) {
               break label223;
            }

            Item var114 = Items.NETHERITE_LEGGINGS;
            Item var113 = var1;
            var11 = var113;
            var12 = var114;
         }

         int var117 = var4;
         Item var116 = var12;
         Item var115 = var11;
         Item var15 = var115;
         Item var16 = var116;
         Item var13 = var115;
         Item var14 = var116;
         if (var117 != 0) {
            Item var119 = var14;
            Item var118 = var13;
            if (var118 == var119) {
               break label223;
            }

            Item var121 = Items.NETHERITE_BOOTS;
            Item var120 = var1;
            var15 = var120;
            var16 = var121;
         }

         int var124 = var4;
         Item var123 = var16;
         Item var122 = var15;
         Item var19 = var122;
         Item var20 = var123;
         Item var17 = var122;
         Item var18 = var123;
         if (var124 != 0) {
            Item var126 = var18;
            Item var125 = var17;
            if (var125 == var126) {
               break label223;
            }

            var20 = Items.DIAMOND_HELMET;
            var19 = var1;
         }

         label224: {
            int var129 = var4;
            Item var128 = var20;
            Item var127 = var19;
            Item var23 = var127;
            Item var24 = var128;
            Item var21 = var127;
            Item var22 = var128;
            if (var129 != 0) {
               Item var131 = var22;
               Item var130 = var21;
               if (var130 == var131) {
                  break label224;
               }

               Item var133 = Items.DIAMOND_CHESTPLATE;
               Item var132 = var1;
               var23 = var132;
               var24 = var133;
            }

            int var136 = var4;
            Item var135 = var24;
            Item var134 = var23;
            Item var27 = var134;
            Item var28 = var135;
            Item var25 = var134;
            Item var26 = var135;
            if (var136 != 0) {
               Item var138 = var26;
               Item var137 = var25;
               if (var137 == var138) {
                  break label224;
               }

               Item var140 = Items.DIAMOND_LEGGINGS;
               Item var139 = var1;
               var27 = var139;
               var28 = var140;
            }

            int var143 = var4;
            Item var142 = var28;
            Item var141 = var27;
            Item var31 = var141;
            Item var32 = var142;
            Item var29 = var141;
            Item var30 = var142;
            if (var143 != 0) {
               Item var145 = var30;
               Item var144 = var29;
               if (var144 == var145) {
                  break label224;
               }

               Item var147 = Items.DIAMOND_BOOTS;
               Item var146 = var1;
               var31 = var146;
               var32 = var147;
            }

            int var150 = var4;
            Item var149 = var32;
            Item var148 = var31;
            Item var35 = var148;
            Item var36 = var149;
            Item var33 = var148;
            Item var34 = var149;
            if (var150 != 0) {
               Item var152 = var34;
               Item var151 = var33;
               if (var151 == var152) {
                  break label224;
               }

               var36 = Items.IRON_HELMET;
               var35 = var1;
            }

            label225: {
               int var155 = var4;
               Item var154 = var36;
               Item var153 = var35;
               Item var39 = var153;
               Item var40 = var154;
               Item var37 = var153;
               Item var38 = var154;
               if (var155 != 0) {
                  Item var157 = var38;
                  Item var156 = var37;
                  if (var156 == var157) {
                     break label225;
                  }

                  Item var159 = Items.IRON_CHESTPLATE;
                  Item var158 = var1;
                  var39 = var158;
                  var40 = var159;
               }

               int var162 = var4;
               Item var161 = var40;
               Item var160 = var39;
               Item var43 = var160;
               Item var44 = var161;
               Item var41 = var160;
               Item var42 = var161;
               if (var162 != 0) {
                  Item var164 = var42;
                  Item var163 = var41;
                  if (var163 == var164) {
                     break label225;
                  }

                  Item var166 = Items.IRON_LEGGINGS;
                  Item var165 = var1;
                  var43 = var165;
                  var44 = var166;
               }

               int var169 = var4;
               Item var168 = var44;
               Item var167 = var43;
               Item var47 = var167;
               Item var48 = var168;
               Item var45 = var167;
               Item var46 = var168;
               if (var169 != 0) {
                  Item var171 = var46;
                  Item var170 = var45;
                  if (var170 == var171) {
                     break label225;
                  }

                  Item var173 = Items.IRON_BOOTS;
                  Item var172 = var1;
                  var47 = var172;
                  var48 = var173;
               }

               int var176 = var4;
               Item var175 = var48;
               Item var174 = var47;
               Item var51 = var174;
               Item var52 = var175;
               Item var49 = var174;
               Item var50 = var175;
               if (var176 != 0) {
                  Item var178 = var50;
                  Item var177 = var49;
                  if (var177 == var178) {
                     break label225;
                  }

                  Item var180 = Items.TURTLE_HELMET;
                  Item var179 = var1;
                  var51 = var179;
                  var52 = var180;
               }

               int var183 = var4;
               Item var182 = var52;
               Item var181 = var51;
               Item var55 = var181;
               Item var56 = var182;
               Item var53 = var181;
               Item var54 = var182;
               if (var183 != 0) {
                  Item var185 = var54;
                  Item var184 = var53;
                  if (var184 == var185) {
                     break label225;
                  }

                  var56 = Items.CHAINMAIL_HELMET;
                  var55 = var1;
               }

               label226: {
                  int var188 = var4;
                  Item var187 = var56;
                  Item var186 = var55;
                  Item var59 = var186;
                  Item var60 = var187;
                  Item var57 = var186;
                  Item var58 = var187;
                  if (var188 != 0) {
                     Item var190 = var58;
                     Item var189 = var57;
                     if (var189 == var190) {
                        break label226;
                     }

                     Item var192 = Items.CHAINMAIL_CHESTPLATE;
                     Item var191 = var1;
                     var59 = var191;
                     var60 = var192;
                  }

                  int var195 = var4;
                  Item var194 = var60;
                  Item var193 = var59;
                  Item var63 = var193;
                  Item var64 = var194;
                  Item var61 = var193;
                  Item var62 = var194;
                  if (var195 != 0) {
                     Item var197 = var62;
                     Item var196 = var61;
                     if (var196 == var197) {
                        break label226;
                     }

                     Item var199 = Items.CHAINMAIL_LEGGINGS;
                     Item var198 = var1;
                     var63 = var198;
                     var64 = var199;
                  }

                  int var202 = var4;
                  Item var201 = var64;
                  Item var200 = var63;
                  Item var67 = var200;
                  Item var68 = var201;
                  Item var65 = var200;
                  Item var66 = var201;
                  if (var202 != 0) {
                     Item var204 = var66;
                     Item var203 = var65;
                     if (var203 == var204) {
                        break label226;
                     }

                     Item var206 = Items.CHAINMAIL_BOOTS;
                     Item var205 = var1;
                     var67 = var205;
                     var68 = var206;
                  }

                  int var209 = var4;
                  Item var208 = var68;
                  Item var207 = var67;
                  Item var71 = var207;
                  Item var72 = var208;
                  Item var69 = var207;
                  Item var70 = var208;
                  if (var209 != 0) {
                     Item var211 = var70;
                     Item var210 = var69;
                     if (var210 == var211) {
                        break label226;
                     }

                     var72 = Items.GOLDEN_HELMET;
                     var71 = var1;
                  }

                  label227: {
                     int var214 = var4;
                     Item var213 = var72;
                     Item var212 = var71;
                     Item var75 = var212;
                     Item var76 = var213;
                     Item var73 = var212;
                     Item var74 = var213;
                     if (var214 != 0) {
                        Item var216 = var74;
                        Item var215 = var73;
                        if (var215 == var216) {
                           break label227;
                        }

                        Item var218 = Items.GOLDEN_CHESTPLATE;
                        Item var217 = var1;
                        var75 = var217;
                        var76 = var218;
                     }

                     int var221 = var4;
                     Item var220 = var76;
                     Item var219 = var75;
                     Item var79 = var219;
                     Item var80 = var220;
                     Item var77 = var219;
                     Item var78 = var220;
                     if (var221 != 0) {
                        Item var223 = var78;
                        Item var222 = var77;
                        if (var222 == var223) {
                           break label227;
                        }

                        Item var225 = Items.GOLDEN_LEGGINGS;
                        Item var224 = var1;
                        var79 = var224;
                        var80 = var225;
                     }

                     int var228 = var4;
                     Item var227 = var80;
                     Item var226 = var79;
                     Item var83 = var226;
                     Item var84 = var227;
                     Item var81 = var226;
                     Item var82 = var227;
                     if (var228 != 0) {
                        Item var230 = var82;
                        Item var229 = var81;
                        if (var229 == var230) {
                           break label227;
                        }

                        Item var232 = Items.GOLDEN_BOOTS;
                        Item var231 = var1;
                        var83 = var231;
                        var84 = var232;
                     }

                     int var235 = var4;
                     Item var234 = var84;
                     Item var233 = var83;
                     Item var87 = var233;
                     Item var88 = var234;
                     Item var85 = var233;
                     Item var86 = var234;
                     if (var235 != 0) {
                        Item var237 = var86;
                        Item var236 = var85;
                        if (var236 == var237) {
                           break label227;
                        }

                        var88 = Items.LEATHER_HELMET;
                        var87 = var1;
                     }

                     label228: {
                        int var240 = var4;
                        Item var239 = var88;
                        Item var238 = var87;
                        Item var91 = var238;
                        Item var92 = var239;
                        Item var89 = var238;
                        Item var90 = var239;
                        if (var240 != 0) {
                           Item var242 = var90;
                           Item var241 = var89;
                           if (var241 == var242) {
                              break label228;
                           }

                           Item var244 = Items.LEATHER_CHESTPLATE;
                           Item var243 = var1;
                           var91 = var243;
                           var92 = var244;
                        }

                        int var247 = var4;
                        Item var246 = var92;
                        Item var245 = var91;
                        Item var95 = var245;
                        Item var96 = var246;
                        Item var93 = var245;
                        Item var94 = var246;
                        if (var247 != 0) {
                           Item var249 = var94;
                           Item var248 = var93;
                           if (var248 == var249) {
                              break label228;
                           }

                           Item var251 = Items.LEATHER_LEGGINGS;
                           Item var250 = var1;
                           var95 = var250;
                           var96 = var251;
                        }

                        int var254 = var4;
                        Item var253 = var96;
                        Item var252 = var95;
                        Item var99 = var252;
                        Item var100 = var253;
                        Item var97 = var252;
                        Item var98 = var253;
                        if (var254 != 0) {
                           Item var256 = var98;
                           Item var255 = var97;
                           if (var255 == var256) {
                              break label228;
                           }

                           Item var258 = Items.LEATHER_BOOTS;
                           Item var257 = var1;
                           var99 = var257;
                           var100 = var258;
                        }

                        Item var260 = var100;
                        Item var259 = var99;
                        if (var259 != var260) {
                           return 0;
                        }
                     }

                     short var10000 = 21279;
                     long var10001 = 4656720461390008040L ^ var261;
                     return 10;
                  }

                  short var262 = 23744;
                  long var267 = 652283914640408888L ^ var261;
                  return 15;
               }

               short var263 = 9486;
               long var268 = 1943769100880820468L ^ var261;
               return 20;
            }

            short var264 = 8749;
            long var269 = 2953929846799810516L ^ var261;
            return 30;
         }

         short var265 = 3345;
         long var270 = 4281649790402531552L ^ var261;
         return 50;
      }

      short var266 = 23845;
      long var271 = 2461654631720534230L ^ var261;
      return 60;
   }

   private static boolean eReturningBoolean(Object[] var0) {
      ItemStack var1 = (ItemStack)var0[0];
      RegistryKey var4 = (RegistryKey)var0[1];
      long var2 = (Long)var0[2];
      var2 = 140083216759171L ^ var2;
      long var5 = var2 ^ 57281331031008L;
      int var7 = Event.bReturningInt();
      Object[] var8 = new Object[]{var1, var4, var5};
      int var10000 = eReturningInt(var8);
      int var13 = var7;
      int var12 = var10000;
      int var10 = var12;
      int var9 = var12;
      if (var13 == 0) {
         int var14 = var9;
         if (var14 <= 0) {
            return false;
         }

         var10 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var10);
   }

   private static int eReturningInt(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      RegistryKey var4 = (RegistryKey)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 140083216759171L ^ var1;
      int var5 = Event.bReturningInt();
      int var30 = var5;
      ItemStack var29 = var3;
      ItemStack var23 = var29;
      ItemStack var22 = var29;
      if (var30 == 0) {
         ItemStack var8 = var22;
         boolean var31 = var8.isEmpty();
         if (var31) {
            return 0;
         }

         var23 = var3;
      }

      ItemStack var11 = var23;
      ItemEnchantmentsComponent var12 = var11.getEnchantments();
      Set var13 = var12.getEnchantmentEntries();
      Iterator var6 = var13.iterator();

      byte var28;
      while (true) {
         Iterator var14 = var6;
         boolean var32 = var14.hasNext();
         if (var32) {
            Iterator var15 = var6;
            Entry var7 = (Entry)var15.next();
            Entry var16 = var7;
            RegistryEntry var41 = (RegistryEntry)var16.getKey();
            RegistryKey var18 = var4;
            RegistryEntry var17 = var41;
            byte var42 = ((byte)((var17.matchesKey(var18)) ? 1 : 0));
            int var34 = var5;
            byte var33 = var42;
            var28 = var33;
            byte var24 = var33;
            if (var34 != 0) {
               break;
            }

            int var36 = var5;
            byte var35 = var24;
            int var27 = var35;
            byte var25 = var35;
            if (var36 != 0) {
               return var27;
            }

            byte var37 = var25;
            byte var26 = var37;
            byte var38 = var26;
            if (var38 != 0) {
               Entry var21 = var7;
               int var39 = var21.getIntValue();
               var27 = var39;
               return var27;
            }

            int var40 = var5;
            if (var40 == 0) {
               continue;
            }
         }

         var28 = 0;
         break;
      }

      return var28;
   }

   private boolean lambda$new$0(Integer var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Keybind";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(31503126503728L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[3];
      String var15 = "\u0000C\u0083\u0018û¶\u001bL\u009c\u0011k\u0006OõmIv\u009eí\u001cÐ ùÒ\u0010¦\u009c\u0098\u0084Dè\u0092\u009c\u0003\u008e\u0080ZøðÆ¥\u0010¨£ààøMs\u0010=ã_\u00019iv\u009f";
      int var17 = "\u0000C\u0083\u0018û¶\u001bL\u009c\u0011k\u0006OõmIv\u009eí\u001cÐ ùÒ\u0010¦\u009c\u0098\u0084Dè\u0092\u009c\u0003\u008e\u0080ZøðÆ¥\u0010¨£ààøMs\u0010=ã_\u00019iv\u009f"
         .length();
      char var14 = 24;
      int var13 = -1;

      while (true) {
         byte[] var19 = var11.doFinal(var15.substring(++var13, var13 + var14).getBytes("ISO-8859-1"));
         String var28 = b(var19).intern();
         int var10001 = -1;
         var18[var16++] = var28;
         if ((var13 += var14) >= var17) {
            l = var18;
            m = new String[3];
            q = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(31503126503728L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[13];
            String var4 = "}ô\u0087ö=>Oë¬t>Ð>Ä1µuqi_r\u0092\u009d\u007f O\u0083õ²\u0098\u008eä\u007f¡\u0089Ë_[ì\u0007(|À\u009f±G\u008b\u0095\u008bþóo³Û\u009dú@\"W®A¦a\u0016\u001b.\u0005d@uÀì\u00adñ\u0000nªMQô©8FBù!Âí";
            int var5 = "}ô\u0087ö=>Oë¬t>Ð>Ä1µuqi_r\u0092\u009d\u007f O\u0083õ²\u0098\u008eä\u007f¡\u0089Ë_[ì\u0007(|À\u009f±G\u008b\u0095\u008bþóo³Û\u009dú@\"W®A¦a\u0016\u001b.\u0005d@uÀì\u00adñ\u0000nªMQô©8FBù!Âí"
               .length();
            label32:
            while (true) {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               long[] var23 = var6;
               var10001 = var3++;
               long var31 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               // while (true) {
                  long var8 = var31;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var36 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var34) {
                     case 0:
                        var23[var10001] = var36;
                        if (var2 >= var5) {
                           o = var6;
                           p = new Integer[13];
                           g = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
                           break;
                        }
                        break;
                     default:
                        var23[var10001] = var36;
                        if (var2 < var5) {
                           continue label32;
                        }

                        var4 = "\u0087ój\u0015\u0000\u0002\"$:\u009a\u0086\u0090\u007f¼Ö\u0005";
                        var5 = "\u0087ój\u0015\u0000\u0002\"$:\u009a\u0086\u0090\u007f¼Ö\u0005".length();
                        var2 = 0;
                  }

                  int var27 = var2;
                  var2 += 8;
                  var7 = var4.substring(var27, var2).getBytes("ISO-8859-1");
                  var23 = var6;
                  var10001 = var3++;
                  var31 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var34 = 0;
               }
            }
         }

         var14 = var15.charAt(var13);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20420;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d2", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d2",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 32643;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d2", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d2",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 11;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 4;
            yield var18;
         }
         case 4 -> {
            byte var19 = 54;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 34;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 58;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 5;
            yield var26;
         }
         case 12 -> {
            byte var27 = 36;
            yield var27;
         }
         case 13 -> {
            byte var28 = 13;
            yield var28;
         }
         case 14 -> {
            byte var29 = 8;
            yield var29;
         }
         case 15 -> {
            byte var30 = 3;
            yield var30;
         }
         case 16 -> {
            byte var31 = 33;
            yield var31;
         }
         case 17 -> {
            byte var32 = 24;
            yield var32;
         }
         case 18 -> {
            byte var33 = 59;
            yield var33;
         }
         case 19 -> {
            byte var34 = 28;
            yield var34;
         }
         case 20 -> {
            byte var35 = 22;
            yield var35;
         }
         case 21 -> {
            byte var36 = 44;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 55;
            yield var38;
         }
         case 24 -> {
            byte var39 = 53;
            yield var39;
         }
         case 25 -> {
            byte var40 = 19;
            yield var40;
         }
         case 26 -> {
            byte var41 = 16;
            yield var41;
         }
         case 27 -> {
            byte var42 = 20;
            yield var42;
         }
         case 28 -> {
            byte var43 = 39;
            yield var43;
         }
         case 29 -> {
            byte var44 = 29;
            yield var44;
         }
         case 30 -> {
            byte var45 = 27;
            yield var45;
         }
         case 31 -> {
            byte var46 = 1;
            yield var46;
         }
         case 32 -> {
            byte var47 = 49;
            yield var47;
         }
         case 33 -> {
            byte var48 = 6;
            yield var48;
         }
         case 34 -> {
            byte var49 = 52;
            yield var49;
         }
         case 35 -> {
            byte var50 = 17;
            yield var50;
         }
         case 36 -> {
            byte var51 = 63;
            yield var51;
         }
         case 37 -> {
            byte var52 = 61;
            yield var52;
         }
         case 38 -> {
            byte var53 = 40;
            yield var53;
         }
         case 39 -> {
            byte var54 = 47;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 41;
            yield var59;
         }
         case 45 -> {
            byte var60 = 60;
            yield var60;
         }
         case 46 -> {
            byte var61 = 14;
            yield var61;
         }
         case 47 -> {
            byte var62 = 31;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 35;
            yield var64;
         }
         case 50 -> {
            byte var65 = 25;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 37;
            yield var67;
         }
         case 53 -> {
            byte var68 = 46;
            yield var68;
         }
         case 54 -> {
            byte var69 = 2;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 0;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 10;
            yield var73;
         }
         case 59 -> {
            byte var74 = 51;
            yield var74;
         }
         case 60 -> {
            byte var75 = 9;
            yield var75;
         }
         case 61 -> {
            byte var76 = 43;
            yield var76;
         }
         case 62 -> {
            byte var77 = 7;
            yield var77;
         }
         default -> 42;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "\nk\u000fNLk\u001ck\n\u0014_|\u000b \t\u0012Sh\u001ag\u001e\u0005\u0018z+";
      r[1] = int.class;
      s[1] = "java/lang/Integer";
      r[2] = "i$\u0019\u000f%\ri$\u000eS)\u0002so\u000eM)\u0017t\u001e\\\u0012xP";
      r[3] = "xX\u001c0\u0003\u0010xX\u000bl\u000f\u001fb\u0013\u000br\u000f\nebY&^K";
      r[4] = "%\u0001\u0011\u001f(T%\u0001\u0006C$[?J\u0006]$N8;T\u0006|\u000f";
      r[5] = "!S9\u007ftY7S<%gN \u0018?#kZ1_(4 Mw";
      r[6] = "V\u001eA\u0018\u0003\u0002]\u0011PW`\u000fH\u001c_<U\rY\u000fC\u0010B\u0000";
      r[7] = ".Y\u0016['G[y\u001dT6\b:w\u0016_2RN";
      r[8] = "wBvYOSwBa\u0005C\\m\ta\u001bCIjx3G\u0016\u000b";
      r[9] = long.class;
      s[9] = "java/lang/Long";
      r[10] = "\u0005A6\u0011\u001c.\u000eN'^a6\u001dI.\u0017";
      r[11] = "Oz/bj#Du>-\u000b-O~:w";
      r[12] = boolean.class;
      s[12] = "java/lang/Boolean";
      r[13] = ":7P# S:7G\u007f,\\ |Ga,I'\r\u0017<}";
      r[14] = "}\u001d|l{\"}\u001dk0w-gVk.w8`'<q!";
      r[15] = ".\u0018m\u0016{\u0001+\rf\u0016p\u001a'\u001d$\u007f[0\u0016";
      r[16] = "q`\b\u000e%\u0019g`\rT6\u000ep+\u000eR:\u001aal\u0019Eq\rS";
      r[17] = ">t\u0004e\u001185{\u0015*v: p\u0015aM";
      r[18] = "Zb.H\u0011#Zb9\u0014\u001d,@)9\n\u001d9GXcUL~";
      r[19] = "F!ssm+X)i<\u0010;X";
      r[20] = ",\u0015\u0016sNq,\u0015\u0001/B~6^\u00011Bk1/Sj\u001a!";
      r[21] = "\\lWQ\r\u0012BdM\u001ej\u0013S\u007f@DL\u0015";
      r[22] = "2~\u0010p&L2~\u0007,*C(5\u00072*V/DRfs\u0015";
      r[23] = "\u0001ag&Ep\u0001apzI\u007f\u001b*pdIj\u001c[&;\u001a(";
      r[24] = "T\u001dVC(rP\u0000VR5r\u0013\u000f\u0019E2nI\u0000\u0014\u0018)yW\f\u001bB55r\u000b\u0012S%o\u000f \u0016B\u000bzMM=X2iD";
      r[25] = "x?m8^vn?hbMaytkdAuh3|s\n`E";
      r[26] = "hH-n\u001a\u001c\u001dh&a\u000bS|f-j\u000f\t\b";
      r[27] = "8sR1\u0007\u001cMSY>\u0016S,]R5\u0012\tX";
      r[28] = "\u001eTB\u007fn \u001eTU#b/\u0004\u001fU=b:\u0003n\u0000b;";
      r[29] = "<0\u00170l;<0\u0000l`4&{\u0000r`!!\nT*7";
      r[30] = "\u001d\u000f]8\u0017Ph/V7\u0006\u001f\t!]<\u0002E}";
      r[31] = void.class;
      s[31] = "java/lang/Void";
      r[32] = "Y\u0012B,mm,2I#|\"M<B(xx9";
      r[33] = "b\u0002\u0017&\u0014#b\u0002\u0000z\u0018,xI\u0000d\u00189\u007f8R0@y";
      r[34] = "!{'\u0004d\u0019T[,\u000buV5U'\u0000q\fA";
      r[35] = "\u0013~\u0000m\u0012\ff^\u000bb\u0003C\u0007P\u0000i\u0007\u0019s";
      r[36] = "\u0012n\u001d,;*\u0012n\np7%\b%\nn70\u000fTX4`r";
      r[37] = "OboE\u0002\u0007Dm~\nn\u0004Jo|EB";
      r[38] = "8\u0019~dLbM9uk]-,7~`YwX";
      r[39] = "\u0000UWk!Iuu\\d0\u0006\u0014{Wo4\\`";
      r[40] = "\"~<\"uK4~9xf\\#5:~jH2r-i!X)";
      r[41] = "9'\tM#ML\u0007\u0002B2\u0002-\t\tI6XY";
      r[42] = "\b\u0018\"L=\u001f\b\u00185\u00101\u0010\u0012S5\u000e1\u0005\u0015\"gUaE";
      r[43] = "\u00189Q\u007f^\u0001m\u0019ZpON\f\u0017Q{K\u0014x";
      r[44] = "4\u0002\u0016\u0006?u?\u000e]\u0002[n\u000f\u000f\u0016\u000f6uv\u000e\u001a\u001d*\u0007r\u0017Y\u001c:>s\n\u001df";
      r[45] = "y|L^\u000byk$E\u000e6wwfO\u0005ZE!#\u0012^\u0006\u0012bxR\u0003\u000fh!tE\f6";
      r[46] = "1^R_n\u00191]F_Q\u0000gOTq6\fc4I^o\u001ao\rHC+`";
      r[47] = "*>g\n1W<`y\u0004R\b-3m\u0018\u0005Wuf0t=Zr'hN-\u001447";
      r[48] = "|ac;h=((q{S3'5~,\u0004c\u007ff+@id?#! =--c";
      r[49] = "r5D*x_ uE{\u0001O\"cC&V\u0018|3\u001aJ0]|2I+d\u001b9l";
      r[50] = "^?\u0004sS1\u0014=\u00074cb\u0005<\u0003e4<_n_\tYr\u00157\u0019f\\w\u0002=";
      r[51] = "\u0010b1\u007f\tJ\u001f*,jr^\u0010.+t\u001elBcu+r\u000b\u0016ksn\u000bF\u00197(\u0013";
      r[52] = " \u000b~\u0007|7j\t}@Ld{\by\u0011\u001b:'Z\"}vtk\u0003c\u0012sq|\t";
      r[53] = "\u000f|KR\u001dJE~H\u0015-\u0019T\u007fLDzG\t+\u0016(\u0017\tDtVG\u0012\fS~";
      r[54] = "u&\u0002\u0011A\bur\u001b\t8Vx6;\u0004\\JsJ\u0018\t\u0006M\u007fs\u0019\u0014B7";
      r[55] = ")L]\u0007j.}\u0005OGQ r\u0018@\u0010\u0006p*K\u001a|kwj\u000e\u001f\u001c?>xN";
      r[56] = "\u0012gZ>aYXeYyQ\nId](\u0006T\u00120\tDk\u001aYoG+n\u001fNe";
      r[57] = "`eqY3\fgmo\u0000K\n`ei8t\nix+Yq\u0016a$\u0015";
      r[58] = "Oh#0^4\u0005j wng\u0014k$&99H9xJTw\u0004`>%Qr\u0013j";
      r[59] = "8qzr4bl8h2\u000flc%geX<;w9\t5;{38iaris";
      r[60] = "\u0011p\u001e\u001e|}[r\u001dYL.Js\u0019\b\u001bz\u0011&GULzUo\u001b\u001a#\u007fPx\u0011";
      r[61] = "9t\u0018z2(/*\u0006tQw>y\u0012h\u0006(f,G\u0004>%am\u0017>.k'}";
      r[62] = "S\u0006'\u000bo@\u0019\u0004$L_\u0013\b\u0005 \u001d\bMSX\u007fqe\u0003\u0018\u000e:\u001e`\u0006\u000f\u0004";
      r[63] = "YO^\n+?\u0013M]M\u001bl\u0002LY\u001cL2]\u001e\rp!|\u0012GC\u001f$y\u0005M";
      r[64] = "\f!sPL\u001b^ar\u00015\u0000PfpWY2\u0007 .\u0000\u000ee\u0000|,]H\u000f[|(U5";
      r[65] = "WGW\u0007SO\u001dET@c\u001c\fDP\u00114BR\u0014\u000f}Y\f\u001cOJ\u0012\\\t\u000bE";
      r[66] = "Ir-=\u0010s\u0003p.z  \u0012q*+w~C#uG\u001a0\u0002z0(\u001f5\u0015p";
      r[67] = "_/9;'a_,-;\u0018u\u001986:c\u0018_#;3&yZ?3o\u0018(\u000b|g#ae\u0004 <^";
      r[68] = "\u000e\u001dc6(}\u0018C}8K\"\t\u0010i$\u001c}QD<H$pV\u0004lr4>\u0010\u0014";
      r[69] = ":\u0005<;j\rp\u0007?|Z^a\u0006;-\r\u0000>UgA`Nq\r!.eKf\u0007";
      r[70] = "&\u001ba8M00E\u007f6.o!\u0016k*y0yC0FA=~\u0002n|Qs8\u0012";
      r[71] = "8y\u007fp\u007fy0y!{\u000f{>z&ucIn9{)>\u001e?h;q}z==4.\u000f";
      r[72] = "\n\u0014i:\u001d\"\bAfeo'\u001a\u0017n0\u0013!\u001czy)\u000b'\u001e\u001a~!\u0015~f";
      r[73] = "C\u000bD\u0014U\u001a\t\tGSeI\u0018\bC\u00022\u001dC]\u001dQe\u001d\u0007\u0014A\u0010\n\u0018\u0002\u0003K";
      r[74] = "\u000euj\u0017C)My}\u0018z6\u001bkw\u0011\u0016\u0004K+,Fz.\u0012)m\u0017C/\u000fm\u0017\u001bJ)\u001alf\u0014\u00024\u000f\u0017";
      r[75] = "\r`w!\\Y_ vp%I]6p-r\u001e\u0002k+AGD]?r-[AC'";
      r[76] = "D\u0012^\u007f\u0015-Z\u0002Xqi-G\fBq\u0005\u001f\u0016H\u0018,THEL\u001co\brU\u0002Z\u007fixAI\u001ak\u00105N\u0015A\u0016";
      r[77] = "E\u001edLQOS@zB2\u0010B\u0013n^eO\u001aD;2]B\u001d\u0007k\bM\f[\u0017";
      r[78] = "<]pE\by7Q;Al`\u0007PpL\u0001y~Q|^\u001d\u000bzH?_\r2{U{%";
      r[79] = "a\u007foO.\u001d+}l\b\u001eN:|hYI\u0010c,<5$^*wrZ![=}";
      r[80] = "`XqIn\u0005i\u0007s\u0014\u0013\u0004\u001b\u001b|\u001e~\u001bb\u001ap\fbi+\f4On\u0010f\u0003h\u0014\u0013";
      r[81] = "|ou\t29(&gI\t><:m\u0014`=F+hLs8\u007f*u\b\t";
      r[82] = "J`QM*\u0018\u001c}M\\\u001b\fHdpYg=L|LR\u001b\u001eA&K^\"\u001f\\b1";
      r[83] = "\u0018>\u0001\u0011C)\u000e`\u001f\u001f v\u001f3\u000b\u0003w\"EfPV wB`\u0016\u000e\u001ag\f&\u0006";
      r[84] = "\u000bn\u001d3B>\u001d0\u0003=!a\fc\u0017!v>T7JMN3Sw\u0012w^}\u0015g";
      r[85] = "-xc=So.g4_\\\u00049nc%W=8s'_";
      r[86] = ">\u0000y\u00166P1Hd\u0003MD>Lc\u001d!vl\u0001;KM\u001b-Ae\u0004\"\u001e(Voz";
      r[87] = "\u0019\"jGAw\u000bzc\u0017|y\u00178i\u001c\u0010KD}0K|&C=r@\u001cr\n/2{\u0011,\u0000(r\n\u001ed\u001d=\t";
      r[88] = "\u0019veGmX\u000f({I\u000e\u0007\u001e{oUYXF,49aUAoj\u0003q\u001b\u0007\u007f";
      r[89] = "\fj\"rw\u000f\u000b|2v\t\u001b\u0001~3Pd\b&}=\u001f7D\u0018luxhL\u0017sLbmJ\u001fqucp\u000eem(!s\u0015\\l5e\t";
      r[90] = "2hH^U\n9d\u0003Z1\u0015\teHW\\\npdDE@xt}\u0007DPAu`C>";
      r[91] = "=v~H\tG>i)*\u0007,)`~P\r\u0015(}:*";
      r[92] = "X]J\u000bRaQ\u001cE\u000e>lF\u000bO\u001aW`\u007f\u0005O\nS\u0006\u0011\u0007\u0012OC\u007f\\\bN\u0014>";
      r[93] = "k\u0002=L\u001fz}\\#B|%l\u000f7^+z4Zn2\u0013w3\u001b2\b\u00039u\u000b";
      r[94] = "cG\u0013Yb/5H\u0011V\u001a\u007f\t\u001b\u0016Ww(h\u001e\n_+\u0016";
      r[95] = "\u00146<kd}\u0002h\"e\u0007\"\u0013;6yP}Jgl\u0015hpL/3/x>\n?";
      r[96] = "Z4R[\"h\u00106Q\u001c\u0012;\u00017UMEePd\u000b!(+\u0011<ON-.\u00066";
      r[97] = "\u001brOFH\u0001I2N\u00171\u0011K$HJfF\u0015s\u0010&R\u0019Iu\u0011M@A@%";
      r[98] = "(Zl96%/\u001d/yK!HX!l&:1Y-~:H-\u0019>8s6,F:4K";
      r[99] = "\u001aidv'BPkg1\u0017\u0011Ajc`@O\u001a7:\f-\u0001Qayc(\u0004Fk";
      r[100] = "\u001c,<\u0019&qV.?^\u0016\"G/;\u000fA|\u001d{dc,2W$!\f)7@.";
      r[101] = "\u001b!z,\u000e&Q#yk>u@\"}:i!\u001bw#f>!_>\u007f(Q$Z)u";
      r[102] = "\u001bvu\u0011x/QtvVH|@ur\u0007\u001f\"\u001a$&krlP~h\u0004wiGt";
      r[103] = "3z\u0018\u00040\u001b4r\u0006]H\u001b7q:\b8\u0007^:\u0017\\p\u0006'w\u0018\u0000+{";
      r[104] = "xjG\"f\u00132hDeV@#i@4\u0001\u001e}8\u001fXlP3bZ7iU$h";
      r[105] = ")C\u0013 \u00110cA\u0010g!cr@\u00146v=.\u0017KZ\u001bsbK\u000e5\u001evuA";
      r[106] = "(;7\u000f\u0017e>e)\u0001t:/6=\u001d#evjdq\u001bhp\"8K\u000b&62";
      r[107] = "\\_\u0015}\r4\u001aV\u0017&`&AR\bt7w\u001f\u000eT\u0018\u001c(YZ\u0001dZ![\u0001";
      r[108] = "\u0016\u001b\u0007\u0006A\nBR\u0015Fz\u0004MO\u001a\u0011-T\u0015\u001dB}@SUYE\u001d\u0014\u001aG\u0019";
      r[109] = "IMz;=WBA1?YLr@z24W\u000bAv (%H\u0005r bE\u001cL``Y";
      r[110] = "zVS;y\u0019!VW3\u0004\u0016*L\u000f1h${\f^n\u0004MwM\u0013oc\u0012\u007fB\fV";
      r[111] = "\u000fY\"W:)\b\u001ea\u0017G-o[o\u0002*6\u0016Zc\u00106D_L'S:=\u0012C{\bG";
      r[112] = "s>dSE\u000e9<g\u0014u](=cE\"\u0003yk<)OM86yFJH/<";
      r[113] = "s\u001c'\u001c\u001d*x\u0010l\u0018y1HQ9L\u001b !\u000f5@GXt\u0002f\u001e\u00011*\u000ejBy";
      r[114] = "&x=\u00155Olz>R\u0005\u001c}{:\u0003RB,.co?\fmp \u0000:\tzz";
      r[115] = "\u000f[r\u0015F\u0001\u0019\u0005l\u001b%^\bVx\u0007r\u0001P\u0002'kJ\fWB}QZB\u0011R";
      r[116] = "Q^B/#;\u001b\\Ah\u0013h\n]E9D6Q\u000e\u001eU)x\u001aV_:,}\r\\";
      r[117] = "'rt'\fq1,j)o. \u007f~58qy#%Y\u0000|\u007fk{c\u001029{";
      r[118] = "\u00000QK\\O\u000b<\u001aO8Q;=QBUOB<]PI=F%\u001eQY\u0004G8Z+";
      r[119] = "zi:?\u0005fqeq;a}Ad:6\ff8e6$\u0010\u0014qsrg\u001cm<|.<a";
      r[120] = "@Pj!<\u0013\nRif\f@\u001bSm7[\u0014@\u00062c\f\u0014\u0004Oo%c\u0011\u0001Xe";
      r[121] = "\u007ft\u001a\u000e)=5v\u0019I\u0019n$w\u001d\u0018N0}+At#~4|\u0007\u001b&{#v";
      r[122] = "d[\u001aT\u0013/oWQPw0_V\u001a]\u001a/&W\u0016O\u0006]oAR\f\n$\"N\u000eWw";
      r[123] = "\u001c\u0004d\u0017'\u0007\nZz\u0019DX\u001b\tn\u0005\u0013\u0007C^:i+\nD\u001dkS;D\u0002\r";
      r[124] = "~u0\u0018\bUuy{\u001clKEx0\u0011\u0001U<y<\u0003\u001d'uox@\u0011^8`$\u001bl";
      r[125] = "\u0003M\f<x\u0004UP\u0010-I\u0010\u0001I/#8\u007fSS\b#w\u001eVO\u0000\u007fI";
      r[126] = "W\nkp\u0010qXBvekeWFq{\u0007W\u0007\n/!T\u0000QE(~\u001bgYEvuk";
      r[127] = "ke*\u0002!\u007f};4\fB lh \u0010\u0015u=?~GB!1;=\u001dx1\u007f}-";
      r[128] = "\u001bU\u0001WutQW\u0002\u0010E'@V\u0006A\u0012y\u001a\n\\-\u007f7P]\u001cBz2GW";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(777481740108045L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(777481740108045L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(777481740108045L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 231;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 214;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 239;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 89;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 252;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 116;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 231;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 214;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 239;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d2",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
