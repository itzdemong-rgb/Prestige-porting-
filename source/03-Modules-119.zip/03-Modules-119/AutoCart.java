package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.KeyBindingAccessor;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.client.modules.state.AutoCartWeaponMode;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.client.modules.state.AutoCartState;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.lwjgl.glfw.GLFW;

public class AutoCart extends Module implements RotationSource {
   private IntSetting a;
   private IntSetting c;
   private IntSetting d;
   private IntSetting e;
   private BindSetting f;
   private IntSetting g;
   private BindSetting h;
   private MinMaxSetting i;
   private BooleanSetting j;
   private ModeSetting k;
   private BooleanSetting l;
   private BooleanSetting m;
   private FloatSetting n;
   private IntSetting o;
   private BooleanSetting p;
   private BooleanSetting q;
   private BooleanSetting r;
   private FloatSetting s;
   private BooleanSetting t;
   private ColorSetting u;
   private static final Item[] v;
   private static final Block[] w;
   private static final Set x;
   private AutoCartState y;
   private AutoCartWeaponMode z;
   private int A;
   private int B;
   private int C;
   private BlockPos D;
   private boolean E;
   private int F;
   private int G;
   private int H;
   private boolean I;
   private boolean J;
   private boolean K;
   private boolean L;
   private int M;
   private boolean N;
   private ElapsedTimer O;
   private int P;
   private boolean Q;
   private BlockPos R;
   private boolean S;
   private TntMinecartEntity T;
   private boolean U;
   private Rotation V;
   private boolean W;
   private int X;
   private static final long Y = 106857869378349L;
   private static final String[] Z;
   private static final String[] ab;
   private static final Map bb = new HashMap(13);
   private static final long[] hb;
   private static final Integer[] ib;
   private static final Map jb;
   private static final Object[] kb = new Object[322];
   private static final String[] lb = new String[322];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;

   public AutoCart() {
      super();
      long var10001 = 33541126676007L ^ 140239160797454L;
      var10001 = 33541126676007L ^ 65134909873511L;
      var10001 = 33541126676007L ^ 135700191512392L;
      var10001 = 33541126676007L ^ 2163392802032L;
      var10001 = 33541126676007L ^ 62705491486149L;
      var10001 = 33541126676007L ^ 72588760577686L;
      var10001 = 33541126676007L ^ 86037563544971L;

      this.y = AutoCartState.IDLE;
      this.z = AutoCartWeaponMode.PASSIVE;
      this.F = -1;
      this.G = 0;
      this.H = 0;
      this.I = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.J = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.K = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.L = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.M = 0;
      this.N = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.O = new ElapsedTimer(106698256430889L);
      this.P = 0;
      this.Q = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.R = null;
      this.S = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.U = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.W = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.X = -1;
      BindSetting var10000 = this.h;
      Object[] var18 = new Object[]{invokeBinding1(this), 101728543910065L};
      BindSetting var17 = var10000;
      var17.aReturningBindSetting(var18);
      BooleanSetting var35 = this.j;
      Object[] var20 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var19 = var35;
      var19.aReturningBooleanSetting(var20);
      MinMaxSetting var36 = this.i;
      Object[] var22 = new Object[]{invokeBinding3(this), 112057026795887L};
      MinMaxSetting var21 = var36;
      var21.aReturningMinMaxSetting(var22);
      BooleanSetting var37 = this.r;
      Object[] var24 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var23 = var37;
      var23.aReturningBooleanSetting(var24);
      FloatSetting var38 = this.s;
      Object[] var26 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var25 = var38;
      var25.aReturningFloatSetting(var26);
      BooleanSetting var39 = this.t;
      Object[] var28 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var27 = var39;
      var27.aReturningBooleanSetting(var28);
      FloatSetting var40 = this.n;
      Object[] var30 = new Object[]{invokeBinding7(this), 34595201528535L};
      FloatSetting var29 = var40;
      var29.aReturningFloatSetting(var30);
      IntSetting var41 = this.o;
      Object[] var32 = new Object[]{invokeBinding8(this), 43459238656994L};
      IntSetting var31 = var41;
      var31.aReturningIntSetting(var32);
      ColorSetting var42 = this.u;
      Object[] var34 = new Object[]{invokeBinding9(this), 41489415177024L};
      ColorSetting var33 = var42;
      var33.aReturningColorSetting(var34);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   private boolean aReturningBoolean(Object[] var1) {
      Item var2 = (Item)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 106857869378349L ^ var3;
      Item[] var6 = v;
      int var16 = Event.bReturningInt();
      int var7 = var6.length;
      int var5 = var16;

      int var15;
      do {
         int var11 = var7;
         int var10 = var8;
         if (var10 >= var11) {
            break;
         }

         Item var9 = var6[var8];
         int var12 = var5;
         if (var12 == 0) {
            Item var14 = var9;
            Item var13 = var2;
            if (var13 == var14) {
               return true;
            }

            var8++;
         }

         var15 = var5;
      } while (var15 == 0);

      return false;
   }

   private boolean dReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 106857869378349L ^ var3;
      MinecraftClient var11 = b;
      BlockPos var13 = var2;
      ClientWorld var12 = var11.world;
      BlockState var14 = var12.getBlockState(var13);
      Block var6 = var14.getBlock();
      int var21 = Event.cReturningInt();
      Block[] var7 = w;
      int var5 = var21;
      int var8 = var7.length;
      int var20;
      do {
         int var16 = var8;
         int var15 = var9;
         if (var15 >= var16) {
            break;
         }

         Block var10 = var7[var9];
         int var17 = var5;
         if (var17 != 0) {
            Block var19 = var10;
            Block var18 = var6;
            if (var18 == var19) {
               return true;
            }

            var9++;
         }

         var20 = var5;
      } while (var20 != 0);

      return false;
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      long var4 = var2 ^ 643279104220L;
      int var10000 = Event.cReturningInt();
      int var6 = var10000;

      byte var19;
      while (true) {
         short var10001 = 22086;
         long var10002 = 2870710599056911213L ^ var2;
         byte var21 = 9;
         int var20 = var7;
         if (var20 < var21) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var31 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var31;
            ItemStack var12 = var10.getStack(var11);
            Object[] var14 = new Object[]{var12.getItem(), var4};
            AutoCart var13 = this;
            byte var30 = ((byte)((var13.aReturningBoolean(var14)) ? 1 : 0));
            int var23 = var6;
            byte var22 = var30;
            var19 = var22;
            byte var15 = var22;
            if (var23 == 0) {
               break;
            }

            int var25 = var6;
            byte var24 = var15;
            int var18 = var24;
            byte var16 = var24;
            if (var25 == 0) {
               return var18;
            }

            byte var26 = var16;
            byte var17 = var26;
            byte var27 = var17;
            if (var27 != 0) {
               var18 = var7;
               return var18;
            }

            var7++;
            int var28 = var6;
            if (var28 != 0) {
               continue;
            }
         }

         var19 = -1;
         break;
      }

      return var19;
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      byte var16;
      while (true) {
         short var10001 = 22086;
         long var10002 = 2870671824329953642L ^ var2;
         byte var18 = 9;
         int var17 = var5;
         if (var17 < var18) {
            MinecraftClient var7 = b;
            ClientPlayerEntity var8 = var7.player;
            PlayerInventory var26 = var8.getInventory();
            int var10 = var5;
            PlayerInventory var9 = var26;
            ItemStack var6 = var9.getStack(var10);
            int var19 = var4;
            if (var19 == 0) {
               Set var27 = x;
               ItemStack var11 = var6;
               Item var13 = var11.getItem();
               Set var12 = var27;
               byte var28 = ((byte)((var12.contains(var13)) ? 1 : 0));
               int var21 = var4;
               byte var20 = var28;
               var16 = var20;
               byte var14 = var20;
               if (var21 != 0) {
                  break;
               }

               byte var22 = var14;
               byte var15 = var22;
               byte var23 = var15;
               if (var23 != 0) {
                  return var5;
               }

               var5++;
            }

            int var24 = var4;
            if (var24 == 0) {
               continue;
            }
         }

         var16 = -1;
         break;
      }

      return var16;
   }

   private Integer aReturningBoxedInteger(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      long var4 = var2 ^ 112615681378488L;
      long var6 = var2 ^ 24660900815656L;
      long var8 = var2 ^ 120801285730209L;
      long var10 = var2 ^ 77009510762675L;
      int var10000 = Event.bReturningInt();
      Object[] var18 = new Object[]{Items.TNT_MINECART, var6};
      Integer var13 = InventoryUtil.aReturningBoxedInteger(var18);
      int var12 = var10000;
      int var81 = var12;
      Integer var80 = var13;
      Integer var54 = var80;
      Integer var53 = var80;
      if (var81 == 0) {
         Integer var82 = var53;
         if (var82 == null) {
            int var14 = -1;
            short var131 = 22086;
            long var10001 = 2870690328139657578L ^ var2;
            int var15 = 9;

            int var56;
            label129: {
               while (true) {
                  short var136 = 26544;
                  long var10002 = 1815872609615233178L ^ var2;
                  byte var85 = 36;
                  int var84 = var15;
                  label126:
                  if (var84 < var85) {
                     int var86 = var12;
                     if (var86 != 0) {
                        break;
                     }

                     MinecraftClient var21 = b;
                     ClientPlayerEntity var22 = var21.player;
                     PlayerInventory var132 = var22.getInventory();
                     int var24 = var15;
                     PlayerInventory var23 = var132;
                     ItemStack var25 = var23.getStack(var24);
                     Item var133 = var25.getItem();
                     Item var88 = Items.TNT_MINECART;
                     Item var87 = var133;
                     if (var87 == var88) {
                        var14 = var15;
                        int var89 = var12;
                        if (var89 == 0) {
                           break label126;
                        }
                     }

                     var15++;
                     int var90 = var12;
                     if (var90 == 0) {
                        continue;
                     }
                  }

                  int var92 = var12;
                  int var91 = var14;
                  var56 = var91;
                  int var55 = var91;
                  if (var92 != 0) {
                     break label129;
                  }

                  
                  if (var93 == var94) {
                     return null;
                  }

                  Object[] var30 = new Object[]{var8};
                  var15 = InventoryUtil.aReturningInt(var30);
                  break;
               }

               var56 = -1;
            }

            int var16 = var56;
            int var65;
            int var66;
            while (true) {
               short var137 = 22086;
               long var138 = 2870690328139657578L ^ var2;
               byte var96 = 9;
               int var95 = var17;
               label110:
               if (var95 < var96) {
                  label139: {
                     int var98 = var12;
                     int var97 = var17;
                     int var62 = var97;
                     int var57 = var97;
                     if (var98 == 0) {
                        int var101 = var12;
                        int var100 = var15;
                        int var99 = var57;
                        var65 = var99;
                        var66 = var100;
                        int var58 = var99;
                        int var59 = var100;
                        if (var101 != 0) {
                           break;
                        }

                        int var103 = var59;
                        int var102 = var58;
                        int var60 = var102;
                        int var61 = var103;
                        int var105 = var61;
                        int var104 = var60;
                        if (var104 == var105) {
                           break label139;
                        }

                        MinecraftClient var33 = b;
                        ClientPlayerEntity var34 = var33.player;
                        PlayerInventory var134 = var34.getInventory();
                        int var36 = var17;
                        PlayerInventory var35 = var134;
                        ItemStack var37 = var35.getStack(var36);
                        var62 = (((var37.isEmpty()) ? 1 : 0));
                     }

                     int var107 = var12;
                     int var106 = var62;
                     int var64 = var106;
                     int var63 = var106;
                     if (var107 == 0) {
                        int var108 = var63;
                        if (var108 == 0) {
                           break label139;
                        }

                        var64 = var17;
                     }

                     var16 = var64;
                     int var109 = var12;
                     if (var109 == 0) {
                        break label110;
                     }
                  }

                  var17++;
                  int var110 = var12;
                  if (var110 == 0) {
                     continue;
                  }
               }

               var66 = -1;
               var65 = var16;
               break;
            }

            int var113 = var12;
            int var112 = var66;
            int var111 = var65;
            int var69 = var111;
            int var70 = var112;
            int var67 = var111;
            int var68 = var112;
            if (var113 == 0) {
               int var115 = var68;
               int var114 = var67;
               if (var114 == var115) {
                  return null;
               }

               var70 = -1;
               var69 = this.X;
            }

            int var77;
            label146: {
               int var78;
               int var79;
               int var118 = var12;
               int var117 = var70;
               int var116 = var69;
               var78 = var116;
               var79 = var117;
               int var71 = var116;
               int var72 = var117;
               label71:
               if (var118 == 0) {
                  label147: {
                     int var120 = var72;
                     int var119 = var71;
                     if (var119 != var120) {
                        label143: {
                           int var122 = var12;
                           PacketQueueManager var121 = Prestige.u;
                           PacketQueueManager var75 = var121;
                           PacketQueueManager var73 = var121;
                           if (var122 == 0) {
                              PacketQueueManager var123 = var73;
                              PacketQueueManager var74 = var123;
                              PacketQueueManager var124 = var74;
                              if (var124 == null) {
                                 break label143;
                              }

                              var75 = Prestige.u;
                           }

                           Object[] var46 = new Object[]{var4};
                           PacketQueueManager var45 = var75;
                           byte var135 = ((byte)((var45.aReturningBoolean(var46)) ? 1 : 0));
                           int var126 = var12;
                           byte var125 = var135;
                           var77 = var125;
                           byte var76 = var125;
                           if (var126 != 0) {
                              break label146;
                           }

                           byte var127 = var76;
                           if (var127 != 0) {
                              break label147;
                           }
                        }

                        this.X = -1;
                        int var128 = var12;
                        if (var128 != 0) {
                           break label147;
                        }
                     }

                     var79 = var16;
                     var78 = var14;
                     break label71;
                  }

                  int var129 = this.X;
                  var77 = var129;
                  break label146;
               }

               Object[] var10004 = new Object[]{null, null, var10};
               var10004[1] = var79;
               var10004[0] = var78;
               Object[] var51 = var10004;
               InventoryUtil.fReturningBoolean(var51);
               this.X = var16;
               int var52 = var16;
               return var52;
            }

            int var50 = var77;
            return var50;
         }

         this.X = -1;
         Integer var83 = var13;
         var54 = var83;
      }

      return var54;
   }

   private int fReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      int var25;
      do {
         short var10001 = 4789;
         long var10002 = 5096547233951800277L ^ var2;
         byte var19 = 9;
         int var18 = var5;
         if (var18 >= var19) {
            break;
         }

         label23: {
            MinecraftClient var7 = b;
            ClientPlayerEntity var8 = var7.player;
            PlayerInventory var27 = var8.getInventory();
            int var10 = var5;
            PlayerInventory var9 = var27;
            ItemStack var6 = var9.getStack(var10);
            ItemStack var11 = var6;
            Item var28 = var11.getItem();
            int var21 = var4;
            Item var20 = var28;
            Object var17 = var20;
            Item var16 = var20;
            if (var21 == 0) {
               Item var23 = Items.CROSSBOW;
               Item var22 = var16;
               if (var22 != var23) {
                  break label23;
               }

               ComponentType var15 = DataComponentTypes.CHARGED_PROJECTILES;
               ItemStack var14 = var6;
               var17 = var14.get(var15);
            }

            Object var24 = var17;
            if (var24 != null) {
               return var5;
            }
         }

         var5++;
         var25 = var4;
      } while (var25 == 0);

      return -1;
   }

   private boolean eReturningBoolean(Object[] var1) {
      ItemStack var4 = (ItemStack)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 106857869378349L ^ var2;
      int var5 = Event.cReturningInt();
      ItemStack var6 = var4;
      Item var20 = var6.getItem();
      int var14 = var5;
      Item var13 = var20;
      Object var11 = var13;
      Item var10 = var13;
      if (var14 != 0) {
         Item var16 = Items.CROSSBOW;
         Item var15 = var10;
         if (var15 != var16) {
            return false;
         }

         ComponentType var9 = DataComponentTypes.CHARGED_PROJECTILES;
         ItemStack var8 = var4;
         Object var17 = var8.get(var9);
         var11 = var17;
      }

      Object var18 = var11;
      return var18 != null;
   }

   private void jReturningVoid(Object[] var1) {
      this.y = AutoCartState.IDLE;
      this.z = AutoCartWeaponMode.PASSIVE;
      this.F = -1;
      this.G = 0;
      this.H = 0;
      this.I = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.D = null;
      this.E = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.V = null;
      this.L = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.M = 0;
      this.N = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.P = 0;
      this.Q = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.R = null;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var4;
      long var6;
      int var8;
      AutoCart var40;
      int var41;
      label49: {
         AutoCart var37;
         int var38;
         label48: {
            AutoCart var39;
            label52: {
               long var2 = (Long)var1[0];
               var4 = var2 ^ 76771855182675L;
               var6 = var2 ^ 38266410274184L;
               int var10000 = Event.cReturningInt();
               Object[] var10 = new Object[0];
               AutoCart var9 = this;
               var9.jReturningVoid(var10);
               var8 = var10000;
               BindSetting var11 = this.f;
               Integer var12 = (Integer)var11.aReturningObject();
               int var10001 = var12;
               int var59 = var8;
               int var58 = var10001;
               AutoCart var57 = this;
               AutoCart var31 = var57;
               int var32 = var58;
               AutoCart var27 = var57;
               int var28 = var58;
               if (var59 != 0) {
                  
                  AutoCart var60 = var27;
                  var39 = var60;
                  AutoCart var29 = var60;
                  if (var61 == var62) {
                     break label52;
                  }

                  AutoCart var63 = var29;
                  AutoCart var30 = var63;
                  BindSetting var92 = this.f;
                  Object[] var15 = new Object[]{var4};
                  BindSetting var14 = var92;
                  byte var65 = ((byte)((var14.cReturningBoolean(var15)) ? 1 : 0));
                  AutoCart var64 = var30;
                  var31 = var64;
                  var32 = var65;
               }

               int var68 = var8;
               int var67 = var32;
               AutoCart var66 = var31;
               var37 = var66;
               var38 = var67;
               AutoCart var33 = var66;
               int var34 = var67;
               if (var68 == 0) {
                  break label48;
               }

               int var70 = var34;
               AutoCart var69 = var33;
               var39 = var69;
               AutoCart var35 = var69;
               if (var70 != 0) {
                  AutoCart var71 = var35;
                  AutoCart var36 = var71;
                  var38 = 1;
                  var37 = var36;
                  break label48;
               }
            }

            var41 = 0;
            var40 = var39;
            break label49;
         }

         int var73 = var38;
         AutoCart var72 = var37;
         var40 = var72;
         var41 = var73;
      }

      AutoCart var55;
      int var56;
      label36: {
         AutoCart var52;
         int var53;
         label35: {
            AutoCart var54;
            label53: {
               var40.J = dev.prestige.recovery.SourceSupport.asBoolean(var41);
               BindSetting var18 = this.h;
               Integer var19 = (Integer)var18.aReturningObject();
               int var93 = var19;
               int var76 = var8;
               int var75 = var93;
               AutoCart var74 = this;
               AutoCart var46 = var74;
               int var47 = var75;
               AutoCart var42 = var74;
               int var43 = var75;
               if (var76 != 0) {
                  
                  AutoCart var77 = var42;
                  var54 = var77;
                  AutoCart var44 = var77;
                  if (var78 == var79) {
                     break label53;
                  }

                  AutoCart var80 = var44;
                  AutoCart var45 = var80;
                  BindSetting var94 = this.h;
                  Object[] var22 = new Object[]{var4};
                  BindSetting var21 = var94;
                  byte var82 = ((byte)((var21.cReturningBoolean(var22)) ? 1 : 0));
                  AutoCart var81 = var45;
                  var46 = var81;
                  var47 = var82;
               }

               int var85 = var8;
               int var84 = var47;
               AutoCart var83 = var46;
               var52 = var83;
               var53 = var84;
               AutoCart var48 = var83;
               int var49 = var84;
               if (var85 == 0) {
                  break label35;
               }

               int var87 = var49;
               AutoCart var86 = var48;
               var54 = var86;
               AutoCart var50 = var86;
               if (var87 != 0) {
                  AutoCart var88 = var50;
                  AutoCart var51 = var88;
                  var53 = 1;
                  var52 = var51;
                  break label35;
               }
            }

            var56 = 0;
            var55 = var54;
            break label36;
         }

         int var90 = var53;
         AutoCart var89 = var52;
         var55 = var89;
         var56 = var90;
      }

      var55.K = dev.prestige.recovery.SourceSupport.asBoolean(var56);
      this.T = null;
      this.U = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.S = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.W = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var91 = Prestige.o;
      Object[] var26 = new Object[]{this, var6};
      RotationManager var25 = var91;
      var25.dReturningVoid(var26);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 54423664449695L;
      long var6 = var2 ^ 64097829662901L;
      Object[] var9 = new Object[]{var4};
      AutoCart var8 = this;
      var8.kReturningVoid(var9);
      Object[] var11 = new Object[0];
      AutoCart var10 = this;
      var10.jReturningVoid(var11);
      this.T = null;
      this.U = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var10000 = Prestige.o;
      Object[] var13 = new Object[]{this, var6};
      RotationManager var12 = var10000;
      var12.eReturningVoid(var13);
   }

   private void kReturningVoid(Object[] var1) {
      int var8;
      label40: {
         int var45;
         label39: {
            int var44;
            label42: {
               long var2 = (Long)var1[0];
               var2 = 106857869378349L ^ var2;
               long var4 = var2 ^ 47785672279083L;
               int var10000 = Event.bReturningInt();
               MinecraftClient var9 = b;
               GameOptions var10 = var9.options;
               KeyBindingAccessor var10001 = new KeyBindingAccessor(var10.useKey);
               Object[] var12 = new Object[]{var4};
               KeyBindingAccessor var11 = var10001;
               Key var13 = var11.aReturningVoid(var12);
               int var7 = var13.getCode();
               int var6 = var10000;
               short var72 = 14780;
               long var10002 = 469614229912810727L ^ var2;
               int var48 = var6;
               byte var47 = 8;
               int var46 = var7;
               int var42 = var46;
               byte var43 = var47;
               int var34 = var46;
               byte var35 = var47;
               if (var48 == 0) {
                  byte var50 = var35;
                  int var49 = var34;
                  if (var49 < var50) {
                     MinecraftClient var15 = b;
                     Window var16 = var15.getWindow();
                     long var68 = var16.getHandle();
                     int var19 = var7;
                     long var17 = var68;
                     var10000 = GLFW.glfwGetMouseButton(var17, var19);
                     int var52 = var6;
                     int var51 = var10000;
                     int var38 = var51;
                     int var36 = var51;
                     int var39;
                     if (var52 == 0) {
                        int var53 = var36;
                        int var37 = var53;
                        byte var55 = 1;
                        int var54 = var37;
                        if (var54 == var55) {
                           byte var56 = 1;
                           var39 = var56;
                        } else {
                           var39 = 0;
                        }
                     } else {
                        int var57 = var38;
                        var39 = var57;
                     }

                     var8 = var39;
                     int var58 = var6;
                     if (var58 == 0) {
                        break label40;
                     }
                  }

                  MinecraftClient var23 = b;
                  Window var24 = var23.getWindow();
                  long var70 = var24.getHandle();
                  int var27 = var7;
                  long var25 = var70;
                  var10000 = GLFW.glfwGetKey(var25, var27);
                  int var60 = var6;
                  int var59 = var10000;
                  var44 = var59;
                  int var40 = var59;
                  if (var60 != 0) {
                     break label42;
                  }

                  int var61 = var40;
                  int var41 = var61;
                  byte var63 = 1;
                  int var62 = var41;
                  var42 = var62;
                  var43 = var63;
               }

               byte var65 = var43;
               int var64 = var42;
               if (var64 != var65) {
                  var45 = 0;
                  break label39;
               }

               var44 = 1;
            }

            int var66 = var44;
            var45 = var66;
         }

         var8 = var45;
      }

      MinecraftClient var30 = b;
      GameOptions var31 = var30.options;
      int var33 = var8;
      KeyBinding var32 = var31.useKey;
      var32.setPressed(dev.prestige.recovery.SourceSupport.asBoolean(var33));
   }

   private void lReturningVoid(Object[] var1) {
      AutoCart var16;
      long var2 = (Long)var1[0];
      long var10000 = 106857869378349L ^ var2;
      int var27 = Event.bReturningInt();
      this.N = dev.prestige.recovery.SourceSupport.asBoolean(0);
      int var4 = var27;
      int var18 = var4;
      AutoCart var17 = this;
      var16 = var17;
      AutoCart var13 = var17;
      label24:
      if (var18 == 0) {
         AutoCartWeaponMode var20 = AutoCartWeaponMode.BOW;
         AutoCartWeaponMode var19 = var13.z;
         if (var19 == var20) {
            int var22 = var4;
            AutoCart var21 = this;
            var16 = var21;
            AutoCart var14 = var21;
            if (var22 != 0) {
               break label24;
            }

            AutoCart var23 = var14;
            AutoCart var15 = var23;
            boolean var24 = var15.Q;
            if (!var24) {
               IntSetting var8 = this.a;
               Integer var9 = (Integer)var8.aReturningObject();
               this.G = var9;
               this.y = AutoCartState.SWITCH_WEAPON;
               int var25 = var4;
               if (var25 == 0) {
                  return;
               }
            }
         }

         IntSetting var11 = this.c;
         Integer var12 = (Integer)var11.aReturningObject();
         this.G = var12;
         AutoCart var26 = this;
         var16 = var26;
      }

      var16.y = AutoCartState.WAIT_BACK;
   }

   private void mReturningVoid(Object[] var1) {
      float var4 = (Float)var1[0];
      float var2 = (Float)var1[1];
      float var3 = (Float)var1[2];
      long var5 = (Long)var1[3];
      var5 = 106857869378349L ^ var5;
      long var7 = var5 ^ 58793313478382L;
      long var9 = var5 ^ 53453372950059L;
      long var11 = var5 ^ 21761525117213L;
      int var10000 = Event.bReturningInt();
      Object[] var10007 = new Object[]{null, null, null, var9};
      var10007[2] = var4;
      var10007[1] = var3;
      var10007[0] = var2;
      Object[] var16 = var10007;
      AutoCart var15 = this;
      BlockPos var14 = var15.aReturningBlockPos(var16);
      int var13 = var10000;
      int var54 = var13;
      if (var54 == 0) {
         AutoCart var51;
         label49: {
            AutoCart var52;
            BlockPos var53;
            label48: {
               BlockPos var55 = var14;
               if (var55 != null) {
                  int var57 = var13;
                  AutoCart var56 = this;
                  var51 = var56;
                  AutoCart var40 = var56;
                  if (var57 != 0) {
                     break label49;
                  }

                  AutoCart var58 = var40;
                  AutoCart var41 = var58;
                  BlockPos var19 = var14;
                  Object[] var21 = new Object[]{var19.up(), var7};
                  AutoCart var20 = var41;
                  boolean var59 = var20.hReturningVoid(var21);
                  if (!var59) {
                     int var61 = var13;
                     AutoCart var60 = this;
                     var51 = var60;
                     AutoCart var42 = var60;
                     if (var61 != 0) {
                        break label49;
                     }

                     AutoCart var62 = var42;
                     AutoCart var43 = var62;
                     Object[] var25 = new Object[]{var14, var7};
                     AutoCart var24 = var43;
                     boolean var63 = var24.hReturningVoid(var25);
                     label43:
                     if (!var63) {
                        MinecraftClient var27 = b;
                        ClientWorld var76 = var27.world;
                        BlockPos var28 = var14;
                        BlockPos var30 = var28.up();
                        ClientWorld var29 = var76;
                        BlockState var31 = var29.getBlockState(var30);
                        boolean var77 = var31.isReplaceable();
                        int var65 = var13;
                        boolean var64 = var77;
                        boolean var50 = var64;
                        boolean var44 = var64;
                        if (var65 == 0) {
                           boolean var66 = var44;
                           boolean var45 = var66;
                           boolean var67 = var45;
                           if (!var67) {
                              break label43;
                           }

                           int var70 = var13;
                           BlockPos var69 = var14;
                           AutoCart var68 = this;
                           var52 = var68;
                           var53 = var69;
                           AutoCart var46 = var68;
                           BlockPos var47 = var69;
                           if (var70 != 0) {
                              break label48;
                           }

                           BlockPos var72 = var47;
                           AutoCart var71 = var46;
                           AutoCart var48 = var71;
                           BlockPos var49 = var72;
                           Object[] var36 = new Object[]{var49, var11};
                           AutoCart var35 = var48;
                           boolean var73 = var35.fReturningBoolean(var36);
                           var50 = var73;
                        }

                        boolean var74 = var50;
                        if (var74) {
                           var53 = var14;
                           var52 = this;
                           break label48;
                        }
                     }
                  }
               }

               var51 = this;
               break label49;
            }

            var52.D = var53;
            this.E = dev.prestige.recovery.SourceSupport.asBoolean(1);
            this.y = AutoCartState.SWITCH_RAIL;
            this.G = 0;
            return;
         }

         Object[] var39 = new Object[0];
         AutoCart var38 = var51;
         var38.jReturningVoid(var39);
      }
   }

   private void nReturningVoid(Object[] var1) {
      long var5;
      int var7;
      Rotation var8;
      AutoCart var35;
      float var36;
      float var37;
      label27: {
         float var2 = (Float)var1[0];
         long var3 = (Long)var1[1];
         var3 = 106857869378349L ^ var3;
         var5 = var3 ^ 87021491001464L;
         int var10000 = Event.cReturningInt();
         RotationManager var10001 = Prestige.o;
         Object[] var10 = new Object[0];
         RotationManager var9 = var10001;
         var8 = var9.bReturningdx_C0210(var10);
         var7 = var10000;
         int var62 = var7;
         Rotation var61 = var8;
         float var60 = var2;
         AutoCart var59 = this;
         AutoCart var30 = var59;
         float var31 = var60;
         Rotation var32 = var61;
         AutoCart var23 = var59;
         float var24 = var60;
         Rotation var25 = var61;
         if (var62 != 0) {
            Rotation var65 = var25;
            float var64 = var24;
            AutoCart var63 = var23;
            AutoCart var33 = var63;
            float var34 = var64;
            AutoCart var26 = var63;
            float var27 = var64;
            if (var65 == null) {
               MinecraftClient var14 = b;
               ClientPlayerEntity var15 = var14.player;
               var37 = var15.getYaw();
               var36 = var34;
               var35 = var33;
               break label27;
            }

            float var67 = var27;
            AutoCart var66 = var26;
            AutoCart var28 = var66;
            float var29 = var67;
            var32 = var8;
            var31 = var29;
            var30 = var28;
         }

         Object[] var13 = new Object[0];
         Rotation var12 = var32;
         float var70 = var12.aReturningFloat(var13);
         float var69 = var31;
         AutoCart var68 = var30;
         var35 = var68;
         var36 = var69;
         var37 = var70;
      }

      AutoCart var55;
      float var56;
      float var57;
      float var58;
      label21: {
         int var75 = var7;
         Rotation var74 = var8;
         float var73 = var37;
         float var72 = var36;
         AutoCart var71 = var35;
         AutoCart var48 = var71;
         float var49 = var72;
         float var50 = var73;
         Rotation var51 = var74;
         AutoCart var38 = var71;
         float var39 = var72;
         float var40 = var73;
         Rotation var41 = var74;
         if (var75 != 0) {
            Rotation var79 = var41;
            float var78 = var40;
            float var77 = var39;
            AutoCart var76 = var38;
            AutoCart var52 = var76;
            float var53 = var77;
            float var54 = var78;
            AutoCart var42 = var76;
            float var43 = var77;
            float var44 = var78;
            if (var79 == null) {
               MinecraftClient var19 = b;
               ClientPlayerEntity var20 = var19.player;
               var58 = var20.getPitch();
               var57 = var54;
               var56 = var53;
               var55 = var52;
               break label21;
            }

            float var82 = var44;
            float var81 = var43;
            AutoCart var80 = var42;
            AutoCart var45 = var80;
            float var46 = var81;
            float var47 = var82;
            var51 = var8;
            var50 = var47;
            var49 = var46;
            var48 = var45;
         }

         Object[] var18 = new Object[0];
         Rotation var17 = var51;
         float var86 = var17.bReturningFloat(var18);
         float var85 = var50;
         float var84 = var49;
         AutoCart var83 = var48;
         var55 = var83;
         var56 = var84;
         var57 = var85;
         var58 = var86;
      }

      Object[] var10006 = new Object[]{null, null, null, var5};
      var10006[2] = var58;
      var10006[1] = var57;
      var10006[0] = var56;
      Object[] var22 = var10006;
      AutoCart var21 = var55;
      var21.mReturningVoid(var22);
   }

   private BlockPos aReturningBlockPos(Object[] var1) {
      float var2 = (Float)var1[0];
      float var3 = (Float)var1[1];
      float var4 = (Float)var1[2];
      long var5 = (Long)var1[3];
      var5 = 106857869378349L ^ var5;
      int var7 = Event.bReturningInt();
      int var104 = var7;
      MinecraftClient var103 = b;
      MinecraftClient var86 = var103;
      MinecraftClient var85 = var103;
      if (var104 == 0) {
         MinecraftClient var32 = var85;
         ClientPlayerEntity var105 = var32.player;
         if (var105 == null) {
            return null;
         }

         MinecraftClient var106 = b;
         var86 = var106;
      }

      int var108 = var7;
      MinecraftClient var107 = var86;
      MinecraftClient var88 = var107;
      MinecraftClient var87 = var107;
      if (var108 == 0) {
         MinecraftClient var35 = var87;
         ClientWorld var109 = var35.world;
         if (var109 == null) {
            return null;
         }

         var88 = b;
      }

      MinecraftClient var38 = var88;
      ClientPlayerEntity var39 = var38.player;
      Vec3d var8 = var39.getEyePos();
      Vec3d var40 = var8;
      double var9 = var40.x;
      Vec3d var41 = var8;
      double var11 = var41.y - 0.1;
      Vec3d var42 = var8;
      double var13 = var42.z;
      double var43 = var2;
      double var15 = Math.toRadians(var43);
      double var45 = var3;
      double var17 = Math.toRadians(var45);
      double var47 = (float)var15;
      float var10000 = -MathHelper.sin(var47);
      double var49 = (float)var17;
      double var19 = var10000 * MathHelper.cos(var49);
      double var51 = (float)var17;
      double var21 = -MathHelper.sin(var51);
      double var53 = (float)var15;
      var10000 = MathHelper.cos(var53);
      double var55 = (float)var17;
      double var23 = var10000 * MathHelper.cos(var55);
      double var57 = var19 * var19 + var21 * var21 + var23 * var23;
      double var25 = Math.sqrt(var57);
      int var114 = var7;
      double var110 = var25;
      double var93 = var110;
      double var95 = var112;
      double var89 = var110;
      double var91 = var112;
      if (var114 == 0) {
         double var143;
         int var115 = (var143 = var89 - var91) == 0.0 ? 0 : (var143 < 0.0 ? -1 : 1);
         if (!((var115) != 0)) {
            return null;
         }

         var19 /= var25;
         var21 /= var25;
         var95 = var25;
         var93 = var23;
      }

      var23 = var93 / var95;
      float var63 = 1.05F;
      float var62 = 0.0F;
      float var61 = var4;
      float var27 = MathHelper.clamp(var61, var62, var63) * 3.0F;
      var19 *= var27;
      var21 *= var27;
      var23 *= var27;
      MinecraftClient var64 = b;
      ClientPlayerEntity var65 = var64.player;
      Vec3d var66 = var65.getVelocity();
      var19 += var66.x;
      MinecraftClient var67 = b;
      ClientPlayerEntity var68 = var67.player;
      Vec3d var69 = var68.getVelocity();
      var23 += var69.z;
      MinecraftClient var70 = b;
      ClientPlayerEntity var71 = var70.player;
      byte var140 = ((byte)((var71.isOnGround()) ? 1 : 0));
      int var117 = var7;
      byte var116 = var140;
      byte var98 = var116;
      byte var97 = var116;
      if (var117 == 0) {
         byte var118 = var97;
         if (var118 == 0) {
            MinecraftClient var73 = b;
            ClientPlayerEntity var74 = var73.player;
            Vec3d var75 = var74.getVelocity();
            var21 += var75.y;
         }

         var98 = 0;
      }

      int var28 = var98;

      BlockHitResult var102;
      label64: {
         while (true) {
            short var10001 = 7244;
            long var10002 = 8307708451071331024L ^ var5;
            short var120 = 300;
            int var119 = var28;
            if (var119 >= var120) {
               break;
            }

            label79: {
               Vec3d var29 = new Vec3d(var9, var11, var13);
               var9 += var19;
               var11 += var21;
               var13 += var23;
               var19 *= 0.99;
               var21 *= 0.99;
               var23 *= 0.99;
               var21 -= 0.05;
               Vec3d var30 = new Vec3d(var9, var11, var13);
               MinecraftClient var76 = b;
               ClientWorld var141 = var76.world;
               MinecraftClient var77 = b;
               RaycastContext var79 = new RaycastContext(var29, var30, ShapeType.OUTLINE, FluidHandling.NONE, var77.player);
               ClientWorld var78 = var141;
               BlockHitResult var31 = var78.raycast(var79);
               int var122 = var7;
               BlockHitResult var121 = var31;
               BlockHitResult var100 = var121;
               BlockHitResult var99 = var121;
               if (var122 == 0) {
                  BlockHitResult var123 = var99;
                  if (var123 == null) {
                     break label79;
                  }

                  var100 = var31;
               }

               int var125 = var7;
               BlockHitResult var124 = var100;
               var102 = var124;
               BlockHitResult var101 = var124;
               if (var125 != 0) {
                  break label64;
               }

               BlockHitResult var81 = var101;
               Type var142 = var81.getType();
               Type var127 = Type.BLOCK;
               Type var126 = var142;
               if (var126 == var127) {
                  BlockHitResult var128 = var31;
                  var102 = var128;
                  break label64;
               }
            }

            double var144;
            int var129 = (var144 = var11 - -65.0) == 0.0 ? 0 : (var144 < 0.0 ? -1 : 1);
            if (var129 >= 0) {
               var28++;
               int var130 = var7;
               if (var130 == 0) {
                  continue;
               }
            }
            break;
         }

         return null;
      }

      BlockHitResult var84 = var102;
      return var84.getBlockPos();
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      float var5 = (Float)var1[1];
      long var3 = (Long)var1[2];
      var3 = 106857869378349L ^ var3;
      long var6 = var3 ^ 28797885126828L;
      long var8 = var3 ^ 98426187563574L;
      int var10000 = Event.cReturningInt();
      MinecraftClient var28 = b;
      ClientPlayerEntity var29 = var28.player;
      Vec3d var11 = var29.getEyePos();
      int var10 = var10000;
      Vec3d var30 = var2;
      Vec3d var31 = var11;
      double var12 = var30.x - var31.x;
      Vec3d var32 = var2;
      Vec3d var33 = var11;
      double var14 = var32.z - var33.z;
      double var36 = var12;
      double var34 = var14;
      double var38 = Math.atan2(var34, var36);
      float var16 = (float)Math.toDegrees(var38) - 90.0F;
      ArrayList var17 = new ArrayList();
      double var18 = Double.MAX_VALUE;
      float var20 = -89.0F;

      double var88;
      double var90;
      label87: {
         while (true) {
            float var132;
            int var96 = (var132 = var20 - 60.0F) == 0.0F ? 0 : (var132 < 0.0F ? -1 : 1);
            if (var96 <= 0) {
               Object[] var10006 = new Object[]{null, null, null, var6};
               var10006[2] = var5;
               var10006[1] = var20;
               var10006[0] = var16;
               Object[] var41 = var10006;
               AutoCart var40 = this;
               BlockPos var21 = var40.aReturningBlockPos(var41);
               int var97 = var10;
               if (var97 == 0) {
                  break;
               }

               label81: {
                  label93: {
                     int var99 = var10;
                     BlockPos var98 = var21;
                     BlockPos var83 = var98;
                     BlockPos var81 = var98;
                     if (var99 != 0) {
                        BlockPos var100 = var81;
                        BlockPos var82 = var100;
                        BlockPos var101 = var82;
                        if (var101 == null) {
                           break label93;
                        }

                        var83 = var21;
                     }

                     BlockPos var44 = var83;
                     Vec3d var126 = var44.toCenterPos();
                     Vec3d var46 = var2;
                     Vec3d var45 = var126;
                     double var22 = var45.squaredDistanceTo(var46);
                     float[] var48 = new float[]{var20, (float)var22};
                     ArrayList var47 = var17;
                     var47.add(var48);
                     int var102 = var10;
                     if (var102 == 0) {
                        break label81;
                     }

                     double var133;
                     int var103 = (var133 = var22 - var18) == 0.0 ? 0 : (var133 < 0.0 ? -1 : 1);
                     if (var103 < 0) {
                        var18 = var22;
                     }
                  }

                  var20 += 0.5F;
               }

               int var104 = var10;
               if (var104 != 0) {
                  continue;
               }
            }

            int var109 = var10;
            double var107 = 4.0;
            double var105 = var18;
            var88 = var105;
            var90 = var107;
            double var84 = var105;
            double var86 = var107;
            if (var109 == 0) {
               break label87;
            }

            double var134;
            int var110 = (var134 = var84 - var86) == 0.0 ? 0 : (var134 < 0.0 ? -1 : 1);
            if (var110 > 0) {
               return null;
            }
            break;
         }

         var90 = 0.25;
         var88 = var18;
      }

      double var122 = var88 + var90;
      Predicate var53 = invokeBinding10(var122);
      ArrayList var52 = var17;
      var52.removeIf(var53);
      IntSetting var54 = this.e;
      Integer var55 = (Integer)var54.aReturningObject();
      double var127 = var55.intValue() / 100.0;
      ArrayList var56 = var17;
      double var57 = var127 * (var56.size() - 1);
      var10000 = (int)Math.round(var57);
      ArrayList var59 = var17;
      int var61 = var59.size() - 1;
      int var60 = var10000;
      int var123 = Math.min(var60, var61);
      int var63 = var123;
      ArrayList var62 = var17;
      float var23 = ((float[])var62.get(var63))[0];
      float var24 = var23 - 0.5F;

      int var117;
      do {
         float var135;
         int var111 = (var135 = var24 - (var23 + 0.5F)) == 0.0F ? 0 : (var135 < 0.0F ? -1 : 1);
         if (var111 > 0) {
            break;
         }

         label61: {
            label95: {
               Object[] var131 = new Object[]{null, null, null, var6};
               var131[2] = var5;
               var131[1] = var24;
               var131[0] = var16;
               Object[] var65 = var131;
               AutoCart var64 = this;
               BlockPos var25 = var64.aReturningBlockPos(var65);
               int var113 = var10;
               BlockPos var112 = var25;
               BlockPos var93 = var112;
               BlockPos var92 = var112;
               if (var113 != 0) {
                  BlockPos var114 = var92;
                  if (var114 == null) {
                     break label95;
                  }

                  var93 = var25;
               }

               BlockPos var67 = var93;
               Vec3d var129 = var67.toCenterPos();
               Vec3d var69 = var2;
               Vec3d var68 = var129;
               double var26 = var68.squaredDistanceTo(var69);
               int var115 = var10;
               if (var115 == 0) {
                  break label61;
               }

               double var136;
               int var116 = (var136 = var26 - var18) == 0.0 ? 0 : (var136 < 0.0 ? -1 : 1);
               if (var116 < 0) {
                  var18 = var26;
                  var23 = var24;
               }
            }

            var24 += 0.05F;
         }

         var117 = var10;
      } while (var117 != 0);

      RotationManager var130 = Prestige.o;
      Object[] var72 = new Object[]{var2, var8};
      RotationManager var71 = var130;
      Rotation var124 = var71.aReturningdx_C0210(var72);
      int var119 = var10;
      Rotation var118 = var124;
      Rotation var95 = var118;
      Rotation var94 = var118;
      if (var119 != 0) {
         Rotation var120 = var94;
         if (var120 == null) {
            return new Rotation(var16, var23);
         }

         Object[] var76 = new Object[0];
         Rotation var75 = var124;
         var95 = new Rotation(var75.aReturningFloat(var76), var23);
      }

      Rotation var125 = var95;
      Object[] var78 = new Object[0];
      Rotation var77 = var124;
      Object[] var80 = new Object[]{var77.aReturningBoolean(var78)};
      Rotation var79 = var125;
      var79.cReturningVoid(var80);
      return var125;
   }

   private void o(Object[] var1) {
      BlockHitResult var4 = (BlockHitResult)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 106857869378349L ^ var2;
      int var5 = Event.bReturningInt();
      int var23 = var5;
      MinecraftClient var22 = b;
      MinecraftClient var21 = var22;
      MinecraftClient var20 = var22;
      if (var23 == 0) {
         MinecraftClient var6 = var20;
         MinecraftClient var7 = b;
         BlockHitResult var11 = var4;
         Hand var10 = Hand.MAIN_HAND;
         ClientPlayerEntity var9 = var7.player;
         ClientPlayerInteractionManager var8 = var6.interactionManager;
         ActionResult var12 = var8.interactBlock(var9, var10, var11);
         boolean var24 = var12.isAccepted();
         if (!var24) {
            return;
         }

         MinecraftClient var25 = b;
         var21 = var25;
      }

      MinecraftClient var15 = var21;
      Hand var17 = Hand.MAIN_HAND;
      ClientPlayerEntity var16 = var15.player;
      var16.swingHand(var17);
      RotationManager var26 = Prestige.o;
      Object[] var19 = new Object[]{true};
      RotationManager var18 = var26;
      var18.fReturningVoid(var19);
   }

   private boolean fReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      var3 = 106857869378349L ^ var3;
      long var5 = var3 ^ 17716513808912L;
      MinecraftClient var17 = b;
      ClientPlayerEntity var18 = var17.player;
      Vec3d var8 = var18.getEyePos();
      Object[] var19 = new Object[]{var5};
      double var9 = ItemUseUtil.bReturningFloat(var19);
      int var10000 = Event.cReturningInt();
      BlockPos var20 = var2;
      double var10001 = var20.getX() + 0.5;
      Vec3d var21 = var8;
      double var11 = var10001 - var21.x;
      BlockPos var22 = var2;
      var10001 = var22.getY() + 1.0;
      Vec3d var23 = var8;
      double var13 = var10001 - var23.y;
      int var7 = var10000;
      BlockPos var24 = var2;
      double var34 = var24.getZ() + 0.5;
      Vec3d var25 = var8;
      double var15 = var34 - var25.z;
      double var37;
      var10000 = (var37 = var11 * var11 + var13 * var13 + var15 * var15 - var9 * var9) == 0.0 ? 0 : (var37 < 0.0 ? -1 : 1);
      int var30 = var7;
      int var29 = var10000;
      int var27 = var29;
      int var26 = var29;
      if (var30 != 0) {
         int var31 = var26;
         if (var31 > 0) {
            return false;
         }

         var27 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var27);
   }

   private boolean gReturningBoolean(Object[] var1) {
      double var2 = (Double)var1[0];
      double var4 = (Double)var1[1];
      double var6 = (Double)var1[2];
      long var8 = (Long)var1[3];
      var8 = 106857869378349L ^ var8;
      long var10 = var8 ^ 39071823111376L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var22 = b;
      ClientPlayerEntity var23 = var22.player;
      Vec3d var13 = var23.getEyePos();
      Object[] var24 = new Object[]{var10};
      double var14 = ItemUseUtil.bReturningFloat(var24);
      Vec3d var25 = var13;
      double var16 = var2 - var25.x;
      Vec3d var26 = var13;
      double var18 = var4 - var26.y;
      Vec3d var27 = var13;
      double var20 = var6 - var27.z;
      int var12 = var10000;
      double var37;
      var10000 = (var37 = var16 * var16 + var18 * var18 + var20 * var20 - var14 * var14) == 0.0 ? 0 : (var37 < 0.0 ? -1 : 1);
      int var32 = var12;
      int var31 = var10000;
      int var29 = var31;
      int var28 = var31;
      if (var32 == 0) {
         int var33 = var28;
         if (var33 > 0) {
            return false;
         }

         var29 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var29);
   }

   private boolean h(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 106857869378349L ^ var3;
      int var5 = Event.cReturningInt();
      MinecraftClient var8 = b;
      int var26 = var5;
      ClientWorld var25 = var8.world;
      ClientWorld var19 = var25;
      ClientWorld var18 = var25;
      if (var26 != 0) {
         ClientWorld var27 = var18;
         if (var27 == null) {
            return false;
         }

         MinecraftClient var11 = b;
         var19 = var11.world;
      }

      Box var14 = new Box(var2);
      Object var13 = null;
      ClientWorld var12 = var19;
      List var15 = var12.getOtherEntities((Entity)var13, var14);
      Iterator var6 = var15.iterator();

      byte var24;
      while (true) {
         Iterator var16 = var6;
         boolean var28 = var16.hasNext();
         if (var28) {
            Iterator var17 = var6;
            Entity var7 = (Entity)var17.next();
            byte var36 = ((byte)((var7 instanceof TntMinecartEntity) ? 1 : 0));
            int var30 = var5;
            byte var29 = var36;
            var24 = var29;
            byte var20 = var29;
            if (var30 == 0) {
               break;
            }

            int var32 = var5;
            byte var31 = var20;
            byte var23 = var31;
            byte var21 = var31;
            if (var32 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var23);
            }

            byte var33 = var21;
            byte var22 = var33;
            byte var34 = var22;
            if (var34 != 0) {
               var23 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var23);
            }

            int var35 = var5;
            if (var35 != 0) {
               continue;
            }
         }

         var24 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   private TntMinecartEntity aReturningTntMinecartEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      long var4 = var2 ^ 12302913438036L;
      int var6 = Event.bReturningInt();
      int var80 = var6;
      MinecraftClient var79 = b;
      MinecraftClient var70 = var79;
      MinecraftClient var69 = var79;
      if (var80 == 0) {
         MinecraftClient var28 = var69;
         ClientWorld var81 = var28.world;
         if (var81 == null) {
            return null;
         }

         MinecraftClient var82 = b;
         var70 = var82;
      }

      MinecraftClient var31 = var70;
      int var84 = var6;
      ClientPlayerEntity var83 = var31.player;
      ClientPlayerEntity var72 = var83;
      ClientPlayerEntity var71 = var83;
      if (var84 == 0) {
         ClientPlayerEntity var85 = var71;
         if (var85 == null) {
            return null;
         }

         MinecraftClient var34 = b;
         var72 = var34.player;
      }

      ClientPlayerEntity var35 = var72;
      Vec3d var7 = var35.getEyePos();
      FloatSetting var36 = this.n;
      Float var37 = (Float)var36.aReturningObject();
      float var8 = var37;
      TntMinecartEntity var9 = null;
      double var10 = Double.MAX_VALUE;
      MinecraftClient var38 = b;
      float var40 = 1.0F;
      ClientPlayerEntity var39 = var38.player;
      Vec3d var12 = var39.getRotationVec(var40);
      MinecraftClient var41 = b;
      ClientWorld var42 = var41.world;
      Iterable var43 = var42.getEntities();
      Iterator var13 = var43.iterator();

      while (true) {
         Iterator var44 = var13;
         boolean var86 = var44.hasNext();
         if (!var86) {
            break;
         }

         Iterator var45 = var13;
         Entity var14 = (Entity)var45.next();
         int var88 = var6;
         Entity var87 = var14;
         Entity var74 = var87;
         Entity var73 = var87;
         if (var88 == 0) {
            boolean var89 = var73 instanceof TntMinecartEntity;
            if (!var89) {
               continue;
            }

            var74 = var14;
         }

         TntMinecartEntity var15 = (TntMinecartEntity)var74;
         Object[] var47 = new Object[]{var15, var4};
         Vec3d var49 = RaycastUtil.aReturningVec3d(var47);
         Vec3d var48 = var7;
         double var16 = var48.distanceTo(var49);
         double var102;
         int var90 = (var102 = var16 - var8) == 0.0 ? 0 : (var102 < 0.0 ? -1 : 1);
         if (var90 <= 0) {
            Object[] var51 = new Object[]{var15, var4};
            Vec3d var10000 = RaycastUtil.aReturningVec3d(var51);
            Vec3d var53 = var7;
            Vec3d var52 = var10000;
            Vec3d var18 = var52.subtract(var53);
            Vec3d var54 = var18;
            Vec3d var55 = var18;
            double var100 = var54.x * var55.x;
            Vec3d var56 = var18;
            Vec3d var57 = var18;
            double var58 = var100 + var56.z * var57.z;
            double var19 = Math.sqrt(var58);
            double var103;
            int var91 = (var103 = var19 - 1.0E-6) == 0.0 ? 0 : (var103 < 0.0 ? -1 : 1);
            if (var91 >= 0) {
               label42: {
                  Vec3d var61 = var18;
                  Vec3d var21 = var61.normalize();
                  Vec3d var63 = var21;
                  Vec3d var62 = var12;
                  double var22 = var62.dotProduct(var63);
                  float var101 = (float)var22;
                  float var66 = 1.0F;
                  float var65 = -1.0F;
                  float var64 = var101;
                  double var67 = MathHelper.clamp(var64, var65, var66);
                  double var24 = Math.acos(var67);
                  double var26 = var24 * 8.0 + var16 * 0.05;
                  int var94 = var6;
                  double var92 = var26;
                  double var77 = var92;
                  double var75 = var92;
                  if (var94 == 0) {
                     double var104;
                     int var95 = (var104 = var75 - var10) == 0.0 ? 0 : (var104 < 0.0 ? -1 : 1);
                     if (var95 >= 0) {
                        break label42;
                     }

                     double var96 = var26;
                     var77 = var96;
                  }

                  var10 = var77;
                  var9 = var15;
               }

               int var98 = var6;
               if (var98 != 0) {
                  break;
               }
            }
         }
      }

      return var9;
   }

   private boolean i(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 106857869378349L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var5 = b;
      int var21 = var4;
      ClientPlayerEntity var20 = var5.player;
      ClientPlayerEntity var16 = var20;
      ClientPlayerEntity var15 = var20;
      if (var21 != 0) {
         ClientPlayerEntity var22 = var15;
         if (var22 == null) {
            return false;
         }

         MinecraftClient var8 = b;
         var16 = var8.player;
      }

      int var24 = var4;
      ClientPlayerEntity var23 = var16;
      ClientPlayerEntity var18 = var23;
      ClientPlayerEntity var17 = var23;
      if (var24 != 0) {
         ClientPlayerEntity var9 = var17;
         boolean var25 = var9.isUsingItem();
         if (!var25) {
            return false;
         }

         MinecraftClient var12 = b;
         var18 = var12.player;
      }

      ClientPlayerEntity var13 = var18;
      ItemStack var14 = var13.getActiveItem();
      Item var29 = var14.getItem();
      Item var27 = Items.BOW;
      Item var26 = var29;
      byte var19;
      if (var26 == var27) {
         byte var28 = 1;
         var19 = var28;
      } else {
         var19 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var19);
   }

   private int gReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 106857869378349L ^ var2;
      IntSetting var4 = this.d;
      Integer var5 = (Integer)var4.aReturningObject();
      int var6 = var5;
      return Math.max(var6, 3);
   }

   private boolean jReturningBoolean(Object[] var1) {
      int var6;
      int var22;
      label39: {
         long var2 = (Long)var1[0];
         var2 = 106857869378349L ^ var2;
         long var4 = var2 ^ 57947795957252L;
         var6 = Event.bReturningInt();
         IntSetting var7 = this.g;
         Integer var8 = (Integer)var7.aReturningObject();
         int var10000 = var8;
         int var28 = var6;
         byte var27 = 1;
         int var26 = var10000;
         int var20 = var26;
         byte var21 = var27;
         int var16 = var26;
         byte var17 = var27;
         if (var28 == 0) {
            byte var30 = var17;
            int var29 = var16;
            if (var29 <= var30) {
               return false;
            }

            BindSetting var10 = this.h;
            Integer var11 = (Integer)var10.aReturningObject();
            var10000 = var11;
            int var32 = var6;
            int var31 = var10000;
            var22 = var31;
            int var18 = var31;
            if (var32 != 0) {
               break label39;
            }

            int var33 = var18;
            int var19 = var33;
            
            var20 = var34;
            var21 = var35;
         }

         byte var37 = var21;
         int var36 = var20;
         if (var36 == var37) {
            return false;
         }

         BindSetting var45 = this.h;
         Object[] var15 = new Object[]{var4};
         BindSetting var14 = var45;
         byte var38 = ((byte)((var14.cReturningBoolean(var15)) ? 1 : 0));
         var22 = var38;
      }

      int var40 = var6;
      int var39 = var22;
      int var24 = var39;
      int var23 = var39;
      if (var40 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var24);
      } else {
         int var41 = var23;
         if (var41 != 0) {
            byte var46 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var46);
         } else {
            return false;
         }
      }
   }

   private float bReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      long var4 = var2 ^ 7824068862499L;
      long var6 = var2 ^ 90959870110825L;
      long var8 = var2 ^ 66008470041717L;
      Object[] var11 = new Object[]{var4};
      AutoCart var10 = this;
      int var10000 = var10.fReturningInt(var11);
      
      if (var17 != var18) {
         return 1.0500001F;
      } else {
         Object[] var13 = new Object[]{Items.BOW, var6};
         Integer var19 = InventoryUtil.aReturningBoxedInteger(var13);
         if (var19 != null) {
            Object[] var15 = new Object[]{var8};
            AutoCart var14 = this;
            int var16 = var14.gReturningInt(var15);
            return BowItem.getPullProgress(var16);
         } else {
            return -1.0F;
         }
      }
   }

   private boolean kReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 106857869378349L ^ var2;
      long var4 = var2 ^ 59210716255330L;
      int var6 = Event.bReturningInt();
      MinecraftClient var8 = b;
      int var20 = var6;
      ClientPlayerEntity var19 = var8.player;
      ClientPlayerEntity var18 = var19;
      ClientPlayerEntity var17 = var19;
      if (var20 == 0) {
         ClientPlayerEntity var21 = var17;
         if (var21 == null) {
            return false;
         }

         MinecraftClient var11 = b;
         var18 = var11.player;
      }

      ClientPlayerEntity var12 = var18;
      ItemStack var7 = var12.getMainHandStack();
      ItemStack var13 = var7;
      Item var10000 = var13.getItem();
      Item var23 = Items.BOW;
      Item var22 = var10000;
      if (var22 == var23) {
         return true;
      }

      Object[] var16 = new Object[]{var7, var4};
      AutoCart var15 = this;
      return var15.eReturningBoolean(var16);
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      int var20;
      AutoCart var107;
      label191: {
         long var10001 = 8916103170773L ^ 75146401119057L;
         var10001 = 8916103170773L ^ 46077279396182L;
         var10001 = 8916103170773L ^ 57566615400487L;
         var10001 = 8916103170773L ^ 54692960227554L;
         var10001 = 8916103170773L ^ 20792351958996L;
         var10001 = 8916103170773L ^ 55057381855696L;
         var10001 = 8916103170773L ^ 40792647208410L;
         var10001 = 8916103170773L ^ 11941540979381L;
         var20 = Event.bReturningInt();
         int var139 = var20;
         boolean var138 = this.S;
         boolean var106 = var138;
         boolean var104 = var138;
         if (var139 == 0) {
            boolean var140 = var104;
            if (var140) {
               this.S = dev.prestige.recovery.SourceSupport.asBoolean(0);
               return;
            }

            int var142 = var20;
            AutoCart var141 = this;
            var107 = var141;
            AutoCart var105 = var141;
            if (var142 != 0) {
               break label191;
            }

            BooleanSetting var29 = var105.l;
            Boolean var30 = (Boolean)var29.aReturningObject();
            boolean var143 = var30;
            var106 = var143;
         }

         boolean var144 = var106;
         if (!var144) {
            return;
         }

         var107 = this;
      }

      int var146 = var20;
      AutoCart var145 = var107;
      AutoCart var109 = var145;
      AutoCart var108 = var145;
      if (var146 == 0) {
         AutoCartState var148 = AutoCartState.IDLE;
         AutoCartState var147 = var108.y;
         if (var147 != var148) {
            return;
         }

         var109 = this;
      }

      boolean var149 = var109.W;
      if (!var149) {
         int var151 = var20;
         MinecraftClient var150 = b;
         MinecraftClient var111 = var150;
         MinecraftClient var110 = var150;
         if (var151 == 0) {
            MinecraftClient var35 = var110;
            ClientPlayerEntity var152 = var35.player;
            if (var152 == null) {
               return;
            }

            MinecraftClient var153 = b;
            var111 = var153;
         }

         int var155 = var20;
         MinecraftClient var154 = var111;
         MinecraftClient var113 = var154;
         MinecraftClient var112 = var154;
         if (var155 == 0) {
            MinecraftClient var38 = var112;
            ClientWorld var156 = var38.world;
            if (var156 == null) {
               return;
            }

            var113 = b;
         }

         float var24;
         byte var123;
         label167: {
            byte var23;
            label194: {
               MinecraftClient var41 = var113;
               ClientPlayerEntity var42 = var41.player;
               ItemStack var21 = var42.getMainHandStack();
               ItemStack var43 = var21;
               Item var22 = var43.getItem();
               var23 = 0;
               var24 = 1.0F;
               Object[] var45 = new Object[0];
               PacketSendEvent var44 = var1;
               Packet var26 = var44.aReturningVoid(var45);
               byte var10000 = ((byte)((var26 instanceof PlayerActionC2SPacket) ? 1 : 0));
               int var158 = var20;
               byte var157 = var10000;
               byte var119 = var157;
               byte var114 = var157;
               if (var158 == 0) {
                  Object var118;
                  label163: {
                     byte var159 = var114;
                     if (var159 != 0) {
                        PlayerActionC2SPacket var25 = (PlayerActionC2SPacket)var26;
                        int var161 = var20;
                        PlayerActionC2SPacket var160 = var25;
                        var118 = var160;
                        PlayerActionC2SPacket var115 = var160;
                        if (var161 != 0) {
                           break label163;
                        }

                        PlayerActionC2SPacket var47 = var115;
                        Action var209 = var47.getAction();
                        Action var163 = Action.RELEASE_USE_ITEM;
                        Action var162 = var209;
                        if (var162 == var163) {
                           Item var165 = Items.BOW;
                           Item var164 = var22;
                           if (var164 == var165) {
                              MinecraftClient var50 = b;
                              ClientPlayerEntity var51 = var50.player;
                              int var208 = var51.getItemUseTime();
                              int var167 = var20;
                              int var166 = var208;
                              int var117 = var166;
                              int var116 = var166;
                              if (var167 == 0) {
                                 byte var169 = 4;
                                 int var168 = var116;
                                 if (var168 < var169) {
                                    return;
                                 }

                                 var23 = 1;
                                 var117 = var208;
                              }

                              int var54 = var117;
                              var24 = BowItem.getPullProgress(var54);
                              break label194;
                           }
                        }
                     }

                     Object[] var56 = new Object[0];
                     PacketSendEvent var55 = var1;
                     var118 = var55.aReturningVoid(var56);
                  }

                  var119 = ((byte)((var118 instanceof PlayerInteractItemC2SPacket) ? 1 : 0));
               }

               int var171 = var20;
               byte var170 = var119;
               var123 = var170;
               byte var120 = var170;
               if (var171 != 0) {
                  break label167;
               }

               byte var172 = var120;
               if (var172 != 0) {
                  Object[] var59 = new Object[]{var21, 3056580651104L};
                  AutoCart var58 = this;
                  var10000 = ((byte)((var58.eReturningBoolean(var59)) ? 1 : 0));
                  int var174 = var20;
                  byte var173 = var10000;
                  var123 = var173;
                  byte var121 = var173;
                  if (var174 != 0) {
                     break label167;
                  }

                  byte var175 = var121;
                  byte var122 = var175;
                  byte var176 = var122;
                  if (var176 != 0) {
                     var23 = 1;
                     var24 = 1.0500001F;
                  }
               }
            }

            var123 = var23;
         }

         AutoCart var127;
         label195: {
            int var178 = var20;
            byte var177 = var123;
            int var126 = var177;
            byte var124 = var177;
            if (var178 == 0) {
               byte var179 = var124;
               if (var179 == 0) {
                  return;
               }

               int var181 = var20;
               AutoCart var180 = this;
               var127 = var180;
               AutoCart var125 = var180;
               if (var181 != 0) {
                  break label195;
               }

               Object[] var64 = new Object[]{83853123449220L};
               AutoCart var63 = var125;
               int var182 = var63.dReturningInt(var64);
               var126 = var182;
            }

            
            if (var183 == var184) {
               return;
            }

            var127 = this;
         }

         Object[] var68 = new Object[]{37330831764355L};
         AutoCart var67 = var127;
         Integer var185 = var67.aReturningBoxedInteger(var68);
         if (var185 != null) {
            AutoCart var137;
            BlockPos var207;
            label139: {
               label198: {
                  var207 = null;
                  int var187 = var20;
                  AutoCart var186 = this;
                  AutoCart var129 = var186;
                  AutoCart var128 = var186;
                  if (var187 == 0) {
                     ModeSetting var70 = var128.k;
                     String var211 = (String)var70.aReturningObject();
                     String var72 = "Trajectory";
                     String var71 = var211;
                     boolean var188 = var71.equals(var72);
                     if (!var188) {
                        break label198;
                     }

                     AutoCart var189 = this;
                     var129 = var189;
                  }

                  MinecraftClient var75 = b;
                  ClientPlayerEntity var76 = var75.player;
                  float var221 = var76.getYaw();
                  MinecraftClient var77 = b;
                  ClientPlayerEntity var78 = var77.player;
                  float var10002 = var78.getPitch();
                  Object[] var10006 = new Object[]{null, null, null, 63384110160439L};
                  var10006[2] = var24;
                  var10006[1] = var10002;
                  var10006[0] = var221;
                  Object[] var80 = var10006;
                  AutoCart var79 = var129;
                  var207 = var79.aReturningBlockPos(var80);
                  BlockPos var190 = var207;
                  if (var190 == null) {
                     return;
                  }

                  BlockPos var82 = var207;
                  Object[] var84 = new Object[]{var82.up(), 66248603925234L};
                  AutoCart var83 = this;
                  boolean var212 = var83.hReturningVoid(var84);
                  int var192 = var20;
                  boolean var191 = var212;
                  boolean var131 = var191;
                  boolean var130 = var191;
                  if (var192 == 0) {
                     boolean var193 = var130;
                     if (var193) {
                        return;
                     }

                     Object[] var87 = new Object[]{var207, 66248603925234L};
                     AutoCart var86 = this;
                     boolean var194 = var86.hReturningVoid(var87);
                     var131 = var194;
                  }

                  int var196 = var20;
                  boolean var195 = var131;
                  boolean var133 = var195;
                  boolean var132 = var195;
                  if (var196 == 0) {
                     boolean var197 = var132;
                     if (var197) {
                        return;
                     }

                     MinecraftClient var90 = b;
                     ClientWorld var213 = var90.world;
                     BlockPos var91 = var207;
                     BlockPos var93 = var91.up();
                     ClientWorld var92 = var213;
                     BlockState var94 = var92.getBlockState(var93);
                     var133 = var94.isReplaceable();
                  }

                  int var199 = var20;
                  boolean var198 = var133;
                  boolean var136 = var198;
                  boolean var134 = var198;
                  if (var199 == 0) {
                     boolean var200 = var134;
                     if (!var200) {
                        return;
                     }

                     int var202 = var20;
                     AutoCart var201 = this;
                     var137 = var201;
                     AutoCart var135 = var201;
                     if (var202 != 0) {
                        break label139;
                     }

                     Object[] var97 = new Object[]{var207, 29630608780545L};
                     AutoCart var96 = var135;
                     boolean var203 = var96.fReturningBoolean(var97);
                     var136 = var203;
                  }

                  boolean var204 = var136;
                  if (!var204) {
                     return;
                  }
               }

               Object[] var99 = new Object[]{49487520630543L};
               this.F = InventoryUtil.aReturningInt(var99);
               var137 = this;
            }

            var137.z = AutoCartWeaponMode.PASSIVE;
            int var205 = var20;
            if (var205 == 0) {
               BlockPos var206 = var207;
               if (var206 != null) {
                  this.D = var207;
                  this.E = dev.prestige.recovery.SourceSupport.asBoolean(1);
               }

               Object[] var103 = new Object[]{63810238520069L};
               AutoCart var102 = this;
               this.L = var102.jReturningBoolean(var103);
               this.M = 0;
               this.y = AutoCartState.SWITCH_RAIL;
               this.G = 0;
            }
         }
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 103611252249118L ^ 102450339092434L;
      var10001 = 103611252249118L ^ 23784976944010L;
      var10001 = 103611252249118L ^ 112394758078852L;
      var10001 = 103611252249118L ^ 34976895555432L;
      var10001 = 103611252249118L ^ 45265816275045L;
      var10001 = 103611252249118L ^ 20307884663706L;
      var10001 = 103611252249118L ^ 50510269344849L;
      var10001 = 103611252249118L ^ 140497458166173L;
      var10001 = 103611252249118L ^ 132828495346206L;
      var10001 = 103611252249118L ^ 126692575417617L;
      var10001 = 103611252249118L ^ 54601548606514L;
      var10001 = 103611252249118L ^ 76514322418200L;
      var10001 = 103611252249118L ^ 121755244222877L;
      var10001 = 103611252249118L ^ 131240689383903L;
      var10001 = 103611252249118L ^ 115474403669232L;
      var10001 = 103611252249118L ^ 127596543284195L;
      var10001 = 103611252249118L ^ 74327188242954L;
      var10001 = 103611252249118L ^ 9388873406872L;
      var10001 = 103611252249118L ^ 110170834929947L;
      var10001 = 103611252249118L ^ 17983334576402L;
      var10001 = 103611252249118L ^ 36259492259426L;
      var10001 = 103611252249118L ^ 92392569360955L;
      var10001 = 103611252249118L ^ 59563691363631L;
      var10001 = 103611252249118L ^ 26554927011450L;
      var10001 = 103611252249118L ^ 133561134181837L;
      var10001 = 103611252249118L ^ 138793884755647L;
      int var56 = Event.cReturningInt();
      int var623 = var56;
      if (var623 != 0) {
         MinecraftClient var71 = b;
         ClientWorld var624 = var71.world;
         label818:
         if (var624 != null) {
            MinecraftClient var73 = b;
            int var626 = var56;
            ClientPlayerEntity var625 = var73.player;
            Object var456 = var625;
            ClientPlayerEntity var454 = var625;
            if (var626 != 0) {
               ClientPlayerEntity var627 = var454;
               ClientPlayerEntity var455 = var627;
               ClientPlayerEntity var628 = var455;
               if (var628 == null) {
                  break label818;
               }

               BindSetting var79 = this.f;
               var456 = var79.aReturningObject();
            }

            int var461;
            label808: {
               int var460;
               label807: {
                  label825: {
                     Integer var80 = (Integer)var456;
                     int var10000 = var80;
                     int var630 = var56;
                     int var629 = var10000;
                     int var458 = var629;
                     int var457 = var629;
                     if (var630 != 0) {
                        
                        if (var631 == var632) {
                           break label825;
                        }

                        BindSetting var971 = this.f;
                        Object[] var83 = new Object[]{122678057516588L};
                        BindSetting var82 = var971;
                        byte var633 = ((byte)((var82.cReturningBoolean(var83)) ? 1 : 0));
                        var458 = var633;
                     }

                     int var635 = var56;
                     int var634 = var458;
                     var460 = var634;
                     int var459 = var634;
                     if (var635 == 0) {
                        break label807;
                     }

                     int var636 = var459;
                     if (var636 != 0) {
                        var460 = 1;
                        break label807;
                     }
                  }

                  var461 = 0;
                  break label808;
               }

               int var637 = var460;
               var461 = var637;
            }

            int var57;
            int var466;
            label795: {
               int var465;
               label794: {
                  label826: {
                     var57 = var461;
                     int var639 = var56;
                     int var638 = var57;
                     int var463 = var638;
                     int var462 = var638;
                     if (var639 != 0) {
                        int var640 = var462;
                        if (var640 == 0) {
                           break label826;
                        }

                        byte var641 = ((byte)((this.J) ? 1 : 0));
                        var463 = var641;
                     }

                     int var643 = var56;
                     int var642 = var463;
                     var465 = var642;
                     int var464 = var642;
                     if (var643 == 0) {
                        break label794;
                     }

                     int var644 = var464;
                     if (var644 == 0) {
                        var465 = 1;
                        break label794;
                     }
                  }

                  var466 = 0;
                  break label795;
               }

               int var645 = var465;
               var466 = var645;
            }

            int var58;
            int var471;
            label782: {
               int var470;
               label781: {
                  label827: {
                     var58 = var466;
                     this.J = dev.prestige.recovery.SourceSupport.asBoolean(var57);
                     BindSetting var89 = this.h;
                     Integer var90 = (Integer)var89.aReturningObject();
                     int var972 = var90;
                     int var647 = var56;
                     int var646 = var972;
                     int var468 = var646;
                     int var467 = var646;
                     if (var647 != 0) {
                        
                        if (var648 == var649) {
                           break label827;
                        }

                        BindSetting var973 = this.h;
                        Object[] var93 = new Object[]{122678057516588L};
                        BindSetting var92 = var973;
                        byte var650 = ((byte)((var92.cReturningBoolean(var93)) ? 1 : 0));
                        var468 = var650;
                     }

                     int var652 = var56;
                     int var651 = var468;
                     var470 = var651;
                     int var469 = var651;
                     if (var652 == 0) {
                        break label781;
                     }

                     int var653 = var469;
                     if (var653 != 0) {
                        var470 = 1;
                        break label781;
                     }
                  }

                  var471 = 0;
                  break label782;
               }

               int var654 = var470;
               var471 = var654;
            }

            int var59;
            int var476;
            label769: {
               int var475;
               label768: {
                  label828: {
                     var59 = var471;
                     int var656 = var56;
                     int var655 = var59;
                     int var473 = var655;
                     int var472 = var655;
                     if (var656 != 0) {
                        int var657 = var472;
                        if (var657 == 0) {
                           break label828;
                        }

                        byte var658 = ((byte)((this.K) ? 1 : 0));
                        var473 = var658;
                     }

                     int var660 = var56;
                     int var659 = var473;
                     var475 = var659;
                     int var474 = var659;
                     if (var660 == 0) {
                        break label768;
                     }

                     int var661 = var474;
                     if (var661 == 0) {
                        var475 = 1;
                        break label768;
                     }
                  }

                  var476 = 0;
                  break label769;
               }

               int var662 = var475;
               var476 = var662;
            }

            int var60 = var476;
            int var664 = var56;
            AutoCart var663 = this;
            AutoCart var478 = var663;
            AutoCart var477 = var663;
            if (var664 != 0) {
               var477.K = dev.prestige.recovery.SourceSupport.asBoolean(var59);
               MinecraftClient var99 = b;
               GameOptions var100 = var99.options;
               KeyBinding var101 = var100.useKey;
               boolean var665 = var101.isPressed();
               if (!var665) {
                  this.W = false;
               }

               var478 = this;
            }

            int var511;
            label755: {
               AutoCart var510;
               int var667 = var56;
               AutoCart var666 = var478;
               var510 = var666;
               AutoCart var479 = var666;
               label754:
               if (var667 != 0) {
                  AutoCartState var669 = AutoCartState.IDLE;
                  AutoCartState var668 = var479.y;
                  label752:
                  if (var668 == var669) {
                     int var671 = var56;
                     int var670 = var58;
                     int var484 = var670;
                     int var480 = var670;
                     if (var671 != 0) {
                        int var672 = var480;
                        int var481 = var672;
                        int var673 = var481;
                        if (var673 == 0) {
                           int var675 = var56;
                           int var674 = var60;
                           var511 = var674;
                           int var482 = var674;
                           if (var675 == 0) {
                              break label755;
                           }

                           int var676 = var482;
                           int var483 = var676;
                           int var677 = var483;
                           if (var677 == 0) {
                              break label752;
                           }
                        }

                        Object[] var110 = new Object[]{63810238520069L};
                        AutoCart var109 = this;
                        byte var678 = ((byte)((var109.jReturningBoolean(var110)) ? 1 : 0));
                        var484 = var678;
                     }

                     int var61;
                     int var487;
                     var61 = var484;
                     Object[] var113 = new Object[]{3394298381772L};
                     AutoCart var112 = this;
                     int var974 = var112.fReturningInt(var113);
                     int var680 = var56;
                     int var679 = var974;
                     int var486 = var679;
                     int var485 = var679;
                     label742:
                     if (var680 != 0) {
                        
                        if (var681 == var682) {
                           Object[] var115 = new Object[]{Items.BOW, 95321893129094L};
                           Integer var683 = InventoryUtil.aReturningBoxedInteger(var115);
                           if (var683 == null) {
                              var487 = 0;
                              break label742;
                           }
                        }

                        byte var684 = 1;
                        var487 = var684;
                     } else {
                        int var685 = var486;
                        var487 = var685;
                     }

                     int var62 = var487;
                     Object[] var119 = new Object[]{83853123449220L};
                     AutoCart var118 = this;
                     var974 = var118.dReturningInt(var119);
                     int var687 = var56;
                     int var686 = var974;
                     var511 = var686;
                     int var488 = var686;
                     if (var687 == 0) {
                        break label755;
                     }

                     
                     if (var688 != var689) {
                        int var691 = var56;
                        AutoCart var690 = this;
                        var510 = var690;
                        AutoCart var489 = var690;
                        if (var691 == 0) {
                           break label754;
                        }

                        AutoCart var692 = var489;
                        AutoCart var490 = var692;
                        Object[] var123 = new Object[]{37330831764355L};
                        AutoCart var122 = var490;
                        Integer var693 = var122.aReturningBoxedInteger(var123);
                        label734:
                        if (var693 != null) {
                           label831: {
                              int var695 = var56;
                              int var694 = var61;
                              int var493 = var694;
                              int var491 = var694;
                              if (var695 != 0) {
                                 int var696 = var491;
                                 int var492 = var696;
                                 int var697 = var492;
                                 if (var697 == 0) {
                                    break label831;
                                 }

                                 var493 = var62;
                              }

                              int var699 = var56;
                              int var698 = var493;
                              var511 = var698;
                              int var494 = var698;
                              if (var699 == 0) {
                                 break label755;
                              }

                              int var700 = var494;
                              if (var700 == 0) {
                                 break label734;
                              }
                           }

                           AutoCart var504;
                           BlockPos var505;
                           label723: {
                              AutoCart var501;
                              HitResult var502;
                              label722: {
                                 Object[] var128 = new Object[]{49487520630543L};
                                 this.F = InventoryUtil.aReturningInt(var128);
                                 this.z = AutoCartWeaponMode.BOW;
                                 this.Q = dev.prestige.recovery.SourceSupport.asBoolean(var61);
                                 int var702 = var61;
                                 AutoCart var701 = this;
                                 AutoCart var503 = var701;
                                 AutoCart var495 = var701;
                                 if (var702 != 0) {
                                    AutoCart var703 = var495;
                                    AutoCart var496 = var703;
                                    MinecraftClient var130 = b;
                                    HitResult var64 = var130.crosshairTarget;
                                    int var706 = var56;
                                    HitResult var705 = var64;
                                    AutoCart var704 = var496;
                                    var501 = var704;
                                    var502 = var705;
                                    AutoCart var497 = var704;
                                    HitResult var498 = var705;
                                    if (var706 == 0) {
                                       break label722;
                                    }

                                    boolean var708 = var498 instanceof BlockHitResult;
                                    AutoCart var707 = var497;
                                    var503 = var707;
                                    AutoCart var499 = var707;
                                    if (var708) {
                                       AutoCart var709 = var499;
                                       AutoCart var500 = var709;
                                       HitResult var711 = var64;
                                       AutoCart var710 = var500;
                                       var501 = var710;
                                       var502 = var711;
                                       break label722;
                                    }
                                 }

                                 var505 = null;
                                 var504 = var503;
                                 break label723;
                              }

                              BlockHitResult var63 = (BlockHitResult)var502;
                              BlockHitResult var133 = var63;
                              BlockPos var713 = var133.getBlockPos();
                              AutoCart var712 = var501;
                              var504 = var712;
                              var505 = var713;
                           }

                           var504.R = var505;
                           this.D = null;
                           this.E = false;
                           this.W = true;
                           Object[] var135 = new Object[]{63810238520069L};
                           AutoCart var134 = this;
                           this.L = var134.jReturningBoolean(var135);
                           this.M = 0;
                           int var715 = var61;
                           AutoCart var714 = this;
                           AutoCart var507 = var714;
                           AutoCart var506 = var714;
                           AutoCart var508;
                           AutoCartState var509;
                           if (var715 != 0) {
                              AutoCartState var717 = AutoCartState.SWITCH_WEAPON;
                              AutoCart var716 = var506;
                              var508 = var716;
                              var509 = var717;
                           } else {
                              var509 = AutoCartState.SWITCH_RAIL;
                              var508 = var507;
                           }

                           var508.y = var509;
                           this.G = 0;
                        }
                     }
                  }

                  var510 = this;
               }

               var511 = (((var510.U) ? 1 : 0));
            }

            label708: {
               AutoCart var526;
               label832: {
                  int var519;
                  int var719 = var56;
                  int var718 = var511;
                  var519 = var718;
                  int var512 = var718;
                  label706:
                  if (var719 != 0) {
                     Object var518;
                     label833: {
                        int var720 = var512;
                        if (var720 != 0) {
                           int var722 = var56;
                           AutoCartState var721 = this.y;
                           var518 = var721;
                           AutoCartState var513 = var721;
                           if (var722 == 0) {
                              break label833;
                           }

                           AutoCartState var723 = var513;
                           AutoCartState var514 = var723;
                           AutoCartState var725 = AutoCartState.IDLE;
                           AutoCartState var724 = var514;
                           if (var724 == var725) {
                              Object[] var141 = new Object[]{83124813339028L};
                              AutoCart var140 = this;
                              byte var976 = ((byte)((var140.iReturningVoid(var141)) ? 1 : 0));
                              int var727 = var56;
                              byte var726 = var976;
                              var519 = var726;
                              byte var515 = var726;
                              if (var727 == 0) {
                                 break label706;
                              }

                              byte var728 = var515;
                              byte var516 = var728;
                              byte var729 = var516;
                              if (var729 != 0) {
                                 this.S = true;
                                 MinecraftClient var144 = b;
                                 GameOptions var145 = var144.options;
                                 KeyBinding var146 = var145.useKey;
                                 var146.setPressed(false);
                                 int var730 = var56;
                                 if (var730 != 0) {
                                    MinecraftClient var149 = b;
                                    ClientPlayerEntity var150 = var149.player;
                                    boolean var731 = var150.isUsingItem();
                                    if (var731) {
                                       MinecraftClient var152 = b;
                                       MinecraftClient var153 = b;
                                       ClientPlayerEntity var155 = var153.player;
                                       ClientPlayerInteractionManager var154 = var152.interactionManager;
                                       var154.stopUsingItem((PlayerEntity)var155);
                                    }

                                    this.U = false;
                                    this.T = null;
                                 }

                                 return;
                              }
                           }
                        }

                        int var733 = var56;
                        AutoCart var732 = this;
                        var526 = var732;
                        AutoCart var517 = var732;
                        if (var733 == 0) {
                           break label832;
                        }

                        BooleanSetting var157 = var517.m;
                        Object var734 = var157.aReturningObject();
                        var518 = var734;
                     }

                     Boolean var159 = (Boolean)var518;
                     var519 = ((((java.lang.Boolean)(var159)).booleanValue() ? 1 : 0));
                  }

                  int var735 = var519;
                  if (var735 != 0) {
                     int var737 = var56;
                     AutoCart var736 = this;
                     var526 = var736;
                     AutoCart var520 = var736;
                     if (var737 == 0) {
                        break label832;
                     }

                     AutoCart var738 = var520;
                     AutoCart var521 = var738;
                     AutoCartState var740 = AutoCartState.IDLE;
                     AutoCartState var739 = var521.y;
                     if (var739 == var740) {
                        int var742 = var56;
                        AutoCart var741 = this;
                        var526 = var741;
                        AutoCart var522 = var741;
                        if (var742 == 0) {
                           break label832;
                        }

                        AutoCart var743 = var522;
                        AutoCart var523 = var743;
                        Object[] var164 = new Object[]{83124813339028L};
                        AutoCart var163 = var523;
                        boolean var744 = var163.iReturningVoid(var164);
                        if (var744) {
                           Object[] var167 = new Object[]{32583673286676L};
                           AutoCart var166 = this;
                           TntMinecartEntity var953 = var166.aReturningTntMinecartEntity(var167);
                           this.T = var953;
                           TntMinecartEntity var745 = var953;
                           if (var745 != null) {
                              MinecraftClient var168 = b;
                              ClientPlayerEntity var169 = var168.player;
                              int var977 = var169.getItemUseTime();
                              IntSetting var170 = this.o;
                              Integer var171 = (Integer)var170.aReturningObject();
                              int var747 = var171;
                              int var746 = var977;
                              label682:
                              if (var746 >= var747) {
                                 RotationManager var978 = Prestige.o;
                                 Object[] var174 = new Object[0];
                                 RotationManager var173 = var978;
                                 Rotation var959 = var173.cReturningdx_C0210(var174);
                                 int var749 = var56;
                                 Rotation var748 = var959;
                                 Rotation var525 = var748;
                                 Rotation var524 = var748;
                                 if (var749 != 0) {
                                    Rotation var750 = var524;
                                    if (var750 == null) {
                                       break label682;
                                    }

                                    var525 = var959;
                                 }

                                 Object[] var177 = new Object[0];
                                 Rotation var176 = var525;
                                 boolean var751 = var176.aReturningBoolean(var177);
                                 if (!var751) {
                                    this.U = true;
                                 }
                              }
                           }

                           int var752 = var56;
                           if (var752 != 0) {
                              break label708;
                           }
                        }
                     }
                  }

                  this.T = null;
                  AutoCart var753 = this;
                  var526 = var753;
               }

               var526.U = false;
            }

            int var755 = var56;
            AutoCartState var754 = this.y;
            AutoCartState var528 = var754;
            AutoCartState var527 = var754;
            if (var755 != 0) {
               AutoCartState var757 = AutoCartState.IDLE;
               AutoCartState var756 = var527;
               if (var756 == var757) {
                  return;
               }

               var528 = this.y;
            }

            AutoCart var553;
            label667: {
               label893: {
                  label837: {
                     label838: {
                        label839: {
                           label840: {
                              label867: {
                                 label868: {
                                    label843: {
                                       AutoCartState var182 = var528;
                                       int var979 = var182.ordinal();
                                       int var759 = var56;
                                       int var758 = var979;
                                       int var530 = var758;
                                       int var529 = var758;
                                       if (var759 != 0) {
                                          int var760 = var529;
                                          switch (var760) {
                                             case 1:
                                                Object[] var185 = new Object[]{83853123449220L};
                                                AutoCart var184 = this;
                                                int var761 = var184.dReturningInt(var185);
                                                var530 = var761;
                                                break;
                                             case 2:
                                                break label843;
                                             case 3:
                                                break label868;
                                             case 4:
                                                break label867;
                                             case 5:
                                                break label840;
                                             case 6:
                                                break label839;
                                             case 7:
                                                break label838;
                                             case 8:
                                                break label837;
                                             default:
                                                return;
                                          }
                                       }

                                       int var954 = var530;
                                       int var762 = var56;
                                       if (var762 == 0) {
                                          return;
                                       }

                                       
                                       if (var763 == var764) {
                                          Object[] var189 = new Object[0];
                                          AutoCart var188 = this;
                                          var188.jReturningVoid(var189);
                                          return;
                                       }

                                       Object[] var192 = new Object[]{35187187528865L};
                                       AutoCart var191 = this;
                                       BlockHitResult var960 = var191.aReturningBlockHitResult(var192);
                                       BlockHitResult var765 = var960;
                                       if (var765 == null) {
                                          int var767 = var56;
                                          AutoCart var766 = this;
                                          AutoCart var533 = var766;
                                          AutoCart var531 = var766;
                                          if (var767 != 0) {
                                             AutoCart var768 = var531;
                                             AutoCart var532 = var768;
                                             var979 = ++var532.H;
                                             byte var770 = 10;
                                             int var769 = var979;
                                             if (var769 <= var770) {
                                                return;
                                             }

                                             AutoCart var771 = this;
                                             var533 = var771;
                                          }

                                          Object[] var197 = new Object[0];
                                          AutoCart var196 = var533;
                                          var196.jReturningVoid(var197);
                                          return;
                                       }

                                       double var1028 = this.A + 0.5;
                                       double var10002 = this.B + 0.5;
                                       double var10003 = this.C + 0.5;
                                       Object[] var10006 = new Object[]{null, null, null, 45522447051713L};
                                       var10006[2] = var10003;
                                       var10006[1] = var10002;
                                       var10006[0] = var1028;
                                       Object[] var199 = var10006;
                                       AutoCart var198 = this;
                                       byte var980 = ((byte)((var198.gReturningBoolean(var199)) ? 1 : 0));
                                       int var773 = var56;
                                       byte var772 = var980;
                                       int var535 = var772;
                                       byte var534 = var772;
                                       if (var773 != 0) {
                                          byte var774 = var534;
                                          if (var774 == 0) {
                                             Object[] var202 = new Object[0];
                                             AutoCart var201 = this;
                                             var201.jReturningVoid(var202);
                                             return;
                                          }

                                          var535 = var954;
                                       }

                                       Object[] var1035 = new Object[]{null, 72518082610550L};
                                       var1035[0] = var535;
                                       Object[] var204 = var1035;
                                       InventoryUtil.aReturningVoid(var204);
                                       Object[] var206 = new Object[]{var960, 30430898198534L};
                                       AutoCart var205 = this;
                                       var205.o(var206);
                                       IntSetting var207 = this.a;
                                       Integer var208 = (Integer)var207.aReturningObject();
                                       this.G = var208;
                                       this.y = AutoCartState.SWITCH_CART;
                                       int var775 = var56;
                                       if (var775 != 0) {
                                          return;
                                       }
                                    }

                                    int var777 = var56;
                                    int var776 = this.G;
                                    int var538 = var776;
                                    int var536 = var776;
                                    if (var777 != 0) {
                                       int var778 = var536;
                                       int var537 = var778;
                                       int var779 = var537;
                                       if (var779 > 0) {
                                          this.G--;
                                          return;
                                       }

                                       var538 = (((this.N) ? 1 : 0));
                                    }

                                    Integer var548;
                                    label642: {
                                       AutoCart var547;
                                       label844: {
                                          int var781 = var56;
                                          int var780 = var538;
                                          int var544 = var780;
                                          int var539 = var780;
                                          if (var781 != 0) {
                                             int var782 = var539;
                                             if (var782 != 0) {
                                                int var784 = var56;
                                                AutoCart var783 = this;
                                                AutoCart var542 = var783;
                                                AutoCart var540 = var783;
                                                if (var784 != 0) {
                                                   AutoCart var785 = var540;
                                                   AutoCart var541 = var785;
                                                   ElapsedTimer var981 = var541.O;
                                                   Object[] var215 = new Object[]{this.i, 130913203968635L};
                                                   ElapsedTimer var214 = var981;
                                                   boolean var786 = var214.bReturningBoolean(var215);
                                                   if (!var786) {
                                                      return;
                                                   }

                                                   var542 = this;
                                                }

                                                var542.N = false;
                                             }

                                             int var788 = var56;
                                             AutoCart var787 = this;
                                             var547 = var787;
                                             AutoCart var543 = var787;
                                             if (var788 == 0) {
                                                break label844;
                                             }

                                             BooleanSetting var218 = var543.j;
                                             Boolean var219 = (Boolean)var218.aReturningObject();
                                             byte var789 = ((byte)(((java.lang.Boolean)(var219)).booleanValue() ? 1 : 0));
                                             var544 = var789;
                                          }

                                          int var790 = var544;
                                          if (var790 != 0) {
                                             int var792 = var56;
                                             AutoCart var791 = this;
                                             var547 = var791;
                                             AutoCart var545 = var791;
                                             if (var792 == 0) {
                                                break label844;
                                             }

                                             AutoCart var793 = var545;
                                             AutoCart var546 = var793;
                                             int var794 = var546.M;
                                             if (var794 > 0) {
                                                Object[] var223 = new Object[]{Items.TNT_MINECART, 95321893129094L};
                                                Integer var795 = InventoryUtil.aReturningBoxedInteger(var223);
                                                var548 = var795;
                                                break label642;
                                             }
                                          }

                                          var547 = this;
                                       }

                                       Object[] var226 = new Object[]{37330831764355L};
                                       AutoCart var225 = var547;
                                       var548 = var225.aReturningBoxedInteger(var226);
                                    }

                                    Integer var955 = var548;
                                    Integer var796 = var955;
                                    if (var796 == null) {
                                       int var798 = var56;
                                       AutoCart var797 = this;
                                       AutoCart var551 = var797;
                                       AutoCart var549 = var797;
                                       if (var798 != 0) {
                                          AutoCart var799 = var549;
                                          AutoCart var550 = var799;
                                          int var800 = var550.M;
                                          if (var800 > 0) {
                                             Object[] var230 = new Object[]{139369772315772L};
                                             AutoCart var229 = this;
                                             var229.lReturningVoid(var230);
                                             int var801 = var56;
                                             if (var801 != 0) {
                                                return;
                                             }
                                          }

                                          AutoCart var802 = this;
                                          var551 = var802;
                                       }

                                       Object[] var234 = new Object[0];
                                       AutoCart var233 = var551;
                                       var233.jReturningVoid(var234);
                                       return;
                                    }

                                    MinecraftClient var235 = b;
                                    ClientPlayerEntity var236 = var235.player;
                                    PlayerInventory var982 = var236.getInventory();
                                    Integer var237 = var955;
                                    int var239 = var237;
                                    PlayerInventory var238 = var982;
                                    ItemStack var240 = var238.getStack(var239);
                                    Item var983 = var240.getItem();
                                    Item var804 = Items.TNT_MINECART;
                                    Item var803 = var983;
                                    if (var803 != var804) {
                                       return;
                                    }

                                    int var806 = var56;
                                    AutoCart var805 = this;
                                    var553 = var805;
                                    AutoCart var552 = var805;
                                    if (var806 == 0) {
                                       break label667;
                                    }

                                    double var1029 = this.A + 0.5;
                                    double var1032 = this.B + 0.5;
                                    double var1036 = this.C + 0.5;
                                    Object[] var1044 = new Object[]{null, null, null, 45522447051713L};
                                    var1044[2] = var1036;
                                    var1044[1] = var1032;
                                    var1044[0] = var1029;
                                    Object[] var243 = var1044;
                                    AutoCart var242 = var552;
                                    boolean var807 = var242.gReturningBoolean(var243);
                                    if (!var807) {
                                       AutoCart var808 = this;
                                       var553 = var808;
                                       break label667;
                                    }

                                    BlockHitResult var961 = new BlockHitResult(
                                       new Vec3d(this.A + 0.5, this.B + 0.125, this.C + 0.5), Direction.UP, new BlockPos(this.A, this.B, this.C), false
                                    );
                                    int var810 = var56;
                                    int var809 = this.M;
                                    int var554 = var809;
                                    label625:
                                    if (var810 != 0) {
                                       byte var812 = 1;
                                       int var811 = var554;
                                       if (var811 >= var812) {
                                          Integer var249 = var955;
                                          int var984 = var249;
                                          Runnable var1030 = invokeBinding11(this, var961);
                                          Object[] var10005 = new Object[]{null, null, null, 86177674060556L};
                                          var10005[2] = true;
                                          var10005[1] = var1030;
                                          var10005[0] = var984;
                                          Object[] var250 = var10005;
                                          InventoryUtil.bReturningVoid(var250);
                                          int var813 = var56;
                                          if (var813 != 0) {
                                             break label625;
                                          }
                                       }

                                       Integer var252 = var955;
                                       int var985 = var252;
                                       Object[] var1037 = new Object[]{null, 72518082610550L};
                                       var1037[0] = var985;
                                       Object[] var253 = var1037;
                                       InventoryUtil.aReturningVoid(var253);
                                       Object[] var254 = new Object[]{var961, 11253043183653L};
                                       boolean var814 = ItemUseUtil.aReturningBoolean(var254);
                                    }

                                    label619: {
                                       AutoCart var563;
                                       label846: {
                                          int var562;
                                          label847: {
                                             label848: {
                                                this.M++;
                                                int var816 = var56;
                                                byte var815 = ((byte)((this.L) ? 1 : 0));
                                                int var559 = var815;
                                                byte var556 = var815;
                                                if (var816 != 0) {
                                                   byte var817 = var556;
                                                   if (var817 == 0) {
                                                      Object[] var258 = new Object[]{63810238520069L};
                                                      AutoCart var257 = this;
                                                      byte var986 = ((byte)((var257.jReturningBoolean(var258)) ? 1 : 0));
                                                      int var819 = var56;
                                                      byte var818 = var986;
                                                      var562 = var818;
                                                      byte var557 = var818;
                                                      if (var819 == 0) {
                                                         break label847;
                                                      }

                                                      byte var820 = var557;
                                                      byte var558 = var820;
                                                      byte var821 = var558;
                                                      if (var821 == 0) {
                                                         break label848;
                                                      }
                                                   }

                                                   int var822 = this.M;
                                                   var559 = var822;
                                                }

                                                int var824 = var56;
                                                int var823 = var559;
                                                var562 = var823;
                                                int var560 = var823;
                                                if (var824 == 0) {
                                                   break label847;
                                                }

                                                IntSetting var262 = this.g;
                                                Integer var263 = (Integer)var262.aReturningObject();
                                                int var826 = var263;
                                                int var825 = var560;
                                                if (var825 < var826) {
                                                   ElapsedTimer var987 = this.O;
                                                   Object[] var266 = new Object[]{42835128969216L};
                                                   ElapsedTimer var265 = var987;
                                                   var265.aReturningVoid(var266);
                                                   MinMaxSetting var988 = this.i;
                                                   Object[] var268 = new Object[]{127318019014223L};
                                                   MinMaxSetting var267 = var988;
                                                   var267.bReturningVoid(var268);
                                                   this.N = true;
                                                   return;
                                                }
                                             }

                                             int var828 = var56;
                                             AutoCart var827 = this;
                                             var563 = var827;
                                             AutoCart var561 = var827;
                                             if (var828 == 0) {
                                                break label846;
                                             }

                                             BooleanSetting var270 = var561.q;
                                             Boolean var271 = (Boolean)var270.aReturningObject();
                                             byte var829 = ((byte)(((java.lang.Boolean)(var271)).booleanValue() ? 1 : 0));
                                             var562 = var829;
                                          }

                                          int var830 = var562;
                                          if (var830 != 0) {
                                             this.y = AutoCartState.SWITCH_SAFE;
                                             IntSetting var273 = this.c;
                                             Integer var274 = (Integer)var273.aReturningObject();
                                             this.G = var274;
                                             int var831 = var56;
                                             if (var831 != 0) {
                                                break label619;
                                             }
                                          }

                                          AutoCart var832 = this;
                                          var563 = var832;
                                       }

                                       Object[] var278 = new Object[]{139369772315772L};
                                       AutoCart var277 = var563;
                                       var277.lReturningVoid(var278);
                                    }

                                    int var833 = var56;
                                    if (var833 != 0) {
                                       return;
                                    }
                                 }

                                 int var835 = var56;
                                 int var834 = this.G;
                                 int var566 = var834;
                                 int var564 = var834;
                                 if (var835 != 0) {
                                    int var836 = var564;
                                    int var565 = var836;
                                    int var837 = var565;
                                    if (var837 > 0) {
                                       this.G--;
                                       return;
                                    }

                                    Object[] var283 = new Object[]{53358626229123L};
                                    AutoCart var282 = this;
                                    var566 = var282.eReturningInt(var283);
                                 }

                                 int var956 = var566;
                                 int var838 = var56;
                                 if (var838 == 0) {
                                    return;
                                 }

                                 
                                 if (var839 == var840) {
                                    Object[] var286 = new Object[]{139369772315772L};
                                    AutoCart var285 = this;
                                    var285.lReturningVoid(var286);
                                    return;
                                 }

                                 MinecraftClient var288 = b;
                                 HitResult var965 = var288.crosshairTarget;
                                 int var841 = var56;
                                 label571:
                                 if (var841 != 0) {
                                    AutoCart var577;
                                    label593: {
                                       boolean var842 = var965 instanceof BlockHitResult;
                                       if (var842) {
                                          BlockHitResult var962 = (BlockHitResult)var965;
                                          int var843 = var56;
                                          if (var843 == 0) {
                                             break label571;
                                          }

                                          BlockHitResult var290 = var962;
                                          Direction var989 = var290.getSide();
                                          Direction var845 = Direction.UP;
                                          Direction var844 = var989;
                                          if (var844 == var845) {
                                             BlockHitResult var292 = var962;
                                             BlockPos var966 = var292.getBlockPos();
                                             Object[] var293 = new Object[]{43167644123091L};
                                             Vec3d var968 = RaycastUtil.bReturningVec3d(var293);
                                             Vec3d var65 = new Vec3d(this.A + 0.5, this.B + 0.5, this.C + 0.5);
                                             BlockPos var294 = var966;
                                             double var1033 = var294.getX() + 0.5;
                                             BlockPos var295 = var966;
                                             double var1038 = var295.getY() + 0.5;
                                             BlockPos var296 = var966;
                                             Vec3d var66 = new Vec3d(var1033, var1038, var296.getZ() + 0.5);
                                             Vec3d var298 = var65;
                                             Vec3d var297 = var968;
                                             double var67 = var297.distanceTo(var298);
                                             Vec3d var300 = var66;
                                             Vec3d var299 = var968;
                                             double var69 = var299.distanceTo(var300);
                                             int var846 = var56;
                                             if (var846 == 0) {
                                                break label571;
                                             }

                                             BlockPos var301 = var966;
                                             int var990 = var301.getY();
                                             Vec3d var302 = var968;
                                             double var303 = var302.y;
                                             int var848 = (int)Math.floor(var303);
                                             int var847 = var990;
                                             label588:
                                             if (var847 <= var848) {
                                                double var1047;
                                                int var991 = (var1047 = var69 - var67) == 0.0 ? 0 : (var1047 < 0.0 ? -1 : 1);
                                                int var850 = var56;
                                                int var849 = var991;
                                                int var571 = var849;
                                                int var567 = var849;
                                                if (var850 != 0) {
                                                   int var851 = var567;
                                                   int var568 = var851;
                                                   int var852 = var568;
                                                   if (var852 >= 0) {
                                                      break label588;
                                                   }

                                                   int var854 = var56;
                                                   AutoCart var853 = this;
                                                   var577 = var853;
                                                   AutoCart var569 = var853;
                                                   if (var854 == 0) {
                                                      break label593;
                                                   }

                                                   AutoCart var855 = var569;
                                                   AutoCart var570 = var855;
                                                   Object[] var310 = new Object[]{var966, 60740051216110L};
                                                   AutoCart var309 = var570;
                                                   byte var856 = ((byte)((var309.dReturningBoolean(var310)) ? 1 : 0));
                                                   var571 = var856;
                                                }

                                                int var857 = var571;
                                                label582:
                                                if (var857 == 0) {
                                                   MinecraftClient var312 = b;
                                                   BlockPos var314 = var966;
                                                   ClientWorld var313 = var312.world;
                                                   BlockState var315 = var313.getBlockState(var314);
                                                   boolean var992 = var315.isReplaceable();
                                                   int var859 = var56;
                                                   boolean var858 = var992;
                                                   boolean var576 = var858;
                                                   boolean var572 = var858;
                                                   if (var859 != 0) {
                                                      boolean var860 = var572;
                                                      boolean var573 = var860;
                                                      boolean var861 = var573;
                                                      if (var861) {
                                                         break label582;
                                                      }

                                                      int var863 = var56;
                                                      AutoCart var862 = this;
                                                      var577 = var862;
                                                      AutoCart var574 = var862;
                                                      if (var863 == 0) {
                                                         break label593;
                                                      }

                                                      AutoCart var864 = var574;
                                                      AutoCart var575 = var864;
                                                      BlockPos var319 = var966;
                                                      double var1031 = var319.getX() + 0.5;
                                                      BlockPos var320 = var966;
                                                      var1033 = var320.getY() + 1.0;
                                                      BlockPos var321 = var966;
                                                      var1038 = var321.getZ() + 0.5;
                                                      Object[] var1045 = new Object[]{null, null, null, 45522447051713L};
                                                      var1045[2] = var1038;
                                                      var1045[1] = var1033;
                                                      var1045[0] = var1031;
                                                      Object[] var323 = var1045;
                                                      AutoCart var322 = var575;
                                                      boolean var865 = var322.gReturningBoolean(var323);
                                                      var576 = var865;
                                                   }

                                                   boolean var866 = var576;
                                                   if (var866) {
                                                      Object[] var1040 = new Object[]{null, 72518082610550L};
                                                      var1040[0] = var956;
                                                      Object[] var325 = var1040;
                                                      InventoryUtil.aReturningVoid(var325);
                                                      Object[] var327 = new Object[]{var962, 30430898198534L};
                                                      AutoCart var326 = this;
                                                      var326.o(var327);
                                                   }
                                                }
                                             }
                                          }
                                       }

                                       var577 = this;
                                    }

                                    Object[] var330 = new Object[]{139369772315772L};
                                    AutoCart var329 = var577;
                                    var329.lReturningVoid(var330);
                                 }

                                 int var867 = var56;
                                 if (var867 != 0) {
                                    return;
                                 }
                              }

                              BooleanSetting var331 = this.p;
                              Boolean var332 = (Boolean)var331.aReturningObject();
                              int var993 = ((((java.lang.Boolean)(var332)).booleanValue() ? 1 : 0));
                              int var869 = var56;
                              byte var868 = (byte)var993;
                              int var580 = var868;
                              byte var578 = var868;
                              if (var869 != 0) {
                                 byte var870 = var578;
                                 byte var579 = var870;
                                 byte var871 = var579;
                                 if (var871 == 0) {
                                    Object[] var336 = new Object[0];
                                    AutoCart var335 = this;
                                    var335.jReturningVoid(var336);
                                    return;
                                 }

                                 var580 = this.G;
                              }

                              AutoCart var584;
                              label852: {
                                 int var873 = var56;
                                 int var872 = var580;
                                 int var583 = var872;
                                 int var581 = var872;
                                 if (var873 != 0) {
                                    int var874 = var581;
                                    if (var874 > 0) {
                                       this.G--;
                                       return;
                                    }

                                    int var876 = var56;
                                    AutoCart var875 = this;
                                    var584 = var875;
                                    AutoCart var582 = var875;
                                    if (var876 == 0) {
                                       break label852;
                                    }

                                    int var877 = var582.F;
                                    var583 = var877;
                                 }

                                 
                                 if (var878 != var879) {
                                    var993 = this.F;
                                    Object[] var1041 = new Object[]{null, 72518082610550L};
                                    var1041[0] = var993;
                                    Object[] var341 = var1041;
                                    InventoryUtil.aReturningVoid(var341);
                                 }

                                 var584 = this;
                              }

                              Object[] var344 = new Object[0];
                              AutoCart var343 = var584;
                              var343.jReturningVoid(var344);
                              int var880 = var56;
                              if (var880 != 0) {
                                 return;
                              }
                           }

                           int var882 = var56;
                           int var881 = this.G;
                           int var587 = var881;
                           int var585 = var881;
                           if (var882 != 0) {
                              int var883 = var585;
                              int var586 = var883;
                              int var884 = var586;
                              if (var884 > 0) {
                                 this.G--;
                                 return;
                              }

                              Object[] var349 = new Object[]{3394298381772L};
                              AutoCart var348 = this;
                              var587 = var348.fReturningInt(var349);
                           }

                           label854: {
                              Integer var963;
                              label554: {
                                 int var957 = var587;
                                 Object[] var350 = new Object[]{Items.BOW, 95321893129094L};
                                 var963 = InventoryUtil.aReturningBoxedInteger(var350);
                                 int var886 = var56;
                                 int var885 = var957;
                                 int var589 = var885;
                                 int var588 = var885;
                                 if (var886 != 0) {
                                    
                                    if (var887 == var888) {
                                       break label554;
                                    }

                                    int var889 = var957;
                                    var589 = var889;
                                 }

                                 Object[] var1042 = new Object[]{null, 72518082610550L};
                                 var1042[0] = var589;
                                 Object[] var353 = var1042;
                                 InventoryUtil.aReturningVoid(var353);
                                 this.I = true;
                                 int var890 = var56;
                                 if (var890 != 0) {
                                    break label854;
                                 }
                              }

                              int var892 = var56;
                              Integer var891 = var963;
                              Integer var592 = var891;
                              Integer var590 = var891;
                              if (var892 != 0) {
                                 Integer var893 = var590;
                                 Integer var591 = var893;
                                 Integer var894 = var591;
                                 if (var894 == null) {
                                    break label893;
                                 }

                                 var592 = var963;
                              }

                              Integer var356 = var592;
                              int var995 = var356;
                              Object[] var1043 = new Object[]{null, 72518082610550L};
                              var1043[0] = var995;
                              Object[] var357 = var1043;
                              InventoryUtil.aReturningVoid(var357);
                              this.I = false;
                              int var895 = var56;
                              if (var895 == 0) {
                                 break label893;
                              }
                           }

                           this.y = AutoCartState.USE_WEAPON;
                           int var896 = var56;
                           if (var896 != 0) {
                              return;
                           }
                        }

                        int var898 = var56;
                        AutoCart var897 = this;
                        AutoCart var598 = var897;
                        AutoCart var593 = var897;
                        if (var898 != 0) {
                           AutoCart var899 = var593;
                           AutoCart var594 = var899;
                           boolean var900 = var594.I;
                           if (var900) {
                              this.W = true;
                              MinecraftClient var363 = b;
                              MinecraftClient var364 = b;
                              Hand var367 = Hand.MAIN_HAND;
                              ClientPlayerEntity var366 = var364.player;
                              ClientPlayerInteractionManager var365 = var363.interactionManager;
                              var365.interactItem((PlayerEntity)var366, var367);
                              int var902 = var56;
                              AutoCart var901 = this;
                              AutoCart var597 = var901;
                              AutoCart var595 = var901;
                              if (var902 != 0) {
                                 AutoCart var903 = var595;
                                 AutoCart var596 = var903;
                                 boolean var904 = var596.Q;
                                 if (var904) {
                                    Object[] var10004 = new Object[]{null, 77090688812132L};
                                    var10004[0] = 1.0500001F;
                                    Object[] var371 = var10004;
                                    AutoCart var370 = this;
                                    var370.nReturningVoid(var371);
                                    int var905 = var56;
                                    if (var905 != 0) {
                                       return;
                                    }
                                 }

                                 AutoCart var906 = this;
                                 var597 = var906;
                              }

                              Object[] var375 = new Object[0];
                              AutoCart var374 = var597;
                              var374.jReturningVoid(var375);
                              int var907 = var56;
                              if (var907 != 0) {
                                 return;
                              }
                           }

                           MinecraftClient var376 = b;
                           GameOptions var377 = var376.options;
                           KeyBinding var378 = var377.useKey;
                           var378.setPressed(true);
                           MinecraftClient var380 = b;
                           MinecraftClient var381 = b;
                           Hand var384 = Hand.MAIN_HAND;
                           ClientPlayerEntity var383 = var381.player;
                           ClientPlayerInteractionManager var382 = var380.interactionManager;
                           var382.interactItem((PlayerEntity)var383, var384);
                           IntSetting var385 = this.d;
                           Integer var386 = (Integer)var385.aReturningObject();
                           this.G = var386;
                           AutoCart var908 = this;
                           var598 = var908;
                        }

                        var598.y = AutoCartState.CHARGE_BOW;
                        int var909 = var56;
                        if (var909 != 0) {
                           return;
                        }
                     }

                     MinecraftClient var388 = b;
                     GameOptions var389 = var388.options;
                     KeyBinding var390 = var389.useKey;
                     byte var996 = ((byte)((var390.isPressed()) ? 1 : 0));
                     int var911 = var56;
                     byte var910 = var996;
                     int var601 = var910;
                     byte var599 = var910;
                     if (var911 != 0) {
                        byte var912 = var599;
                        byte var600 = var912;
                        byte var913 = var600;
                        if (var913 == 0) {
                           MinecraftClient var393 = b;
                           GameOptions var394 = var393.options;
                           KeyBinding var395 = var394.useKey;
                           var395.setPressed(true);
                        }

                        MinecraftClient var398 = b;
                        ClientPlayerEntity var399 = var398.player;
                        var601 = var399.getItemUseTime();
                     }

                     Object[] var401 = new Object[]{61586312254362L};
                     AutoCart var400 = this;
                     int var915 = var400.gReturningInt(var401);
                     int var914 = var601;
                     if (var914 < var915) {
                        return;
                     }

                     this.P = 0;
                     this.y = AutoCartState.RELEASE_BOW;
                     int var916 = var56;
                     if (var916 != 0) {
                        return;
                     }
                  }

                  int var612;
                  label495: {
                     label855: {
                        RotationManager var997 = Prestige.o;
                        Object[] var404 = new Object[0];
                        RotationManager var403 = var997;
                        Rotation var958 = var403.cReturningdx_C0210(var404);
                        int var918 = var56;
                        Rotation var917 = this.V;
                        Rotation var603 = var917;
                        Rotation var602 = var917;
                        if (var918 != 0) {
                           Rotation var919 = var602;
                           if (var919 == null) {
                              break label855;
                           }

                           var603 = var958;
                        }

                        int var921 = var56;
                        Rotation var920 = var603;
                        Rotation var605 = var920;
                        Rotation var604 = var920;
                        if (var921 != 0) {
                           Rotation var922 = var604;
                           if (var922 == null) {
                              break label855;
                           }

                           var605 = var958;
                        }

                        Object[] var408 = new Object[0];
                        Rotation var407 = var605;
                        byte var998 = ((byte)((var407.aReturningBoolean(var408)) ? 1 : 0));
                        int var924 = var56;
                        byte var923 = var998;
                        var612 = var923;
                        byte var606 = var923;
                        if (var924 == 0) {
                           break label495;
                        }

                        byte var925 = var606;
                        if (var925 != 0) {
                           int var999 = this.P++;
                           int var927 = var56;
                           int var926 = var999;
                           var612 = var926;
                           int var607 = var926;
                           if (var927 == 0) {
                              break label495;
                           }

                           int var928 = var607;
                           int var608 = var928;
                           byte var930 = 10;
                           int var929 = var608;
                           if (var929 < var930) {
                              MinecraftClient var412 = b;
                              GameOptions var413 = var412.options;
                              int var932 = var56;
                              KeyBinding var931 = var413.useKey;
                              KeyBinding var611 = var931;
                              KeyBinding var609 = var931;
                              if (var932 != 0) {
                                 KeyBinding var933 = var609;
                                 KeyBinding var610 = var933;
                                 KeyBinding var415 = var610;
                                 boolean var934 = var415.isPressed();
                                 if (var934) {
                                    return;
                                 }

                                 MinecraftClient var417 = b;
                                 GameOptions var418 = var417.options;
                                 KeyBinding var935 = var418.useKey;
                                 var611 = var935;
                              }

                              KeyBinding var420 = var611;
                              var420.setPressed(true);
                              return;
                           }
                        }
                     }

                     MinecraftClient var422 = b;
                     ClientPlayerEntity var423 = var422.player;
                     var612 = var423.getItemUseTime();
                  }

                  float var615;
                  float var964;
                  Rotation var967;
                  label477: {
                     int var424 = var612;
                     var964 = BowItem.getPullProgress(var424);
                     RotationManager var1000 = Prestige.o;
                     Object[] var426 = new Object[0];
                     RotationManager var425 = var1000;
                     var967 = var425.bReturningdx_C0210(var426);
                     int var937 = var56;
                     Rotation var936 = var967;
                     Rotation var614 = var936;
                     Rotation var613 = var936;
                     if (var937 != 0) {
                        Rotation var938 = var613;
                        if (var938 == null) {
                           MinecraftClient var430 = b;
                           ClientPlayerEntity var431 = var430.player;
                           var615 = var431.getYaw();
                           break label477;
                        }

                        var614 = var967;
                     }

                     Object[] var429 = new Object[0];
                     Rotation var428 = var614;
                     float var939 = var428.aReturningFloat(var429);
                     var615 = var939;
                  }

                  float var618;
                  float var969;
                  label471: {
                     var969 = var615;
                     int var941 = var56;
                     Rotation var940 = var967;
                     Rotation var617 = var940;
                     Rotation var616 = var940;
                     if (var941 != 0) {
                        Rotation var942 = var616;
                        if (var942 == null) {
                           MinecraftClient var435 = b;
                           ClientPlayerEntity var436 = var435.player;
                           var618 = var436.getPitch();
                           break label471;
                        }

                        var617 = var967;
                     }

                     Object[] var434 = new Object[0];
                     Rotation var433 = var617;
                     float var943 = var433.bReturningFloat(var434);
                     var618 = var943;
                  }

                  AutoCart var622;
                  label856: {
                     float var970 = var618;
                     Object[] var438 = new Object[]{46418886754813L};
                     AutoCart var437 = this;
                     var437.kReturningVoid(var438);
                     MinecraftClient var439 = b;
                     ClientPlayerEntity var440 = var439.player;
                     boolean var1001 = var440.isUsingItem();
                     int var945 = var56;
                     boolean var944 = var1001;
                     boolean var621 = var944;
                     boolean var619 = var944;
                     if (var945 != 0) {
                        boolean var946 = var619;
                        if (var946) {
                           this.W = true;
                           MinecraftClient var442 = b;
                           MinecraftClient var443 = b;
                           ClientPlayerEntity var445 = var443.player;
                           ClientPlayerInteractionManager var444 = var442.interactionManager;
                           var444.stopUsingItem((PlayerEntity)var445);
                        }

                        int var948 = var56;
                        AutoCart var947 = this;
                        var622 = var947;
                        AutoCart var620 = var947;
                        if (var948 == 0) {
                           break label856;
                        }

                        boolean var949 = var620.Q;
                        var621 = var949;
                     }

                     boolean var950 = var621;
                     if (var950) {
                        Object[] var1046 = new Object[]{null, null, null, 114450665889585L};
                        var1046[2] = var970;
                        var1046[1] = var969;
                        var1046[0] = var964;
                        Object[] var449 = var1046;
                        AutoCart var448 = this;
                        var448.mReturningVoid(var449);
                        int var951 = var56;
                        if (var951 != 0) {
                           return;
                        }
                     }

                     AutoCart var952 = this;
                     var622 = var952;
                  }

                  Object[] var453 = new Object[0];
                  AutoCart var452 = var622;
                  var452.jReturningVoid(var453);
                  return;
               }

               Object[] var359 = new Object[0];
               AutoCart var358 = this;
               var358.jReturningVoid(var359);
               return;
            }

            Object[] var247 = new Object[0];
            AutoCart var246 = var553;
            var246.jReturningVoid(var247);
            return;
         }

         Object[] var77 = new Object[0];
         AutoCart var76 = this;
         var76.jReturningVoid(var77);
      }
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      AutoCart var29;
      label50: {
         int var4;
         label48: {
            long var2 = (Long)var1[0];
            long var10000 = 106857869378349L ^ var2;
            var4 = Event.bReturningInt();
            int var35 = var4;
            AutoCart var34 = this;
            AutoCart var27 = var34;
            AutoCart var26 = var34;
            if (var35 == 0) {
               boolean var36 = var26.E;
               if (!var36) {
                  break label48;
               }

               AutoCart var37 = this;
               var27 = var37;
            }

            int var39 = var4;
            AutoCart var38 = var27;
            var29 = var38;
            AutoCart var28 = var38;
            if (var39 != 0) {
               break label50;
            }

            BlockPos var40 = var28.D;
            if (var40 != null) {
               BlockPos var10 = this.D;
               this.A = var10.getX();
               BlockPos var11 = this.D;
               this.B = var11.getY() + 1;
               AutoCart var41 = this;
               var29 = var41;
               break label50;
            }
         }

         MinecraftClient var15 = b;
         HitResult var6 = var15.crosshairTarget;
         int var43 = var4;
         HitResult var42 = var6;
         HitResult var31 = var42;
         HitResult var30 = var42;
         if (var43 == 0) {
            boolean var44 = var30 instanceof BlockHitResult;
            if (!var44) {
               return null;
            }

            HitResult var45 = var6;
            var31 = var45;
         }

         BlockHitResult var5 = (BlockHitResult)var31;
         int var46 = var4;
         if (var46 == 0) {
            int var48 = var4;
            BlockHitResult var47 = var5;
            BlockHitResult var33 = var47;
            BlockHitResult var32 = var47;
            if (var48 == 0) {
               BlockHitResult var19 = var32;
               Direction var52 = var19.getSide();
               Direction var50 = Direction.UP;
               Direction var49 = var52;
               if (var49 != var50) {
                  return null;
               }

               var33 = var5;
            }

            BlockHitResult var22 = var33;
            BlockPos var51 = var22.getBlockPos();
            BlockPos var23 = var51;
            this.A = var23.getX();
            BlockPos var24 = var51;
            this.B = var24.getY() + 1;
            BlockPos var25 = var51;
            this.C = var25.getZ();
            return var5;
         }

         return null;
      }

      BlockPos var13 = this.D;
      var29.C = var13.getZ();
      double var10004 = this.A + 0.5;
      BlockPos var14 = this.D;
      return new BlockHitResult(new Vec3d(var10004, var14.getY() + 1.0, this.C + 0.5), Direction.UP, this.D, false);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 138426539507609L;
      long var6 = var2 ^ 37187903518836L;
      long var8 = var2 ^ 98218082897058L;
      long var10 = var2 ^ 139410548074966L;
      long var12 = var2 ^ 131846930854388L;
      long var14 = var2 ^ 77379818547405L;
      long var16 = var2 ^ 83347268631053L;
      int var18 = Event.bReturningInt();
      int var230 = var18;
      MinecraftClient var229 = b;
      MinecraftClient var152 = var229;
      MinecraftClient var151 = var229;
      if (var230 == 0) {
         MinecraftClient var23 = var151;
         ClientPlayerEntity var231 = var23.player;
         if (var231 == null) {
            return null;
         }

         MinecraftClient var232 = b;
         var152 = var232;
      }

      AutoCart var167;
      label293: {
         MinecraftClient var26 = var152;
         int var234 = var18;
         ClientWorld var233 = var26.world;
         Object var155 = var233;
         ClientWorld var153 = var233;
         if (var234 == 0) {
            ClientWorld var235 = var153;
            if (var235 == null) {
               return null;
            }

            int var237 = var18;
            AutoCart var236 = this;
            var167 = var236;
            AutoCart var154 = var236;
            if (var237 != 0) {
               break label293;
            }

            BooleanSetting var29 = var154.m;
            Object var238 = var29.aReturningObject();
            var155 = var238;
         }

         Boolean var31 = (Boolean)var155;
         boolean var239 = var31;
         if (var239) {
            int var241 = var18;
            AutoCart var240 = this;
            var167 = var240;
            AutoCart var156 = var240;
            if (var241 != 0) {
               break label293;
            }

            AutoCart var242 = var156;
            AutoCart var157 = var242;
            AutoCartState var244 = AutoCartState.IDLE;
            AutoCartState var243 = var157.y;
            if (var243 == var244) {
               int var246 = var18;
               AutoCart var245 = this;
               var167 = var245;
               AutoCart var158 = var245;
               if (var246 != 0) {
                  break label293;
               }

               AutoCart var247 = var158;
               AutoCart var159 = var247;
               Object[] var36 = new Object[]{var12};
               AutoCart var35 = var159;
               boolean var248 = var35.iReturningVoid(var36);
               label272:
               if (var248) {
                  TntMinecartEntity var163;
                  label270: {
                     int var250 = var18;
                     AutoCart var249 = this;
                     AutoCart var162 = var249;
                     AutoCart var160 = var249;
                     if (var250 == 0) {
                        AutoCart var251 = var160;
                        AutoCart var161 = var251;
                        TntMinecartEntity var252 = var161.T;
                        if (var252 != null) {
                           TntMinecartEntity var253 = this.T;
                           var163 = var253;
                           break label270;
                        }

                        var162 = this;
                     }

                     Object[] var42 = new Object[]{var6};
                     AutoCart var41 = var162;
                     var163 = var41.aReturningTntMinecartEntity(var42);
                  }

                  TntMinecartEntity var19 = var163;
                  int var255 = var18;
                  TntMinecartEntity var254 = var19;
                  TntMinecartEntity var165 = var254;
                  TntMinecartEntity var164 = var254;
                  if (var255 == 0) {
                     TntMinecartEntity var256 = var164;
                     if (var256 == null) {
                        break label272;
                     }

                     var165 = var19;
                  }

                  Object[] var44 = new Object[]{var165, var16};
                  Vec3d var10000 = RaycastUtil.aReturningVec3d(var44);
                  double var48 = 0.25;
                  Vec3d var45 = var10000;
                  Vec3d var20 = var45.add(var46, var48, var50);
                  int var258 = var18;
                  AutoCart var257 = this;
                  var167 = var257;
                  AutoCart var166 = var257;
                  if (var258 != 0) {
                     break label293;
                  }

                  Object[] var10005 = new Object[]{null, null, var10};
                  var10005[1] = 1.0F;
                  var10005[0] = var20;
                  Object[] var53 = var10005;
                  AutoCart var52 = var166;
                  Rotation var21 = var52.bReturningdx_C0210(var53);
                  Rotation var259 = var21;
                  if (var259 != null) {
                     Object[] var55 = new Object[0];
                     Rotation var54 = var21;
                     float var390 = var54.aReturningFloat(var55);
                     MinecraftClient var56 = b;
                     ClientPlayerEntity var57 = var56.player;
                     float var391 = var390 - var57.getYaw();
                     Object[] var10003 = new Object[]{null, var4};
                     var10003[0] = var391;
                     Object[] var58 = var10003;
                     float var59 = RotationUtil.bReturningFloat(var58);
                     float var22 = Math.abs(var59);
                     FloatSetting var60 = this.s;
                     Float var61 = (Float)var60.aReturningObject();
                     float var409;
                     int var260 = (var409 = var22 - var61) == 0.0F ? 0 : (var409 < 0.0F ? -1 : 1);
                     if (var260 <= 0) {
                        return var21;
                     }
                  }
               }
            }
         }

         var167 = this;
      }

      int var213;
      label254: {
         Object var212;
         label296: {
            int var263 = var18;
            AutoCartWeaponMode var262 = AutoCartWeaponMode.BOW;
            AutoCartWeaponMode var261 = var167.z;
            AutoCartWeaponMode var185 = var261;
            AutoCartWeaponMode var186 = var262;
            AutoCartWeaponMode var168 = var261;
            AutoCartWeaponMode var169 = var262;
            if (var263 == 0) {
               AutoCart var183;
               label250: {
                  AutoCartWeaponMode var265 = var169;
                  AutoCartWeaponMode var264 = var168;
                  if (var264 == var265) {
                     int var267 = var18;
                     AutoCart var266 = this;
                     var183 = var266;
                     AutoCart var170 = var266;
                     if (var267 != 0) {
                        break label250;
                     }

                     AutoCart var268 = var170;
                     AutoCart var171 = var268;
                     boolean var269 = var171.Q;
                     if (var269) {
                        int var271 = var18;
                        AutoCart var270 = this;
                        var183 = var270;
                        AutoCart var172 = var270;
                        if (var271 != 0) {
                           break label250;
                        }

                        AutoCart var272 = var172;
                        AutoCart var173 = var272;
                        BlockPos var273 = var173.R;
                        label245:
                        if (var273 != null) {
                           AutoCart var180;
                           int var275 = var18;
                           AutoCart var274 = this;
                           var180 = var274;
                           AutoCart var174 = var274;
                           label243:
                           if (var275 == 0) {
                              AutoCart var276 = var174;
                              AutoCart var175 = var276;
                              AutoCartState var278 = AutoCartState.USE_WEAPON;
                              AutoCartState var277 = var175.y;
                              if (var277 != var278) {
                                 int var280 = var18;
                                 AutoCart var279 = this;
                                 var180 = var279;
                                 AutoCart var176 = var279;
                                 if (var280 != 0) {
                                    break label243;
                                 }

                                 AutoCart var281 = var176;
                                 AutoCart var177 = var281;
                                 AutoCartState var283 = AutoCartState.CHARGE_BOW;
                                 AutoCartState var282 = var177.y;
                                 if (var282 != var283) {
                                    int var285 = var18;
                                    AutoCart var284 = this;
                                    var183 = var284;
                                    AutoCart var178 = var284;
                                    if (var285 != 0) {
                                       break label250;
                                    }

                                    AutoCart var286 = var178;
                                    AutoCart var179 = var286;
                                    AutoCartState var288 = AutoCartState.RELEASE_BOW;
                                    AutoCartState var287 = var179.y;
                                    if (var287 != var288) {
                                       break label245;
                                    }
                                 }
                              }

                              AutoCart var289 = this;
                              var180 = var289;
                           }

                           Object[] var76 = new Object[]{var8};
                           AutoCart var75 = var180;
                           float var379 = var75.bReturningFloat(var76);
                           float var410;
                           int var290 = (var410 = var379 - 0.0F) == 0.0F ? 0 : (var410 < 0.0F ? -1 : 1);
                           Rotation var181;
                           if (var290 > 0) {
                              BlockPos var77 = this.R;
                              Vec3d var10001 = var77.toCenterPos();
                              Object[] var407 = new Object[]{null, null, var10};
                              var407[1] = var379;
                              var407[0] = var10001;
                              Object[] var79 = var407;
                              AutoCart var78 = this;
                              Rotation var291 = var78.bReturningdx_C0210(var79);
                              var181 = var291;
                           } else {
                              var181 = null;
                           }

                           Rotation var382 = var181;
                           int var293 = var18;
                           AutoCart var292 = this;
                           var183 = var292;
                           AutoCart var182 = var292;
                           if (var293 != 0) {
                              break label250;
                           }

                           var182.V = var382;
                           Rotation var294 = var382;
                           if (var294 != null) {
                              Object[] var83 = new Object[0];
                              Rotation var82 = var382;
                              float var392 = var82.aReturningFloat(var83);
                              MinecraftClient var84 = b;
                              ClientPlayerEntity var85 = var84.player;
                              var392 -= var85.getYaw();
                              Object[] var403 = new Object[]{null, var4};
                              var403[0] = var392;
                              Object[] var86 = var403;
                              float var87 = RotationUtil.bReturningFloat(var86);
                              float var385 = Math.abs(var87);
                              FloatSetting var88 = this.s;
                              Float var89 = (Float)var88.aReturningObject();
                              float var411;
                              int var295 = (var411 = var385 - var89) == 0.0F ? 0 : (var411 < 0.0F ? -1 : 1);
                              if (var295 <= 0) {
                                 return var382;
                              }
                           }
                        }
                     }
                  }

                  var183 = this;
               }

               int var297 = var18;
               AutoCartWeaponMode var296 = var183.z;
               var212 = var296;
               AutoCartWeaponMode var184 = var296;
               if (var297 != 0) {
                  break label296;
               }

               AutoCartWeaponMode var299 = AutoCartWeaponMode.BOW;
               AutoCartWeaponMode var298 = var184;
               var185 = var298;
               var186 = var299;
            }

            AutoCartWeaponMode var301 = var186;
            AutoCartWeaponMode var300 = var185;
            if (var300 == var301) {
               int var303 = var18;
               byte var302 = ((byte)((this.Q) ? 1 : 0));
               var213 = var302;
               byte var187 = var302;
               if (var303 != 0) {
                  break label254;
               }

               byte var304 = var187;
               byte var188 = var304;
               byte var305 = var188;
               label220:
               if (var305 == 0) {
                  label300: {
                     int var308 = var18;
                     AutoCartState var307 = AutoCartState.SWITCH_SAFE;
                     AutoCartState var306 = this.y;
                     AutoCartState var193 = var306;
                     AutoCartState var194 = var307;
                     AutoCartState var189 = var306;
                     AutoCartState var190 = var307;
                     if (var308 == 0) {
                        AutoCartState var310 = var190;
                        AutoCartState var309 = var189;
                        AutoCartState var191 = var309;
                        AutoCartState var192 = var310;
                        AutoCartState var312 = var192;
                        AutoCartState var311 = var191;
                        if (var311 == var312) {
                           break label300;
                        }

                        AutoCartState var314 = AutoCartState.SWITCH_WEAPON;
                        AutoCartState var313 = this.y;
                        var193 = var313;
                        var194 = var314;
                     }

                     int var317 = var18;
                     AutoCartState var316 = var194;
                     AutoCartState var315 = var193;
                     AutoCartState var197 = var315;
                     AutoCartState var198 = var316;
                     AutoCartState var195 = var315;
                     AutoCartState var196 = var316;
                     if (var317 == 0) {
                        AutoCartState var319 = var196;
                        AutoCartState var318 = var195;
                        if (var318 == var319) {
                           break label300;
                        }

                        AutoCartState var321 = AutoCartState.USE_WEAPON;
                        AutoCartState var320 = this.y;
                        var197 = var320;
                        var198 = var321;
                     }

                     int var324 = var18;
                     AutoCartState var323 = var198;
                     AutoCartState var322 = var197;
                     AutoCartState var201 = var322;
                     AutoCartState var202 = var323;
                     AutoCartState var199 = var322;
                     AutoCartState var200 = var323;
                     if (var324 == 0) {
                        AutoCartState var326 = var200;
                        AutoCartState var325 = var199;
                        if (var325 == var326) {
                           break label300;
                        }

                        AutoCartState var328 = AutoCartState.CHARGE_BOW;
                        AutoCartState var327 = this.y;
                        var201 = var327;
                        var202 = var328;
                     }

                     int var331 = var18;
                     AutoCartState var330 = var202;
                     AutoCartState var329 = var201;
                     AutoCartState var207 = var329;
                     AutoCartState var208 = var330;
                     AutoCartState var203 = var329;
                     AutoCartState var204 = var330;
                     if (var331 == 0) {
                        AutoCartState var333 = var204;
                        AutoCartState var332 = var203;
                        if (var332 == var333) {
                           break label300;
                        }

                        int var335 = var18;
                        AutoCartState var334 = this.y;
                        var212 = var334;
                        AutoCartState var205 = var334;
                        if (var335 != 0) {
                           break label296;
                        }

                        AutoCartState var336 = var205;
                        AutoCartState var206 = var336;
                        AutoCartState var338 = AutoCartState.RELEASE_BOW;
                        AutoCartState var337 = var206;
                        var207 = var337;
                        var208 = var338;
                     }

                     AutoCartState var340 = var208;
                     AutoCartState var339 = var207;
                     if (var339 != var340) {
                        break label220;
                     }
                  }

                  Vec3d var380 = new Vec3d(this.A + 0.5, this.B + 0.5, this.C + 0.5);
                  Object[] var105 = new Object[]{var8};
                  AutoCart var104 = this;
                  float var383 = var104.bReturningFloat(var105);
                  float var412;
                  int var341 = (var412 = var383 - 0.0F) == 0.0F ? 0 : (var412 < 0.0F ? -1 : 1);
                  Rotation var209;
                  if (var341 > 0) {
                     Object[] var408 = new Object[]{null, null, var10};
                     var408[1] = var383;
                     var408[0] = var380;
                     Object[] var107 = var408;
                     AutoCart var106 = this;
                     Rotation var342 = var106.bReturningdx_C0210(var107);
                     var209 = var342;
                  } else {
                     var209 = null;
                  }

                  Rotation var386 = var209;
                  this.V = var386;
                  int var344 = var18;
                  Rotation var343 = var386;
                  var212 = var343;
                  Rotation var210 = var343;
                  if (var344 != 0) {
                     break label296;
                  }

                  Rotation var345 = var210;
                  if (var345 != null) {
                     Object[] var111 = new Object[0];
                     Rotation var110 = var386;
                     float var394 = var110.aReturningFloat(var111);
                     MinecraftClient var112 = b;
                     ClientPlayerEntity var113 = var112.player;
                     var394 -= var113.getYaw();
                     Object[] var404 = new Object[]{null, var4};
                     var404[0] = var394;
                     Object[] var114 = var404;
                     float var115 = RotationUtil.bReturningFloat(var114);
                     float var388 = Math.abs(var115);
                     FloatSetting var116 = this.s;
                     Float var117 = (Float)var116.aReturningObject();
                     float var413;
                     int var396 = (var413 = var388 - var117) == 0.0F ? 0 : (var413 < 0.0F ? -1 : 1);
                     int var347 = var18;
                     int var346 = var396;
                     var213 = var346;
                     int var211 = var346;
                     if (var347 != 0) {
                        break label254;
                     }

                     int var348 = var211;
                     if (var348 <= 0) {
                        return var386;
                     }
                  }
               }
            }

            BooleanSetting var120 = this.r;
            var212 = var120.aReturningObject();
         }

         Boolean var121 = (Boolean)var212;
         var213 = ((((java.lang.Boolean)(var121)).booleanValue() ? 1 : 0));
      }

      int var350 = var18;
      int var349 = var213;
      int var215 = var349;
      int var214 = var349;
      if (var350 == 0) {
         int var351 = var214;
         if (var351 == 0) {
            return null;
         }

         ModeSetting var123 = this.k;
         String var397 = (String)var123.aReturningObject();
         short var401 = 3748;
         long var10002 = 7769489712664640751L ^ var2;
         String var125 = "Trajectory";
         String var124 = var397;
         byte var352 = ((byte)((var124.equals(var125)) ? 1 : 0));
         var215 = var352;
      }

      AutoCart var220;
      label303: {
         int var354 = var18;
         int var353 = var215;
         int var219 = var353;
         int var216 = var353;
         if (var354 == 0) {
            int var355 = var216;
            if (var355 == 0) {
               return null;
            }

            int var357 = var18;
            AutoCart var356 = this;
            var220 = var356;
            AutoCart var217 = var356;
            if (var357 != 0) {
               break label303;
            }

            AutoCart var358 = var217;
            AutoCart var218 = var358;
            byte var359 = ((byte)((var218.E) ? 1 : 0));
            var219 = var359;
         }

         int var360 = var219;
         if (var360 == 0) {
            return null;
         }

         var220 = this;
      }

      int var362 = var18;
      AutoCart var361 = var220;
      AutoCart var222 = var361;
      AutoCart var221 = var361;
      if (var362 == 0) {
         BlockPos var363 = var221.D;
         if (var363 == null) {
            return null;
         }

         AutoCart var364 = this;
         var222 = var364;
      }

      AutoCart var226;
      int var366 = var18;
      AutoCart var365 = var222;
      var226 = var365;
      AutoCart var223 = var365;
      label162:
      if (var366 == 0) {
         AutoCartState var368 = AutoCartState.SWITCH_RAIL;
         AutoCartState var367 = var223.y;
         if (var367 != var368) {
            int var370 = var18;
            AutoCart var369 = this;
            var226 = var369;
            AutoCart var224 = var369;
            if (var370 != 0) {
               break label162;
            }

            AutoCart var371 = var224;
            AutoCart var225 = var371;
            AutoCartState var373 = AutoCartState.SWITCH_CART;
            AutoCartState var372 = var225.y;
            if (var372 != var373) {
               return null;
            }
         }

         AutoCart var374 = this;
         var226 = var374;
      }

      BlockPos var136 = var226.D;
      BlockPos var381 = var136.up();
      BlockPos var137 = var381;
      double var402 = var137.getX() + 0.5;
      BlockPos var138 = var381;
      double var405 = var138.getY() + 0.5;
      BlockPos var139 = var381;
      Vec3d var384 = new Vec3d(var402, var405, var139.getZ() + 0.5);
      RotationManager var398 = Prestige.o;
      Object[] var141 = new Object[]{var384, var14};
      RotationManager var140 = var398;
      Rotation var387 = var140.aReturningdx_C0210(var141);
      int var376 = var18;
      Rotation var375 = var387;
      Rotation var228 = var375;
      Rotation var227 = var375;
      if (var376 == 0) {
         Rotation var377 = var227;
         if (var377 == null) {
            return null;
         }

         var228 = var387;
      }

      Object[] var144 = new Object[0];
      Rotation var143 = var228;
      float var399 = var143.aReturningFloat(var144);
      MinecraftClient var145 = b;
      ClientPlayerEntity var146 = var145.player;
      float var400 = var399 - var146.getYaw();
      Object[] var406 = new Object[]{null, var4};
      var406[0] = var400;
      Object[] var147 = var406;
      float var148 = RotationUtil.bReturningFloat(var147);
      float var389 = Math.abs(var148);
      FloatSetting var149 = this.s;
      Float var150 = (Float)var149.aReturningObject();
      float var414;
      int var378 = (var414 = var389 - var150) == 0.0F ? 0 : (var414 < 0.0F ? -1 : 1);
      return var378 <= 0 ? var387 : null;
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 139839860118360L ^ 45206472387703L;
      var10001 = 139839860118360L ^ 77561781471599L;
      var10001 = 139839860118360L ^ 4229605385368L;
      var10001 = 139839860118360L ^ 34437115249500L;
      var10001 = 139839860118360L ^ 138438260521784L;
      int var14 = Event.cReturningInt();
      BooleanSetting var30 = this.t;
      Boolean var31 = (Boolean)var30.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var31)).booleanValue() ? 1 : 0));
      int var102 = var14;
      boolean var101 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var87 = var101;
      boolean var86 = var101;
      if (var102 != 0) {
         boolean var103 = var86;
         if (!var103) {
            return;
         }

         ModeSetting var33 = this.k;
         String var131 = (String)var33.aReturningObject();
         String var35 = "Trajectory";
         String var34 = var131;
         var87 = var34.equals(var35);
      }

      boolean var104 = var87;
      if (var104) {
         int var106 = var14;
         MinecraftClient var105 = b;
         MinecraftClient var89 = var105;
         MinecraftClient var88 = var105;
         if (var106 != 0) {
            MinecraftClient var36 = var88;
            ClientPlayerEntity var107 = var36.player;
            if (var107 == null) {
               return;
            }

            MinecraftClient var108 = b;
            var89 = var108;
         }

         MinecraftClient var39 = var89;
         ClientWorld var109 = var39.world;
         if (var109 != null) {
            Object[] var42 = new Object[]{94774670032687L};
            AutoCart var41 = this;
            boolean var110 = var41.kReturningBoolean(var42);
            if (var110) {
               Rotation var15;
               float var92;
               label80: {
                  RotationManager var132 = Prestige.o;
                  Object[] var45 = new Object[0];
                  RotationManager var44 = var132;
                  var15 = var44.bReturningdx_C0210(var45);
                  int var112 = var14;
                  Rotation var111 = var15;
                  Rotation var91 = var111;
                  Rotation var90 = var111;
                  if (var112 != 0) {
                     Rotation var113 = var90;
                     if (var113 == null) {
                        MinecraftClient var49 = b;
                        ClientPlayerEntity var50 = var49.player;
                        var92 = var50.getYaw();
                        break label80;
                     }

                     var91 = var15;
                  }

                  Object[] var48 = new Object[0];
                  Rotation var47 = var91;
                  float var114 = var47.aReturningFloat(var48);
                  var92 = var114;
               }

               float var16;
               float var95;
               label74: {
                  var16 = var92;
                  int var116 = var14;
                  Rotation var115 = var15;
                  Rotation var94 = var115;
                  Rotation var93 = var115;
                  if (var116 != 0) {
                     Rotation var117 = var93;
                     if (var117 == null) {
                        MinecraftClient var54 = b;
                        ClientPlayerEntity var55 = var54.player;
                        var95 = var55.getPitch();
                        break label74;
                     }

                     var94 = var15;
                  }

                  Object[] var53 = new Object[0];
                  Rotation var52 = var94;
                  float var118 = var52.bReturningFloat(var53);
                  var95 = var118;
               }

               float var17 = var95;
               MinecraftClient var56 = b;
               ClientPlayerEntity var57 = var56.player;
               ItemStack var19 = var57.getMainHandStack();
               ItemStack var58 = var19;
               Item var133 = var58.getItem();
               Item var120 = Items.BOW;
               Item var119 = var133;
               float var18;
               if (var119 == var120) {
                  MinecraftClient var59 = b;
                  ClientPlayerEntity var60 = var59.player;
                  var10000 = ((byte)((var60.isUsingItem()) ? 1 : 0));
                  int var122 = var14;
                  byte var121 = var10000;
                  int var98 = var121;
                  byte var96 = var121;
                  if (var122 != 0) {
                     byte var123 = var96;
                     byte var97 = var123;
                     byte var124 = var97;
                     if (var124 == 0) {
                        return;
                     }

                     MinecraftClient var63 = b;
                     ClientPlayerEntity var64 = var63.player;
                     var98 = var64.getItemUseTime();
                  }

                  int var65 = var98;
                  var18 = BowItem.getPullProgress(var65);
                  float var144;
                  int var125 = (var144 = var18 - 0.05F) == 0.0F ? 0 : (var144 < 0.0F ? -1 : 1);
                  if (var125 < 0) {
                     return;
                  }
               } else {
                  Object[] var68 = new Object[]{var19, 3056580651104L};
                  AutoCart var67 = this;
                  boolean var126 = var67.eReturningBoolean(var68);
                  if (!var126) {
                     return;
                  }

                  var18 = 1.0500001F;
                  int var127 = var14;
                  if (var127 == 0) {
                     return;
                  }
               }

               Object[] var10006 = new Object[]{null, null, null, 63384110160439L};
               var10006[2] = var18;
               var10006[1] = var17;
               var10006[0] = var16;
               Object[] var71 = var10006;
               AutoCart var70 = this;
               BlockPos var20 = var70.aReturningBlockPos(var71);
               int var129 = var14;
               BlockPos var128 = var20;
               BlockPos var100 = var128;
               BlockPos var99 = var128;
               if (var129 != 0) {
                  BlockPos var130 = var99;
                  if (var130 == null) {
                     return;
                  }

                  BlockPos var73 = var20;
                  var100 = var73.up();
               }

               BlockPos var21 = var100;
               BlockPos var74 = var21;
               float var22 = var74.getX();
               BlockPos var75 = var21;
               float var23 = var75.getY();
               BlockPos var76 = var21;
               float var24 = var76.getZ();
               float var25 = var22 + 1.0F;
               float var26 = var23 + 1.0F;
               float var27 = var24 + 1.0F;
               ColorSetting var77 = this.u;
               Color var28 = (Color)var77.aReturningObject();
               Color var78 = var28;
               int var10002 = var78.getRed();
               Color var79 = var28;
               int var10003 = var79.getGreen();
               Color var80 = var28;
               int var10004 = var80.getBlue();
               short var10005 = 255;
               Color var81 = var28;
               int var83 = var81.getAlpha() + 100;
               Color var29 = new Color(var10002, var10003, var10004, Math.min(255, var83));
               RenderContext var135 = var1.b;
               MeshBufferManager var141 = var1.a;
               Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var28, 137403672065984L};
               var10011[7] = var27;
               var10011[6] = var26;
               var10011[5] = var25;
               var10011[4] = var24;
               var10011[3] = var23;
               var10011[2] = var22;
               var10011[1] = var141;
               var10011[0] = var135;
               Object[] var84 = var10011;
               ShapeRenderer.hReturningVoid(var84);
               RenderContext var136 = var1.b;
               MeshBufferManager var142 = var1.a;
               var10011 = new Object[]{null, null, null, null, null, null, null, null, var29, 106090074574852L};
               var10011[7] = var27;
               var10011[6] = var26;
               var10011[5] = var25;
               var10011[4] = var24;
               var10011[3] = var23;
               var10011[2] = var22;
               var10011[1] = var142;
               var10011[0] = var136;
               Object[] var85 = var10011;
               ShapeRenderer.gReturningVoid(var85);
            }
         }
      }
   }

   private void lambda$onTick$10(BlockHitResult var1) {
      long var10001 = 61546455524727L ^ 48742921076081L;
      Object[] var7 = new Object[]{var1, 30430898198534L};
      AutoCart var6 = this;
      var6.o(var7);
   }

   private static boolean lambda$solveShotRotation$9(double var0, float[] var2) {
      int var5 = Event.bReturningInt();
      double var13;
      int var10000 = (var13 = var2[1] - var0) == 0.0 ? 0 : (var13 < 0.0 ? -1 : 1);
      int var10 = var5;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      if (var10 == 0) {
         int var11 = var6;
         if (var11 <= 0) {
            return false;
         }

         var7 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private boolean lambda$new$8(Color var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.k;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Trajectory";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.t;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$7(Boolean var1) {
      ModeSetting var4 = this.k;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Trajectory";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$6(Float var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.k;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Trajectory";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.r;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$5(Boolean var1) {
      ModeSetting var4 = this.k;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Trajectory";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$4(Integer var1) {
      BooleanSetting var4 = this.m;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Float var1) {
      BooleanSetting var4 = this.m;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Boolean var1) {
      int var4 = Event.cReturningInt();
      IntSetting var5 = this.g;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 != 0) {
         byte var13 = 1;
         int var12 = var7;
         if (var12 > var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$1(Float var1) {
      int var4 = Event.cReturningInt();
      IntSetting var5 = this.g;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 != 0) {
         byte var13 = 1;
         int var12 = var7;
         if (var12 > var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$0(Integer var1) {
      int var4 = Event.cReturningInt();
      IntSetting var5 = this.g;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 != 0) {
         byte var13 = 1;
         int var12 = var7;
         if (var12 > var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   static {

      {

      f();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(77492661253332L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[2];
      String var15 = "ÎÖ\u0083\u009co~ÎÆ\u009dIúå\u008bå\u0095µê\u0086I-.ËÕ\u001e \f¯\u0007F\u008eË¸r¬á\r^\u0097ø\u009b×Îê/S¤ýù^r\u009añ\u0083\u008b3;¢";
      int var17 = "ÎÖ\u0083\u009co~ÎÆ\u009dIúå\u008bå\u0095µê\u0086I-.ËÕ\u001e \f¯\u0007F\u008eË¸r¬á\r^\u0097ø\u009b×Îê/S¤ýù^r\u009añ\u0083\u008b3;¢".length();
      char var14 = 24;
      int var13 = -1;

      while (true) {
         byte[] var19 = var11.doFinal(var15.substring(++var13, var13 + var14).getBytes("ISO-8859-1"));
         String var37 = b(var19).intern();
         int var10001 = -1;
         var18[var16++] = var37;
         if ((var13 += var14) >= var17) {
            Z = var18;
            ab = new String[2];
            jb = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(77492661253332L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[9];
            String var4 = "r&8t\u0003µ\u0089\u0084ó%ì\u0017Ã\u0018(¼V\\Ã<n\n¦+`H_¢çnËÎxªiÀoÅ\u0087÷\u000eÿJSSæ5\u0097ÿó\u0001È9\u000bX\u0005";
            int var5 = "r&8t\u0003µ\u0089\u0084ó%ì\u0017Ã\u0018(¼V\\Ã<n\n¦+`H_¢çnËÎxªiÀoÅ\u0087÷\u000eÿJSSæ5\u0097ÿó\u0001È9\u000bX\u0005".length();
            label32:
            while (true) {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               long[] var32 = var6;
               var10001 = var3++;
               long var40 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               
                  long var8 = var40;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var45 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var43) {
                     case 0:
                        var32[var10001] = var45;
                        if (var2 >= var5) {
                           hb = var6;
                           ib = new Integer[9];
                           v = new Item[]{Items.RAIL, Items.POWERED_RAIL, Items.DETECTOR_RAIL, Items.ACTIVATOR_RAIL};
                           w = new Block[]{Blocks.RAIL, Blocks.POWERED_RAIL, Blocks.DETECTOR_RAIL, Blocks.ACTIVATOR_RAIL};
                           Item var28 = Items.RESPAWN_ANCHOR;
                           Item var27 = Items.ENDER_CHEST;
                           Item var26 = Items.COBBLED_DEEPSLATE;
                           Item var25 = Items.DEEPSLATE;
                           Item var24 = Items.NETHERITE_BLOCK;
                           Item var23 = Items.CRYING_OBSIDIAN;
                           Item var22 = Items.OBSIDIAN;
                           x = Set.of(var22, var23, var24, var25, var26, var27, var28);
                           break;
                        }
                        break;
                     default:
                        var32[var10001] = var45;
                        if (var2 < var5) {
                           continue label32;
                        }

                        var4 = "ôH|nÊÙ\u009c¬\u008eÇ3ÂÜGº\f";
                        var5 = "ôH|nÊÙ\u009c¬\u008eÇ3ÂÜGº\f".length();
                        var2 = 0;
                  }

                  int var36 = var2;
                  var2 += 8;
                  var7 = var4.substring(var36, var2).getBytes("ISO-8859-1");
                  var32 = var6;
                  var10001 = var3++;
                  var40 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var43 = 0;
               }
            }
         }

         var14 = var15.charAt(var13);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6699;
      if (ab[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])bb.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               bb.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d3", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = Z[var5].getBytes("ISO-8859-1");
         ab[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return ab[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d3",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20355;
      if (ib[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = hb[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])jb.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               jb.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d3", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         ib[var3] = var15;
      }

      return ib[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d3",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = lb[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = kb[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 53;
            yield var15;
         }
         case 1 -> {
            byte var16 = 59;
            yield var16;
         }
         case 2 -> {
            byte var17 = 10;
            yield var17;
         }
         case 3 -> {
            byte var18 = 17;
            yield var18;
         }
         case 4 -> {
            byte var19 = 34;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 62;
            yield var21;
         }
         case 7 -> {
            byte var22 = 55;
            yield var22;
         }
         case 8 -> {
            byte var23 = 45;
            yield var23;
         }
         case 9 -> {
            byte var24 = 58;
            yield var24;
         }
         case 10 -> {
            byte var25 = 14;
            yield var25;
         }
         case 11 -> {
            byte var26 = 42;
            yield var26;
         }
         case 12 -> {
            byte var27 = 12;
            yield var27;
         }
         case 13 -> {
            byte var28 = 21;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 57;
            yield var30;
         }
         case 16 -> {
            byte var31 = 19;
            yield var31;
         }
         case 17 -> {
            byte var32 = 20;
            yield var32;
         }
         case 18 -> {
            byte var33 = 61;
            yield var33;
         }
         case 19 -> {
            byte var34 = 28;
            yield var34;
         }
         case 20 -> {
            byte var35 = 39;
            yield var35;
         }
         case 21 -> {
            byte var36 = 7;
            yield var36;
         }
         case 22 -> {
            byte var37 = 24;
            yield var37;
         }
         case 23 -> {
            byte var38 = 18;
            yield var38;
         }
         case 24 -> {
            byte var39 = 2;
            yield var39;
         }
         case 25 -> {
            byte var40 = 50;
            yield var40;
         }
         case 26 -> {
            byte var41 = 43;
            yield var41;
         }
         case 27 -> {
            byte var42 = 46;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 63;
            yield var44;
         }
         case 30 -> {
            byte var45 = 36;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 56;
            yield var47;
         }
         case 33 -> {
            byte var48 = 38;
            yield var48;
         }
         case 34 -> {
            byte var49 = 3;
            yield var49;
         }
         case 35 -> {
            byte var50 = 25;
            yield var50;
         }
         case 36 -> {
            byte var51 = 44;
            yield var51;
         }
         case 37 -> {
            byte var52 = 48;
            yield var52;
         }
         case 38 -> {
            byte var53 = 9;
            yield var53;
         }
         case 39 -> {
            byte var54 = 49;
            yield var54;
         }
         case 40 -> {
            byte var55 = 32;
            yield var55;
         }
         case 41 -> {
            byte var56 = 6;
            yield var56;
         }
         case 42 -> {
            byte var57 = 35;
            yield var57;
         }
         case 43 -> {
            byte var58 = 0;
            yield var58;
         }
         case 44 -> {
            byte var59 = 31;
            yield var59;
         }
         case 45 -> {
            byte var60 = 54;
            yield var60;
         }
         case 46 -> {
            byte var61 = 8;
            yield var61;
         }
         case 47 -> {
            byte var62 = 47;
            yield var62;
         }
         case 48 -> {
            byte var63 = 52;
            yield var63;
         }
         case 49 -> {
            byte var64 = 27;
            yield var64;
         }
         case 50 -> {
            byte var65 = 22;
            yield var65;
         }
         case 51 -> {
            byte var66 = 26;
            yield var66;
         }
         case 52 -> {
            byte var67 = 51;
            yield var67;
         }
         case 53 -> {
            byte var68 = 4;
            yield var68;
         }
         case 54 -> {
            byte var69 = 60;
            yield var69;
         }
         case 55 -> {
            byte var70 = 41;
            yield var70;
         }
         case 56 -> {
            byte var71 = 30;
            yield var71;
         }
         case 57 -> {
            byte var72 = 5;
            yield var72;
         }
         case 58 -> {
            byte var73 = 37;
            yield var73;
         }
         case 59 -> {
            byte var74 = 33;
            yield var74;
         }
         case 60 -> {
            byte var75 = 15;
            yield var75;
         }
         case 61 -> {
            byte var76 = 23;
            yield var76;
         }
         case 62 -> {
            byte var77 = 40;
            yield var77;
         }
         default -> 11;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            lb[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      kb[0] = "\u0006Y,$\bS\u0010Y)~\u001bD\u0007\u0012*x\u0017P\u0016U=o\\GQ";
      kb[1] = "(P\u001d\u001e+!]p\u0016\u0011:n<~\u001d\u001a>4H";
      kb[2] = void.class;
      lb[2] = "java/lang/Void";
      kb[3] = ">t-Z`H(t(\u0000s_??+\u0006\u007fK.x<\u00114\\#";
      kb[4] = "\u0012\u0000)3h\fg \"<yC\u0006.)7}\u0019r";
      kb[5] = "\u0019QIX \u007f\u000fQL\u00023h\u0018\u001aO\u0004?|\t]X\u0013tl\u0011]Z\u0018.!-FZ\u0005.f\u001aQ";
      kb[6] = "00s'\"!E\u0010x(3n$\u001es#74P";
      kb[7] = "@tJZK2VtO\u0000X%A?L\u0006T1Px[\u0011\u001f#a";
      kb[8] = int.class;
      lb[8] = "java/lang/Integer";
      kb[9] = "c\u001d|:Pdc\u001dkf\\kyVkx\\~~'9#\u00044";
      kb[10] = "K<LpyyK<[,uvQw[2ucV\u0006\ti-\"";
      kb[11] = "rtGUSgrtP\t_hh?P\u0017_}oN\u0004O\b";
      kb[12] = float.class;
      lb[12] = "java/lang/Float";
      kb[13] = "X7\u0010\u000e\u00034S8\u0001Ao7]:\u0003\u000eC";
      kb[14] = boolean.class;
      lb[14] = "java/lang/Boolean";
      kb[15] = "\u0006\r> yCs-5/h\f\u0012#>$lVf";
      kb[16] = "\u0012\u0018\u00043\u0004/\u0012\u0018\u0013o\b \bS\u0013q\b5\u000f\"B.Z~";
      kb[17] = "7I\u0016t\u001f$!I\u0013.\f36\u0002\u0010(\u0000''E\u0007?K0\u0015";
      kb[18] = "Y\u0007JzR\u007fR\b[53qY\u0003_o";
      kb[19] = "\u000f\u0016dtT)\u000f\u0016s(X&\u0015]s6X3\u0012,#k\t";
      kb[20] = "bipG60tiu\u001d%'c\"v\u001b)3rea\fb#i";
      kb[21] = "\u001czG\\`8iZLSqw\bTGXu-|";
      kb[22] = "^[/\fj\u001f^[8Pf\u0010D\u00108Nf\u0005Cai\u001a3@";
      kb[23] = "$\u000b=[~P$\u000b*\u0007r_>@*\u0019rJ91{M'\u000fn\r%\u0014`J\u0015\\qA$";
      kb[24] = "bTL:f\r\u0017tG5wBvzL>s\u0018\u0002";
      kb[25] = "_9sxj\u000f_9d$f\u0000Erd:f\u0015B\u00035`?V";
      kb[26] = "\u001d~eG%:\u000b~`\u001d6-\u001c5c\u001b:9\rrt\fq(\u001c";
      kb[27] = "\u0016qd\u0018\"vcQo\u001739\u0002_d\u001c7cv";
      kb[28] = "x!@W<3x!W\u000b0<bjW\u00150)e\u001b\u0006Lhl";
      kb[29] = ",j\u0010C\u0006T,j\u0007\u001f\n[6!\u0007\u0001\nN1PR^S";
      kb[30] = "S5rdO%&\u0015yk^jG\u001br`Z03";
      kb[31] = "\u0016\fG@wfc,LOf)\u0002\"GDbsv";
      kb[32] = "T6]|\u0019X_9L3~ZJ2LxE";
      kb[33] = "$j3fFu$j$:Jz>!$$Jo9Pv\u007f\u001e/";
      kb[34] = "T]L\u0004\u0006F!}G\u000b\u0017\t@sL\u0000\u0013S4";
      kb[35] = "L\u0005\u000e5\u0001fG\n\u001fzbkR\u0007\u0010\u0011WiC\u0014\f=@d";
      kb[36] = "3egRj\u000eFEl]{A'KgV\u007f\u001bS";
      kb[37] = "BMy\u0003/=IBhLR%ZEa\u0005";
      kb[38] = "hx&C`khx1\u001fldr31\u0001lquBcU=0";
      kb[39] = "\u0013\fl\u000e\u0000\u001cf,g\u0001\u0011S\u0007\"l\n\u0015\ts";
      kb[40] = "/oG\u0000q\u00169oBZb\u0001.$A\\n\u0015?cVK%\u0002\u0007";
      kb[41] = "kr\u001a>|m\u001eR\u00111m\"\u007f\\\u001a:ix\u000b";
      kb[42] = "P\bi\u0014MdP\b~HAkJC~VA~M2,\f\u0016<";
      kb[43] = "&7`4ih07enz\u007f'|fhvk6;q\u007f={";
      kb[44] = "B -3\f#7\u0000&<\u001dlV\u000e-7\u00196\"";
      kb[45] = "DN%\u0004a\r1n.\u000bpBP`%\u0000t\u0018$";
      kb[46] = "68Iw,\u0012C\u0018Bx=]\"\u0016Is9\u0007V";
      kb[47] = "Ly\u0010FBq9Y\u001bIS>XW\u0010BWd,";
      kb[48] = "Q3;\u0013*?G3>I9(Px=O5<A?*X~+M";
      kb[49] = "\u0010H\u001b;\u0015?eh\u00104\u0004p\u0004f\u001b?\u0000*p";
      kb[50] = "b2?\u0010W2b2(L[=xy(R[(\u007f\by\n\t";
      kb[51] = double.class;
      lb[51] = "java/lang/Double";
      kb[52] = "/\u001a5#^9Z:>,Ov;45'K,O";
      kb[53] = "Rk\u001d\u0011M\u0006Rk\nMA\tH \nSA\u001cOQZ\u000e\u0015";
      kb[54] = "a\f\u0003\rVoa\f\u0014QZ`{G\u0014OZu|6A\u0010\r";
      kb[55] = "H|1H\u0015dH|&\u0014\u0019kR7&\n\u0019~UFtPM:";
      kb[56] = "\t\u0014O\b\u000f^|4D\u0007\u001e\u0011\u001d:O\f\u001aKi";
      kb[57] = "Kf2N^\u000fKf%\u0012R\u0000Q-%\fR\u0015V\\wW\u0003W";
      kb[58] = "F~\u0015\u0003\u0013\u00163^\u001e\f\u0002YRP\u0015\u0007\u0006\u0003&";
      kb[59] = "X,\u0017dNaN,\u0012>]vYg\u00118QbH \u0006/\u001ar\u000f";
      kb[60] = "^/T\u001c\u001a\"+\u000f_\u0013\u000bmJ\u0001T\u0018\u000f7>";
      kb[61] = "C\u0012i43vC\u0012~h?yYY~v?l^(/)g";
      kb[62] = "8\u00160yS\rM6;vBB,80}F\u0018X";
      kb[63] = "3Us\\\fOFuxS\u001d\u0000'{sX\u0019ZS";
      kb[64] = "gD]U:}gDJ\t6r}\u000fJ\u00176gz~\u001aBa!";
      kb[65] = "(I\u0007O\u0010=(I\u0010\u0013\u001c22\u0002\u0010\r\u001c'5sARHd";
      kb[66] = "\u0003y\u0007\u0002e\u0001\u0003y\u0010^i\u000e\u00192\u0010@i\u001b\u001eCB\u001e>P";
      kb[67] = "*\u0004\u0014\u0010[p*\u0004\u0003LW\u007f0O\u0003RWj7>S\u000e\u0002";
      kb[68] = ":l$%\u0006pOL/*\u0017?.B$!\u0013eZ";
      kb[69] = ".WN(e'[wE'th:yN,p2N";
      kb[70] = "TF\u0004zm+BF\u0001 ~<U\r\u0002&r(DJ\u0015198\\";
      kb[71] = "fWo\u0004q\u001d\u0013wd\u000b`Rryo\u0000d\b\u0006";
      kb[72] = "@kStj$5KX{{kTESp\u007f1 ";
      kb[73] = "k/2EZu\u001e\u000f9JK:\u007f\u00012AO`\u000b";
      kb[74] = "&+1X320+4\u0002 %'`7\u0004,16' \u0013g$\u001b";
      kb[75] = "\u0013chNI\u0006fCcAXI\u0007MhJ\\\u0013s";
      kb[76] = "\u000f\u0011\u001e0%Xz1\u0015?4\u0017\u001b?\u001e40Mo";
      kb[77] = "\u0000\u0005:4%`\u0000\u0005-h)o\u001aN-v)z\u001d?\u007f(~0";
      kb[78] = "no';)I\u001bO,48\u0006zA'?<\\\u000e";
      kb[79] = "WR-.h7\"r&!yxC|-*}\"7";
      kb[80] = "\f&\u0006P>Dy\u0006\r_/\u000b\u0018\b\u0006T+Ql";
      kb[81] = "WnI>\u0013:\\aXqp7Ig";
      kb[82] = "'2XWR\u0012R\u0012SXC]3\u001cXSG\u0007G";
      kb[83] = "~Wy7c\u0004\u000bwr8rKjyy3v\u0011\u001e";
      kb[84] = "}};\u0016uJ\b]0\u0019d\u0005iS;\u0012`_\u001d";
      kb[85] = "1\u0000-8H&'\u0000(b[10K+dW%!\f<s\u001c2\u0012";
      kb[86] = "\fUo\u000b|Kyud\u0004m\u0004\u0018{o\u000fi^l";
      kb[87] = "RoT2\t]RoCn\u0005RH$Cp\u0005GOU\u0012.P\f";
      kb[88] = "9o\u001f\u0003\u001b.9o\b_\u0017!#$\bA\u00174$UR\u001eEv";
      kb[89] = "\u001f\u000e!VPg\u001f\u000e6\n\\h\u0005E6\u0014\\}\u00024lK\u000e:";
      kb[90] = "j\u0000\b0`\u0013\u001f \u0003?q\\~.\b4u\u0006\n";
      kb[91] = "^\u007f^LeQ+_UCt\u001eJQ^HpD>";
      kb[92] = "l/l^(\u000ez/i\u0004;\u0019mdj\u00027\r|#}\u0015|\u001a@";
      kb[93] = "g8\u001e?\u0003-\u0012\u0018\u00150\u0012bs\u0016\u001e;\u00168\u0007";
      kb[94] = "\u0007a=xVF\u0011a8\"EQ\u0006*;$IE\u0017m,3\u0002R*";
      kb[95] = "\u000b\nmG?e~*fH.*\u001f$mC*pk";
      kb[96] = "%\u0002\f/WTP\"\u0007 F\u001b1,\f+BAE";
      kb[97] = "I\u007f\u001c3\u0012__\u007f\u0019i\u0001HH4\u001ao\r\\Ys\rxFKg";
      kb[98] = "#\u001a4g-\u0003V:?h<L744c8\u0016C";
      kb[99] = "Ix\u001ci~,<X\u0017foc]V\u001cmk9)";
      kb[100] = "_C\u001a\u0014x\u0010IC\u001fNk\u0007^\b\u001cHg\u0013OO\u000b_,\u0004p";
      kb[101] = "d\b~\u001f]~\u0011(u\u0010L1p&~\u001bHk\u0004";
      kb[102] = "t.6W\u001d\u0014\u0001\u000e=X\f[`\u00006S\b\u0001\u0014";
      kb[103] = "]r%MLdCz?\u0002.xDg";
      kb[104] = "\\\n|0)AB\u0002f\u007faAX\b~8hZ\u0018;x4c]U\n~4";
      kb[105] = "\\\u000f/H@\u0016)/$GQYH!/LU\u0003<";
      kb[106] = long.class;
      lb[106] = "java/lang/Long";
      kb[107] = "\u001dfmi#nhFff2!\tHmm6{}";
      kb[108] = "$8Mk\u007fe$8Z7sj>sZ)s\u007f9\u0002\bu&=";
      kb[109] = "Y\u0000<raYO\u00009(rNXK:.~ZI\f-95e";
      kb[110] = "r\u0017\rqPY\u00077\u0006~A\u0016f9\ruEL\u0012";
      kb[111] = "DQ>\u000b\u00066DQ)W\n9^\u001a)I\n,Yky\u0013\\j\u000eW&D\u0018,u\u0007z\u0013";
      kb[112] = "5$\u001c[9 01\u0017[2;<!U2\u0019\u0011\r";
      kb[113] = "m\u0001\u0012c\u0007\u0006\u0018!\u0019l\u0016Iy/\u0012g\u0012\u0013\r";
      kb[114] = "=yc\u0006,t6vrIKl2jt\u0005n}";
      kb[115] = "C\u0006I\u007f6\f]\u000eS0Q\rL\u0015^jw\u000b";
      kb[116] = "IZi$ByIZ~xNvS\u0011~fNcT`.?\u001c\"";
      kb[117] = "v]U\u00002\u0017}RDOZ\u0017s]W";
      kb[118] = "\u0019'!m\u0005,l\u0007*b\u0014c\r\t!i\u00109y";
      kb[119] = "++,'%1=+)}6&*`*{:2;'=lq%\r";
      kb[120] = "~3g\u000b\u0003\u0005\u000b\u0013l\u0004\u0012Jj\u001dg\u000f\u0016\u0010\u001e";
      kb[121] = "&NI\u0005\u0004`SnB\n\u0015/2`I\u0001\u0011uF";
      kb[122] = "l\u007f\u001a\u00050(rw\u0000JM8r";
      kb[123] = "TOC+QUIZ\u001b\t\u0010XQ\\";
      kb[124] = "r:F}Q\u0004d:C'B\u0013sq@!N\u0007b6W6\u0005\u0010`";
      kb[125] = "6t$zcgCT/ur(\"Z$~vrV";
      kb[126] = "\u0014U\u0016yD?au\u001dvUp\u0000{\u0016}Q*t";
      kb[127] = "]>G\u001aw{(\u001eL\u0015f4I\u0010G\u001ebn=";
      kb[128] = "^S\u001e\u0001%G^S\t])HD\u0018\tC)]Ci[\u001dq\u0019";
      kb[129] = "!1\u0017q: !1\u0000-6/;z\u000036:<\u000bQlo";
      kb[130] = "=8j[c\u0005=8}\u0007o\n's}\u0019o\u001f \u0002,F7H01\u007f\u0006}3ai.";
      kb[131] = "r\u0010\u0019MBhr\u0010\u000e\u0011Ngh[\u000e\u000fNro*^Z\u001a8";
      kb[132] = ")\u0018BBsN)\u0018U\u001e\u007fA3SU\u0000\u007fT4\"\u0005U+\u001ec\u001eZ\rmT\u0018N\u000fZ.";
      kb[133] = "^>x\u001b_\u0014^>oGS\u001bDuoYS\u000eC\u0004?\f\u0007D\u00148`TA\u000eoi8\u0007";
      kb[134] = "$\u001c_v1\u0014Q<Ty [02_r$\u0001D";
      kb[135] = "J\u001cV\u0017Ay\\\u001cSMRnKWPK^zZ\u0010G\\\u0015kx";
      kb[136] = "&WFi7\u000fSwMf&@2yFm\"\u001aF";
      kb[137] = "$\u000fw9\u0017(Q/|6\u0006g0!w=\u0002=D";
      kb[138] = "\t\u0017\bU#S\t\u0017\u001f\t/\\\u0013\\\u001f\u0017/I\u0014-NIz\f";
      kb[139] = "P \r\u0001m\u0012\u0011s\u0003Xh\u007f\f*\u001df:\r\t?\f\u0019~\u000e\u0012ym[u\u001f\u0015\"\u0012\u001fv\u0004SCP\u0014g\u0003\b<\u0014\u0017|Ei";
      kb[140] = "6j?\u001c\u0013TpbzOYnjfz\u001e\u0004\u0002X1=@]S\u000fb?\u000f\u001d\u0010m19F\u001bn";
      kb[141] = "Z\u0005\u000f9\fm\u001c\u001b\u0007{}c\\\u0017\u0007g\u0014`&F\u0014a\u0001eY\u0002\u0017zG\u0004";
      kb[142] = "j'9M+a:\"mQ<\u001e:\\h[9sj%(Vlyo\\kF>n-#;Cjr:\\";
      kb[143] = "JQ5\u001aqnE]jD\nrG]eGf@\u0010\u001f?\u00186\u0017\u0013Fu\u001d5jRE`Be\u0017";
      kb[144] = "@eh$/tDu}wTkXr}\"\u00035\u0000%(NkoKmkrk4@b";
      kb[145] = "f\u000fH\u007fyG6\u000b\u00195iw9_\t$d\u001b\u000b\u000bIx?wa@\u00158b\b%C\u000e~\u0003";
      kb[146] = "%'Ht\u001f\u0011| M~yA\u001f Rx\u0014\u0014f`_-\u001e\u0011\u001f#P{\u001bN{&\n/\u001d-";
      kb[147] = "sQ=\u0016Tj{A&\u001c\u0010\u0004#/m\u0001\u0007isV-\fRcv/n\u0019\u0001uuAf\t\u001a\u007f1/";
      kb[148] = "Ma\u001e||gGi\u0010\u007f\"\u0015\u0019f\u0002c+BN?W=z\u0015N`\u001f:xh\u000fc\ne(";
      kb[149] = "Wt[}\u0010\rV5\u0013n*W\n9\u0002tFe]yR)\u001a2\u000e|\u0013mTP]zZk*";
      kb[150] = "lQF$`Fm\u0010\u000e7Z\u001c1\u001c\u001f-6.g^Cwgyl\u0003B3;\u0015 ]N+Z";
      kb[151] = "joh\u000f\u001d^<<$d@0lgy\t\u0014I,j,\u0003\u00110ksu\u0018LO/pn^-";
      kb[152] = "o|R3\u0000=9/\u001eX_SitC5\t*)y\u0016?\fS:+^&N1i-\u0017 0";
      kb[153] = "z2\u0003)wJ#5\u0006#\u0011\u001c@5\u0019%|O9u\u0014pvJ@\u007f\u00124)\u000b'j\u00169jv";
      kb[154] = "bK!4$&4\u0018m_xHdC02-1$Ne8(H7\u001c-!j*d\u001ad'\u0014";
      kb[155] = "\u0016i/~*NIrgak>Aqxt7i\u0013!+,j>\u0016h+jf\u0003\u0013*h(j";
      kb[156] = "\u001e44<0i_g:e5\u0004\\..'Zv^-na*uU,([(}]mn++v\\+T";
      kb[157] = "*P\u0006SC'+D\u001eAC]y4FI\u00160)M\u0006DC:,4\u0015\u0016\u000b#nVF\u0010B%\u0010";
      kb[158] = "Ok\u0006\u0005\u001a9\u001b6\u001b\u001bLB\u001aj\u001d!\u001c.u:\u0013\u001b\r#\n~\u0010\u0000KB";
      kb[159] = "tvi\u0013X\r>pjV\u0006m t;\b[:w.j\\7W-*)\u0003W\u001d+)l]";
      kb[160] = "G 6a{$\u00119jdE/I$ju\u0012x\u0012x1%E.Aqv' xX-s";
      kb[161] = "5{EY\u0003\u00164:\rJ9Lh6\u001cPU~>qA\b\u0000)t;\u0001\tC\u0012`!F\u000b9";
      kb[162] = "!|-(Wu6.s*3!!:%1HL4|.:\fv#(0j3%a62+Qvg\u007f4U";
      kb[163] = "Ymlqx4Iel5\u001fdTzv\"H3\u000b&*N&2Exp-g3\\|,";
      kb[164] = "Zq~:w\u0002\u0004;ghv}\u0006,xj`\u00114x;57Fc{efb\u0002X?glb\u0019c";
      kb[165] = "\u007f\"Tn&-{2A=]2g5Ah\nl<h\u001c\u0004b6t*W8bm\u007f%";
      kb[166] = "aC\u000bd9P7\u0010G\u000f`>gK\u001ab0G'FOh5>d\u0016\fqyT1@Ibl>";
      kb[167] = "@\"#jbcS:91\u001adG=;jvV\u0013ya3\"\u0001\u00173;q{~S0 7\u001a";
      kb[168] = "\u0010\u0013\r:4\nFI\u000f9-v@u\t#8\u001b\u0010\fI.m\u0011\u0015u\n#j\tI\t\\yh\nPu";
      kb[169] = "\n~\"H\u000e\u0016\na/V0J\u001bz(C\\xK:s\u00140\u0012\u0004f4EOV\u0007}r$\u000e\u001f\bzs\u001dW]\r>H";
      kb[170] = "y;\u000b/tMj#\u0011t\fJ~$\u0013/`x*`Kx0/y;\u000b/tMj#\u0011t\f";
      kb[171] = "5)fH{) -k\u000b\u0006'E~}\u001ckw<>pIarE-\"\u0001x0'~$H~N";
      kb[172] = "\u0000\u0016h\u0006\u00129T\u0016kEQY_J.^\u00075m\u001eo\u0005^b:\u00171\u0003\u00198V[o\u000f\u0001Y\nDoG\u00015F\u001ac_`iY\u001a+_\f%\u0007\u00163>P:\u0007^3R\u001cd\u000bFR";
      kb[173] = "'G,\u001fI wR1\u0017HOvK7\u001bX.{WQ\u000b\n-r\u0013k\u001c^3\",8^@1cNkX\t7\u001d";
      kb[174] = "\u000f{\u0005\u001047\f2E\nm^X+T\u0015a\t\u000fs\u0001J3^\u000f{\u0005\u001047\f2E\nm";
      kb[175] = "/BPN*\u000bdG\u0005ExuxJ\rP,\"+\u001bX\u0004@L\u007f\u001b\u001a^>\u0007zN\u0011\f";
      kb[176] = "E\"F\u001b\u0004OQ8\u0001\u0019~\u0011Y/[B\u0012#\rk\u0001\u0018~\u0005E.\u0005_E\u0011_i\u0007%\f\rNi\u0001U\u000f\u0006O/;";
      kb[177] = "\n\u0005!n1\u0015S\u0002$dWB0\u0002;b:\u0010IB670\u00150H0soTW]4~,)";
      kb[178] = "\u001a>\u001aoX\u001f\u0013<G6D}JR\u001bjP\u0010\u001a+[g\u0005\u001a\u001fRH5M\u0003]0\u001b3\u0004\u0005#";
      kb[179] = "r;NZ_\\f!\tX%\u0002n6S\u0003I0:r\t\\%\u0016r7\r\u001e\u001e\u0002hp\u000fdT\u0016~tI_@\f9v3";
      kb[180] = "\fQBse\u0016X\f_m3mYPYBt\u0000[[%0|\rJ\\Zt\u007f\u0016\f=";
      kb[181] = "v&\u0005\u0017HUwgM\u0004r\u000f+k\\\u001e\u001e=x.\u0005Dr\u0003\u007ffB\u0007\u0010Py/Dy";
      kb[182] = "@fT\nFoNe[\u0015vp,-\f\u001c\u001b'Um\u0001I\u0011\",~S\u0001\b`N-UH\u000e\u001e";
      kb[183] = "\u0011uy:#\rH7|~\u0018QB9g!tc\u0010t?w\u0018\u000bE7u4$\u000b\u001e<zF";
      kb[184] = "k\u0003fu f6V>ri[1n<o}6h\u0017|b(<mn?m~92\n:7*?Q";
      kb[185] = "/\u0014},=\b!\u0017r3\r\u0010C_%:`@:\u001f(ojEC\\'9o\u001a'Y}miy";
      kb[186] = "xM\u0005Dvx(X\u0018Lw\u0017%HxP5u-\u0019BGak}&BWso:I\u0012Bng;&";
      kb[187] = "x\u0004Lf+%l\u001e\u000bdQ{d\tQ?=I0M\u000biQox\b\u000f\"j{bO\rX";
      kb[188] = ")+k\u00184 \u007fx'sjN/#z\u001e=7o./\u00148N(7v\u000fe1l4mI\u0004";
      kb[189] = "R\rZ~IFZ\u0010Vc/\u0013\u0004\u0006RkF\u001f=\bR{By\nXGxQ\u001bY^\u000e~/";
      kb[190] = "J3P\\|\u0000\u001bg@_B\u0004w7][>\u000e\bs^@xo";
      kb[191] = "\u0007+\u0014bYlW>\tjX\u0003Z.iv\u001aaR\u007fSaN\u007f\u0002@\u0005!Cl\u0002z\u0012u]<=,RxN<\u0007;\u0006f\u001e\u0003Q{\u000bu\u001e9F/\u0015%!o\u0006\"\u0006%\u001bxR<V\u001aM8_/V ZlA\u007fiv\u001aaR\u007fSaN\u007f\u0002@Sq\\{E/\u0003dAsD@";
      kb[192] = "S\u0015\".\u0017hY\u001d,-I\u001a\u0007\u0012>1@MPKoo\u0011\u001aP\u0014#h\u0013g\u0011\u001767C";
      kb[193] = "jnzk\n\f,{\u007f6Uk9\u0000&lX\u0006jyfa\r\fo\u0000u3E\u0015-b&5\f\u0013S";
      kb[194] = "cN\f\u0019\u0014a5\u001d@rM\u000feF\u001d\u001f\u001dv%KH\u0015\u0018\u000f5C\t\u0015\\m&[\u0013N$";
      kb[195] = "Gw)9_\u0004Smn;%QWk0kr\u0006\r;l\u0007WFL<nwTMMz";
      kb[196] = "uS))n\u0018aIn+\u0014Fi^4pxt=\u001an)\u0014Ru_jm/Fo\u0018h\u0017fZ~\u0018ngeQ\u007f^T";
      kb[197] = "\u001c;O\u0017j?\f3OS\ro\u0011,UDZ8O{\r(=0I/\u000b\u0017<q\u0001<";
      kb[198] = "%{]\u0015\u0010`$:\u0015\u0006*:x6\u0004\u001cF\b,z[J\u001a_d;\u0019EPdp!^G*";
      kb[199] = "C \u001d\u0004O\u0006V$\u0010G2\b3w\u0006P_XJ7\u000b\u0005U]3}\u0003\u0001K\u0000_1]\rSa";
      kb[200] = "l<QAG(:o\u001d*\u001eFj4@GN?*9\u0015MKF9k]T\t$jm\u0014Rw";
      kb[201] = "l\\HwE\u000f:\u000f\u0004\u001c\u0019ajTYqL\u0018*Y\f{Iam@U`\u0014\u001e)CN&u";
      kb[202] = "`gtQ2+!4z\b7F%cX[7<4io6*?#>.F)4\"x\u0014D!<c>dG*=%\u0004";
      kb[203] = "]me\u0018 4\u000b>)srZ[et\u001e)#\u001bh!\u0014,ZXgw\u0011s>]=#\u0017\u0010";
      kb[204] = "U>-pZYRd#|C \u000fghUWP\u0013\u000ez*K^\u0011l),\u0002Xo";
      kb[205] = "B\u00166\u000fz9\u001c\\/]{F\u001eK0_m*,\u001fs\u00005y{L/Gm>\u0019_7]6F";
      kb[206] = "!!'@|f  mUMc@q0W 391=\u0002*6@)2P)0'31Fq\n";
      kb[207] = "B\u0018t\u0001QN\u0003KzXT#\u001e\u001arf\u0006Q\u001b\u0007u\u0019BR\u0000A\u0014[IC\u0007\u001ak\u001fJXA{)\u0014[_\u001a\u0004m\u0017@\u0019{";
      kb[208] = "XOZLz=\u0019\u001cT\u0015\u007fP\bG]P\u0010\"\u0018V\u0000\u0011`!\u0013WF+b)\u001b\u0016\u0000[a\"\u001aP:";
      kb[209] = "}.Ogdfy>Z4\u001fye9ZaH'8j\u0000\r }v&L1 &})";
      kb[210] = "5Q*w\u0007\u0014c\u0002f\u001cWz3Y;q\u000e\u0003sTn{\u000bz`\u0006&bI\u00183\u0000od7";
      kb[211] = "wpqT\\a!#=?\u0002\u000fqx`RUv1u5XP\u000f\"'}A\u0012mq!4Gl";
      kb[212] = "rc8w\u000fivs-$tvjt-q#\"1!p-t'ak;oH':`4";
      kb[213] = "e8 ]Y5<+cH`:i1'U'*\u0000h(X\u001c%\u007f,+CZDe8 ]Y5<+cH`";
      kb[214] = ",V`F>\u000ez\u0005,-l`*^q@7\u0019jS$J2`y\u0001lSp\u0002*\u0007%U\u000e";
      kb[215] = "o\\e\u0003UOn\u001d-\u0010o\u00152\u0011<\n\u0003'aUgUoNo\u0013 VV\u0017-\u0016dm";
      kb[216] = "\u0006G\u0015Y:w\u0013C\u0018\u001aG{v\u0010\u000e\r*)\u000fP\u0003X ,v\u0013\f\u000e%s\u0012\u0016VZ#\u0010";
      kb[217] = "%6zTKd!&o\u00070{=!oRg%g}:>\u000f\u007f.>y\u0002\u000f$%1";
      kb[218] = "Ag\u0012Y\u000fV@&ZJ5\f\u001c*KPY>Lf\u0011\u00075Y\u0012kRVY\u0015LgJ7D\u0018\fhQ\fP\u0002Kj+";
      kb[219] = ".(5JG\u0005x{y!\u0014k( $LN\u0012h-qFKk+\"'C\u0014\u000f.xsEw";
      kb[220] = "ma@\u001aD l \b\t~z0,\u0019\u0013\u0012HchEK~!m.\u0005OGx/+At";
      kb[221] = "L9$(`1Y=)k\u001d<<n?|poE.2)zj<d:-d7P(d!|V";
      kb[222] = "~s\u0019\u000b\"\nzc\fXY\u0015fd\f\r\u000eA79V_YDm{\u001a\u0013eD6p\u0015";
      kb[223] = "wqDA\u000e9upPF[\u0004'\r\u0010YYiwtPT\fcr\r\u0013C[zu0\u0011BO} \r";
      kb[224] = "\b\u0004J>&G\f\u0014_m]X\u0010\u0013_8\n\u0006OC\u0006Tb\\\u0003\fIhb\u0007\b\u0003";
      kb[225] = "67=Y\u0015)2'(\nn6. (_9bttp\nng%?>ARg~41";
      kb[226] = "EN*NS2\u000e\u0004*E]B\u0015P ?Qy\u001eSs\u0005F-\u0000\u0003LV\u00043\u0002B.\u0005\u0002z\u0004<";
      kb[227] = "fQ\u000e+l(-\u001b\u000e bX$B\u001a7\u0002e-C\u0014;}!.XRZ";
      kb[228] = "nbx\f&Zjzk\t@Y`\u007fd\u0000,k4<;[z<7bz\f-^b<i\u001c\u007f<43~W0Cjyg\u00051<";
      kb[229] = "vP\u0001\u0013ZyeH\u001bH\"~qO\u0019\u0013NL \rDI\u0012\u001bmB\u0004JX yXCH\"";
      kb[230] = "\u0005\u0012FxX[\u0004S\u000ekb\u0001X_\u001fq\u000e3\u000b\u001bC&bYGC\u0003w\u001d\u001dDXE\u0016";
      kb[231] = "{\u000fg\u000ewf%Le\u0011`\u0004/Za\u0019aZ(Z{\u001d\u001d4\"\u0003\u007f\u0011qx|\u000fgp";
      kb[232] = ",\fj\u0000W8u\u000bo\n1m\u0016\u000bp\f\\=oK}YV8\u0016A{\u001d\tyqT\u007f\u0010J\u0004";
      kb[233] = "]7k\u00193YI-,\u001bI\u0007A:v@%5\u0015~-\u001eI\u0010U<,\u001d9\u0013^=j';\u001bV|,W8\u0010W:\u0016U0\u0018\u0016|fV;\u0019PFgV4\\V}sLs^,";
      kb[234] = ",T\u0016^\u00169u\u0016\u0013\u001a-e\u007f\u0018\bEAW/TV\u0013\u0011\u0000+\u001cVX\u0010=.^\u0015\u001a\u001c\u0000~_\nM\u0012:i\u000b\u0014\u001d-";
      kb[235] = "6-NA\u007f\u001br/DAd b-O@lw5w\u0019\u001e\u0000\u001am G[;^o*G@";
      kb[236] = "R\b\u001ev\u0018\u001f\u0019B\u001e}\u0016o\u0011\u0017\u001d`\b\u0002*\u0014x=N\u0016\u0015\u001f\u0016=\u0010\u0003UGxnO\u001e\u0015\u0004\u001a=IW\u0013z";
      kb[237] = "\u0015y.D#x\f9c\u0010Bvnx5D/%\u001788\u0011% n{7G \u007f\n~m\u0013&\u001c";
      kb[238] = "Hp)\u001b-9L`<HV&Pg<\u001d\u0001r\u00002bLVw[x*\u0003jw\u0000s%";
      kb[239] = "\u001ea\r]S%\u001f ENi\u007fC,TT\u0005M\u0015i\t\u000fY\u001aR(^_W#R7SAi";
      kb[240] = "]5nC$;\ths]r@\b4ut+8\u00070\t\u0000= \u001b8vD>;]Y";
      kb[241] = "s\u007f\u001eG\u0017%r>VT-\u007f.2GNAMxp\u001b\u0014\u0011\u001as-\u001aPLv?s\u0016H-";
      kb[242] = "&E;h\berE8+K\u0005y\u0019}0\u001diKM<kD?\u001c\u0006x*@?l\u0005s+\u0006\u0005,\u0017<)\u001bi`I01z";
      kb[243] = "=p\u0002\u0017v$d2\u0007SMxn<\u001c\f!J<qBSMt:1\u0002\u0015/'<x\u0004k";
      kb[244] = "\u000bAHlWc@\u000bHgY\u0013SOCgPoUI.'\t-QSW S#]J.";
      kb[245] = "#f\u001a\nZ#)n\u0014\t\u0004Qwa\u0006\u0015\r\u0006 8VM_Q g\u001bL^,ad\u000e\u0013\u000e";
      kb[246] = "o\u000b\u0018\u0013\u000259XTx][i\u0003\t\u0015\u000b\")\u000e\\\u001f\u000e[n\u0017\u0005\u0004S$*\u0014\u001eB2";
      kb[247] = "huZ\u0011\u001dB1f\u0019\u0004$Rkd~\u001d@N`\u0018\u001d\u0006DOlgY\u0005_\t\r";
      kb[248] = "3=X\u0004.\u0010rnV]+}v9b\n(\u001cc8Cc6\u0004pd\u0002\u00135\u000fq\"8\u0011=\u00070dH\u00126\u0006v^";
      kb[249] = "i^\f6\u0006\bn\u0004\u0002:\u001fq5\u0003B)f\u001dh\f]j\\\n<\u0012\rU";
      kb[250] = "v/:eHf|'4f\u0016\u0014\"(&z\u001fCuqr L\u0014u.;#Li4-.|\u001c";
      kb[251] = "\u000b\u0010`Oi'\u0019\u00125\u0018\n}\b\u0014lBfO\\R7\u001b1\u0018\n\u00014]4}\\\u0018hX\n";
      kb[252] = "O1!B]z\u000eb/\u001bX\u0017\u001f8:%\u0007tK+ IK*G3A\u0015T*\u000f3-Y\n&\u0017R";
      kb[253] = "h\"c[\u0007\u0016l2v\b|\tp5v]+W!d\"1C\rc*`\rCVh%";
      kb[254] = " \u001a\u000bly\u000f0\u0012\u000b(\u001eT!\u001c\u00154rfvZKc%1v[\u001b8\u007f_>\u0006\u0013h#1";
      kb[255] = "r\u007f`i2j*~s#z\u000e&|l7&Yq\"<n{\u000er\u007f`i2j*~s#z";
      kb[256] = "=e\u00026%Zk6N]|4;m\u00130,M{`F:)4df\u00058,E=uF-\u0015";
      kb[257] = "Pm41\u0019A\u0011= 9\u001dx\f93iD\u0014>n\u007f8\u001dxYevg\u0019GX$>t#A\u0000d5c]\n\u00051>1#AY.\u007fy\\\u001f\u00137-x#A\bm-y\u0019\u0007\u0000(~3#";
      kb[258] = "Q'zDlDU7o\u0017\u0017[I0oB@\u000f\u0012a1\u0017\u0017\nB/y\\+\n\u0019$v";
      kb[259] = "5`*`3\u0013c3f\u000bj}ntnka\u0001p>+m\u0003\u001as77i\u007f\u00049r1\u000b";
      kb[260] = "\u007fz<)dzk`{+\u001e/of%{Ix56x\u0017l8t1{go3uw";
      kb[261] = "U{\u0007m\u0013AAa@oi\u0014Eg\u001e?>C\u001f7@S\u001b\u0003^0@#\u0018\b_v";
      kb[262] = "j?\u0010\u001b1\u00003xX_MDV<\r\\1\u0000,=\u0019D#\u0000";
      kb[263] = "`5Oh.7n6@w\u001e/\f~\u0017~s\u007fu>\u001a+yz\f!\u001ch{\u007f}x\u000f+nF";
      kb[264] = "ONE\u0015E\n\u000e\u001eQ\u001dA3\u0013\u001aBM\u0018_!M\u000e\u001c@3OM\u0003\u0015CJ\r\u0019\\P\u00073O\u0013QO\u001cWJI\u0005I\u007f";
      kb[265] = ".Fb|)m*^qyOn [~p#\\}\u001c%*O1\"\\{)+jwG\"pO1-@uuv56CawO2?Aoy?yuAdwO";
      kb[266] = "/7LTv1{7O\u00175Qpk\n\fc=B?KW;m\u0015t\u000f\u0016>kew\u0004\u0017xQ%eK\u0015e=i;G\r\u0004";
      kb[267] = "\u001d\n./eh\u0013\t!0UsqAv98 \b\u0001{l2%qBt:7z\u0015G.n1\u0019";
      kb[268] = "s \n{=Ys'\u001cr*5 \u001d[r?Xsd\u001b\u007fjRv\u001d\u0010e.\u000b0&\u0004\u007fi\tJ";
      kb[269] = "\u0018\fm4_|\b\u0004mp8,\u0015\u001bwgo{KH.\u000b\u0001|\u0013\f/wEz\b\u0011c";
      kb[270] = ")4\u00023O^9<\u0002w(\u000e$#\u0018`\u007fY{~C\fK\u00019%\u001ajO\u0019* ";
      kb[271] = "rDXH3l9\u000eXC=\u001c$[B9`n+J_F$m0\f>Uf~$\t\u0004B2`t6";
      kb[272] = "}d=1eJ+7qZ<${l,7l];ay=i$x::j%[&p#8$$";
      kb[273] = "xyr)lvkahr\u0014q\u007ffj)xC+\"0p/\u0014/hj2ukkkqt\u0014";
      kb[274] = "=d\u0002\u0003BZ|e\u001b\u0007\u001e9j=\u001f\bLn=mJP \u0000nf\u001eQP\u0001nc\u0016\u0010";
      kb[275] = "I*\u007f@kU\u0014\u007f'G\"h\u001cG%Z6\u0005J>eWc\u000fOG&X5\n\u0010##\u0002a\fs";
      kb[276] = ";Btl\u0017Pm\u00118\u0007J>=Jej\u001eG}G0`\u001b>n\u0015xyY\\=\u00131\u007f'";
      kb[277] = "(V1fwt)V4n6\u0004tQwj-hF\u000571v\u0004x\u0005zt4f+\u00033rJ";
      kb[278] = "7\\b\u0011O'\u007fVv\u001d\u001a\u0017g5=FIz4L}K\u001cp157C\u0018nlY{\u001d\u0014v\r";
      kb[279] = "}Z\u0005TM\fy\u0015\u0006YY<(\u0000QIrQ;!XKFQ\r\u0019CJZZG^\u0006N\u0004^|^\u000fV\u0005YGYMVA]8\u001dNM\u0007<z\u0016_J\\C>\u0015D\f=";
      kb[280] = "\u000eB00;\\X\u0011|[h2\bJ!62KHGt<72[\u0015<%uP\b\u0013u#\u000b";
      kb[281] = "IjTTp2\u001f9\u0018?%\\ObERy%\u000fo\u0010X|\\L`F]#8I:\u0012[@";
      kb[282] = "d&]Q\tT5rMR7QY\"PVKZ&fSM\r;";
      kb[283] = "SC=G\fBCK=\u0003k\u0012^T'\u0014<E\u0000\u0007zxRED\u0001yA\u0013\u0015P\t}";
      kb[284] = "\u0013\u001fdC0A\u0000\u0007~\u0018HF\u0014\u0000|C$t@D&\u001at#D\u000e|X)\\\u0000\rg\u001eH";
      kb[285] = "bu>#ddf:=.pT7/j>[9$\bi0\u0014na3=#/nh+<$\u0014i*+x k-)0>A)&87e>m%#q\u0004";
      kb[286] = "v]F@6brMS\u0013M}nJSF\u001a#7\u0019\u0006*ry}UE\u0016r\"vZ";
      kb[287] = "\\Q\u000f\u000b#\u0005\n\u0002C`rkZY\u001e\r*\u0012\u001aTK\u0007/k\t\u0006\u0003\u001em\tZ\u0000J\u0018\u0013";
      kb[288] = "rRAW\u001d\u001ak\u0012\f\u0003|\u0017\tSZW\u0011Gp\u0013W\u0002\u001bB\t\u0012\u0007F\u0010\u001fm\u000bG\u000bD~";
      kb[289] = "wi<o\b9{om?m)\u001d{k1\u0002\u007f'l?/R@";
      kb[290] = "\bnO9WcQiJ3112iU5\\fK)X`Vc2jW6S<Vo\rbU_";
      kb[291] = "\"|`t\u0001\f{{e~g]\u0018{zx\n\ta;w-\u0000\f\u0018xx{\u0005S|}\"/\u00030";
      kb[292] = "'5\u001e\u0018&,fe\n\u0010\"\u0015{a\u0019@{yI6T\u0019-\u0015'6X\u0018 leb\u0007]d\u0015'eUZvkl`\u0000Q$\u0015'm\\Bl/ae\u0019\u0011&\u0015";
      kb[293] = "\u0017-\u0003z\u0007IQ8\u0006'X.GC_}UC\u0017:\u001fp\u0000I\u0012C\\\u007fVLM'Y%\u0002J.";
      kb[294] = "V7x~\u0001]\u0000d4\u0015V3P?ix\bJ\u00102<r\r3S=jwRWVg>q1";
      kb[295] = "o:2a~\u00186}z%\u0002FS9v bGo`q%h";
      kb[296] = "6s+7\u000f672c$5lk>r>Y^8{*e50orh3K{j'ca50b-p:Q58yvY";
      kb[297] = "r>\rL3I|=\u0002S\u0003Q\u001euUZn\u0001g5X\u000fd\u0004\u001erAV\u007fYa6BM98";
      kb[298] = "Lp\u000f;\u0012_XjH9h\u0001P}\u0012b\u00043\u00049H?h\u0015L|L\u007fS\u0001V;N\u0005\u001a\u001dG;Hu\u0019\u0016F}r";
      kb[299] = "d\u001cG%\u000fpk\u0010\u0018{tli\u0010\u0017x\u0018^8QK H\tmU\u0006a\nk>SOgt";
      kb[300] = "ww\u00151\rdso\u00064kgyj\t=\u0007U$-Sbkhwn\u000e\"\t{otUZ\u000br$,\u0012#\u0004~{ri";
      kb[301] = "eDx=E83\u00174V\u001fVcLi;L/#A<1IV)Gxn\b1<Cu-u";
      kb[302] = "'\u001dTc\u0001N?\u0015I?}Q,\u0003P8\u0011c~@\ne}\t3\u001fL>\u0002M0\u0004\n_MW|\u0006Q3\u0001\tp\u001e0";
      kb[303] = "Cko>~TG{zm\u0005K[|z8R\u0015\u0000('T:OHclh:\u0014Cl";
      kb[304] = "TL\u000fL.\u001cTK\u0019E9p\u0004q^E,\u001dT\b\u001eHy\u0017Qq\u0015R=N\u0017J\u0001HzLm";
      kb[305] = "=\u000b[\u0000\u000e\u001cuVSPRrb]I\u000b\b\u001eP\f\tZWr=\tMR\rI=\u0000US\nr";
      kb[306] = "]{fz\u0006\u0013\u001c(h#\u0003~\n|az\u0016~\u0016a|'V\u000e\u0015j}al\f\u001db<'\u001c\u000f\u0016cz\u001d";
      kb[307] = "ziX-B-;:VtG@9mE,D@1sBp\u001202xC6(zzr\u0001(\u0013zsj\u0000/(";
      kb[308] = "W\u0002'\u001c89\u0003R?\u001f5G\fA*\u001d`;\nGG]9y\u000e]>Zcw\u0002DG";
      kb[309] = "B\u0016J&\u000eI\u0016KW8X2\u0017\u0017Q\u0012\u0001O\u0015z\u0010*\u0005N\u0019\u0005T)\u001e\bx";
      kb[310] = "d\u001aA\r\u0016ZaLV\u000b\u0005$7!\u0006\u0012\u0003IgXF\u001fVCb!\u0006IR\u001f$\u0011VM\u0003U4!";
      kb[311] = "Kz9\u0006p\\\n)7_u1\u001be0\u0007 1\u0000`#[ A\u0003k\"\u001d\u001aC\u000bcc[j@\u0000b%ahH\b#c\u0011kC\teY";
      kb[312] = "TZ\u0007\bxvPJ\u0012[\u0003iLM\u0012\u000eT7\u0014\u0018Lb<m_R\u0004^<6T]";
      kb[313] = "O]1J=!N]4B|Q\u0013ZwFg=!\r0\u001a0hv^2W~/\u0014\r4\u001exQOSdDc5J\t0B\u0000";
      kb[314] = "uX\u0019[T~&DS\\V\u0013%(XG\u0000~uQ\u0018JUtp([Q\u0017itE\bM]nv(";
      kb[315] = "RJXe*\u0006[H\u0005<6d\u0001&Y`\"\tR_\u0019mw\u0003W&Ses\u001d\nJ\u001f;\u007f\u0005k";
      kb[316] = "<6\\;hTje\u0010P<::>M=aCz3\u00187d:9<N2;^<f\u001a4X";
      kb[317] = "=\u000e~\f=&k]2ggH;\u0006o\n41{\u000b:\u00001H1\u0003>\u001el$}]2\u0006\r";
      kb[318] = "O\u001f\bG\u0019G\u0019LD,O)I\u0017\u0019A\u0010P\t\u001aLK\u0015)J\u0015\u001aNJMOONH)";
      kb[319] = "ZsQ[\u000e?\u00049H\t\u000f@\u0006.W\u000b\u0019,4z\u0014TNxcz\u001aW\u001fy\nyS\u0017\u0005 c";
      kb[320] = "s\"]~o\u0011w:N{\t\u0012}?Are )s\u0018,3w*|An8\t~,Ym5w";
      kb[321] = "dk8[Aw21:XX\u000b6\r<BMfdt|O\u0018la\ro\u001dPu#o<\u001b\u0019s]";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = kb[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(lb[var4]);
            kb[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = kb[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = lb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            kb[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  kb[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1330266941997595L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = kb[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = lb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  kb[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1330266941997595L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        kb[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1330266941997595L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 113;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 221;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 122;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 186;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 68;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 223;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 113;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 221;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 122;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d3",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoCart var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$0", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoCart var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoCart var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoCart var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AutoCart var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$6", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AutoCart var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$7", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AutoCart var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$3", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AutoCart var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$4", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(AutoCart var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$new$8", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10(double var0) {
         MethodHandle var6 = bindingCache10;
         MethodHandle var5 = bindingCache10;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(D)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/d3", "lambda$solveShotRotation$9", "(D[F)Z"),
                  SourceSupport.methodType("([F)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var3.invokeExact((double)var0);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Runnable invokeBinding11(AutoCart var0, BlockHitResult var1) {
         MethodHandle var6 = bindingCache11;
         MethodHandle var5 = bindingCache11;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d3;Lnet/minecraft/util/hit/BlockHitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d3", "lambda$onTick$10", "(Lnet/minecraft/util/hit/BlockHitResult;)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var3.invokeExact((AutoCart)var0, (BlockHitResult)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
