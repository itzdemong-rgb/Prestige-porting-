package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.MouseInputManager;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoClicker extends Module {
   private ModeSetting a;
   private ModeSetting c;
   private IntSetting d;
   private FloatSetting e;
   private FloatSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private FloatSetting i;
   private FloatSetting j;
   private ElapsedTimer k;
   private float l;
   private float m;
   private float n;
   private int o;
   private long p;
   private float q;
   private static final long r = 122182795919662L;
   private static final String[] s;
   private static final String[] t;
   private static final Map u = new HashMap(13);
   private static final Object[] v = new Object[89];
   private static final String[] w = new String[89];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   public AutoClicker() {
      super();
      long var10001 = 9860674628674L ^ 116536449571691L;
      var10001 = 9860674628674L ^ 25843031121557L;
      var10001 = 9860674628674L ^ 52164432582560L;
      var10001 = 9860674628674L ^ 112623216983942L;
      var10001 = 9860674628674L ^ 96991478245358L;

      this.k = new ElapsedTimer(106698256430889L);
      this.l = 200.0F;
      this.n = -1.0F;
      this.o = -1;
      IntSetting var10000 = this.d;
      Object[] var14 = new Object[]{invokeBinding1(this), 43459238656994L};
      IntSetting var13 = var10000;
      var13.aReturningIntSetting(var14);
      ModeSetting var29 = this.c;
      Object[] var16 = new Object[]{invokeBinding2(this), 121607650890692L};
      ModeSetting var15 = var29;
      var15.aReturningModeSetting(var16);
      FloatSetting var30 = this.i;
      Object[] var18 = new Object[]{invokeBinding3(this), 34595201528535L};
      FloatSetting var17 = var30;
      var17.aReturningFloatSetting(var18);
      FloatSetting var31 = this.f;
      Object[] var20 = new Object[]{invokeBinding4(this), 34595201528535L};
      FloatSetting var19 = var31;
      var19.aReturningFloatSetting(var20);
      FloatSetting var32 = this.j;
      Object[] var22 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var21 = var32;
      var21.aReturningFloatSetting(var22);
      BooleanSetting var33 = this.h;
      Object[] var24 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var23 = var33;
      var23.aReturningBooleanSetting(var24);
      BooleanSetting var34 = this.g;
      Object[] var26 = new Object[]{invokeBinding7(this), 88791076916140L};
      BooleanSetting var25 = var34;
      var25.aReturningBooleanSetting(var26);
      FloatSetting var35 = this.e;
      Object[] var28 = new Object[]{invokeBinding8(this), 34595201528535L};
      FloatSetting var27 = var35;
      var27.aReturningFloatSetting(var28);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 122182795919662L ^ var2;
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      short var10001 = 6986;
      long var10002 = 5343732414856573670L ^ var2;
      String var6 = "Ghost";
      String var5 = var10000;
      return var5.equals(var6);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 121547201430655L;
      long var6 = var2 ^ 104796557709698L;
      Object[] var9 = new Object[]{var4};
      AutoClicker var8 = this;
      var8.jReturningVoid(var9);
      this.o = -1;
      this.q = 0.0F;
      FloatSetting var10 = this.e;
      Float var11 = (Float)var10.aReturningObject();
      float var10002 = var11;
      float var13 = 1.0F;
      float var12 = var10002;
      var10002 = Math.max(var12, var13);
      FloatSetting var14 = this.f;
      Float var15 = (Float)var14.aReturningObject();
      float var10003 = var15;
      Object[] var10006 = new Object[]{null, null, var6};
      var10006[1] = var10003;
      var10006[0] = var10002;
      Object[] var16 = var10006;
      this.l = 1000.0F / RandomUtil.aReturningFloat(var16);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 84305891947009L ^ 55176131716117L;
      var10001 = 84305891947009L ^ 116933338372609L;
      var10001 = 84305891947009L ^ 99098934700899L;
      var10001 = 84305891947009L ^ 122811589579907L;
      var10001 = 84305891947009L ^ 2160477904425L;
      var10001 = 84305891947009L ^ 102367364115901L;
      var10001 = 84305891947009L ^ 63371269863164L;
      int var18 = Event.cReturningInt();
      int var130 = var18;
      MinecraftClient var129 = b;
      MinecraftClient var95 = var129;
      MinecraftClient var94 = var129;
      if (var130 != 0) {
         MinecraftClient var21 = var94;
         Screen var131 = var21.currentScreen;
         if (var131 != null) {
            return;
         }

         MinecraftClient var132 = b;
         var95 = var132;
      }

      MinecraftClient var24 = var95;
      ClientPlayerEntity var133 = var24.player;
      if (var133 != null) {
         MouseInputManager var10000 = Prestige.j;
         Object[] var26 = new Object[]{38614768952962L};
         MouseInputManager var25 = var10000;
         boolean var185 = var25.aReturningBoolean(var26);
         int var135 = var18;
         boolean var134 = var185;
         boolean var98 = var134;
         boolean var96 = var134;
         if (var135 != 0) {
            boolean var136 = var96;
            boolean var97 = var136;
            boolean var137 = var97;
            if (var137) {
               return;
            }

            ModeSetting var29 = this.a;
            String var186 = (String)var29.aReturningObject();
            String var31 = "Interval";
            String var30 = var186;
            var98 = var30.equals(var31);
         }

         int var139 = var18;
         boolean var138 = var98;
         boolean var109 = var138;
         boolean var99 = var138;
         if (var139 != 0) {
            boolean var140 = var99;
            if (var140) {
               ElapsedTimer var189 = this.k;
               IntSetting var33 = this.d;
               Integer var34 = (Integer)var33.aReturningObject();
               float var199 = var34.floatValue();
               Object[] var203 = new Object[]{null, 139098136696340L};
               var203[0] = var199;
               Object[] var36 = var203;
               ElapsedTimer var35 = var189;
               boolean var141 = var35.aReturningBoolean(var36);
               if (!var141) {
                  return;
               }

               MouseInputManager var107;
               byte var108;
               label94: {
                  var10000 = Prestige.j;
                  ModeSetting var39 = this.c;
                  String var200 = (String)var39.aReturningObject();
                  String var41 = "Left";
                  String var40 = var200;
                  byte var201 = ((byte)((var40.equals(var41)) ? 1 : 0));
                  int var144 = var18;
                  byte var143 = var201;
                  MouseInputManager var142 = var10000;
                  MouseInputManager var104 = var142;
                  byte var105 = var143;
                  MouseInputManager var100 = var142;
                  byte var101 = var143;
                  if (var144 != 0) {
                     byte var146 = var101;
                     MouseInputManager var145 = var100;
                     MouseInputManager var106 = var145;
                     MouseInputManager var102 = var145;
                     if (var146 == 0) {
                        var108 = 1;
                        var107 = var106;
                        break label94;
                     }

                     MouseInputManager var147 = var102;
                     MouseInputManager var103 = var147;
                     var105 = 0;
                     var104 = var103;
                  }

                  byte var149 = var105;
                  MouseInputManager var148 = var104;
                  var107 = var148;
                  var108 = var149;
               }

               Object[] var204 = new Object[]{null, null, 85057401875496L};
               var204[1] = 0.0F;
               var204[0] = Integer.valueOf(var108);
               Object[] var44 = var204;
               MouseInputManager var43 = var107;
               var43.aReturningVoid(var44);
               ElapsedTimer var191 = this.k;
               Object[] var46 = new Object[]{42835128969216L};
               ElapsedTimer var45 = var191;
               var45.aReturningVoid(var46);
               return;
            }

            MinecraftClient var47 = b;
            ClientPlayerEntity var48 = var47.player;
            var109 = var48.isUsingItem();
         }

         int var151 = var18;
         boolean var150 = var109;
         boolean var111 = var150;
         boolean var110 = var150;
         if (var151 != 0) {
            boolean var152 = var110;
            if (var152) {
               return;
            }

            BooleanSetting var50 = this.g;
            Boolean var51 = (Boolean)var50.aReturningObject();
            var111 = var51;
         }

         boolean var115;
         int var154 = var18;
         boolean var153 = var111;
         var115 = var153;
         boolean var112 = var153;
         label123:
         if (var154 != 0) {
            boolean var155 = var112;
            if (var155) {
               MinecraftClient var53 = b;
               boolean var187 = var53.crosshairTarget instanceof BlockHitResult;
               int var157 = var18;
               boolean var156 = var187;
               var115 = var156;
               boolean var113 = var156;
               if (var157 == 0) {
                  break label123;
               }

               boolean var158 = var113;
               boolean var114 = var158;
               boolean var159 = var114;
               if (var159) {
                  return;
               }
            }

            BooleanSetting var56 = this.h;
            Boolean var57 = (Boolean)var56.aReturningObject();
            var115 = var57;
         }

         MinecraftClient var122;
         label116: {
            label115: {
               int var161 = var18;
               boolean var160 = var115;
               boolean var119 = var160;
               boolean var116 = var160;
               if (var161 != 0) {
                  boolean var162 = var116;
                  if (!var162) {
                     break label115;
                  }

                  int var164 = var18;
                  MinecraftClient var163 = b;
                  var122 = var163;
                  MinecraftClient var117 = var163;
                  if (var164 == 0) {
                     break label116;
                  }

                  MinecraftClient var165 = var117;
                  MinecraftClient var118 = var165;
                  MinecraftClient var60 = var118;
                  ClientPlayerEntity var61 = var60.player;
                  Object[] var62 = new Object[]{var61.getMainHandStack(), 19476550655932L};
                  boolean var166 = InventoryUtil.aReturningBoolean(var62);
                  var119 = var166;
               }

               boolean var167 = var119;
               if (!var167) {
                  int var169 = var18;
                  MinecraftClient var168 = b;
                  var122 = var168;
                  MinecraftClient var120 = var168;
                  if (var169 == 0) {
                     break label116;
                  }

                  MinecraftClient var170 = var120;
                  MinecraftClient var121 = var170;
                  MinecraftClient var65 = var121;
                  ClientPlayerEntity var66 = var65.player;
                  ItemStack var67 = var66.getMainHandStack();
                  boolean var171 = var67.getItem() instanceof AxeItem;
                  if (!var171) {
                     return;
                  }
               }
            }

            var122 = b;
         }

         label143: {
            MinecraftClient var70 = var122;
            HitResult var20 = var70.crosshairTarget;
            int var173 = var18;
            HitResult var172 = var20;
            HitResult var124 = var172;
            HitResult var123 = var172;
            if (var173 != 0) {
               boolean var174 = var123 instanceof EntityHitResult;
               if (!var174) {
                  this.o = -1;
                  break label143;
               }

               HitResult var175 = var20;
               var124 = var175;
            }

            EntityHitResult var19 = (EntityHitResult)var124;
            EntityHitResult var73 = var19;
            Entity var74 = var73.getEntity();
            int var184 = var74.getId();
            int var177 = var18;
            int var176 = var184;
            int var126 = var176;
            int var125 = var176;
            if (var177 != 0) {
               int var179 = this.o;
               int var178 = var125;
               if (var178 != var179) {
                  this.o = var184;
                  this.p = System.currentTimeMillis();
                  Object[] var77 = new Object[]{24797974174050L};
                  AutoClicker var76 = this;
                  this.q = var76.bReturningFloat(var77);
               }

               long var205;
               var126 = (var205 = System.currentTimeMillis() - this.p - (long)this.q) == 0L ? 0 : (var205 < 0L ? -1 : 1);
            }

            int var180 = var126;
            if (var180 < 0) {
               return;
            }
         }

         int var182 = var18;
         ElapsedTimer var181 = this.k;
         ElapsedTimer var128 = var181;
         ElapsedTimer var127 = var181;
         if (var182 != 0) {
            float var198 = this.l;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var198;
            Object[] var80 = var10004;
            ElapsedTimer var79 = var127;
            boolean var183 = var79.aReturningBoolean(var80);
            if (!var183) {
               return;
            }

            var10000 = Prestige.j;
            Object[] var10005 = new Object[]{null, null, 85057401875496L};
            var10005[1] = 0.0F;
            var10005[0] = 0;
            Object[] var84 = var10005;
            MouseInputManager var83 = var10000;
            var83.aReturningVoid(var84);
            FloatSetting var85 = this.e;
            Float var86 = (Float)var85.aReturningObject();
            float var10002 = var86;
            float var88 = 1.0F;
            float var87 = var10002;
            var10002 = Math.max(var87, var88);
            FloatSetting var89 = this.f;
            Float var90 = (Float)var89.aReturningObject();
            float var10003 = var90;
            Object[] var10006 = new Object[]{null, null, 128703941739773L};
            var10006[1] = var10003;
            var10006[0] = var10002;
            Object[] var91 = var10006;
            this.l = 1000.0F / RandomUtil.aReturningFloat(var91);
            var128 = this.k;
         }

         Object[] var93 = new Object[]{42835128969216L};
         ElapsedTimer var92 = var128;
         var92.aReturningVoid(var93);
      }
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 122182795919662L ^ var2;
      long var4 = var2 ^ 55747061406918L;
      long var6 = var2 ^ 53014998565031L;
      int var10000 = Event.cReturningInt();
      FloatSetting var9 = this.i;
      Float var10 = (Float)var9.aReturningObject();
      this.n = var10;
      int var8 = var10000;
      int var26 = var8;
      AutoClicker var25 = this;
      AutoClicker var24 = var25;
      AutoClicker var23 = var25;
      if (var26 != 0) {
         FloatSetting var11 = var23.i;
         Float var12 = (Float)var11.aReturningObject();
         float var30;
         int var27 = (var30 = var12 - 0.0F) == 0.0F ? 0 : (var30 < 0.0F ? -1 : 1);
         if (var27 <= 0) {
            this.m = 0.0F;
            return;
         }

         var24 = this;
      }

      FloatSetting var15 = this.i;
      Float var16 = (Float)var15.aReturningObject();
      float var10001 = var16;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 15.0F;
      var10005[0] = var10001;
      Object[] var17 = var10005;
      var10001 = cReturningFloat(var17);
      FloatSetting var18 = this.i;
      Float var19 = (Float)var18.aReturningObject();
      float var10002 = var19 - 50.0F;
      FloatSetting var20 = this.i;
      Float var21 = (Float)var20.aReturningObject();
      float var10003 = var21 + 50.0F;
      Object[] var10006 = new Object[]{null, null, null, var6};
      var10006[2] = var10003;
      var10006[1] = var10002;
      var10006[0] = var10001;
      Object[] var22 = var10006;
      var24.m = dReturningFloat(var22);
   }

   private float bReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 122182795919662L ^ var2;
      long var4 = var2 ^ 67449587681612L;
      long var6 = var2 ^ 106601849164964L;
      long var8 = var2 ^ 108234093922501L;
      int var10 = Event.cReturningInt();
      FloatSetting var12 = this.i;
      Float var13 = (Float)var12.aReturningObject();
      float var51;
      int var10000 = (var51 = var13 - this.n) == 0.0F ? 0 : (var51 < 0.0F ? -1 : 1);
      int var36 = var10;
      int var35 = var10000;
      int var29 = var35;
      int var28 = var35;
      if (var36 != 0) {
         int var37 = var28;
         if (var37 != 0) {
            Object[] var16 = new Object[]{var4};
            AutoClicker var15 = this;
            var15.jReturningVoid(var16);
         }

         float var52;
         var29 = (var52 = this.m - 0.0F) == 0.0F ? 0 : (var52 < 0.0F ? -1 : 1);
      }

      float var34;
      label30: {
         int var39 = var10;
         int var38 = var29;
         int var32 = var38;
         int var30 = var38;
         if (var39 != 0) {
            int var40 = var30;
            if (var40 <= 0) {
               return 0.0F;
            }

            FloatSetting var20 = this.j;
            Float var21 = (Float)var20.aReturningObject();
            float var48 = var21;
            int var42 = var10;
            float var41 = var48;
            float var33 = var41;
            float var31 = var41;
            if (var42 == 0) {
               float var46 = var33;
               var34 = var46;
               break label30;
            }

            float var53;
            int var43 = (var53 = var31 - 0.0F) == 0.0F ? 0 : (var53 < 0.0F ? -1 : 1);
            var32 = var43;
         }

         int var44 = var32;
         if (var44 > 0) {
            FloatSetting var23 = this.j;
            Float var24 = (Float)var23.aReturningObject();
            float var45 = var24;
            var34 = var45;
         } else {
            var34 = 1.0F;
         }
      }

      float var11 = var34;
      float var49 = this.m;
      Object[] var10004 = new Object[]{null, null, var6};
      var10004[1] = var11;
      var10004[0] = var49;
      Object[] var26 = var10004;
      float var50 = cReturningFloat(var26);
      Object[] var10005 = new Object[]{null, null, null, var8};
      var10005[2] = 500.0F;
      var10005[1] = 80.0F;
      var10005[0] = var50;
      Object[] var27 = var10005;
      return dReturningFloat(var27);
   }

   private static float cReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      float var4 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 122182795919662L ^ var2;
      long var5 = var2 ^ 3812581542203L;
      Object[] var10004 = new Object[]{null, null, var5};
      var10004[1] = 1.0F;
      var10004[0] = 1.0E-6F;
      Object[] var9 = var10004;
      float var7 = RandomUtil.aReturningFloat(var9);
      var10004 = new Object[]{null, null, var5};
      var10004[1] = 1.0F;
      var10004[0] = 0.0F;
      Object[] var10 = var10004;
      float var8 = RandomUtil.aReturningFloat(var10);
      double var11 = var7;
      double var13 = -2.0 * Math.log(var11);
      double var10002 = Math.sqrt(var13);
      double var15 = (Math.PI * 2) * var8;
      return var1 + var4 * (float)(var10002 * Math.cos(var15));
   }

   private static float dReturningFloat(Object[] var0) {
      float var4 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var5 = (Float)var0[2];
      long var2 = (Long)var0[3];
      long var10000 = 122182795919662L ^ var2;
      float var7 = var4;
      float var6 = var5;
      float var9 = Math.min(var6, var7);
      float var8 = var1;
      return Math.max(var8, var9);
   }

   private boolean lambda$new$7(Float var1) {
      long var10001 = 126231310745157L ^ 38609193415847L;
      int var6 = Event.bReturningInt();
      Object[] var8 = new Object[]{89970491362018L};
      AutoClicker var7 = this;
      byte var10000 = ((byte)((var7.dReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var10000;
      int var13 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            return false;
         }

         FloatSetting var10 = this.i;
         Float var11 = (Float)var10.aReturningObject();
         float var25;
         int var20 = (var25 = var11 - 0.0F) == 0.0F ? 0 : (var25 < 0.0F ? -1 : 1);
         var13 = var20;
      }

      int var22 = var6;
      int var21 = var13;
      int var15 = var21;
      int var14 = var21;
      if (var22 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var15);
      } else {
         int var23 = var14;
         if (var23 > 0) {
            byte var26 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var26);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$6(Float var1) {
      long var10001 = 119871699166437L ^ 66890577849863L;
      Object[] var7 = new Object[]{89970491362018L};
      AutoClicker var6 = this;
      return var6.dReturningBoolean(var7);
   }

   private boolean lambda$new$5(Boolean var1) {
      long var10001 = 111766128439396L ^ 57679117531782L;
      Object[] var7 = new Object[]{89970491362018L};
      AutoClicker var6 = this;
      return var6.dReturningBoolean(var7);
   }

   private boolean lambda$new$4(Boolean var1) {
      long var10001 = 42328985960146L ^ 131583286080560L;
      Object[] var7 = new Object[]{89970491362018L};
      AutoClicker var6 = this;
      return var6.dReturningBoolean(var7);
   }

   private boolean lambda$new$3(Float var1) {
      long var10001 = 96138829535873L ^ 7301241311331L;
      Object[] var7 = new Object[]{89970491362018L};
      AutoClicker var6 = this;
      return var6.dReturningBoolean(var7);
   }

   private boolean lambda$new$2(Float var1) {
      long var10001 = 39199065652235L ^ 125848402245353L;
      Object[] var7 = new Object[]{89970491362018L};
      AutoClicker var6 = this;
      return var6.dReturningBoolean(var7);
   }

   private boolean lambda$new$1(Integer var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Interval";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(String var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Interval";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(80064323838244L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      String var6 = "æä<³\u001d]u\t Ë\u0090FÄÌûv\u0097£*)\u000eù\u0099ÜZ\u0092òºu\u001c¾Y\u0018|}¸ö{\u0093þg\u008bÊ«\u008aÉ{\u0092Ç~à¸F\u009bãn¾";
      int var8 = "æä<³\u001d]u\t Ë\u0090FÄÌûv\u0097£*)\u000eù\u0099ÜZ\u0092òºu\u001c¾Y\u0018|}¸ö{\u0093þg\u008bÊ«\u008aÉ{\u0092Ç~à¸F\u009bãn¾".length();
      char var5 = ' ';
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     s = var9;
                     t = new String[4];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "\"\u0085<B\u0016ìwè\u0092\u008eÎÀ\u00ad \u0015c\u0010î¿ÂM*G\u0082\u0090ÉÛL¡\u0014}M¶";
                  var8 = "\"\u0085<B\u0016ìwè\u0092\u008eÎÀ\u00ad \u0015c\u0010î¿ÂM*G\u0082\u0090ÉÛL¡\u0014}M¶".length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8802;
      if (t[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])u.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               u.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d4", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = s[var5].getBytes("ISO-8859-1");
         t[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return t[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d4",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = w[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = v[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 47;
            yield var15;
         }
         case 1 -> {
            byte var16 = 20;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 31;
            yield var18;
         }
         case 4 -> {
            byte var19 = 17;
            yield var19;
         }
         case 5 -> {
            byte var20 = 23;
            yield var20;
         }
         case 6 -> {
            byte var21 = 58;
            yield var21;
         }
         case 7 -> {
            byte var22 = 16;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 44;
            yield var24;
         }
         case 10 -> {
            byte var25 = 29;
            yield var25;
         }
         case 11 -> {
            byte var26 = 14;
            yield var26;
         }
         case 12 -> {
            byte var27 = 13;
            yield var27;
         }
         case 13 -> {
            byte var28 = 40;
            yield var28;
         }
         case 14 -> {
            byte var29 = 18;
            yield var29;
         }
         case 15 -> {
            byte var30 = 2;
            yield var30;
         }
         case 16 -> {
            byte var31 = 63;
            yield var31;
         }
         case 17 -> {
            byte var32 = 24;
            yield var32;
         }
         case 18 -> {
            byte var33 = 53;
            yield var33;
         }
         case 19 -> {
            byte var34 = 5;
            yield var34;
         }
         case 20 -> {
            byte var35 = 43;
            yield var35;
         }
         case 21 -> {
            byte var36 = 55;
            yield var36;
         }
         case 22 -> {
            byte var37 = 57;
            yield var37;
         }
         case 23 -> {
            byte var38 = 51;
            yield var38;
         }
         case 24 -> {
            byte var39 = 59;
            yield var39;
         }
         case 25 -> {
            byte var40 = 6;
            yield var40;
         }
         case 26 -> {
            byte var41 = 0;
            yield var41;
         }
         case 27 -> {
            byte var42 = 28;
            yield var42;
         }
         case 28 -> {
            byte var43 = 9;
            yield var43;
         }
         case 29 -> {
            byte var44 = 30;
            yield var44;
         }
         case 30 -> {
            byte var45 = 10;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 38;
            yield var47;
         }
         case 33 -> {
            byte var48 = 22;
            yield var48;
         }
         case 34 -> {
            byte var49 = 62;
            yield var49;
         }
         case 35 -> {
            byte var50 = 56;
            yield var50;
         }
         case 36 -> {
            byte var51 = 41;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 8;
            yield var53;
         }
         case 39 -> {
            byte var54 = 34;
            yield var54;
         }
         case 40 -> {
            byte var55 = 61;
            yield var55;
         }
         case 41 -> {
            byte var56 = 54;
            yield var56;
         }
         case 42 -> {
            byte var57 = 25;
            yield var57;
         }
         case 43 -> {
            byte var58 = 46;
            yield var58;
         }
         case 44 -> {
            byte var59 = 15;
            yield var59;
         }
         case 45 -> {
            byte var60 = 12;
            yield var60;
         }
         case 46 -> {
            byte var61 = 60;
            yield var61;
         }
         case 47 -> {
            byte var62 = 45;
            yield var62;
         }
         case 48 -> {
            byte var63 = 33;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 49;
            yield var65;
         }
         case 51 -> {
            byte var66 = 3;
            yield var66;
         }
         case 52 -> {
            byte var67 = 21;
            yield var67;
         }
         case 53 -> {
            byte var68 = 35;
            yield var68;
         }
         case 54 -> {
            byte var69 = 52;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 42;
            yield var72;
         }
         case 58 -> {
            byte var73 = 1;
            yield var73;
         }
         case 59 -> {
            byte var74 = 27;
            yield var74;
         }
         case 60 -> {
            byte var75 = 4;
            yield var75;
         }
         case 61 -> {
            byte var76 = 36;
            yield var76;
         }
         case 62 -> {
            byte var77 = 26;
            yield var77;
         }
         default -> 37;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            w[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      v[0] = "'8T0t\u0000,7E\u007f\u0017\r91";
      v[1] = double.class;
      w[1] = "java/lang/Double";
      v[2] = "J+\u000fpYT\\+\n*JCK`\t,FWZ'\u001e;\r@G";
      v[3] = "HM|#f\u0007=mw,wH\\c|'s\u0012(";
      v[4] = float.class;
      w[4] = "java/lang/Float";
      v[5] = "\u0013\u0017eQe\u001c\u0018\u0018t\u001e\u0018\u0004\u000b\u001f}W";
      v[6] = "\u001f\u0003\u007f/`j\u0014\fn`\u0001d\u001f\u0007j:";
      v[7] = boolean.class;
      w[7] = "java/lang/Boolean";
      v[8] = "rU\r\u000bj6dU\bQy!s\u001e\u000bWu5bY\u001c@>\"P";
      v[9] = "c\\{_]>c\\l\u0003Q1y\u0017l\u001dQ$~f>F\tn";
      v[10] = "@5\u000b\u001e4Z@5\u001cB8UZ~\u001c\\8@]\u000fN\u0007`\u0001";
      v[11] = "uT\u000fX15~[\u001e\u0017L lA\u001cT";
      v[12] = long.class;
      w[12] = "java/lang/Long";
      v[13] = "h4Imr.h4^1~!r\u007f^/~4u\u000e\u000er/";
      v[14] = "z\u0002\u0011EMCz\u0002\u0006\u0019AL`I\u0006\u0007AYg8QX\u0017";
      v[15] = "9|I\u0017K|9|^KGs#7^UGf$F\f\u000b\u001f\"";
      v[16] = int.class;
      w[16] = "java/lang/Integer";
      v[17] = "EV\u0015flDSV\u0010<\u007fSD\u001d\u0013:sGUZ\u0004-8P\u0015";
      v[18] = "\u0003G4Wz(vg?Xkg\u0017i4So=c";
      v[19] = "\u001f{\u001f,\u001a\t\u0014t\u000ecv\n\u001av\f,Z";
      v[20] = "I<\u0013M/?_<\u0016\u0017<(Hw\u0015\u00110<Y0\u0002\u0006{.h";
      v[21] = "\u0002 #Zd\u0015\u0014 &\u0000w\u0002\u0003k%\u0006{\u0016\u0012,2\u00110\u0006\n,0\u001ajK670\u0007j\f\u0001 ";
      v[22] = "B\u000fz\f\u0011vT\u000f\u007fV\u0002aCD|P\u000euR\u0003kGEgT";
      v[23] = "&\u0019]<*W&\u0019J`&X<RJ~&M;#\u001e&q";
      v[24] = "_2\rD7%T=\u001c\u000bP'A6\u001c@k";
      v[25] = "M\u0019Za\u0010\u0015[\u0019_;\u0003\u0002LR\\=\u000f\u0016]\u0015K*D\u0003p";
      v[26] = "g9\u0016\t3^\u0012\u0019\u001d\u0006\"\u0011s\u0017\u0016\r&K\u0007";
      v[27] = void.class;
      w[27] = "java/lang/Void";
      v[28] = "e#\u0016y8#\u0010\u0003\u001dv)lq\r\u0016}-6\u0005";
      v[29] = "\r)\u0003H?gx\t\bG.(\u0019\u0007\u0003L*rm";
      v[30] = "hx9zC)\u001dX2uRf|V9~V<\b";
      v[31] = "\u0014$\u000eII\u0016\u0014$\u0019\u0015E\u0019\u000eo\u0019\u000bE\f\t\u001eHT\u001d";
      v[32] = "\u000f\n\u0003ej,\u000f\n\u00149f#\u0015A\u0014'f6\u00120Dr1s";
      v[33] = "\f\u001fOT/d\u0007\u0010^\u001bGd\t\u001fM";
      v[34] = "cx>\u0013ILhw/\\*A}z 7\u001fCli<\u001b\bN";
      v[35] = "?vXU-8)v]\u000f>/>=^\t2;/zI\u001ey+4";
      v[36] = "!qE\u0005d~TQN\nu15_E\u0001qkA";
      v[37] = "\u0003DTy\n:vd_v\u001bu\u0017jT}\u001f/c";
      v[38] = "b3pJ0e\u0017\u0013{E!*v\u001dpN%p\u0002";
      v[39] = "e\\\u000f\u000f\u0005t\u0010|\u0004\u0000\u0014;qr\u000f\u000b\u0010a\u0005";
      v[40] = ".\"zZ/\u000e[\u0002qU>A:\fz^:\u001bN";
      v[41] = "'33,IC9;)c4S9";
      v[42] = "+U\u001bQ@c=U\u001e\u000bSt*\u001e\u001d\r_`;Y\n\u001a\u0014w\u0007";
      v[43] = "\r ~6N0x\u0000u9_\u007f\u0019\u000e~2[%m";
      v[44] = "&\u000byuWz0\u000b|/Dm'@\u007f)Hy6\u0007h>\u0003n\b";
      v[45] = "\u00141M(Nza\u0011F'_5\u0000\u001fM,[ot";
      v[46] = "W\u0000mXD,A\u0000h\u0002W;VKk\u0004[/G\f|\u0013\u00108x";
      v[47] = "\u0006\u0007\u0016`\u000b;s'\u001do\u001at\u0012)\u0016d\u001e.f";
      v[48] = "\u0014m7YDb\u0002m2\u0003Wu\u0015&1\u0005[a\u0004a&\u0012\u0010v=";
      v[49] = "8K1\u00075uMk:\b$:,e1\u0003 `X";
      v[50] = "j09y\bcx0:qo3\u0007c(,\u0004bl`)&\u001dY";
      v[51] = "\u00196aa*\u0016I4j%O\u0010J50x#\"\u0018xh.OJ\u001e7;nw\u000b\u00166 \u001f";
      v[52] = "6\u0012\u00159ek<\u0014\n2\u00041{\u0001\u000b2b&Z\u001a\u00142A;b\u001f\u0010$\u0004j\u007f\u001fM3<0:\nI_";
      v[53] = "v:i,\u001cMh#h?\u007fFcZ)6N@`'u-\u0001\u001a\rf~l\u001eLp:e#D!v:i,\u001cMh#h?\u007f";
      v[54] = "T}\u001d#O9D#H%/n(b](V;C\"\u00172A\u0007T}\u001d#O9D#H%/";
      v[55] = ")\u0001F\r0\u0018g]\u0018\u0000S\u001cy\u000e\u001f\u0013\u0004K'^F\u007fb\u000er\u0013EN/\u0014h\u0000";
      v[56] = "\u0015T\u00178\u0013\"\u001bCO=\u007f?\u0011SH4\u0013\rA\u0011\u0012c\u007f0\u0013\u0015Ch\u00143\u0012\u001fZS";
      v[57] = "vm0W\"l+.rn)m*\u00172Q71',f\u001f(sL,6\u0015qgwxx\n3\fw(rS'7#fm\u0011L";
      v[58] = "\u001dxg\u0004\u0018v\u001b!i\u0014c-v3d\u0000\u001a{\u001ds.\u001a\rGM|n[\b|\u00192q\u0019c";
      v[59] = "?s\b\u001eWu3:UUle4mPH\u0005i\rcPX\u0001\u000fn0W\u001f\u0001h){\u000e\u001cl";
      v[60] = "Ha>R\u001a\fZa=Z}]%2/\u0007\u0016\rN1.\r\u000f6";
      v[61] = "4:aZnb2coJ\u00151_qb^lo41(D{S=0\"S+:\"ac@\u0015";
      v[62] = "yioLcwv,lO\u0007z\u0007\"$T~/lbnNi\u0013yioLcwv,lO\u0007";
      v[63] = "Kw\u0005<*\u000e\u0007r\u0004j\u001b\nuv\u0010<z\u000e\b*\u000bs c";
      v[64] = "U6\"xh\u0010Fm.dP\u000e;`.%+\u000eEmxbh";
      v[65] = "t\u0014\u000fkFW)WMRCP5n\u000foD\u000fq\u0017G5MGNW\u000b>\u0010\b7\u001fQ7X7";
      v[66] = "\u0002\u000bf\rw\\LW8\u0000\u0014XR\u0004?\u0013C\u000f\fSg\u007f{TZ\u00047\u0010*G\n\u0014";
      v[67] = "c7\u0000Od<pt\\X\u000f<h(RHQ;h2V44mwrP\u000f`#h0;";
      v[68] = "\\4\u0012::\\V%\u00178@W<5Z09\u0002Wu\u0010*.>^t\u001a=~WA%[.@";
      v[69] = "q\u001e/!-\u0019bXn'W\n\u0001\u0010c.._jP)49cq\u001e/!-\u0019bXn'W";
      v[70] = "\u0012|JbBsO?\b[WjRzsb\u0011\u007f\u00109\n*KvX\u0006Jf@+\u0017\u007f\u0002<Ic(";
      v[71] = "@\u0002\u000e \u0012(MTIcp?.\u0018F=\tjEX\f'\u001eV\u0013RTa\u001d1T\u0019\rbp";
      v[72] = "tt\rKC%2b]\u0014|#M{B\u0017\u0005v&;\b\r\u0012Jv4HL\u0017q\"zW\u000e|";
      v[73] = "\u0006Q:cS\"\u000b\u0007} 15hKr~H`\u0003\u000b8d_\\\n\n2s\u000f5\u0015[s`1";
      v[74] = "\u001aV\u0018\u001d\r\u001e\u001bT]Bb\tXPOD\u0019d\u001dF\u0017A\u000f\u0019A]X\u001bbY\u001bN\u001cM\u0005\u001eP\u0017\u001f ";
      v[75] = "Z$\u0007Y%YP5\u0002[_R:%OS&\u0007Qe\u0005I1;\u0007o]\u000f2\\@$\u0004\f_";
      v[76] = "]9b0hG\u0000z \tcN\u0017C`6}\u001a\fx4xbXgxdr;L\\,*my'\\| 4m\u001c\b2?v\u0006";
      v[77] = ")f\u00036\u001czxuS&pp+x\n<\u001cBx<Vdp+95\u0014>\u0013{;>P[";
      v[78] = "1Y/\u0016-u7\u0000!\u0006V(Z\u0012,\u0012/x1Rf\b8Da]&I=\u007f5\u00139\u000bV";
      v[79] = "q9O}C(,z\rDI/$COyApt:\u0007#H8KzK(\u0015w22\u0011!]H";
      v[80] = "l\u001d4aFbjD:q=?\u0007V7eDol\u0016}\u007fSS:\u001c%9P4}W|:=";
      v[81] = "\u0001&7+\u0011UOzi&rQQ)n5%\u0006\u000fz7Y\u0016N[$r \tMM#";
      v[82] = "\r[K}J!R^J>s\u007f\u0005DGh\u001fMQ\u0007\u0018?I\u001a\u0001C\u0018d\u001fb\u000fT@as";
      v[83] = "kC\r?\u007fBr\u0013Ri\r\u0016\u0014\\\u0013htC\u007f\u001cYrc\u007fkC\r?\u007fBr\u0013Ri\r";
      v[84] = "\u0002\u001b]>Z#\u0018PU4b4\u0000L\f:<3\u0000V\bFYe\u001f\u0016\u000e}\r+\u0000Te";
      v[85] = "l`'`\u001c\u001ej9)pgD\u0007+$d\u001e\u0013lkn~\t/<d.?\f\u0014h*1}g";
      v[86] = ">];B\u001as8\u00045Ra+U\u0001y\u001c\u001ay6\u0000yM\u0005B2Vu[Z!3V$Da";
      v[87] = "1EFPkM1CI_\t\u001fVOR\u0006pJ=\u000f\u0018\u001cgvk\u0005@Zd\u0011,N\u0019Y\t";
      v[88] = "i\u0001H\r;\f8\u0012\u0018\u001dW\u0006k\u001fA\u0007;48Z\u0018]W^<\u0000\u001b\r0\u0019wY\u0018`";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = v[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(w[var4]);
            v[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = v[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = w[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            v[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  v[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(440838502874031L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = v[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = w[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  v[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(440838502874031L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        v[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(440838502874031L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 112;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 170;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 241;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 72;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 119;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 211;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 112;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 170;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 241;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d4",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoClicker var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$1", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoClicker var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$0", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoClicker var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$6", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoClicker var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$3", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AutoClicker var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AutoClicker var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AutoClicker var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$4", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AutoClicker var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d4;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d4", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoClicker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
