package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.client.modules.state.AutoCrystalRenderAnimation;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.util.ExplosionDamageUtil;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.util.DroppedItemUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.MagmaCubeEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class AutoCrystal extends Module {
   public static boolean a;
   private BooleanSetting d;
   private BooleanSetting c;
   private BooleanSetting e;
   private MinMaxSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private ColorSetting j;
   private BooleanSetting k;
   private ElapsedTimer l;
   private BlockPos m;
   private float n;
   private AutoCrystalRenderAnimation o;
   private boolean p;
   private int q;
   private static final int r;
   private static final boolean s = false;
   private static final boolean t = true;
   private static final boolean u = true;
   private static final boolean v = true;
   private static final float w = 0.0F;
   private static final float x = 200.0F;
   private static final long y = 139497674086703L;
   private static final long[] z;
   private static final Integer[] A;
   private static final Map B = new HashMap(13);
   private static final Object[] C = new Object[182];
   private static final String[] D = new String[182];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;

   public AutoCrystal() {
      super();
      long var10001 = 107344212777156L ^ 737023619053L;
      var10001 = 107344212777156L ^ 74891419278212L;
      var10001 = 107344212777156L ^ 73875108027485L;

      this.l = new ElapsedTimer(106698256430889L);
      this.m = null;
      this.n = 0.0F;
      this.o = new AutoCrystalRenderAnimation(this, 38007880647833L);
      this.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.q = 0;
      ColorSetting var10000 = this.j;
      Object[] var10 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var9 = var10000;
      var9.aReturningColorSetting(var10);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 116176014403610L;
      long var6 = var2 ^ 96507572244946L;
      a = dev.prestige.recovery.SourceSupport.asBoolean(1);
      this.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.q = 0;
      AutoCrystalRenderAnimation var10000 = this.o;
      Object[] var9 = new Object[]{var4};
      AutoCrystalRenderAnimation var8 = var10000;
      var8.recoveryAccess_call_bReturningVoid(var9);
      EventBus var12 = Prestige.b;
      Object[] var11 = new Object[]{this.o, var6};
      EventBus var10 = var12;
      var10.aReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 97446187082759L;
      long var6 = var2 ^ 99036229876736L;
      a = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
      EventBus var10000 = Prestige.b;
      Object[] var9 = new Object[]{this.o, var6};
      EventBus var8 = var10000;
      var8.bReturningVoid(var9);
      AutoCrystalRenderAnimation var12 = this.o;
      Object[] var11 = new Object[]{var4};
      AutoCrystalRenderAnimation var10 = var12;
      var10.recoveryAccess_call_bReturningVoid(var11);
      this.m = null;
   }

   @Override
   public void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 0L;
      long var6 = var2 ^ 139091725966610L;
      int var8 = Event.bReturningInt();
      int var30 = var8;
      AutoCrystal var29 = this;
      AutoCrystal var28 = var29;
      AutoCrystal var20 = var29;
      if (var30 == 0) {
         AutoCrystal var9 = var20;
         boolean var31 = var9.aReturningBoolean();
         if (var31) {
            AutoCrystal var27;
            int var33 = var8;
            AutoCrystal var32 = this;
            var27 = var32;
            AutoCrystal var21 = var32;
            label35:
            if (var33 == 0) {
               AutoCrystal var34 = var21;
               AutoCrystal var22 = var34;
               boolean var35 = var22.p;
               if (!var35) {
                  int var37 = var8;
                  AutoCrystal var36 = this;
                  var27 = var36;
                  AutoCrystal var23 = var36;
                  if (var37 != 0) {
                     break label35;
                  }

                  AutoCrystal var38 = var23;
                  AutoCrystal var24 = var38;
                  BooleanSetting var14 = var24.k;
                  Boolean var15 = (Boolean)var14.aReturningObject();
                  boolean var39 = var15;
                  if (var39) {
                     int var41 = var8;
                     AutoCrystal var40 = this;
                     var27 = var40;
                     AutoCrystal var25 = var40;
                     if (var41 != 0) {
                        break label35;
                     }

                     AutoCrystal var42 = var25;
                     AutoCrystal var26 = var42;
                     Object[] var19 = new Object[]{var6};
                     AutoCrystal var18 = var26;
                     Entity var43 = var18.aReturningEntity(var19);
                     if (var43 != null) {
                        this.p = dev.prestige.recovery.SourceSupport.asBoolean(1);
                        this.q = 0;
                        return;
                     }
                  }
               }

               var27 = this;
            }

            var27.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
         }

         var28 = this;
      }

      var28.aReturningVoid(new Object[]{var4});
   }

   private Entity aReturningEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 139497674086703L ^ var2;
      int var4 = Event.bReturningInt();
      MinecraftClient var6 = b;
      int var35 = var4;
      HitResult var34 = var6.crosshairTarget;
      HitResult var23 = var34;
      HitResult var22 = var34;
      if (var35 == 0) {
         HitResult var36 = var22;
         if (var36 == null) {
            return null;
         }

         MinecraftClient var8 = b;
         HitResult var37 = var8.crosshairTarget;
         var23 = var37;
      }

      int var39 = var4;
      HitResult var38 = var23;
      HitResult var25 = var38;
      HitResult var24 = var38;
      if (var39 == 0) {
         HitResult var10 = var24;
         Type var57 = var10.getType();
         Type var41 = Type.ENTITY;
         Type var40 = var57;
         if (var40 != var41) {
            return null;
         }

         MinecraftClient var13 = b;
         var25 = var13.crosshairTarget;
      }

      Entity var5;
      boolean var32;
      EntityHitResult var14 = (EntityHitResult)var25;
      var5 = var14.getEntity();
      boolean var58 = var5 instanceof EndCrystalEntity;
      int var43 = var4;
      boolean var42 = var58;
      var32 = var42;
      boolean var26 = var42;
      label45:
      if (var43 == 0) {
         boolean var44 = var26;
         if (!var44) {
            boolean var59 = var5 instanceof SlimeEntity;
            int var46 = var4;
            boolean var45 = var59;
            var32 = var45;
            boolean var27 = var45;
            if (var46 != 0) {
               break label45;
            }

            boolean var47 = var27;
            boolean var28 = var47;
            boolean var48 = var28;
            if (!var48) {
               boolean var60 = var5 instanceof MagmaCubeEntity;
               int var50 = var4;
               boolean var49 = var60;
               var32 = var49;
               boolean var29 = var49;
               if (var50 != 0) {
                  break label45;
               }

               boolean var51 = var29;
               boolean var30 = var51;
               boolean var52 = var30;
               if (!var52) {
                  return null;
               }
            }
         }

         int var54 = var4;
         Entity var53 = var5;
         Entity var33 = var53;
         Entity var31 = var53;
         if (var54 != 0) {
            return var33;
         }

         Entity var21 = var31;
         boolean var55 = var21.isAlive();
         var32 = var55;
      }

      boolean var56 = var32;
      return !var56 ? null : var5;
   }

   private void jReturningVoid(Object[] var1) {
      PlayerUpdateEvent var4 = (PlayerUpdateEvent)var1[0];
      long var2 = (Long)var1[1];
      var2 = 139497674086703L ^ var2;
      long var5 = var2 ^ 140476112828210L;
      long var7 = var2 ^ 1391370644000L;
      long var9 = var2 ^ 117594440054914L;
      int var11 = Event.bReturningInt();
      Object[] var14 = new Object[0];
      PlayerUpdateEvent var13 = var4;
      EventPhase var10000 = var13.aReturningEventPhase(var14);
      EventPhase var54 = EventPhase.POST;
      EventPhase var53 = var10000;
      if (var53 != var54) {
         Object[] var17 = new Object[]{var7};
         AutoCrystal var16 = this;
         Entity var12 = var16.aReturningEntity(var17);
         int var55 = var11;
         if (var55 == 0) {
            AutoCrystal var45;
            int var46;
            label54: {
               Entity var56 = var12;
               if (var56 != null) {
                  int var10001 = this.q + 1;
                  int var59 = var11;
                  int var58 = var10001;
                  AutoCrystal var57 = this;
                  var45 = var57;
                  var46 = var58;
                  AutoCrystal var41 = var57;
                  int var42 = var58;
                  if (var59 != 0) {
                     break label54;
                  }

                  int var61 = var42;
                  AutoCrystal var60 = var41;
                  AutoCrystal var43 = var60;
                  int var44 = var61;
                  int var80 = var43.q = var44;
                  short var84 = 26481;
                  long var10002 = 8728093750290344506L ^ var2;
                  byte var63 = 20;
                  int var62 = var80;
                  if (var62 <= var63) {
                     int var67 = var11;
                     MinecraftClient var66 = b;
                     MinecraftClient var48 = var66;
                     MinecraftClient var47 = var66;
                     if (var67 == 0) {
                        MinecraftClient var22 = var47;
                        Screen var68 = var22.currentScreen;
                        if (var68 != null) {
                           return;
                        }

                        MinecraftClient var69 = b;
                        var48 = var69;
                     }

                     MinecraftClient var25 = var48;
                     boolean var81 = var25.isWindowFocused();
                     int var71 = var11;
                     boolean var70 = var81;
                     boolean var50 = var70;
                     boolean var49 = var70;
                     if (var71 == 0) {
                        boolean var72 = var49;
                        if (!var72) {
                           return;
                        }

                        MinecraftClient var27 = b;
                        ClientPlayerEntity var28 = var27.player;
                        boolean var73 = var28.isUsingItem();
                        var50 = var73;
                     }

                     int var75 = var11;
                     boolean var74 = var50;
                     boolean var52 = var74;
                     boolean var51 = var74;
                     if (var75 == 0) {
                        boolean var76 = var51;
                        if (var76) {
                           return;
                        }

                        RotationManager var82 = Prestige.o;
                        Object[] var32 = new Object[0];
                        RotationManager var31 = var82;
                        boolean var77 = var31.fReturningBoolean(var32);
                        var52 = var77;
                     }

                     boolean var78 = var52;
                     if (!var78) {
                        Object[] var35 = new Object[0];
                        PlayerUpdateEvent var34 = var4;
                        var34.aReturningVoid(var35);
                        Object[] var36 = new Object[]{var12, var9};
                        ItemUseUtil.aReturningVoid(var36);
                        this.m = null;
                        AutoCrystalRenderAnimation var83 = this.o;
                        Entity var37 = var12;
                        BlockPos var38 = var37.getBlockPos();
                        Object[] var40 = new Object[]{var38.down()};
                        AutoCrystalRenderAnimation var39 = var83;
                        var39.aReturningVoid(var40);
                        return;
                     }

                     return;
                  }
               }

               byte var65 = 0;
               AutoCrystal var64 = this;
               var45 = var64;
               var46 = var65;
            }

            var45.p = dev.prestige.recovery.SourceSupport.asBoolean(var46);
            super.aReturningVoid(new Object[]{var5});
         }
      }
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 82199235523437L ^ 64556142482107L;
      int var6 = Event.cReturningInt();
      Object[] var8 = new Object[]{123644152586710L};
      AutoCrystal var7 = this;
      int var10000 = var7.bReturningInt(var8);
      int var21 = var6;
      int var20 = var10000;
      int var19 = var20;
      int var18 = var20;
      if (var21 != 0) {
         short var23 = 9998;
         int var22 = var18;
         if (var22 != var23) {
            return;
         }

         MinecraftClient var10 = b;
         ClientPlayerEntity var11 = var10.player;
         ItemStack var12 = var11.getMainHandStack();
         Item var26 = var12.getItem();
         Item var14 = Items.END_CRYSTAL;
         Item var13 = var26;
         byte var24 = ((byte)((var13.equals(var14)) ? 1 : 0));
         var19 = var24;
      }

      int var25 = var19;
      if (var25 != 0) {
         Object[] var17 = new Object[0];
         ItemUseEvent var16 = var1;
         var16.aReturningVoid(var17);
      }
   }

   @EventListener
   public void k(PlayerUpdateEvent var1) {
      long var10001 = 20412804718650L ^ 23292146590153L;
      var10001 = 20412804718650L ^ 118828709164590L;
      var10001 = 20412804718650L ^ 74855089206786L;
      var10001 = 20412804718650L ^ 46287875777799L;
      var10001 = 20412804718650L ^ 74910175931324L;
      var10001 = 20412804718650L ^ 5077525593890L;
      var10001 = 20412804718650L ^ 91692576580940L;
      var10001 = 20412804718650L ^ 111601017272897L;
      var10001 = 20412804718650L ^ 124907356786366L;
      var10001 = 20412804718650L ^ 85129418902996L;
      var10001 = 20412804718650L ^ 27130039443487L;
      var10001 = 20412804718650L ^ 57612378572858L;
      var10001 = 20412804718650L ^ 59248884052939L;
      var10001 = 20412804718650L ^ 111245897069143L;
      var10001 = 20412804718650L ^ 37174685909303L;
      var10001 = 20412804718650L ^ 106998753801855L;
      var10001 = 20412804718650L ^ 92895462281066L;
      var10001 = 20412804718650L ^ 93270235566379L;
      var10001 = 20412804718650L ^ 129176865216466L;
      int var42 = Event.cReturningInt();
      int var337 = var42;
      AutoCrystal var336 = this;
      AutoCrystal var274 = var336;
      AutoCrystal var273 = var336;
      if (var337 != 0) {
         boolean var338 = var273.p;
         if (!var338) {
            int var341 = var42;
            MinecraftClient var340 = b;
            MinecraftClient var276 = var340;
            MinecraftClient var275 = var340;
            if (var341 != 0) {
               MinecraftClient var64 = var275;
               Screen var342 = var64.currentScreen;
               if (var342 != null) {
                  return;
               }

               MinecraftClient var343 = b;
               var276 = var343;
            }

            MinecraftClient var67 = var276;
            int var10000 = (((var67.isWindowFocused()) ? 1 : 0));
            int var345 = var42;
            boolean var344 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
            boolean var278 = var344;
            boolean var277 = var344;
            if (var345 != 0) {
               boolean var346 = var277;
               if (!var346) {
                  return;
               }

               MinecraftClient var69 = b;
               ClientPlayerEntity var70 = var69.player;
               boolean var347 = var70.isUsingItem();
               var278 = var347;
            }

            int var349 = var42;
            boolean var348 = var278;
            boolean var280 = var348;
            boolean var279 = var348;
            if (var349 != 0) {
               boolean var350 = var279;
               if (var350) {
                  return;
               }

               MinecraftClient var73 = b;
               ClientPlayerEntity var74 = var73.player;
               boolean var351 = var74.isOnGround();
               var280 = var351;
            }

            boolean var284;
            int var353 = var42;
            boolean var352 = var280;
            var284 = var352;
            boolean var281 = var352;
            label331:
            if (var353 != 0) {
               boolean var354 = var281;
               if (!var354) {
                  BooleanSetting var77 = this.d;
                  Boolean var78 = (Boolean)var77.aReturningObject();
                  var10000 = ((((java.lang.Boolean)(var78)).booleanValue() ? 1 : 0));
                  int var356 = var42;
                  boolean var355 = ((((int)(var10000) & 1) != 0));
                  var284 = var355;
                  boolean var282 = var355;
                  if (var356 == 0) {
                     break label331;
                  }

                  boolean var357 = var282;
                  boolean var283 = var357;
                  boolean var358 = var283;
                  if (!var358) {
                     return;
                  }
               }

               ElapsedTimer var474 = this.l;
               MinMaxSetting var81 = this.f;
               Float var82 = (Float)var81.aReturningObject();
               float var516 = var82;
               Object[] var10004 = new Object[]{null, 139098136696340L};
               var10004[0] = var516;
               Object[] var84 = var10004;
               ElapsedTimer var83 = var474;
               boolean var359 = var83.aReturningBoolean(var84);
               var284 = var359;
            }

            int var361 = var42;
            boolean var360 = var284;
            boolean var286 = var360;
            boolean var285 = var360;
            if (var361 != 0) {
               boolean var362 = var285;
               if (!var362) {
                  return;
               }

               var286 = AutoHitCrystal.a;
            }

            int var364 = var42;
            boolean var363 = var286;
            boolean var288 = var363;
            boolean var287 = var363;
            if (var364 != 0) {
               boolean var365 = var287;
               if (var365) {
                  return;
               }

               var288 = AutoObbyCrystal.R;
            }

            boolean var366 = var288;
            if (!var366) {
               Object[] var89 = new Object[0];
               PlayerUpdateEvent var88 = var1;
               EventPhase var475 = var88.aReturningEventPhase(var89);
               EventPhase var368 = EventPhase.POST;
               EventPhase var367 = var475;
               if (var367 != var368) {
                  RotationManager var476 = Prestige.o;
                  Object[] var93 = new Object[0];
                  RotationManager var92 = var476;
                  boolean var369 = var92.fReturningBoolean(var93);
                  if (var369) {
                     return;
                  }

                  MinecraftClient var95 = b;
                  HitResult var370 = var95.crosshairTarget;
                  if (var370 == null) {
                     return;
                  }

                  AutoCrystal var294;
                  label355: {
                     Object[] var98 = new Object[0];
                     PlayerUpdateEvent var97 = var1;
                     var97.aReturningVoid(var98);
                     Object[] var99 = new Object[]{Items.END_CRYSTAL, 8519502184947L};
                     var10000 = (((InventoryUtil.lReturningBoolean(var99)) ? 1 : 0));
                     int var372 = var42;
                     boolean var371 = ((((int)(var10000) & 1) != 0));
                     boolean var293 = var371;
                     boolean var289 = var371;
                     if (var372 != 0) {
                        boolean var373 = var289;
                        if (!var373) {
                           BooleanSetting var101 = this.g;
                           Boolean var102 = (Boolean)var101.aReturningObject();
                           boolean var374 = var102;
                           if (var374) {
                              Object[] var104 = new Object[]{Items.END_CRYSTAL, 95321893129094L};
                              Integer var470 = InventoryUtil.aReturningBoxedInteger(var104);
                              int var376 = var42;
                              Integer var375 = var470;
                              Integer var291 = var375;
                              Integer var290 = var375;
                              if (var376 != 0) {
                                 Integer var377 = var290;
                                 if (var377 == null) {
                                    return;
                                 }

                                 var291 = var470;
                              }

                              Integer var106 = var291;
                              var10000 = var106;
                              Object[] var10003 = new Object[]{null, 72518082610550L};
                              var10003[0] = var10000;
                              Object[] var107 = var10003;
                              InventoryUtil.aReturningVoid(var107);
                              ElapsedTimer var497 = this.l;
                              Object[] var109 = new Object[]{42835128969216L};
                              ElapsedTimer var108 = var497;
                              var108.aReturningVoid(var109);
                              return;
                           }

                           return;
                        }

                        int var379 = var42;
                        AutoCrystal var378 = this;
                        var294 = var378;
                        AutoCrystal var292 = var378;
                        if (var379 == 0) {
                           break label355;
                        }

                        ElapsedTimer var478 = var292.l;
                        Object[] var111 = new Object[]{this.f, 130913203968635L};
                        ElapsedTimer var110 = var478;
                        boolean var380 = var110.bReturningBoolean(var111);
                        var293 = var380;
                     }

                     boolean var381 = var293;
                     if (!var381) {
                        return;
                     }

                     var294 = this;
                  }

                  PlayerEntity var43;
                  Entity var47;
                  Vec3d var48;
                  label385: {
                     Object[] var114 = new Object[]{77980785094480L};
                     AutoCrystal var113 = var294;
                     var113.kReturningVoid(var114);
                     Object[] var115 = new Object[]{77260333461777L};
                     var43 = EntityUtil.aReturningPlayerEntity(var115);
                     Object[] var117 = new Object[]{var43, 24251765792536L};
                     AutoCrystal var116 = this;
                     boolean var44 = var116.aReturningBoolean(var117);
                     boolean var382 = var44;
                     label297:
                     if (var382) {
                        AutoCrystal var311;
                        label360: {
                           MinecraftClient var118 = b;
                           HitResult var119 = var118.crosshairTarget;
                           Type var479 = var119.getType();
                           int var384 = var42;
                           Type var383 = var479;
                           Object var310 = var383;
                           Type var295 = var383;
                           if (var384 != 0) {
                              Type var385 = var295;
                              Type var296 = var385;
                              Type var387 = Type.ENTITY;
                              Type var386 = var296;
                              if (var386 == var387) {
                                 label363: {
                                    EntityHitResult var45;
                                    boolean var302;
                                    MinecraftClient var122 = b;
                                    var45 = (EntityHitResult)var122.crosshairTarget;
                                    EntityHitResult var123 = var45;
                                    boolean var480 = var123.getEntity() instanceof EndCrystalEntity;
                                    int var389 = var42;
                                    boolean var388 = var480;
                                    var302 = var388;
                                    boolean var297 = var388;
                                    label289:
                                    if (var389 != 0) {
                                       boolean var390 = var297;
                                       if (!var390) {
                                          EntityHitResult var125 = var45;
                                          var480 = var125.getEntity() instanceof SlimeEntity;
                                          int var392 = var42;
                                          boolean var391 = var480;
                                          var302 = var391;
                                          boolean var298 = var391;
                                          if (var392 == 0) {
                                             break label289;
                                          }

                                          boolean var393 = var298;
                                          boolean var299 = var393;
                                          boolean var394 = var299;
                                          if (!var394) {
                                             EntityHitResult var128 = var45;
                                             var480 = var128.getEntity() instanceof MagmaCubeEntity;
                                             int var396 = var42;
                                             boolean var395 = var480;
                                             var302 = var395;
                                             boolean var300 = var395;
                                             if (var396 == 0) {
                                                break label289;
                                             }

                                             boolean var397 = var300;
                                             boolean var301 = var397;
                                             boolean var398 = var301;
                                             if (!var398) {
                                                break label363;
                                             }
                                          }
                                       }

                                       BooleanSetting var131 = this.e;
                                       Boolean var132 = (Boolean)var131.aReturningObject();
                                       boolean var399 = var132;
                                       var302 = var399;
                                    }

                                    Entity var307;
                                    label277: {
                                       label276: {
                                          int var401 = var42;
                                          boolean var400 = var302;
                                          boolean var306 = var400;
                                          boolean var303 = var400;
                                          if (var401 != 0) {
                                             boolean var402 = var303;
                                             if (!var402) {
                                                break label276;
                                             }

                                             EntityHitResult var135 = var45;
                                             Entity var483 = var135.getEntity();
                                             int var404 = var42;
                                             Entity var403 = var483;
                                             var307 = var403;
                                             Entity var304 = var403;
                                             if (var404 == 0) {
                                                break label277;
                                             }

                                             Entity var405 = var304;
                                             Entity var305 = var405;
                                             Entity var137 = var305;
                                             Object[] var138 = new Object[]{var137.getBlockPos(), 108898817732228L};
                                             boolean var406 = DroppedItemUtil.aReturningBoolean(var138);
                                             var306 = var406;
                                          }

                                          boolean var407 = var306;
                                          if (var407) {
                                             return;
                                          }
                                       }

                                       EntityHitResult var140 = var45;
                                       var307 = var140.getEntity();
                                    }

                                    Object[] var141 = new Object[]{var307, 114267283224552L};
                                    ItemUseUtil.aReturningVoid(var141);
                                    int var408 = var42;
                                    if (var408 != 0) {
                                       PlayerEntity var409 = var43;
                                       if (var409 != null) {
                                          ExplosionDamageUtil var517 = Prestige.f;
                                          EntityHitResult var143 = var45;
                                          Object[] var144 = new Object[]{var143.getEntity(), 131657085751917L};
                                          Object[] var146 = new Object[]{var43, RaycastUtil.aReturningVec3d(var144), 95125857965624L};
                                          ExplosionDamageUtil var145 = var517;
                                          this.n = (float)var145.aReturningDouble(var146);
                                       }

                                       this.m = null;
                                    }

                                    AutoCrystalRenderAnimation var484 = this.o;
                                    EntityHitResult var148 = var45;
                                    Entity var149 = var148.getEntity();
                                    BlockPos var150 = var149.getBlockPos();
                                    Object[] var152 = new Object[]{var150.down()};
                                    AutoCrystalRenderAnimation var151 = var484;
                                    var151.aReturningVoid(var152);
                                 }

                                 int var410 = var42;
                                 if (var410 != 0) {
                                    break label297;
                                 }
                              }

                              int var412 = var42;
                              AutoCrystal var411 = this;
                              var311 = var411;
                              AutoCrystal var308 = var411;
                              if (var412 == 0) {
                                 break label360;
                              }

                              AutoCrystal var413 = var308;
                              AutoCrystal var309 = var413;
                              BooleanSetting var154 = var309.h;
                              Object var414 = var154.aReturningObject();
                              var310 = var414;
                           }

                           Boolean var156 = (Boolean)var310;
                           boolean var415 = var156;
                           if (!var415) {
                              break label297;
                           }

                           AutoCrystal var416 = this;
                           var311 = var416;
                        }

                        BlockPos var471 = var311.m;
                        int var418 = var42;
                        BlockPos var417 = var471;
                        BlockPos var316 = var417;
                        BlockPos var312 = var417;
                        if (var418 != 0) {
                           BlockPos var419 = var312;
                           label256:
                           if (var419 == null) {
                              MinecraftClient var159 = b;
                              int var421 = var42;
                              HitResult var420 = var159.crosshairTarget;
                              HitResult var315 = var420;
                              HitResult var313 = var420;
                              if (var421 != 0) {
                                 HitResult var422 = var313;
                                 HitResult var314 = var422;
                                 HitResult var161 = var314;
                                 Type var485 = var161.getType();
                                 Type var424 = Type.BLOCK;
                                 Type var423 = var485;
                                 if (var423 != var424) {
                                    break label256;
                                 }

                                 MinecraftClient var163 = b;
                                 HitResult var425 = var163.crosshairTarget;
                                 var315 = var425;
                              }

                              BlockHitResult var165 = (BlockHitResult)var315;
                              var471 = var165.getBlockPos();
                           }

                           var316 = var471;
                        }

                        BlockPos var426 = var316;
                        if (var426 == null) {
                           return;
                        }

                        MinecraftClient var166 = b;
                        ClientWorld var167 = var166.world;
                        Iterable var168 = var167.getEntities();
                        Iterator var46 = var168.iterator();

                        while (true) {
                           Iterator var169 = var46;
                           boolean var427 = var169.hasNext();
                           if (!var427) {
                              break;
                           }

                           Iterator var170 = var46;
                           var47 = (Entity)var170.next();
                           int var428 = var42;
                           if (var428 == 0) {
                              return;
                           }

                           int var430 = var42;
                           Entity var429 = var47;
                           Entity var319 = var429;
                           Entity var317 = var429;
                           if (var430 != 0) {
                              Entity var431 = var317;
                              Entity var318 = var431;
                              boolean var432 = var318 instanceof EndCrystalEntity;
                              if (!var432) {
                                 int var433 = var42;
                                 if (var433 != 0) {
                                    continue;
                                 }
                              }

                              var319 = var47;
                           }

                           int var321;
                           label243: {
                              Object[] var174 = new Object[]{var319, 131657085751917L};
                              var48 = RaycastUtil.aReturningVec3d(var174);
                              BlockPos var175 = var471;
                              BlockPos var176 = var175.up();
                              Vec3d var178 = var176.toCenterPos();
                              Vec3d var177 = var48;
                              double var520;
                              int var434 = (var520 = var177.distanceTo(var178) - 1.0) == 0.0 ? 0 : (var520 < 0.0 ? -1 : 1);
                              if (var434 < 0) {
                                 Entity var179 = var47;
                                 Box var49 = var179.getBoundingBox();
                                 MinecraftClient var180 = b;
                                 ClientPlayerEntity var181 = var180.player;
                                 Vec3d var50 = var181.getEyePos();
                                 Box var182 = var49;
                                 Vec3d var183 = var50;
                                 double var486 = var182.minX - var183.x;
                                 Vec3d var184 = var50;
                                 Box var185 = var49;
                                 double var188 = var184.x - var185.maxX;
                                 double var192 = Math.max(var186, var188);
                                 double var190 = var486;
                                 double var51 = Math.max(var190, var192);
                                 Box var194 = var49;
                                 Vec3d var195 = var50;
                                 double var487 = var194.minY - var195.y;
                                 Vec3d var196 = var50;
                                 Box var197 = var49;
                                 double var200 = var196.y - var197.maxY;
                                 double var204 = Math.max(var198, var200);
                                 double var202 = var487;
                                 double var53 = Math.max(var202, var204);
                                 Box var206 = var49;
                                 Vec3d var207 = var50;
                                 double var488 = var206.minZ - var207.z;
                                 Vec3d var208 = var50;
                                 Box var209 = var49;
                                 double var212 = var208.z - var209.maxZ;
                                 double var216 = Math.max(var210, var212);
                                 double var214 = var488;
                                 double var55 = Math.max(var214, var216);
                                 double var218 = var51 * var51 + var53 * var53 + var55 * var55;
                                 double var57 = Math.sqrt(var218);
                                 double var521;
                                 var10000 = (var521 = var57 - 2.7F) == 0.0 ? 0 : (var521 < 0.0 ? -1 : 1);
                                 int var436 = var42;
                                 int var435 = var10000;
                                 var321 = var435;
                                 int var320 = var435;
                                 if (var436 == 0) {
                                    break label243;
                                 }

                                 int var437 = var320;
                                 if (var437 <= 0) {
                                    BooleanSetting var221 = this.e;
                                    Boolean var222 = (Boolean)var221.aReturningObject();
                                    byte var438 = ((byte)(((java.lang.Boolean)(var222)).booleanValue() ? 1 : 0));
                                    var321 = var438;
                                    break label243;
                                 }
                              }

                              int var447 = var42;
                              if (var447 == 0) {
                                 break;
                              }
                              continue;
                           }

                           int var440 = var42;
                           int var439 = var321;
                           int var323 = var439;
                           int var322 = var439;
                           if (var440 != 0) {
                              int var441 = var322;
                              if (var441 == 0) {
                                 break label385;
                              }

                              Entity var225 = var47;
                              Object[] var226 = new Object[]{var225.getBlockPos(), 108898817732228L};
                              byte var442 = ((byte)((DroppedItemUtil.aReturningBoolean(var226)) ? 1 : 0));
                              var323 = var442;
                           }

                           int var443 = var323;
                           if (var443 == 0) {
                              break label385;
                           }

                           int var444 = var42;
                           if (var444 == 0) {
                              break label385;
                           }
                        }
                     }

                     MinecraftClient var246 = b;
                     int var449 = var42;
                     HitResult var448 = var246.crosshairTarget;
                     HitResult var325 = var448;
                     HitResult var324 = var448;
                     if (var449 != 0) {
                        HitResult var247 = var324;
                        Type var492 = var247.getType();
                        Type var451 = Type.BLOCK;
                        Type var450 = var492;
                        if (var450 != var451) {
                           return;
                        }

                        MinecraftClient var249 = b;
                        HitResult var452 = var249.crosshairTarget;
                        var325 = var452;
                     }

                     boolean var329;
                     BlockHitResult var472;
                     var472 = (BlockHitResult)var325;
                     BlockHitResult var251 = var472;
                     Object[] var252 = new Object[]{var251.getBlockPos(), Blocks.BEDROCK, 105536024440302L};
                     boolean var493 = BlockUtil.kReturningBoolean(var252);
                     int var454 = var42;
                     boolean var453 = var493;
                     var329 = var453;
                     boolean var326 = var453;
                     label211:
                     if (var454 != 0) {
                        boolean var455 = var326;
                        if (!var455) {
                           BlockHitResult var254 = var472;
                           Object[] var255 = new Object[]{var254.getBlockPos(), Blocks.OBSIDIAN, 105536024440302L};
                           var493 = BlockUtil.kReturningBoolean(var255);
                           int var457 = var42;
                           boolean var456 = var493;
                           var329 = var456;
                           boolean var327 = var456;
                           if (var457 == 0) {
                              break label211;
                           }

                           boolean var458 = var327;
                           boolean var328 = var458;
                           boolean var459 = var328;
                           if (!var459) {
                              return;
                           }
                        }

                        BlockHitResult var258 = var472;
                        BlockPos var259 = var258.getBlockPos();
                        Object[] var260 = new Object[]{var259.up(), 56486840213773L};
                        var329 = BlockUtil.gReturningBoolean(var260);
                     }

                     int var461 = var42;
                     boolean var460 = var329;
                     boolean var331 = var460;
                     boolean var330 = var460;
                     if (var461 != 0) {
                        boolean var462 = var330;
                        if (var462) {
                           return;
                        }

                        BlockHitResult var262 = var472;
                        Object[] var263 = new Object[]{var262.getBlockPos(), 62163303384381L};
                        boolean var463 = BlockUtil.fReturningBoolean(var263);
                        var331 = var463;
                     }

                     int var465 = var42;
                     boolean var464 = var331;
                     boolean var333 = var464;
                     boolean var332 = var464;
                     if (var465 != 0) {
                        boolean var466 = var332;
                        if (!var466) {
                           return;
                        }

                        Object[] var266 = new Object[]{Items.END_CRYSTAL, 8519502184947L};
                        var333 = InventoryUtil.lReturningBoolean(var266);
                     }

                     int var468 = var42;
                     boolean var467 = var333;
                     boolean var334 = var467;
                     if (var468 != 0) {
                        boolean var469 = var334;
                        if (!var469) {
                           return;
                        }

                        Object[] var268 = new Object[]{var472, 11253043183653L};
                        boolean var335 = ItemUseUtil.aReturningBoolean(var268);
                     }

                     BlockHitResult var269 = var472;
                     this.m = var269.getBlockPos();
                     AutoCrystalRenderAnimation var495 = this.o;
                     BlockHitResult var270 = var472;
                     Object[] var272 = new Object[]{var270.getBlockPos()};
                     AutoCrystalRenderAnimation var271 = var495;
                     var271.aReturningVoid(var272);
                     return;
                  }

                  Vec3d var229 = var48;
                  float var490 = (float)var229.x;
                  Vec3d var230 = var48;
                  float var518 = (float)(var230.y + 0.45F);
                  Vec3d var231 = var48;
                  float var10002 = (float)var231.z;
                  Object[] var10005 = new Object[]{null, null, null, 43371877274609L};
                  var10005[2] = var10002;
                  var10005[1] = var518;
                  var10005[0] = var490;
                  Object[] var232 = var10005;
                  Rotation var59 = RotationUtil.bReturningdx_C0210(var232);
                  Object[] var234 = new Object[0];
                  Rotation var233 = var59;
                  Object[] var236 = new Object[]{var233.bReturningFloat(var234)};
                  PlayerUpdateEvent var235 = var1;
                  var235.cReturningVoid(var236);
                  Object[] var237 = new Object[]{var47, 114267283224552L};
                  ItemUseUtil.aReturningVoid(var237);
                  int var445 = var42;
                  if (var445 != 0) {
                     PlayerEntity var446 = var43;
                     if (var446 != null) {
                        ExplosionDamageUtil var519 = Prestige.f;
                        Object[] var240 = new Object[]{var43, var48, 95125857965624L};
                        ExplosionDamageUtil var239 = var519;
                        this.n = (float)var239.aReturningDouble(var240);
                     }

                     this.m = null;
                     AutoCrystalRenderAnimation var491 = this.o;
                     Entity var242 = var47;
                     BlockPos var243 = var242.getBlockPos();
                     Object[] var245 = new Object[]{var243.down()};
                     AutoCrystalRenderAnimation var244 = var491;
                     var244.aReturningVoid(var245);
                  }

                  return;
               }
            }

            return;
         }

         AutoCrystal var339 = this;
         var274 = var339;
      }

      Object[] var63 = new Object[]{var1, 127269264643653L};
      AutoCrystal var62 = var274;
      var62.jReturningVoid(var63);
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 139497674086703L ^ var2;
      long var4 = var2 ^ 83530889218096L;
      long var6 = var2 ^ 33837112647295L;
      MinMaxSetting var10000 = this.f;
      Object[] var9 = new Object[]{var4};
      MinMaxSetting var8 = var10000;
      var8.bReturningVoid(var9);
      ElapsedTimer var13 = this.l;
      Object[] var11 = new Object[]{var6};
      ElapsedTimer var10 = var13;
      var10.aReturningVoid(var11);
   }

   private float bReturningFloat(Object[] param1) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[17];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=5; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=6; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=8; { recoveryStack[0]=139497674086703L; }
                  recoveryAt=9; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=10; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=11; { recoveryLocals[2]=recoveryStack[0];  }
                  recoveryAt=12; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=13; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=14; { recoveryStack[2]=83768207413224L; }
                  recoveryAt=15; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=16; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=17; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=18; { recoveryStack[2]=119942147083197L; }
                  recoveryAt=19; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=20; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=21; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=22; { recoveryStack[2]=102183353526465L; }
                  recoveryAt=23; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=24; { recoveryLocals[8]=recoveryStack[1];  }
                  recoveryAt=26; { recoveryStack[0]=1869427560266648562L; }
                  recoveryAt=27; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=28; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding2(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=31; { recoveryStack[1]=recoveryLocals[8];  }
                  recoveryAt=32; { recoveryStack[2]=1; }
                  recoveryAt=33; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=34; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=35; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=37; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=38; { recoveryStack[4]=0; }
                  recoveryAt=39; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=40; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=41; { recoveryStack[2]=1871880900633622523L; }
                  recoveryAt=42; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=43; { recoveryStack[1]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding3(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=44; { recoveryLocals[11]=recoveryStack[1];  }
                  recoveryAt=45; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=48; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=49; { if(recoveryStack[0]==null){recoveryPc=85; continue recoveryFlow;} recoveryPc=51; continue recoveryFlow; }
               }
               case 51 -> {
                  recoveryAt=51; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.b; }
                  recoveryAt=52; { recoveryStack[1]=1870817394343784619L; }
                  recoveryAt=53; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=54; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding4(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=55; { recoveryStack[1]=recoveryLocals[11];  }
                  recoveryAt=56; { recoveryStack[2]=1870608131016136200L; }
                  recoveryAt=57; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=58; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding5(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=59; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=60; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=99; continue recoveryFlow;} recoveryPc=62; continue recoveryFlow; }
               }
               case 62 -> {
                  recoveryAt=62; { recoveryPc=71; continue recoveryFlow; }
               }
               case 65 -> {
                  recoveryAt=65; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=66; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=67; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding6(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=68; { throw (Throwable)recoveryStack[0]; }
               }
               case 71 -> {
                  recoveryAt=71; { recoveryStack[1]=Float.intBitsToFloat(1101004800); }
                  recoveryAt=72; { float recoveryA=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]), recoveryB=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]);recoveryStack[0]=Float.isNaN(recoveryA)||Float.isNaN(recoveryB)?-1:recoveryA>recoveryB?1:recoveryA==recoveryB?0:-1; }
                  recoveryAt=73; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=0){recoveryPc=96; continue recoveryFlow;} recoveryPc=75; continue recoveryFlow; }
               }
               case 75 -> {
                  recoveryAt=75; { recoveryPc=85; continue recoveryFlow; }
               }
               case 78 -> {
                  recoveryAt=78; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=79; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=80; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding7(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=81; { throw (Throwable)recoveryStack[0]; }
               }
               case 85 -> {
                  recoveryAt=85; { recoveryStack[0]=Float.intBitsToFloat(0); }
                  recoveryAt=86; { return dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]); }
               }
               case 89 -> {
                  recoveryAt=89; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=90; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=91; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding8(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=92; { throw (Throwable)recoveryStack[0]; }
               }
               case 96 -> {
                  recoveryAt=96; { recoveryStack[0]=Float.intBitsToFloat(0); }
                  recoveryPc=99; continue recoveryFlow;
               }
               case 99 -> {
                  recoveryAt=99; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=102; { recoveryStack[0]=0; }
                  recoveryAt=103; { recoveryLocals[13]=recoveryStack[0];  }
                  recoveryAt=106; { recoveryStack[0]=1870903982375501197L; }
                  recoveryAt=107; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=108; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding9(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=109; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=112; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.b; }
                  recoveryAt=113; { recoveryStack[1]=1859442280403553624L; }
                  recoveryAt=114; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=115; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding10(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=116; { recoveryStack[0]=recoveryStack[0] instanceof net.minecraft.util.hit.BlockHitResult ? 1 : 0; }
                  recoveryAt=117; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=118; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=178; continue recoveryFlow;} recoveryPc=119; continue recoveryFlow; }
               }
               case 119 -> {
                  recoveryAt=119; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=151; continue recoveryFlow;} recoveryPc=121; continue recoveryFlow; }
               }
               case 121 -> {
                  recoveryAt=121; { recoveryPc=131; continue recoveryFlow; }
               }
               case 124 -> {
                  recoveryAt=124; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=125; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=126; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding11(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=127; { throw (Throwable)recoveryStack[0]; }
               }
               case 131 -> {
                  recoveryAt=131; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.b; }
                  recoveryAt=132; { recoveryStack[1]=1859442280403553624L; }
                  recoveryAt=133; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=134; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding12(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=135; { recoveryStack[1]=1858225774167427732L; }
                  recoveryAt=136; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=137; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding13(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=138; { recoveryStack[1]=Double.longBitsToDouble(0L); }
                  recoveryAt=139; { recoveryStack[2]=Double.longBitsToDouble(4607182418800017408L); }
                  recoveryAt=140; { recoveryStack[3]=Double.longBitsToDouble(0L); }
                  recoveryAt=141; { recoveryStack[4]=1872655837662300976L; }
                  recoveryAt=142; { recoveryStack[5]=recoveryLocals[2];  }
                  recoveryAt=143; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding14(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asDouble(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asDouble(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asDouble(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=144; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=146; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=147; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=221; continue recoveryFlow;} recoveryPc=151; continue recoveryFlow; }
               }
               case 151 -> {
                  recoveryAt=151; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.b; }
                  recoveryAt=152; { recoveryStack[1]=1859442280403553624L; }
                  recoveryAt=153; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=154; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding15(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=155; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=156; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=195; continue recoveryFlow;} recoveryPc=158; continue recoveryFlow; }
               }
               case 158 -> {
                  recoveryAt=158; { recoveryPc=167; continue recoveryFlow; }
               }
               case 161 -> {
                  recoveryAt=161; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=162; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=163; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding16(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=164; { throw (Throwable)recoveryStack[0]; }
               }
               case 167 -> {
                  recoveryAt=167; { recoveryStack[0]=recoveryStack[0] instanceof net.minecraft.util.hit.EntityHitResult ? 1 : 0; }
                  recoveryAt=169; { recoveryPc=178; continue recoveryFlow; }
               }
               case 172 -> {
                  recoveryAt=172; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=173; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=174; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding17(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=175; { throw (Throwable)recoveryStack[0]; }
               }
               case 178 -> {
                  recoveryAt=178; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=221; continue recoveryFlow;} recoveryPc=181; continue recoveryFlow; }
               }
               case 181 -> {
                  recoveryAt=181; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.b; }
                  recoveryAt=182; { recoveryStack[1]=1859442280403553624L; }
                  recoveryAt=183; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=184; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding18(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=186; { recoveryPc=195; continue recoveryFlow; }
               }
               case 189 -> {
                  recoveryAt=189; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=190; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=191; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding19(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=192; { throw (Throwable)recoveryStack[0]; }
               }
               case 195 -> {
                  recoveryAt=195; { recoveryStack[0]=((net.minecraft.util.hit.EntityHitResult)recoveryStack[0]); }
                  recoveryAt=196; { recoveryStack[1]=1859627645586948975L; }
                  recoveryAt=197; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=198; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding20(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=199; { recoveryStack[1]=recoveryLocals[6];  }
                  recoveryAt=200; { recoveryStack[2]=2; }
                  recoveryAt=201; { recoveryStack[2]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=202; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=203; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=205; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=206; { recoveryStack[4]=1; }
                  recoveryAt=207; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=208; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=209; { Object recoveryTemp=recoveryStack[1];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryStack[0];recoveryStack[0]=recoveryTemp; }
                  recoveryAt=210; { Object recoveryTemp=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=211; { recoveryStack[3]=0; }
                  recoveryAt=212; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=213; { ((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]=recoveryStack[3]; }
                  recoveryAt=214; { recoveryStack[1]=1871505148525235498L; }
                  recoveryAt=215; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=216; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding21(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=217; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryPc=221; continue recoveryFlow;
               }
               case 221 -> {
                  recoveryAt=221; { recoveryStack[0]=1869220473734640759L; }
                  recoveryAt=222; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=223; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding22(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=224; { recoveryStack[1]=recoveryLocals[11];  }
                  recoveryAt=225; { recoveryStack[2]=recoveryLocals[14];  }
                  recoveryAt=226; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=227; { recoveryStack[4]=3; }
                  recoveryAt=228; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=229; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=230; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=232; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=233; { recoveryStack[6]=2; }
                  recoveryAt=234; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=235; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=236; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=237; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=238; { recoveryStack[5]=1; }
                  recoveryAt=239; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=240; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=241; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=242; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=243; { recoveryStack[4]=0; }
                  recoveryAt=244; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=245; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=246; { recoveryStack[2]=1872207662566476840L; }
                  recoveryAt=247; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=248; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding23(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=249; { recoveryStack[0]=(float)dev.prestige.recovery.SourceSupport.asDouble(recoveryStack[0]); }
                  recoveryAt=250; { recoveryLocals[15]=recoveryStack[0];  }
                  recoveryAt=253; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=254; { recoveryStack[1]=1859847021484023041L; }
                  recoveryAt=255; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=256; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding24(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=257; { recoveryStack[1]=recoveryLocals[11];  }
                  recoveryAt=258; { recoveryStack[2]=1869558060307675335L; }
                  recoveryAt=259; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=260; { recoveryStack[1]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding25(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=261; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=262; { recoveryLocals[16]=recoveryStack[0];  }
                  recoveryAt=265; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=266; { recoveryStack[1]=Float.intBitsToFloat(0); }
                  recoveryAt=267; { recoveryStack[2]=Float.intBitsToFloat(1065353216); }
                  recoveryAt=268; { recoveryStack[3]=recoveryLocals[15];  }
                  recoveryAt=269; { recoveryStack[4]=recoveryLocals[16];  }
                  recoveryAt=270; { recoveryStack[5]=Float.intBitsToFloat(1065353216); }
                  recoveryAt=271; { recoveryStack[6]=1871702944822065148L; }
                  recoveryAt=272; { recoveryStack[7]=recoveryLocals[2];  }
                  recoveryAt=273; { recoveryStack[4]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding26(dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[5]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[6]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[7])); }
                  recoveryAt=274; { recoveryStack[3]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[3])/dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[4]); }
                  recoveryAt=275; { recoveryStack[4]=1857766031607894558L; }
                  recoveryAt=276; { recoveryStack[5]=recoveryLocals[2];  }
                  recoveryAt=277; { recoveryStack[2]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding27(dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=278; { recoveryStack[3]=1871702944822065148L; }
                  recoveryAt=279; { recoveryStack[4]=recoveryLocals[2];  }
                  recoveryAt=280; { recoveryStack[1]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding28(dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=281; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=282; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=285; { recoveryLocals[13]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[13])+(1); }
                  recoveryAt=288; { recoveryStack[0]=recoveryLocals[11];  }
                  recoveryAt=289; { recoveryStack[1]=1857549534082425296L; }
                  recoveryAt=290; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=291; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding29(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=292; { recoveryStack[1]=1869490867018022913L; }
                  recoveryAt=293; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=294; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding30(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=295; { recoveryStack[1]=1872006295921945694L; }
                  recoveryAt=296; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=297; { recoveryStack[1]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding31(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=298; { if(recoveryStack[0]!=recoveryStack[1]){recoveryPc=309; continue recoveryFlow;} recoveryPc=299; continue recoveryFlow; }
               }
               case 299 -> {
                  recoveryAt=299; { recoveryStack[0]=1; }
                  recoveryAt=300; { recoveryPc=312; continue recoveryFlow; }
               }
               case 303 -> {
                  recoveryAt=303; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=304; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=305; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding32(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=306; { throw (Throwable)recoveryStack[0]; }
               }
               case 309 -> {
                  recoveryAt=309; { recoveryStack[0]=0; }
                  recoveryPc=312; continue recoveryFlow;
               }
               case 312 -> {
                  recoveryAt=312; { recoveryLocals[14]=recoveryStack[0];  }
                  recoveryAt=315; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=316; { recoveryStack[1]=recoveryLocals[14];  }
                  recoveryAt=317; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=328; continue recoveryFlow;} recoveryPc=318; continue recoveryFlow; }
               }
               case 318 -> {
                  recoveryAt=318; { recoveryStack[1]=Float.intBitsToFloat(0); }
                  recoveryAt=319; { recoveryPc=331; continue recoveryFlow; }
               }
               case 322 -> {
                  recoveryAt=322; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=323; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=324; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding33(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=325; { throw (Throwable)recoveryStack[0]; }
               }
               case 328 -> {
                  recoveryAt=328; { recoveryStack[1]=Float.intBitsToFloat(1065353216); }
                  recoveryPc=331; continue recoveryFlow;
               }
               case 331 -> {
                  recoveryAt=331; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=332; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=335; { recoveryLocals[13]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[13])+(1); }
                  recoveryAt=338; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=339; { recoveryStack[1]=recoveryLocals[11];  }
                  recoveryAt=340; { recoveryStack[2]=1869690301617958719L; }
                  recoveryAt=341; { recoveryStack[3]=recoveryLocals[2];  }
                  recoveryAt=342; { recoveryStack[1]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding34(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=343; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])<=0){recoveryPc=354; continue recoveryFlow;} recoveryPc=344; continue recoveryFlow; }
               }
               case 344 -> {
                  recoveryAt=344; { recoveryStack[1]=Float.intBitsToFloat(0); }
                  recoveryAt=345; { recoveryPc=357; continue recoveryFlow; }
               }
               case 348 -> {
                  recoveryAt=348; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=349; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=350; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding35(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=351; { throw (Throwable)recoveryStack[0]; }
               }
               case 354 -> {
                  recoveryAt=354; { recoveryStack[1]=Float.intBitsToFloat(1065353216); }
                  recoveryPc=357; continue recoveryFlow;
               }
               case 357 -> {
                  recoveryAt=357; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])+dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=358; { recoveryStack[1]=recoveryLocals[10];  }
                  recoveryAt=359; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])!=0){recoveryPc=384; continue recoveryFlow;} recoveryPc=360; continue recoveryFlow; }
               }
               case 360 -> {
                  recoveryAt=360; { recoveryLocals[12]=recoveryStack[0];  }
                  recoveryAt=363; { recoveryLocals[13]=dev.prestige.recovery.SourceSupport.asInt(recoveryLocals[13])+(1); }
                  recoveryAt=366; { recoveryStack[0]=3; }
                  recoveryAt=367; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=0){recoveryPc=387; continue recoveryFlow;} recoveryPc=368; continue recoveryFlow; }
               }
               case 368 -> {
                  recoveryAt=368; { recoveryStack[0]=recoveryLocals[12];  }
                  recoveryAt=369; { recoveryStack[1]=3; }
                  recoveryAt=370; { recoveryStack[1]=(float)dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]); }
                  recoveryAt=371; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])/dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=372; { recoveryStack[1]=Float.intBitsToFloat(1120403456); }
                  recoveryAt=373; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0])*dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[1]); }
                  recoveryAt=375; { recoveryPc=390; continue recoveryFlow; }
               }
               case 378 -> {
                  recoveryAt=378; { recoveryStack[1]=1871550187560936973L; }
                  recoveryAt=379; { recoveryStack[2]=recoveryLocals[2];  }
                  recoveryAt=380; { recoveryStack[0]=dev.zprestige.prestige.client.modules.AutoCrystal.invokeBinding36(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=381; { throw (Throwable)recoveryStack[0]; }
               }
               case 384 -> {
                  recoveryAt=384; { recoveryPc=390; continue recoveryFlow; }
               }
               case 387 -> {
                  recoveryAt=387; { recoveryStack[0]=Float.intBitsToFloat(0); }
                  recoveryPc=390; continue recoveryFlow;
               }
               case 390 -> {
                  recoveryAt=390; { return dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[0]); }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=46 && recoveryAt<61 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=65; continue recoveryFlow;}
            if(recoveryAt>=50 && recoveryAt<74 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=78; continue recoveryFlow;}
            if(recoveryAt>=69 && recoveryAt<87 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=89; continue recoveryFlow;}
            if(recoveryAt>=110 && recoveryAt<120 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=124; continue recoveryFlow;}
            if(recoveryAt>=145 && recoveryAt<157 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=161; continue recoveryFlow;}
            if(recoveryAt>=148 && recoveryAt<168 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=172; continue recoveryFlow;}
            if(recoveryAt>=176 && recoveryAt<185 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=189; continue recoveryFlow;}
            if(recoveryAt>=283 && recoveryAt<301 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=303; continue recoveryFlow;}
            if(recoveryAt>=313 && recoveryAt<320 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=322; continue recoveryFlow;}
            if(recoveryAt>=333 && recoveryAt<346 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=348; continue recoveryFlow;}
            if(recoveryAt>=361 && recoveryAt<374 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=378; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 139497674086703L ^ var2;
      long var5 = var2 ^ 68538791628815L;
      long var7 = var2 ^ 34549077185626L;
      int var9 = Event.cReturningInt();
      BooleanSetting var12 = this.c;
      Boolean var13 = (Boolean)var12.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
      int var53 = var9;
      byte var52 = (byte)var10000;
      byte var51 = var52;
      byte var39 = var52;
      if (var53 != 0) {
         byte var54 = var39;
         label62:
         if (var54 != 0) {
            int var56 = var9;
            PlayerEntity var55 = var4;
            PlayerEntity var42 = var55;
            PlayerEntity var40 = var55;
            if (var56 != 0) {
               PlayerEntity var57 = var40;
               PlayerEntity var41 = var57;
               PlayerEntity var58 = var41;
               if (var58 == null) {
                  break label62;
               }

               var42 = var4;
            }

            PlayerEntity var17 = var42;
            int var59 = var17.hurtTime;
            if (var59 == 0) {
               this.n = 0.0F;
            }

            Vec3d var10;
            label51: {
               HitResult var47;
               label69: {
                  var10 = Vec3d.ZERO;
                  MinecraftClient var19 = b;
                  boolean var75 = var19.crosshairTarget instanceof BlockHitResult;
                  int var61 = var9;
                  boolean var60 = var75;
                  boolean var46 = var60;
                  boolean var43 = var60;
                  if (var61 != 0) {
                     boolean var62 = var43;
                     if (var62) {
                        MinecraftClient var21 = b;
                        HitResult var22 = var21.crosshairTarget;
                        Vec3d var76 = var22.getPos();
                        double var26 = 1.0;
                        Vec3d var23 = var76;
                        var10 = var23.add(var24, var26, var28);
                        int var63 = var9;
                        if (var63 != 0) {
                           break label51;
                        }
                     }

                     MinecraftClient var30 = b;
                     int var65 = var9;
                     HitResult var64 = var30.crosshairTarget;
                     var47 = var64;
                     HitResult var44 = var64;
                     if (var65 == 0) {
                        break label69;
                     }

                     HitResult var66 = var44;
                     HitResult var45 = var66;
                     boolean var67 = var45 instanceof EntityHitResult;
                     var46 = var67;
                  }

                  boolean var68 = var46;
                  if (!var68) {
                     break label51;
                  }

                  MinecraftClient var33 = b;
                  HitResult var69 = var33.crosshairTarget;
                  var47 = var69;
               }

               EntityHitResult var35 = (EntityHitResult)var47;
               Object[] var36 = new Object[]{var35.getEntity(), var7};
               var10 = RaycastUtil.aReturningVec3d(var36);
            }

            ExplosionDamageUtil var77 = Prestige.f;
            Object[] var38 = new Object[]{var4, var10, var5};
            ExplosionDamageUtil var37 = var77;
            float var11 = (float)var37.aReturningDouble(var38);
            float var79;
            var10000 = (var79 = var11 - this.n) == 0.0F ? 0 : (var79 < 0.0F ? -1 : 1);
            int var71 = var9;
            int var70 = var10000;
            int var49 = var70;
            int var48 = var70;
            if (var71 != 0) {
               int var72 = var48;
               if (var72 < 0) {
                  return false;
               }

               var49 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var49);
         }

         var51 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var51);
   }

   private boolean lambda$new$0(Color var1) {
      BooleanSetting var4 = this.i;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(118591387806314L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[3];
      String var6 = "\u0086\u0015±dHyjI\u0089\"(á\u0085mÂÚ+\u0081®\u008få#!ï";
      int var7 = "\u0086\u0015±dHyjI\u0089\"(á\u0085mÂÚ+\u0081®\u008få#!ï".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      z = var8;
      A = new Integer[3];
      r = 20;
      a = dev.prestige.recovery.SourceSupport.asBoolean(0);
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 16928;
      if (A[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = z[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])B.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               B.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d5", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         A[var3] = var15;
      }

      return A[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d5",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = D[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = C[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 50;
            yield var15;
         }
         case 1 -> {
            byte var16 = 8;
            yield var16;
         }
         case 2 -> {
            byte var17 = 13;
            yield var17;
         }
         case 3 -> {
            byte var18 = 56;
            yield var18;
         }
         case 4 -> {
            byte var19 = 60;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 33;
            yield var21;
         }
         case 7 -> {
            byte var22 = 7;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 44;
            yield var24;
         }
         case 10 -> {
            byte var25 = 52;
            yield var25;
         }
         case 11 -> {
            byte var26 = 53;
            yield var26;
         }
         case 12 -> {
            byte var27 = 17;
            yield var27;
         }
         case 13 -> {
            byte var28 = 15;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 4;
            yield var30;
         }
         case 16 -> {
            byte var31 = 18;
            yield var31;
         }
         case 17 -> {
            byte var32 = 63;
            yield var32;
         }
         case 18 -> {
            byte var33 = 24;
            yield var33;
         }
         case 19 -> {
            byte var34 = 36;
            yield var34;
         }
         case 20 -> {
            byte var35 = 31;
            yield var35;
         }
         case 21 -> {
            byte var36 = 49;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 10;
            yield var38;
         }
         case 24 -> {
            byte var39 = 28;
            yield var39;
         }
         case 25 -> {
            byte var40 = 23;
            yield var40;
         }
         case 26 -> {
            byte var41 = 41;
            yield var41;
         }
         case 27 -> {
            byte var42 = 54;
            yield var42;
         }
         case 28 -> {
            byte var43 = 2;
            yield var43;
         }
         case 29 -> {
            byte var44 = 45;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 22;
            yield var46;
         }
         case 32 -> {
            byte var47 = 43;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 42;
            yield var49;
         }
         case 35 -> {
            byte var50 = 20;
            yield var50;
         }
         case 36 -> {
            byte var51 = 16;
            yield var51;
         }
         case 37 -> {
            byte var52 = 55;
            yield var52;
         }
         case 38 -> {
            byte var53 = 3;
            yield var53;
         }
         case 39 -> {
            byte var54 = 21;
            yield var54;
         }
         case 40 -> {
            byte var55 = 40;
            yield var55;
         }
         case 41 -> {
            byte var56 = 5;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 35;
            yield var58;
         }
         case 44 -> {
            byte var59 = 47;
            yield var59;
         }
         case 45 -> {
            byte var60 = 62;
            yield var60;
         }
         case 46 -> {
            byte var61 = 46;
            yield var61;
         }
         case 47 -> {
            byte var62 = 32;
            yield var62;
         }
         case 48 -> {
            byte var63 = 14;
            yield var63;
         }
         case 49 -> {
            byte var64 = 1;
            yield var64;
         }
         case 50 -> {
            byte var65 = 19;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 58;
            yield var68;
         }
         case 54 -> {
            byte var69 = 61;
            yield var69;
         }
         case 55 -> {
            byte var70 = 9;
            yield var70;
         }
         case 56 -> {
            byte var71 = 26;
            yield var71;
         }
         case 57 -> {
            byte var72 = 25;
            yield var72;
         }
         case 58 -> {
            byte var73 = 51;
            yield var73;
         }
         case 59 -> {
            byte var74 = 11;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 48;
            yield var76;
         }
         case 62 -> {
            byte var77 = 29;
            yield var77;
         }
         default -> 0;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            D[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      C[0] = "S\u0001)) \u0018E\u0001,s3\u000fRJ/u?\u001bC\r8bt\f\u0002";
      C[1] = "`(53\u001etk'$|}y~*+\u0017H{o97;_v";
      C[2] = "Vd~M&}@d{\u00175jW/x\u00119~Fho\u0006rlw";
      C[3] = int.class;
      D[3] = "java/lang/Integer";
      C[4] = "\u0015((\u00039;\u0015(?_54\u000fc?A5!\b\u0012m\u001fme";
      C[5] = boolean.class;
      D[5] = "java/lang/Boolean";
      C[6] = "\\],\u001d\u000fj\\];A\u0003eF\u0016;_\u0003pAgk\u0002R";
      C[7] = "\u0006-F}F\f\u0006-Q!J\u0003\u001cfQ?J\u0016\u001b\u0017\u0000`\u0012";
      C[8] = "GN5\u0011NnGN\"MBa]\u0005\"SBtZtr\u0006\u00151";
      C[9] = "p'\u0000%/Tp'\u0017y#[jl\u0017g#Nm\u001dF8{\u0019}.\u0015x1b,vD";
      C[10] = "N*yhCiX*|2P~Oa\u007f4\\j^&h#\u0017}f";
      C[11] = "wZ-eY*\u0002z&jHect-aL?\u0017";
      C[12] = void.class;
      D[12] = "java/lang/Void";
      C[13] = "\"xd#6S4xay%D#3b\u007f)P2tuhbE\u001f";
      C[14] = "\bU~z\u00113}uuu\u0000|\u001c{~~\u0004&h";
      C[15] = "*C\u000bG6M<C\u000e\u001d%Z+\b\r\u001b)N:O\u001a\fb\\&";
      C[16] = "\u000f2u{\u0016Dz\u0012~t\u0007\u000b\u001b\u001cu\u007f\u0003Qo";
      C[17] = "/\u0011,cqx9\u0011)9bo.Z*?n{?\u001d=(%k'\u001d?#\u007f&\u001b\u0006?>\u007fa,\u0011";
      C[18] = "oxU\u0004EXyxP^VOn3SXZ[\u007ftDO\u0011JG";
      C[19] = "\u0003.\u001fl,'v\u000e\u0014c=h\u0017\u0000\u001fh92c";
      C[20] = "I\f\u0019*d\u0006_\f\u001cpw\u0011HG\u001fv{\u0005Y\u0000\ba0\u0015\u001e";
      C[21] = "{p~-Bd\u000ePu\"S+o^~)Wq\u001b";
      C[22] = "?h@DJ^?hW\u0018FQ%#W\u0006FD\"R\u0006^\u0014";
      C[23] = "E%[NQZE%L\u0012]U_nL\f]@X\u001f\u001eV\t\u0004";
      C[24] = "UKU\u00141KCKPN\"\\T\u0000SH.HEGD_eZI";
      C[25] = "l\\pK\u0010\u0002\u0019|{D\u0001MxrpO\u0005\u0017\f";
      C[26] = double.class;
      D[26] = "java/lang/Double";
      C[27] = "&phOD`-\u007fy\u0000(c#}{O\u0004";
      C[28] = "W\nN\u0011%_A\nKK6HVAHM:\\G\u0006_ZqKu";
      C[29] = "xKA/3DsDP`RJxOT:";
      C[30] = "JL\u0002g\u0018tTD\u0018(edT";
      C[31] = "oF2f:K\u001af9i+\u0004{h2b/^\u000f";
      C[32] = "j\u001b+\u000f{zj\u001b<SwupP<Mw`w!m\u0013\"%";
      C[33] = "\b>\u0007y\u0004\u0007\b>\u0010%\b\b\u0012u\u0010;\b\u001d\u0015\u0004Ae]V";
      C[34] = "(Wc%f:(Wtyj52\u001ctgj 5m%83";
      C[35] = "x1C\u001a\"\fs>RUA\u0001f8";
      C[36] = "blVS?@tlS\t,Wc'P\u000f Cr`G\u0018kQj";
      C[37] = "\naO]z%\u007fADRkj\u001eOOYo0j";
      C[38] = "JzS\u001cK(?ZX\u0013Zg^TS\u0018^=*";
      C[39] = "=R\u000b`\u001f!=R\u001c<\u0013.'\u0019\u001c\"\u0013; hK}E";
      C[40] = "`+\u0012C\u0016x`+\u0005\u001f\u001awz`\u0005\u0001\u001ab}\u0011T^H)";
      C[41] = "b4l\b:\u000fb4{T6\u0000x\u007f{J6\u0015\u007f\u000e/\u0012a";
      C[42] = "u'mXQ`c'h\u0002Bwtlk\u0004Nce+|\u0013\u0005s}";
      C[43] = "M)/+z\u00148\t$$k[Y\u0007//o\u0001-";
      C[44] = "Kn~o\u0004O@ao cMUjokX";
      C[45] = "\u000f\u0003bIP}z#iFA2\u001b-bMEho";
      C[46] = "<\u00064G]+\"\u000e.\b:*3\u0015#R\u001c,";
      C[47] = "\\Q?F/QJQ:\u001c<F]\u001a9\u001a0RL].\r{Ez";
      C[48] = "]\u001e*1\f:(>!>\u001duI0*5\u0019/=";
      C[49] = "O#\by1QY#\r#\"FNh\u000e%.R_/\u00192eES";
      C[50] = "\u0003C<n7ovc7a& \u0017m<j\"zc";
      C[51] = "''!\n\u0006fR\u0007*\u0005\u0017)3\t!\u000e\u0013sG";
      C[52] = "\u0007F~h\u001a\u0018\u0011F{2\t\u000f\u0006\rx4\u0005\u001b\u0017Jo#N\u000f\u0002";
      C[53] = "yWzlq\r\fwqc`Bmyzhd\u0018\u0019";
      C[54] = "\t\u0000^!\u0011n\u001f\u0000[{\u0002y\bKX}\u000em\u0019\fOjE}\u0002";
      C[55] = "\u0016V\u0013'\u001e?cv\u0018(\u000fp\u0002x\u0013#\u000b*v";
      C[56] = "\u00134!WC\u001d\u00054$\rP\n\u0012\u007f'\u000b\\\u001e\u000380\u001c\u0017\u000f\u0016";
      C[57] = "u\u0005#&Vy\u0000%()G6a+#\"Cl\u0015";
      C[58] = "\u001dvk\u001a\u000bMhV`\u0015\u001a\u0002\tXk\u001e\u001eX}";
      C[59] = "[c\u0012E:\u0019[c\u0005\u00196\u0016A(\u0005\u00076\u0003FYPXo";
      C[60] = "G\u0012w\u0006h{22|\ty4S<w\u0002}n'";
      C[61] = ")VR1m\u0007\\vY>|H=xR5x\u0012I";
      C[62] = "<ZmWO0IzfX^\u007f(tmSZ%\\";
      C[63] = "(@D\u001baU>@AArB)\u000bBG~V8LUP5R";
      C[64] = "uDGACB\u0000dLNR\rajGEVW\u0015";
      C[65] = "\u001a\n]%-*\f\nX\u007f>=\u001bA[y2)\n\u0006Lny>\u0007";
      C[66] = "Q\u0001t4`i$!\u007f;q&E/t0u|1";
      C[67] = "uGB&\u001aIuGUz\u0016Fo\fUd\u0016Sh}\u00070G\u0012";
      C[68] = "s\u0012\u001cp.\u0003s\u0012\u000b,\"\fiY\u000b2\"\u0019n(YizX";
      C[69] = "zdV\u0018)/\u000fD]\u00178`nJV\u001c<:\u001a";
      C[70] = "\u0017\u0006Fu+,\u0017\u0006Q)'#\rMQ7'6\n<\u0001bpp";
      C[71] = "\u0018~0\u001ck2m^;\u0013z}\fP0\u0018~'x";
      C[72] = "\u0010%8-~\u001f\u001b*)b\u0019\u0007\u001f6/.<\u0016";
      C[73] = "\u0014\u0018a\u007fS0a8jpB\u007f\u00006a{F%t";
      C[74] = "`7>[yHv7;\u0001j_a|8\u0007fKp;/\u0010-^Q";
      C[75] = "\u0002\\(,\u000b\u0011w|##\u001a^\u0016r((\u001e\u0004b";
      C[76] = "w;HD\u000e\u001a\u0002\u001bCK\u001fUc\u0015H@\u001b\u000f\u0017";
      C[77] = float.class;
      D[77] = "java/lang/Float";
      C[78] = "\u001f\u007faZTcj_jUE,\u000bQa^Av\u007f";
      C[79] = "]}^\u0004z\u007fVrOK\u0012\u007fX}\\";
      C[80] = "YB\u0017@\nkOB\u0012\u001a\u0019|X\t\u0011\u001c\u0015hIN\u0006\u000b^\u007fl";
      C[81] = "X+b\u0006>\u000f-\u000bi\t/@L\u0005b\u0002+\u001a8";
      C[82] = "\u001cg<)%K\u001cg+u)D\u0006,+k)Q\u0001]y0q\u001b";
      C[83] = ")\u000bnB(\u0003\\+eM9L=%nF=\u0016I";
      C[84] = "1m0\u00051:'m5_\"-0&6Y.9!a!Ne.\u001c";
      C[85] = "\u0006\u001eKLi{s>@Cx4\u00120KH|nf";
      C[86] = "+\u000fC;s?+Z\u0012*\u0003#t\t\u0016&Tt._HJ=&$\u0015\u00028=su\u0004";
      C[87] = ")bUwD\u0015-y\u0011j<\u0003\u00160\t\u007f_\u000bst\n`P\u000e\u00169\fqVX)sQ1\fi";
      C[88] = "(\u0017({(\u001e=\u000e$?\u0017\u001c,\u0002qk@C|_*\u0007q\u001b2\u0011(8i\u0016 \u0001";
      C[89] = "\u001f~`V-&\u0005bx]H#\u0018tg]\u001ftB#91)(\u0004chM:<H}";
      C[90] = "1\u001e&7e{$\u0007*sZy5\u000b\u007f'\r.l['sZq=\u0019evei0\u000bu";
      C[91] = "}>\u0016~\t\n|'\u001c`n\u000es-'m\u000b\u0016`6[~\u001fZ~]Fi\u0013\u0011q!U}_\u000f\u001a<Bq\u0014\u0000f/V=\nk";
      C[92] = "\r\rDd\u0005\u0003\u0013\u0012^su\u0014uWKs\u0016\u0018\u0010\u0013Hl\u0019\u001duR\u0015d\t\u000b\n\u0010\u001er\fz";
      C[93] = "q;D~6?g.\u0001tD1r5_h(\u0003!q\u0000>Dm{u\u0002h)jq.\u0005sD";
      C[94] = "B~m\u0010*aU#c\u0019Wn(}h\u00194eM9k\u0006;`(tm\u0017=6\u0017>0Wg\u0007";
      C[95] = "*ia\\+\u0015mb6ZB\u0011wjb\b\u0015F):;d8\u0010v<k\u0018)Ai}";
      C[96] = "9\u0002Y\u0000`/8\u001bS\u001e\u0007+?\u0007hKg7=\u0011\u0012\u00197r;\u0005hKg7=\u0011\u0012\u00197r;\u0005hKg7=\u0011\u0012\u00197r;\u0005h";
      C[97] = "Bb$(n|\u0005is.\u0007s\u0013p#wkAG1}!\u0007*Ek?axhN}:\u0010";
      C[98] = "5J\u0018PF-(\u0006\u0014S!\"#\n\u0018LM\u0010wN@\u0014\u001dG5J\u0018PF-(\u0006\u0014S!";
      C[99] = "$\"\u0019 |o%8\u0015&\u0004d2&\u0007\"hVefW\u007f4\u0001ca\u00009u~!j\u0016<\u0004";
      C[100] = "<\u0003D.P$!\u001bVy.=@SHfM6%\u0017KyB3@ZMhDe\u007f\u0010\u0010(\u001eT";
      C[101] = "YG3\n\u0015.G@}Q,%B\\\u0012RH9I vA@?\u0018J*PN $";
      C[102] = " .\u0013\f[LqsQ\u000e)Rp>N\u0016E`$}\u0011A\u00157s:V\u001cUI,;UL)";
      C[103] = "j-%<\u0005yt2?+uc\u0012w*+\u0016bw3)4\u0019g\u0012rt<\tqm0\u007f*\f\u0000";
      C[104] = "1\u0017>$!@)B{5_\\#\n|I<P<\u0015zy#\u000bu\u0006\u0000";
      C[105] = "m\u0004\u000f!\\J-\u0018U.fM\u0012A\b4\u0005Ew\u0005\u000b+\n@\u0012\t\u000f [_rB\u0017*\\'";
      C[106] = "g[S4Glx\u0000\u001a'=1}LH?F\\g[S4Glx\u0000\u001a'=`?V]*B\"4@X[";
      C[107] = "p%\u0001_\u0003F.>\u0010\fa]I\u007f\u0014A\u0002V,;\u0017^\rSIv\u0011O\u000b\u0005v<L\u000fQ4";
      C[108] = "Q'R\u001c\u001b5\u001a.M-\u0013QS3MN\u00184\u00170RA\u001dQVmZQ\u000b.\u0014fLTz";
      C[109] = "n\u0005wd\u0018W~X\"a)B\u0005Wb>QVx\f#cI";
      C[110] = "Vm\u0015y\u0012DWt\u001fgu^HtX\u000b\u0014@LtOw\u0007T\u0000j$j\u0010XKeXy\u0004\u0014U\u000e";
      C[111] = "/\u001f$q\u001b}5\u0003<z~x(\u0015#z)/rB~\u0016\u001fs4\u0002,j\fgx\u001c";
      C[112] = ":\u0007\u007fw\u0006+i\u0014n~\u0013Yie7+\u001c:a\u0000s(\u00035de44\u0000\"?\u000fh%\u000e=\u0003";
      C[113] = "\u001fLD\\,LBK@Mc0Ot\u0014YcSD\u0011PZ|\\At\u0011\u0007tLW\u000bS\fbI&";
      C[114] = ">k\r\u00121\u001c?q\u0001\u0014I\u0017(o\u0013\u0010%%~(NHpr+k\u000b\u001a5\ftj\bJI";
      C[115] = ";S|D-SdR\u007f\u0014QC4F`E\u0006\u0014n\u0016>)0H(QoU#\\dO";
      C[116] = "\u0013x\u0013]BgLy\u0010\r>w\u001cm\u000f\\i F=R0_|\u0000z\u0000LLhLd";
      C[117] = "x\u00144\"\b\u0011>\u0010'd\u0002 (-u8\u001cC#H1;\u0003L&-1:\u0013\u0011xG/=]JA";
      C[118] = "jPJ5*Z9\fP>2?8j\r!:\\1\u000fI\"%S4j\u0004$4UbUNyt\u000fS";
      C[119] = "\u0001}qEV\b\u001baiN3\r\u0006wvNdZ\\ *\"R\u0006\u001a`y^A\u0012V~";
      C[120] = "\b%d\u001a}\u0019O.3\u001c\u0014\u001dU&gNCJ\u000bu>\")\u001f\t6qYxBK4";
      C[121] = "$;\u0000x\u0010\u0018o2\u001fI\u0013|&/\u001f*\u0013\u0019b,\u0000%\u0016|/*\u0011#@CewQyq";
      C[122] = "gMe\u0013iyfO4I\u0005z7IkLiHc\n4\u001b?\u001fa\u000bbJ4q$T7F\u0005";
      C[123] = "\u001dUtpYmZ^#v0i@Vw$g>\u001f\u000b,H\t:A\u0005x7NvOGh";
      C[124] = "'z!~!\n:6-}F\u00051:!b*7e~y5z`'z!~!\n:6-}F";
      C[125] = "DT7Yf,^H/R\u0003)C^0RT~\u0019\to>b\"_I?Bq6\u0013W";
      C[126] = "\u0014qP\u001a|-\u0002d\u0015\u0010\u000e#\u0017\u007fK\fb\u0011D;\u0015P\u000e\u007f\u001azH\u001bt-J?N\u000f\u000e";
      C[127] = "]Jt\u000f0p\f\u00176\rBn\rZ)\u0015.\\Y\u0019vBy\u000b^Mx\u00032y^\u0018)\u0012B";
      C[128] = "\\L&\u00020e\u0017E938\u0001^X9P3d\u001a[&_6\u0001\\\u0003 R`o\u0019\\u^Q";
      C[129] = "x`\u0019\u0012\u0005\u001c#!D\n{\b\u0013'C\u001a\u0018\u0003vc@\u0005\u0017\u0006\u0013.F\u0014\u0011P,d\u001bTKa";
      C[130] = "O%/48KR==cFR3u#|%YV1 c*\\3p}k:JL2v}?;";
      C[131] = "?\u0014]g\u0018\u001a/I\bb)\u000bTM\rb\u0014\u00025@O`[";
      C[132] = "GQmw36FKaqK=QUsu'\u000f\u0002\u0010*/Kd\u0007Noc4&\fXj\u0012";
      C[133] = "\u0018K\u0003QobC\n^I\u0011us\fYYr}\u0016HZF}xs\u0005\\W{.LO\u0001\u0017!\u001f";
      C[134] = ":%V\u001d~hd>GN\u001cp\u0003|\\\u001fg&i M\u0011x\u001a";
      C[135] = "zu\u0000}E-}\u007f[z^@&|@ E,\u0014.\rx\u0013@z{Z.Z+ss]|H@";
      C[136] = "6L*-[\u0015 Yo')\u001b5B1;E)f\u0006oc)G8G2,S\u0015h\u000248)";
      C[137] = ":$\u000e|+0,1KvY55;\u0011a\u000eenmH\rc!8-Ig?062";
      C[138] = " \u0011j\u0001P\u0012u\u0002h\u0001.\b*x`W\\\u0000>H\u007f\f\u0015\u0013D\u001cjT\u0012\u00119IyV\u0012o";
      C[139] = "\u0015\u0007Z/!-S\u0003Ii+\u001cE>\u001b55\u007fN[_6*pK>\u00120;v\u001d\u0001Xm{,,";
      C[140] = "txS@]x*cB\u0013?cM\"F^\\h(fEASmM\"\u001cTF;/r\u0012\u001e\u0004aM";
      C[141] = "\u0001!\u0017fs)D~BjB\"Wc\u001e`.\u0010\u0007/F:B{\u0001x\u0002v=9\nn\u0007\u0007";
      C[142] = "\u001e\u001fW`Sh\u0002\u0003\u0015>4n\u0018\u0004I=]b!\nI-Y\u0004CXJ,E{\u0001S\\)4";
      C[143] = "VB%\u0017\u0000X\bY4DbAo\u001b/\u0015\u0019\u0016\u0005G>\u001b\u0006*";
      C[144] = "p\tL3\u0007{z\u000eC:=lAYY2^d$\u001dZ-QaA\\\u0007%Aw>\u001e\f3D\u0006";
      C[145] = "R(Q*\u000f*\u0017w\u0004&>!\u0004jX,R\u0013T&\u0002z>\"\u000eu_.U8\u0012mTK";
      C[146] = "\u001f4pf|PB&o:\u0007\u0000}%{)h\u0013M: `{i";
      C[147] = "$_6vJ\\a\u0000cz{Wr\u001d?p\u0017e%]b.F2d]?l\u001cXy\u00113o{";
      C[148] = "\u000bB'\u00045cTC$TIs\u0004W;\u0005\u001e$^\u0007gi(x\u0018@4\u0015;lT^";
      C[149] = "ZP\t\u000f3zY\n\u0012\u00020\u001e\raZV;}\u0001\u0004\u001eU$r\u0004a_\b,b\u0012\u001e\u001d\u0003:gc";
      C[150] = "88lHj59\"`N\u0012>.<rJ~\f~\u007f)\u001c\u0012`})s\u001c|%\"|\u007f-+;:#bWyk\u007f%v-";
      C[151] = "K\u0014N(|\"Q\bV#\u0019'L\u001eI#Np\u0016I\u0010Ox,P\tF3k8\u001c\u0017";
      C[152] = "F,\u001fk]/L+\u0010bg;w|\nj\u00040\u00128\tu\u000b5wu\u000fd\rcH?R$WR";
      C[153] = "]d>jW=\u001aoil>9\u0000g=>in^0eRE/\u001fo!<D5\u0013i";
      C[154] = "\u0011pnad\\\u0011%?p\u0014@Nv;|C\u0017\u0014 f\u0010*E\u001ej/b*\u0010O{";
      C[155] = "\"\u0010\u000b_{R}\u0011\b\u000f\u0007B-\u0005\u0017^P\u0015wUH2iT4\u0005\u000fL6U7U";
      C[156] = "h:\u0001k-3xgTn\u001c+\u0003:[d 4g9\u0001\u007f-7";
      C[157] = "=\u0010h.B\u0010}\u0006{o\u0006+j\u0018{0U|4B.m9\u0012n\u001fx,R\u001bf\u0018*>";
      C[158] = "4w\u007fq{_.kgz\u001eZ3}xzI\ri* \u0016\u007fQ/jwjlEct";
      C[159] = "/Df\u001edW7\u0011#\u000f\u001aM9R\u001e\u001ejQP\u0015c\u0014f\\/Wh\u0002c-";
      C[160] = "\u000fMKf\u0003\u0006PLH6\u007f\u001d\fISl\u0013/X\r\t1\u007f\u0016\u0019M^w\u0001I\u0018N\u000e\u000b\u001e\u001d\u001cOXw\r\tPQ3";
      C[161] = "\r<sfSr\u0013#iq#duf|q@i\u0010\"\u007fnOluc\"f_z\n!)pZ\u000b";
      C[162] = "95\u0000c\u000bMln\u0001y\u00132e3\u001dc\u0017^Wg^<O\r\u0000%]c\u000bUj8\u0011o\b2";
      C[163] = "@r]?\u0001&Px^jq+-{Ru\u0012 H?Qj\u001d%-,O}\u001c>SsN~LB";
      C[164] = "!\"\u000ec.Ij+\u0011R&-#j\u001f#4Kgk\u00189O\u0014#-\u0010))P\"*\nR";
      C[165] = "' \\\u0019\"t-'S\u0010\u0018`\u0016pI\u0018{ks4J\u0007tn\u0016u\u0017\u000fdxi7\u001c\u0019a\t";
      C[166] = "nh!jZloq+t=h`{\u0010!]tj{js\r1lo\u0010!]tj{js\r1lo\u0010!]tj{js\r1lo\u0010";
      C[167] = "MR@5c>H]\u0002vf@\u0015C\u001720<\u0013Ez74~\u0019A\u0000/a;\b?";
      C[168] = "\u000br|F(:Mvo\u0000\"\u000bVK=\\<hP.y_#gUK8\u0002+wC4z\t=r2";
      C[169] = "v\fN7\u0001c,\u0006\u0019\"R\r&b\u0011 Nn-\u0007U#Qa(bF7E|=\tP\"\u0000vO";
      C[170] = "?T{/>C\u007fBhnzxh\\h1)/6\u00075eEAl[k-.Hd\\9?";
      C[171] = "/LOk%i.VCm]b9HQi1Pj\f\r1]>0\b\fi09:S\u000br]";
      C[172] = "<\u0017}\nuzw\u000fw\r\rpML|Gnx(\b\u007fXa}MLyNnj7\u001e)\u000bh~M";
      C[173] = "a8$\u001bF\u001flz&T!\u0017\u0001:!VB\u001cd~\"IM\u0019\u0001b![[\u0015}q5\u0017E~";
      C[174] = ">\bSBFS\u007f\u000f\u001c\u0010\n\"nmULJAe\b\u0011OUN`mUL\u0005I{\u001c\u0014KJ\u001b7m";
      C[175] = "(:\u0016OA-c3\t~CI*.\t\u001dB,n-\u0016\u0012GI#+\u0007\u0014\u0011vivGN ";
      C[176] = "t^Rt1E'MC}$7$<\u001fv<K<C]}*NM";
      C[177] = "\u0007`\u0017$6\f\u001a,\u001b'Q\u0003\u0011 \u00178=1@bJbaf\u0012$\u000f2-\u0018M%\fbQ";
      C[178] = "A\u0003\u0018HWp\u0002\u0006\u001f\u0016\u000eO\u0016\u0006\u0002BH\u0011\u0011\u0006\u0018F4v\u0018\u001b\u0006[N$H^\u0000O4";
      C[179] = "J:yFX]]gwO%Q 9|OFYE}\u007fPI\\ 0yAO\n\u001fz$\u0001\u0015;";
      C[180] = "\u0000n$mpI_o'=\fR\u0003j<g``W.g9\fV\u000bk&kpE\u001f'8\u0000mR\u0013l7|~F_r\\aiJ\u0014} r}\u0006\n\u00162xtZ\u0012hmyw\nn";
      C[181] = "\\4>\u0002\u00101\u001bx0@\u0000N\u0000d\"\\\u001c\"20n\u0005Bte03\u0006\u0006t\u001b5<DEqe";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = C[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(D[var4]);
            C[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = C[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            C[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  C[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2065010563999577L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = C[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  C[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2065010563999577L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        C[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2065010563999577L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 227;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 201;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 231;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 87;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 205;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 216;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 227;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 201;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 231;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d5",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoCrystal var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d5;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d5", "lambda$new$0", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static int invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = c(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static PlayerEntity invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(
                  MethodHandles.lookup(),
                  "Ø",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/entity/player/PlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (PlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = c(
                  MethodHandles.lookup(),
                  "ã",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding5(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = c(MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding9(long var0, long var2) {
         MethodHandle var8 = bindingCache9;
         MethodHandle var7 = bindingCache9;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache9 = c(MethodHandles.lookup(), "ç", SourceSupport.methodType("(JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Vec3d)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static HitResult invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = c(
                  MethodHandles.lookup(), "ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/HitResult;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (HitResult)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static HitResult invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = c(
                  MethodHandles.lookup(), "ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/HitResult;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (HitResult)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = c(
                  MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding14(Object var0, double var1, double var3, double var5, long var7, long var9) {
         MethodHandle var15 = bindingCache14;
         MethodHandle var14 = bindingCache14;
         MethodHandle var12 = var14;
         if (var15 == null) {
            var12 = bindingCache14 = c(
                  MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;DDDJJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var12.invokeExact((Object)var0, (double)var1, (double)var3, (double)var5, (long)var7, (long)var9);
      } catch (Throwable var16) {
         throw SourceSupport.rethrow(var16);
      }
   }

   private static HitResult invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = c(
                  MethodHandles.lookup(), "ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/HitResult;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (HitResult)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static HitResult invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = c(
                  MethodHandles.lookup(), "ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/hit/HitResult;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (HitResult)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Entity invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = c(
                  MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/entity/Entity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Entity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ExplosionDamageUtil invokeBinding22(long var0, long var2) {
         MethodHandle var8 = bindingCache22;
         MethodHandle var7 = bindingCache22;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache22 = c(MethodHandles.lookup(), "ç", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/ax_C0050;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (ExplosionDamageUtil)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static double invokeBinding23(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = c(
                  MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (double)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = c(MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = c(MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding26(float var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache26;
         MethodHandle var9 = bindingCache26;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache26 = c(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(FFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((float)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding27(float var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache27;
         MethodHandle var9 = bindingCache27;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache27 = c(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(FFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((float)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding28(float var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = c(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(FFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var7.invokeExact((float)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ItemStack invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = c(
                  MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/ItemStack;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ItemStack)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = c(
                  MethodHandles.lookup(), "Í", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Item)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Item invokeBinding31(long var0, long var2) {
         MethodHandle var8 = bindingCache31;
         MethodHandle var7 = bindingCache31;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache31 = c(MethodHandles.lookup(), "ç", SourceSupport.methodType("(JJ)Lnet/minecraft/item/Item;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Item)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = c(MethodHandles.lookup(), "ã", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding35(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = c(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

    public final dev.zprestige.prestige.api.setting.BooleanSetting recoveryAccess_read_i() { return this.i; }

    public final dev.zprestige.prestige.api.setting.ColorSetting recoveryAccess_read_j() { return this.j; }
}
