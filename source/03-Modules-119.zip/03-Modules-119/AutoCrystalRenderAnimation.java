package dev.zprestige.prestige.client.modules.state;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.client.modules.AutoCrystal;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public class AutoCrystalRenderAnimation {
   private AutoCrystal a;
   private BlockPos b;
   private Box c;
   private float d;
   public long e;
   public long f;
   private static final long g = 132276543008586L;
   private static final long[] h;
   private static final Long[] i;
   private static final Map j = new HashMap(13);
   private static final Object[] k = new Object[59];
   private static final String[] l = new String[59];

   public AutoCrystalRenderAnimation(AutoCrystal var1, long var2) {
      super();
      var2 = 132276543008586L ^ var2;

      this.d = 0.0F;
      short var10001 = 31504;
      long var10002 = 2173445208980512509L ^ var2;
      this.e = 0L;
      this.a = var1;
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 59634050120774L ^ 52811652882500L;
      var10001 = 59634050120774L ^ 82237539208070L;
      var10001 = 59634050120774L ^ 94839981616194L;
      int var10 = Event.bReturningInt();
      int var100 = var10;
      AutoCrystalRenderAnimation var99 = this;
      AutoCrystalRenderAnimation var85 = var99;
      AutoCrystalRenderAnimation var84 = var99;
      if (var100 == 0) {
         BooleanSetting var14 = var84.a.recoveryAccess_read_i();
         Boolean var15 = (Boolean)var14.aReturningObject();
         boolean var101 = var15;
         if (!var101) {
            return;
         }

         this.e = System.currentTimeMillis() - this.f;
         this.f = System.currentTimeMillis();
         var85 = this;
      }

      float var11 = (float)var85.e * 0.005F;
      float var158;
      int var102 = (var158 = var11 - 1.0F) == 0.0F ? 0 : (var158 < 0.0F ? -1 : 1);
      if (var102 <= 0) {
         int var104 = var10;
         AutoCrystalRenderAnimation var103 = this;
         AutoCrystalRenderAnimation var87 = var103;
         AutoCrystalRenderAnimation var86 = var103;
         if (var104 == 0) {
            BlockPos var105 = var86.b;
            if (var105 == null) {
               return;
            }

            AutoCrystalRenderAnimation var106 = this;
            var87 = var106;
         }

         label71: {
            int var108 = var10;
            AutoCrystalRenderAnimation var107 = var87;
            AutoCrystalRenderAnimation var94 = var107;
            AutoCrystalRenderAnimation var88 = var107;
            if (var108 == 0) {
               AutoCrystal var21 = var88.a;
               boolean var109 = var21.aReturningBoolean();
               label67:
               if (var109) {
                  int var111 = var10;
                  MinecraftClient var110 = MinecraftAccess.b;
                  MinecraftClient var91 = var110;
                  MinecraftClient var89 = var110;
                  if (var111 == 0) {
                     MinecraftClient var112 = var89;
                     MinecraftClient var90 = var112;
                     MinecraftClient var24 = var90;
                     ClientPlayerEntity var25 = var24.player;
                     ItemStack var10000 = var25.getMainHandStack();
                     Item var27 = Items.END_CRYSTAL;
                     ItemStack var26 = var10000;
                     boolean var113 = var26.isOf(var27);
                     if (!var113) {
                        break label67;
                     }

                     MinecraftClient var114 = MinecraftAccess.b;
                     var91 = var114;
                  }

                  MinecraftClient var30 = var91;
                  int var116 = var10;
                  HitResult var115 = var30.crosshairTarget;
                  HitResult var93 = var115;
                  HitResult var92 = var115;
                  if (var116 == 0) {
                     HitResult var117 = var92;
                     if (var117 == null) {
                        break label67;
                     }

                     MinecraftClient var32 = MinecraftAccess.b;
                     HitResult var118 = var32.crosshairTarget;
                     var93 = var118;
                  }

                  HitResult var34 = var93;
                  Type var129 = var34.getType();
                  Type var120 = Type.BLOCK;
                  Type var119 = var129;
                  if (var119 == var120) {
                     float var134 = this.d;
                     ColorSetting var35 = this.a.recoveryAccess_read_j();
                     Color var36 = (Color)var35.aReturningObject();
                     float var10002 = var36.getAlpha() / 255.0F;
                     Object[] var10006 = new Object[]{null, null, null, 6822716038146L};
                     var10006[2] = var11;
                     var10006[1] = var10002;
                     var10006[0] = var134;
                     Object[] var37 = var10006;
                     this.d = ClientUiUtil.bReturningFloat(var37);
                     int var121 = var10;
                     if (var121 == 0) {
                        break label71;
                     }
                  }
               }

               AutoCrystalRenderAnimation var122 = this;
               var94 = var122;
            }

            float var135 = this.d;
            Object[] var153 = new Object[]{null, null, null, 6822716038146L};
            var153[2] = var11;
            var153[1] = 0.0F;
            var153[0] = var135;
            Object[] var40 = var153;
            var94.d = ClientUiUtil.bReturningFloat(var40);
         }

         int var124 = var10;
         AutoCrystalRenderAnimation var123 = this;
         AutoCrystalRenderAnimation var96 = var123;
         AutoCrystalRenderAnimation var95 = var123;
         if (var124 == 0) {
            float var159;
            int var125 = (var159 = var95.d - 0.01F) == 0.0F ? 0 : (var159 < 0.0F ? -1 : 1);
            if (var125 <= 0) {
               this.b = null;
               return;
            }

            var96 = this;
         }

         int var127 = var10;
         AutoCrystalRenderAnimation var126 = var96;
         AutoCrystalRenderAnimation var98 = var126;
         AutoCrystalRenderAnimation var97 = var126;
         if (var127 == 0) {
            Box var128 = var97.c;
            if (var128 == null) {
               this.c = new Box(this.b);
            }

            var98 = this;
         }

         Box var136 = this.c;
         BlockPos var45 = this.b;
         double var139 = var45.getX();
         Box var46 = this.c;
         var139 = (var139 - var46.minX) * 0.05F;
         BlockPos var47 = this.b;
         double var10003 = var47.getY();
         Box var48 = this.c;
         var10003 = (var10003 - var48.minY) * 0.05F;
         BlockPos var49 = this.b;
         double var10004 = var49.getZ();
         Box var50 = this.c;
         double var56 = (var10004 - var50.minZ) * 0.05F;
         double var54 = var10003;
         double var52 = var139;
         Box var51 = var136;
         var98.c = var51.offset(var52, var54, var56);
         ColorSetting var58 = this.a.recoveryAccess_read_j();
         Color var59 = (Color)var58.aReturningObject();
         int var141 = var59.getRed();
         ColorSetting var60 = this.a.recoveryAccess_read_j();
         Color var61 = (Color)var60.aReturningObject();
         int var146 = var61.getGreen();
         ColorSetting var62 = this.a.recoveryAccess_read_j();
         Color var63 = (Color)var62.aReturningObject();
         Color var12 = new Color(var141, var146, var63.getBlue(), (int)(this.d / 4.0F * 255.0F));
         ColorSetting var64 = this.a.recoveryAccess_read_j();
         Color var65 = (Color)var64.aReturningObject();
         int var142 = var65.getRed();
         ColorSetting var66 = this.a.recoveryAccess_read_j();
         Color var67 = (Color)var66.aReturningObject();
         int var147 = var67.getGreen();
         ColorSetting var68 = this.a.recoveryAccess_read_j();
         Color var69 = (Color)var68.aReturningObject();
         Color var13 = new Color(var142, var147, var69.getBlue(), (int)(this.d * 255.0F));
         RenderContext var130 = var1.b;
         MeshBufferManager var137 = var1.a;
         Box var70 = this.c;
         float var143 = (float)var70.minX;
         Box var71 = this.c;
         float var148 = (float)var71.minY;
         Box var72 = this.c;
         float var150 = (float)var72.minZ;
         Box var73 = this.c;
         float var10005 = (float)var73.maxX;
         Box var74 = this.c;
         float var154 = (float)var74.maxY;
         Box var75 = this.c;
         float var10007 = (float)var75.maxZ;
         Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var12, 137403672065984L};
         var10011[7] = var10007;
         var10011[6] = var154;
         var10011[5] = var10005;
         var10011[4] = var150;
         var10011[3] = var148;
         var10011[2] = var143;
         var10011[1] = var137;
         var10011[0] = var130;
         Object[] var76 = var10011;
         ShapeRenderer.hReturningVoid(var76);
         var130 = var1.b;
         MeshBufferManager var138 = var1.a;
         Box var77 = this.c;
         float var144 = (float)var77.minX;
         Box var78 = this.c;
         float var149 = (float)var78.minY;
         Box var79 = this.c;
         float var151 = (float)var79.minZ;
         Box var80 = this.c;
         var10005 = (float)var80.maxX;
         Box var81 = this.c;
         var154 = (float)var81.maxY;
         Box var82 = this.c;
         var10007 = (float)var82.maxZ;
         var10011 = new Object[]{null, null, null, null, null, null, null, null, var13, 106090074574852L};
         var10011[7] = var10007;
         var10011[6] = var154;
         var10011[5] = var10005;
         var10011[4] = var151;
         var10011[3] = var149;
         var10011[2] = var144;
         var10011[1] = var138;
         var10011[0] = var130;
         Object[] var83 = var10011;
         ShapeRenderer.gReturningVoid(var83);
      }
   }

   public void aReturningVoid(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      this.b = var2;
   }

   public BlockPos aReturningBlockPos(Object[] var1) {
      return this.b;
   }

   private void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 132276543008586L ^ var2;
      this.b = null;
      this.c = null;
      this.d = 0.0F;
      short var10001 = 20345;
      long var10002 = 788069810283975529L ^ var2;
      this.e = 0L;
      this.f = System.currentTimeMillis();
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(133858961744638L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "0WÖ±\u0003&åaìä¾3\u008b~û±";
      int var7 = "0WÖ±\u0003&åaìä¾3\u008b~û±".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      h = var8;
      i = new Long[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3647;
      if (i[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = h[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])j.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ah", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         i[var3] = var15;
      }

      return i[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ah_C0018",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ah" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = l[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = k[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 42;
            yield var15;
         }
         case 1 -> {
            byte var16 = 33;
            yield var16;
         }
         case 2 -> {
            byte var17 = 10;
            yield var17;
         }
         case 3 -> {
            byte var18 = 14;
            yield var18;
         }
         case 4 -> {
            byte var19 = 44;
            yield var19;
         }
         case 5 -> {
            byte var20 = 55;
            yield var20;
         }
         case 6 -> {
            byte var21 = 0;
            yield var21;
         }
         case 7 -> {
            byte var22 = 35;
            yield var22;
         }
         case 8 -> {
            byte var23 = 58;
            yield var23;
         }
         case 9 -> {
            byte var24 = 38;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 53;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 32;
            yield var28;
         }
         case 14 -> {
            byte var29 = 22;
            yield var29;
         }
         case 15 -> {
            byte var30 = 11;
            yield var30;
         }
         case 16 -> {
            byte var31 = 26;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 3;
            yield var33;
         }
         case 19 -> {
            byte var34 = 16;
            yield var34;
         }
         case 20 -> {
            byte var35 = 57;
            yield var35;
         }
         case 21 -> {
            byte var36 = 17;
            yield var36;
         }
         case 22 -> {
            byte var37 = 23;
            yield var37;
         }
         case 23 -> {
            byte var38 = 7;
            yield var38;
         }
         case 24 -> {
            byte var39 = 49;
            yield var39;
         }
         case 25 -> {
            byte var40 = 13;
            yield var40;
         }
         case 26 -> {
            byte var41 = 50;
            yield var41;
         }
         case 27 -> {
            byte var42 = 45;
            yield var42;
         }
         case 28 -> {
            byte var43 = 6;
            yield var43;
         }
         case 29 -> {
            byte var44 = 39;
            yield var44;
         }
         case 30 -> {
            byte var45 = 28;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 51;
            yield var47;
         }
         case 33 -> {
            byte var48 = 46;
            yield var48;
         }
         case 34 -> {
            byte var49 = 15;
            yield var49;
         }
         case 35 -> {
            byte var50 = 25;
            yield var50;
         }
         case 36 -> {
            byte var51 = 48;
            yield var51;
         }
         case 37 -> {
            byte var52 = 56;
            yield var52;
         }
         case 38 -> {
            byte var53 = 19;
            yield var53;
         }
         case 39 -> {
            byte var54 = 2;
            yield var54;
         }
         case 40 -> {
            byte var55 = 31;
            yield var55;
         }
         case 41 -> {
            byte var56 = 30;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 5;
            yield var58;
         }
         case 44 -> {
            byte var59 = 1;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 8;
            yield var61;
         }
         case 47 -> {
            byte var62 = 9;
            yield var62;
         }
         case 48 -> {
            byte var63 = 61;
            yield var63;
         }
         case 49 -> {
            byte var64 = 37;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 20;
            yield var67;
         }
         case 53 -> {
            byte var68 = 54;
            yield var68;
         }
         case 54 -> {
            byte var69 = 41;
            yield var69;
         }
         case 55 -> {
            byte var70 = 60;
            yield var70;
         }
         case 56 -> {
            byte var71 = 52;
            yield var71;
         }
         case 57 -> {
            byte var72 = 36;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 63;
            yield var74;
         }
         case 60 -> {
            byte var75 = 43;
            yield var75;
         }
         case 61 -> {
            byte var76 = 47;
            yield var76;
         }
         case 62 -> {
            byte var77 = 18;
            yield var77;
         }
         default -> 40;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            l[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      k[0] = "\b?X>\u0019y\b?Ob\u0015v\u0012tO|\u0015c\u0015\u0005\u001e#M4\u00056Mc\u0007OTn\u001c";
      k[1] = "-\u001d\u001aQ\u0017,;\u001d\u001f\u000b\u0004;,V\u001c\r\b/=\u0011\u000b\u001aC=\f";
      k[2] = int.class;
      l[2] = "java/lang/Integer";
      k[3] = "Q]@_8kQ]W\u00034dK\u0016W\u001d4qLg\u0006Bm";
      k[4] = double.class;
      l[4] = "java/lang/Double";
      k[5] = "\u0003A~EH\b\u001eT&g\t\u0005\u0006R";
      k[6] = "\u001d8^6!@\u00167Oy\\U\u0004-M:";
      k[7] = long.class;
      l[7] = "java/lang/Long";
      k[8] = "1i\u0019\u0005Z~'i\u001c_Ii0\"\u001fYE}!e\bN\u000ej#";
      k[9] = "oRFFD`\u001arMIU/{|FBQu\u000f";
      k[10] = void.class;
      l[10] = "java/lang/Void";
      k[11] = "\u001anqj9U\u001anf65Z\u0000%f(5O\u0007T7wg\u0004";
      k[12] = "f%-K\u001b(m*<\u0004w+c(>K[";
      k[13] = boolean.class;
      l[13] = "java/lang/Boolean";
      k[14] = "e\rGU^Cs\rB\u000fMTdFA\tA@u\u0001V\u001e\nWG";
      k[15] = "A\u001au)\u000e\nJ\u0015dfo\u0004A\u001e`<";
      k[16] = ".+^>\u0000A.+Ib\fN4`I|\f[3\u0011\u0019!]";
      k[17] = "P%\rC0;P%\u001a\u001f<4Jn\u001a\u0001<!M\u001fNYk";
      k[18] = "Bx*GB\u0002Bx=\u001bN\rX3=\u0005N\u0018_BoQ\u001fY";
      k[19] = "^jiOW>^j~\u0013[1D!~\r[$CP,V\u0003e";
      k[20] = "K-\u0006\u001a:Y]-\u0003@)NJf\u0000F%Z[!\u0017QnHG";
      k[21] = "oAssu'dNb<\u0016*qCmW#(`Pq{4%";
      k[22] = "[zCM\u0019&[zT\u0011\u0015)A1T\u000f\u0015<F@\u0006TMv";
      k[23] = "*pKLUd*p\\\u0010Yk0;\\\u000eY~7J\rQ\u0001";
      k[24] = "{2\u001e\u001d\u0011#m2\u001bG\u00024zy\u0018A\u000e k>\u000fVE7N";
      k[25] = "umx\u0011,s\u0000Ms\u001e=<aCx\u00159f\u0015";
      k[26] = "\u001d0Bd\u0012h\u000b0G>\u0001\u007f\u001c{D8\rk\r<S/Fy;";
      k[27] = " s\t\u00061hUS\u0002\t '4]\t\u0002$}@";
      k[28] = float.class;
      l[28] = "java/lang/Float";
      k[29] = "y\u001fb\u001bcqh@svkjyEb!<0/\u001b\u000e\u001b;gyGt\ndv";
      k[30] = "yz&\u0013}q+|(JMa@y=\u001d&`##fN7\u000b";
      k[31] = "N\u00175W\u0013-O\t Qv,\u0015\u001d>\u0000!{OJ`lM+\u001e\u0016#PO#\u001dM";
      k[32] = " _,D[d}]h_ 0q\u001a[XX?uf+XJ4w\u0005q\u0003\u0019%\u001c";
      k[33] = "Du\u0004Y\r`Bi\rWc{\u0005h\u0014J\u0005l$s\u000bJ&q\u001cv\u000f\\c-\u0012cQ\u001a\u0003l\u001apU'";
      k[34] = "\u0017\t_\u0015&A\u0013\u0017M\u001b\u001dL*\u0013\u001f\u0015,\u001c@NE\u0010$,\u0015H\u001e\u0012{J\u001aNC\r\u001d";
      k[35] = ":{9X\u0016w8xq\fi/hb+R\u0005\u001d<&q\u000bUJ<z!^\u0002)f!rOi";
      k[36] = "~sg\u0017\u0001awpu\nk3)y{\u0006\u0002?\u0010w{\u0016\u0006Y\u007fz!\u0015Tfqpr\u0006k";
      k[37] = "jKl\u0007ldkUy\u0001\tn=Pc[e\\a\u001c2<2b:Jz\u00000j9\u0011\u0003\u0007`a6U?\u0005hbm,8Ucm)\u0010:]`6P\u0016dS2n?\u0017zF4\u000b";
      k[38] = "X(\u0002M\u0017,T*\u001e_y~1z\u0005]\u0002qTuVLI\u0017";
      k[39] = "|\u007f< E\u0007}a)& \u0006'u7wwQ}\"n\u001b\u001b\u0001,~*'\u0019\t/%";
      k[40] = "jx\u0010XB:`yM\u0005z>a{D\u000b-i?,\u001cg\u0011m~t[\\G9n)";
      k[41] = "\u001cLF`Zt\u000e\u0004Et9z\u0011\u001b\u001ean$KNC\rU+A\u0017Fn\u0002(LJ";
      k[42] = "c\b\tR\u0000\u001ab\u0016\u001cTe\u001b8\u0002\u0002\u00052LbUZi^\u001c3\t\u001fU\\\u00140R";
      k[43] = "Pu\u0004(\t]Qk\u0011.l\\\u000b\u007f\u000f\u007f;\u000bQ(R\u0013W[\u0000t\u0012/US\u0003/";
      k[44] = "\u001b}\u0005F\">F\u007fA]YjJ8aS5\u0005\u001e QU2fD{\u0002DY";
      k[45] = "z:D\u0019j\u000e'8\u0000\u0002\u0011Z+\u007f0\u0005lXF:\u001e\u000bz^%`EXk5";
      k[46] = "p\u00183n.pr\u000b/c\u0016k\u001d\u001cu6t:c\u001d8<w\u0002sN,1.|r\u0003&2\u0016";
      k[47] = "\u0011C1AhmG\u0017!\u001c\u00133\u0017\u0002/D\u007f\u0001DFs\u001c\u00138\u0013G\u007f_v0C\u000e\"#";
      k[48] = "i3Q;\\\u000bh-D=9\n29Zln]hn\u0006\u0000\u0002\r92G<\u0000\u0005:i";
      k[49] = "!Nlo\u0019(#M$;fpsW~e\nB'\u0013$<^\u0015'Oti\rv}\u0014'xf";
      k[50] = "<sHr]K6r\u0015/eO7p\u001c!2\u0018i#EM\u000bQ/$\np\u0019H:x";
      k[51] = "9Jr-?W;\u0003zvDBV\nzr:\u0014i\u0004p!)+";
      k[52] = "3\u001c\u0002\u000b2@2\u0002\u0017\rWAh\u0016\t\\\u0000\u00162AV0lFc\u001d\u0014\fnN`F";
      k[53] = "oM\u0015;2\u0001mN]oMY=T\u00071!ki\u0010]hv<iL\r=&_3\u0017^,M";
      k[54] = "X&h\u0019wsJ?}E\u0005+[*qGi\u0019\u000fi.\u0010>N[h}Mc4J7l ";
      k[55] = "}A:M_2y_(Cd0@[zMUo*\u0006 H]_\u007f\u0000{J\u00029p\u0006&Ud";
      k[56] = "\u001b^:^z\u0000\u0013\u000es\u0003\u0006\u0000\u0018Kc\tj2N\u000e>Q:e\u0019\b2\u000f:\u0006N\u000b?R\u0006T\u0011\t}Q9Z\u001bZnn";
      k[57] = "V%\u0006R\\\u0007^y\nW6\u00147}^M\u0007N] \u0004H\u000f~U{XB\b\u0010Lt_\\6";
      k[58] = "qZ&?b',Xb$\u0019s \u001fW=tq+c!#sw&\u0000{x fM";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = k[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            k[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  k[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1071378866020616L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  k[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1071378866020616L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        k[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1071378866020616L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 84;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 226;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 68;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 69;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 186;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 238;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 84;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 226;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 68;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ah_C0018",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ah" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

    public final void recoveryAccess_call_bReturningVoid(java.lang.Object[] p0) { this.bReturningVoid(p0); }
}
