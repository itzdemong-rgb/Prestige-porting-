package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class AutoDrain extends Module implements RotationSource {
   private ModeSetting a;
   private MultiModeSetting c;
   private MinMaxSetting d;
   private ModeSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private FloatSetting i;
   private ArrayList j;
   private ArrayList k;
   private int l;
   private boolean m;
   private ElapsedTimer n;
   private static final long o = 38101383247930L;
   private static final String[] p;
   private static final String[] q;
   private static final Map r = new HashMap(13);
   private static final Object[] s = new Object[215];
   private static final String[] t = new String[215];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public AutoDrain() {
      super();
      long var10001 = 45772494318063L ^ 79902010220230L;
      var10001 = 45772494318063L ^ 60301071424312L;
      var10001 = 45772494318063L ^ 133455201100355L;

      this.j = new ArrayList();
      this.k = new ArrayList();
      this.l = -1;
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.n = new ElapsedTimer(106698256430889L);
      BooleanSetting var10000 = this.h;
      Object[] var10 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var9 = var10000;
      var9.aReturningBooleanSetting(var10);
      FloatSetting var13 = this.i;
      Object[] var12 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var11 = var13;
      var11.aReturningFloatSetting(var12);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 13970279202175L;
      long var6 = var2 ^ 38266410274184L;
      this.l = -1;
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
      ElapsedTimer var10000 = this.n;
      Object[] var9 = new Object[]{var4};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      RotationManager var12 = Prestige.o;
      Object[] var11 = new Object[]{this, var6};
      RotationManager var10 = var12;
      var10.dReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var4;
      AutoDrain var34;
      long var2 = (Long)var1[0];
      var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 43943734930567L;
      long var8 = var2 ^ 99766400949268L;
      int var10 = Event.bReturningInt();
      int var36 = var10;
      AutoDrain var35 = this;
      var34 = var35;
      AutoDrain var28 = var35;
      label35:
      if (var36 == 0) {
         BooleanSetting var11 = var28.h;
         Boolean var12 = (Boolean)var11.aReturningObject();
         boolean var37 = var12;
         if (var37) {
            int var39 = var10;
            AutoDrain var38 = this;
            var34 = var38;
            AutoDrain var29 = var38;
            if (var39 != 0) {
               break label35;
            }

            AutoDrain var40 = var29;
            AutoDrain var30 = var40;
            // int var41 = var30.l;
            if (var41 != var42) {
               label29: {
                  RotationManager var10000 = Prestige.o;
                  Object[] var17 = new Object[0];
                  RotationManager var16 = var10000;
                  byte var49 = ((byte)((var16.fReturningBoolean(var17)) ? 1 : 0));
                  int var44 = var10;
                  byte var43 = var49;
                  int var33 = var43;
                  byte var31 = var43;
                  if (var44 == 0) {
                     byte var45 = var31;
                     byte var32 = var45;
                     byte var46 = var32;
                     if (var46 != 0) {
                        var10000 = Prestige.o;
                        int var10001 = this.l;
                        Object[] var10004 = new Object[]{null, var6};
                        var10004[0] = var10001;
                        Object[] var21 = var10004;
                        RotationManager var20 = var10000;
                        var20.hReturningVoid(var21);
                        int var47 = var10;
                        if (var47 == 0) {
                           break label29;
                        }
                     }

                     int var48 = this.l;
                     var33 = var48;
                  }

                  Object[] var10003 = new Object[]{null, var8};
                  var10003[0] = var33;
                  Object[] var24 = var10003;
                  InventoryUtil.aReturningVoid(var24);
               }

               this.l = -1;
            }
         }

         ArrayList var25 = this.k;
         var25.clear();
         var34 = this;
      }

      var34.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var51 = Prestige.o;
      Object[] var27 = new Object[]{this, var4};
      RotationManager var26 = var51;
      var26.eReturningVoid(var27);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      ArrayList var4 = this.j;
      var4.clear();
      ArrayList var5 = this.k;
      var5.clear();
      this.l = -1;
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 4423032806718L ^ 133752389123437L;
      var10001 = 4423032806718L ^ 131728123847537L;
      var10001 = 4423032806718L ^ 38416434197822L;
      var10001 = 4423032806718L ^ 38788140851949L;
      var10001 = 4423032806718L ^ 90933229573816L;
      var10001 = 4423032806718L ^ 127234590936915L;
      var10001 = 4423032806718L ^ 76904606554184L;
      var10001 = 4423032806718L ^ 90396405264211L;
      var10001 = 4423032806718L ^ 72848080612399L;
      var10001 = 4423032806718L ^ 126535277758277L;
      var10001 = 4423032806718L ^ 135686281717174L;
      int var10000 = Event.cReturningInt();
      ArrayList var199 = this.j;
      Predicate var31 = invokeBinding3(this);
      ArrayList var30 = var199;
      var30.removeIf(var31);
      int var26 = var10000;
      ArrayList var174 = this.k;
      Predicate var33 = invokeBinding4(this);
      ArrayList var32 = var174;
      var32.removeIf(var33);
      ModeSetting var34 = this.a;
      String var175 = (String)var34.aReturningObject();
      String var36 = "Legit";
      String var35 = var175;
      byte var176 = ((byte)((var35.equals(var36)) ? 1 : 0));
      int var124 = var26;
      byte var123 = var176;
      byte var97 = var123;
      byte var96 = var123;
      if (var124 != 0) {
         byte var125 = var96;
         if (var125 == 0) {
            return;
         }

         MinecraftClient var38 = b;
         ClientPlayerEntity var39 = var38.player;
         var97 = ((byte)((var39.isUsingItem()) ? 1 : 0));
      }

      int var127 = var26;
      byte var126 = var97;
      byte var99 = var126;
      byte var98 = var126;
      if (var127 != 0) {
         byte var128 = var98;
         if (var128 != 0) {
            return;
         }

         RotationManager var177 = Prestige.o;
         Object[] var42 = new Object[0];
         RotationManager var41 = var177;
         var99 = ((byte)((var41.fReturningBoolean(var42)) ? 1 : 0));
      }

      int var130 = var26;
      byte var129 = var99;
      byte var101 = var129;
      byte var100 = var129;
      if (var130 != 0) {
         byte var131 = var100;
         if (var131 != 0) {
            return;
         }

         var101 = ((byte)((this.m) ? 1 : 0));
      }

      int var112;
      int var133 = var26;
      byte var132 = var101;
      var112 = var132;
      byte var102 = var132;
      label138:
      if (var133 != 0) {
         byte var134 = var102;
         if (var134 != 0) {
            int var136 = var26;
            int var135 = this.l;
            var112 = var135;
            int var103 = var135;
            if (var136 == 0) {
               break label138;
            }

            int var137 = var103;
            int var104 = var137;
            // int var138 = var104;
            if (var138 != var139) {
               AutoDrain var111;
               label145: {
                  ElapsedTimer var179 = this.n;
                  Object[] var48 = new Object[]{this.d, 130913203968635L};
                  ElapsedTimer var47 = var179;
                  int var180 = (((var47.bReturningBoolean(var48)) ? 1 : 0));
                  int var141 = var26;
                  boolean var140 = dev.prestige.recovery.SourceSupport.asBoolean(var180);
                  boolean var108 = var140;
                  boolean var105 = var140;
                  if (var141 != 0) {
                     boolean var142 = var105;
                     boolean var106 = var142;
                     boolean var143 = var106;
                     if (!var143) {
                        return;
                     }

                     int var145 = var26;
                     AutoDrain var144 = this;
                     var111 = var144;
                     AutoDrain var107 = var144;
                     if (var145 == 0) {
                        break label145;
                     }

                     BooleanSetting var51 = var107.h;
                     Boolean var52 = (Boolean)var51.aReturningObject();
                     boolean var146 = var52;
                     var108 = var146;
                  }

                  boolean var147 = var108;
                  if (var147) {
                     int var149 = var26;
                     AutoDrain var148 = this;
                     var111 = var148;
                     AutoDrain var109 = var148;
                     if (var149 == 0) {
                        break label145;
                     }

                     AutoDrain var150 = var109;
                     AutoDrain var110 = var150;
                     BooleanSetting var55 = var110.g;
                     Boolean var56 = (Boolean)var55.aReturningObject();
                     boolean var151 = var56;
                     if (var151) {
                        var180 = this.l;
                        Object[] var10003 = new Object[]{null, 72518082610550L};
                        var10003[0] = var180;
                        Object[] var58 = var10003;
                        InventoryUtil.aReturningVoid(var58);
                     }
                  }

                  this.l = -1;
                  this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  ElapsedTimer var182 = this.n;
                  Object[] var61 = new Object[]{42835128969216L};
                  ElapsedTimer var60 = var182;
                  var60.aReturningVoid(var61);
                  var111 = this;
               }

               MinMaxSetting var183 = var111.d;
               Object[] var63 = new Object[]{127318019014223L};
               MinMaxSetting var62 = var183;
               var62.bReturningVoid(var63);
               return;
            }
         }

         ElapsedTimer var178 = this.n;
         Object[] var65 = new Object[]{this.d, 130913203968635L};
         ElapsedTimer var64 = var178;
         var112 = (((var64.bReturningBoolean(var65)) ? 1 : 0));
      }

      int var152 = var112;
      if (var152 != 0) {
         label148: {
            Object[] var66 = new Object[]{Items.BUCKET, 95321893129094L};
            Integer var184 = InventoryUtil.aReturningBoxedInteger(var66);
            int var154 = var26;
            Integer var153 = var184;
            Object var114 = var153;
            Integer var113 = var153;
            if (var154 != 0) {
               Integer var155 = var113;
               if (var155 != null) {
                  break label148;
               }

               BooleanSetting var68 = this.f;
               Object var156 = var68.aReturningObject();
               var114 = var156;
            }

            Boolean var70 = (Boolean)var114;
            boolean var157 = var70;
            if (!var157) {
               return;
            }

            Object[] var71 = new Object[]{Items.COBWEB, 95321893129094L};
            Integer var158 = InventoryUtil.aReturningBoxedInteger(var71);
            if (var158 == null) {
               return;
            }
         }

         Object[] var74 = new Object[]{77260333461777L};
         PlayerEntity var27 = EntityUtil.aReturningPlayerEntity(var74);
         int var160 = var26;
         PlayerEntity var159 = var27;
         PlayerEntity var116 = var159;
         PlayerEntity var115 = var159;
         if (var160 != 0) {
            PlayerEntity var161 = var115;
            if (var161 == null) {
               return;
            }

            var116 = var27;
         }

         Object[] var76 = new Object[]{var116, 131657085751917L};
         Vec3d var185 = RaycastUtil.aReturningVec3d(var76);
         Object[] var77 = new Object[]{43167644123091L};
         Vec3d var79 = RaycastUtil.bReturningVec3d(var77);
         Vec3d var78 = var185;
         double var200;
         int var162 = (var200 = var78.distanceTo(var79) - 10.0) == 0.0 ? 0 : (var200 < 0.0 ? -1 : 1);
         if (var162 <= 0) {
            Object[] var82 = new Object[]{138128143196243L};
            AutoDrain var81 = this;
            BlockHitResult var28 = var81.aReturningBlockHitResult(var82);
            int var164 = var26;
            BlockHitResult var163 = var28;
            BlockHitResult var118 = var163;
            BlockHitResult var117 = var163;
            if (var164 != 0) {
               BlockHitResult var165 = var117;
               if (var165 == null) {
                  return;
               }

               var118 = var28;
            }

            AutoDrain var122;
            label150: {
               BlockHitResult var84 = var118;
               BlockPos var29 = var84.getBlockPos();
               Object[] var86 = new Object[]{var29, 94776453198445L};
               AutoDrain var85 = this;
               boolean var186 = var85.eReturningBoolean(var86);
               int var167 = var26;
               boolean var166 = var186;
               boolean var121 = var166;
               boolean var119 = var166;
               if (var167 != 0) {
                  boolean var168 = var119;
                  if (!var168) {
                     return;
                  }

                  int var170 = var26;
                  AutoDrain var169 = this;
                  var122 = var169;
                  AutoDrain var120 = var169;
                  if (var170 == 0) {
                     break label150;
                  }

                  Object[] var89 = new Object[]{var29, var28, 140059920824456L};
                  AutoDrain var88 = var120;
                  boolean var171 = var88.aReturningBoolean(var89);
                  var121 = var171;
               }

               boolean var172 = var121;
               if (!var172) {
                  return;
               }

               ElapsedTimer var187 = this.n;
               Object[] var92 = new Object[]{42835128969216L};
               ElapsedTimer var91 = var187;
               var91.aReturningVoid(var92);
               AutoDrain var173 = this;
               var122 = var173;
            }

            MinMaxSetting var188 = var122.d;
            Object[] var95 = new Object[]{127318019014223L};
            MinMaxSetting var94 = var188;
            var94.bReturningVoid(var95);
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 87666872358447L;
      long var6 = var2 ^ 29159961624672L;
      long var8 = var2 ^ 29904810088371L;
      long var10 = var2 ^ 117380820149222L;
      long var12 = var2 ^ 77379818547405L;
      long var14 = var2 ^ 83347268631053L;
      long var16 = var2 ^ 73026071141449L;
      long var18 = var2 ^ 138007752420630L;
      long var20 = var2 ^ 59641449638428L;
      long var22 = var2 ^ 134366226930033L;
      long var24 = var2 ^ 82878281429531L;
      long var26 = var2 ^ 73745600418024L;
      int var28 = Event.cReturningInt();
      RotationManager var10000 = Prestige.o;
      Object[] var40 = new Object[0];
      RotationManager var39 = var10000;
      byte var268 = ((byte)((var39.fReturningBoolean(var40)) ? 1 : 0));
      int var190 = var28;
      byte var189 = var268;
      byte var149 = var189;
      byte var148 = var189;
      if (var190 != 0) {
         byte var191 = var148;
         if (var191 != 0) {
            return null;
         }

         ModeSetting var43 = this.a;
         String var269 = (String)var43.aReturningObject();
         short var10001 = 18943;
         long var10002 = 3384539477576543453L ^ var2;
         String var45 = "Silent Aim";
         String var44 = var269;
         var149 = ((byte)((var44.equalsIgnoreCase(var45)) ? 1 : 0));
      }

      int var193 = var28;
      byte var192 = var149;
      byte var151 = var192;
      byte var150 = var192;
      if (var193 != 0) {
         byte var194 = var150;
         if (var194 == 0) {
            return null;
         }

         MinecraftClient var48 = b;
         ClientPlayerEntity var49 = var48.player;
         var151 = ((byte)((var49.isUsingItem()) ? 1 : 0));
      }

      int var196 = var28;
      byte var195 = var151;
      byte var153 = var195;
      byte var152 = var195;
      if (var196 != 0) {
         byte var197 = var152;
         if (var197 != 0) {
            return null;
         }

         var153 = ((byte)((this.m) ? 1 : 0));
      }

      int var164;
      int var199 = var28;
      byte var198 = var153;
      var164 = var198;
      byte var154 = var198;
      label215:
      if (var199 != 0) {
         byte var200 = var154;
         if (var200 != 0) {
            int var202 = var28;
            int var201 = this.l;
            var164 = var201;
            int var155 = var201;
            if (var202 == 0) {
               break label215;
            }

            int var203 = var155;
            int var156 = var203;
            // int var204 = var156;
            if (var204 != var205) {
               AutoDrain var163;
               label222: {
                  ElapsedTimer var271 = this.n;
                  Object[] var56 = new Object[]{this.d, var24};
                  ElapsedTimer var55 = var271;
                  boolean var272 = var55.bReturningBoolean(var56);
                  int var207 = var28;
                  boolean var206 = var272;
                  boolean var160 = var206;
                  boolean var157 = var206;
                  if (var207 != 0) {
                     boolean var208 = var157;
                     boolean var158 = var208;
                     boolean var209 = var158;
                     if (!var209) {
                        return null;
                     }

                     int var211 = var28;
                     AutoDrain var210 = this;
                     var163 = var210;
                     AutoDrain var159 = var210;
                     if (var211 == 0) {
                        break label222;
                     }

                     BooleanSetting var60 = var159.h;
                     Boolean var61 = (Boolean)var60.aReturningObject();
                     boolean var212 = var61;
                     var160 = var212;
                  }

                  boolean var213 = var160;
                  if (var213) {
                     int var215 = var28;
                     AutoDrain var214 = this;
                     var163 = var214;
                     AutoDrain var161 = var214;
                     if (var215 == 0) {
                        break label222;
                     }

                     AutoDrain var216 = var161;
                     AutoDrain var162 = var216;
                     BooleanSetting var64 = var162.g;
                     Boolean var65 = (Boolean)var64.aReturningObject();
                     boolean var217 = var65;
                     if (var217) {
                        int var273 = this.l;
                        Object[] var10003 = new Object[]{null, var18};
                        var10003[0] = var273;
                        Object[] var67 = var10003;
                        InventoryUtil.aReturningVoid(var67);
                     }
                  }

                  this.l = -1;
                  this.m = false;
                  ElapsedTimer var274 = this.n;
                  Object[] var70 = new Object[]{var6};
                  ElapsedTimer var69 = var274;
                  var69.aReturningVoid(var70);
                  var163 = this;
               }

               MinMaxSetting var275 = var163.d;
               Object[] var72 = new Object[]{var4};
               MinMaxSetting var71 = var275;
               var71.bReturningVoid(var72);
               return null;
            }
         }

         ElapsedTimer var270 = this.n;
         Object[] var74 = new Object[]{this.d, var24};
         ElapsedTimer var73 = var270;
         var164 = (((var73.bReturningBoolean(var74)) ? 1 : 0));
      }

      int var218 = var164;
      if (var218 == 0) {
         return null;
      }

      label225: {
         Object[] var76 = new Object[]{Items.BUCKET, var10};
         Integer var276 = InventoryUtil.aReturningBoxedInteger(var76);
         int var220 = var28;
         Integer var219 = var276;
         Object var166 = var219;
         Integer var165 = var219;
         if (var220 != 0) {
            Integer var221 = var165;
            if (var221 != null) {
               break label225;
            }

            BooleanSetting var78 = this.f;
            Object var222 = var78.aReturningObject();
            var166 = var222;
         }

         Boolean var80 = (Boolean)var166;
         boolean var223 = var80;
         if (!var223) {
            return null;
         }

         Object[] var81 = new Object[]{Items.COBWEB, var10};
         Integer var224 = InventoryUtil.aReturningBoxedInteger(var81);
         if (var224 == null) {
            return null;
         }
      }

      Object[] var84 = new Object[]{var22};
      PlayerEntity var29 = EntityUtil.aReturningPlayerEntity(var84);
      int var226 = var28;
      PlayerEntity var225 = var29;
      PlayerEntity var168 = var225;
      PlayerEntity var167 = var225;
      if (var226 != 0) {
         PlayerEntity var227 = var167;
         if (var227 == null) {
            return null;
         }

         var168 = var29;
      }

      Object[] var86 = new Object[]{var168, var14};
      Vec3d var277 = RaycastUtil.aReturningVec3d(var86);
      Object[] var87 = new Object[]{var8};
      Vec3d var89 = RaycastUtil.bReturningVec3d(var87);
      Vec3d var88 = var277;
      double var288;
      int var228 = (var288 = var88.distanceTo(var89) - 10.0) == 0.0 ? 0 : (var288 < 0.0 ? -1 : 1);
      if (var228 <= 0) {
         Object[] var92 = new Object[]{var16};
         AutoDrain var91 = this;
         BlockHitResult var30 = var91.bReturningBlockHitResult(var92);
         int var230 = var28;
         BlockHitResult var229 = var30;
         BlockHitResult var170 = var229;
         BlockHitResult var169 = var229;
         if (var230 != 0) {
            BlockHitResult var231 = var169;
            if (var231 == null) {
               return null;
            }

            var170 = var30;
         }

         BlockHitResult var95 = var170;
         BlockPos var31 = var95.getBlockPos();
         Object[] var96 = new Object[]{Items.BUCKET, var10};
         Integer var232 = InventoryUtil.aReturningBoxedInteger(var96);
         boolean var171;
         if (var232 != null) {
            boolean var233 = true;
            var171 = var233;
         } else {
            var171 = false;
         }

         boolean var176;
         label185: {
            boolean var175;
            label184: {
               label227: {
                  boolean var32 = var171;
                  int var235 = var28;
                  boolean var234 = var32;
                  boolean var173 = var234;
                  boolean var172 = var234;
                  if (var235 != 0) {
                     boolean var236 = var172;
                     if (var236) {
                        break label227;
                     }

                     BooleanSetting var99 = this.f;
                     Boolean var100 = (Boolean)var99.aReturningObject();
                     boolean var237 = var100;
                     var173 = var237;
                  }

                  int var239 = var28;
                  boolean var238 = var173;
                  var175 = var238;
                  boolean var174 = var238;
                  if (var239 == 0) {
                     break label184;
                  }

                  boolean var240 = var174;
                  if (var240) {
                     var175 = true;
                     break label184;
                  }
               }

               var176 = false;
               break label185;
            }

            boolean var241 = var175;
            var176 = var241;
         }

         Rotation var34;
         label171: {
            boolean var33 = var176;
            boolean var242 = var33;
            if (var242) {
               BlockPos var103 = var31;
               BlockPos var35 = var103.down();
               BlockPos var104 = var35;
               Vec3d var278 = Vec3d.ofCenter((Vec3i)var104);
               double var108 = 0.5;
               Vec3d var105 = var278;
               Vec3d var36 = var105.add(var106, var108, var110);
               var10000 = Prestige.o;
               Object[] var113 = new Object[]{var36, var12};
               RotationManager var112 = var10000;
               var34 = var112.aReturningdx_C0210(var113);
               Object[] var114 = new Object[]{var34, var20};
               HitResult var37 = RotationUtil.aReturningHitResult(var114);
               int var244 = var28;
               HitResult var243 = var37;
               HitResult var178 = var243;
               HitResult var177 = var243;
               if (var244 != 0) {
                  HitResult var245 = var177;
                  if (var245 == null) {
                     return null;
                  }

                  var178 = var37;
               }

               int var247 = var28;
               HitResult var246 = var178;
               HitResult var180 = var246;
               HitResult var179 = var246;
               if (var247 != 0) {
                  HitResult var116 = var179;
                  Type var280 = var116.getType();
                  Type var249 = Type.BLOCK;
                  Type var248 = var280;
                  if (var248 != var249) {
                     return null;
                  }

                  HitResult var250 = var37;
                  var180 = var250;
               }

               int var252 = var28;
               HitResult var251 = var180;
               HitResult var182 = var251;
               HitResult var181 = var251;
               if (var252 != 0) {
                  boolean var253 = var181 instanceof BlockHitResult;
                  if (!var253) {
                     return null;
                  }

                  HitResult var254 = var37;
                  var182 = var254;
               }

               BlockHitResult var38 = (BlockHitResult)var182;
               int var255 = var28;
               if (var255 == 0) {
                  return null;
               }

               var30 = var38;
               int var256 = var28;
               if (var256 != 0) {
                  break label171;
               }
            }

            var10000 = Prestige.o;
            BlockHitResult var122 = var30;
            Object[] var124 = new Object[]{var122.getPos(), var12};
            RotationManager var123 = var10000;
            var34 = var123.aReturningdx_C0210(var124);
         }

         Object[] var126 = new Object[0];
         Rotation var125 = var34;
         float var282 = var125.aReturningFloat(var126);
         MinecraftClient var127 = b;
         ClientPlayerEntity var128 = var127.player;
         float var129 = var282 - var128.getYaw();
         float var283 = Math.abs(var129);
         FloatSetting var130 = this.i;
         Float var131 = (Float)var130.aReturningObject();
         float var289;
         int var284 = (var289 = var283 - var131) == 0.0F ? 0 : (var289 < 0.0F ? -1 : 1);
         int var258 = var28;
         int var257 = var284;
         int var184 = var257;
         int var183 = var257;
         if (var258 != 0) {
            int var259 = var183;
            if (var259 > 0) {
               return null;
            }

            Object[] var135 = new Object[0];
            Rotation var134 = var34;
            var184 = (((var134.aReturningBoolean(var135)) ? 1 : 0));
         }

         AutoDrain var188;
         label230: {
            int var261 = var28;
            int var260 = var184;
            int var187 = var260;
            int var185 = var260;
            if (var261 != 0) {
               int var262 = var185;
               if (var262 != 0) {
                  return var34;
               }

               var10000 = Prestige.o;
               Object[] var139 = new Object[]{var34};
               RotationManager var138 = var10000;
               var138.aReturningVoid(var139);
               int var264 = var28;
               AutoDrain var263 = this;
               var188 = var263;
               AutoDrain var186 = var263;
               if (var264 == 0) {
                  break label230;
               }

               Object[] var141 = new Object[]{var31, var30, var26};
               AutoDrain var140 = var186;
               byte var265 = ((byte)((var140.aReturningBoolean(var141)) ? 1 : 0));
               var187 = var265;
            }

            int var266 = var187;
            if (var266 == 0) {
               return var34;
            }

            ElapsedTimer var286 = this.n;
            Object[] var144 = new Object[]{var6};
            ElapsedTimer var143 = var286;
            var143.aReturningVoid(var144);
            AutoDrain var267 = this;
            var188 = var267;
         }

         MinMaxSetting var287 = var188.d;
         Object[] var147 = new Object[]{var4};
         MinMaxSetting var146 = var287;
         var146.bReturningVoid(var147);
         return var34;
      } else {
         return null;
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      int var10000 = Event.bReturningInt();
      Object[] var9 = new Object[0];
      PacketSendEvent var8 = var1;
      Packet var6 = var8.aReturningVoid(var9);
      int var4 = var10000;
      int var45 = var4;
      Packet var44 = var6;
      Packet var38 = var44;
      Packet var37 = var44;
      if (var45 == 0) {
         boolean var46 = var37 instanceof PlayerInteractBlockC2SPacket;
         if (!var46) {
            return;
         }

         Packet var47 = var6;
         var38 = var47;
      }

      PlayerInteractBlockC2SPacket var5 = (PlayerInteractBlockC2SPacket)var38;
      int var48 = var4;
      if (var48 == 0) {
         PlayerInteractBlockC2SPacket var13 = var5;
         Hand var62 = var13.getHand();
         Hand var50 = Hand.MAIN_HAND;
         Hand var49 = var62;
         ItemStack var39;
         if (var49 == var50) {
            MinecraftClient var14 = b;
            ClientPlayerEntity var15 = var14.player;
            ItemStack var51 = var15.getMainHandStack();
            var39 = var51;
         } else {
            MinecraftClient var17 = b;
            ClientPlayerEntity var18 = var17.player;
            var39 = var18.getOffHandStack();
         }

         label27: {
            ItemStack var61 = var39;
            ItemStack var19 = var61;
            Item var63 = var19.getItem();
            int var54 = var4;
            Item var53 = Items.WATER_BUCKET;
            Item var52 = var63;
            Item var42 = var52;
            Item var43 = var53;
            Item var40 = var52;
            Item var41 = var53;
            if (var54 == 0) {
               Item var56 = var41;
               Item var55 = var40;
               if (var55 == var56) {
                  break label27;
               }

               ItemStack var21 = var61;
               Item var64 = var21.getItem();
               Item var58 = Items.LAVA_BUCKET;
               Item var57 = var64;
               var42 = var57;
               var43 = var58;
            }

            Item var60 = var43;
            Item var59 = var42;
            if (var59 != var60) {
               return;
            }
         }

         PlayerInteractBlockC2SPacket var23 = var5;
         BlockHitResult var7 = var23.getBlockHitResult();
         ArrayList var65 = this.j;
         BlockHitResult var24 = var7;
         BlockPos var10001 = var24.getBlockPos();
         BlockHitResult var25 = var7;
         Direction var26 = var25.getSide();
         int var10002 = var26.getOffsetX();
         BlockHitResult var27 = var7;
         Direction var28 = var27.getSide();
         int var10003 = var28.getOffsetY();
         BlockHitResult var29 = var7;
         Direction var30 = var29.getSide();
         int var34 = var30.getOffsetZ();
         int var33 = var10003;
         int var32 = var10002;
         BlockPos var31 = var10001;
         BlockPos var36 = var31.add(var32, var33, var34);
         ArrayList var35 = var65;
         var35.add(var36);
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      BlockHitResult var5 = (BlockHitResult)var1[1];
      long var3 = (Long)var1[2];
      var3 = 38101383247930L ^ var3;
      long var6 = var3 ^ 99482437730625L;
      long var8 = var3 ^ 12596286475060L;
      long var10 = var3 ^ 15602114198895L;
      long var12 = var3 ^ 124000548980669L;
      long var14 = var3 ^ 76754232626397L;
      long var16 = var3 ^ 121976167610943L;
      int var18 = Event.cReturningInt();
      BlockPos var21 = var2;
      ArrayList var20 = this.k;
      byte var10000 = ((byte)((var20.contains(var21)) ? 1 : 0));
      int var74 = var18;
      byte var73 = var10000;
      byte var54 = var73;
      byte var53 = var73;
      if (var74 != 0) {
         byte var75 = var53;
         if (var75 == 0) {
            Object[] var23 = new Object[]{Items.BUCKET, var8};
            Integer var76 = InventoryUtil.aReturningBoxedInteger(var23);
            byte var55;
            if (var76 != null) {
               byte var77 = 1;
               var55 = var77;
            } else {
               var55 = 0;
            }

            byte var19 = var55;
            int var79 = var18;
            byte var78 = var19;
            byte var63 = var78;
            byte var56 = var78;
            if (var79 != 0) {
               byte var80 = var56;
               if (var80 == 0) {
                  BooleanSetting var26 = this.f;
                  Boolean var27 = (Boolean)var26.aReturningObject();
                  var10000 = ((byte)(((java.lang.Boolean)(var27)).booleanValue() ? 1 : 0));
                  int var82 = var18;
                  byte var81 = var10000;
                  byte var59 = var81;
                  byte var57 = var81;
                  if (var82 != 0) {
                     byte var83 = var57;
                     byte var58 = var83;
                     byte var84 = var58;
                     if (var84 == 0) {
                        return false;
                     }

                     Object[] var31 = new Object[]{var2, var5, var10};
                     AutoDrain var30 = this;
                     byte var85 = ((byte)((var30.dReturningBoolean(var31)) ? 1 : 0));
                     var59 = var85;
                  }

                  int var87 = var18;
                  byte var86 = var59;
                  byte var61 = var86;
                  byte var60 = var86;
                  if (var87 == 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var61);
                  }

                  byte var88 = var60;
                  if (var88 != 0) {
                     var61 = 1;
                     return dev.prestige.recovery.SourceSupport.asBoolean(var61);
                  }

                  return false;
               }

               Object[] var34 = new Object[]{Items.BUCKET, var6};
               var63 = ((byte)((InventoryUtil.lReturningBoolean(var34)) ? 1 : 0));
            }

            int var91 = var18;
            byte var90 = var63;
            byte var70 = var90;
            byte var64 = var90;
            if (var91 != 0) {
               byte var92 = var64;
               if (var92 == 0) {
                  ModeSetting var36 = this.e;
                  String var105 = (String)var36.aReturningObject();
                  short var10001 = 4289;
                  long var10002 = 8700819463283465532L ^ var3;
                  String var38 = "None";
                  String var37 = var105;
                  var10000 = ((byte)((var37.equals(var38)) ? 1 : 0));
                  int var94 = var18;
                  byte var93 = var10000;
                  int var67 = var93;
                  byte var65 = var93;
                  if (var94 != 0) {
                     byte var95 = var65;
                     byte var66 = var95;
                     byte var96 = var66;
                     if (var96 != 0) {
                        return false;
                     }

                     var67 = this.l;
                  }

                  int var98 = var18;
                  int var97 = var67;
                  int var69 = var97;
                  int var68 = var97;
                  if (var98 != 0) {
                     // int var99 = var68;
                     if (var99 == var100) {
                        Object[] var43 = new Object[]{var12};
                        this.l = InventoryUtil.aReturningInt(var43);
                     }

                     Object[] var45 = new Object[]{Items.BUCKET, var14};
                     InventoryUtil.hReturningVoid(var45);
                     var69 = 1;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var69);
               }

               BooleanSetting var46 = this.g;
               Boolean var47 = (Boolean)var46.aReturningObject();
               var70 = ((byte)(((java.lang.Boolean)(var47)).booleanValue() ? 1 : 0));
            }

            int var102 = var18;
            byte var101 = var70;
            byte var72 = var101;
            byte var71 = var101;
            if (var102 != 0) {
               byte var103 = var71;
               if (var103 != 0) {
                  Object[] var49 = new Object[]{Hand.MAIN_HAND, var16};
                  ItemUseUtil.cReturningBoolean(var49);
                  this.m = dev.prestige.recovery.SourceSupport.asBoolean(1);
               }

               BlockPos var52 = var2;
               ArrayList var51 = this.k;
               var51.add(var52);
               var72 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var72);
         }

         var54 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var54);
   }

   private boolean dReturningBoolean(Object[] var1) {
      BlockPos var3 = (BlockPos)var1[0];
      BlockHitResult var2 = (BlockHitResult)var1[1];
      long var4 = (Long)var1[2];
      var4 = 38101383247930L ^ var4;
      long var6 = var4 ^ 135714894169538L;
      long var8 = var4 ^ 130760317879316L;
      long var10 = var4 ^ 43856988917345L;
      long var12 = var4 ^ 101501581918952L;
      long var14 = var4 ^ 115831809100168L;
      int var16 = Event.cReturningInt();
      BooleanSetting var17 = this.g;
      Boolean var18 = (Boolean)var17.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var18)).booleanValue() ? 1 : 0));
      int var70 = var16;
      boolean var69 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var47 = var69;
      boolean var46 = var69;
      if (var70 != 0) {
         boolean var71 = var46;
         if (!var71) {
            return false;
         }

         Object[] var21 = new Object[]{Items.COBWEB, var8};
         var47 = InventoryUtil.lReturningBoolean(var21);
      }

      int var73 = var16;
      boolean var72 = var47;
      boolean var54 = var72;
      boolean var48 = var72;
      if (var73 != 0) {
         boolean var74 = var48;
         if (!var74) {
            ModeSetting var23 = this.e;
            String var104 = (String)var23.aReturningObject();
            short var106 = 16223;
            long var107 = 2894719853637597174L ^ var4;
            String var25 = "None";
            String var24 = var104;
            var10000 = ((byte)((var24.equals(var25)) ? 1 : 0));
            int var76 = var16;
            byte var75 = var10000;
            byte var51 = var75;
            byte var49 = var75;
            if (var76 != 0) {
               byte var77 = var49;
               byte var50 = var77;
               byte var78 = var50;
               if (var78 == 0) {
                  Object[] var28 = new Object[]{Items.COBWEB, var10};
                  Integer var79 = InventoryUtil.aReturningBoxedInteger(var28);
                  if (var79 == null) {
                     return false;
                  }

                  int var81 = var16;
                  int var80 = this.l;
                  int var53 = var80;
                  int var52 = var80;
                  if (var81 != 0) {
                     // int var82 = var52;
                     if (var82 == var83) {
                        Object[] var31 = new Object[]{var12};
                        this.l = InventoryUtil.aReturningInt(var31);
                     }

                     Object[] var33 = new Object[]{Items.COBWEB, var14};
                     InventoryUtil.hReturningVoid(var33);
                     var53 = 1;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var53);
               }

               var51 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var51);
         }

         ModeSetting var34 = this.a;
         String var103 = (String)var34.aReturningObject();
         short var10001 = 18943;
         long var10002 = 3384456887668048218L ^ var4;
         String var36 = "Silent Aim";
         String var35 = var103;
         var54 = var35.equals(var36);
      }

      int var85 = var16;
      boolean var84 = var54;
      boolean var55 = var84;
      if (var85 != 0) {
         boolean var86 = var55;
         if (!var86) {
            MinecraftClient var38 = b;
            int var88 = var16;
            HitResult var87 = var38.crosshairTarget;
            HitResult var58 = var87;
            HitResult var56 = var87;
            if (var88 != 0) {
               HitResult var89 = var56;
               HitResult var57 = var89;
               boolean var90 = var57 instanceof BlockHitResult;
               if (!var90) {
                  return false;
               }

               MinecraftClient var42 = b;
               var58 = var42.crosshairTarget;
            }

            var2 = (BlockHitResult)var58;
         }

         Object[] var43 = new Object[]{var2, var6};
         ItemUseUtil.aReturningBoolean(var43);
         BlockPos var45 = var3;
         ArrayList var44 = this.k;
         boolean var59 = var44.add(var45);
      }

      int var93 = var16;
      int var92 = this.l;
      AutoDrain var91 = this;
      AutoDrain var64 = var91;
      int var65 = var92;
      AutoDrain var60 = var91;
      int var61 = var92;
      AutoDrain var67;
      int var68;
      if (var93 != 0) {
         // int var95 = var61;
         AutoDrain var94 = var60;
         AutoDrain var66 = var94;
         AutoDrain var62 = var94;
         if (var95 != var96) {
            AutoDrain var97 = var62;
            AutoDrain var63 = var97;
            byte var99 = 1;
            AutoDrain var98 = var63;
            var67 = var98;
            var68 = var99;
         } else {
            var68 = 0;
            var67 = var66;
         }
      } else {
         int var101 = var65;
         AutoDrain var100 = var64;
         var67 = var100;
         var68 = var101;
      }

      var67.m = dev.prestige.recovery.SourceSupport.asBoolean(var68);
      return true;
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 38101383247930L ^ var2;
      long var4 = var2 ^ 58027419096149L;
      MinecraftClient var10 = b;
      ClientPlayerEntity var11 = var10.player;
      Vec3d var7 = var11.getEyePos();
      MinecraftClient var12 = b;
      float var14 = 1.0F;
      ClientPlayerEntity var13 = var12.player;
      Vec3d var8 = var13.getRotationVec(var14);
      int var10000 = Event.cReturningInt();
      MinecraftClient var15 = b;
      ClientWorld var10001 = var15.world;
      Object[] var16 = new Object[]{var4};
      double var18 = ItemUseUtil.bReturningFloat(var16);
      Vec3d var17 = var8;
      Vec3d var21 = var17.multiply(var18);
      Vec3d var20 = var7;
      Vec3d var10005 = var20.add(var21);
      MinecraftClient var22 = b;
      RaycastContext var24 = new RaycastContext(var7, var10005, ShapeType.OUTLINE, FluidHandling.SOURCE_ONLY, var22.player);
      ClientWorld var23 = var10001;
      BlockHitResult var9 = var23.raycast(var24);
      int var6 = var10000;
      int var33 = var6;
      BlockHitResult var32 = var9;
      BlockHitResult var28 = var32;
      BlockHitResult var27 = var32;
      if (var33 != 0) {
         BlockHitResult var34 = var27;
         if (var34 == null) {
            return null;
         }

         var28 = var9;
      }

      int var36 = var6;
      BlockHitResult var35 = var28;
      BlockHitResult var30 = var35;
      BlockHitResult var29 = var35;
      if (var36 == 0) {
         return var30;
      }

      BlockHitResult var26 = var29;
      Type var42 = var26.getType();
      Type var38 = Type.BLOCK;
      Type var37 = var42;
      return var37 == var38 ? var9 : null;
   }

   private BlockHitResult bReturningBlockHitResult(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 38101383247930L ^ var2;
      long var4 = var2 ^ 136336757191616L;
      long var6 = var2 ^ 134094516874276L;
      long var8 = var2 ^ 61007021867055L;
      long var10 = var2 ^ 11610424868478L;
      int var10000 = Event.cReturningInt();
      MinecraftClient var18 = b;
      ClientPlayerEntity var19 = var18.player;
      Vec3d var13 = var19.getEyePos();
      int var12 = var10000;
      MinecraftClient var20 = b;
      ClientPlayerEntity var21 = var20.player;
      BlockPos var22 = var21.getBlockPos();
      Iterable var26 = BlockPos.iterateOutwards(var22, 5, 5, 5);
      Iterator var14 = var26.iterator();

      BlockHitResult var65;
      while (true) {
         BlockPos var15;
         BlockHitResult var17;
         BlockHitResult var63;
         while (true) {
            int var61;
            while (true) {
               Iterator var27 = var14;
               boolean var66 = var27.hasNext();
               if (!var66) {
                  return null;
               }

               Iterator var28 = var14;
               var15 = (BlockPos)var28.next();
               Object[] var29 = new Object[]{var4};
               Vec3d var80 = RaycastUtil.bReturningVec3d(var29);
               BlockPos var30 = var15;
               Vec3d var32 = var30.toCenterPos();
               Vec3d var31 = var80;
               double var81 = var31.distanceTo(var32);
               Object[] var33 = new Object[]{var8};
               double var88;
               var10000 = (var88 = var81 - ItemUseUtil.bReturningFloat(var33)) == 0.0 ? 0 : (var88 < 0.0 ? -1 : 1);
               int var68 = var12;
               int var67 = var10000;
               var61 = var67;
               int var60 = var67;
               if (var68 == 0) {
                  break;
               }

               int var69 = var60;
               if (var69 <= 0) {
                  Object[] var36 = new Object[]{var15, var10};
                  AutoDrain var35 = this;
                  var61 = (((var35.eReturningBoolean(var36)) ? 1 : 0));
                  break;
               }
            }

            int var70 = var61;
            if (var70 != 0) {
               BlockPos var37 = var15;
               double var10002 = var37.getX();
               BlockPos var38 = var15;
               double var10003 = var38.getY();
               BlockPos var39 = var15;
               double var10004 = var39.getZ();
               BlockPos var40 = var15;
               double var10005 = var40.getX() + 1;
               BlockPos var41 = var15;
               double var10006 = var41.getY() + 1;
               BlockPos var42 = var15;
               Box var16 = new Box(var10002, var10003, var10004, var10005, var10006, var42.getZ() + 1);
               Object[] var44 = new Object[]{var13, var16, var6};
               AutoDrain var43 = this;
               Vec3d var46 = var43.aReturningVec3d(var44);
               Vec3d var45 = var13;
               double var83 = var45.distanceTo(var46);
               Object[] var47 = new Object[]{var8};
               double var89;
               int var71 = (var89 = var83 - ItemUseUtil.bReturningFloat(var47)) == 0.0 ? 0 : (var89 < 0.0 ? -1 : 1);
               if (var71 <= 0) {
                  MinecraftClient var49 = b;
                  ClientWorld var84 = var49.world;
                  Box var50 = var16;
                  Vec3d var87 = var50.getCenter();
                  MinecraftClient var51 = b;
                  RaycastContext var53 = new RaycastContext(var13, var87, ShapeType.OUTLINE, FluidHandling.SOURCE_ONLY, var51.player);
                  ClientWorld var52 = var84;
                  var17 = var52.raycast(var53);
                  int var73 = var12;
                  BlockHitResult var72 = var17;
                  var63 = var72;
                  BlockHitResult var62 = var72;
                  if (var73 == 0) {
                     break;
                  }

                  BlockHitResult var54 = var62;
                  Type var85 = var54.getType();
                  Type var75 = Type.MISS;
                  Type var74 = var85;
                  if (var74 != var75) {
                     var63 = var17;
                     break;
                  }
               }
            }
         }

         int var77 = var12;
         BlockHitResult var76 = var63;
         var65 = var76;
         BlockHitResult var64 = var76;
         if (var77 == 0) {
            break;
         }

         BlockHitResult var57 = var64;
         BlockPos var86 = var57.getBlockPos();
         BlockPos var59 = var15;
         BlockPos var58 = var86;
         int var78 = var58.getManhattanDistance((Vec3i)var59);
         if (var78 == 0) {
            var65 = var17;
            break;
         }
      }

      return var65;
   }

   private boolean eReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      var3 = 38101383247930L ^ var3;
      long var5 = var3 ^ 112878449072846L;
      long var7 = var3 ^ 98971166246210L;
      int var9 = Event.cReturningInt();
      MinecraftClient var10 = b;
      BlockPos var12 = var2;
      ClientWorld var11 = var10.world;
      BlockState var13 = var11.getBlockState(var12);
      Object[] var15 = new Object[]{var13.getBlock(), var5};
      AutoDrain var14 = this;
      boolean var10000 = var14.gReturningBoolean(var15);
      int var47 = var9;
      boolean var46 = var10000;
      boolean var39 = var46;
      boolean var38 = var46;
      if (var47 != 0) {
         boolean var48 = var38;
         if (!var48) {
            return false;
         }

         MinecraftClient var18 = b;
         BlockPos var20 = var2;
         ClientWorld var19 = var18.world;
         FluidState var21 = var19.getFluidState(var20);
         var39 = var21.isStill();
      }

      int var50 = var9;
      boolean var49 = var39;
      boolean var41 = var49;
      boolean var40 = var49;
      if (var50 != 0) {
         boolean var51 = var40;
         if (!var51) {
            return false;
         }

         BlockPos var25 = var2;
         ArrayList var24 = this.k;
         var41 = var24.contains(var25);
      }

      int var53 = var9;
      boolean var52 = var41;
      boolean var43 = var52;
      boolean var42 = var52;
      if (var53 != 0) {
         boolean var54 = var42;
         if (var54) {
            return false;
         }

         BlockPos var29 = var2;
         ArrayList var28 = this.j;
         var43 = var28.contains(var29);
      }

      int var56 = var9;
      boolean var55 = var43;
      boolean var45 = var55;
      boolean var44 = var55;
      if (var56 != 0) {
         boolean var57 = var44;
         if (var57) {
            return false;
         }

         MinecraftClient var32 = b;
         BlockPos var34 = var2;
         ClientWorld var33 = var32.world;
         BlockState var35 = var33.getBlockState(var34);
         Object[] var37 = new Object[]{var35.getBlock(), var2, var7};
         AutoDrain var36 = this;
         var45 = var36.fReturningBoolean(var37);
      }

      return var45;
   }

   private boolean fReturningBoolean(Object[] var1) {
      Block var5 = (Block)var1[0];
      BlockPos var2 = (BlockPos)var1[1];
      long var3 = (Long)var1[2];
      var3 = 38101383247930L ^ var3;
      long var6 = var3 ^ 41188327320846L;
      long var8 = var3 ^ 84435554282817L;
      int var10 = Event.bReturningInt();
      MultiModeSetting var10000 = this.c;
      short var10001 = 16855;
      long var10002 = 3750526026073996219L ^ var3;
      Object[] var12 = new Object[]{"Water", var8};
      MultiModeSetting var11 = var10000;
      boolean var75 = var11.aReturningBoolean(var12);
      int var48 = var10;
      boolean var47 = var75;
      boolean var36 = var47;
      boolean var35 = var47;
      if (var48 == 0) {
         boolean var49 = var35;
         if (var49) {
            Block var51 = Blocks.WATER;
            Block var50 = var5;
            if (var50 == var51) {
               return true;
            }
         }

         var10000 = this.c;
         var10001 = 10825;
         var10002 = 7298228101750657057L ^ var3;
         Object[] var17 = new Object[]{"Lava", var8};
         MultiModeSetting var16 = var10000;
         var36 = var16.aReturningBoolean(var17);
      }

      int var53 = var10;
      boolean var52 = var36;
      boolean var38 = var52;
      boolean var37 = var52;
      if (var53 == 0) {
         boolean var54 = var37;
         if (var54) {
            Block var56 = Blocks.LAVA;
            Block var55 = var5;
            if (var55 == var56) {
               return true;
            }
         }

         var10000 = this.c;
         var10001 = 26540;
         var10002 = 6609732918192561605L ^ var3;
         Object[] var22 = new Object[]{"Water On Web", var8};
         MultiModeSetting var21 = var10000;
         var38 = var21.aReturningBoolean(var22);
      }

      boolean var42;
      int var58 = var10;
      boolean var57 = var38;
      var42 = var57;
      boolean var39 = var57;
      label64:
      if (var58 == 0) {
         boolean var59 = var39;
         if (var59) {
            Block var61 = Blocks.WATER;
            Block var60 = var5;
            if (var60 == var61) {
               Object[] var26 = new Object[]{var2, var6};
               AutoDrain var25 = this;
               boolean var78 = var25.hReturningVoid(var26);
               int var63 = var10;
               boolean var62 = var78;
               var42 = var62;
               boolean var40 = var62;
               if (var63 != 0) {
                  break label64;
               }

               boolean var64 = var40;
               boolean var41 = var64;
               boolean var65 = var41;
               if (var65) {
                  return true;
               }
            }
         }

         var10000 = this.c;
         var10001 = 17581;
         var10002 = 1166524370708102850L ^ var3;
         Object[] var31 = new Object[]{"Lava On Web", var8};
         MultiModeSetting var30 = var10000;
         var42 = var30.aReturningBoolean(var31);
      }

      boolean var66 = var42;
      if (var66) {
         Block var68 = Blocks.LAVA;
         Block var67 = var5;
         if (var67 == var68) {
            Object[] var34 = new Object[]{var2, var6};
            AutoDrain var33 = this;
            boolean var80 = var33.hReturningVoid(var34);
            int var70 = var10;
            boolean var69 = var80;
            boolean var45 = var69;
            boolean var43 = var69;
            if (var70 != 0) {
               return var45;
            }

            boolean var71 = var43;
            boolean var44 = var71;
            boolean var72 = var44;
            if (var72) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean gReturningBoolean(Object[] var1) {
      Block var4 = (Block)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 38101383247930L ^ var2;
      int var5 = Event.cReturningInt();
      int var13 = var5;
      Block var12 = Blocks.WATER;
      Block var11 = var4;
      Block var8 = var11;
      Block var9 = var12;
      Block var6 = var11;
      Block var7 = var12;
      if (var13 != 0) {
         Block var15 = var7;
         Block var14 = var6;
         if (var14 == var15) {
            return true;
         }

         Block var17 = Blocks.LAVA;
         Block var16 = var4;
         var8 = var16;
         var9 = var17;
      }

      Block var19 = var9;
      Block var18 = var8;
      return var18 == var19;
   }

   private boolean h(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 38101383247930L ^ var3;
      Direction[] var6 = Direction.values();
      int var22 = Event.cReturningInt();
      int var7 = var6.length;
      int var5 = var22;

      int var21;
      do {
         int var17 = var7;
         int var16 = var8;
         if (var16 >= var17) {
            break;
         }

         Direction var9 = var6[var8];
         int var18 = var5;
         if (var18 != 0) {
            MinecraftClient var10 = b;
            ClientWorld var23 = var10.world;
            Direction var12 = var9;
            BlockPos var11 = var2;
            BlockPos var14 = var11.offset(var12);
            ClientWorld var13 = var23;
            BlockState var15 = var13.getBlockState(var14);
            Block var24 = var15.getBlock();
            Block var20 = Blocks.COBWEB;
            Block var19 = var24;
            if (var19 == var20) {
               return true;
            }

            var8++;
         }

         var21 = var5;
      } while (var21 != 0);

      return false;
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      Box var5 = (Box)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 38101383247930L ^ var3;
      Box var6 = var5;
      double var10002 = var6.minX;
      Vec3d var7 = var2;
      Box var8 = var5;
      double var11 = var8.maxX;
      double var9 = var7.x;
      double var15 = Math.min(var9, var11);
      double var13 = var10002;
      var10002 = Math.max(var13, var15);
      Box var17 = var5;
      double var10003 = var17.minY;
      Vec3d var18 = var2;
      Box var19 = var5;
      double var22 = var19.maxY;
      double var20 = var18.y;
      double var26 = Math.min(var20, var22);
      double var24 = var10003;
      var10003 = Math.max(var24, var26);
      Box var28 = var5;
      double var10004 = var28.minZ;
      Vec3d var29 = var2;
      Box var30 = var5;
      double var33 = var30.maxZ;
      double var31 = var29.z;
      double var37 = Math.min(var31, var33);
      double var35 = var10004;
      return new Vec3d(var10002, var10003, Math.max(var35, var37));
   }

   private boolean lambda$onTick$3(BlockPos var1) {
      long var10001 = 111058809884401L ^ 131106503335528L;
      int var6 = Event.bReturningInt();
      MinecraftClient var7 = b;
      BlockPos var9 = var1;
      ClientWorld var8 = var7.world;
      BlockState var10 = var8.getBlockState(var9);
      Object[] var12 = new Object[]{var10.getBlock(), 20050927325337L};
      AutoDrain var11 = this;
      byte var10000 = ((byte)((var11.gReturningBoolean(var12)) ? 1 : 0));
      int var17 = var6;
      byte var16 = var10000;
      byte var14 = var16;
      byte var13 = var16;
      if (var17 == 0) {
         byte var18 = var13;
         if (var18 != 0) {
            return false;
         }

         var14 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var14);
   }

   private boolean lambda$onTick$2(BlockPos var1) {
      long var10001 = 70344332898566L ^ 50329108341151L;
      int var6 = Event.cReturningInt();
      MinecraftClient var7 = b;
      BlockPos var9 = var1;
      ClientWorld var8 = var7.world;
      BlockState var10 = var8.getBlockState(var9);
      Object[] var12 = new Object[]{var10.getBlock(), 20050927325337L};
      AutoDrain var11 = this;
      byte var10000 = ((byte)((var11.gReturningBoolean(var12)) ? 1 : 0));
      int var17 = var6;
      byte var16 = var10000;
      byte var14 = var16;
      byte var13 = var16;
      if (var17 != 0) {
         byte var18 = var13;
         if (var18 != 0) {
            return false;
         }

         var14 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var14);
   }

   private boolean lambda$new$1(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Silent Aim";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Boolean var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.e;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Normal";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.g;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(97783932817684L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      String var6 = " 5ÅW\u001e¹)>epØ/\u0084ÉàÒ\u0018\u0086\tÁ¹E$z\u000e\u001bº.Û{\f\u001b\u008d\u000b\u0098\u0013kS\u009f\u0080\u009d\u0010¥KÅ»?Ç¯ï\u008b|ËÖîí¼\u0000 |ê\u0085ïã\u0087ûÒÇ¸C\u0011Öcv9©üÊóÂa\u008b>ÆÈ\u000fNR\u0000«\u0093\u0010UÀ\u000b\u001e\u0002\u009bÚ2$\u0010ü\u0001F¨\u0099\u0004 .ê\u008a\u0005EÌ\u00050\u0094ð¡B8º\u0096>\u008a¥\u0087Tbitñ\u0017ôp\u008aªô&à\u0010\u0003\u0000üÑY\u009a;\u0013\u0097ôï\u0080)\u0093N1\u0018\u0019¯Hn\u000fú³Û\u001fy¿$ÚTT[oô\u0095ÝÈe/V";
      int var8 = " 5ÅW\u001e¹)>epØ/\u0084ÉàÒ\u0018\u0086\tÁ¹E$z\u000e\u001bº.Û{\f\u001b\u008d\u000b\u0098\u0013kS\u009f\u0080\u009d\u0010¥KÅ»?Ç¯ï\u008b|ËÖîí¼\u0000 |ê\u0085ïã\u0087ûÒÇ¸C\u0011Öcv9©üÊóÂa\u008b>ÆÈ\u000fNR\u0000«\u0093\u0010UÀ\u000b\u001e\u0002\u009bÚ2$\u0010ü\u0001F¨\u0099\u0004 .ê\u008a\u0005EÌ\u00050\u0094ð¡B8º\u0096>\u008a¥\u0087Tbitñ\u0017ôp\u008aªô&à\u0010\u0003\u0000üÑY\u009a;\u0013\u0097ôï\u0080)\u0093N1\u0018\u0019¯Hn\u000fú³Û\u001fy¿$ÚTT[oô\u0095ÝÈe/V"
         .length();
      char var5 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     p = var9;
                     q = new String[10];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "f\u0003w\u0095\u0095S©Ê¸u¢0FO´]\u0010»\u0013*+¨\u0082?Ï\u0005:-ÿ\u007f\u001f\u0097\u0002";
                  var8 = "f\u0003w\u0095\u0095S©Ê¸u¢0FO´]\u0010»\u0013*+¨\u0082?Ï\u0005:-ÿ\u007f\u001f\u0097\u0002".length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19783;
      if (q[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])r.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d6", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = p[var5].getBytes("ISO-8859-1");
         q[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return q[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d6",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = t[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = s[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 1;
            yield var15;
         }
         case 1 -> {
            byte var16 = 54;
            yield var16;
         }
         case 2 -> {
            byte var17 = 33;
            yield var17;
         }
         case 3 -> {
            byte var18 = 52;
            yield var18;
         }
         case 4 -> {
            byte var19 = 10;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 24;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 57;
            yield var23;
         }
         case 9 -> {
            byte var24 = 50;
            yield var24;
         }
         case 10 -> {
            byte var25 = 12;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 32;
            yield var27;
         }
         case 13 -> {
            byte var28 = 60;
            yield var28;
         }
         case 14 -> {
            byte var29 = 6;
            yield var29;
         }
         case 15 -> {
            byte var30 = 62;
            yield var30;
         }
         case 16 -> {
            byte var31 = 26;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 15;
            yield var33;
         }
         case 19 -> {
            byte var34 = 18;
            yield var34;
         }
         case 20 -> {
            byte var35 = 41;
            yield var35;
         }
         case 21 -> {
            byte var36 = 45;
            yield var36;
         }
         case 22 -> {
            byte var37 = 44;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 38;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 23;
            yield var41;
         }
         case 27 -> {
            byte var42 = 14;
            yield var42;
         }
         case 28 -> {
            byte var43 = 55;
            yield var43;
         }
         case 29 -> {
            byte var44 = 30;
            yield var44;
         }
         case 30 -> {
            byte var45 = 34;
            yield var45;
         }
         case 31 -> {
            byte var46 = 48;
            yield var46;
         }
         case 32 -> {
            byte var47 = 22;
            yield var47;
         }
         case 33 -> {
            byte var48 = 17;
            yield var48;
         }
         case 34 -> {
            byte var49 = 3;
            yield var49;
         }
         case 35 -> {
            byte var50 = 9;
            yield var50;
         }
         case 36 -> {
            byte var51 = 11;
            yield var51;
         }
         case 37 -> {
            byte var52 = 39;
            yield var52;
         }
         case 38 -> {
            byte var53 = 13;
            yield var53;
         }
         case 39 -> {
            byte var54 = 42;
            yield var54;
         }
         case 40 -> {
            byte var55 = 58;
            yield var55;
         }
         case 41 -> {
            byte var56 = 16;
            yield var56;
         }
         case 42 -> {
            byte var57 = 37;
            yield var57;
         }
         case 43 -> {
            byte var58 = 25;
            yield var58;
         }
         case 44 -> {
            byte var59 = 27;
            yield var59;
         }
         case 45 -> {
            byte var60 = 35;
            yield var60;
         }
         case 46 -> {
            byte var61 = 46;
            yield var61;
         }
         case 47 -> {
            byte var62 = 51;
            yield var62;
         }
         case 48 -> {
            byte var63 = 31;
            yield var63;
         }
         case 49 -> {
            byte var64 = 8;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 49;
            yield var66;
         }
         case 52 -> {
            byte var67 = 0;
            yield var67;
         }
         case 53 -> {
            byte var68 = 43;
            yield var68;
         }
         case 54 -> {
            byte var69 = 63;
            yield var69;
         }
         case 55 -> {
            byte var70 = 59;
            yield var70;
         }
         case 56 -> {
            byte var71 = 47;
            yield var71;
         }
         case 57 -> {
            byte var72 = 20;
            yield var72;
         }
         case 58 -> {
            byte var73 = 5;
            yield var73;
         }
         case 59 -> {
            byte var74 = 7;
            yield var74;
         }
         case 60 -> {
            byte var75 = 28;
            yield var75;
         }
         case 61 -> {
            byte var76 = 56;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 21;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            t[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      s[0] = "8\fkAk'8\f|\u001dg(\"G|\u0003g=%6-[5";
      s[1] = double.class;
      t[1] = "java/lang/Double";
      s[2] = "\u001fTjT!N\u001fT}\b-A\u0005\u001f}\u0016-T\u0002n,It";
      s[3] = "Fi3n)0Mf\"!J=X`";
      s[4] = "\u001d)/_s\"\u001d)8\u0003\u007f-\u0007b8\u001d\u007f8\u0000\u0013iG&{";
      s[5] = "Y\u0014stUfY\u0014d(YiC_d6Y|D.5h\f7";
      s[6] = "S\u001atE\u00182E\u001aq\u001f\u000b%RQr\u0019\u00071C\u0016e\u000eL#r";
      s[7] = int.class;
      t[7] = "java/lang/Integer";
      s[8] = "$\u0005_\u0007\u0014\u00162\u0005Z]\u0007\u0001%NY[\u000b\u00154\tNL@\u0002v";
      s[9] = "d==A9xo2,\u000eZuz?#eowk,?Ixz";
      s[10] = "\u0016\u0013\u0005AI.\u0016\u0013\u0012\u001dE!\fX\u0012\u0003E4\u000b)B^\u0014";
      s[11] = "<!|W \u0005<!k\u000b,\n&jk\u0015,\u001f!\u001b>Ju";
      s[12] = "_]% 4\u0003*}./%LKs%$!\u0016?";
      s[13] = boolean.class;
      t[13] = "java/lang/Boolean";
      s[14] = "CO_\u001fV]COHCZRY\u0004H]ZG^u\u0019\u0002\b\f";
      s[15] = "\u0017GD\u001c\u001d\n\tO^Sr\r\u000fGK1Z\f\t";
      s[16] = void.class;
      t[16] = "java/lang/Void";
      s[17] = "\u001bb:L.j\rb?\u0016=}\u001a)<\u00101i\u000bn+\u0007z~\u0006";
      s[18] = "\u0010sV%\u0006#eS]*\u0017l\u0004]V!\u00136p";
      s[19] = "k+Bv \u0001}+G,3\u0016j`D*?\u0002{'S=t\u0017V";
      s[20] = "S^~_VU&~uPG\u001aGp~[C@3";
      s[21] = "Ri676rDi3m%eS\"0k)qBe'|baZe%w8,f~%j8kQi";
      s[22] = "%k\u0002I>y.d\u0013\u0006Ca=c\u001aO";
      s[23] = "U\tgnW\u0014^\u0006v!6\u001aU\rr{";
      s[24] = "\u0019TY(K}\u000fT\\rXj\u0018\u001f_tT~\tXHc\u001fi;";
      s[25] = "Kj[\u0006`\u0011KjLZl\u001eQ!LDl\u000bVP\u001c\u001e<H";
      s[26] = "p\u000b\ri5z\u0005+\u0006f$5d%\rm o\u0010";
      s[27] = "\nX8wU\n\u001cX=-F\u001d\u000b\u0013>+J\t\u001aT)<\u0001\u0019\u0001";
      s[28] = ")V\u0000 (0\\v\u000b/9\u007f=x\u0000$=%I";
      s[29] = "\t\u0012p2j!\u0002\u001da}\r#\u0017\u0016a66";
      s[30] = "Ppa@+R%PjO:\u001dD^aD>G0";
      s[31] = "+@-wOA+@:+CN1\u000b:5C[6zha\u0012\u001a";
      s[32] = "g\u000fQ\u007fLBg\u000fF#@M}DF=@Xz5\u0014f\u0018\u0019";
      s[33] = "\u0005w\u007fG>+pWtH/d\u0011Y\u007fC+>e";
      s[34] = "PcrfQ}[lc)=~Unaf\u0011";
      s[35] = "<AL*]\u0016*AIpN\u0001=\nJvB\u0015,M]a\t\u00054";
      s[36] = "\u001f~l\u001aS]j^g\u0015B\u0012\u000bPl\u001eFH\u007f";
      s[37] = "@Jhxw]@J\u007f${RZ\u0001\u007f:{G]p-d,\f";
      s[38] = "\u000b9\u000bu\u00182~\u0019\u0000z\t}\u001f\u0017\u000bq\r'k";
      s[39] = "aofA\f\u0000\u0014OmN\u001dOuAfE\u0019\u0015\u0001";
      s[40] = "Cz\u0019)ltUz\u001cs\u007fcB1\u001fuswSv\bb8`o";
      s[41] = "\u0006.\u0001@d~s\u000e\nOu1\u0012\u0000\u0001Dqkf";
      s[42] = "2\u0001\u00176\u000ff$\u0001\u0012l\u001cq3J\u0011j\u0010e\"\r\u0006}[r\u001c";
      s[43] = "\u0011ao+]FdAd$L\t\u0005Oo/HSq";
      s[44] = "_S\u0012\n\\#_S\u0005VP,E\u0018\u0005HP9BiT\u0017\b";
      s[45] = "\f\u001b,9:\u001by;'6+T\u00185,=/\u000el";
      s[46] = "S42PR[S4%\f^TI\u007f%\u0012^AN\u000etM\n\u0002";
      s[47] = "f\u0002\u0001\u001f\u0016^P'\u0001\u001f\u0001\u0002\\(\u001bT\u0001\u001c\\=\u001c%PC\b~T";
      s[48] = "]\u001d\u001a`\u0010o]\u001d\r<\u001c`GV\r\"\u001cu@'\\|I0";
      s[49] = "d3\u0001JZod3\u0016\u0016V`~x\u0016\bVuy\tDS\u000e?";
      s[50] = "Nya\r\u007f\u001fNyvQs\u0010T2vOs\u0005SC\"\u0017$";
      s[51] = "\u0014\u001dh9~E\u0014\u001d\u007ferJ\u000eV\u007f{r_\t'./+\u0019";
      s[52] = "O-kDn-O-|\u0018b\"Uf|\u0006b7R\u0017,S5q";
      s[53] = "StFuG9EtC/T.R?@)X:CxW>\u0013+R";
      s[54] = "?[\u0007VhBJ{\fYy\r+u\u0007R}W_";
      s[55] = "U\\)wJ\u000eU\\>+F\u0001O\u0017>5F\u0014Hfol\u001eQ";
      s[56] = "c,V0\u0007\"\u0016\f]?\u0016mw\u0002V4\u00127\u0003";
      s[57] = "TO K&R!o+D7\u001d@a O3G4";
      s[58] = "+pQhw?^PZgfp?^Qlb*K";
      s[59] = "qD\u000bR\u001b\u001e\u0004d\u0000]\nQej\u000bV\u000e\u000b\u0011";
      s[60] = "Lv_\f5DLvHP9KV=HN9^QL\u0019\u0011a\tA\u007fJQ+r\u0010'\u001b";
      s[61] = "e<``\u007f\u0004\u0010\u001ckonKq\u0012`dj\u0011\u0005";
      s[62] = "\f\u001e*E\u0011\u0019\u0007\u0011;\nv\u0001\u0003\r=FS\u0010";
      s[63] = "}\u000e\u0001rD\u000e}\u000e\u0016.H\u0001gE\u00160H\u0014`4Fe\u001c^7\b\u0019=Z\u0014LYAn";
      s[64] = "\u0016\u0007U\u0018^T\b\u000fOW9U\u0019\u0014B\r\u001fS";
      s[65] = "h\u0001@V\u001doh\u0001W\n\u0011`rJW\u0014\u0011uu;\u0007AE?\"\u0007X\u0019\u0003uYW\rN@";
      s[66] = "@x-O755X&@&zTV-K\"  ";
      s[67] = "?\u0013Qk[1?\u0013F7W>%XF)W+\")\u0017v\u000ej";
      s[68] = "-~^O>T;~[\u0015-C,5X\u0013!W=rO\u0004jGz";
      s[69] = "9aF&+\u0013LAM):\\-OF\">\u0006Y";
      s[70] = "5 \u0000F.|5 \u0017\u001a\"s/k\u0017\u0004\"f(\u001aGQv,";
      s[71] = "\u0017c\u0010)\u0019DbC\u001b&\b\u000b\u0003M\u0010-\fQw";
      s[72] = float.class;
      t[72] = "java/lang/Float";
      s[73] = "Y3pO\u000esO3u\u0015\u001ddXxv\u0013\u0011pI?a\u0004Zgq";
      s[74] = "\u000fF\u001bsDdzf\u0010|U+\u001bh\u001bwQqo";
      s[75] = "\rBa\u0011k\"xbj\u001ezm\u0019la\u0015~7m";
      s[76] = "\u001f# 5;.j\u0003+:*a\u000b\r 1.;\u007f";
      s[77] = "zh(6\u0012\u0012\u000fH#9\u0003]nF(2\u0007\u0007\u001a";
      s[78] = "|t0y\"Yb|*6jYxv2qcB8E4}hEut2}";
      s[79] = "a7|4A\n\u0014\u0017w;PEu\u0019|0T\u001f\u0001";
      s[80] = "\u0002K\t'k(\u0014K\f}x?\u0003\u0000\u000f{t+\u0012G\u0018l?>3";
      s[81] = "36nQ\u0011.F\u0016e^\u0000a'\u0018nU\u0004;S";
      s[82] = "\r(r\u0001X\u001f\r(e]T\u0010\u0017ceCT\u0005\u0010\u00127\u0019\u0000A";
      s[83] = "\t?l7\u0018D\u001f?im\u000bS\btjk\u0007G\u00193}|LP#";
      s[84] = "BR\u0000<'\u00127r\u000b36]V|\u000082\u0007\"";
      s[85] = "\u000e\n\u0006S#${*\r\\2k\u001a$\u0006W61n";
      s[86] = "R\u0017\u0017\r|*D\u0017\u0012Wo=S\\\u0011Qc)B\u001b\u0006F(>N";
      s[87] = "\u0014T\r7\u0013zat\u00068\u00025\u0000z\r3\u0006ot";
      s[88] = "Rx\u001f\u0006[4'X\u0014\tJ{FV\u001f\u0002N!2";
      s[89] = "6#*|\\JC\u0003!sM\u0005\"\r*xI_V";
      s[90] = "}\u0015l\fI|k\u0015iVZk|^jPV\u007fm\u0019}G\u001dh[";
      s[91] = "\u00153]g\u0003\u0018`\u0013Vh\u0012W\u0001\u001d]c\u0016\ru";
      s[92] = "?r%{!!JR.t0n+\\%\u007f44_";
      s[93] = "/njB\u0004-$a{\rl-*nh";
      s[94] = "\u0014|\u0015\u0010\u000fOa\\\u001e\u001f\u001e\u0000\u0000R\u0015\u0014\u001aZt";
      s[95] = "c\u00119\u007f(?}\u0019#0U/}";
      s[96] = "\u0019/+jE|\u001a0 +uhA#!6\"?\u001bt\u007fZL?O.?1Dg\u001c+";
      s[97] = "-@\u0013\u0016y;&B\u0000\u0004GkW\u0007\r\u001b.a9\u0006\u001c\u0002%yWD\u000f\u0019*<nO\r\n8\u0002";
      s[98] = "4lz\u001cU\u0000po{\u0016?\fb.+\u001dS>5lqB\u0003i4*2\u0014\u0002\u0015`#!\u0015?";
      s[99] = "-(K(-\u0017/,O2D\u0005FzQ9-\n({@ &\u0012F)\u001c&<X:9Q 6i";
      s[100] = "\u001e\u0004\u0012\u0014p\u001e\u001a\t\u0014\u0015\r\u0007bR\u0007\nd\r\fS\u0016\u0013o\u0015b\u0017\u0014\u0003s\u0013\u0012\u0013\u0019\u0005rn";
      s[101] = "**z>!\u0013&<(.J\u0004.?u;&6z{-cva**z>!\u0013&<(.J";
      s[102] = "N\u0012O\u001b\u0001b\u0011X\t\u0005\u0001\u0004\u0019C\u001a\u0006SSN\u0019K_?=G\u001a\u000e\\Yb\r\\\u0010\\";
      s[103] = "\f*I:\u0004N\ri\tuaBWw0sXHVk[{\u0000\u001bS\u0011\ts\u000eGLz\u0001+]B6(\t%\u0001]] Qv\u0004'";
      s[104] = "c\u0002<\u001dn*,\u001a6[Qs|\u00148@=A+Te\u001el\u0016x\u00017E:dt\u0017eUQ";
      s[105] = "Gycj\tBDfh+9]\u0013dm=UoG 5g9^\u001bb1c\\X\u0017{\r";
      s[106] = "\u0019\u00166\u0019\r_\\\u000b#\u001dfO\u000f\u001e.O\u001d1\u0016DjA]O\u0006\u0003.Mf";
      s[107] = "p6\u0006\fY2?.\fJfko \u0002Q\nY9g_\t_\u000ed9\u0018\n_kb5\u00016";
      s[108] = "\u0019\u0000O\u0010m&\u0017QQUR/\u000eLT\u000e)B\u0018ZG[8:\u0014W\u0005\u0011Rs\u0014M\fZ++\r\u000bOj";
      s[109] = "\u0015W!pogD\u001dlg\u00051(\u001f,`l?F\u001e=yg'(\u00173|4lQO*:w\\";
      s[110] = "s'3L2#%e{O4A/r7Im-\u001d&t\u0016:zJ&vU` 4fr[i%J";
      s[111] = "KL:\u000007GZh\u0010[ OY5\u00057\u0012\u001b\u001do\\cE\u001f\u001e:\u0012)/@F2\u0019[";
      s[112] = "*e\u0003\u0014.\u0001c.\u0014XD\u001fw \u0005\u000f(-*g\\VD\u0013s3\u0007\u00036\u001fea\u0017h$\u000bs5\u001e\u0002y@\u007f-e";
      s[113] = "\u007f\u0004/qI\u000f8\u0013v6Gk/c*pK\u0002%\r+aR\t=c\"oWZv\u001azv\u0011\u0019F";
      s[114] = "z,\u001fHv7y3\u0014\tF#\" \u0015\u0014\u0011txwJx\u007ft,-\u000b\u0013w,\u007f(";
      s[115] = "\n@?}\\o@@bc7g\u001bW`t`0B\u00014\"72\u0002Cj%Kf\u000bPk";
      s[116] = "R\u000e\"8#}Y\u001fs9N/J\t)>\u0019|\u001b\\}R7+D\u000e n<:\u0015\u000f";
      s[117] = "\u0017\u0016\u0000x8\r\n@\u0012qS\u0000u\u0014\u001ex:\u0003\u001b\u0015\u000fa1\u001bu\u001c\u0001dbP\fD\u0018\"!`";
      s[118] = "\u0019/#w~3\u00136\":E&~l4*,,\u0010m%3'4~d+6t\u007f\u0007<2p7O";
      s[119] = "--m\u000bMpb5gMr)2;iV\u001e\u001ba~0\fr}<;8\u0001\u000b%%}{1";
      s[120] = ":i&\u001c\u0005%=e3\u0019>&?f8Mixa;b![x?{3MU*':";
      s[121] = "e\u001d\u001aAOB*\u0001\u0019\u001d!\u001ax\u0013\b\u001bM(*^PM!\u001a%\u000e\u0018\u0013M\u0014w\u0016Y|";
      s[122] = "Im\u0019Dy\u0003Na\fAB\u0000Lb\u0007\u0015\u0015^\u00102[y'^L\u007f\f\u0015)\fT>";
      s[123] = "xWgI08e\u0001u@[<\u001aUyI26tThP9.\u001a\u00064V#df\u0016yP)U";
      s[124] = "}_\u0007d&\u0018<_\u001fif!#Mz70[uI\u0002;=\u0019?#C$&\u001d9\u001a\u0002$>\u0010y#";
      s[125] = "l%z\u00183(09t]\f=P{\"K|$:$zCwV";
      s[126] = "\r\u0002' [(\u0015\u001e(j=+\f\u0018*=T'5\u0016*-PAZ\u001c2a\r8\u0002\u0005t\"=";
      s[127] = "U&\u001aGN\u0014\u0006t\u001f\u00122B9.\u0002L[KW/\u0013UPS9&\u001dP\u0003\u0018@~\u0004\u0016@(";
      s[128] = "\u0003\u0006YYQn\u0005\n@e\u0006j\b\u0007O2Q0X[#\\Qd\u0005\u0019HT\t7\u0000";
      s[129] = "K\u0019\u0011Au\u0000G\u000fCQ\u001e\u0017O\f\u001eDr%\u0018MO\u0012 rK\u0019\u0011Au\u0000G\u000fCQ\u001eO\u0019\u001f\u000eQt\u0010A\u0017\u0005##IM\u0000\fI|\u0011E\u000b~\u001e%\u001dR\u0002\u0014A}\u0015YpG\u001c\u007f\f\\@BLt\u001b\u001ap";
      s[130] = "\u0014?{#C,Eu64)~)wv3@tGvg*Kl)\u007fi/\u0018'P'pi[\u0017";
      s[131] = "r#\u000eGm?e#\u0004P\u001c'v#\u0007Kq\u001cuFYT&`%+YRpf%FQV`l+?\tO&/\u001b";
      s[132] = "\u001c\u001c\u00010i\tEE\u00006\u0019\\B\u0013\u001ccN\u000b\u001cDD\u000fkXGDG3$@M\u0002";
      s[133] = "T{\\\u007f>4\u0013l\u000580P\u0004\u001cY~<9\u000erXo%2\u0016\u001cYn,?\u001cc\u000el6!W\u001c";
      s[134] = "\u001e\u001eN;BM\u001cUG9\tuGGPE\u0014\u0005[.\u001a`\u0005D\u0017WByC\u0007'";
      s[135] = "\u001bO+u:/M\rcv<MG\u001a/pe!uNl/=r\"\u001e:\u007f`&P\u0012,-pM";
      s[136] = "\u001dCG|!=@GAl+AMz\u0014j!(G\u0014\u0015{8#_z\u0014,;zA@\u001d|\"=\u0014z";
      s[137] = "0ly8'?7`l=\u001c<5cgiKbm><\u0005yb5~liw0-?";
      s[138] = "]ds \u001b1@2a)p8?fm \u0019?Qg|9\u0012'?nr<AlF6kz\u0002\\";
      s[139] = "@\r\bC*\u0018\u000f\u0015\u0002\u0005\u0015A_\u001b\f\u001eys\u000fWVI\u0015\u001d^\u0017\u0003\bjJ\\\r\u001dC\u0015BW\u001dP@pD[\u0004l";
      s[140] = "{<@\fs\u001d4$JJLDd*DQ v7n\u0018\tLQ{$\u0019Xq\u001eg'E6";
      s[141] = ",M\u0018S+\u0011}\u0007UDAC\u0011\u0002\u0015IxUa\\\f\u001b */@\u0003\u001a>ZqYQBA";
      s[142] = "@\u0017m\u0016 OW\u0017g\u0001QDE\u001e\u0003\u000b:W\u0018\u0018{\u00077\u0015Rr2\u0007-\u001c\u0019\u000bj\u001ek_)";
      s[143] = "^\u0006F\u0010h\n\u0017MQ\\\u0002\u0014\u0003C@\u000bn&W\u0000\u001fP8qWTX\u0012~\u0001^\u0007J\u0006:qW\u0007X\t:\u0013\u0001E\u0010\n<q";
      s[144] = "\u0013X\u001d\u0013Z\f\u001aLIKe\u0002\fO\u0013\u0017\t0X\tNL[g\u0018Y\u001c\u001a\b[\u0013HM\u001be";
      s[145] = "kt\u0015cM]gbGs&Joa\u001afJx>#G<\u0016/dx\u0000=\u001fJbt\u0019\u0001";
      s[146] = "Zv\u0017<hN\u0013i\u0005<\"#\ri\t5o}\ni\u00131\u0013\u001a\u000f}\u0001-lM\rg\u001ff\u0013";
      s[147] = "!7R4WQp}\u001f#=\u0004\u001c\u007f_$T\tr~N=_\u0011\u001cw@8\fZe/Y~Oj";
      s[148] = "'|Y\u00169$baL\u0012R/5l\\J>\u001da(\u0005\u0013nJe+S]  :s[VR";
      s[149] = "\u0016\u0016G \u0018z\u0014\u0012C:qm}D]1\u0018g\u0013EL(\u0013\u007f}DFm\ff\u0019\u0003Q4Kh}";
      s[150] = "S}\u001er\u0004:Uq\u0007NX2Ix\u0003\"je\t)Yu=f\\j\u00004RdZ \\!=9PbXwX?\\{d";
      s[151] = "0\u0003NL\u000eK6\u000fWpRC*\u0006S\u001c`\u0017n\\\rp\u000e\u00179\u0006N\u001b\u0006Oj\u00034\u0016RTj_Q\u0010^MV";
      s[152] = "!\u0013hQ\u0014I'\u001fqmHA;\u0016u\u0001z\u0015\u007fM+m\u0014\u0015(\u0016h\u0006\u001cM{\u0013\u0012T\u0014C'\fy\\L\u0010\"v+TBL=\u001d#\f\u0011IG\u0010w\u0017\u0011\u0015\"\u0016{\u000e-";
      s[153] = "\u0010+ub\u0017^\u001c='r|I\u0014>zg\u0010{@z\">M,Dyup\u000eF\u001b!}{|\u0011B-jr\u0016N\u001a%a\u0000A\u0017\u00162hj\u001eO\u001e9\u001ai\u0015C\u001b)he\u0003\u0011\u000bB";
      s[154] = "\u0011^]xV[QZSqS%F\u0002Lv[r\u0011X\u001a(7\u001c\u0015\u001fKsI\\\u0011\u0011Bv";
      s[155] = "v\bi\b6i2\u00070B Y%e6D*0,\u000b7U3;4ee\t5!~\u0019uD3+O";
      s[156] = "5q<-|e\u007fqa3\u0017m$fc$@:}29t\u00178=riukl4ah";
      s[157] = "\u001cy\u001eI\u000e4\u001d:^\u0006k8O2g\u0000R2F8\f\b\naCB^\u0000\u0004=\\)VXW8&{^V\u000b'Ms\u0006\u0005\u000e]";
      s[158] = "nTm\u0001_2?\u001e \u00165eS\u001c`\u0011\\j=\u001dq\bWrS\u0014\u007f\r\u00049*LfKG\t";
      s[159] = "G\bJY\u0015;K\u001e\u0018I~,C\u001dE\\\u0012\u001e\u0017Y\u001d\nEIQ\r@\u0000\u0015'\u0014\u0010U\u0004~ G\u000eGP\f,Q\\W;";
      s[160] = "%Vb3\u0015@jNhu*\u0019:@fnF+l\u0002:4\u0016|nPvf[\u00039Rlx\u0010|";
      s[161] = "@\u0018\nQ\rR\u0011RGFg\u0000}P\u0007A\u000e\n\u0013Q\u0016X\u0005\u0012}PCY\u0002Q\u001f\u0006\u0001\u0011\u0001W}";
      s[162] = "N%VZ'\u0000Ln_Xl8\u0011xC\u001e\u001cW\u001co\u0002\bd[\u0011-Hb";
      s[163] = "\u0001H\f{\u0013\t\u0002W\u0007:#\u001dYD\u0006'tJ\u0003\u0013[K\u001aJWI\u0018 \u0012\u0012\u0004L";
      s[164] = "q\\>h{9p\u001f~'\u001e9!\u001cG!r $\u00168vp::]G!r $\u00168vp::]G";
      s[165] = "\u0005%U$G{L(]&\u0004\u0015Ru\t:\u0016B\u0005+YcK\u0015\u0005%U$G{L(]&\u0004";
      s[166] = "\u0001\u001fhW%$\\TdO^+\f\u0012aY2\u0019XS>\u0001gNP\r}\u000fn7\b\u0014;L^";
      s[167] = "&D5\u001e\u001e\u0017 H,\"I\u0013-E#u\u001eI}\u001bO\u001b\u001e\u001d [$\u0013FN%";
      s[168] = "7#b\u000e\fD1/{2[@<\"te\f\u001al\u007f\u0018\u000b\fN1<s\u0003T\u001d4";
      s[169] = "-!lRbSh<yV\tX?1i\u000eejku0W4=ovf\u0019{W0.n\u0012\t";
      s[170] = "\u001aQw<WvK\u001b:+=''\u0019z,T.I\u0018k5_6'\u0019>4XuEO||[s'";
      s[171] = "UB7\u007f3qH\u0014%vXu7@)\u007f1\u007fYA8f:g7\u001aja5-G\u00106 '\u001c";
      s[172] = "?\u001b\u001e1\u001b\u0014=\u001f\u001a+r\nTI\u0004 \u001b\t:H\u00159\u0010\u0011T\u001aI?\n[(\n\u00049\u0000j";
      s[173] = "oifN\u0011rmmbTxe\u0004;|_\u0011oj:mF\u001aw\u0004h1@\u0000=xx|F\n\f";
      s[174] = "*\u0005!8Cb/\u0017~&A\u001ez|}>\u001cwp\u0012|/\u0005|h|92\u0001n|\f',\rc\u0013";
      s[175] = "X5Rr\u0001T[*Y31@\u00009X.f\u0017Zn\u0004B\b\u0017\u000e4F)\u0000O]1";
      s[176] = ")\u000fh6n\u000b%\u0019:&\u0005\u001c-\u001ag3i.yW;i8yy\u000fu0\u007f\u0016{\t?ljy}]h$w\u0013\"\u0005`/\u0005";
      s[177] = "{.bTzV\"wcR\n\u0003%!\u007f\u0007]T{r&kw\u001d9<t\u001bi\u000351";
      s[178] = "~e>\u0018\u0010\u0012*49[\u000fr-\u000f:^\u0013\u001b$a;O\n\u0010<\u000feG\tN~jcK\u0010r";
      s[179] = "\u0001`|fB*X9}`2\u007f_oa5e(\u00002:Y\u0002(X~o\"KcO2";
      s[180] = "\u0018\u0014\u0010>Oj\u0014\u0002B.$}\u001c\u0001\u001f;HOHEEb\u001f\u0018LF\u0010,Vr\u0013\u001e\u0018'$";
      s[181] = "\u0017\u0019bT\u0017$X\u0001h\u0012(}\b\u000ff\tDO[K9_(h\u0017\u0001;\u0000\u0015'\u000b\u0002gn";
      s[182] = "_X\u0011~\u0004QAF\u001dskDOT\fi\u0007v\u001b\u0017S>P!\u001b\u0015\u0010d\n_[\u0011\u001em\u000f!";
      s[183] = "7U^gdp0YKb_s2Z@6\b-l\u000f\u0019Z:-2GK64\u007f*\u0006";
      s[184] = "f\\c`Qx:@m%nlZ\u0002;3\u001et0]c;\u0015\u0006";
      s[185] = "+(&$*\u000eh(sz\u007f~{M#;{\u0017q#\"*b\u001ciM+$gO\"4s=!\f\u0012";
      s[186] = "\u0016,b\u0012\u0007LV(l\u001b\u00022Aps\u001c\ne\u0016*%Cf\u000b\u0012mt\u0019\u0018K\u0016c}\u001c";
      s[187] = "4=\u007f\u0018C\u00038+-\b(\u00140(p\u001dD&dl*D\u0014q`o\u007f\nZ\u001b?7w\u0001(";
      s[188] = "\u001f\fR2JgNF\u001f% 5\"D_\"I?LEN;B'\"\u001bF8\u001ceG\u001dJ! ";
      s[189] = "\u0005Q\b}<7\u0012HJfL9jL\u0018m}:\u0012@\u0015/7P";
      s[190] = "\u00023\u0011\f\u0018}\b*\u0010A#jep\u0006QJb\u000bq\u0017HAzex\u0019M\u00121\u001c \u0000\u000bQ\u0001";
      s[191] = "K(:\u0018MRI,>\u0002$B z \tMON{1\u0010FW r?\u0015\u0015\u001cY*&SV,";
      s[192] = ":{^BH-8\u007fZX!>Q)DSH0?(UJC(Qz\tLYb-jDJSS";
      s[193] = "U@.LL\u000bV_%\r|\u001f\rL$\u0010+HW\u001b}|EH\u0003A:\u0017M\u0010PD";
      s[194] = "8\u0001\u000f\u007f\u00002kS\n*|gT\t\u0017t\u0015m:\b\u0006m\u001euTZZk\u0004?(J\u0017m\u000e\u000e";
      s[195] = "\u0012N\u0003\u0016\u0017D\u001bZWN(J\rY\r\u0012DxY\u001fPI\u0013/Y\u001d\u0015\u0010\u0010M\u000f_]\u0013\u0016/";
      s[196] = "5\tTY \u0017'VH\u0007O\u000f[[DY>\u0001%Y@]$";
      s[197] = "pDfG'k5YsCL`bTc\u001b R6\u0010:@|\u00052\u0013l\f>omKd\u0007L";
      s[198] = "M\t\u0004*}W\u001cCI=\u0017\u0003pA\t:~\u000f\u001e@\u0018#u\u0017pI\u0016&&\\\t\u0011\u000f`el";
      s[199] = "\u0000:y3g1\u001dlk:\f5b8g3e?\f9v*n'b< <|.\bcx4w\\";
      s[200] = "J\u001cI'\\XI\u0003BflL\u0012\u0010C{;\u001bHG\u001b\u0017U\u001b\u001c\u001d]|]CO\u0018";
      s[201] = "L\u0010d(\u0016D\u0006\u001096}L]\u0007;!*\u001b\u0004Qcv}\u0019D\u00131p\u0001MM\u00000";
      s[202] = "(O\t#9j.C\u0010\u001feb2J\u0014sW6v\u0010I\u001ffj4\u0016Jz`f-*J&oo4AB~<jN";
      s[203] = "q&m\u0019\u0013\u00008mzUy\u001e,ck\u0002\u0015,q$1]y\u0012(pi\u000e\u000b\u001e>\"yeBEpya\f\u0006Fqs\u000b";
      s[204] = "#)Yh\u0011mrc\u0014\u007f{6\u001eaTx\u00125p`Ea\u0019-\u001eiKdJfg1R\"\tV";
      s[205] = "\ng]\rKX^6ZNT8Z\rYKHQPcXZQZH\r\u0006RR\u0004\nh\u0000^K8";
      s[206] = "SG{\u0014]\u0012V\u0017p\u0003\u001b\"\u000b\u0004w\u0010J^\r\u0002\u001aS\u0013GRC\"QXNP\b\u001a";
      s[207] = "v{\u0007J9\u0006 a\fY'k&\u0019DH%\u0002,wEY<\t4\u0019DP+\u0005pi\u0005I|\u0017w\u0019";
      s[208] = "<I8\u0006M=2\u0018&Cr4+\u0005#\u0018\t\u0018=\u001e-\u0006\u001f\u0012;\u0003'|\u001ch \u0002u\u0018\u00129>GJM\u0011%cH3\u0015\bc x";
      s[209] = "Inoj}1^ne}\f8Gm}qm5[\u000bnsvbJsb~4( :bd=cYb{\"~S";
      s[210] = "M\u0006\u007f6\u0010%K\nf\nL-W\u0003bf~y\u0013Z4\nO%Q_<oI)HccoS|\u0012\u0006ecJ@";
      s[211] = "d8'l\u0019\u00162zoo\u001ft8m#iF\u0018\n9`6\u0011H]f:s\u001dM8`6j!";
      s[212] = "v'9\r#\u001ea'3\u001aR\u0017{/>\u0005R\u0016.=/N.\u0006c;%\u007f";
      s[213] = "ixm@B\u0005cal\ry\u0013\u000e;z\u001d\u0010\u001a`:k\u0004\u001b\u0002\u000e;j\r\u0016\bqlh\u0017\bC\u000e";
      s[214] = "\r\u000e\r\u0010\u001d5[LE\u0013\u001bWQ[\t\u0015B;c\u000fJJ\u0015o4I\u0019\u0010\u001e<Z\f\u0004\u0005\u001aW";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = s[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(t[var4]);
            s[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = s[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            s[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  s[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1660948757137036L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = s[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  s[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1660948757137036L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        s[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1660948757137036L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 99;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 207;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 239;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 209;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 84;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 162;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 99;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 207;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 239;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d6",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoDrain var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d6;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d6", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoDrain)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoDrain var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d6;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d6", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoDrain)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoDrain var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d6;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d6", "lambda$onTick$2", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoDrain)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoDrain var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d6;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d6", "lambda$onTick$3", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoDrain)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
