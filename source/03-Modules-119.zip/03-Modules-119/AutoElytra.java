package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.KeyInputEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.KeyBindingUtil;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public class AutoElytra extends Module {
   private BooleanSetting d;
   private MinMaxSetting a;
   private BooleanSetting c;
   private BooleanSetting e;
   private FloatSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private MinMaxSetting j;
   private ElapsedTimer k;
   private ElapsedTimer l;
   private ElapsedTimer m;
   private boolean n;
   private boolean o;
   private boolean p;
   private boolean q;
   private int r;
   private int s;
   private int t;
   public static boolean u;
   public static AutoElytra v;
   private static final long w = 28785544097510L;
   private static final long[] x;
   private static final Integer[] y;
   private static final Map z = new HashMap(13);
   private static final Object[] A = new Object[124];
   private static final String[] B = new String[124];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.Mace;
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4, var5);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   public AutoElytra() {
      super();
      long var10001 = 5774595670816L ^ 110269511857161L;
      var10001 = 5774595670816L ^ 106286750341711L;
      var10001 = 5774595670816L ^ 28820607070711L;

      this.k = new ElapsedTimer(106698256430889L);
      this.l = new ElapsedTimer(106698256430889L);
      this.m = new ElapsedTimer(106698256430889L);
      this.r = 0;
      this.s = -1;
      this.t = -1;
      v = this;
      FloatSetting var10000 = this.f;
      Object[] var10 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var9 = var10000;
      var9.aReturningFloatSetting(var10);
      MinMaxSetting var13 = this.j;
      Object[] var12 = new Object[]{invokeBinding2(this), 112057026795887L};
      MinMaxSetting var11 = var13;
      var11.aReturningMinMaxSetting(var12);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      AutoElytra var24;
      label49: {
         int var6;
         byte var25;
         long var2 = (Long)var1[0];
         long var4 = var2 ^ 116087004029242L;
         var6 = Event.bReturningInt();
         BooleanSetting var7 = this.e;
         Boolean var8 = (Boolean)var7.aReturningObject();
         byte var10000 = ((byte)(((java.lang.Boolean)(var8)).booleanValue() ? 1 : 0));
         int var29 = var6;
         byte var28 = var10000;
         var25 = var28;
         byte var21 = var28;
         label32:
         if (var29 == 0) {
            label40: {
               byte var30 = var21;
               if (var30 == 0) {
                  int var32 = var6;
                  AutoElytra var31 = this;
                  var24 = var31;
                  AutoElytra var22 = var31;
                  if (var32 != 0) {
                     break label49;
                  }

                  AutoElytra var33 = var22;
                  AutoElytra var23 = var33;
                  boolean var34 = var23.o;
                  if (var34) {
                     break label40;
                  }

                  this.o = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  Object[] var13 = new Object[]{var4};
                  AutoElytra var12 = this;
                  var12.aReturningVoid(var13);
                  int var35 = var6;
                  if (var35 != 0) {
                     break label40;
                  }
               }

               var25 = ((byte)((this.o) ? 1 : 0));
               break label32;
            }

            AutoElytra var36 = this;
            var24 = var36;
            break label49;
         }

         int var38 = var6;
         byte var37 = var25;
         byte var27 = var37;
         byte var26 = var37;
         if (var38 == 0) {
            byte var39 = var26;
            if (var39 == 0) {
               MinecraftClient var17 = b;
               EquipmentSlot var19 = EquipmentSlot.CHEST;
               ClientPlayerEntity var18 = var17.player;
               ItemStack var20 = var18.getEquippedStack(var19);
               Item var42 = var20.getItem();
               Item var41 = Items.ELYTRA;
               Item var40 = var42;
               if (var40 == var41) {
                  this.o = dev.prestige.recovery.SourceSupport.asBoolean(1);
               }
            }

            var27 = 0;
         }

         u = dev.prestige.recovery.SourceSupport.asBoolean(var27);
         return;
      }

      var24.o = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 98450992130864L;
      long var6 = var2 ^ 13970279202175L;
      int var8 = Event.bReturningInt();
      int var19 = var8;
      byte var18 = ((byte)((this.o) ? 1 : 0));
      byte var17 = var18;
      byte var16 = var18;
      if (var19 == 0) {
         byte var20 = var16;
         if (var20 != 0) {
            return;
         }

         this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.r = 0;
         ElapsedTimer var10000 = this.k;
         Object[] var11 = new Object[]{var6};
         ElapsedTimer var10 = var10000;
         var10.aReturningVoid(var11);
         MinMaxSetting var21 = this.a;
         Object[] var13 = new Object[]{var4};
         MinMaxSetting var12 = var21;
         var12.bReturningVoid(var13);
         var10000 = this.l;
         Object[] var15 = new Object[]{var6};
         ElapsedTimer var14 = var10000;
         var14.aReturningVoid(var15);
         this.s = -1;
         this.t = -1;
         this.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
         var17 = 1;
      }

      u = dev.prestige.recovery.SourceSupport.asBoolean(var17);
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 31369743974346L ^ 121339415299986L;
      var10001 = 31369743974346L ^ 122373805818245L;
      var10001 = 31369743974346L ^ 64263495833546L;
      var10001 = 31369743974346L ^ 96975317700849L;
      var10001 = 31369743974346L ^ 107776188934622L;
      var10001 = 31369743974346L ^ 106424807754262L;
      var10001 = 31369743974346L ^ 54451065108677L;
      var10001 = 31369743974346L ^ 102751606405820L;
      var10001 = 31369743974346L ^ 118297583871409L;
      var10001 = 31369743974346L ^ 52420259087687L;
      var10001 = 31369743974346L ^ 12228562785262L;
      int var26 = Event.bReturningInt();
      int var532 = var26;
      MinecraftClient var531 = b;
      MinecraftClient var389 = var531;
      MinecraftClient var388 = var531;
      if (var532 == 0) {
         MinecraftClient var32 = var388;
         boolean var533 = var32.isWindowFocused();
         if (!var533) {
            return;
         }

         MinecraftClient var534 = b;
         var389 = var534;
      }

      byte var394;
      label614: {
         int var536 = var26;
         MinecraftClient var535 = var389;
         MinecraftClient var393 = var535;
         MinecraftClient var390 = var535;
         if (var536 == 0) {
            MinecraftClient var35 = var390;
            Screen var537 = var35.currentScreen;
            if (var537 != null) {
               MinecraftClient var37 = b;
               byte var10000 = ((byte)((var37.currentScreen instanceof InventoryScreen) ? 1 : 0));
               int var539 = var26;
               byte var538 = var10000;
               var394 = var538;
               byte var391 = var538;
               if (var539 != 0) {
                  break label614;
               }

               byte var540 = var391;
               byte var392 = var540;
               byte var541 = var392;
               if (var541 == 0) {
                  return;
               }
            }

            var393 = b;
         }

         MinecraftClient var40 = var393;
         ClientPlayerEntity var41 = var40.player;
         var394 = ((byte)((var41.isOnGround()) ? 1 : 0));
      }

      int var404;
      int var543 = var26;
      byte var542 = var394;
      var404 = var542;
      byte var395 = var542;
      label601:
      if (var543 == 0) {
         byte var544 = var395;
         if (var544 != 0) {
            int var546 = var26;
            byte var545 = ((byte)((this.o) ? 1 : 0));
            var404 = var545;
            byte var396 = var545;
            if (var546 != 0) {
               break label601;
            }

            byte var547 = var396;
            byte var397 = var547;
            byte var548 = var397;
            if (var548 == 0) {
               int var402;
               BooleanSetting var45 = this.h;
               Boolean var46 = (Boolean)var45.aReturningObject();
               byte var797 = ((byte)(((java.lang.Boolean)(var46)).booleanValue() ? 1 : 0));
               int var550 = var26;
               byte var549 = var797;
               var402 = var549;
               byte var398 = var549;
               label594:
               if (var550 == 0) {
                  byte var551 = var398;
                  byte var399 = var551;
                  byte var552 = var399;
                  if (var552 != 0) {
                     int var554 = var26;
                     int var553 = this.r;
                     var402 = var553;
                     int var400 = var553;
                     if (var554 != 0) {
                        break label594;
                     }

                     int var555 = var400;
                     int var401 = var555;
                     int var556 = var401;
                     if (var556 == 0) {
                        Object[] var51 = new Object[]{136670736201180L};
                        KeyBindingUtil.aReturningVoid(var51);
                     }
                  }

                  this.n = false;
                  ElapsedTimer var798 = this.l;
                  Object[] var54 = new Object[]{42835128969216L};
                  ElapsedTimer var53 = var798;
                  var53.aReturningVoid(var54);
                  this.p = true;
                  var402 = this.r;
               }

               int var558 = var26;
               int var557 = var402;
               var404 = var557;
               int var403 = var557;
               if (var558 != 0) {
                  break label601;
               }

               byte var560 = 3;
               int var559 = var403;
               if (var559 >= var560) {
                  return;
               }
            }
         }

         ElapsedTimer var799 = this.k;
         Object[] var58 = new Object[]{this.a, 130913203968635L};
         ElapsedTimer var57 = var799;
         var404 = (((var57.bReturningBoolean(var58)) ? 1 : 0));
      }

      int var562 = var26;
      int var561 = var404;
      int var406 = var561;
      int var405 = var561;
      if (var562 == 0) {
         int var563 = var405;
         if (var563 == 0) {
            return;
         }

         byte var564 = ((byte)((this.p) ? 1 : 0));
         var406 = var564;
      }

      label581: {
         int var566 = var26;
         int var565 = var406;
         int var408 = var565;
         int var407 = var565;
         if (var566 == 0) {
            int var567 = var407;
            if (var567 != 0) {
               break label581;
            }

            BooleanSetting var62 = this.d;
            Boolean var63 = (Boolean)var62.aReturningObject();
            byte var568 = ((byte)(((java.lang.Boolean)(var63)).booleanValue() ? 1 : 0));
            var408 = var568;
         }

         int var569 = var408;
         if (var569 != 0) {
            return;
         }
      }

      Item var800 = Items.ELYTRA;
      Object[] var10004 = new Object[]{null, null, 75544266747707L};
      var10004[1] = true;
      var10004[0] = var800;
      Object[] var65 = var10004;
      List var27 = InventoryUtil.aReturningList(var65);
      var800 = Items.FIREWORK_ROCKET;
      var10004 = new Object[]{null, null, 75544266747707L};
      var10004[1] = true;
      var10004[0] = var800;
      Object[] var66 = var10004;
      List var28 = InventoryUtil.aReturningList(var66);
      byte var29 = 0;
      int var571 = var26;
      int var570 = this.r;
      int var410 = var570;
      int var409 = var570;
      if (var571 == 0) {
         int var572 = var409;
         if (var572 == 0) {
            MinecraftClient var68 = b;
            EquipmentSlot var70 = EquipmentSlot.CHEST;
            ClientPlayerEntity var69 = var68.player;
            ItemStack var71 = var69.getEquippedStack(var70);
            var800 = var71.getItem();
            Item var574 = Items.ELYTRA;
            Item var573 = var800;
            if (var573 == var574) {
               this.r = 1;
               var29 = 1;
            }
         }

         var410 = this.r;
      }

      int var456;
      label622: {
         int var577 = var26;
         byte var576 = 2;
         int var575 = var410;
         int var454 = var575;
         byte var455 = var576;
         int var411 = var575;
         byte var412 = var576;
         if (var577 == 0) {
            byte var579 = var412;
            int var578 = var411;
            if (var578 < var579) {
               byte var417;
               int var581 = var26;
               byte var580 = var29;
               var417 = var580;
               byte var413 = var580;
               label563:
               if (var581 == 0) {
                  byte var582 = var413;
                  byte var414 = var582;
                  byte var583 = var414;
                  if (var583 == 0) {
                     List var76 = var27;
                     byte var803 = ((byte)((var76.isEmpty()) ? 1 : 0));
                     int var585 = var26;
                     byte var584 = var803;
                     var417 = var584;
                     byte var415 = var584;
                     if (var585 != 0) {
                        break label563;
                     }

                     byte var586 = var415;
                     byte var416 = var586;
                     byte var587 = var416;
                     if (var587 != 0) {
                        Object[] var80 = new Object[]{126290808879192L};
                        AutoElytra var79 = this;
                        var79.aReturningVoid(var80);
                        return;
                     }
                  }

                  BooleanSetting var82 = this.c;
                  Boolean var83 = (Boolean)var82.aReturningObject();
                  var417 = ((byte)(((java.lang.Boolean)(var83)).booleanValue() ? 1 : 0));
               }

               byte var421;
               int var589 = var26;
               byte var588 = var417;
               var421 = var588;
               byte var418 = var588;
               label556:
               if (var589 == 0) {
                  byte var590 = var418;
                  if (var590 != 0) {
                     List var85 = var28;
                     byte var804 = ((byte)((var85.isEmpty()) ? 1 : 0));
                     int var592 = var26;
                     byte var591 = var804;
                     var421 = var591;
                     byte var419 = var591;
                     if (var592 != 0) {
                        break label556;
                     }

                     byte var593 = var419;
                     byte var420 = var593;
                     byte var594 = var420;
                     if (var594 != 0) {
                        Object[] var89 = new Object[]{126290808879192L};
                        AutoElytra var88 = this;
                        var88.aReturningVoid(var89);
                        return;
                     }
                  }

                  var421 = var29;
               }

               int var424;
               label549: {
                  int var596 = var26;
                  byte var595 = var421;
                  byte var423 = var595;
                  byte var422 = var595;
                  if (var596 == 0) {
                     byte var597 = var422;
                     if (var597 == 0) {
                        List var92 = var27;
                        Integer var93 = (Integer)var92.getFirst();
                        var424 = var93;
                        break label549;
                     }

                     var423 = 0;
                  }

                  byte var598 = var423;
                  var424 = var598;
               }

               int var30;
               int var427;
               label543: {
                  var30 = var424;
                  BooleanSetting var94 = this.c;
                  Boolean var805 = (Boolean)var94.aReturningObject();
                  int var600 = var26;
                  Boolean var599 = var805;
                  Object var426 = var599;
                  Boolean var425 = var599;
                  if (var600 == 0) {
                     Boolean var95 = var425;
                     boolean var601 = var95;
                     if (!var601) {
                        byte var602 = 0;
                        var427 = var602;
                        break label543;
                     }

                     List var98 = var28;
                     var426 = var98.getFirst();
                  }

                  Integer var99 = (Integer)var426;
                  var427 = var99;
               }

               AutoElytra var451;
               int var452;
               label657: {
                  AutoElytra var448;
                  int var449;
                  int var31 = var427;
                  BooleanSetting var100 = this.g;
                  Boolean var101 = (Boolean)var100.aReturningObject();
                  byte var860 = ((byte)(((java.lang.Boolean)(var101)).booleanValue() ? 1 : 0));
                  int var605 = var26;
                  byte var604 = var860;
                  AutoElytra var603 = this;
                  var448 = var603;
                  var449 = var604;
                  AutoElytra var428 = var603;
                  byte var429 = var604;
                  label523:
                  if (var605 == 0) {
                     AutoElytra var447;
                     byte var607 = var429;
                     AutoElytra var606 = var428;
                     var447 = var606;
                     AutoElytra var430 = var606;
                     label527:
                     if (var607 == 0) {
                        AutoElytra var450;
                        label532: {
                           AutoElytra var608 = var430;
                           AutoElytra var431 = var608;
                           int var612 = var26;
                           byte var611 = 9;
                           int var610 = var30;
                           AutoElytra var609 = var431;
                           AutoElytra var444 = var609;
                           int var445 = var610;
                           byte var446 = var611;
                           AutoElytra var432 = var609;
                           int var433 = var610;
                           byte var434 = var611;
                           if (var612 == 0) {
                              byte var615 = var434;
                              int var614 = var433;
                              AutoElytra var613 = var432;
                              AutoElytra var435 = var613;
                              int var436 = var614;
                              byte var437 = var615;
                              byte var618 = var437;
                              int var617 = var436;
                              AutoElytra var616 = var435;
                              var450 = var616;
                              AutoElytra var438 = var616;
                              if (var617 >= var618) {
                                 break label532;
                              }

                              AutoElytra var619 = var438;
                              AutoElytra var439 = var619;
                              int var622 = var26;
                              int var621 = var31;
                              AutoElytra var620 = var439;
                              var448 = var620;
                              var449 = var621;
                              AutoElytra var440 = var620;
                              int var441 = var621;
                              if (var622 != 0) {
                                 break label523;
                              }

                              int var624 = var441;
                              AutoElytra var623 = var440;
                              AutoElytra var442 = var623;
                              int var443 = var624;
                              byte var627 = 9;
                              int var626 = var443;
                              AutoElytra var625 = var442;
                              var444 = var625;
                              var445 = var626;
                              var446 = var627;
                           }

                           byte var630 = var446;
                           int var629 = var445;
                           AutoElytra var628 = var444;
                           var450 = var628;
                           var447 = var628;
                           if (var629 < var630) {
                              break label527;
                           }
                        }

                        var452 = 0;
                        var451 = var450;
                        break label657;
                     }

                     var449 = 1;
                     var448 = var447;
                  }

                  int var632 = var449;
                  AutoElytra var631 = var448;
                  var451 = var631;
                  var452 = var632;
               }

               var451.q = dev.prestige.recovery.SourceSupport.asBoolean(var452);
            }

            int var634 = var26;
            int var633 = this.r;
            var456 = var633;
            int var453 = var633;
            if (var634 != 0) {
               break label622;
            }

            byte var636 = 8;
            int var635 = var453;
            var454 = var635;
            var455 = var636;
         }

         byte var638 = var455;
         int var637 = var454;
         if (var637 == var638) {
            MinecraftClient var108 = b;
            EquipmentSlot var110 = EquipmentSlot.CHEST;
            ClientPlayerEntity var109 = var108.player;
            ItemStack var111 = var109.getEquippedStack(var110);
            var800 = var111.getItem();
            Item var640 = Items.ELYTRA;
            Item var639 = var800;
            if (var639 != var640) {
               Object[] var114 = new Object[]{126290808879192L};
               AutoElytra var113 = this;
               var113.aReturningVoid(var114);
               return;
            }
         }

         var456 = this.r;
      }

      label628: {
         label629: {
            label630: {
               label631: {
                  label632: {
                     label506: {
                        label633: {
                           label504: {
                              AutoElytra var461;
                              label634: {
                                 int var642 = var26;
                                 int var641 = var456;
                                 int var460 = var641;
                                 int var457 = var641;
                                 if (var642 == 0) {
                                    int var643 = var457;
                                    switch (var643) {
                                       case 0:
                                       case 5:
                                          int var645 = var26;
                                          AutoElytra var644 = this;
                                          var461 = var644;
                                          AutoElytra var458 = var644;
                                          if (var645 != 0) {
                                             break label634;
                                          }

                                          AutoElytra var646 = var458;
                                          AutoElytra var459 = var646;
                                          byte var647 = ((byte)((var459.q) ? 1 : 0));
                                          var460 = var647;
                                          break;
                                       case 1:
                                          break label504;
                                       case 2:
                                       case 7:
                                          break label633;
                                       case 3:
                                          break label506;
                                       case 4:
                                          break label632;
                                       case 6:
                                          break label631;
                                       case 8:
                                          break label630;
                                       case 9:
                                          break label629;
                                       case 10:
                                          break label628;
                                       default:
                                          return;
                                    }
                                 }

                                 int var648 = var460;
                                 if (var648 == 0) {
                                    MinecraftClient var119;
                                    MinecraftClient var807 = var119 = b;
                                    InventoryScreen var121 = new InventoryScreen(var119.player);
                                    MinecraftClient var120 = var807;
                                    var120.setScreen((Screen)var121);
                                 }

                                 ElapsedTimer var808 = this.k;
                                 Object[] var124 = new Object[]{42835128969216L};
                                 ElapsedTimer var123 = var808;
                                 var123.aReturningVoid(var124);
                                 MinMaxSetting var809 = this.a;
                                 Object[] var126 = new Object[]{127318019014223L};
                                 MinMaxSetting var125 = var809;
                                 var125.bReturningVoid(var126);
                                 var461 = this;
                              }

                              var461.r++;
                              int var649 = var26;
                              if (var649 == 0) {
                                 return;
                              }
                           }

                           int var467;
                           label483: {
                              int var651 = var26;
                              MinecraftClient var650 = b;
                              MinecraftClient var466 = var650;
                              MinecraftClient var462 = var650;
                              if (var651 == 0) {
                                 MinecraftClient var652 = var462;
                                 MinecraftClient var463 = var652;
                                 MinecraftClient var128 = var463;
                                 Screen var653 = var128.currentScreen;
                                 if (var653 == null) {
                                    int var655 = var26;
                                    byte var654 = ((byte)((this.q) ? 1 : 0));
                                    var467 = var654;
                                    byte var464 = var654;
                                    if (var655 != 0) {
                                       break label483;
                                    }

                                    byte var656 = var464;
                                    byte var465 = var656;
                                    byte var657 = var465;
                                    if (var657 == 0) {
                                       this.r = 0;
                                       int var658 = var26;
                                       if (var658 == 0) {
                                          return;
                                       }
                                    }
                                 }

                                 MinecraftClient var659 = b;
                                 var466 = var659;
                              }

                              MinecraftClient var134 = var466;
                              ClientPlayerEntity var135 = var134.player;
                              ScreenHandler var136 = var135.currentScreenHandler;
                              var467 = var136.syncId;
                           }

                           AutoElytra var481;
                           label636: {
                              boolean var474;
                              int var789;
                              label637: {
                                 label638: {
                                    var789 = var467;
                                    int var661 = var26;
                                    List var660 = var27;
                                    List var469 = var660;
                                    List var468 = var660;
                                    if (var661 == 0) {
                                       List var137 = var468;
                                       boolean var662 = var137.isEmpty();
                                       if (!var662) {
                                          int var794;
                                          label468: {
                                             List var139 = var27;
                                             Integer var140 = (Integer)var139.getFirst();
                                             var794 = var140;
                                             int var663 = var26;
                                             if (var663 == 0) {
                                                byte var665 = 9;
                                                int var664 = var794;
                                                if (var664 < var665) {
                                                   Object[] var10003 = new Object[]{null, 72518082610550L};
                                                   var10003[0] = var794;
                                                   Object[] var142 = var10003;
                                                   InventoryUtil.aReturningVoid(var142);
                                                   int var666 = var26;
                                                   if (var666 == 0) {
                                                      break label468;
                                                   }
                                                }

                                                MinecraftClient var144 = b;
                                                boolean var864 = false;
                                                MinecraftClient var145 = b;
                                                ClientPlayerEntity var151 = var145.player;
                                                SlotActionType var150 = SlotActionType.PICKUP;
                                                int var148 = var794;
                                                int var147 = var789;
                                                ClientPlayerInteractionManager var146 = var144.interactionManager;
                                                var146.clickSlot(var147, var148, 0, var150, (PlayerEntity)var151);
                                                MinecraftClient var152 = b;
                                                byte var10002 = 6;
                                                var864 = false;
                                                MinecraftClient var153 = b;
                                                ClientPlayerEntity var159 = var153.player;
                                                SlotActionType var158 = SlotActionType.PICKUP;
                                                int var155 = var789;
                                                ClientPlayerInteractionManager var154 = var152.interactionManager;
                                                var154.clickSlot(var155, 6, 0, var158, (PlayerEntity)var159);
                                             }

                                             MinecraftClient var161 = b;
                                             boolean var866 = false;
                                             MinecraftClient var162 = b;
                                             ClientPlayerEntity var168 = var162.player;
                                             SlotActionType var167 = SlotActionType.PICKUP;
                                             int var165 = var794;
                                             int var164 = var789;
                                             ClientPlayerInteractionManager var163 = var161.interactionManager;
                                             var163.clickSlot(var164, var165, 0, var167, (PlayerEntity)var168);
                                          }

                                          this.t = var794;
                                          int var667 = var26;
                                          if (var667 == 0) {
                                             break label638;
                                          }
                                       }

                                       var800 = Items.NETHERITE_CHESTPLATE;
                                       var10004 = new Object[]{null, null, 75544266747707L};
                                       var10004[1] = true;
                                       var10004[0] = var800;
                                       Object[] var169 = var10004;
                                       List var668 = InventoryUtil.aReturningList(var169);
                                       var469 = var668;
                                    }

                                    List var795 = var469;
                                    List var171 = var795;
                                    boolean var811 = var171.isEmpty();
                                    int var670 = var26;
                                    boolean var669 = var811;
                                    boolean var471 = var669;
                                    boolean var470 = var669;
                                    if (var670 == 0) {
                                       boolean var671 = var470;
                                       if (var671) {
                                          var800 = Items.DIAMOND_CHESTPLATE;
                                          var10004 = new Object[]{null, null, 75544266747707L};
                                          var10004[1] = true;
                                          var10004[0] = var800;
                                          Object[] var173 = var10004;
                                          var795 = InventoryUtil.aReturningList(var173);
                                       }

                                       List var174 = var795;
                                       var471 = var174.isEmpty();
                                    }

                                    int var673 = var26;
                                    boolean var672 = var471;
                                    var474 = var672;
                                    boolean var472 = var672;
                                    if (var673 != 0) {
                                       break label637;
                                    }

                                    boolean var674 = var472;
                                    if (!var674) {
                                       List var176 = var795;
                                       Integer var177 = (Integer)var176.getFirst();
                                       this.t = var177;
                                    }
                                 }

                                 int var676 = var26;
                                 AutoElytra var675 = this;
                                 var481 = var675;
                                 AutoElytra var473 = var675;
                                 if (var676 != 0) {
                                    break label636;
                                 }

                                 BooleanSetting var179 = var473.c;
                                 Boolean var180 = (Boolean)var179.aReturningObject();
                                 boolean var677 = var180;
                                 var474 = var677;
                              }

                              boolean var678 = var474;
                              if (var678) {
                                 int var796;
                                 label451: {
                                    label640: {
                                       List var182 = var28;
                                       Integer var183 = (Integer)var182.getFirst();
                                       var796 = var183;
                                       int var680 = var26;
                                       int var679 = var796;
                                       int var476 = var679;
                                       int var475 = var679;
                                       if (var680 == 0) {
                                          byte var682 = 9;
                                          int var681 = var475;
                                          if (var681 >= var682) {
                                             break label640;
                                          }

                                          List var185 = var27;
                                          byte var683 = ((byte)((var185.isEmpty()) ? 1 : 0));
                                          var476 = var683;
                                       }

                                       int var685 = var26;
                                       int var684 = var476;
                                       int var478 = var684;
                                       int var477 = var684;
                                       if (var685 == 0) {
                                          int var686 = var477;
                                          if (var686 != 0) {
                                             break label451;
                                          }

                                          List var188 = var27;
                                          Integer var189 = (Integer)var188.getFirst();
                                          int var687 = var189;
                                          var478 = var687;
                                       }

                                       int var689 = var26;
                                       int var688 = var478;
                                       int var480 = var688;
                                       int var479 = var688;
                                       if (var689 == 0) {
                                          byte var691 = 9;
                                          int var690 = var479;
                                          if (var690 <= var691) {
                                             break label451;
                                          }

                                          int var692 = var796;
                                          var480 = var692;
                                       }

                                       Object[] var867 = new Object[]{null, 72518082610550L};
                                       var867[0] = var480;
                                       Object[] var193 = var867;
                                       InventoryUtil.aReturningVoid(var193);
                                       int var693 = var26;
                                       if (var693 == 0) {
                                          break label451;
                                       }
                                    }

                                    MinecraftClient var194 = b;
                                    ClientPlayerInteractionManager var813 = var194.interactionManager;
                                    Object[] var195 = new Object[]{49487520630543L};
                                    int var868 = InventoryUtil.aReturningInt(var195);
                                    MinecraftClient var196 = b;
                                    ClientPlayerEntity var202 = var196.player;
                                    SlotActionType var201 = SlotActionType.SWAP;
                                    int var200 = var868;
                                    int var199 = var796;
                                    int var198 = var789;
                                    ClientPlayerInteractionManager var197 = var813;
                                    var197.clickSlot(var198, var199, var200, var201, (PlayerEntity)var202);
                                 }

                                 this.s = var796;
                              }

                              this.r++;
                              ElapsedTimer var814 = this.k;
                              Object[] var205 = new Object[]{42835128969216L};
                              ElapsedTimer var204 = var814;
                              var204.aReturningVoid(var205);
                              var481 = this;
                           }

                           MinMaxSetting var815 = var481.a;
                           Object[] var207 = new Object[]{127318019014223L};
                           MinMaxSetting var206 = var815;
                           var206.bReturningVoid(var207);
                           int var694 = var26;
                           if (var694 == 0) {
                              return;
                           }
                        }

                        Object var209 = null;
                        MinecraftClient var208 = b;
                        var208.setScreen((Screen)var209);
                        this.r++;
                        ElapsedTimer var816 = this.k;
                        Object[] var211 = new Object[]{42835128969216L};
                        ElapsedTimer var210 = var816;
                        var210.aReturningVoid(var211);
                        MinMaxSetting var817 = this.a;
                        Object[] var213 = new Object[]{127318019014223L};
                        MinMaxSetting var212 = var817;
                        var212.bReturningVoid(var213);
                        int var695 = var26;
                        if (var695 == 0) {
                           return;
                        }
                     }

                     int var697 = var26;
                     MinecraftClient var696 = b;
                     MinecraftClient var484 = var696;
                     MinecraftClient var482 = var696;
                     if (var697 == 0) {
                        MinecraftClient var698 = var482;
                        MinecraftClient var483 = var698;
                        MinecraftClient var216 = var483;
                        Screen var699 = var216.currentScreen;
                        if (var699 != null) {
                           return;
                        }

                        var484 = b;
                     }

                     MinecraftClient var219 = var484;
                     int var701 = var26;
                     ClientPlayerEntity var700 = var219.player;
                     ClientPlayerEntity var489 = var700;
                     ClientPlayerEntity var485 = var700;
                     if (var701 == 0) {
                        EquipmentSlot var221 = EquipmentSlot.CHEST;
                        ClientPlayerEntity var220 = var485;
                        ItemStack var222 = var220.getEquippedStack(var221);
                        var800 = var222.getItem();
                        Item var703 = Items.ELYTRA;
                        Item var702 = var800;
                        if (var702 != var703) {
                           MinecraftClient var224 = b;
                           ClientPlayerEntity var225 = var224.player;
                           ItemStack var846 = var225.getMainHandStack();
                           Item var227 = Items.ELYTRA;
                           ItemStack var226 = var846;
                           boolean var847 = var226.isOf(var227);
                           int var705 = var26;
                           boolean var704 = var847;
                           boolean var486 = var704;
                           if (var705 == 0) {
                              boolean var706 = var486;
                              boolean var487 = var706;
                              boolean var707 = var487;
                              if (var707) {
                                 Object[] var230 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
                                 boolean var708 = ItemUseUtil.cReturningBoolean(var230);
                              }
                           }

                           ElapsedTimer var848 = this.k;
                           Object[] var233 = new Object[]{42835128969216L};
                           ElapsedTimer var232 = var848;
                           var232.aReturningVoid(var233);
                           MinMaxSetting var849 = this.a;
                           Object[] var235 = new Object[]{127318019014223L};
                           MinMaxSetting var234 = var849;
                           var234.bReturningVoid(var235);
                           return;
                        }

                        MinecraftClient var236 = b;
                        var489 = var236.player;
                     }

                     int var710 = var26;
                     ClientPlayerEntity var709 = var489;
                     ClientPlayerEntity var491 = var709;
                     ClientPlayerEntity var490 = var709;
                     if (var710 == 0) {
                        ClientPlayerEntity var237 = var490;
                        boolean var711 = var237.isOnGround();
                        if (var711) {
                           return;
                        }

                        MinecraftClient var240 = b;
                        var491 = var240.player;
                     }

                     ClientPlayerEntity var241 = var491;
                     ClientPlayNetworkHandler var819 = var241.networkHandler;
                     MinecraftClient var242 = b;
                     ClientCommandC2SPacket var244 = new ClientCommandC2SPacket(var242.player, Mode.START_FALL_FLYING);
                     ClientPlayNetworkHandler var243 = var819;
                     var243.sendPacket((Packet)var244);
                     Object[] var245 = new Object[]{25945785642020L};
                     ItemUseUtil.bReturningVoid(var245);
                     this.n = true;
                     ElapsedTimer var820 = this.l;
                     Object[] var247 = new Object[]{42835128969216L};
                     ElapsedTimer var246 = var820;
                     var246.aReturningVoid(var247);
                     this.r++;
                     ElapsedTimer var821 = this.k;
                     Object[] var249 = new Object[]{42835128969216L};
                     ElapsedTimer var248 = var821;
                     var248.aReturningVoid(var249);
                     MinMaxSetting var822 = this.a;
                     Object[] var251 = new Object[]{127318019014223L};
                     MinMaxSetting var250 = var822;
                     var250.bReturningVoid(var251);
                     int var712 = var26;
                     if (var712 == 0) {
                        return;
                     }
                  }

                  int var714 = var26;
                  AutoElytra var713 = this;
                  AutoElytra var500 = var713;
                  AutoElytra var492 = var713;
                  if (var714 == 0) {
                     AutoElytra var715 = var492;
                     AutoElytra var493 = var715;
                     BooleanSetting var253 = var493.c;
                     Boolean var254 = (Boolean)var253.aReturningObject();
                     boolean var716 = var254;
                     if (var716) {
                        MinecraftClient var256 = b;
                        ClientPlayerEntity var257 = var256.player;
                        ItemStack var823 = var257.getMainHandStack();
                        Item var259 = Items.FIREWORK_ROCKET;
                        ItemStack var258 = var823;
                        boolean var824 = var258.isOf(var259);
                        int var718 = var26;
                        boolean var717 = var824;
                        boolean var494 = var717;
                        if (var718 == 0) {
                           boolean var719 = var494;
                           boolean var495 = var719;
                           boolean var720 = var495;
                           if (!var720) {
                              List var262 = var28;
                              byte var843 = ((byte)((var262.isEmpty()) ? 1 : 0));
                              int var722 = var26;
                              byte var721 = var843;
                              int var498 = var721;
                              byte var496 = var721;
                              if (var722 == 0) {
                                 byte var723 = var496;
                                 byte var497 = var723;
                                 byte var724 = var497;
                                 if (var724 != 0) {
                                    return;
                                 }

                                 List var265 = var28;
                                 Integer var266 = (Integer)var265.getFirst();
                                 var498 = var266;
                              }

                              int var793 = var498;
                              Object[] var875 = new Object[]{null, 72518082610550L};
                              var875[0] = var793;
                              Object[] var267 = var875;
                              InventoryUtil.aReturningVoid(var267);
                              ElapsedTimer var844 = this.k;
                              Object[] var269 = new Object[]{42835128969216L};
                              ElapsedTimer var268 = var844;
                              var268.aReturningVoid(var269);
                              MinMaxSetting var845 = this.a;
                              Object[] var271 = new Object[]{127318019014223L};
                              MinMaxSetting var270 = var845;
                              var270.bReturningVoid(var271);
                              return;
                           }

                           Object[] var272 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
                           boolean var499 = ItemUseUtil.cReturningBoolean(var272);
                        }

                        ElapsedTimer var825 = this.k;
                        Object[] var274 = new Object[]{42835128969216L};
                        ElapsedTimer var273 = var825;
                        var273.aReturningVoid(var274);
                        MinMaxSetting var826 = this.a;
                        Object[] var276 = new Object[]{127318019014223L};
                        MinMaxSetting var275 = var826;
                        var275.bReturningVoid(var276);
                     }

                     var500 = this;
                  }

                  var500.r++;
                  int var725 = var26;
                  if (var725 == 0) {
                     return;
                  }
               }

               AutoElytra var512;
               label641: {
                  boolean var508;
                  label426: {
                     MinecraftClient var277 = b;
                     int var727 = var26;
                     Screen var726 = var277.currentScreen;
                     Object var507 = var726;
                     Screen var501 = var726;
                     if (var727 == 0) {
                        Screen var728 = var501;
                        Screen var502 = var728;
                        Screen var729 = var502;
                        if (var729 == null) {
                           int var731 = var26;
                           boolean var730 = this.q;
                           var508 = var730;
                           boolean var503 = var730;
                           if (var731 != 0) {
                              break label426;
                           }

                           boolean var732 = var503;
                           boolean var504 = var732;
                           boolean var733 = var504;
                           if (!var733) {
                              this.r = 5;
                              int var734 = var26;
                              if (var734 == 0) {
                                 return;
                              }
                           }
                        }

                        int var736 = var26;
                        AutoElytra var735 = this;
                        var512 = var735;
                        AutoElytra var505 = var735;
                        if (var736 != 0) {
                           break label641;
                        }

                        AutoElytra var737 = var505;
                        AutoElytra var506 = var737;
                        BooleanSetting var284 = var506.c;
                        Object var738 = var284.aReturningObject();
                        var507 = var738;
                     }

                     Boolean var286 = (Boolean)var507;
                     var508 = var286;
                  }

                  boolean var739 = var508;
                  if (var739) {
                     label416: {
                        int var741 = var26;
                        int var740 = this.s;
                        int var511 = var740;
                        int var509 = var740;
                        if (var741 == 0) {
                           int var742 = var509;
                           int var510 = var742;
                           byte var744 = 9;
                           int var743 = var510;
                           if (var743 < var744) {
                              int var827 = this.s;
                              Object[] var869 = new Object[]{null, 72518082610550L};
                              var869[0] = var827;
                              Object[] var289 = var869;
                              InventoryUtil.aReturningVoid(var289);
                              int var745 = var26;
                              if (var745 == 0) {
                                 break label416;
                              }
                           }

                           MinecraftClient var291 = b;
                           ClientPlayerEntity var292 = var291.player;
                           ScreenHandler var293 = var292.currentScreenHandler;
                           int var746 = var293.syncId;
                           var511 = var746;
                        }

                        int var790 = var511;
                        MinecraftClient var295 = b;
                        ClientPlayerInteractionManager var828 = var295.interactionManager;
                        int var862 = this.s;
                        Object[] var296 = new Object[]{49487520630543L};
                        int var870 = InventoryUtil.aReturningInt(var296);
                        MinecraftClient var297 = b;
                        ClientPlayerEntity var303 = var297.player;
                        SlotActionType var302 = SlotActionType.SWAP;
                        int var301 = var870;
                        int var300 = var862;
                        int var299 = var790;
                        ClientPlayerInteractionManager var298 = var828;
                        var298.clickSlot(var299, var300, var301, var302, (PlayerEntity)var303);
                     }

                     ElapsedTimer var829 = this.k;
                     Object[] var305 = new Object[]{42835128969216L};
                     ElapsedTimer var304 = var829;
                     var304.aReturningVoid(var305);
                     MinMaxSetting var830 = this.a;
                     Object[] var307 = new Object[]{127318019014223L};
                     MinMaxSetting var306 = var830;
                     var306.bReturningVoid(var307);
                  }

                  var512 = this;
               }

               var512.r++;
               int var747 = var26;
               if (var747 == 0) {
                  return;
               }
            }

            AutoElytra var521;
            label643: {
               boolean var520;
               label644: {
                  label645: {
                     BooleanSetting var308 = this.e;
                     Boolean var309 = (Boolean)var308.aReturningObject();
                     boolean var831 = var309;
                     int var749 = var26;
                     boolean var748 = var831;
                     boolean var517 = var748;
                     boolean var513 = var748;
                     if (var749 == 0) {
                        boolean var750 = var513;
                        boolean var514 = var750;
                        boolean var751 = var514;
                        if (var751) {
                           ElapsedTimer var832 = this.l;
                           FloatSetting var312 = this.f;
                           Float var313 = (Float)var312.aReturningObject();
                           float var861 = var313;
                           var10004 = new Object[]{null, 139098136696340L};
                           var10004[0] = var861;
                           Object[] var315 = var10004;
                           ElapsedTimer var314 = var832;
                           boolean var833 = var314.aReturningBoolean(var315);
                           int var753 = var26;
                           boolean var752 = var833;
                           var520 = var752;
                           boolean var515 = var752;
                           if (var753 != 0) {
                              break label644;
                           }

                           boolean var754 = var515;
                           boolean var516 = var754;
                           boolean var755 = var516;
                           if (!var755) {
                              return;
                           }
                           break label645;
                        }

                        var517 = this.o;
                     }

                     int var757 = var26;
                     boolean var756 = var517;
                     var520 = var756;
                     boolean var518 = var756;
                     if (var757 != 0) {
                        break label644;
                     }

                     boolean var758 = var518;
                     if (!var758) {
                        return;
                     }
                  }

                  int var760 = var26;
                  AutoElytra var759 = this;
                  var521 = var759;
                  AutoElytra var519 = var759;
                  if (var760 != 0) {
                     break label643;
                  }

                  boolean var761 = var519.q;
                  var520 = var761;
               }

               boolean var762 = var520;
               if (!var762) {
                  MinecraftClient var320;
                  MinecraftClient var834 = var320 = b;
                  InventoryScreen var322 = new InventoryScreen(var320.player);
                  MinecraftClient var321 = var834;
                  var321.setScreen((Screen)var322);
               }

               ElapsedTimer var835 = this.k;
               Object[] var325 = new Object[]{42835128969216L};
               ElapsedTimer var324 = var835;
               var324.aReturningVoid(var325);
               MinMaxSetting var836 = this.a;
               Object[] var327 = new Object[]{127318019014223L};
               MinMaxSetting var326 = var836;
               var326.bReturningVoid(var327);
               var521 = this;
            }

            var521.r++;
            int var763 = var26;
            if (var763 == 0) {
               return;
            }
         }

         int var524;
         label388: {
            MinecraftClient var328 = b;
            Screen var764 = var328.currentScreen;
            if (var764 == null) {
               int var766 = var26;
               byte var765 = ((byte)((this.q) ? 1 : 0));
               var524 = var765;
               byte var522 = var765;
               if (var766 != 0) {
                  break label388;
               }

               byte var767 = var522;
               byte var523 = var767;
               byte var768 = var523;
               if (var768 == 0) {
                  this.r = 8;
                  int var769 = var26;
                  if (var769 == 0) {
                     return;
                  }
               }
            }

            int var770 = this.t;
            var524 = var770;
         }

         label382: {
            int var530;
            label646: {
               int var773 = var26;
               // int var771 = var524;
               int var528 = var771;
               byte var529 = var772;
               int var525 = var771;
               byte var526 = var772;
               if (var773 == 0) {
                  byte var775 = var526;
                  int var774 = var525;
                  if (var774 == var775) {
                     List var791;
                     label376: {
                        var800 = Items.AIR;
                        var10004 = new Object[]{null, null, 75544266747707L};
                        var10004[1] = false;
                        var10004[0] = var800;
                        Object[] var335 = var10004;
                        var791 = InventoryUtil.aReturningList(var335);
                        int var776 = var26;
                        if (var776 == 0) {
                           List var336 = var791;
                           boolean var777 = var336.isEmpty();
                           if (!var777) {
                              break label376;
                           }

                           this.r++;
                           ElapsedTimer var838 = this.k;
                           Object[] var339 = new Object[]{42835128969216L};
                           ElapsedTimer var338 = var838;
                           var338.aReturningVoid(var339);
                           MinMaxSetting var839 = this.a;
                           Object[] var341 = new Object[]{127318019014223L};
                           MinMaxSetting var340 = var839;
                           var340.bReturningVoid(var341);
                        }

                        int var778 = var26;
                        if (var778 == 0) {
                           return;
                        }
                     }

                     List var343 = var791;
                     Integer var344 = (Integer)var343.getFirst();
                     this.t = var344;
                  }

                  int var780 = var26;
                  int var779 = this.t;
                  var530 = var779;
                  int var527 = var779;
                  if (var780 != 0) {
                     break label646;
                  }

                  byte var782 = 9;
                  int var781 = var527;
                  var528 = var781;
                  var529 = var782;
               }

               byte var784 = var529;
               int var783 = var528;
               if (var783 < var784) {
                  int var840 = this.t;
                  Object[] var871 = new Object[]{null, 72518082610550L};
                  var871[0] = var840;
                  Object[] var347 = var871;
                  InventoryUtil.aReturningVoid(var347);
                  Object[] var348 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
                  ItemUseUtil.cReturningBoolean(var348);
                  int var785 = var26;
                  if (var785 == 0) {
                     break label382;
                  }
               }

               MinecraftClient var350 = b;
               ClientPlayerEntity var351 = var350.player;
               ScreenHandler var352 = var351.currentScreenHandler;
               int var786 = var352.syncId;
               var530 = var786;
            }

            int var792 = var530;
            MinecraftClient var354 = b;
            boolean var872 = false;
            MinecraftClient var355 = b;
            ClientPlayerEntity var361 = var355.player;
            SlotActionType var360 = SlotActionType.PICKUP;
            int var358 = this.t;
            int var357 = var792;
            ClientPlayerInteractionManager var356 = var354.interactionManager;
            var356.clickSlot(var357, var358, 0, var360, (PlayerEntity)var361);
            MinecraftClient var362 = b;
            byte var863 = 6;
            var872 = false;
            MinecraftClient var363 = b;
            ClientPlayerEntity var369 = var363.player;
            SlotActionType var368 = SlotActionType.PICKUP;
            int var365 = var792;
            ClientPlayerInteractionManager var364 = var362.interactionManager;
            var364.clickSlot(var365, 6, 0, var368, (PlayerEntity)var369);
            MinecraftClient var370 = b;
            var872 = false;
            MinecraftClient var371 = b;
            ClientPlayerEntity var377 = var371.player;
            SlotActionType var376 = SlotActionType.PICKUP;
            int var374 = this.t;
            int var373 = var792;
            ClientPlayerInteractionManager var372 = var370.interactionManager;
            var372.clickSlot(var373, var374, 0, var376, (PlayerEntity)var377);
         }

         this.r++;
         ElapsedTimer var841 = this.k;
         Object[] var379 = new Object[]{42835128969216L};
         ElapsedTimer var378 = var841;
         var378.aReturningVoid(var379);
         MinMaxSetting var842 = this.a;
         Object[] var381 = new Object[]{127318019014223L};
         MinMaxSetting var380 = var842;
         var380.bReturningVoid(var381);
         int var787 = var26;
         if (var787 == 0) {
            return;
         }
      }

      Object var383 = null;
      MinecraftClient var382 = b;
      var382.setScreen((Screen)var383);
      MinecraftClient var384 = b;
      Screen var788 = var384.currentScreen;
      if (var788 == null) {
         Object[] var387 = new Object[]{126290808879192L};
         AutoElytra var386 = this;
         var386.aReturningVoid(var387);
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      int var4 = Event.bReturningInt();
      boolean var17 = this.n;
      if (var17) {
         Object[] var9 = new Object[0];
         PacketSendEvent var8 = var1;
         Packet var6 = var8.aReturningVoid(var9);
         int var19 = var4;
         Packet var18 = var6;
         Packet var16 = var18;
         Packet var15 = var18;
         if (var19 == 0) {
            boolean var20 = var15 instanceof ClientCommandC2SPacket;
            if (!var20) {
               return;
            }

            Packet var21 = var6;
            var16 = var21;
         }

         ClientCommandC2SPacket var5 = (ClientCommandC2SPacket)var16;
         ClientCommandC2SPacket var12 = var5;
         Mode var10000 = var12.getMode();
         Mode var23 = Mode.START_FALL_FLYING;
         Mode var22 = var10000;
         if (var22 == var23) {
            Object[] var14 = new Object[0];
            PacketSendEvent var13 = var1;
            var13.aReturningVoid(var14);
         }
      }
   }

   @EventListener
   public void a(KeyInputEvent var1) {
      long var10001 = 45195262624281L ^ 63521215579202L;
      var10001 = 45195262624281L ^ 51287520822250L;
      var10001 = 45195262624281L ^ 99855285943382L;
      var10001 = 45195262624281L ^ 17521372981785L;
      var10001 = 45195262624281L ^ 116388415687490L;
      var10001 = 45195262624281L ^ 103398327703650L;
      var10001 = 45195262624281L ^ 28793646168212L;
      int var18 = Event.bReturningInt();
      BooleanSetting var20 = this.i;
      Boolean var21 = (Boolean)var20.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var21)).booleanValue() ? 1 : 0));
      int var102 = var18;
      byte var101 = (byte)var10000;
      int var70 = var101;
      byte var69 = var101;
      if (var102 == 0) {
         byte var103 = var69;
         if (var103 == 0) {
            return;
         }

         Object[] var24 = new Object[0];
         KeyInputEvent var23 = var1;
         var70 = var23.dReturningInt(var24);
      }

      int var106 = var18;
      byte var105 = 1;
      int var104 = var70;
      int var73 = var104;
      byte var74 = var105;
      int var71 = var104;
      byte var72 = var105;
      if (var106 == 0) {
         byte var108 = var72;
         int var107 = var71;
         if (var107 != var108) {
            return;
         }

         Object[] var27 = new Object[0];
         KeyInputEvent var26 = var1;
         var10000 = var26.aReturningInt(var27);
         var74 = 32;
         var73 = var10000;
      }

      byte var110 = var74;
      int var109 = var73;
      if (var109 == var110) {
         int var112 = var18;
         MinecraftClient var111 = b;
         MinecraftClient var76 = var111;
         MinecraftClient var75 = var111;
         if (var112 == 0) {
            MinecraftClient var28 = var75;
            ClientPlayerEntity var113 = var28.player;
            if (var113 == null) {
               return;
            }

            MinecraftClient var114 = b;
            var76 = var114;
         }

         int var116 = var18;
         MinecraftClient var115 = var76;
         MinecraftClient var78 = var115;
         MinecraftClient var77 = var115;
         if (var116 == 0) {
            MinecraftClient var31 = var77;
            ClientWorld var117 = var31.world;
            if (var117 == null) {
               return;
            }

            var78 = b;
         }

         int var119 = var18;
         MinecraftClient var118 = var78;
         MinecraftClient var80 = var118;
         MinecraftClient var79 = var118;
         if (var119 == 0) {
            MinecraftClient var34 = var79;
            Screen var120 = var34.currentScreen;
            if (var120 != null) {
               return;
            }

            var80 = b;
         }

         MinecraftClient var37 = var80;
         byte var156 = ((byte)((var37.isWindowFocused()) ? 1 : 0));
         int var122 = var18;
         byte var121 = var156;
         byte var82 = var121;
         byte var81 = var121;
         if (var122 == 0) {
            byte var123 = var81;
            if (var123 == 0) {
               return;
            }

            Object[] var39 = new Object[]{18551992649307L};
            var82 = ((byte)((RaycastUtil.aReturningBoolean(var39)) ? 1 : 0));
         }

         int var125 = var18;
         byte var124 = var82;
         byte var84 = var124;
         byte var83 = var124;
         if (var125 == 0) {
            byte var126 = var83;
            if (var126 == 0) {
               return;
            }

            var84 = ((byte)((u) ? 1 : 0));
         }

         int var94;
         int var128 = var18;
         byte var127 = var84;
         var94 = var127;
         byte var85 = var127;
         label118:
         if (var128 == 0) {
            byte var129 = var85;
            if (var129 != 0) {
               int var132 = var18;
               byte var131 = 4;
               int var130 = this.r;
               int var92 = var130;
               byte var93 = var131;
               int var86 = var130;
               byte var87 = var131;
               if (var132 == 0) {
                  byte var134 = var87;
                  int var133 = var86;
                  int var88 = var133;
                  byte var89 = var134;
                  byte var136 = var89;
                  int var135 = var88;
                  if (var135 < var136) {
                     return;
                  }

                  int var138 = var18;
                  int var137 = this.r;
                  var94 = var137;
                  int var90 = var137;
                  if (var138 != 0) {
                     break label118;
                  }

                  int var139 = var90;
                  int var91 = var139;
                  byte var141 = 8;
                  int var140 = var91;
                  var92 = var140;
                  var93 = var141;
               }

               byte var143 = var93;
               int var142 = var92;
               if (var142 > var143) {
                  return;
               }
            }

            ElapsedTimer var157 = this.m;
            Object[] var47 = new Object[]{this.j, 130913203968635L};
            ElapsedTimer var46 = var157;
            var94 = (((var46.bReturningBoolean(var47)) ? 1 : 0));
         }

         int var145 = var18;
         int var144 = var94;
         int var96 = var144;
         int var95 = var144;
         if (var145 == 0) {
            int var146 = var95;
            if (var146 == 0) {
               return;
            }

            RotationManager var158 = Prestige.o;
            Object[] var50 = new Object[0];
            RotationManager var49 = var158;
            var96 = (((var49.fReturningBoolean(var50)) ? 1 : 0));
         }

         int var148 = var18;
         int var147 = var96;
         int var98 = var147;
         int var97 = var147;
         if (var148 == 0) {
            int var149 = var97;
            if (var149 != 0) {
               return;
            }

            Object[] var52 = new Object[]{Items.FIREWORK_ROCKET, 8519502184947L};
            var98 = (((InventoryUtil.lReturningBoolean(var52)) ? 1 : 0));
         }

         int var151 = var18;
         int var150 = var98;
         int var100 = var150;
         int var99 = var150;
         if (var151 == 0) {
            int var152 = var99;
            if (var152 != 0) {
               Object[] var54 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
               ItemUseUtil.cReturningBoolean(var54);
               RotationManager var163 = Prestige.o;
               Object[] var56 = new Object[]{true};
               RotationManager var55 = var163;
               var55.fReturningVoid(var56);
               ElapsedTimer var164 = this.m;
               Object[] var58 = new Object[]{42835128969216L};
               ElapsedTimer var57 = var164;
               var57.aReturningVoid(var58);
               MinMaxSetting var165 = this.j;
               Object[] var60 = new Object[]{127318019014223L};
               MinMaxSetting var59 = var165;
               var59.bReturningVoid(var60);
               return;
            }

            var100 = 1;
         }

         boolean[] var159 = new boolean[var100];
         var159[0] = dev.prestige.recovery.SourceSupport.asBoolean(0);
         boolean[] var19 = var159;
         Item var160 = Items.FIREWORK_ROCKET;
         Runnable var172 = invokeBinding3(var19);
         Object[] var10005 = new Object[]{null, null, null, 71193876973915L};
         var10005[2] = true;
         var10005[1] = var172;
         var10005[0] = var160;
         Object[] var62 = var10005;
         InventoryUtil.jReturningBoolean(var62);
         int var153 = var18;
         if (var153 == 0) {
            boolean var154 = var19[0];
            if (!var154) {
               return;
            }

            ElapsedTimer var161 = this.m;
            Object[] var65 = new Object[]{42835128969216L};
            ElapsedTimer var64 = var161;
            var64.aReturningVoid(var65);
         }

         MinMaxSetting var162 = this.j;
         Object[] var68 = new Object[]{127318019014223L};
         MinMaxSetting var67 = var162;
         var67.bReturningVoid(var68);
      }
   }

   private static void lambda$onKey$2(boolean[] var0) {
      long var10001 = 131936720155567L ^ 75678226073890L;
      int var5 = Event.bReturningInt();
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      ItemStack var10000 = var7.getMainHandStack();
      Item var9 = Items.FIREWORK_ROCKET;
      ItemStack var8 = var10000;
      boolean var21 = var8.isOf(var9);
      int var18 = var5;
      boolean var17 = var21;
      boolean var15 = var17;
      if (var18 == 0) {
         boolean var19 = var15;
         if (!var19) {
            return;
         }

         Object[] var11 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
         boolean var20 = ItemUseUtil.cReturningBoolean(var11);
      }

      RotationManager var22 = Prestige.o;
      Object[] var14 = new Object[]{true};
      RotationManager var13 = var22;
      var13.fReturningVoid(var14);
      var0[0] = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   private boolean lambda$new$1(Float var1) {
      BooleanSetting var4 = this.i;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(86102706255771L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[8];
      String var6 = "ÑÃ¢ÐgRGåü7Ë:¸ y(âr¦ w¿ØJ\u0095+\u0083<g¿ÆLm\"\b\u00848ØóS¹\u001d\u008btÔª\u0080\u0091";
      int var7 = "ÑÃ¢ÐgRGåü7Ë:¸ y(âr¦ w¿ØJ\u0095+\u0083<g¿ÆLm\"\b\u00848ØóS¹\u001d\u008btÔª\u0080\u0091".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     x = var8;
                     y = new Integer[8];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "»dê\u0081Bq\u0083GVHkÃo\u009a6\u0098";
                  var7 = "»dê\u0081Bq\u0083GVHkÃo\u009a6\u0098".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29654;
      if (y[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = x[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])z.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               z.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d7", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         y[var3] = var15;
      }

      return y[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d7",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = B[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = A[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 61;
            yield var15;
         }
         case 1 -> {
            byte var16 = 13;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 31;
            yield var18;
         }
         case 4 -> {
            byte var19 = 52;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 34;
            yield var21;
         }
         case 7 -> {
            byte var22 = 15;
            yield var22;
         }
         case 8 -> {
            byte var23 = 44;
            yield var23;
         }
         case 9 -> {
            byte var24 = 50;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 35;
            yield var26;
         }
         case 12 -> {
            byte var27 = 9;
            yield var27;
         }
         case 13 -> {
            byte var28 = 48;
            yield var28;
         }
         case 14 -> {
            byte var29 = 5;
            yield var29;
         }
         case 15 -> {
            byte var30 = 56;
            yield var30;
         }
         case 16 -> {
            byte var31 = 11;
            yield var31;
         }
         case 17 -> {
            byte var32 = 27;
            yield var32;
         }
         case 18 -> {
            byte var33 = 24;
            yield var33;
         }
         case 19 -> {
            byte var34 = 7;
            yield var34;
         }
         case 20 -> {
            byte var35 = 19;
            yield var35;
         }
         case 21 -> {
            byte var36 = 10;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 30;
            yield var38;
         }
         case 24 -> {
            byte var39 = 16;
            yield var39;
         }
         case 25 -> {
            byte var40 = 14;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 0;
            yield var42;
         }
         case 28 -> {
            byte var43 = 63;
            yield var43;
         }
         case 29 -> {
            byte var44 = 51;
            yield var44;
         }
         case 30 -> {
            byte var45 = 59;
            yield var45;
         }
         case 31 -> {
            byte var46 = 37;
            yield var46;
         }
         case 32 -> {
            byte var47 = 8;
            yield var47;
         }
         case 33 -> {
            byte var48 = 46;
            yield var48;
         }
         case 34 -> {
            byte var49 = 38;
            yield var49;
         }
         case 35 -> {
            byte var50 = 62;
            yield var50;
         }
         case 36 -> {
            byte var51 = 47;
            yield var51;
         }
         case 37 -> {
            byte var52 = 54;
            yield var52;
         }
         case 38 -> {
            byte var53 = 20;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 42;
            yield var56;
         }
         case 42 -> {
            byte var57 = 55;
            yield var57;
         }
         case 43 -> {
            byte var58 = 39;
            yield var58;
         }
         case 44 -> {
            byte var59 = 2;
            yield var59;
         }
         case 45 -> {
            byte var60 = 32;
            yield var60;
         }
         case 46 -> {
            byte var61 = 33;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 60;
            yield var63;
         }
         case 49 -> {
            byte var64 = 58;
            yield var64;
         }
         case 50 -> {
            byte var65 = 18;
            yield var65;
         }
         case 51 -> {
            byte var66 = 28;
            yield var66;
         }
         case 52 -> {
            byte var67 = 6;
            yield var67;
         }
         case 53 -> {
            byte var68 = 36;
            yield var68;
         }
         case 54 -> {
            byte var69 = 53;
            yield var69;
         }
         case 55 -> {
            byte var70 = 1;
            yield var70;
         }
         case 56 -> {
            byte var71 = 17;
            yield var71;
         }
         case 57 -> {
            byte var72 = 3;
            yield var72;
         }
         case 58 -> {
            byte var73 = 49;
            yield var73;
         }
         case 59 -> {
            byte var74 = 22;
            yield var74;
         }
         case 60 -> {
            byte var75 = 4;
            yield var75;
         }
         case 61 -> {
            byte var76 = 23;
            yield var76;
         }
         case 62 -> {
            byte var77 = 41;
            yield var77;
         }
         default -> 43;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            B[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      A[0] = "l(%]#Tz( \u00070Cmc#\u0001<W|$4\u0016w@D";
      A[1] = "m\u0007\u0004B\u001f\t\u0018'\u000fM\u000eFy)\u0004F\n\u001c\r";
      A[2] = void.class;
      B[2] = "java/lang/Void";
      A[3] = "\u0000\u00180\u0011[ \u0016\u00185KH7\u0001S6MD#\u0010\u0014!Z\u000f1!";
      A[4] = int.class;
      B[4] = "java/lang/Integer";
      A[5] = "^=xC\u0012XH=}\u0019\u0001O_v~\u001f\r[N1i\bFNc";
      A[6] = "KZ<7a3>z78p|_t<3t&+";
      A[7] = "\\1>K\u0001^J1;\u0011\u0012I]z8\u0017\u001e]L=/\u0000UJ\u000f";
      A[8] = "\bYnU\u001b\u0000\u0003V\u007f\u001ax\r\u0016[pqM\u000f\u0007Hl]Z\u0002";
      A[9] = "\u001c\frh'\u001f\n\fw24\b\u001dGt48\u001c\f\u0000c#s\u000b2";
      A[10] = "%r\u000bAN\u0018PR\u0000N_W1\\\u000bE[\rE";
      A[11] = "v<\u0005`m\\\u0003\u001c\u000eo|\u0013b\u0012\u0005dxI\u0016";
      A[12] = "\u0018\u0014\"*y\u000f\u0018\u00145vu\u0000\u0002_5hu\u0015\u0005.g<$T";
      A[13] = "\u0013oM#hU\u0013oZ\u007fdZ\t$ZadO\u000eU\b:<\u000e";
      A[14] = "X\u007f\u0012\u0014\f~X\u007f\u0005H\u0000qB4\u0005V\u0000dEEW\rX.";
      A[15] = "CbJ?@\"Cb]cL-Y)]}L8^X\t%\u001b";
      A[16] = "\u000fKvGnL\u000fKa\u001bbC\u0015\u0000a\u0005bV\u0012q3Z3\u0011";
      A[17] = "m\u000bPe3\u0012f\u0004A*_\u0011h\u0006Ces";
      A[18] = boolean.class;
      B[18] = "java/lang/Boolean";
      A[19] = "K~'-%-]~\"w6:J5!q:.[r6fq9~";
      A[20] = "z\"KS\u001f\u0017\u000f\u0002@\\\u000eXn\fKW\n\u0002\u001a";
      A[21] = ">;9\ng\u000f(;<Pt\u0018?p?Vx\f.7(A3\u001b\u001c";
      A[22] = "\u001d\u000b]'jF\u0016\u0004Lh\u000bH\u001d\u000fH2";
      A[23] = "x;\u0019uAcx;\u000e)Mlbp\u000e7Mye\u0001^j\u001c";
      A[24] = "9QhK\u0017\u001d/Qm\u0011\u0004\n8\u001an\u0017\b\u001e)]y\u0000C\fj";
      A[25] = "\f|4\u0016o(y\\?\u0019~g\u0018R4\u0012z=l";
      A[26] = "N\u0016\u001eS0\u0017X\u0016\u001b\t#\u0000O]\u0018\u000f/\u0014^\u001a\u000f\u0018d\u0004E";
      A[27] = "6lG+\bICLL$\u0019\u0006\"BG/\u001d\\V";
      A[28] = "RP30;0RP$l7?H\u001b$r7*Ojs-a";
      A[29] = ".\u0011dqt1[1o~e~:?dua$N";
      A[30] = "*4\u0017;\\,_\u0014\u001c4Mc>\u001a\u0017?I9J";
      A[31] = "\u000f]>f`G\u000f]):lH\u0015\u0016)$l]\u0012g|{5";
      A[32] = "\"C<\u0018t\b4C9Bg\u001f#\b:Dk\u000b2O-S \u001b*";
      A[33] = "%-?\u0003\"\u0000P\r4\f3O1\u0003?\u00077\u0015E";
      A[34] = "KL<@GF]L9\u001aTQJ\u0007:\u001cXE[@-\u000b\u0013RV";
      A[35] = "+Oq\u0011Km^oz\u001eZ\"?aq\u0015^xK";
      A[36] = "=\u0002\\6\r~H\"W9\u001c1),\\2\u0018k]";
      A[37] = "U\t]hBc )VgS,A']lWv5";
      A[38] = ";[g\b\"t;[pT.{!\u0010pJ.n&a\"\u0014y%";
      A[39] = "\u0000\te5#z\u0016\t`o0m\u0001Bci<y\u0010\u0005t~wi\b\u0005vu-$4\u001evh-c\u0003\t";
      A[40] = "U}o5\bZC}jo\u001bMT6ii\u0017YEq~~\\I\u0002";
      A[41] = "In90\"G<N2?3\b]@947R)";
      A[42] = "9{}8SF9{jd_I#0jz_\\$A;.\n\u0017";
      A[43] = " p4\u0007+{ p#['t:;#E'a=Jr\u0011r*jv,H5a\u0011'x\u001d\u007f";
      A[44] = "RST\u0005\ti's_\n\u0018&F}T\u0001\u001c|2";
      A[45] = "\fY9f\u0012#\u001aY<<\u00014\r\u0012?:\r \u001cU(-F1\r";
      A[46] = "\b \u000e?eU}\u0000\u00050t\u001a\u001c\u000e\u000e;p@h";
      A[47] = "\u0013\\/-\u000e1\u0013\\8q\u0002>\t\u00178o\u0002+\u000efi6Zn";
      A[48] = "\\ N\u0010]{B(T_ kB";
      A[49] = "Op-@E8Op:\u001cI7U;:\u0002I\"RJo]\u001c";
      A[50] = "u_G\u001cFNu_P@JAo\u0014P^JThe\u0005\u0001\u001d";
      A[51] = "\u001b\u0005kQsrn%`^b=\u000f+kUfg{";
      A[52] = "ho-nvOvg7!\u0014Sqz";
      A[53] = "W\u007fRewe\"_Yjf*CQRabp7";
      A[54] = "e\r\u0013YS-e\r\u0004\u0005_\"\u007fF\u0004\u001b_7x7V@\u000ew";
      A[55] = "Hd\rp\u0000\u001eCk\u001c?g\u001cV`\u001ct\\";
      A[56] = "gS\u0007t`V\u0012s\f{q\u0019s}\u0007puC\u0007";
      A[57] = "@\u0001\u007f\u0012:\u0010@\u0001hN6\u001fZJhP6\n];:\u000bfJ";
      A[58] = "gC\u000b2\t%\u0012c\u0000=\u0018jsm\u000b6\u001c0\u0007";
      A[59] = "C\u0018;\u001c\u0014OC\u0018,@\u0018@YS,^\u0018U^\"~\u0004L\u0011";
      A[60] = "_\u0007/,r\u0001*'$#cNK)/(g\u0014?";
      A[61] = "/0e*~\u001b$?te\u0016\u001b*0g";
      A[62] = float.class;
      B[62] = "java/lang/Float";
      A[63] = "\tuoc\t\u000f\u001fuj9\u001a\u0018\b>i?\u0016\f\u0019y~(]\u001c\u001f";
      A[64] = "\u0003\u0004GO(Zv$L@9\u0015\u0017*GK=Oc";
      A[65] = "~TL/\u0004%2\u0018[\u0013U\u001fwYP-B',\b[\"@\u001fw\u0015\u0010vUc4\u0019Hr?";
      A[66] = "%\u00195joV4K=6\f_+\u001a<j[\buJe\u0006nJtL&wrI(F";
      A[67] = "~;\u0015\u000bk07y\u0011\u0005\u007fV)c\u001c\u0010i\u0001x=OO\u0005l;p\u0013\u000fj1*:\u0010";
      A[68] = "=r\u0001iJk, \t5)i?`\fbE[k!R4)`j{\u000e>\u0017<.q\r\u0005";
      A[69] = "-p9NI\u0017sw)\r%\u0014\u0013$p\u000b\u001b\u0000+\u007f!\u0000\u0014\u0002\u0013#-\t\u001b\u0011y}*\u0019X}";
      A[70] = "\u001c#\u0018C-eN5\u0012P\u0013q\u0018$\u0002^\u007fCOdR\u0003#\u0014\u0019`\u0005[(*E$\u000fX\u0013";
      A[71] = "~k2\u0001#\b7-;\t1k&7*&'\u000f:<VB2\u0019%*9\u001f#S&Q";
      A[72] = "\u0002\u0013\u0007\u001bn:\u0005\f\u000f\u001f\u001438GE\u0000*'\u0000\u001c\u0014\u000b%%8G\t@q0D\u0004\u0005\u0018uZ";
      A[73] = "\u0006\u0005\u0019\u001c\u0013\u0002D\u0001\u001e\u0016m\u000b|G\u0013VS\u001fD\u001cB]\\\u001d|\u0012\u001bJ\u000fYBN_@\fb";
      A[74] = "y<}\t{\"i>bKD'\u0015c=Bz3-8lIu1\u0015cq\u0002!$i }Z%N";
      A[75] = "\r\u0006-e?$\u001cT%9\\-\u0003\u0005$e\u000bz\\X\u007f\t8!_\u0007)5d%\u0005\u000f";
      A[76] = "rD\u000b\u001fla'W\t\u0016\u0014d\u0017\u001e\u0001\u000e*s/EP\u0005%q\u0017\u001eMNqdk]A\u0016u\u000e";
      A[77] = "=@fJ\u000f\u0002&HmUt\u001e!\u0014xD#IzH,\u0012t\ry\u0003~S\u0006\u0016q\ba";
      A[78] = "3\"8+@[&ad%8G+=` o\u0014zh4LA[v7|>T\u0018*9";
      A[79] = "\u0000ieDi!\nt9CW0Qc>N\u0000n\b3j\"f5Oc6\u001d4;We";
      A[80] = "h\u001e\rnX/*P_yRK8.\r1Bu,\u0016V`Iz..\r}\u0002.;RNqZ*Q";
      A[81] = "i\u0013h(]\fn\f`,'\u0006SDf:E\u0017<\u0019wpFl";
      A[82] = "\u000f%P\u007fU~\u000ep\u0016&5+\u00134K(Y\u0019Cr\u0014\u007f\nN\u000etU&\nvC'\u001b!5w\u0002sN%I4\u000e+JO";
      A[83] = "X\\d\u0005\u000f;I\u000elYl2V_m\u0005;e\b\f0i\u001d\"E\be\u0012\u0001?K\u0003";
      A[84] = "FIo{\u00067I\u00014%l1B\f2%\u0000\u0003\u0010AjsleD\u000f?.S7J\u00179B";
      A[85] = "oycpb#=oic\\<go}f\u000bi7>%\n-?}2y:,j;k";
      A[86] = "P:QBZjY<\u000f\\+6N^\u0006OJ/\u001d3\rMH  0\u0017QUlM;\u0015SZQP:QBZjY<\u000f\\+";
      A[87] = "K|\u0003b\" G,^eO%*~\r#q1\u0012%\\(~3*~\u0005d$=Vz\u000137v*";
      A[88] = "78fZmDe.lISP3?|G?b`z%\u0010S_'8d\u0019+Q9?- :\fczvC5D8$\u001c";
      A[89] = "\\\n|R%\u0019PZ!UH\u001c=\br\u0013v\b\u0005S#\u0018y\n=\b>S-\u001fAK2\u000b)u";
      A[90] = "\r\u0012_\u0019k\u0014V\u0016\t[P\u0010\u0001M\u0002\u00069\u001c8C\u0002\u0016=z\n\u0012\u0001\tkDVV\u000b\nP";
      A[91] = "zq\u0006^zz-}^\bD,A5\rCz;yn\\Hu9A`\u0005_&}\u007f<AU%F";
      A[92] = "`\u000f]\t\u0006m!^BXy8q\u0019Y\u0002\u0015\n%_\u0002[D]a\\C\u0007\u0002/zTH\u0018y";
      A[93] = "{%\u0019\"@e7i\u000e\u001e\u0012_r(\u0005 \u0006g)y\u000e/\u0004_{%\u0019\"@e7i\u000e\u001e";
      A[94] = "\u000e\u0017%u\u0000\u0019\u0002V)|`I`C&d\u001e\u001d\rH$f\u0011 ";
      A[95] = "i58\u00182\u001e<&:\u0011J\u001a\fo2\tt\f44c\u0002{\u000e\f::\u0015(J2f~\u001f+q";
      A[96] = "(\u0017D~EU~R\u0006w}\u0007NWOgC\u0014v\f\u001elL\u0016N\u0002G{\u001fRp^\u0003q\u001ci";
      A[97] = "|~Q)bU*;\u0013 Z\u0007\u001a>Z0d\u0014\"e\u000b;k\u0016\u001a>\u0016p?\u0003f}\u001a(;i";
      A[98] = "1Fx^M\u001afJ \bsO\n\u0002sCM[2Y\"HBY\n\u0002?\u0003\u0016LvA3[\u0012&";
      A[99] = "\u0002S\"&\u0002e\u0013\u0001*zal\fP+&6;R\u0007sJ\by\u0017Gq;Zo\u001dT";
      A[100] = ")I.fzM%\u0019sa\u0017CHK ')\\p\u0010q,&^H\u001e(;u\u001avBl1v!";
      A[101] = "K\u001b^,$=A\u0006\u0002+\u001a,\u001a\u0011\u0005&MxAD[z\u001as\u0010\u0003\f&%!\u001e\u001b\n";
      A[102] = "\u0015V7\u001e\u0002\u0017D\u00057^~\u0001(\u0003q\u0003\u0000SC[s\u000fOh\u0016\u0003*\u0018E\u0003N\u0001&W~";
      A[103] = "\u0010pl\b\tT\u00125.^xAj,l\u0002\u001a\u001eVz)@\u0013";
      A[104] = "1mp\b(U==-\u000fEPPo~I{Dh4/BtFPl2@'B?1#\n$9";
      A[105] = "\n)S\u00134\u0016\u000e-\u0004\u0000\u007fjRj\"\u001d=\u0016B\u0011\u0003@\"\b\b/_\u0004(\u000b3";
      A[106] = "\r:\u0018\u0007V\u001e\u0018$\u0017\u001b&JscG\u001c\u0018^K8\u0016\u0017\u0017\\s*K\u0019O\u001cKg\u0018WH#";
      A[107] = "uI\u0010VS\u0012p\bP\u0002G\"\"\u0014C\fZusJ\u001fP6\u001bpK\u0010\r\u0006\u001e1\u000bD\u0019";
      A[108] = "\u0004\u0015~&^c\n\u000byogu\u000f\u0001a20%WS9^\rb\u0015\u0014<&\u0003|\u0012]";
      A[109] = "4+au\u0001Y>6=r?He!:\u007fh\u0016=rd\u0013\u000eM{!2,\\Cc'";
      A[110] = "\u0004\u0002\u0018\u0017.\u0005\u001a\u0003[ARUk@U\u0006lDS\u001b\u0004\rcFkC\u0019\u000f0B\u0004\u001e\bE39";
      A[111] = "\u007f\u0017Hx29u\n\u0014\u007f\f(.\u001d\u0013r[v\u007fKL\u001e=-0\u001d\u001b!o#(\u001b";
      A[112] = "\u0004<]o]5S0\u00059c`?xVr]t\u0007#\u0007yRv?-^n\u00012\u0001q\u001ad\u0002\t";
      A[113] = "IEHWFUE\u0015\u0015P+](GF\u0016\u0015D\u0010\u001c\u0017\u001d\u001aF(\u0012N\nI\u0002\u0016N\n\u0000J9";
      A[114] = "?cR](A;g\u0005Nc=i6\u0012x8G}'nX&\\xf\u0003S$^w[";
      A[115] = "tV\u0006&Bm&@\f5|ypQ\u001c;\u0010K#\u0015@c|u$\u0010E6\u001fzlK\u001b\\";
      A[116] = ">\u0004D\u0007X4\"\u0019J\f4*\"\u0006VZX\u0018uK\u000e\u00034u3\bTF[(\"BW=\u000e3=\u0018MRS\"w\u001b6\u0007H=-\u0001YZYw.z\u000f\u0001\nq*J\n@J%>z\u000f\u0000U-2\u0002\t[W~%z\u000fA\u000f*%\u0006LMW.O";
      A[117] = "$if_uJ:h%\t\t\u001fK++N7\u000bspzE8\tK(gGk\r$uv\rhv";
      A[118] = "<K~c\u0017E-\u0019v?tG>Ysh\u0018uj\u0018+0t@(\u001b(q\u0005\\+G\"\u000fM^h@ys\u000eR0D\u0013";
      A[119] = "a\u0004\u001a\u0012\u0001sk\u0019F\u0015?b0\u000eA\u0018h<oX\u0014t\u000eg.\u000eIK\\i6\b";
      A[120] = "]|~[V2\u000fjtHh-Uj`M?|\t>>!QzPxjG\u00188Tv~";
      A[121] = "M}tX\u0007k\u0006<e\u001cY\u0013\u001a'p\u000b\u0019M\u001d'j\u000fe*K~l\u0006\u0017,\u000e(s\u0002e";
      A[122] = "YKF\u0010TSV\u0003\u001dN>U]\u000e\u001bNRg\u000bKF\u0016\u00020\u0001\u0019\u0004DR\u000fS\u0017\u001cB>\\\b\u0015\u0019\u0012\u0000\u0000L\u001f\u001a)";
      A[123] = "b[/Z\u0017Lg\u001ao\u000e\u0003|5\u0006|\u0000\u001e+dX ]rEgY/\u0001B@&\u0019{\u0015";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = A[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(B[var4]);
            A[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = A[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = B[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            A[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  A[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1615153229182546L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = A[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = B[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  A[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1615153229182546L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        A[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1615153229182546L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 163;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 200;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 65;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 250;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 75;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 164;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 163;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 200;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 65;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d7",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoElytra var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d7;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d7", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoElytra)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoElytra var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d7;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d7", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoElytra)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding3(boolean[] var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("([Z)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/d7", "lambda$onKey$2", "([Z)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((boolean[])var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
