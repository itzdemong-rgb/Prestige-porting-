package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.util.DroppedItemUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AutoHitCrystal extends Module {
   public static boolean a;
   private BooleanSetting d;
   private BooleanSetting c;
   private BooleanSetting e;
   private MinMaxSetting f;
   private BooleanSetting g;
   private ModeSetting h;
   private MinMaxSetting i;
   private BooleanSetting j;
   private ElapsedTimer k;
   private int l;
   private static final long m = 13045796692584L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long[] q;
   private static final Integer[] r;
   private static final Map s;
   private static final Object[] t = new Object[158];
   private static final String[] u = new String[158];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public AutoHitCrystal() {
      super();
      long var10001 = 84935704657764L ^ 48607171250253L;
      var10001 = 84935704657764L ^ 44899282445835L;

      this.k = new ElapsedTimer(106698256430889L);
      this.l = 0;
      MinMaxSetting var10000 = this.i;
      Object[] var8 = new Object[]{invokeBinding1(this), 112057026795887L};
      MinMaxSetting var7 = var10000;
      var7.aReturningMinMaxSetting(var8);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      short var10000 = 20399;
      long var2 = (Long)var1[0];
      long var10001 = 1784744513414229261L ^ var2;
      ModeSetting var4 = this.h;
      Object var6 = var4.aReturningObject();
      String var5 = "Infinite";
      return var5.equals(var6);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      int var10;
      int var26;
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 97434553232679L;
      long var6 = var2 ^ 99186983384233L;
      long var8 = var2 ^ 78438275227136L;
      var10 = Event.bReturningInt();
      Object[] var12 = new Object[]{var6};
      AutoHitCrystal var11 = this;
      int var10000 = var11.bReturningInt(var12);
      int var30 = var10;
      int var29 = var10000;
      var26 = var29;
      int var23 = var29;
      label31:
      if (var30 == 0) {
         short var10001 = 27428;
         long var10002 = 9184840064308607159L ^ var2;
         short var32 = 9998;
         int var31 = var23;
         if (var31 == var32) {
            Object[] var14 = new Object[]{var8};
            byte var40 = ((byte)((ItemUseUtil.eReturningBoolean(var14)) ? 1 : 0));
            int var34 = var10;
            byte var33 = var40;
            var26 = var33;
            byte var24 = var33;
            if (var34 != 0) {
               break label31;
            }

            byte var35 = var24;
            byte var25 = var35;
            byte var36 = var25;
            if (var36 != 0) {
               Object[] var18 = new Object[]{var4};
               AutoHitCrystal var17 = this;
               var17.aReturningVoid(var18);
               return;
            }
         }

         ModeSetting var20 = this.h;
         String var41 = (String)var20.aReturningObject();
         var10001 = 6487;
         var10002 = 4349115743122293938L ^ var2;
         String var22 = "None";
         String var21 = var41;
         var26 = (((var21.equals(var22)) ? 1 : 0));
      }

      int var38 = var10;
      int var37 = var26;
      int var28 = var37;
      int var27 = var37;
      if (var38 == 0) {
         int var39 = var27;
         if (var39 != 0) {
            return;
         }

         var28 = 1;
      }

      a = dev.prestige.recovery.SourceSupport.asBoolean(var28);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      a = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.l = 0;
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 71499166341044L ^ 54370387523170L;
      int var6 = Event.bReturningInt();
      Object[] var8 = new Object[]{123644152586710L};
      AutoHitCrystal var7 = this;
      int var10000 = var7.bReturningInt(var8);
      int var31 = var6;
      int var30 = var10000;
      int var27 = var30;
      int var26 = var30;
      if (var31 == 0) {
         short var33 = 9998;
         int var32 = var26;
         if (var32 != var33) {
            return;
         }

         MinecraftClient var10 = b;
         ClientPlayerEntity var11 = var10.player;
         ItemStack var12 = var11.getMainHandStack();
         Item var40 = var12.getItem();
         Item var14 = Items.END_CRYSTAL;
         Item var13 = var40;
         byte var34 = ((byte)((var13.equals(var14)) ? 1 : 0));
         var27 = var34;
      }

      label21: {
         int var36 = var6;
         int var35 = var27;
         int var29 = var35;
         int var28 = var35;
         if (var36 == 0) {
            int var37 = var28;
            if (var37 != 0) {
               break label21;
            }

            MinecraftClient var17 = b;
            ClientPlayerEntity var18 = var17.player;
            ItemStack var19 = var18.getMainHandStack();
            Item var41 = var19.getItem();
            Block var20 = Blocks.OBSIDIAN;
            Item var22 = var20.asItem();
            Item var21 = var41;
            byte var38 = ((byte)((var21.equals(var22)) ? 1 : 0));
            var29 = var38;
         }

         int var39 = var29;
         if (var39 == 0) {
            return;
         }
      }

      Object[] var25 = new Object[0];
      ItemUseEvent var24 = var1;
      var24.aReturningVoid(var25);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 112322222490871L ^ 24585129370913L;
      var10001 = 112322222490871L ^ 107303714604292L;
      var10001 = 112322222490871L ^ 57009864616360L;
      var10001 = 112322222490871L ^ 125590833878309L;
      var10001 = 112322222490871L ^ 30219442257927L;
      var10001 = 112322222490871L ^ 18934718324364L;
      var10001 = 112322222490871L ^ 23039561514159L;
      var10001 = 112322222490871L ^ 5647705107059L;
      var10001 = 112322222490871L ^ 24066973498040L;
      var10001 = 112322222490871L ^ 71319450905847L;
      var10001 = 112322222490871L ^ 12366192709512L;
      var10001 = 112322222490871L ^ 42778202688940L;
      var10001 = 112322222490871L ^ 138691545876632L;
      var10001 = 112322222490871L ^ 59675658050880L;
      var10001 = 112322222490871L ^ 93973081728506L;
      var10001 = 112322222490871L ^ 35650855712230L;
      var10001 = 112322222490871L ^ 1945133609759L;
      var10001 = 112322222490871L ^ 131523488389963L;
      var10001 = 112322222490871L ^ 102479027467950L;
      int var42 = Event.bReturningInt();
      int var421 = var42;
      MinecraftClient var420 = b;
      MinecraftClient var301 = var420;
      MinecraftClient var300 = var420;
      if (var421 == 0) {
         MinecraftClient var46 = var300;
         Screen var422 = var46.currentScreen;
         if (var422 != null) {
            return;
         }

         MinecraftClient var423 = b;
         var301 = var423;
      }

      MinecraftClient var49 = var301;
      int var10000 = (((var49.isWindowFocused()) ? 1 : 0));
      int var425 = var42;
      byte var424 = (byte)var10000;
      byte var303 = var424;
      byte var302 = var424;
      if (var425 == 0) {
         byte var426 = var302;
         if (var426 == 0) {
            return;
         }

         ElapsedTimer var645 = this.k;
         Object[] var52 = new Object[]{this.f, 130913203968635L};
         ElapsedTimer var51 = var645;
         byte var427 = ((byte)((var51.bReturningBoolean(var52)) ? 1 : 0));
         var303 = var427;
      }

      int var429 = var42;
      byte var428 = var303;
      byte var305 = var428;
      byte var304 = var428;
      if (var429 == 0) {
         byte var430 = var304;
         if (var430 == 0) {
            return;
         }

         BooleanSetting var55 = this.d;
         Boolean var56 = (Boolean)var55.aReturningObject();
         byte var431 = ((byte)(((java.lang.Boolean)(var56)).booleanValue() ? 1 : 0));
         var305 = var431;
      }

      byte var309;
      int var433 = var42;
      byte var432 = var305;
      var309 = var432;
      byte var306 = var432;
      label579:
      if (var433 == 0) {
         byte var434 = var306;
         if (var434 != 0) {
            MinecraftClient var59 = b;
            ClientPlayerEntity var60 = var59.player;
            var10000 = (((var60.isOnGround()) ? 1 : 0));
            int var436 = var42;
            byte var435 = ((byte)(var10000));
            var309 = var435;
            byte var307 = var435;
            if (var436 != 0) {
               break label579;
            }

            byte var437 = var307;
            byte var308 = var437;
            byte var438 = var308;
            if (var438 == 0) {
               return;
            }
         }

         MinecraftClient var63 = b;
         ClientPlayerEntity var64 = var63.player;
         byte var439 = ((byte)((var64.isUsingItem()) ? 1 : 0));
         var309 = var439;
      }

      int var441 = var42;
      byte var440 = var309;
      int var311 = var440;
      byte var310 = var440;
      if (var441 == 0) {
         byte var442 = var310;
         if (var442 != 0) {
            return;
         }

         Object[] var68 = new Object[]{123644152586710L};
         AutoHitCrystal var67 = this;
         var311 = var67.bReturningInt(var68);
      }

      int var315;
      int var444 = var42;
      int var443 = var311;
      var315 = var443;
      int var312 = var443;
      label558:
      if (var444 == 0) {
         short var446 = 9998;
         int var445 = var312;
         if (var445 == var446) {
            Object[] var70 = new Object[]{119946435234687L};
            var10000 = (((ItemUseUtil.eReturningBoolean(var70)) ? 1 : 0));
            int var448 = var42;
            byte var447 = ((byte)(var10000));
            var315 = var447;
            byte var313 = var447;
            if (var448 != 0) {
               break label558;
            }

            byte var449 = var313;
            byte var314 = var449;
            byte var450 = var314;
            if (var450 != 0) {
               a = false;
               return;
            }
         }

         Object[] var74 = new Object[]{Items.NETHERITE_SPEAR, 8519502184947L};
         var315 = (((InventoryUtil.lReturningBoolean(var74)) ? 1 : 0));
      }

      int var452 = var42;
      int var451 = var315;
      int var317 = var451;
      int var316 = var451;
      if (var452 == 0) {
         int var453 = var316;
         if (var453 != 0) {
            return;
         }

         RotationManager var648 = Prestige.o;
         Object[] var77 = new Object[0];
         RotationManager var76 = var648;
         var317 = (((var76.fReturningBoolean(var77)) ? 1 : 0));
      }

      int var454 = var317;
      if (var454 == 0) {
         PlayerEntity var43;
         int var321;
         label548: {
            label587: {
               Object[] var78 = new Object[]{77260333461777L};
               var43 = EntityUtil.aReturningPlayerEntity(var78);
               int var456 = var42;
               PlayerEntity var455 = var43;
               PlayerEntity var319 = var455;
               PlayerEntity var318 = var455;
               if (var456 == 0) {
                  PlayerEntity var457 = var318;
                  if (var457 == null) {
                     break label587;
                  }

                  var319 = var43;
               }

               MinecraftClient var80 = b;
               ClientPlayerEntity var82 = var80.player;
               PlayerEntity var81 = var319;
               float var713;
               var10000 = (var713 = var81.distanceTo((Entity)var82) - 10.0F) == 0.0F ? 0 : (var713 < 0.0F ? -1 : 1);
               int var459 = var42;
               int var458 = var10000;
               var321 = var458;
               int var320 = var458;
               if (var459 != 0) {
                  break label548;
               }

               int var460 = var320;
               if (var460 > 0) {
                  var43 = null;
               }
            }

            var321 = this.l;
         }

         MinecraftClient var328;
         label538: {
            label588: {
               int var462 = var42;
               int var461 = var321;
               int var323 = var461;
               int var322 = var461;
               if (var462 == 0) {
                  int var463 = var322;
                  if (var463 != 0) {
                     break label588;
                  }

                  BooleanSetting var85 = this.c;
                  Boolean var86 = (Boolean)var85.aReturningObject();
                  byte var464 = ((byte)(((java.lang.Boolean)(var86)).booleanValue() ? 1 : 0));
                  var323 = var464;
               }

               int var466 = var42;
               int var465 = var323;
               int var327 = var465;
               int var324 = var465;
               if (var466 == 0) {
                  int var467 = var324;
                  if (var467 == 0) {
                     break label588;
                  }

                  int var469 = var42;
                  MinecraftClient var468 = b;
                  var328 = var468;
                  MinecraftClient var325 = var468;
                  if (var469 != 0) {
                     break label538;
                  }

                  MinecraftClient var470 = var325;
                  MinecraftClient var326 = var470;
                  MinecraftClient var90 = var326;
                  ClientPlayerEntity var91 = var90.player;
                  Object[] var92 = new Object[]{var91.getMainHandStack(), 19476550655932L};
                  byte var471 = ((byte)((InventoryUtil.aReturningBoolean(var92)) ? 1 : 0));
                  var327 = var471;
               }

               int var472 = var327;
               if (var472 == 0) {
                  Object[] var95 = new Object[]{126290808879192L};
                  AutoHitCrystal var94 = this;
                  var94.aReturningVoid(var95);
                  return;
               }
            }

            var328 = b;
         }

         MinecraftClient var97 = var328;
         HitResult var44 = var97.crosshairTarget;
         int var474 = var42;
         HitResult var473 = var44;
         Object var330 = var473;
         HitResult var329 = var473;
         if (var474 == 0) {
            HitResult var475 = var329;
            if (var475 == null) {
               return;
            }

            ModeSetting var99 = this.h;
            var330 = var99.aReturningObject();
         }

         String var650 = (String)var330;
         String var101 = "None";
         String var100 = var650;
         byte var651 = ((byte)((var100.equals(var101)) ? 1 : 0));
         int var477 = var42;
         byte var476 = var651;
         int var332 = var476;
         byte var331 = var476;
         if (var477 == 0) {
            byte var478 = var331;
            if (var478 == 0) {
               a = true;
            }

            var332 = this.l;
         }

         int var355;
         label520: {
            boolean var359;
            label634: {
               boolean var366;
               label517: {
                  label635: {
                     label614: {
                        label592: {
                           label593: {
                              label594: {
                                 label595: {
                                    int var480 = var42;
                                    int var479 = var332;
                                    int var334 = var479;
                                    int var333 = var479;
                                    if (var480 == 0) {
                                       int var481 = var333;
                                       switch (var481) {
                                          case 0:
                                             byte var482 = ((byte)((var44 instanceof EntityHitResult) ? 1 : 0));
                                             var334 = var482;
                                             break;
                                          case 1:
                                             break label595;
                                          case 2:
                                             break label594;
                                          case 3:
                                          case 5:
                                             break label593;
                                          case 4:
                                             break label592;
                                          case 6:
                                             break label614;
                                          default:
                                             return;
                                       }
                                    }

                                    int var351;
                                    int var484 = var42;
                                    int var483 = var334;
                                    var351 = var483;
                                    int var335 = var483;
                                    label477:
                                    if (var484 == 0) {
                                       int var485 = var335;
                                       if (var485 != 0) {
                                          EntityHitResult var45 = (EntityHitResult)var44;
                                          EntityHitResult var107 = var45;
                                          var651 = ((byte)((var107.getEntity() instanceof EndCrystalEntity) ? 1 : 0));
                                          int var487 = var42;
                                          byte var486 = var651;
                                          var351 = var486;
                                          byte var336 = var486;
                                          if (var487 != 0) {
                                             break label477;
                                          }

                                          byte var488 = var336;
                                          if (var488 != 0) {
                                             ModeSetting var109 = this.h;
                                             String var653 = (String)var109.aReturningObject();
                                             String var111 = "None";
                                             String var110 = var653;
                                             var651 = ((byte)((var110.equals(var111)) ? 1 : 0));
                                             int var490 = var42;
                                             byte var489 = var651;
                                             byte var339 = var489;
                                             byte var337 = var489;
                                             if (var490 == 0) {
                                                byte var491 = var337;
                                                byte var338 = var491;
                                                byte var492 = var338;
                                                if (var492 != 0) {
                                                   a = false;
                                                   return;
                                                }

                                                BooleanSetting var115 = this.e;
                                                Boolean var116 = (Boolean)var115.aReturningObject();
                                                var339 = ((byte)(((java.lang.Boolean)(var116)).booleanValue() ? 1 : 0));
                                             }

                                             byte var343;
                                             int var494 = var42;
                                             byte var493 = var339;
                                             var343 = var493;
                                             byte var340 = var493;
                                             label344:
                                             if (var494 == 0) {
                                                byte var495 = var340;
                                                if (var495 != 0) {
                                                   EntityHitResult var118 = var45;
                                                   Entity var119 = var118.getEntity();
                                                   Object[] var120 = new Object[]{var119.getBlockPos(), 108898817732228L};
                                                   var651 = ((byte)((DroppedItemUtil.aReturningBoolean(var120)) ? 1 : 0));
                                                   int var497 = var42;
                                                   byte var496 = var651;
                                                   var343 = var496;
                                                   byte var341 = var496;
                                                   if (var497 != 0) {
                                                      break label344;
                                                   }

                                                   byte var498 = var341;
                                                   byte var342 = var498;
                                                   byte var499 = var342;
                                                   if (var499 != 0) {
                                                      a = false;
                                                      return;
                                                   }
                                                }

                                                BooleanSetting var124 = this.g;
                                                Boolean var125 = (Boolean)var124.aReturningObject();
                                                var343 = ((byte)(((java.lang.Boolean)(var125)).booleanValue() ? 1 : 0));
                                             }

                                             int var350;
                                             int var501 = var42;
                                             byte var500 = var343;
                                             var350 = var500;
                                             byte var344 = var500;
                                             label337:
                                             if (var501 == 0) {
                                                Object var349;
                                                label335: {
                                                   byte var502 = var344;
                                                   if (var502 != 0) {
                                                      int var504 = var42;
                                                      PlayerEntity var503 = var43;
                                                      var349 = var503;
                                                      PlayerEntity var345 = var503;
                                                      if (var504 != 0) {
                                                         break label335;
                                                      }

                                                      PlayerEntity var505 = var345;
                                                      PlayerEntity var346 = var505;
                                                      PlayerEntity var506 = var346;
                                                      if (var506 != null) {
                                                         PlayerEntity var129 = var43;
                                                         int var508 = var42;
                                                         int var507 = var129.hurtTime;
                                                         var350 = var507;
                                                         int var347 = var507;
                                                         if (var508 != 0) {
                                                            break label337;
                                                         }

                                                         int var509 = var347;
                                                         int var348 = var509;
                                                         int var510 = var348;
                                                         if (var510 != 0) {
                                                            return;
                                                         }
                                                      }
                                                   }

                                                   EntityHitResult var132 = var45;
                                                   var349 = var132.getEntity();
                                                }

                                                Object[] var133 = new Object[]{var349, 114267283224552L};
                                                ItemUseUtil.aReturningVoid(var133);
                                                MinMaxSetting var656 = this.f;
                                                Object[] var135 = new Object[]{127318019014223L};
                                                MinMaxSetting var134 = var656;
                                                var134.bReturningVoid(var135);
                                                ElapsedTimer var657 = this.k;
                                                Object[] var137 = new Object[]{42835128969216L};
                                                ElapsedTimer var136 = var657;
                                                var136.aReturningVoid(var137);
                                                var350 = 0;
                                             }

                                             a = dev.prestige.recovery.SourceSupport.asBoolean(var350);
                                             return;
                                          }
                                       }

                                       var351 = (((var44 instanceof BlockHitResult) ? 1 : 0));
                                    }

                                    int var512 = var42;
                                    int var511 = var351;
                                    var355 = var511;
                                    int var352 = var511;
                                    if (var512 != 0) {
                                       break label520;
                                    }

                                    int var513 = var352;
                                    if (var513 == 0) {
                                       break label635;
                                    }

                                    Object[] var139 = new Object[]{var44, 88434925001143L};
                                    var651 = ((byte)((BlockUtil.cReturningBoolean(var139)) ? 1 : 0));
                                    int var515 = var42;
                                    byte var514 = var651;
                                    var355 = var514;
                                    byte var353 = var514;
                                    if (var515 != 0) {
                                       break label520;
                                    }

                                    byte var516 = var353;
                                    byte var354 = var516;
                                    byte var517 = var354;
                                    if (var517 == 0) {
                                       break label635;
                                    }

                                    MinecraftClient var142 = b;
                                    ClientWorld var659 = var142.world;
                                    BlockHitResult var143 = (BlockHitResult)var44;
                                    BlockPos var145 = var143.getBlockPos();
                                    ClientWorld var144 = var659;
                                    BlockState var146 = var144.getBlockState(var145);
                                    Block var660 = var146.getBlock();
                                    int var519 = var42;
                                    Block var518 = var660;
                                    Block var357 = var518;
                                    Block var356 = var518;
                                    if (var519 == 0) {
                                       Block var521 = Blocks.OBSIDIAN;
                                       Block var520 = var356;
                                       if (var520 == var521) {
                                          this.l = 2;
                                          return;
                                       }

                                       var357 = Blocks.OBSIDIAN;
                                    }

                                    Object[] var149 = new Object[]{var357, 64992723038809L};
                                    boolean var661 = InventoryUtil.iReturningVoid(var149);
                                    int var523 = var42;
                                    boolean var522 = var661;
                                    var359 = var522;
                                    boolean var358 = var522;
                                    if (var523 != 0) {
                                       break label634;
                                    }

                                    boolean var524 = var358;
                                    if (!var524) {
                                       var359 = false;
                                       break label634;
                                    }

                                    Object[] var152 = new Object[]{22065044672978L};
                                    AutoHitCrystal var151 = this;
                                    var151.kReturningVoid(var152);
                                    int var525 = var42;
                                    if (var525 == 0) {
                                       return;
                                    }
                                 }

                                 HitResult var364;
                                 label597: {
                                    boolean var662 = var44 instanceof BlockHitResult;
                                    int var527 = var42;
                                    boolean var526 = var662;
                                    boolean var363 = var526;
                                    boolean var360 = var526;
                                    if (var527 == 0) {
                                       boolean var528 = var360;
                                       boolean var361 = var528;
                                       boolean var529 = var361;
                                       if (!var529) {
                                          a = false;
                                          return;
                                       }

                                       int var531 = var42;
                                       HitResult var530 = var44;
                                       var364 = var530;
                                       HitResult var362 = var530;
                                       if (var531 != 0) {
                                          break label597;
                                       }

                                       Object[] var156 = new Object[]{var362, 88434925001143L};
                                       boolean var532 = BlockUtil.cReturningBoolean(var156);
                                       var363 = var532;
                                    }

                                    boolean var533 = var363;
                                    if (!var533) {
                                       a = false;
                                       return;
                                    }

                                    var364 = var44;
                                 }

                                 BlockHitResult var159 = (BlockHitResult)var364;
                                 BlockPos var663 = var159.getBlockPos();
                                 BlockHitResult var160 = (BlockHitResult)var44;
                                 Direction var162 = var160.getSide();
                                 BlockPos var161 = var663;
                                 BlockPos var643 = var161.offset(var162);
                                 Object[] var163 = new Object[]{var643, 56486840213773L};
                                 boolean var664 = BlockUtil.gReturningBoolean(var163);
                                 int var535 = var42;
                                 boolean var534 = var664;
                                 var366 = var534;
                                 boolean var365 = var534;
                                 if (var535 != 0) {
                                    break label517;
                                 }

                                 boolean var536 = var365;
                                 if (var536) {
                                    var366 = false;
                                    break label517;
                                 }

                                 MinecraftClient var165 = b;
                                 ClientWorld var665 = var165.world;
                                 BlockHitResult var166 = (BlockHitResult)var44;
                                 BlockPos var168 = var166.getBlockPos();
                                 ClientWorld var167 = var665;
                                 BlockState var169 = var167.getBlockState(var168);
                                 Block var666 = var169.getBlock();
                                 Block var538 = Blocks.OBSIDIAN;
                                 Block var537 = var666;
                                 if (var537 == var538) {
                                    a = false;
                                    Object[] var171 = new Object[]{22065044672978L};
                                    AutoHitCrystal var170 = this;
                                    var170.kReturningVoid(var171);
                                    return;
                                 }

                                 BlockHitResult var173 = (BlockHitResult)var44;
                                 Object[] var174 = new Object[]{var173.getBlockPos(), 56486840213773L};
                                 var664 = BlockUtil.gReturningBoolean(var174);
                                 int var540 = var42;
                                 boolean var539 = var664;
                                 boolean var368 = var539;
                                 boolean var367 = var539;
                                 if (var540 == 0) {
                                    boolean var541 = var367;
                                    if (var541) {
                                       a = false;
                                       return;
                                    }

                                    Block var668 = Blocks.OBSIDIAN;
                                    Runnable var710 = invokeBinding2(var44);
                                    Object[] var10005 = new Object[]{null, null, null, 94496437480799L};
                                    var10005[2] = false;
                                    var10005[1] = var710;
                                    var10005[0] = var668;
                                    Object[] var177 = var10005;
                                    var368 = InventoryUtil.kReturningBoolean(var177);
                                 }

                                 boolean var542 = var368;
                                 if (!var542) {
                                    return;
                                 }

                                 Object[] var179 = new Object[]{22065044672978L};
                                 AutoHitCrystal var178 = this;
                                 var178.kReturningVoid(var179);
                                 int var543 = var42;
                                 if (var543 == 0) {
                                    return;
                                 }
                              }

                              Object[] var180 = new Object[]{Items.END_CRYSTAL, 26438384176239L};
                              boolean var544 = InventoryUtil.hReturningVoid(var180);
                              if (!var544) {
                                 return;
                              }

                              Object[] var184 = new Object[]{22065044672978L};
                              AutoHitCrystal var183 = this;
                              var183.kReturningVoid(var184);
                              int var545 = var42;
                              if (var545 == 0) {
                                 return;
                              }
                           }

                           ModeSetting var185 = this.h;
                           String var669 = (String)var185.aReturningObject();
                           String var187 = "None";
                           String var186 = var669;
                           var651 = ((byte)((var186.equals(var187)) ? 1 : 0));
                           int var547 = var42;
                           byte var546 = var651;
                           int var371 = var546;
                           byte var369 = var546;
                           if (var547 == 0) {
                              byte var548 = var369;
                              byte var370 = var548;
                              byte var549 = var370;
                              if (var549 != 0) {
                                 Object[] var191 = new Object[]{126290808879192L};
                                 AutoHitCrystal var190 = this;
                                 var190.aReturningVoid(var191);
                                 return;
                              }

                              var371 = this.l;
                           }

                           HitResult var377;
                           label599: {
                              int var376;
                              int var551 = var42;
                              int var550 = var371;
                              var376 = var550;
                              int var372 = var550;
                              label488:
                              if (var551 == 0) {
                                 byte var553 = 5;
                                 int var552 = var372;
                                 if (var552 == var553) {
                                    ElapsedTimer var671 = this.k;
                                    Object[] var195 = new Object[]{this.i, 130913203968635L};
                                    ElapsedTimer var194 = var671;
                                    var651 = ((byte)((var194.bReturningBoolean(var195)) ? 1 : 0));
                                    int var555 = var42;
                                    byte var554 = var651;
                                    var376 = var554;
                                    byte var373 = var554;
                                    if (var555 != 0) {
                                       break label488;
                                    }

                                    byte var556 = var373;
                                    byte var374 = var556;
                                    byte var557 = var374;
                                    if (var557 == 0) {
                                       return;
                                    }
                                 }

                                 int var559 = var42;
                                 HitResult var558 = var44;
                                 var377 = var558;
                                 HitResult var375 = var558;
                                 if (var559 != 0) {
                                    break label599;
                                 }

                                 byte var560 = ((byte)((var375 instanceof BlockHitResult) ? 1 : 0));
                                 var376 = var560;
                              }

                              int var561 = var376;
                              if (var561 == 0) {
                                 return;
                              }

                              var377 = var44;
                           }

                           BlockHitResult var199 = (BlockHitResult)var377;
                           BlockPos var644 = var199.getBlockPos();
                           MinecraftClient var200 = b;
                           BlockPos var202 = var644;
                           ClientWorld var201 = var200.world;
                           BlockState var203 = var201.getBlockState(var202);
                           Block var673 = var203.getBlock();
                           Block var563 = Blocks.OBSIDIAN;
                           Block var562 = var673;
                           if (var562 != var563) {
                              return;
                           }

                           Object[] var205 = new Object[]{var644, 56486840213773L};
                           boolean var674 = BlockUtil.gReturningBoolean(var205);
                           int var565 = var42;
                           boolean var564 = var674;
                           boolean var379 = var564;
                           boolean var378 = var564;
                           if (var565 == 0) {
                              boolean var566 = var378;
                              if (var566) {
                                 return;
                              }

                              Item var675 = Items.END_CRYSTAL;
                              Runnable var711 = invokeBinding3(var44);
                              Object[] var712 = new Object[]{null, null, null, 71193876973915L};
                              var712[2] = false;
                              var712[1] = var711;
                              var712[0] = var675;
                              Object[] var207 = var712;
                              var379 = InventoryUtil.jReturningBoolean(var207);
                           }

                           boolean var567 = var379;
                           if (!var567) {
                              return;
                           }

                           Object[] var209 = new Object[]{22065044672978L};
                           AutoHitCrystal var208 = this;
                           var208.kReturningVoid(var209);
                           int var568 = var42;
                           if (var568 == 0) {
                              return;
                           }
                        }

                        BooleanSetting var210 = this.g;
                        Boolean var211 = (Boolean)var210.aReturningObject();
                        boolean var569 = var211;
                        label462:
                        if (var569) {
                           int var571 = var42;
                           PlayerEntity var570 = var43;
                           PlayerEntity var382 = var570;
                           PlayerEntity var380 = var570;
                           if (var571 == 0) {
                              PlayerEntity var572 = var380;
                              PlayerEntity var381 = var572;
                              PlayerEntity var573 = var381;
                              if (var573 == null) {
                                 break label462;
                              }

                              var382 = var43;
                           }

                           PlayerEntity var215 = var382;
                           int var574 = var215.hurtTime;
                           if (var574 != 0) {
                              return;
                           }
                        }

                        AutoHitCrystal var399;
                        label602: {
                           boolean var398;
                           label454: {
                              MinecraftClient var217 = b;
                              HitResult var218 = var217.crosshairTarget;
                              Type var676 = var218.getType();
                              int var576 = var42;
                              Type var575 = var676;
                              Object var397 = var575;
                              Type var383 = var575;
                              if (var576 == 0) {
                                 Type var578 = Type.ENTITY;
                                 Type var577 = var383;
                                 if (var577 == var578) {
                                    EntityHitResult var220 = (EntityHitResult)var44;
                                    boolean var677 = var220.getEntity() instanceof EndCrystalEntity;
                                    int var580 = var42;
                                    boolean var579 = var677;
                                    var398 = var579;
                                    boolean var384 = var579;
                                    if (var580 != 0) {
                                       break label454;
                                    }

                                    boolean var581 = var384;
                                    boolean var385 = var581;
                                    boolean var582 = var385;
                                    if (var582) {
                                       AutoHitCrystal var395;
                                       label368: {
                                          label367: {
                                             AutoHitCrystal var394;
                                             label604: {
                                                boolean var391;
                                                BooleanSetting var223 = this.e;
                                                Boolean var224 = (Boolean)var223.aReturningObject();
                                                var677 = var224;
                                                int var584 = var42;
                                                boolean var583 = var677;
                                                var391 = var583;
                                                boolean var386 = var583;
                                                label365:
                                                if (var584 == 0) {
                                                   boolean var585 = var386;
                                                   boolean var387 = var585;
                                                   boolean var586 = var387;
                                                   if (var586) {
                                                      EntityHitResult var227 = (EntityHitResult)var44;
                                                      Entity var228 = var227.getEntity();
                                                      Object[] var229 = new Object[]{var228.getBlockPos(), 108898817732228L};
                                                      var677 = DroppedItemUtil.aReturningBoolean(var229);
                                                      int var588 = var42;
                                                      boolean var587 = var677;
                                                      var391 = var587;
                                                      boolean var388 = var587;
                                                      if (var588 != 0) {
                                                         break label365;
                                                      }

                                                      boolean var589 = var388;
                                                      boolean var389 = var589;
                                                      boolean var590 = var389;
                                                      if (var590) {
                                                         return;
                                                      }
                                                   }

                                                   EntityHitResult var232 = (EntityHitResult)var44;
                                                   Object[] var233 = new Object[]{var232.getEntity(), 114267283224552L};
                                                   ItemUseUtil.aReturningVoid(var233);
                                                   int var592 = var42;
                                                   AutoHitCrystal var591 = this;
                                                   var394 = var591;
                                                   AutoHitCrystal var390 = var591;
                                                   if (var592 != 0) {
                                                      break label604;
                                                   }

                                                   ModeSetting var234 = var390.h;
                                                   String var680 = (String)var234.aReturningObject();
                                                   String var236 = "Double Tap";
                                                   String var235 = var680;
                                                   boolean var593 = var235.equals(var236);
                                                   var391 = var593;
                                                }

                                                boolean var594 = var391;
                                                if (!var594) {
                                                   int var596 = var42;
                                                   AutoHitCrystal var595 = this;
                                                   var395 = var595;
                                                   AutoHitCrystal var392 = var595;
                                                   if (var596 != 0) {
                                                      break label368;
                                                   }

                                                   AutoHitCrystal var597 = var392;
                                                   AutoHitCrystal var393 = var597;
                                                   ModeSetting var239 = var393.h;
                                                   String var681 = (String)var239.aReturningObject();
                                                   String var241 = "Infinite";
                                                   String var240 = var681;
                                                   boolean var598 = var240.equals(var241);
                                                   if (!var598) {
                                                      break label367;
                                                   }
                                                }

                                                AutoHitCrystal var599 = this;
                                                var394 = var599;
                                             }

                                             Object[] var245 = new Object[]{22065044672978L};
                                             AutoHitCrystal var244 = var394;
                                             var244.kReturningVoid(var245);
                                             int var600 = var42;
                                             if (var600 == 0) {
                                                return;
                                             }
                                          }

                                          AutoHitCrystal var601 = this;
                                          var395 = var601;
                                       }

                                       Object[] var248 = new Object[]{126290808879192L};
                                       AutoHitCrystal var247 = var395;
                                       var247.aReturningVoid(var248);
                                       return;
                                    }
                                 }

                                 int var603 = var42;
                                 AutoHitCrystal var602 = this;
                                 var399 = var602;
                                 AutoHitCrystal var396 = var602;
                                 if (var603 != 0) {
                                    break label602;
                                 }

                                 BooleanSetting var249 = var396.j;
                                 Object var604 = var249.aReturningObject();
                                 var397 = var604;
                              }

                              Boolean var251 = (Boolean)var397;
                              var398 = var251;
                           }

                           boolean var605 = var398;
                           if (!var605) {
                              return;
                           }

                           var399 = this;
                        }

                        Object[] var253 = new Object[]{var1, 137799952172272L};
                        AutoHitCrystal var252 = var399;
                        var252.jReturningVoid(var253);
                        int var606 = var42;
                        if (var606 == 0) {
                           return;
                        }
                     }

                     ElapsedTimer var682 = this.k;
                     Object[] var255 = new Object[]{this.i, 130913203968635L};
                     ElapsedTimer var254 = var682;
                     boolean var683 = var254.bReturningBoolean(var255);
                     int var608 = var42;
                     boolean var607 = var683;
                     boolean var402 = var607;
                     boolean var400 = var607;
                     if (var608 == 0) {
                        boolean var609 = var400;
                        boolean var401 = var609;
                        boolean var610 = var401;
                        if (!var610) {
                           return;
                        }

                        BooleanSetting var258 = this.g;
                        Boolean var259 = (Boolean)var258.aReturningObject();
                        var402 = var259;
                     }

                     boolean var611 = var402;
                     label409:
                     if (var611) {
                        int var613 = var42;
                        PlayerEntity var612 = var43;
                        PlayerEntity var405 = var612;
                        PlayerEntity var403 = var612;
                        if (var613 == 0) {
                           PlayerEntity var614 = var403;
                           PlayerEntity var404 = var614;
                           PlayerEntity var615 = var404;
                           if (var615 == null) {
                              break label409;
                           }

                           var405 = var43;
                        }

                        PlayerEntity var262 = var405;
                        int var616 = var262.hurtTime;
                        if (var616 != 0) {
                           return;
                        }
                     }

                     AutoHitCrystal var419;
                     label607: {
                        boolean var418;
                        label401: {
                           MinecraftClient var264 = b;
                           HitResult var265 = var264.crosshairTarget;
                           Type var684 = var265.getType();
                           int var618 = var42;
                           Type var617 = var684;
                           Object var417 = var617;
                           Type var406 = var617;
                           if (var618 == 0) {
                              Type var620 = Type.ENTITY;
                              Type var619 = var406;
                              if (var619 == var620) {
                                 EntityHitResult var267 = (EntityHitResult)var44;
                                 var683 = var267.getEntity() instanceof EndCrystalEntity;
                                 int var622 = var42;
                                 boolean var621 = var683;
                                 var418 = var621;
                                 boolean var407 = var621;
                                 if (var622 != 0) {
                                    break label401;
                                 }

                                 boolean var623 = var407;
                                 boolean var408 = var623;
                                 boolean var624 = var408;
                                 if (var624) {
                                    AutoHitCrystal var415;
                                    label609: {
                                       boolean var414;
                                       BooleanSetting var270 = this.e;
                                       Boolean var271 = (Boolean)var270.aReturningObject();
                                       var683 = var271;
                                       int var626 = var42;
                                       boolean var625 = var683;
                                       var414 = var625;
                                       boolean var409 = var625;
                                       label384:
                                       if (var626 == 0) {
                                          boolean var627 = var409;
                                          boolean var410 = var627;
                                          boolean var628 = var410;
                                          if (var628) {
                                             EntityHitResult var274 = (EntityHitResult)var44;
                                             Entity var275 = var274.getEntity();
                                             Object[] var276 = new Object[]{var275.getBlockPos(), 108898817732228L};
                                             var683 = DroppedItemUtil.aReturningBoolean(var276);
                                             int var630 = var42;
                                             boolean var629 = var683;
                                             var414 = var629;
                                             boolean var411 = var629;
                                             if (var630 != 0) {
                                                break label384;
                                             }

                                             boolean var631 = var411;
                                             boolean var412 = var631;
                                             boolean var632 = var412;
                                             if (var632) {
                                                return;
                                             }
                                          }

                                          EntityHitResult var279 = (EntityHitResult)var44;
                                          Object[] var280 = new Object[]{var279.getEntity(), 114267283224552L};
                                          ItemUseUtil.aReturningVoid(var280);
                                          int var634 = var42;
                                          AutoHitCrystal var633 = this;
                                          var415 = var633;
                                          AutoHitCrystal var413 = var633;
                                          if (var634 != 0) {
                                             break label609;
                                          }

                                          ModeSetting var281 = var413.h;
                                          String var688 = (String)var281.aReturningObject();
                                          String var283 = "Infinite";
                                          String var282 = var688;
                                          boolean var635 = var282.equals(var283);
                                          var414 = var635;
                                       }

                                       boolean var636 = var414;
                                       if (var636) {
                                          this.l = 5;
                                          MinMaxSetting var689 = this.f;
                                          Object[] var286 = new Object[]{127318019014223L};
                                          MinMaxSetting var285 = var689;
                                          var285.bReturningVoid(var286);
                                          MinMaxSetting var690 = this.i;
                                          Object[] var288 = new Object[]{127318019014223L};
                                          MinMaxSetting var287 = var690;
                                          var287.bReturningVoid(var288);
                                          ElapsedTimer var691 = this.k;
                                          Object[] var290 = new Object[]{42835128969216L};
                                          ElapsedTimer var289 = var691;
                                          var289.aReturningVoid(var290);
                                          int var637 = var42;
                                          if (var637 == 0) {
                                             return;
                                          }
                                       }

                                       AutoHitCrystal var638 = this;
                                       var415 = var638;
                                    }

                                    Object[] var294 = new Object[]{126290808879192L};
                                    AutoHitCrystal var293 = var415;
                                    var293.aReturningVoid(var294);
                                    return;
                                 }
                              }

                              int var640 = var42;
                              AutoHitCrystal var639 = this;
                              var419 = var639;
                              AutoHitCrystal var416 = var639;
                              if (var640 != 0) {
                                 break label607;
                              }

                              BooleanSetting var295 = var416.j;
                              Object var641 = var295.aReturningObject();
                              var417 = var641;
                           }

                           Boolean var297 = (Boolean)var417;
                           var418 = var297;
                        }

                        boolean var642 = var418;
                        if (!var642) {
                           return;
                        }

                        var419 = this;
                     }

                     Object[] var299 = new Object[]{var1, 137799952172272L};
                     AutoHitCrystal var298 = var419;
                     var298.jReturningVoid(var299);
                     return;
                  }

                  var355 = 0;
                  break label520;
               }

               a = var366;
               return;
            }

            a = var359;
            return;
         }

         a = dev.prestige.recovery.SourceSupport.asBoolean(var355);
      }
   }

   private void jReturningVoid(Object[] var1) {
      PlayerUpdateEvent var4;
      long var5;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      int var21;
      BlockPos var22;
      long var203;
      label114: {
         var4 = (PlayerUpdateEvent)var1[0];
         long var2 = (Long)var1[1];
         var203 = 13045796692584L ^ var2;
         var5 = var203 ^ 4763755077312L;
         var7 = var203 ^ 23654540249116L;
         var9 = var203 ^ 5785093085399L;
         var11 = var203 ^ 88494303448728L;
         var13 = var203 ^ 90139392374121L;
         var15 = var203 ^ 108405243426634L;
         var17 = var203 ^ 1325919433973L;
         var19 = var203 ^ 19128038691184L;
         int var10000 = Event.bReturningInt();
         var22 = null;
         var21 = var10000;
         MinecraftClient var37 = b;
         int var162 = var21;
         HitResult var161 = var37.crosshairTarget;
         HitResult var145 = var161;
         HitResult var144 = var161;
         if (var162 == 0) {
            HitResult var38 = var144;
            Type var204 = var38.getType();
            Type var164 = Type.BLOCK;
            Type var163 = var204;
            if (var163 != var164) {
               break label114;
            }

            MinecraftClient var40 = b;
            HitResult var165 = var40.crosshairTarget;
            var145 = var165;
         }

         BlockHitResult var42 = (BlockHitResult)var145;
         var22 = var42.getBlockPos();
      }

      BlockPos var166 = var22;
      label107:
      if (var166 != null) {
         MinecraftClient var43 = b;
         int var168 = var21;
         ClientWorld var167 = var43.world;
         ClientWorld var148 = var167;
         ClientWorld var146 = var167;
         if (var168 == 0) {
            ClientWorld var169 = var146;
            ClientWorld var147 = var169;
            BlockPos var46 = var22;
            ClientWorld var45 = var147;
            BlockState var47 = var45.getBlockState(var46);
            Block var205 = var47.getBlock();
            Block var171 = Blocks.OBSIDIAN;
            Block var170 = var205;
            if (var170 != var171) {
               break label107;
            }

            MinecraftClient var52 = b;
            var148 = var52.world;
         }

         ClientWorld var53 = var148;
         Iterable var54 = var53.getEntities();
         Iterator var23 = var54.iterator();

         while (true) {
            Iterator var55 = var23;
            boolean var172 = var55.hasNext();
            if (!var172) {
               break;
            }

            Iterator var56 = var23;
            Entity var24 = (Entity)var56.next();
            int var174 = var21;
            Entity var173 = var24;
            Entity var150 = var173;
            Entity var149 = var173;
            if (var174 == 0) {
               boolean var175 = var149 instanceof EndCrystalEntity;
               if (!var175) {
                  int var176 = var21;
                  if (var176 == 0) {
                     continue;
                  }
               }

               var150 = var24;
            }

            Object[] var59 = new Object[]{var150, var17};
            Vec3d var25 = RaycastUtil.aReturningVec3d(var59);
            BlockPos var60 = var22;
            BlockPos var61 = var60.up();
            Vec3d var63 = var61.toCenterPos();
            Vec3d var62 = var25;
            double var224;
            int var177 = (var224 = var62.distanceTo(var63) - 1.0) == 0.0 ? 0 : (var224 < 0.0 ? -1 : 1);
            label94:
            if (var177 < 0) {
               Entity var64 = var24;
               Box var26 = var64.getBoundingBox();
               MinecraftClient var65 = b;
               ClientPlayerEntity var66 = var65.player;
               Vec3d var27 = var66.getEyePos();
               Box var67 = var26;
               Vec3d var68 = var27;
               double var206 = var67.minX - var68.x;
               Vec3d var69 = var27;
               Box var70 = var26;
               double var73 = var69.x - var70.maxX;
               double var77 = Math.max(var71, var73);
               double var75 = var206;
               double var28 = Math.max(var75, var77);
               Box var79 = var26;
               Vec3d var80 = var27;
               var206 = var79.minY - var80.y;
               Vec3d var81 = var27;
               Box var82 = var26;
               double var85 = var81.y - var82.maxY;
               double var89 = Math.max(var83, var85);
               double var87 = var206;
               double var30 = Math.max(var87, var89);
               Box var91 = var26;
               Vec3d var92 = var27;
               var206 = var91.minZ - var92.z;
               Vec3d var93 = var27;
               Box var94 = var26;
               double var97 = var93.z - var94.maxZ;
               double var101 = Math.max(var95, var97);
               double var99 = var206;
               double var32 = Math.max(var99, var101);
               double var103 = var28 * var28 + var30 * var30 + var32 * var32;
               double var34 = Math.sqrt(var103);
               double var225;
               int var209 = (var225 = var34 - 2.7F) == 0.0 ? 0 : (var225 < 0.0 ? -1 : 1);
               int var179 = var21;
               int var178 = var209;
               int var152 = var178;
               int var151 = var178;
               if (var179 == 0) {
                  int var180 = var151;
                  if (var180 > 0) {
                     break label94;
                  }

                  BooleanSetting var106 = this.e;
                  Boolean var107 = (Boolean)var106.aReturningObject();
                  byte var181 = ((byte)(((java.lang.Boolean)(var107)).booleanValue() ? 1 : 0));
                  var152 = var181;
               }

               label83: {
                  int var183 = var21;
                  int var182 = var152;
                  int var154 = var182;
                  int var153 = var182;
                  if (var183 == 0) {
                     int var184 = var153;
                     if (var184 == 0) {
                        break label83;
                     }

                     Entity var110 = var24;
                     Object[] var111 = new Object[]{var110.getBlockPos(), var7};
                     byte var185 = ((byte)((DroppedItemUtil.aReturningBoolean(var111)) ? 1 : 0));
                     var154 = var185;
                  }

                  int var186 = var154;
                  if (var186 != 0) {
                     int var187 = var21;
                     if (var187 == 0) {
                        continue;
                     }
                  }
               }

               AutoHitCrystal var160;
               label120: {
                  Vec3d var114 = var25;
                  float var210 = (float)var114.x;
                  Vec3d var115 = var25;
                  float var10001 = (float)(var115.y + 0.45F);
                  Vec3d var116 = var25;
                  float var10002 = (float)var116.z;
                  Object[] var10005 = new Object[]{null, null, null, var13};
                  var10005[2] = var10002;
                  var10005[1] = var10001;
                  var10005[0] = var210;
                  Object[] var117 = var10005;
                  Rotation var36 = RotationUtil.bReturningdx_C0210(var117);
                  Object[] var119 = new Object[0];
                  Rotation var118 = var36;
                  Object[] var121 = new Object[]{var118.bReturningFloat(var119)};
                  PlayerUpdateEvent var120 = var4;
                  var120.cReturningVoid(var121);
                  Object[] var122 = new Object[]{var24, var19};
                  ItemUseUtil.aReturningVoid(var122);
                  ModeSetting var123 = this.h;
                  String var211 = (String)var123.aReturningObject();
                  short var216 = 16006;
                  long var220 = 847682296103260293L ^ var203;
                  String var125 = "Infinite";
                  String var124 = var211;
                  byte var212 = ((byte)((var124.equals(var125)) ? 1 : 0));
                  int var189 = var21;
                  byte var188 = var212;
                  int var157 = var188;
                  byte var155 = var188;
                  if (var189 == 0) {
                     byte var190 = var155;
                     if (var190 != 0) {
                        short var219 = 19387;
                        long var223 = 880642287009672136L ^ var203;
                        this.l = 5;
                        MinMaxSetting var214 = this.f;
                        Object[] var128 = new Object[]{var9};
                        MinMaxSetting var127 = var214;
                        var127.bReturningVoid(var128);
                        ElapsedTimer var215 = this.k;
                        Object[] var130 = new Object[]{var11};
                        ElapsedTimer var129 = var215;
                        var129.aReturningVoid(var130);
                        return;
                     }

                     int var192 = var21;
                     AutoHitCrystal var191 = this;
                     var160 = var191;
                     AutoHitCrystal var156 = var191;
                     if (var192 != 0) {
                        break label120;
                     }

                     int var193 = var156.l;
                     var157 = var193;
                  }

                  short var217 = 8836;
                  long var221 = 217703274042639094L ^ var203;
                  byte var195 = 6;
                  int var194 = var157;
                  if (var194 != var195) {
                     int var197 = var21;
                     AutoHitCrystal var196 = this;
                     var160 = var196;
                     AutoHitCrystal var158 = var196;
                     if (var197 != 0) {
                        break label120;
                     }

                     AutoHitCrystal var198 = var158;
                     AutoHitCrystal var159 = var198;
                     ModeSetting var134 = var159.h;
                     String var213 = (String)var134.aReturningObject();
                     short var218 = 982;
                     long var222 = 4567244400037686738L ^ var203;
                     String var136 = "Double Tap";
                     String var135 = var213;
                     boolean var199 = var135.equals(var136);
                     if (var199) {
                        Object[] var139 = new Object[]{var15};
                        AutoHitCrystal var138 = this;
                        var138.kReturningVoid(var139);
                        int var200 = var21;
                        if (var200 == 0) {
                           return;
                        }
                     }
                  }

                  AutoHitCrystal var201 = this;
                  var160 = var201;
               }

               Object[] var143 = new Object[]{var5};
               AutoHitCrystal var142 = var160;
               var142.aReturningVoid(var143);
               return;
            }

            int var202 = var21;
            if (var202 != 0) {
               break;
            }
         }

         return;
      }

      Object[] var50 = new Object[]{var5};
      AutoHitCrystal var49 = this;
      var49.aReturningVoid(var50);
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 13045796692584L ^ var2;
      long var4 = var2 ^ 118779811876341L;
      long var6 = var2 ^ 62918210149306L;
      MinMaxSetting var10000 = this.i;
      Object[] var9 = new Object[]{var4};
      MinMaxSetting var8 = var10000;
      var8.bReturningVoid(var9);
      var10000 = this.f;
      Object[] var11 = new Object[]{var4};
      MinMaxSetting var10 = var10000;
      var10.bReturningVoid(var11);
      this.l++;
      ElapsedTimer var16 = this.k;
      Object[] var13 = new Object[]{var6};
      ElapsedTimer var12 = var16;
      var12.aReturningVoid(var13);
   }

   private static void lambda$onMotionUpdate$2(HitResult var0) {
      long var10001 = 108797592578483L ^ 115239953623446L;
      Object[] var5 = new Object[]{(BlockHitResult)var0, 11253043183653L};
      ItemUseUtil.aReturningBoolean(var5);
   }

   private static void lambda$onMotionUpdate$1(HitResult var0) {
      long var10001 = 126696972257774L ^ 133070932068811L;
      Object[] var5 = new Object[]{(BlockHitResult)var0, 11253043183653L};
      ItemUseUtil.aReturningBoolean(var5);
   }

   private boolean lambda$new$0(Float var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.h;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Double Tap";
      String var6 = var10000;
      byte var25 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var18 = var4;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 != 0) {
         byte var19 = var12;
         if (var19 == 0) {
            ModeSetting var9 = this.h;
            var10000 = (String)var9.aReturningObject();
            String var11 = "Infinite";
            String var10 = var10000;
            byte var27 = ((byte)((var10.equals(var11)) ? 1 : 0));
            int var21 = var4;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(43102581330862L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[6];
      String var17 = "\u007fÑ\u0092m¶õJZÕ7\u001fy£*JÝ\u00185\bz\u0090:Ä&§ÂQ\u0018ã+\u009a\u0010\bÝ\u001d\u007fÌ\u0015\u0012¾Á  \u0084©%;w)¸VU>ñÖ¯¸bÌÕ'\u0084ÐÄVÐ\f:Þ\u009a\u008e1xÏ\u0010òAz \u0016¡5DØ\u0002\u0086\u0098ä7/Ú";
      int var19 = "\u007fÑ\u0092m¶õJZÕ7\u001fy£*JÝ\u00185\bz\u0090:Ä&§ÂQ\u0018ã+\u009a\u0010\bÝ\u001d\u007fÌ\u0015\u0012¾Á  \u0084©%;w)¸VU>ñÖ¯¸bÌÕ'\u0084ÐÄVÐ\f:Þ\u009a\u008e1xÏ\u0010òAz \u0016¡5DØ\u0002\u0086\u0098ä7/Ú"
         .length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     n = var20;
                     o = new String[6];
                     s = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(43102581330862L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[6];
                     String var4 = "\nO\"y\rÜ·OcÄ\u001a\u0002G\u008b\u001cÛE`ý¡ \u0081{ë\fïº\u0090«¸\u0011!";
                     int var5 = "\nO\"y\rÜ·OcÄ\u001a\u0002G\u008b\u001cÛE`ý¡ \u0081{ë\fïº\u0090«¸\u0011!".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    q = var6;
                                    r = new Integer[6];
                                    a = dev.prestige.recovery.SourceSupport.asBoolean(0);
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u001f\fQ+\u0092¤${¾S$æ\u009a¡Ã'";
                                 var5 = "\u001f\fQ+\u0092¤${¾S$æ\u009a¡Ã'".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "H\u008cÇ¦\u0084Æ¤þÄåæx\\\u0018\u0088PP7²\u0012\u008fy\u00996 ìªù\u009b\u009eÍ¥v\bvÇ\u0004\u0018+×wUî\u001d9\u0019\u0005\\>#7ñ\u0086\u0084¿\u0099Ì";
                  var19 = "H\u008cÇ¦\u0084Æ¤þÄåæx\\\u0018\u0088PP7²\u0012\u008fy\u00996 ìªù\u009b\u009eÍ¥v\bvÇ\u0004\u0018+×wUî\u001d9\u0019\u0005\\>#7ñ\u0086\u0084¿\u0099Ì"
                     .length();
                  var16 = 24;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2201;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/d8", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d8",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1769;
      if (r[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = q[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])s.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d8", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         r[var3] = var15;
      }

      return r[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d8",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = u[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = t[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 17;
            yield var15;
         }
         case 1 -> {
            byte var16 = 31;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 52;
            yield var18;
         }
         case 4 -> {
            byte var19 = 53;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 0;
            yield var21;
         }
         case 7 -> {
            byte var22 = 55;
            yield var22;
         }
         case 8 -> {
            byte var23 = 61;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 49;
            yield var25;
         }
         case 11 -> {
            byte var26 = 38;
            yield var26;
         }
         case 12 -> {
            byte var27 = 11;
            yield var27;
         }
         case 13 -> {
            byte var28 = 5;
            yield var28;
         }
         case 14 -> {
            byte var29 = 13;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 62;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 56;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 59;
            yield var35;
         }
         case 21 -> {
            byte var36 = 6;
            yield var36;
         }
         case 22 -> {
            byte var37 = 33;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 63;
            yield var39;
         }
         case 25 -> {
            byte var40 = 24;
            yield var40;
         }
         case 26 -> {
            byte var41 = 43;
            yield var41;
         }
         case 27 -> {
            byte var42 = 25;
            yield var42;
         }
         case 28 -> {
            byte var43 = 7;
            yield var43;
         }
         case 29 -> {
            byte var44 = 26;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 46;
            yield var47;
         }
         case 33 -> {
            byte var48 = 34;
            yield var48;
         }
         case 34 -> {
            byte var49 = 10;
            yield var49;
         }
         case 35 -> {
            byte var50 = 9;
            yield var50;
         }
         case 36 -> {
            byte var51 = 40;
            yield var51;
         }
         case 37 -> {
            byte var52 = 57;
            yield var52;
         }
         case 38 -> {
            byte var53 = 14;
            yield var53;
         }
         case 39 -> {
            byte var54 = 45;
            yield var54;
         }
         case 40 -> {
            byte var55 = 16;
            yield var55;
         }
         case 41 -> {
            byte var56 = 3;
            yield var56;
         }
         case 42 -> {
            byte var57 = 47;
            yield var57;
         }
         case 43 -> {
            byte var58 = 15;
            yield var58;
         }
         case 44 -> {
            byte var59 = 36;
            yield var59;
         }
         case 45 -> {
            byte var60 = 58;
            yield var60;
         }
         case 46 -> {
            byte var61 = 51;
            yield var61;
         }
         case 47 -> {
            byte var62 = 21;
            yield var62;
         }
         case 48 -> {
            byte var63 = 28;
            yield var63;
         }
         case 49 -> {
            byte var64 = 19;
            yield var64;
         }
         case 50 -> {
            byte var65 = 2;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 18;
            yield var67;
         }
         case 53 -> {
            byte var68 = 32;
            yield var68;
         }
         case 54 -> {
            byte var69 = 27;
            yield var69;
         }
         case 55 -> {
            byte var70 = 30;
            yield var70;
         }
         case 56 -> {
            byte var71 = 50;
            yield var71;
         }
         case 57 -> {
            byte var72 = 29;
            yield var72;
         }
         case 58 -> {
            byte var73 = 54;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 37;
            yield var75;
         }
         case 61 -> {
            byte var76 = 35;
            yield var76;
         }
         case 62 -> {
            byte var77 = 41;
            yield var77;
         }
         default -> 23;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            u[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      t[0] = "~+2\\8!h+7\u0006+6\u007f`4\u0000'\"n'#\u0017l2v";
      t[1] = ")e\u000e(Xw\\E\u0005'I8=K\u000e,MbI";
      t[2] = boolean.class;
      u[2] = "java/lang/Boolean";
      t[3] = "M'=\u0013-\u0013F(,\\P\u000bU/%\u0015";
      t[4] = "!Q\\*@\u0002*^Me!\f!UI?";
      t[5] = "\r\u0007E\f|Q\u001b\u0007@VoF\fLCPcR\u001d\u000bTG(E/";
      t[6] = "qh&ZqOgh#\u0000bXp# \u0006nLad7\u0011%[Y";
      t[7] = "\u0017R7Q\u0003!br<^\u0012n\u0003|7U\u00164w";
      t[8] = ">@>Og=(@;\u0015t*?\u000b8\u0013x>.L/\u00043)b";
      t[9] = "#, x\u0011)(#17r$=.>\\G&,=\"pP+";
      t[10] = "\u0012\u0001G\u0019\u0016@\u0004\u0001BC\u0005W\u0013JAE\tC\u0002\rVRBQ3";
      t[11] = int.class;
      u[11] = "java/lang/Integer";
      t[12] = "H.hp\u0001QH.\u007f,\r^Re\u007f2\rKU\u0014.lX\u000e";
      t[13] = "\u0007\f1\u0012yp\u0007\f&Nu\u007f\u001dG&Puj\u001a6w\u000e !";
      t[14] = "Yg \u0014ZrYg7HV}C,7VVhD]e\r\u000e\"";
      t[15] = "F\u0000b/Z\u001dF\u0000usV\u0012\\KumV\u0007[:'6\u000eF";
      t[16] = "\u00030_O3H\u00030H\u0013?G\u0019{H\r?R\u001e\n\u001cUh";
      t[17] = "\tJ\bJXR\tJ\u001f\u0016T]\u0013\u0001\u001f\bTH\u0014pOU\u0005";
      t[18] = "\u001f4Io\\\u0001\u001f4^3P\u000e\u0005\u007f^-P\u001b\u0002\u000e\fy\u0001Z";
      t[19] = "8\u007f\u0002]4PM_\tR%\u001f,Q\u0002Y!EX";
      t[20] = void.class;
      u[20] = "java/lang/Void";
      t[21] = "\rfI\u0003]4\u001bfLYN#\f-O_B7\u001djXH\t 8";
      t[22] = "g>2\\A]\u0012\u001e9SP\u0012s\u00102XTH\u0007";
      t[23] = "XKAg;;FC[(F+F";
      t[24] = "TIxU\u000f(TIo\t\u0003'N\u0002o\u0017\u00032Is>H[eY@m\b\u0011\u001e\b\u0018<";
      t[25] = "K+\u001f7\u001f\f>\u000b\u00148\u000eC_\u0005\u001f3\n\u0019+";
      t[26] = "7\u0004\r\u0007tj7\u0004\u001a[xe-O\u001aExp*>K\u001a!";
      t[27] = double.class;
      u[27] = "java/lang/Double";
      t[28] = "dn\u0002omIoa\u0013 \u000eDzg";
      t[29] = "5\u001fu4\u0005\u00145\u001fbh\t\u001b/Tbv\t\u000e(%3,PM";
      t[30] = "\b\u001f</\u0016R\u0003\u0010-`zQ\r\u0012//V";
      t[31] = "TEZ9b6TEMen9N\u000eM{n,I\u007f\u001f%6h";
      t[32] = "+KkYu\t^k`VdF?ek]`\u001cK";
      t[33] = "\u0015\u001c\u0019lzh\u0015\u001c\u000e0vg\u000fW\u000e.vr\b&_q$9";
      t[34] = "i78\u001c\u0000\bi7/@\f\u0007s|/^\f\u0012t\r~\u0006^";
      t[35] = "{yC\u001d\u0015{eqYRrztjT\bT|";
      t[36] = ";~pLyo-~u\u0016jx:5v\u0010fl+ra\u0007-{\u001d";
      t[37] = "|\u001a(-\u007f<\t:#\"nsh4()j)\u001c";
      t[38] = "7&\\5g\u0002!&Yot\u00156mZix\u0001'*M~3\u0016+";
      t[39] = "LMr2\u001b\u0010ZMwh\b\u0007M\u0006tn\u0004\u0013\\AcyO\u0006q";
      t[40] = "er7\u001a\rq\u0010R<\u0015\u001c>q\\7\u001e\u0018d\u0005";
      t[41] = "\u001eg\u001b{;@\u001eg\f'7O\u0004,\f97Z\u0003]\\l`\u001c";
      t[42] = "cxTXAgcxC\u0004Mhy3C\u001aM}~B\u0016E\u0014";
      t[43] = "\u0001^\u001e\u0014/]\u0017^\u001bN<J\u0000\u0015\u0018H0^\u0011R\u000f_{J\u0004";
      t[44] = "II\u00055\t,<i\u000e:\u0018c]g\u00051\u001c9)";
      t[45] = "6 yWgL  |\rt[7k\u007f\u000bxO&,h\u001c3_a";
      t[46] = "/\u0004tVL(Z$\u007fY]g;*tRY=O";
      t[47] = "C.\u0015+\u001a;H!\u0004d}#L=\u0002(X2";
      t[48] = "#);b(#5)>8;4\"b=>7 3%*)|1&";
      t[49] = "Z81p{i/\u0018:\u007fj&N\u00161tn|:";
      t[50] = "UYJfZV yAiK\u0019AwJbOC5";
      t[51] = float.class;
      u[51] = "java/lang/Float";
      t[52] = "rQY\u0017\u0017\u0010\u0007qR\u0018\u0006_f\u007fY\u0013\u0002\u0005\u0012";
      t[53] = "d\u0002ifdTd\u0002~:h[~I~$hNy8/{0";
      t[54] = "SnDy\u0007\u0005&NOv\u0016JG@D}\u0012\u00103";
      t[55] = "r;]\u0007\u007f8\u0007\u001bV\bnwf\u0015]\u0003j-\u0012";
      t[56] = "w,\t[-,a,\f\u0001>;vg\u000f\u00072/g \u0018\u0010y?|";
      t[57] = "RC;hNg'c0g_(Fm;l[r2";
      t[58] = "~s \u0012\u001aS~s7N\u0016\\d87P\u0016IcIe\nB\r";
      t[59] = "\u0011r~+|a\u0011riwpn\u000b9iip{\fH86$8";
      t[60] = "\u001eA\u0018\u0004;S\u001eA\u000fX7\\\u0004\n\u000fF7I\u0003{X\u0019a";
      t[61] = "eiCS\u000f[\u0010IH\\\u001e\u0014qGCW\u001aN\u0005";
      t[62] = "\u0015Bf#_1\u0003BcyL&\u0014\t`\u007f@2\u0005Nwh\u000b%\b";
      t[63] = ";C\u0013\u001c`\\Nc\u0018\u0013q\u0013/m\u0013\u0018uI[";
      t[64] = "\u0015a!v($`A*y9k\u0001O!r=1u";
      t[65] = "pN\reEhfN\b?V\u007fq\u0005\u000b9Zk`B\u001c.\u0011{xB\u001e%K6DY\u001e8KqsN";
      t[66] = "tc\u0013v-.\u0001C\u0018y<a`M\u0013r8;\u0014";
      t[67] = "YWM^YdOWH\u0004JsX\u001cK\u0002FgI[\\\u0015\ruQ";
      t[68] = "\u001cP)h\u001a\u001cip\"g\u000bS\b~)l\u000f\t|";
      t[69] = "T6}0'x!\u0016v?67@\u0018}42m4";
      t[70] = "uZby|mcZg#ozt\u0011d%cneVs2({D";
      t[71] = "3#5LY\u0004F\u0003>CHK'\r5HL\u0011S";
      t[72] = "U$bHTtU$u\u0014X{Oou\nXnH\u001e%_\u000f+";
      t[73] = "xK\u001f5Zx\rk\u0014:K7le\u001f1Om\u0018";
      t[74] = "~\u00116wNV\u000b1=x_\u0019j?6s[C\u001e";
      t[75] = "V\u001c%\u0004\u001c\u0003#<.\u000b\rLB2%\u0000\t\u00166";
      t[76] = "'88\u0005LQR\u00183\n]\u001e3\u00168\u0001YDG";
      t[77] = "JAN(M;\u001b\u0002E.&lw\r[f\u001d|\u0019\u000f\u001dvD\u0005IOU/_kK\tEv&";
      t[78] = "J;d:XM\u0010:=r(\u0019K<`f\u007fN\u0011j>\nH\u001dJat0\u0012\u001c\u0013)";
      t[79] = "Z/a=x\rW4d}\u0004\u0017fvb:v\u0016\t?cx|\u0012f\"o9x\u0010_(g>o}";
      t[80] = "w%*q\u001f;v{,f#d&(umt3\u007fx-9#;! u;]68+q";
      t[81] = "y\u0017\u0000PHJi]\u0017XwHyB\u0001P \u001f#\u0015_<\u0015L|B\u0001SGBdK";
      t[82] = "\u0001J \u0018\u0017U\\I?\u001fmP\n_M\u0014\u0007Q\u000eK\"F\tI\u0007//\u001c\tX\u0007@}\u0012\u0011QcM'\u0012\u0000Q\f\u001f)\n\t5";
      t[83] = "$KJ)m\u0003-\u001d\u000f%\u0010\u0000*\u0007\u0014.|2}ENq,ev\u001d\u0011-*\u001b{\u0004\u001a)\u0010";
      t[84] = "|EK>5>'F\b0X>wUU44\f#\u0011\rbc[#\u0014Y:9>uX\u000bb2[|EK>5>'F\b0X";
      t[85] = "/L\u000b\u000e\u0015\"9UW\u0001~|$QW\u000b)+z\u0001\u000egG,}\u0000\u000f\u0018Np'\u0006Z";
      t[86] = "\u000b\u0013\u001dw` \u001d\nAx\u000bu\f\u001fEygGX^\u001b/\u000b)\f\u0007\u001a.6k\u000b\u0006Y\u001e";
      t[87] = "`JJ\u0002P\"t\u000b\u001fi\u0000L3Z\\\u001b\u0002#z[\u001e\u0011\u0006LgW_\u0015\u0004um_X\u0002i";
      t[88] = "JId>\u007f%]Z,4\u00129M^4>~\u000b\u001a\u001edc\"\\\u0019O0f\"a[H1%\u0012";
      t[89] = "\u0004`HNZ\u0012\n}\f\u001dd\u0005\u000eoK,_\rR!\u0007\\\u0016\u0000\u001fz7";
      t[90] = "3\u0005h\u0010q\u0001$\u0006|\u0012\u001eRK^h\nlS$\u0017iHfWK\u001ej\fy\u00011\u001ae\u0000e8";
      t[91] = "Ep\u001b\u0013-V\f}VH\u001dK\u0007cCIf&Ep\u001b\u0013-V\f}VH\u001d\u001f\u0013z\u0015\u001d ]\u0014{V-";
      t[92] = "?b\u0001#]&r'\u001dg/=\u0000`\td]?o)\b&W;\u00004\u0004gS99>\f`DT";
      t[93] = "\u0012\u0001\u0003$\u000eGO\u0002\u001c#t\\\t\u001e\u0012J\u0016M\u0014\t\n%DC\f\u0000n(\u001eC\u001d\u0000\u0001z\u0010[\u0014d";
      t[94] = "N!w\u0017\u001d\u0002^k`\u001f\"\u0000Ntv\u0017uW\u0014#+{@\u0004Ktv\u0014\u0012\nS}";
      t[95] = "T\u000fl\u0010h\u007fH\nm\u0012V|9IxV$}V\u0000y\u0014.y9OgK/jEMf\u00120\u0016";
      t[96] = "L\u0016-\u0019tl\u000fE8DM|1\u0012)]?~^[(\u001f5z1\u0012+Br%\fP,C1\u0015";
      t[97] = "\u0017#X6\u0015w\u00000\u0010<xk\u00104\b6\u0014YFsUnA\u000e\u001as\u0002+Bs\u0016+\u0007lx";
      t[98] = ";F\u001bWIH?\u0015[\u0014$HxX\u0002N_%:KZ\u0014\u0014UsF\u0017O$\u001clAT\u001a\u0019^k@\u0017*";
      t[99] = "x^\u0006g)3t\u0006\u0003 \u0013 ~\b\bqDw$XV\u001dq${\b\br#*c\u0001";
      t[100] = "I{\u000fc=\u007fE#\n$\u0007lO-\u0001uP;\u0015}\\\u0019ehJ-\u0001v7fR$";
      t[101] = "5\u0002C\u001clk?\u0015S\u0002\u0002{ER@\u0006p{*\u001bADz\u007fE\u0006M\u0005~}|\fE\u0002i\u0010";
      t[102] = "\u001fL{\u0003ds\u000f\u0006l\u000b[q\u001f\u0019z\u0003\f&EN&o9u\u001a\u0019z\u0000k{\u0002\u0010";
      t[103] = "8\tZ[Tgc\u0011\u0018\nde2\u001eA\u000735hH\u0014Sdb3\bF\u0015\b5=\u0013T";
      t[104] = "A#ti\\d]&ukbd,e`/\u0010fC,am\u001ab,1m,\u001e`\u0015;e+\t\r";
      t[105] = "\u007f\u0010|\b\u0014Xi\t \u0007\u007f\u0006t\r \r(Q*^yaFQ,\u0004~\u000f\u001d\u0018d\t4";
      t[106] = "WB[n%0WOGp-R\u000bCXp#>9\u0017\u001b/thnJFjy)\u0011\\]t9R";
      t[107] = "M\u0015D}\u001f5[\f\u0018rtkF\b\u0018x#<\u0019UC\u0014\beY]\u001enN=\\\u0015";
      t[108] = "\u0019^P@<'B]\u0013NQ'\u0012NNJ=\u0015F\n\u0016\u001dmB\u0019^P@<'B]\u0013NQ";
      t[109] = "\u0011KKJ==\u0001\u0001\\B\u0002?\u0011\u001eJJUhKI\u0015&`;\u0014\u001eJI25\f\u0017";
      t[110] = "ae<Y\u0005\u0018:,tTOv=1y]X\u001a\u000fe:\u0002\u000fMX<o]\u000f\u0006bfn\u0004Gv";
      t[111] = "Ru\n\u00104\u001dF4_{`s\u0001e\u001c\tf\u001cHd^\u0003bs\u0001g\u0003D=NC`\u0002\u0007\r";
      t[112] = "F4#.\u0002+\r7)>B\u0010\u001f\u000f /\u0001b\u0014`i.Ch\u0010\u000f -\u001e/O2b*\u001fl\u007f";
      t[113] = "f'\u0003]xp1'R[#\n4NZHcx4!\u0013I!r0NZJ|5os\u0018M}v_";
      t[114] = "R\u0007S+] FF\u0006@\rN\u0001\u0017E2\u000f!H\u0016\u00078\u000bN\u0001\u0015Z\u007fTsC\u0012[<d";
      t[115] = "fg5V\\t-d?F\u001cO>\\6W_=43\u007fV\u001d70\\6U@poatRA3_";
      t[116] = "%a[pGVnbQ`\u0007muZXqD\u001fw5\u0011p\u0006\u0015sZXs[R,g\u001atZ\u0011\u001c";
      t[117] = "\u0019\u0014\u0019G\u001fV\u000e\u0007QMrJ\u001e\u0003IG\u001exMF\u0010\u001dr\u0016\u001e\u001b\u0016\u0010OT\u0019\u001aU ";
      t[118] = "PO\u0003\u0000hT\u001d\n\u001fD\u001aLoK\u0014ZcZ\u0013I\u0015\u0003|&";
      t[119] = "EtJdVQ\u0016q\u0012}-PA6\u0013{Ab\u0013{K--\\L1\u0010bA\u000bB*\u0002\u001c";
      t[120] = "Rsm\u007f=.\u0019pgo}\u0015\bHn~>g\u0000''\u007f|m\u0004Hn|!*[u,{ ik";
      t[121] = "y^\u0016yj.|\r\b1>\u0013.\u0003\u001c,kD~XJu\u0007,0\u0004\b4{.1]\u0017";
      t[122] = "vJ\u0003yV!&I\u00189('v;^m\u0019~(K\u0017`T%\u0018U\u0014eR>y\u0005\u0017~\u0012@";
      t[123] = "!bg2\u0014;l'{vf\"\u001efph\u001f5bdq1\u0000I";
      t[124] = "HYwYjbE\u0003+\b\u00148KT(_}4rZ(OyR\u0015^(\r$oWY)N\u0014";
      t[125] = "q62qlWo'a \u0001X\u000bl2fsYd%3$y]\u000bl0y>\u00026.7x}2";
      t[126] = "\u0002O\\Lo\f\u0014TB\f\u0014\u0016\u000bQF\u0016x$[\u001d\u001c@\u0014\u0012^HJNx\u0002\u0014_Bq";
      t[127] = "\u0019)M\u0013\tT\u00142HSuM%pN\u0014\u0007OJ9OV\rK%uA\u0003\tXUxZ\u0006I$";
      t[128] = " |n#.j+:o'J=\u001b:zntdksw#/T";
      t[129] = "7!T+4\"!:JkO8>?Nq#\ni\u007f\u0013/r]5/P{\"8n,\u0013uO";
      t[130] = ")D0\u0016a8%\u001c5Q[+/\u0012>\u0000\f|uBbl9/*\u0012>\u0003k!2\u001b";
      t[131] = "{J'DC\u0018?\u0012~^O&,u~K\u0005T)\u001a7JG^-u~I\u001a\u0019rH<N\u001bZB";
      t[132] = "\u0003\u00123Y\u0018G\u0013X$Q'E\u0003G2Yp\u0012Y\u0010k5EA\u0006G2Z\u0017O\u001eN";
      t[133] = "^F \rHhH_|\u0002#6U[|\bta\u000b\f$dI3\u0004Qu\u001d^ L[";
      t[134] = "(S6%\u0017C6BetzOR\t62\bM=@7p\u0002IR];1\u0006KkW36\u0011&";
      t[135] = "6\u000ftm@#}\f~}\u0000\u0018m4wlCjd[>m\u0001``4wn\\'?\t5i]d\u000f";
      t[136] = "\u0013@\u0005{(nIA\\3X:\u0012G\u0001'\u000fmH\u0011\\K8>\u0013\u001a\u0015qb?JR";
      t[137] = "\u0014\u001dc5\bGO\u0005!d8E\u001e\nxio\u001bD_%\u0005QK\u0004\u0004bi\u0006E\u001f\u0016";
      t[138] = "q_'i'\u0000-_}b8m/n$=)\ruP`ep\u0017y";
      t[139] = "\u00049\u0003K\u0015S\u0014s\u0014C*Q\u0004l\u0002K}\u0006^;Z'HU\u0001l\u0002H\u001a[\u0019e";
      t[140] = "\u0005)n^Sc\u000b4*\rmr\u000b-WQ\u001dnbo|XR\"_-{Y\u0011\u0012";
      t[141] = "@)q3\u0004\"Lqtt>:Jn{.R\b\u001e*!s>8\u001cxasC4D}&I\\5C\u007f\u007f&\u000e;[v\u001b";
      t[142] = "\u0005 q A'Tcz&*{8kwgXrW\"v%Rv8?zdVt\u00015rcA\u0019";
      t[143] = ":\u001b*\u0019\u0018<}\b5G)e,\u001a/GEWxYp\u001f\u0016\u0000'\n1MDe|\trC)";
      t[144] = "({)\\\u0013_\u007f{xZH%~\u0012pI\bWz}9HJ]~\u0012pK\u0017\u001a!/2L\u0016Y\u0011";
      t[145] = "\u001a\\GJxf\\\u0004B\u0002\u001ay\u000b@Y\u0015vKV\u0007\u0003J\u001az\nBT\u001f\u007f!\t\u0001Zry,X\\D\u0014pz\u001dP9";
      t[146] = "\u001co+V\u000b\r\u0011v R1\u0016@u.U]$\u001d2~\u00031\u001aMr-L]MCi?2";
      t[147] = "=1\u0015*\u000fV*h\u001b\u007fq\u0001Ci\no\u0003\u0003, \u000b-\t\u0007C7^~\u000bR>;\u0006{Lh";
      t[148] = "pC.~\u0018Bu\u001006L\u007f,\u00125/\u0012\u0013\u001eBvtD\u007f-\u001d3r\u000e\u0000;\u0006-2u\r7\u00198 \u0015O&\u001eyO";
      t[149] = "o]M2\u0016|&\u0013\u0014vrcc\f\u000f#\u000eeea\u00125\r`!\u0010\u001c(I3\u001f";
      t[150] = "\u0002^c9\u0006*I]i)F\u0011_e`8\u0005cP\n)9GiTe`:\u001a.\u000bX\"=\u001bm;";
      t[151] = "\u0011+sbu\u0004\u00068;h\u0018\u0018\u0016<#bt*Ex\u007f:\u0018\u0014Ey;~|G@!\"\u0005";
      t[152] = "\u007f\u000ef\u0010'\u0004$\b$P'i/bc\u0007#\u001b-\r*\u0006a\u0011)bcT?X+_f\u0007!\u0010\u007fb";
      t[153] = "}U\f?QnyZ\u0000#h~\u0004\u0001\u001e#\u001a\u007fkH\u001fa\u0010{\u0004J\u000f>\u0019{d\b\u001e9X\u0014";
      t[154] = "\u001eg0\u0016[IEds\u00186I\u0015w.\u001cZ{D5sF\u0006,\u001f0$\u0001\fQ\u0013h!F6";
      t[155] = "Ubz5>O\u0004!q3U\u0012h)|r'\u001a\u0007`}0-\u001eh}qq)\u001cQwyv>q";
      t[156] = "7~L'&\u001apmSy\u0017C!\u007fIy{qu<\u0016./&u>EwvC#r\u0017/}&";
      t[157] = "'\u0001`\u00020<aYeJR#6\u001d~]>\u0011bQ'\u0003hF+]&B68b\u0013\u007f\u0006R";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = t[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(u[var4]);
            t[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = t[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            t[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  t[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(347715397604650L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = t[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  t[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(347715397604650L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        t[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(347715397604650L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 235;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 69;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 209;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 251;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 102;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 81;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 235;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 69;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 209;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d8",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoHitCrystal var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/d8;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/d8", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoHitCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding2(HitResult var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Lnet/minecraft/util/hit/HitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/d8", "lambda$onMotionUpdate$1", "(Lnet/minecraft/util/hit/HitResult;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((HitResult)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding3(HitResult var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Lnet/minecraft/util/hit/HitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/d8", "lambda$onMotionUpdate$2", "(Lnet/minecraft/util/hit/HitResult;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((HitResult)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
