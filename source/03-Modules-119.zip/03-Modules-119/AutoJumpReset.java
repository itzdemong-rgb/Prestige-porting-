package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.KeyBindingUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;

public class AutoJumpReset extends Module {
   private FloatSetting a;
   private static final long k = 92829908885302L;
   private static final Object[] l = new Object[39];
   private static final String[] m = new String[39];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 43992342980944L ^ 92702059748492L;
      int var10000 = Event.cReturningInt();
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      DamageSource var7 = var9.getRecentDamageSource();
      int var6 = var10000;
      int var63 = var6;
      MinecraftClient var62 = b;
      MinecraftClient var46 = var62;
      MinecraftClient var45 = var62;
      if (var63 != 0) {
         MinecraftClient var10 = var45;
         Screen var64 = var10.currentScreen;
         if (var64 != null) {
            return;
         }

         MinecraftClient var65 = b;
         var46 = var65;
      }

      MinecraftClient var13 = var46;
      ClientPlayerEntity var14 = var13.player;
      byte var96 = ((byte)((var14.isBlocking()) ? 1 : 0));
      int var67 = var6;
      boolean var66 = dev.prestige.recovery.SourceSupport.asBoolean(var96);
      boolean var48 = var66;
      boolean var47 = var66;
      if (var67 != 0) {
         boolean var68 = var47;
         if (var68) {
            return;
         }

         MinecraftClient var16 = b;
         ClientPlayerEntity var17 = var16.player;
         boolean var69 = var17.isUsingItem();
         var48 = var69;
      }

      int var71 = var6;
      boolean var70 = var48;
      boolean var50 = var70;
      boolean var49 = var70;
      if (var71 != 0) {
         boolean var72 = var49;
         if (var72) {
            return;
         }

         MinecraftClient var20 = b;
         ClientPlayerEntity var21 = var20.player;
         boolean var73 = var21.isTouchingWater();
         var50 = var73;
      }

      boolean var74 = var50;
      if (!var74) {
         int var76 = var6;
         DamageSource var75 = var7;
         DamageSource var53 = var75;
         DamageSource var51 = var75;
         if (var76 != 0) {
            DamageSource var77 = var51;
            DamageSource var52 = var77;
            DamageSource var78 = var52;
            if (var78 == null) {
               return;
            }

            var53 = var7;
         }

         DamageSource var25 = var53;
         var96 = ((byte)((var25.getAttacker() instanceof PlayerEntity) ? 1 : 0));
         int var80 = var6;
         byte var79 = var96;
         byte var55 = var79;
         byte var54 = var79;
         if (var80 != 0) {
            byte var81 = var54;
            if (var81 == 0) {
               return;
            }

            MinecraftClient var27 = b;
            ClientPlayerEntity var28 = var27.player;
            var55 = ((byte)((var28.isOnGround()) ? 1 : 0));
         }

         int var83 = var6;
         byte var82 = var55;
         int var57 = var82;
         byte var56 = var82;
         if (var83 != 0) {
            byte var84 = var56;
            if (var84 == 0) {
               return;
            }

            MinecraftClient var30 = b;
            ClientPlayerEntity var31 = var30.player;
            int var85 = var31.hurtTime;
            var57 = var85;
         }

         int var87 = var6;
         int var86 = var57;
         int var59 = var86;
         int var58 = var86;
         if (var87 != 0) {
            MinecraftClient var33 = b;
            ClientPlayerEntity var34 = var33.player;
            int var89 = var34.maxHurtTime;
            int var88 = var58;
            if (var88 != var89) {
               return;
            }

            MinecraftClient var36 = b;
            ClientPlayerEntity var37 = var36.player;
            byte var90 = ((byte)((var37.isOnFire()) ? 1 : 0));
            var59 = var90;
         }

         int var92 = var6;
         int var91 = var59;
         int var61 = var91;
         int var60 = var91;
         if (var92 != 0) {
            int var93 = var60;
            if (var93 != 0) {
               return;
            }

            Random var40 = RandomUtil.a;
            float var98 = var40.nextFloat();
            FloatSetting var41 = this.a;
            Float var42 = (Float)var41.aReturningObject();
            float var99;
            int var94 = (var99 = var98 - var42 / 100.0F) == 0.0F ? 0 : (var99 < 0.0F ? -1 : 1);
            var61 = var94;
         }

         int var95 = var61;
         if (var95 <= 0) {
            Object[] var44 = new Object[]{136670736201180L};
            KeyBindingUtil.aReturningVoid(var44);
         }
      }
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 107025016641677L;
      Object[] var6 = new Object[]{var4};
      KeyBindingUtil.bReturningVoid(var6);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 51;
            yield var15;
         }
         case 1 -> {
            byte var16 = 13;
            yield var16;
         }
         case 2 -> {
            byte var17 = 22;
            yield var17;
         }
         case 3 -> {
            byte var18 = 15;
            yield var18;
         }
         case 4 -> {
            byte var19 = 62;
            yield var19;
         }
         case 5 -> {
            byte var20 = 41;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 16;
            yield var22;
         }
         case 8 -> {
            byte var23 = 12;
            yield var23;
         }
         case 9 -> {
            byte var24 = 20;
            yield var24;
         }
         case 10 -> {
            byte var25 = 36;
            yield var25;
         }
         case 11 -> {
            byte var26 = 3;
            yield var26;
         }
         case 12 -> {
            byte var27 = 58;
            yield var27;
         }
         case 13 -> {
            byte var28 = 60;
            yield var28;
         }
         case 14 -> {
            byte var29 = 43;
            yield var29;
         }
         case 15 -> {
            byte var30 = 54;
            yield var30;
         }
         case 16 -> {
            byte var31 = 31;
            yield var31;
         }
         case 17 -> {
            byte var32 = 6;
            yield var32;
         }
         case 18 -> {
            byte var33 = 53;
            yield var33;
         }
         case 19 -> {
            byte var34 = 33;
            yield var34;
         }
         case 20 -> {
            byte var35 = 32;
            yield var35;
         }
         case 21 -> {
            byte var36 = 56;
            yield var36;
         }
         case 22 -> {
            byte var37 = 17;
            yield var37;
         }
         case 23 -> {
            byte var38 = 27;
            yield var38;
         }
         case 24 -> {
            byte var39 = 35;
            yield var39;
         }
         case 25 -> {
            byte var40 = 39;
            yield var40;
         }
         case 26 -> {
            byte var41 = 26;
            yield var41;
         }
         case 27 -> {
            byte var42 = 23;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 14;
            yield var44;
         }
         case 30 -> {
            byte var45 = 18;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 57;
            yield var47;
         }
         case 33 -> {
            byte var48 = 46;
            yield var48;
         }
         case 34 -> {
            byte var49 = 10;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 2;
            yield var51;
         }
         case 37 -> {
            byte var52 = 50;
            yield var52;
         }
         case 38 -> {
            byte var53 = 52;
            yield var53;
         }
         case 39 -> {
            byte var54 = 40;
            yield var54;
         }
         case 40 -> {
            byte var55 = 24;
            yield var55;
         }
         case 41 -> {
            byte var56 = 49;
            yield var56;
         }
         case 42 -> {
            byte var57 = 44;
            yield var57;
         }
         case 43 -> {
            byte var58 = 11;
            yield var58;
         }
         case 44 -> {
            byte var59 = 63;
            yield var59;
         }
         case 45 -> {
            byte var60 = 5;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 61;
            yield var62;
         }
         case 48 -> {
            byte var63 = 38;
            yield var63;
         }
         case 49 -> {
            byte var64 = 1;
            yield var64;
         }
         case 50 -> {
            byte var65 = 0;
            yield var65;
         }
         case 51 -> {
            byte var66 = 8;
            yield var66;
         }
         case 52 -> {
            byte var67 = 30;
            yield var67;
         }
         case 53 -> {
            byte var68 = 4;
            yield var68;
         }
         case 54 -> {
            byte var69 = 19;
            yield var69;
         }
         case 55 -> {
            byte var70 = 37;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 55;
            yield var72;
         }
         case 58 -> {
            byte var73 = 25;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 28;
            yield var75;
         }
         case 61 -> {
            byte var76 = 45;
            yield var76;
         }
         case 62 -> {
            byte var77 = 48;
            yield var77;
         }
         default -> 34;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "e\\e.sg{T\u007fa\u000ew{";
      l[1] = "p6`\fE\u0003{9qC$\rp2u\u0019";
      l[2] = "R\u0019T\u0013\u0016bR\u0019CO\u001amHRCQ\u001axO#\u0017\tM";
      l[3] = boolean.class;
      m[3] = "java/lang/Boolean";
      l[4] = "2$1nIF2$&2EI(o&,E\\/\u001evq\u0014";
      l[5] = "a\u0000H\u0001\u001fPa\u0000_]\u0013_{K_C\u0013J|:\b\u001cE";
      l[6] = "a8+lPNa8<0\\A{s<.\\T|\u0002np\u0005\u0015";
      l[7] = "ON10\u001f=YN4j\f*N\u00057l\u0000>_B {K,n";
      l[8] = int.class;
      m[8] = "java/lang/Integer";
      l[9] = "\n^\u0002F\u001fy\n^\u0015\u001a\u0013v\u0010\u0015\u0015\u0004\u0013c\u0017dGZK'";
      l[10] = "$.9apw2.<;c`%e?=ot4\"(*$c\u0006";
      l[11] = "H,7<C\tC#&s+\tM,5";
      l[12] = float.class;
      m[12] = "java/lang/Float";
      l[13] = "\u001b6^ |k\r6[zo|\u001a}X|ch\u000b:Ok(x\r";
      l[14] = "u\u001c];Vn\u0000<V4G!a2]?C{\u0015";
      l[15] = void.class;
      m[15] = "java/lang/Void";
      l[16] = "W\u001dp\u0006\u0019aA\u001du\\\nvVVvZ\u0006bG\u0011aMMu\n";
      l[17] = "~~2\rxiuq#B\u001bd`|,).fqo0\u00059k";
      l[18] = "-\u0014FKEc3\u001c\\\u00049w)\u0011_G";
      l[19] = "#~\u001c=w\u0017V^\u00172fX7P\u001c9b\u0002C";
      l[20] = "b\u0011\u0017Y1K\"\b\u0016HA\u00176\u000f\u0015@-%eKN\u0016AH9\u0011\r[yM>\u001a\u0017'";
      l[21] = "WLp?S\u001f\u0017Uq.#C\u0003Rr&OqS\u0011#p#\u001c\fLj=\u001b\u0019\u000bGpA";
      l[22] = "\u001d\u001dn\u00192\"Q\u00072\u000eVv,\u0011p\r2\u007fI\u0014q\u0010$\u001cE\u00012\u00018nC\u00183\fV";
      l[23] = "\u001f\u001e[*\u0014mCODV\u0013d\u007f\u0003H&Ix\u0014\u0002Fjt{\u0003\u0002\t$\u001fz\rN46\u0018e\u0003\u0012SjIz\u007f";
      l[24] = "s>^\u0015L\u0007,1\u000b@4\u0014)8Q\u0017cCwh\b{\u000f\u000b#<L\u0001F\u001awi";
      l[25] = "Gt@\u0016\\\u007f\u0007mA\u0007,#\u0013jB\u000f@\u0011@.\u0012Q,z\u001e&^\nQ,Fm\\h";
      l[26] = ")Iv\"i\\y\u000b/'\fJ\u0014Kv.5Le\u000f.m5!";
      l[27] = "Pj\"o\u001er\u00062im|j\u0001vrt\u0010XQ7(\"|1\u000f{ql\u001bf\u0002w)\u0013";
      l[28] = "g5d6\n\u0012',e'zN3+f/\u0016|dk6rJ+d5d0\u0006\u0013a2o*z";
      l[29] = "EdsLAzB (M'yz)oQ\u001ab\u0011(a\u001d'";
      l[30] = "M\u0014A~#5\u0012\u001b\u0014+[&\u0017\u0012N|\fqIE\u0016\u0010b*\u0014\u0001Z)\"3\u0015\u0010";
      l[31] = "`D !Qde_i#5z;[9fk};A=\u001a\u0005q$L1`\u000b~4\\P";
      l[32] = "\u007fG\u0005Jd<3]Y]\u0000kNK\u001b^da+N\u001aCr\u0002'[YRnp!BX_\u0000";
      l[33] = "8\u0014ryj\u001b(\u0004w#\u0010IR\u0014 vwL#\u0018{%q 9\u0015!z|Q5Nr|\u0010";
      l[34] = "-Gn\u0001\u0018km^o\u0010h<uHh\u0013?l.\u00180\u007fU5f\u001ca\u000e\u0011m%\u001c";
      l[35] = "A\u0005u.%q\u0001\u001ct?U-\u0015\u001bw79\u001fEW/aUr\u001a\u0005o,mw\u001d\u000euP";
      l[36] = "o\u0000g'\u0004x/\u0019f6t/7\u000fa5#\u007flY8YI&$[h(\r~g[";
      l[37] = "Mkk)/\u001fHn??\u0010\u0017Kb&\u000et\u0016OnZpu\nVs ~z\u001aF\u0012";
      l[38] = "`KVj\u0003\u0015 RW{sI4UTs\u001f{g\u0010\r)s\u0016;KLhK\u0013<@V\u0014";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(98262493150720L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(98262493150720L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(98262493150720L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 111;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 236;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 115;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 81;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 67;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 220;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 111;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 236;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 115;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d9",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
