package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.util.Window;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class AutoLoot extends Module {
   private MinMaxSetting a;
   private IntSetting c;
   private IntSetting d;
   private BindSetting f;
   private ElapsedTimer e;
   private static final long k = 85206259234146L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[48];
   private static final String[] p = new String[48];

   public AutoLoot() {
      super();
      long var10001 = 64560112958300L ^ 100867528543349L;

      this.e = new ElapsedTimer(106698256430889L);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      int var110;
      label99: {
         long var10001 = 37737649101953L ^ 31433520043212L;
         var10001 = 37737649101953L ^ 89721638265550L;
         var10001 = 37737649101953L ^ 102049298352789L;
         var10001 = 37737649101953L ^ 5116103898241L;
         var10001 = 37737649101953L ^ 78700547809428L;
         int var14 = Event.cReturningInt();
         MinecraftClient var18 = b;
         int var10000 = (((var18.currentScreen instanceof InventoryScreen) ? 1 : 0));
         int var112 = var14;
         byte var111 = (byte)var10000;
         byte var88 = var111;
         byte var87 = var111;
         if (var112 != 0) {
            byte var113 = var87;
            if (var113 == 0) {
               return;
            }

            ElapsedTimer var155 = this.e;
            MinMaxSetting var20 = this.a;
            Float var21 = (Float)var20.aReturningObject();
            float var173 = var21;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var173;
            Object[] var23 = var10004;
            ElapsedTimer var22 = var155;
            byte var114 = ((byte)((var22.aReturningBoolean(var23)) ? 1 : 0));
            var88 = var114;
         }

         int var116 = var14;
         byte var115 = var88;
         int var90 = var115;
         byte var89 = var115;
         if (var116 != 0) {
            byte var117 = var89;
            if (var117 == 0) {
               return;
            }

            BindSetting var26 = this.f;
            Integer var27 = (Integer)var26.aReturningObject();
            var90 = var27;
         }

         int var119 = var14;
         int var118 = var90;
         int var92 = var118;
         int var91 = var118;
         if (var119 != 0) {
            // int var120 = var91;
            if (var120 == var121) {
               return;
            }

            MinecraftClient var30 = b;
            Window var31 = var30.getWindow();
            long var156 = var31.getHandle();
            BindSetting var32 = this.f;
            Integer var33 = (Integer)var32.aReturningObject();
            int var36 = var33;
            long var34 = var156;
            var92 = GLFW.glfwGetKey(var34, var36);
         }

         int var122 = var92;
         if (var122 == 0) {
            return;
         }

         List var16;
         int var100;
         Item var157 = Items.TOTEM_OF_UNDYING;
         Object[] var175 = new Object[]{null, null, 69015105996877L};
         var175[1] = true;
         var175[0] = var157;
         Object[] var37 = var175;
         List var15 = InventoryUtil.bReturningList(var37);
         Item var158 = Items.ENDER_PEARL;
         var175 = new Object[]{null, null, 69015105996877L};
         var175[1] = true;
         var175[0] = var158;
         Object[] var38 = var175;
         var16 = InventoryUtil.bReturningList(var38);
         List var39 = var15;
         var10000 = (((var39.isEmpty()) ? 1 : 0));
         int var124 = var14;
         byte var123 = ((byte)(var10000));
         var100 = var123;
         byte var93 = var123;
         label89:
         if (var124 != 0) {
            byte var125 = var93;
            if (var125 == 0) {
               List var41 = var15;
               var10000 = var41.size();
               int var127 = var14;
               int var126 = var10000;
               var100 = var126;
               int var94 = var126;
               if (var127 == 0) {
                  break label89;
               }

               int var128 = var94;
               int var95 = var128;
               IntSetting var43 = this.c;
               Integer var44 = (Integer)var43.aReturningObject();
               int var130 = var44;
               int var129 = var95;
               if (var129 > var130) {
                  int var99;
                  label62: {
                     List var46 = var15;
                     Integer var161 = (Integer)var46.get(0);
                     int var132 = var14;
                     Integer var131 = var161;
                     Integer var98 = var131;
                     Integer var96 = var131;
                     if (var132 != 0) {
                        Integer var133 = var96;
                        Integer var97 = var133;
                        Integer var49 = var97;
                        int var162 = var49;
                        byte var135 = 9;
                        int var134 = var162;
                        if (var134 < var135) {
                           List var51 = var15;
                           Integer var53 = (Integer)var51.get(0);
                           int var136 = var53 + 36;
                           var99 = var136;
                           break label62;
                        }

                        List var55 = var15;
                        var98 = (Integer)var55.get(0);
                     }

                     Integer var57 = var98;
                     var99 = var57;
                  }

                  int var17 = var99;
                  Object[] var10005 = new Object[]{null, null, SlotActionType.THROW, 111882238786581L};
                  var10005[1] = 1;
                  var10005[0] = var17;
                  Object[] var58 = var10005;
                  InventoryUtil.eReturningBoolean(var58);
                  MinMaxSetting var163 = this.a;
                  Object[] var60 = new Object[]{127318019014223L};
                  MinMaxSetting var59 = var163;
                  var59.bReturningVoid(var60);
                  ElapsedTimer var164 = this.e;
                  Object[] var62 = new Object[]{42835128969216L};
                  ElapsedTimer var61 = var164;
                  var61.aReturningVoid(var62);
                  return;
               }
            }

            List var63 = var16;
            var100 = (((var63.isEmpty()) ? 1 : 0));
         }

         int var138 = var14;
         int var137 = var100;
         int var102 = var137;
         int var101 = var137;
         if (var138 != 0) {
            int var139 = var101;
            if (var139 != 0) {
               return;
            }

            List var65 = var16;
            int var140 = var65.size();
            var102 = var140;
         }

         Integer var109;
         label100: {
            IntSetting var67 = this.d;
            Integer var68 = (Integer)var67.aReturningObject();
            int var174 = var68;
            int var143 = var14;
            int var142 = var174;
            int var141 = var102;
            int var107 = var141;
            int var108 = var142;
            int var103 = var141;
            int var104 = var142;
            if (var143 != 0) {
               int var145 = var104;
               int var144 = var103;
               if (var144 <= var145) {
                  return;
               }

               List var70 = var16;
               Integer var165 = (Integer)var70.get(0);
               int var147 = var14;
               Integer var146 = var165;
               var109 = var146;
               Integer var105 = var146;
               if (var147 == 0) {
                  break label100;
               }

               Integer var148 = var105;
               Integer var106 = var148;
               Integer var73 = var106;
               int var166 = var73;
               byte var150 = 9;
               int var149 = var166;
               var107 = var149;
               var108 = var150;
            }

            int var152 = var108;
            int var151 = var107;
            if (var151 < var152) {
               List var75 = var16;
               Integer var77 = (Integer)var75.get(0);
               int var153 = var77 + 36;
               var110 = var153;
               break label99;
            }

            List var79 = var16;
            var109 = (Integer)var79.get(0);
         }

         Integer var81 = var109;
         var110 = var81;
      }

      int var154 = var110;
      Object[] var177 = new Object[]{null, null, SlotActionType.THROW, 111882238786581L};
      var177[1] = 1;
      var177[0] = var154;
      Object[] var82 = var177;
      InventoryUtil.eReturningBoolean(var82);
      MinMaxSetting var167 = this.a;
      Object[] var84 = new Object[]{127318019014223L};
      MinMaxSetting var83 = var167;
      var83.bReturningVoid(var84);
      ElapsedTimer var168 = this.e;
      Object[] var86 = new Object[]{42835128969216L};
      ElapsedTimer var85 = var168;
      var85.aReturningVoid(var86);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(100305321119842L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[4];
      String var6 = "}ö\n=)»\u000b\u0098\u0088Ä!Ii.\u009dÃ";
      int var7 = "}ö\n=)»\u000b\u0098\u0088Ä!Ii.\u009dÃ".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     l = var8;
                     m = new Integer[4];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "öª«åjÍ/\u0002Ñ$\u0089´eßÆ4";
                  var7 = "öª«åjÍ/\u0002Ñ$\u0089´eßÆ4".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 26373;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/d_", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d_",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 22;
            yield var15;
         }
         case 1 -> {
            byte var16 = 61;
            yield var16;
         }
         case 2 -> {
            byte var17 = 1;
            yield var17;
         }
         case 3 -> {
            byte var18 = 29;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 41;
            yield var20;
         }
         case 6 -> {
            byte var21 = 55;
            yield var21;
         }
         case 7 -> {
            byte var22 = 48;
            yield var22;
         }
         case 8 -> {
            byte var23 = 53;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 33;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 6;
            yield var27;
         }
         case 13 -> {
            byte var28 = 14;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 4;
            yield var30;
         }
         case 16 -> {
            byte var31 = 42;
            yield var31;
         }
         case 17 -> {
            byte var32 = 32;
            yield var32;
         }
         case 18 -> {
            byte var33 = 54;
            yield var33;
         }
         case 19 -> {
            byte var34 = 19;
            yield var34;
         }
         case 20 -> {
            byte var35 = 58;
            yield var35;
         }
         case 21 -> {
            byte var36 = 12;
            yield var36;
         }
         case 22 -> {
            byte var37 = 7;
            yield var37;
         }
         case 23 -> {
            byte var38 = 45;
            yield var38;
         }
         case 24 -> {
            byte var39 = 47;
            yield var39;
         }
         case 25 -> {
            byte var40 = 50;
            yield var40;
         }
         case 26 -> {
            byte var41 = 15;
            yield var41;
         }
         case 27 -> {
            byte var42 = 21;
            yield var42;
         }
         case 28 -> {
            byte var43 = 26;
            yield var43;
         }
         case 29 -> {
            byte var44 = 35;
            yield var44;
         }
         case 30 -> {
            byte var45 = 18;
            yield var45;
         }
         case 31 -> {
            byte var46 = 10;
            yield var46;
         }
         case 32 -> {
            byte var47 = 5;
            yield var47;
         }
         case 33 -> {
            byte var48 = 38;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 3;
            yield var50;
         }
         case 36 -> {
            byte var51 = 46;
            yield var51;
         }
         case 37 -> {
            byte var52 = 23;
            yield var52;
         }
         case 38 -> {
            byte var53 = 11;
            yield var53;
         }
         case 39 -> {
            byte var54 = 31;
            yield var54;
         }
         case 40 -> {
            byte var55 = 30;
            yield var55;
         }
         case 41 -> {
            byte var56 = 49;
            yield var56;
         }
         case 42 -> {
            byte var57 = 2;
            yield var57;
         }
         case 43 -> {
            byte var58 = 17;
            yield var58;
         }
         case 44 -> {
            byte var59 = 51;
            yield var59;
         }
         case 45 -> {
            byte var60 = 60;
            yield var60;
         }
         case 46 -> {
            byte var61 = 20;
            yield var61;
         }
         case 47 -> {
            byte var62 = 13;
            yield var62;
         }
         case 48 -> {
            byte var63 = 25;
            yield var63;
         }
         case 49 -> {
            byte var64 = 57;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 0;
            yield var66;
         }
         case 52 -> {
            byte var67 = 52;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 37;
            yield var69;
         }
         case 55 -> {
            byte var70 = 28;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 27;
            yield var72;
         }
         case 58 -> {
            byte var73 = 36;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 9;
            yield var75;
         }
         case 61 -> {
            byte var76 = 62;
            yield var76;
         }
         case 62 -> {
            byte var77 = 56;
            yield var77;
         }
         default -> 34;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "\u0000GVKtH\u0016GS\u0011g_\u0001\fP\u0017kK\u0010KG\u0000 \\(";
      o[1] = "^De\u000e7x+dn\u0001&7Jje\n\"m>";
      o[2] = void.class;
      p[2] = "java/lang/Void";
      o[3] = "[' ZiWM'%\u0000z@Zl&\u0006vTK+1\u0011=DP";
      o[4] = "`:^O\u0017 \u0015\u001aU@\u0006ot\u0014^K\u00025\u0000";
      o[5] = "\"\u0003\u001c\u0019\u0001F<\u000b\u0006VcZ;\u0016";
      o[6] = "F\u001a\u0002z;!F\u001a\u0015&7.\\Q\u001587;[ Gdby";
      o[7] = long.class;
      p[7] = "java/lang/Long";
      o[8] = "BG\u0017P\u0018'TG\u0012\n\u000b0C\f\u0011\f\u0007$RK\u0006\u001bL1\u007f";
      o[9] = "ZumX'\t/UfW6FN[m\\2\u001c:";
      o[10] = boolean.class;
      p[10] = "java/lang/Boolean";
      o[11] = "T\u0018\u000f\u00065\"T\u0018\u0018Z9-NS\u0018D98I\"J\u0010hy";
      o[12] = "-\u0002_\"K\u0006-\u0002H~G\t7IH`G\u001c08\u001a;\u001f]";
      o[13] = "xS\u0001^!+xS\u0016\u0002-$b\u0018\u0016\u001c-1eiFA|";
      o[14] = "x\u001b\u0003S;px\u001b\u0014\u000f7\u007fbP\u0014\u00117je!CNa";
      o[15] = "\u0006\u0013\u000f!$+\u0003\u0006\u0004!/0\u000f\u0016FH\u0004\u001a>";
      o[16] = int.class;
      p[16] = "java/lang/Integer";
      o[17] = "pi\u0011\u001f\u0000Pfi\u0014E\u0013Gq\"\u0017C\u001fS`e\u0000TTAQ";
      o[18] = "F\u0012K\u0005XBM\u001dZJ9LF\u0016^\u0010";
      o[19] = "^^\u000f\u0017?\u001c^^\u0018K3\u0013D\u0015\u0018U3\u0006CdJ\u000ecF";
      o[20] = "@__K\u001bzV_Z\u0011\bmA\u0014Y\u0017\u0004yPSN\u0000Onb";
      o[21] = "x\u0017lyg\u0002s\u0018}6\u0000\u0000f\u0013}};";
      o[22] = "g}IL\"xlrX\u0003Jxb}K";
      o[23] = float.class;
      p[23] = "java/lang/Float";
      o[24] = "d5#[#3\u0011\u0015(T2|p\u001b#_6&\u0004";
      o[25] = "(\bu\u000fYS>\bpUJD)CsSFP8\u0004dD\rG\u0013";
      o[26] = "6W\bN%G=X\u0019\u0001FJ(U\u0016jsH9F\nFdE";
      o[27] = "~7lsE<\u000b\u0017g|Tsj\u0019lwP)\u001e";
      o[28] = "E`$aufR6:\u0005q^Jy9z$5Ft!e\u001bgRg2t#'Sd:\u0005";
      o[29] = "\u0001pk!R-\u0003*l 6z;sq%I/P\u007f|=V\u0010\u0000vb0VbWrq&6";
      o[30] = "l/\u000eh&y+0UjDc=+\u000ec(Qlk_<D;`9\bj?y-2V\u0004";
      o[31] = "G\u0001B\u0004=8JARCE)z\u0019D\u0007:\u007f\u0011\u0015I\u001f%@E\u0017]\u0006;&\u001f\u0014\u0000\u001aE";
      o[32] = "\u0006\"YLl\u0006I+\u001dZVWW&CR\u0001\t\f{\u0017>fKU9WS2\u0001\u000f%";
      o[33] = "u\n,\u0007c8uM|\u000e\u001e:%](\u0013Im{\rq\u007f/,&_u\u001eq(yI";
      o[34] = "G\nB)\u0003\u0011MX\\+m\u001dJ\u0007D\u001b\u0000\u000em\u0004JTPB@\u000fU/\u0012\u000fKQ;>\u0007\u0010E\u0017Tk\u0013M_iQ>\u000f\u0019P\u0006\u0004*R\u0003.";
      o[35] = ">'bD&D->?\u0014L^T22H'K;g&\u0015=5";
      o[36] = "P\u00157?\u0002\b\u0007\u0011$)b\u0001\n\u00036Q\b\u0010\t\u001a%>]\u0004T\u0000[";
      o[37] = "N(/|jT\u0019,<j\nI\u00180Cx`D\u001e2,-t\u0019\u0004L(ivO\u00193x}n^u";
      o[38] = "Tgr\u0002\u001e5_4*\u0005\u007f`Y`)T(1\u0007<p8\u0013d\u00077,\u0003\u00187_0";
      o[39] = "\u000f\u0015_\"k\n\fB\u000fxT\u000eb\u0013\u001f<=\u000b\u001dC\u000b$,g";
      o[40] = "AKMy@\u0015\u001d\u000b_)8\u0006JKsq\\\u001aA7GrZ\fRX\u0012f\u0007\u0016,";
      o[41] = "]yUV3|AlRB\\kWzFG\u0002lW`B;2tT'J@1zXo/";
      o[42] = ":B\u001dJdF7\u0002\r\r\u001cW\u0007Z\u001bIc\u0001lV\u0016Q|>>B\u0005Bm\u0006~C\u0006J\u001c";
      o[43] = "Oo\u0002\u0012B3\u0011;C\u00002`/j\u0013XLt\u0016bMTJ\tNkB\u0017O0F5N\u00112";
      o[44] = "VJ6\u001d2\u0000T\u00101\u001cVPlI,\u0019)\u0002\u0007E!\u00016=SG5\u0018([\tDh\u0004V";
      o[45] = "V`\u0010/F\f\u0019iT9|]\u0007d\n1+\u0003X2R]LA\u0005{\u001e0\u0018\u000b_g";
      o[46] = "(|Z`\u0002\t(;\ni\u007f\u0000t:Z\u007f\u00132#|\u0004(De%>Zt\u001d\u001ab!\u0001v\u007f";
      o[47] = "_f(SFC\bb;E&P\u001fO!EZ@d=+[\\O\u0002g(\u0006@1";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1300005725981389L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1300005725981389L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1300005725981389L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 193;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 251;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 229;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 234;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 231;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 122;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 193;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 251;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 229;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/d_",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/d_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
