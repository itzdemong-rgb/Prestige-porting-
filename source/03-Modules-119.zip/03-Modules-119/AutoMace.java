package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.EntityBoundingBoxEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class AutoMace extends Module implements RotationSource {
   private FloatSetting a;
   private FloatSetting c;
   private BooleanSetting d;
   private ModeSetting e;
   private BindSetting f;
   private FloatSetting g;
   private BooleanSetting h;
   private FloatSetting i;
   private IntSetting j;
   private BooleanSetting k;
   private BooleanSetting l;
   private BooleanSetting m;
   private FloatSetting n;
   private BooleanSetting o;
   private BooleanSetting p;
   private IntSetting q;
   private BooleanSetting r;
   private FloatSetting s;
   private ElapsedTimer t;
   private ElapsedTimer u;
   private ElapsedTimer v;
   private ElapsedTimer w;
   private boolean x;
   private boolean y;
   private int z;
   private boolean A;
   private boolean B;
   private PlayerEntity C;
   private Rotation D;
   private long E;
   private int F;
   private static final long G = 58647587722062L;
   private static final String[] H;
   private static final String[] I;
   private static final Map J = new HashMap(13);
   private static final long[] K;
   private static final Integer[] L;
   private static final Map M;
   private static final long[] N;
   private static final Long[] O;
   private static final Map P;
   private static final Object[] Q = new Object[209];
   private static final String[] R = new String[209];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;

   public AutoMace() {
      super();
      long var10001 = 119627858272623L ^ 15150905251398L;
      var10001 = 119627858272623L ^ 127250574726072L;
      var10001 = 119627858272623L ^ 82788237974157L;
      var10001 = 119627858272623L ^ 53087981423070L;
      var10001 = 119627858272623L ^ 2564014355115L;
      var10001 = 119627858272623L ^ 66023569369795L;

      this.t = new ElapsedTimer(106698256430889L);
      this.u = new ElapsedTimer(106698256430889L);
      this.v = new ElapsedTimer(106698256430889L);
      this.w = new ElapsedTimer(106698256430889L);
      this.z = -1;
      this.F = -1;
      FloatSetting var10000 = this.g;
      Object[] var16 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var15 = var10000;
      var15.aReturningFloatSetting(var16);
      var10000 = this.i;
      Object[] var18 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var17 = var10000;
      var17.aReturningFloatSetting(var18);
      ModeSetting var36 = this.e;
      Object[] var20 = new Object[]{invokeBinding3(this), 121607650890692L};
      ModeSetting var19 = var36;
      var19.aReturningModeSetting(var20);
      IntSetting var37 = this.j;
      Object[] var22 = new Object[]{invokeBinding4(this), 43459238656994L};
      IntSetting var21 = var37;
      var21.aReturningIntSetting(var22);
      BooleanSetting var38 = this.m;
      Object[] var24 = new Object[]{invokeBinding5(this), 88791076916140L};
      BooleanSetting var23 = var38;
      var23.aReturningBooleanSetting(var24);
      var10000 = this.n;
      Object[] var26 = new Object[]{invokeBinding6(this), 34595201528535L};
      FloatSetting var25 = var10000;
      var25.aReturningFloatSetting(var26);
      var10000 = this.s;
      Object[] var28 = new Object[]{invokeBinding7(this), 34595201528535L};
      FloatSetting var27 = var10000;
      var27.aReturningFloatSetting(var28);
      BooleanSetting var41 = this.h;
      Object[] var30 = new Object[]{invokeBinding8(this), 88791076916140L};
      BooleanSetting var29 = var41;
      var29.aReturningBooleanSetting(var30);
      BindSetting var42 = this.f;
      Object[] var32 = new Object[]{invokeBinding9(this), 101728543910065L};
      BindSetting var31 = var42;
      var31.aReturningBindSetting(var32);
      IntSetting var43 = this.q;
      Object[] var34 = new Object[]{invokeBinding10(this), 43459238656994L};
      IntSetting var33 = var43;
      var33.aReturningIntSetting(var34);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var4;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      long var18;
      long var20;
      long var22;
      long var24;
      long var26;
      long var28;
      long var30;
      long var32;
      long var34;
      long var36;
      long var38;
      long var40;
      long var42;
      int var44;
      PlayerEntity var341;
      label577: {
         AutoMace var340;
         label580: {
            long var2 = (Long)var1[0];
            var4 = var2 ^ 49132168048187L;
            long var6 = var2 ^ 47083329184753L;
            var8 = var2 ^ 113431327531997L;
            var10 = var2 ^ 73608466808436L;
            var12 = var2 ^ 30352829501857L;
            var14 = var2 ^ 107863313865584L;
            var16 = var2 ^ 107312989478433L;
            var18 = var2 ^ 60429099907870L;
            var20 = var2 ^ 138007752420630L;
            var22 = var2 ^ 106393229133232L;
            var24 = var2 ^ 136327255761257L;
            var26 = var2 ^ 109245071370512L;
            var28 = var2 ^ 44409679904354L;
            var30 = var2 ^ 19667275953380L;
            var32 = var2 ^ 37392379861569L;
            var34 = var2 ^ 29159961624672L;
            var36 = var2 ^ 6649815643729L;
            var38 = var2 ^ 19182256418671L;
            var40 = var2 ^ 100729554575240L;
            var42 = var2 ^ 42519062091112L;
            int var10000 = Event.cReturningInt();
            this.B = false;
            var44 = var10000;
            int var453 = var44;
            
            int var330 = var451;
            byte var331 = var452;
            int var322 = var451;
            byte var323 = var452;
            if (var453 != 0) {
               int var329;
               label581: {
                  byte var455 = var323;
                  int var454 = var322;
                  if (var454 != var455) {
                     int var457 = var44;
                     byte var456 = ((byte)((this.A) ? 1 : 0));
                     var329 = var456;
                     byte var324 = var456;
                     if (var457 == 0) {
                        break label581;
                     }

                     byte var458 = var324;
                     byte var325 = var458;
                     byte var459 = var325;
                     if (var459 == 0) {
                        ElapsedTimer var708 = this.w;
                        Object[] var10004 = new Object[]{null, var10};
                        var10004[0] = 2000.0F;
                        Object[] var55 = var10004;
                        ElapsedTimer var54 = var708;
                        byte var709 = ((byte)((var54.aReturningBoolean(var55)) ? 1 : 0));
                        int var461 = var44;
                        byte var460 = var709;
                        var329 = var460;
                        byte var326 = var460;
                        if (var461 == 0) {
                           break label581;
                        }

                        byte var462 = var326;
                        byte var327 = var462;
                        byte var463 = var327;
                        if (var463 != 0) {
                           Object[] var59 = new Object[0];
                           AutoMace var58 = this;
                           var58.mReturningVoid(var59);
                        }
                     }
                  }

                  int var465 = var44;
                  AutoMace var464 = this;
                  var340 = var464;
                  AutoMace var328 = var464;
                  if (var465 == 0) {
                     break label580;
                  }

                  int var466 = var328.z;
                  var329 = var466;
               }

               var331 = -1;
               var330 = var329;
            }

            byte var468 = var331;
            int var467 = var330;
            if (var467 != var468) {
               int var470 = var44;
               AutoMace var469 = this;
               var340 = var469;
               AutoMace var332 = var469;
               if (var470 == 0) {
                  break label580;
               }

               AutoMace var471 = var332;
               AutoMace var333 = var471;
               boolean var472 = var333.A;
               if (var472) {
                  int var474 = var44;
                  AutoMace var473 = this;
                  var340 = var473;
                  AutoMace var334 = var473;
                  if (var474 == 0) {
                     break label580;
                  }

                  AutoMace var475 = var334;
                  AutoMace var335 = var475;
                  boolean var476 = var335.x;
                  if (!var476) {
                     int var478 = var44;
                     PlayerEntity var477 = this.C;
                     var341 = var477;
                     PlayerEntity var336 = var477;
                     if (var478 == 0) {
                        break label577;
                     }

                     PlayerEntity var479 = var336;
                     PlayerEntity var337 = var479;
                     PlayerEntity var480 = var337;
                     if (var480 == null) {
                        int var482 = var44;
                        AutoMace var481 = this;
                        var340 = var481;
                        AutoMace var338 = var481;
                        if (var482 == 0) {
                           break label580;
                        }

                        AutoMace var483 = var338;
                        AutoMace var339 = var483;
                        ElapsedTimer var710 = var339.v;
                        IntSetting var69 = this.q;
                        Integer var70 = (Integer)var69.aReturningObject();
                        float var10001 = var70.intValue();
                        Object[] var753 = new Object[]{null, var10};
                        var753[0] = var10001;
                        Object[] var72 = var753;
                        ElapsedTimer var71 = var710;
                        boolean var484 = var71.aReturningBoolean(var72);
                        if (var484) {
                           Object[] var75 = new Object[]{var6};
                           AutoMace var74 = this;
                           var74.lReturningVoid(var75);
                        }
                     }
                  }
               }
            }

            var340 = this;
         }

         var341 = var340.C;
      }

      AutoMace var358;
      label582: {
         int var486 = var44;
         PlayerEntity var485 = var341;
         PlayerEntity var357 = var485;
         PlayerEntity var342 = var485;
         if (var486 != 0) {
            AutoMace var355;
            label543: {
               PlayerEntity var487 = var342;
               if (var487 != null) {
                  int var489 = var44;
                  AutoMace var488 = this;
                  var355 = var488;
                  AutoMace var343 = var488;
                  if (var489 == 0) {
                     break label543;
                  }

                  AutoMace var490 = var343;
                  AutoMace var344 = var490;
                  BooleanSetting var79 = var344.d;
                  Boolean var80 = (Boolean)var79.aReturningObject();
                  boolean var491 = var80;
                  if (!var491) {
                     int var350;
                     label538: {
                        AutoMace var349;
                        int var493 = var44;
                        AutoMace var492 = this;
                        var349 = var492;
                        AutoMace var345 = var492;
                        label537:
                        if (var493 != 0) {
                           AutoMace var494 = var345;
                           AutoMace var346 = var494;
                           BooleanSetting var83 = var346.p;
                           Boolean var84 = (Boolean)var83.aReturningObject();
                           boolean var495 = var84;
                           if (var495) {
                              int var497 = var44;
                              AutoMace var496 = this;
                              var349 = var496;
                              AutoMace var347 = var496;
                              if (var497 == 0) {
                                 break label537;
                              }

                              AutoMace var498 = var347;
                              AutoMace var348 = var498;
                              
                              if (var499 != var500) {
                                 int var501 = this.z;
                                 var350 = var501;
                                 break label538;
                              }
                           }

                           var349 = this;
                        }

                        var350 = var349.F;
                     }

                     int var45 = var350;
                     Object[] var90 = new Object[]{var32};
                     AutoMace var89 = this;
                     var89.jReturningVoid(var90);
                     int var503 = var44;
                     AutoMace var502 = this;
                     var355 = var502;
                     AutoMace var351 = var502;
                     if (var503 == 0) {
                        break label543;
                     }

                     Object[] var92 = new Object[0];
                     AutoMace var91 = var351;
                     var91.mReturningVoid(var92);
                     int var504 = var45;
                     label528:
                     if (var504 >= 0) {
                        Object[] var94 = new Object[]{var38};
                        int var711 = InventoryUtil.aReturningInt(var94);
                        int var506 = var44;
                        int var505 = var711;
                        int var354 = var505;
                        int var352 = var505;
                        if (var506 != 0) {
                           int var507 = var352;
                           int var353 = var507;
                           int var509 = var45;
                           int var508 = var353;
                           if (var508 == var509) {
                              break label528;
                           }

                           int var510 = var45;
                           var354 = var510;
                        }

                        Object[] var10003 = new Object[]{null, var20};
                        var10003[0] = var354;
                        Object[] var98 = var10003;
                        InventoryUtil.aReturningVoid(var98);
                     }
                  }
               }

               var355 = this;
            }

            int var512 = var44;
            AutoMace var511 = var355;
            var358 = var511;
            AutoMace var356 = var511;
            if (var512 == 0) {
               break label582;
            }

            PlayerEntity var513 = var356.C;
            var357 = var513;
         }

         PlayerEntity var514 = var357;
         if (var514 != null) {
            Object[] var101 = new Object[]{var14};
            AutoMace var100 = this;
            return var100.cReturningdx_C0210(var101);
         }

         var358 = this;
      }

      Object[] var104 = new Object[]{var42};
      AutoMace var103 = var358;
      int var712 = (((var103.fReturningBoolean(var104)) ? 1 : 0));
      int var516 = var44;
      byte var515 = (byte)var712;
      int var360 = var515;
      byte var359 = var515;
      if (var516 != 0) {
         byte var517 = var359;
         if (var517 != 0) {
            return null;
         }

         Object[] var108 = new Object[]{var16};
         AutoMace var107 = this;
         var360 = var107.eReturningInt(var108);
      }

      int var699 = var360;
      int var519 = var44;
      int var518 = var699;
      int var362 = var518;
      int var361 = var518;
      if (var519 != 0) {
         
         if (var520 == var521) {
            this.x = false;
            return null;
         }

         MinecraftClient var111 = b;
         ClientPlayerEntity var112 = var111.player;
         double var713 = var112.fallDistance;
         FloatSetting var113 = this.c;
         Float var114 = (Float)var113.aReturningObject();
         double var760;
         var362 = (var760 = var713 - var114.floatValue()) == 0.0 ? 0 : (var760 < 0.0 ? -1 : 1);
      }

      int var523 = var44;
      int var522 = var362;
      int var364 = var522;
      int var363 = var522;
      if (var523 != 0) {
         int var524 = var363;
         if (var524 <= 0) {
            return null;
         }

         BooleanSetting var117 = this.d;
         Boolean var118 = (Boolean)var117.aReturningObject();
         var364 = ((((java.lang.Boolean)(var118)).booleanValue() ? 1 : 0));
      }

      label585: {
         int var526 = var44;
         int var525 = var364;
         int var366 = var525;
         int var365 = var525;
         if (var526 != 0) {
            int var527 = var365;
            if (var527 == 0) {
               break label585;
            }

            byte var528 = ((byte)((this.x) ? 1 : 0));
            var366 = var528;
         }

         int var530 = var44;
         int var529 = var366;
         int var368 = var529;
         int var367 = var529;
         if (var530 != 0) {
            int var531 = var367;
            if (var531 == 0) {
               break label585;
            }

            Object[] var123 = new Object[]{var28};
            AutoMace var122 = this;
            int var532 = var122.dReturningInt(var123);
            var368 = var532;
         }

         int var46 = var368;
         int var533 = var44;
         if (var533 != 0) {
            
            if (var534 != var535) {
               PlayerEntity var47;
               Rotation var48;
               AutoMace var384;
               label628: {
                  label629: {
                     label586: {
                        int var383;
                        label587: {
                           label588: {
                              Object var371;
                              var48 = null;
                              MinecraftClient var127 = b;
                              HitResult var50 = var127.crosshairTarget;
                              int var537 = var44;
                              HitResult var536 = var50;
                              var371 = var536;
                              HitResult var369 = var536;
                              label489:
                              if (var537 != 0) {
                                 boolean var538 = var369 instanceof EntityHitResult;
                                 if (var538) {
                                    EntityHitResult var49 = (EntityHitResult)var50;
                                    EntityHitResult var129 = var49;
                                    Entity var714 = var129.getEntity();
                                    int var540 = var44;
                                    Entity var539 = var714;
                                    var371 = var539;
                                    Entity var370 = var539;
                                    if (var540 == 0) {
                                       break label489;
                                    }

                                    boolean var541 = var370 instanceof PlayerEntity;
                                    if (var541) {
                                       EntityHitResult var131 = var49;
                                       var47 = (PlayerEntity)var131.getEntity();
                                       int var542 = var44;
                                       if (var542 != 0) {
                                          break label588;
                                       }
                                    }
                                 }

                                 FloatSetting var132 = this.n;
                                 Object var543 = var132.aReturningObject();
                                 var371 = var543;
                              }

                              Float var134 = (Float)var371;
                              float var715 = var134;
                              Object[] var749 = new Object[]{null, var18};
                              var749[0] = var715;
                              Object[] var135 = var749;
                              var47 = EntityUtil.bReturningPlayerEntity(var135);
                              int var544 = var44;
                              if (var544 == 0) {
                                 return null;
                              }

                              PlayerEntity var545 = var47;
                              if (var545 == null) {
                                 break label629;
                              }

                              MinecraftClient var137 = b;
                              PlayerEntity var139 = var47;
                              ClientPlayerEntity var138 = var137.player;
                              float var761;
                              var712 = (var761 = var138.distanceTo((Entity)var139) - 3.0F) == 0.0F ? 0 : (var761 < 0.0F ? -1 : 1);
                              int var547 = var44;
                              int var546 = var712;
                              int var374 = var546;
                              int var372 = var546;
                              if (var547 != 0) {
                                 int var548 = var372;
                                 int var373 = var548;
                                 int var549 = var373;
                                 if (var549 > 0) {
                                    break label629;
                                 }

                                 MinecraftClient var142 = b;
                                 PlayerEntity var144 = var47;
                                 ClientPlayerEntity var143 = var142.player;
                                 byte var550 = ((byte)((var143.canSee((Entity)var144)) ? 1 : 0));
                                 var374 = var550;
                              }

                              PlayerEntity var379;
                              label589: {
                                 int var552 = var44;
                                 int var551 = var374;
                                 int var378 = var551;
                                 int var375 = var551;
                                 if (var552 != 0) {
                                    int var553 = var375;
                                    if (var553 == 0) {
                                       break label629;
                                    }

                                    int var555 = var44;
                                    PlayerEntity var554 = var47;
                                    var379 = var554;
                                    PlayerEntity var376 = var554;
                                    if (var555 == 0) {
                                       break label589;
                                    }

                                    PlayerEntity var556 = var376;
                                    PlayerEntity var377 = var556;
                                    Object[] var148 = new Object[]{var377, var24};
                                    byte var557 = ((byte)((BlockUtil.aReturningBoolean(var148)) ? 1 : 0));
                                    var378 = var557;
                                 }

                                 int var558 = var378;
                                 if (var558 != 0) {
                                    break label629;
                                 }

                                 var379 = var47;
                              }

                              PlayerEntity var151 = var379;
                              Object[] var152 = new Object[]{var151.getEyePos(), var12};
                              var48 = RotationUtil.aReturningdx_C0210(var152);
                              int var559 = var44;
                              if (var559 == 0) {
                                 return null;
                              }

                              Object[] var154 = new Object[0];
                              Rotation var153 = var48;
                              float var717 = var153.aReturningFloat(var154);
                              MinecraftClient var155 = b;
                              ClientPlayerEntity var156 = var155.player;
                              float var718 = var717 - var156.getYaw();
                              FloatSetting var157 = this.n;
                              Float var158 = (Float)var157.aReturningObject();
                              float var762;
                              int var560 = (var762 = var718 - var158) == 0.0F ? 0 : (var762 < 0.0F ? -1 : 1);
                              if (var560 > 0) {
                                 break label586;
                              }

                              Object[] var161 = new Object[0];
                              Rotation var160 = var48;
                              float var719 = var160.aReturningFloat(var161);
                              MinecraftClient var162 = b;
                              ClientPlayerEntity var163 = var162.player;
                              float var720 = var719 - var163.getYaw();
                              FloatSetting var164 = this.n;
                              Float var165 = (Float)var164.aReturningObject();
                              float var763;
                              var712 = (var763 = var720 - -var165) == 0.0F ? 0 : (var763 < 0.0F ? -1 : 1);
                              int var562 = var44;
                              int var561 = var712;
                              var383 = var561;
                              int var380 = var561;
                              if (var562 == 0) {
                                 break label587;
                              }

                              int var563 = var380;
                              int var381 = var563;
                              int var564 = var381;
                              if (var564 < 0) {
                                 break label586;
                              }
                           }

                           int var566 = var44;
                           AutoMace var565 = this;
                           var384 = var565;
                           AutoMace var382 = var565;
                           if (var566 == 0) {
                              break label628;
                           }

                           Object[] var170 = new Object[]{var30};
                           AutoMace var169 = var382;
                           byte var567 = ((byte)((var169.eReturningBoolean(var170)) ? 1 : 0));
                           var383 = var567;
                        }

                        int var568 = var383;
                        if (var568 == 0) {
                           this.x = false;
                           return null;
                        }

                        this.x = false;
                        var384 = this;
                        break label628;
                     }

                     this.x = false;
                     return null;
                  }

                  this.x = false;
                  return null;
               }

               Object[] var10007 = new Object[]{null, null, null, null, var36};
               var10007[3] = var699;
               var10007[2] = var46;
               var10007[1] = var48;
               var10007[0] = var47;
               Object[] var174 = var10007;
               AutoMace var173 = var384;
               return var173.bReturningdx_C0210(var174);
            }

            this.x = false;
         }

         return null;
      }

      AutoMace var450;
      label591: {
         boolean var412;
         MinecraftClient var175 = b;
         HitResult var702 = var175.crosshairTarget;
         int var722 = (((var702 instanceof EntityHitResult) ? 1 : 0));
         int var570 = var44;
         boolean var569 = dev.prestige.recovery.SourceSupport.asBoolean(var722);
         var412 = var569;
         boolean var385 = var569;
         label443:
         if (var570 != 0) {
            boolean var571 = var385;
            if (var571) {
               EntityHitResult var700 = (EntityHitResult)var702;
               EntityHitResult var177 = var700;
               Entity var703 = var177.getEntity();
               var722 = (((var703 instanceof PlayerEntity) ? 1 : 0));
               int var573 = var44;
               boolean var572 = ((((int)(var722) & 1) != 0));
               var412 = var572;
               boolean var386 = var572;
               if (var573 == 0) {
                  break label443;
               }

               boolean var574 = var386;
               if (var574) {
                  PlayerEntity var701 = (PlayerEntity)var703;
                  BooleanSetting var179 = this.l;
                  Boolean var180 = (Boolean)var179.aReturningObject();
                  var722 = ((((java.lang.Boolean)(var180)).booleanValue() ? 1 : 0));
                  int var576 = var44;
                  byte var575 = ((byte)(var722));
                  byte var388 = var575;
                  byte var387 = var575;
                  if (var576 != 0) {
                     byte var577 = var387;
                     if (var577 == 0) {
                        return null;
                     }

                     ElapsedTimer var725 = this.t;
                     Object[] var754 = new Object[]{null, var10};
                     var754[0] = 800.0F;
                     Object[] var183 = var754;
                     ElapsedTimer var182 = var725;
                     byte var578 = ((byte)((var182.aReturningBoolean(var183)) ? 1 : 0));
                     var388 = var578;
                  }

                  int var580 = var44;
                  byte var579 = var388;
                  byte var390 = var579;
                  byte var389 = var579;
                  if (var580 != 0) {
                     byte var581 = var389;
                     if (var581 == 0) {
                        return null;
                     }

                     Object[] var186 = new Object[]{var701, var8};
                     byte var582 = ((byte)((EntityUtil.aReturningBoolean(var186)) ? 1 : 0));
                     var390 = var582;
                  }

                  int var401;
                  int var584 = var44;
                  byte var583 = var390;
                  var401 = var583;
                  byte var391 = var583;
                  label412:
                  if (var584 != 0) {
                     byte var585 = var391;
                     if (var585 != 0) {
                        BooleanSetting var189 = this.d;
                        Boolean var190 = (Boolean)var189.aReturningObject();
                        var722 = ((((java.lang.Boolean)(var190)).booleanValue() ? 1 : 0));
                        int var587 = var44;
                        byte var586 = ((byte)(var722));
                        var401 = var586;
                        byte var392 = var586;
                        if (var587 == 0) {
                           break label412;
                        }

                        byte var588 = var392;
                        byte var393 = var588;
                        byte var589 = var393;
                        if (var589 != 0) {
                           ElapsedTimer var727 = this.u;
                           Object[] var755 = new Object[]{null, var10};
                           var755[0] = 800.0F;
                           Object[] var194 = var755;
                           ElapsedTimer var193 = var727;
                           var722 = (((var193.aReturningBoolean(var194)) ? 1 : 0));
                           int var591 = var44;
                           byte var590 = ((byte)(var722));
                           var401 = var590;
                           byte var394 = var590;
                           if (var591 == 0) {
                              break label412;
                           }

                           byte var592 = var394;
                           byte var395 = var592;
                           byte var593 = var395;
                           if (var593 != 0) {
                              Object[] var198 = new Object[]{var22};
                              AutoMace var197 = this;
                              var722 = (((var197.dReturningBoolean(var198)) ? 1 : 0));
                              int var595 = var44;
                              byte var594 = ((byte)(var722));
                              var401 = var594;
                              byte var396 = var594;
                              if (var595 == 0) {
                                 break label412;
                              }

                              byte var596 = var396;
                              byte var397 = var596;
                              byte var597 = var397;
                              if (var597 != 0) {
                                 Object[] var202 = new Object[]{var30};
                                 AutoMace var201 = this;
                                 var722 = (((var201.eReturningBoolean(var202)) ? 1 : 0));
                                 int var599 = var44;
                                 byte var598 = ((byte)(var722));
                                 var401 = var598;
                                 byte var398 = var598;
                                 if (var599 == 0) {
                                    break label412;
                                 }

                                 byte var600 = var398;
                                 byte var399 = var600;
                                 byte var601 = var399;
                                 if (var601 != 0) {
                                    Object[] var206 = new Object[]{var28};
                                    AutoMace var205 = this;
                                    int var704 = var205.dReturningInt(var206);
                                    int var603 = var44;
                                    int var602 = var704;
                                    var401 = var602;
                                    int var400 = var602;
                                    if (var603 == 0) {
                                       break label412;
                                    }

                                    
                                    if (var604 != var605) {
                                       Object[] var758 = new Object[]{null, null, null, null, var36};
                                       var758[3] = var699;
                                       var758[2] = var704;
                                       var758[1] = null;
                                       var758[0] = var701;
                                       Object[] var209 = var758;
                                       AutoMace var208 = this;
                                       return var208.bReturningdx_C0210(var209);
                                    }
                                 }
                              }
                           }
                        }
                     }

                     Object[] var211 = new Object[]{var4};
                     var401 = (((RaycastUtil.aReturningBoolean(var211)) ? 1 : 0));
                  }

                  int var607 = var44;
                  int var606 = var401;
                  int var403 = var606;
                  int var402 = var606;
                  if (var607 != 0) {
                     int var608 = var402;
                     if (var608 != 0) {
                        return null;
                     }

                     this.y = true;
                     Object[] var214 = new Object[]{var38};
                     var403 = InventoryUtil.aReturningInt(var214);
                  }

                  int var610 = var44;
                  int var609 = var403;
                  int var405 = var609;
                  int var404 = var609;
                  if (var610 != 0) {
                     int var612 = var699;
                     int var611 = var404;
                     if (var611 != var612) {
                        Object[] var217 = new Object[]{var26};
                        AutoMace var216 = this;
                        var216.kReturningVoid(var217);
                        Object[] var750 = new Object[]{null, var20};
                        var750[0] = var699;
                        Object[] var218 = var750;
                        InventoryUtil.aReturningVoid(var218);
                     }

                     Object[] var220 = new Object[]{var701, var40};
                     ItemUseUtil.aReturningVoid(var220);
                     this.y = false;
                     ElapsedTimer var731 = this.t;
                     Object[] var222 = new Object[]{var34};
                     ElapsedTimer var221 = var731;
                     var221.aReturningVoid(var222);
                     BooleanSetting var223 = this.p;
                     Boolean var224 = (Boolean)var223.aReturningObject();
                     var405 = ((((java.lang.Boolean)(var224)).booleanValue() ? 1 : 0));
                  }

                  AutoMace var410;
                  label595: {
                     int var614 = var44;
                     int var613 = var405;
                     int var409 = var613;
                     int var406 = var613;
                     if (var614 != 0) {
                        int var615 = var406;
                        if (var615 == 0) {
                           return null;
                        }

                        int var617 = var44;
                        AutoMace var616 = this;
                        var410 = var616;
                        AutoMace var407 = var616;
                        if (var617 == 0) {
                           break label595;
                        }

                        AutoMace var618 = var407;
                        AutoMace var408 = var618;
                        int var619 = var408.z;
                        var409 = var619;
                     }

                     
                     if (var620 == var621) {
                        return null;
                     }

                     ElapsedTimer var732 = this.v;
                     Object[] var229 = new Object[]{var34};
                     ElapsedTimer var228 = var732;
                     var228.aReturningVoid(var229);
                     AutoMace var622 = this;
                     var410 = var622;
                  }

                  var410.A = true;
                  return null;
               }
            }

            int var624 = var44;
            AutoMace var623 = this;
            var450 = var623;
            AutoMace var411 = var623;
            if (var624 == 0) {
               break label591;
            }

            BooleanSetting var231 = var411.l;
            Boolean var232 = (Boolean)var231.aReturningObject();
            boolean var625 = var232;
            var412 = var625;
         }

         boolean var626 = var412;
         if (var626) {
            int var628 = var44;
            AutoMace var627 = this;
            var450 = var627;
            AutoMace var413 = var627;
            if (var628 == 0) {
               break label591;
            }

            AutoMace var629 = var413;
            AutoMace var414 = var629;
            BooleanSetting var235 = var414.m;
            Boolean var236 = (Boolean)var235.aReturningObject();
            boolean var630 = var236;
            if (var630) {
               int var632 = var44;
               AutoMace var631 = this;
               var450 = var631;
               AutoMace var415 = var631;
               if (var632 == 0) {
                  break label591;
               }

               AutoMace var633 = var415;
               AutoMace var416 = var633;
               ElapsedTimer var733 = var416.t;
               Object[] var756 = new Object[]{null, var10};
               var756[0] = 800.0F;
               Object[] var240 = var756;
               ElapsedTimer var239 = var733;
               boolean var634 = var239.aReturningBoolean(var240);
               if (var634) {
                  FloatSetting var242 = this.n;
                  Float var243 = (Float)var242.aReturningObject();
                  float var734 = var243;
                  Object[] var751 = new Object[]{null, var18};
                  var751[0] = var734;
                  Object[] var244 = var751;
                  PlayerEntity var705 = EntityUtil.bReturningPlayerEntity(var244);
                  PlayerEntity var635 = var705;
                  if (var635 != null) {
                     MinecraftClient var245 = b;
                     PlayerEntity var247 = var705;
                     ClientPlayerEntity var246 = var245.player;
                     float var764;
                     var722 = (var764 = var246.distanceTo((Entity)var247) - 3.0F) == 0.0F ? 0 : (var764 < 0.0F ? -1 : 1);
                     int var637 = var44;
                     int var636 = var722;
                     int var419 = var636;
                     int var417 = var636;
                     if (var637 != 0) {
                        int var638 = var417;
                        int var418 = var638;
                        int var639 = var418;
                        if (var639 > 0) {
                           return null;
                        }

                        MinecraftClient var250 = b;
                        PlayerEntity var252 = var705;
                        ClientPlayerEntity var251 = var250.player;
                        byte var640 = ((byte)((var251.canSee((Entity)var252)) ? 1 : 0));
                        var419 = var640;
                     }

                     PlayerEntity var424;
                     label598: {
                        int var642 = var44;
                        int var641 = var419;
                        int var423 = var641;
                        int var420 = var641;
                        if (var642 != 0) {
                           int var643 = var420;
                           if (var643 == 0) {
                              return null;
                           }

                           int var645 = var44;
                           PlayerEntity var644 = var705;
                           var424 = var644;
                           PlayerEntity var421 = var644;
                           if (var645 == 0) {
                              break label598;
                           }

                           PlayerEntity var646 = var421;
                           PlayerEntity var422 = var646;
                           Object[] var256 = new Object[]{var422, var24};
                           byte var647 = ((byte)((BlockUtil.aReturningBoolean(var256)) ? 1 : 0));
                           var423 = var647;
                        }

                        int var648 = var423;
                        if (var648 != 0) {
                           return null;
                        }

                        var424 = var705;
                     }

                     PlayerEntity var259 = var424;
                     Object[] var260 = new Object[]{var259.getEyePos(), var12};
                     Rotation var706 = RotationUtil.aReturningdx_C0210(var260);
                     Object[] var262 = new Object[0];
                     Rotation var261 = var706;
                     float var736 = var261.aReturningFloat(var262);
                     MinecraftClient var263 = b;
                     ClientPlayerEntity var264 = var263.player;
                     float var737 = var736 - var264.getYaw();
                     FloatSetting var265 = this.n;
                     Float var266 = (Float)var265.aReturningObject();
                     float var765;
                     var722 = (var765 = var737 - var266) == 0.0F ? 0 : (var765 < 0.0F ? -1 : 1);
                     int var650 = var44;
                     int var649 = var722;
                     int var426 = var649;
                     int var425 = var649;
                     if (var650 != 0) {
                        int var651 = var425;
                        if (var651 > 0) {
                           return null;
                        }

                        Object[] var269 = new Object[0];
                        Rotation var268 = var706;
                        float var739 = var268.aReturningFloat(var269);
                        MinecraftClient var270 = b;
                        ClientPlayerEntity var271 = var270.player;
                        float var740 = var739 - var271.getYaw();
                        FloatSetting var272 = this.n;
                        Float var273 = (Float)var272.aReturningObject();
                        float var766;
                        int var652 = (var766 = var740 - -var273) == 0.0F ? 0 : (var766 < 0.0F ? -1 : 1);
                        var426 = var652;
                     }

                     int var654 = var44;
                     int var653 = var426;
                     int var428 = var653;
                     int var427 = var653;
                     if (var654 != 0) {
                        int var655 = var427;
                        if (var655 < 0) {
                           return null;
                        }

                        var428 = (((this.x) ? 1 : 0));
                     }

                     int var440;
                     int var657 = var44;
                     int var656 = var428;
                     var440 = var656;
                     int var429 = var656;
                     label348:
                     if (var657 != 0) {
                        int var658 = var429;
                        if (var658 == 0) {
                           Object[] var278 = new Object[]{var705, var8};
                           byte var741 = ((byte)((EntityUtil.aReturningBoolean(var278)) ? 1 : 0));
                           int var660 = var44;
                           byte var659 = var741;
                           var440 = var659;
                           byte var430 = var659;
                           if (var660 == 0) {
                              break label348;
                           }

                           byte var661 = var430;
                           byte var431 = var661;
                           byte var662 = var431;
                           if (var662 != 0) {
                              BooleanSetting var281 = this.d;
                              Boolean var282 = (Boolean)var281.aReturningObject();
                              var741 = ((byte)(((java.lang.Boolean)(var282)).booleanValue() ? 1 : 0));
                              int var664 = var44;
                              byte var663 = var741;
                              var440 = var663;
                              byte var432 = var663;
                              if (var664 == 0) {
                                 break label348;
                              }

                              byte var665 = var432;
                              byte var433 = var665;
                              byte var666 = var433;
                              if (var666 != 0) {
                                 ElapsedTimer var743 = this.u;
                                 var756 = new Object[]{null, var10};
                                 var756[0] = 800.0F;
                                 Object[] var286 = var756;
                                 ElapsedTimer var285 = var743;
                                 var741 = ((byte)((var285.aReturningBoolean(var286)) ? 1 : 0));
                                 int var668 = var44;
                                 byte var667 = var741;
                                 var440 = var667;
                                 byte var434 = var667;
                                 if (var668 == 0) {
                                    break label348;
                                 }

                                 byte var669 = var434;
                                 byte var435 = var669;
                                 byte var670 = var435;
                                 if (var670 != 0) {
                                    Object[] var290 = new Object[]{var22};
                                    AutoMace var289 = this;
                                    var741 = ((byte)((var289.dReturningBoolean(var290)) ? 1 : 0));
                                    int var672 = var44;
                                    byte var671 = var741;
                                    var440 = var671;
                                    byte var436 = var671;
                                    if (var672 == 0) {
                                       break label348;
                                    }

                                    byte var673 = var436;
                                    byte var437 = var673;
                                    byte var674 = var437;
                                    if (var674 != 0) {
                                       Object[] var294 = new Object[]{var30};
                                       AutoMace var293 = this;
                                       var741 = ((byte)((var293.eReturningBoolean(var294)) ? 1 : 0));
                                       int var676 = var44;
                                       byte var675 = var741;
                                       var440 = var675;
                                       byte var438 = var675;
                                       if (var676 == 0) {
                                          break label348;
                                       }

                                       byte var677 = var438;
                                       byte var439 = var677;
                                       byte var678 = var439;
                                       if (var678 != 0) {
                                          Object[] var298 = new Object[]{var28};
                                          AutoMace var297 = this;
                                          int var707 = var297.dReturningInt(var298);
                                          int var679 = var44;
                                          if (var679 != 0) {
                                             
                                             if (var680 != var681) {
                                                Object[] var759 = new Object[]{null, null, null, null, var36};
                                                var759[3] = var699;
                                                var759[2] = var707;
                                                var759[1] = var706;
                                                var759[0] = var705;
                                                Object[] var302 = var759;
                                                AutoMace var301 = this;
                                                return var301.bReturningdx_C0210(var302);
                                             }

                                             this.x = false;
                                          }

                                          return null;
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        Object[] var303 = new Object[]{var4};
                        var440 = (((RaycastUtil.aReturningBoolean(var303)) ? 1 : 0));
                     }

                     int var683 = var44;
                     int var682 = var440;
                     int var442 = var682;
                     int var441 = var682;
                     if (var683 != 0) {
                        int var684 = var441;
                        if (var684 != 0) {
                           return null;
                        }

                        Object[] var306 = new Object[]{var38};
                        var442 = InventoryUtil.aReturningInt(var306);
                     }

                     int var686 = var44;
                     int var685 = var442;
                     int var444 = var685;
                     int var443 = var685;
                     if (var686 != 0) {
                        int var688 = var699;
                        int var687 = var443;
                        if (var687 != var688) {
                           Object[] var309 = new Object[]{var26};
                           AutoMace var308 = this;
                           var308.kReturningVoid(var309);
                           var751 = new Object[]{null, var20};
                           var751[0] = var699;
                           Object[] var310 = var751;
                           InventoryUtil.aReturningVoid(var310);
                        }

                        Object[] var312 = new Object[]{var705, var40};
                        ItemUseUtil.aReturningVoid(var312);
                        ElapsedTimer var747 = this.t;
                        Object[] var314 = new Object[]{var34};
                        ElapsedTimer var313 = var747;
                        var313.aReturningVoid(var314);
                        BooleanSetting var315 = this.p;
                        Boolean var316 = (Boolean)var315.aReturningObject();
                        var444 = ((((java.lang.Boolean)(var316)).booleanValue() ? 1 : 0));
                     }

                     AutoMace var449;
                     label601: {
                        int var690 = var44;
                        int var689 = var444;
                        int var448 = var689;
                        int var445 = var689;
                        if (var690 != 0) {
                           int var691 = var445;
                           if (var691 == 0) {
                              return var706;
                           }

                           int var693 = var44;
                           AutoMace var692 = this;
                           var449 = var692;
                           AutoMace var446 = var692;
                           if (var693 == 0) {
                              break label601;
                           }

                           AutoMace var694 = var446;
                           AutoMace var447 = var694;
                           int var695 = var447.z;
                           var448 = var695;
                        }

                        
                        if (var696 == var697) {
                           return var706;
                        }

                        ElapsedTimer var748 = this.v;
                        Object[] var321 = new Object[]{var34};
                        ElapsedTimer var320 = var748;
                        var320.aReturningVoid(var321);
                        AutoMace var698 = this;
                        var449 = var698;
                     }

                     var449.A = true;
                     return var706;
                  }

                  return null;
               }
            }
         }

         var450 = this;
      }

      var450.x = false;
      return null;
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      PlayerEntity var6 = (PlayerEntity)var1[0];
      Rotation var7 = (Rotation)var1[1];
      int var2 = (Integer)var1[2];
      int var3 = (Integer)var1[3];
      long var4 = (Long)var1[4];
      var4 = 58647587722062L ^ var4;
      long var8 = var4 ^ 46041619735935L;
      long var10 = var4 ^ 37557422279280L;
      long var12 = var4 ^ 86719085611017L;
      long var14 = var4 ^ 115201191295639L;
      long var16 = var4 ^ 87965945039887L;
      int var18 = Event.bReturningInt();
      Object[] var20 = new Object[]{var10};
      int var10000 = InventoryUtil.aReturningInt(var20);
      int var35 = var18;
      int var34 = var10000;
      int var33 = var34;
      int var32 = var34;
      if (var35 == 0) {
         int var37 = var2;
         int var36 = var32;
         if (var36 != var37) {
            Object[] var23 = new Object[]{var16};
            AutoMace var22 = this;
            var22.kReturningVoid(var23);
            Object[] var10003 = new Object[]{null, var12};
            var10003[0] = var2;
            Object[] var24 = var10003;
            InventoryUtil.aReturningVoid(var24);
         }

         IntSetting var26 = this.j;
         Integer var27 = (Integer)var26.aReturningObject();
         var33 = var27;
      }

      int var19 = var33;
      int var38 = var18;
      if (var38 == 0) {
         int var39 = var19;
         if (var39 <= 0) {
            this.y = dev.prestige.recovery.SourceSupport.asBoolean(1);
            Object[] var29 = new Object[]{var6, var14};
            ItemUseUtil.aReturningVoid(var29);
            this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
            ElapsedTimer var41 = this.u;
            Object[] var31 = new Object[]{var8};
            ElapsedTimer var30 = var41;
            var30.aReturningVoid(var31);
            return var7;
         }

         this.C = var6;
         this.D = var7;
         this.F = var3;
         this.E = System.currentTimeMillis();
      }

      return var7;
   }

   private Rotation cReturningdx_C0210(Object[] var1) {
      long var4;
      long var8;
      long var10;
      int var14;
      int var84;
      label110: {
         AutoMace var83;
         label113: {
            int var80;
            label108: {
               Object var79;
               long var2 = (Long)var1[0];
               var2 = 58647587722062L ^ var2;
               var4 = var2 ^ 128973600658047L;
               long var6 = var2 ^ 85531103086686L;
               var8 = var2 ^ 77228372633425L;
               var10 = var2 ^ 47053399713064L;
               long var12 = var2 ^ 14104596207542L;
               var14 = Event.cReturningInt();
               int var93 = var14;
               PlayerEntity var92 = this.C;
               var79 = var92;
               PlayerEntity var68 = var92;
               label107:
               if (var93 != 0) {
                  PlayerEntity var94 = var68;
                  if (var94 != null) {
                     PlayerEntity var23 = this.C;
                     int var10000 = (((var23.isAlive()) ? 1 : 0));
                     int var96 = var14;
                     byte var95 = (byte)var10000;
                     var80 = var95;
                     byte var69 = var95;
                     if (var96 == 0) {
                        break label108;
                     }

                     byte var97 = var69;
                     byte var70 = var97;
                     byte var98 = var70;
                     if (var98 != 0) {
                        MinecraftClient var26 = b;
                        int var100 = var14;
                        ClientPlayerEntity var99 = var26.player;
                        var79 = var99;
                        ClientPlayerEntity var71 = var99;
                        if (var100 == 0) {
                           break label107;
                        }

                        ClientPlayerEntity var101 = var71;
                        ClientPlayerEntity var72 = var101;
                        ClientPlayerEntity var102 = var72;
                        if (var102 != null) {
                           MinecraftClient var29 = b;
                           int var104 = var14;
                           ClientWorld var103 = var29.world;
                           var79 = var103;
                           ClientWorld var73 = var103;
                           if (var104 == 0) {
                              break label107;
                           }

                           ClientWorld var105 = var73;
                           ClientWorld var74 = var105;
                           ClientWorld var106 = var74;
                           if (var106 != null) {
                              MinecraftClient var32 = b;
                              PlayerEntity var34 = this.C;
                              ClientPlayerEntity var33 = var32.player;
                              float var147;
                              var10000 = (var147 = var33.distanceTo((Entity)var34) - 6.0F) == 0.0F ? 0 : (var147 < 0.0F ? -1 : 1);
                              int var108 = var14;
                              int var107 = var10000;
                              var80 = var107;
                              int var75 = var107;
                              if (var108 == 0) {
                                 break label108;
                              }

                              int var109 = var75;
                              int var76 = var109;
                              int var110 = var76;
                              if (var110 <= 0) {
                                 long var15 = System.currentTimeMillis() - this.E;
                                 IntSetting var54 = this.j;
                                 Integer var55 = (Integer)var54.aReturningObject();
                                 long var143 = var55.intValue();
                                 short var10001 = 5268;
                                 long var10002 = 692817427672446110L ^ var2;
                                 long var17 = var143 * 50L;
                                 long var148;
                                 int var131 = (var148 = var15 - var17) == 0L ? 0 : (var148 < 0L ? -1 : 1);
                                 if (var131 < 0) {
                                    return this.D;
                                 }

                                 PlayerEntity var19 = this.C;
                                 Rotation var20 = this.D;
                                 int var21 = this.F;
                                 this.y = dev.prestige.recovery.SourceSupport.asBoolean(1);
                                 Object[] var57 = new Object[]{var19, var12};
                                 ItemUseUtil.aReturningVoid(var57);
                                 this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
                                 ElapsedTimer var144 = this.u;
                                 Object[] var59 = new Object[]{var6};
                                 ElapsedTimer var58 = var144;
                                 var58.aReturningVoid(var59);
                                 int var132 = var14;
                                 if (var132 != 0) {
                                    int var133 = var21;
                                    label64:
                                    if (var133 >= 0) {
                                       Object[] var61 = new Object[]{var8};
                                       var10000 = InventoryUtil.aReturningInt(var61);
                                       int var135 = var14;
                                       int var134 = var10000;
                                       int var91 = var134;
                                       int var89 = var134;
                                       if (var135 != 0) {
                                          int var136 = var89;
                                          int var90 = var136;
                                          int var138 = var21;
                                          int var137 = var90;
                                          if (var137 == var138) {
                                             break label64;
                                          }

                                          int var139 = var21;
                                          var91 = var139;
                                       }

                                       Object[] var10003 = new Object[]{null, var10};
                                       var10003[0] = var91;
                                       Object[] var65 = var10003;
                                       InventoryUtil.aReturningVoid(var65);
                                    }

                                    Object[] var67 = new Object[]{var4};
                                    AutoMace var66 = this;
                                    var66.jReturningVoid(var67);
                                 }

                                 return var20;
                              }
                           }
                        }
                     }
                  }

                  int var112 = var14;
                  AutoMace var111 = this;
                  var83 = var111;
                  AutoMace var77 = var111;
                  if (var112 == 0) {
                     break label113;
                  }

                  AutoMace var113 = var77;
                  AutoMace var78 = var113;
                  BooleanSetting var38 = var78.p;
                  Object var114 = var38.aReturningObject();
                  var79 = var114;
               }

               Boolean var40 = (Boolean)var79;
               var80 = ((((java.lang.Boolean)(var40)).booleanValue() ? 1 : 0));
            }

            int var115 = var80;
            if (var115 != 0) {
               int var117 = var14;
               AutoMace var116 = this;
               var83 = var116;
               AutoMace var81 = var116;
               if (var117 == 0) {
                  break label113;
               }

               AutoMace var118 = var81;
               AutoMace var82 = var118;
               
               if (var119 != var120) {
                  int var121 = this.z;
                  var84 = var121;
                  break label110;
               }
            }

            var83 = this;
         }

         var84 = var83.F;
      }

      int var141 = var84;
      Object[] var45 = new Object[]{var4};
      AutoMace var44 = this;
      var44.jReturningVoid(var45);
      Object[] var47 = new Object[0];
      AutoMace var46 = this;
      var46.mReturningVoid(var47);
      int var123 = var14;
      int var122 = var141;
      int var86 = var122;
      int var85 = var122;
      if (var123 != 0) {
         int var124 = var85;
         if (var124 < 0) {
            return null;
         }

         Object[] var49 = new Object[]{var8};
         int var125 = InventoryUtil.aReturningInt(var49);
         var86 = var125;
      }

      int var127 = var14;
      int var126 = var86;
      int var88 = var126;
      int var87 = var126;
      if (var127 != 0) {
         int var129 = var141;
         int var128 = var87;
         if (var128 == var129) {
            return null;
         }

         int var130 = var141;
         var88 = var130;
      }

      Object[] var146 = new Object[]{null, var10};
      var146[0] = var88;
      Object[] var53 = var146;
      InventoryUtil.aReturningVoid(var53);
      return null;
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 58647587722062L ^ var2;
      this.C = null;
      this.D = null;
      short var10001 = 32266;
      long var10002 = 8355920036462812976L ^ var2;
      this.E = 0L;
      this.F = -1;
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 58647587722062L ^ var2;
      long var4 = var2 ^ 84147941521982L;
      long var6 = var2 ^ 78612306482481L;
      int var8 = Event.cReturningInt();
      BooleanSetting var9 = this.p;
      Boolean var10 = (Boolean)var9.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
      int var26 = var8;
      byte var25 = var10000;
      int var20 = var25;
      byte var19 = var25;
      if (var26 != 0) {
         byte var27 = var19;
         if (var27 == 0) {
            return;
         }

         int var28 = this.z;
         var20 = var28;
      }

      AutoMace var24;
      label35: {
         int var30 = var8;
         int var29 = var20;
         int var23 = var29;
         int var21 = var29;
         if (var30 != 0) {
            
            if (var31 != var32) {
               return;
            }

            int var34 = var8;
            AutoMace var33 = this;
            var24 = var33;
            AutoMace var22 = var33;
            if (var34 == 0) {
               break label35;
            }

            byte var35 = ((byte)((var22.B) ? 1 : 0));
            var23 = var35;
         }

         int var36 = var23;
         if (var36 != 0) {
            return;
         }

         Object[] var16 = new Object[]{var6};
         this.z = InventoryUtil.aReturningInt(var16);
         var24 = this;
      }

      ElapsedTimer var38 = var24.w;
      Object[] var18 = new Object[]{var4};
      ElapsedTimer var17 = var38;
      var17.aReturningVoid(var18);
   }

   private void lReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 58647587722062L ^ var2;
      long var4 = var2 ^ 16452713848784L;
      long var6 = var2 ^ 107756077014441L;
      int var10000 = Event.cReturningInt();
      int var9 = this.z;
      int var8 = var10000;
      Object[] var11 = new Object[0];
      AutoMace var10 = this;
      var10.mReturningVoid(var11);
      int var23 = var8;
      int var22 = var9;
      int var19 = var22;
      int var18 = var22;
      if (var23 != 0) {
         int var24 = var18;
         if (var24 < 0) {
            return;
         }

         Object[] var13 = new Object[]{var4};
         int var25 = InventoryUtil.aReturningInt(var13);
         var19 = var25;
      }

      int var27 = var8;
      int var26 = var19;
      int var21 = var26;
      int var20 = var26;
      if (var27 != 0) {
         int var29 = var9;
         int var28 = var20;
         if (var28 == var29) {
            return;
         }

         int var30 = var9;
         var21 = var30;
      }

      Object[] var10003 = new Object[]{null, var6};
      var10003[0] = var21;
      Object[] var17 = var10003;
      InventoryUtil.aReturningVoid(var17);
   }

   private void mReturningVoid(Object[] var1) {
      this.z = -1;
      this.A = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private boolean dReturningBoolean(Object[] var1) {
      int var6;
      Object var54;
      label70: {
         long var2 = (Long)var1[0];
         var2 = 58647587722062L ^ var2;
         long var4 = var2 ^ 7105378238642L;
         var6 = Event.cReturningInt();
         BooleanSetting var12 = this.d;
         Boolean var13 = (Boolean)var12.aReturningObject();
         int var10000 = ((((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
         int var61 = var6;
         boolean var60 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
         boolean var47 = var60;
         boolean var45 = var60;
         if (var61 != 0) {
            boolean var62 = var45;
            if (!var62) {
               return false;
            }

            ModeSetting var16 = this.e;
            String var85 = (String)var16.aReturningObject();
            int var64 = var6;
            String var63 = var85;
            var54 = var63;
            String var46 = var63;
            if (var64 == 0) {
               break label70;
            }

            short var10001 = 23194;
            long var10002 = 2321572367120242513L ^ var2;
            String var18 = "Hold Key";
            String var17 = var46;
            boolean var65 = var17.equals(var18);
            var47 = var65;
         }

         boolean var66 = var47;
         if (var66) {
            BindSetting var20 = this.f;
            Integer var21 = (Integer)var20.aReturningObject();
            var10000 = var21;
            int var68 = var6;
            int var67 = var10000;
            int var50 = var67;
            int var48 = var67;
            if (var68 != 0) {
               int var69 = var48;
               int var49 = var69;
               
               if (var70 == var71) {
                  return false;
               }

               BindSetting var87 = this.f;
               Object[] var25 = new Object[]{var4};
               BindSetting var24 = var87;
               byte var72 = ((byte)((var24.cReturningBoolean(var25)) ? 1 : 0));
               var50 = var72;
            }

            int var74 = var6;
            int var73 = var50;
            int var52 = var73;
            int var51 = var73;
            if (var74 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var52);
            }

            int var75 = var51;
            if (var75 != 0) {
               byte var91 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var91);
            }

            return false;
         }

         FloatSetting var28 = this.g;
         var54 = var28.aReturningObject();
      }

      Float var29 = (Float)var54;
      float var7 = var29;
      BooleanSetting var30 = this.h;
      Boolean var31 = (Boolean)var30.aReturningObject();
      byte var88 = ((byte)(((java.lang.Boolean)(var31)).booleanValue() ? 1 : 0));
      int var78 = var6;
      byte var77 = var88;
      int var56 = var77;
      byte var55 = var77;
      if (var78 != 0) {
         byte var79 = var55;
         if (var79 != 0) {
            MinecraftClient var33 = b;
            ClientPlayerEntity var34 = var33.player;
            float var8 = (float)var34.fallDistance;
            FloatSetting var35 = this.c;
            Float var36 = (Float)var35.aReturningObject();
            float var89 = var36;
            FloatSetting var37 = this.i;
            Float var38 = (Float)var37.aReturningObject();
            float var40 = var38;
            float var39 = var89;
            float var9 = Math.max(var39, var40);
            float var10 = 10.0F;
            float var42 = (var8 - var9) / var10;
            float var41 = 1.0F;
            float var44 = Math.min(var41, var42);
            float var43 = 0.0F;
            float var11 = Math.max(var43, var44);
            var7 *= var11;
         }

         double var90;
         var56 = (var90 = Math.random() * 100.0 - var7) == 0.0 ? 0 : (var90 < 0.0 ? -1 : 1);
      }

      int var81 = var6;
      int var80 = var56;
      int var58 = var80;
      int var57 = var80;
      if (var81 != 0) {
         int var82 = var57;
         if (var82 >= 0) {
            return false;
         }

         var58 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var58);
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 58647587722062L ^ var2;
      int var21 = Event.bReturningInt();
      FloatSetting var6 = this.c;
      Float var7 = (Float)var6.aReturningObject();
      float var10001 = var7;
      FloatSetting var8 = this.i;
      Float var9 = (Float)var8.aReturningObject();
      float var11 = var9;
      float var10 = var10001;
      float var5 = Math.max(var10, var11);
      int var4 = var21;
      MinecraftClient var12 = b;
      ClientPlayerEntity var13 = var12.player;
      double var23;
      int var22 = (var23 = var13.fallDistance - var5) == 0.0 ? 0 : (var23 < 0.0 ? -1 : 1);
      int var18 = var4;
      int var17 = var22;
      int var15 = var17;
      int var14 = var17;
      if (var18 == 0) {
         int var19 = var14;
         if (var19 < 0) {
            return false;
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   @EventListener
   public void a(EntityBoundingBoxEvent var1) {
      int var6;
      Object var42;
      label40: {
         long var10001 = 15138948908142L ^ 134348319534617L;
         var6 = Event.bReturningInt();
         BooleanSetting var8 = this.r;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var10000 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         int var46 = var6;
         byte var45 = var10000;
         int var41 = var45;
         byte var38 = var45;
         if (var46 == 0) {
            byte var47 = var38;
            if (var47 == 0) {
               return;
            }

            MinecraftClient var11 = b;
            int var49 = var6;
            ClientPlayerEntity var48 = var11.player;
            var42 = var48;
            ClientPlayerEntity var39 = var48;
            if (var49 != 0) {
               break label40;
            }

            ClientPlayerEntity var50 = var39;
            ClientPlayerEntity var40 = var50;
            ClientPlayerEntity var13 = var40;
            double var57 = var13.fallDistance;
            FloatSetting var14 = this.c;
            Float var15 = (Float)var14.aReturningObject();
            double var60;
            int var51 = (var60 = var57 - var15.floatValue()) == 0.0 ? 0 : (var60 < 0.0 ? -1 : 1);
            var41 = var51;
         }

         int var52 = var41;
         if (var52 <= 0) {
            return;
         }

         FloatSetting var17 = this.a;
         Float var18 = (Float)var17.aReturningObject();
         float var58 = var18;
         Object[] var10004 = new Object[]{null, 131892681681527L};
         var10004[0] = var58;
         Object[] var20 = var10004;
         AutoMace var19 = this;
         var42 = var19.aReturningPlayerEntity(var20);
      }

      Object var7 = var42;
      int var54 = var6;
      Object var53 = var7;
      Object var44 = var53;
      Object var43 = var53;
      if (var54 == 0) {
         Object var55 = var43;
         if (var55 == null) {
            return;
         }

         var44 = var7;
      }

      Object[] var23 = new Object[0];
      EntityBoundingBoxEvent var22 = var1;
      Entity var25 = var22.aReturningEntity(var23);
      Object var24 = var44;
      boolean var56 = ((PlayerEntity)var24).equals(var25);
      if (var56) {
         Object[] var28 = new Object[0];
         EntityBoundingBoxEvent var27 = var1;
         Box var59 = var27.aReturningBox(var28);
         FloatSetting var29 = this.s;
         Float var30 = (Float)var29.aReturningObject();
         double var32 = var30.floatValue() / 5.0;
         Box var31 = var59;
         Object[] var35 = new Object[]{var31.expand(var32)};
         EntityBoundingBoxEvent var34 = var1;
         var34.bReturningVoid(var35);
         Object[] var37 = new Object[0];
         EntityBoundingBoxEvent var36 = var1;
         var36.aReturningVoid(var37);
      }
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 52804966232702L ^ 39674558162044L;
      var10001 = 52804966232702L ^ 32528878333690L;
      var10001 = 52804966232702L ^ 79105600100361L;
      var10001 = 52804966232702L ^ 118046458395075L;
      var10001 = 52804966232702L ^ 86332370576490L;
      var10001 = 52804966232702L ^ 25236320049790L;
      var10001 = 52804966232702L ^ 120874814260287L;
      var10001 = 52804966232702L ^ 31905891726705L;
      var10001 = 52804966232702L ^ 119524752023470L;
      var10001 = 52804966232702L ^ 125288286320392L;
      var10001 = 52804966232702L ^ 122239155434254L;
      int var26 = Event.bReturningInt();
      int var137 = var26;
      AutoMace var136 = this;
      AutoMace var97 = var136;
      AutoMace var96 = var136;
      if (var137 == 0) {
         boolean var138 = var96.y;
         if (var138) {
            return;
         }

         var97 = this;
      }

      int var28;
      int var118;
      byte var119;
      label147: {
         int var117;
         FloatSetting var31 = this.a;
         Float var32 = (Float)var31.aReturningObject();
         float var229 = var32;
         Object[] var10004 = new Object[]{null, 131892681681527L};
         var10004[0] = var229;
         Object[] var34 = var10004;
         AutoMace var33 = var97;
         PlayerEntity var27 = var33.aReturningPlayerEntity(var34);
         int var140 = var26;
         byte var139 = ((byte)((this.x) ? 1 : 0));
         var117 = var139;
         byte var98 = var139;
         label146:
         if (var140 == 0) {
            byte var141 = var98;
            if (var141 == 0) {
               MinecraftClient var36 = b;
               ClientPlayerEntity var37 = var36.player;
               double var10000 = var37.fallDistance;
               FloatSetting var38 = this.c;
               Float var39 = (Float)var38.aReturningObject();
               double var231;
               int var208 = (var231 = var10000 - var39.floatValue()) == 0.0 ? 0 : (var231 < 0.0 ? -1 : 1);
               int var143 = var26;
               int var142 = var208;
               var117 = var142;
               int var99 = var142;
               if (var143 != 0) {
                  break label146;
               }

               int var144 = var99;
               int var100 = var144;
               int var145 = var100;
               label142:
               if (var145 > 0) {
                  int var147 = var26;
                  PlayerEntity var146 = var27;
                  PlayerEntity var103 = var146;
                  PlayerEntity var101 = var146;
                  if (var147 == 0) {
                     PlayerEntity var148 = var101;
                     PlayerEntity var102 = var148;
                     PlayerEntity var149 = var102;
                     if (var149 == null) {
                        break label142;
                     }

                     var103 = var27;
                  }

                  Object[] var44 = new Object[]{var103, 100443321076669L};
                  byte var209 = ((byte)((EntityUtil.aReturningBoolean(var44)) ? 1 : 0));
                  int var151 = var26;
                  byte var150 = var209;
                  var117 = var150;
                  byte var104 = var150;
                  if (var151 != 0) {
                     break label146;
                  }

                  byte var152 = var104;
                  if (var152 != 0) {
                     MinecraftClient var46 = b;
                     ClientPlayerEntity var47 = var46.player;
                     ItemStack var48 = var47.getMainHandStack();
                     byte var210 = ((byte)((var48.getItem() instanceof AxeItem) ? 1 : 0));
                     int var154 = var26;
                     byte var153 = var210;
                     var117 = var153;
                     byte var105 = var153;
                     if (var154 != 0) {
                        break label146;
                     }

                     byte var155 = var105;
                     byte var106 = var155;
                     byte var156 = var106;
                     if (var156 != 0) {
                        BooleanSetting var51 = this.d;
                        Boolean var52 = (Boolean)var51.aReturningObject();
                        byte var211 = ((byte)(((java.lang.Boolean)(var52)).booleanValue() ? 1 : 0));
                        int var158 = var26;
                        byte var157 = var211;
                        var117 = var157;
                        byte var107 = var157;
                        if (var158 != 0) {
                           break label146;
                        }

                        byte var159 = var107;
                        byte var108 = var159;
                        byte var160 = var108;
                        if (var160 != 0) {
                           ElapsedTimer var212 = this.u;
                           var10004 = new Object[]{null, 139098136696340L};
                           var10004[0] = 800.0F;
                           Object[] var56 = var10004;
                           ElapsedTimer var55 = var212;
                           byte var213 = ((byte)((var55.aReturningBoolean(var56)) ? 1 : 0));
                           int var162 = var26;
                           byte var161 = var213;
                           var117 = var161;
                           byte var109 = var161;
                           if (var162 != 0) {
                              break label146;
                           }

                           byte var163 = var109;
                           byte var110 = var163;
                           byte var164 = var110;
                           if (var164 != 0) {
                              Object[] var60 = new Object[]{101926471724496L};
                              AutoMace var59 = this;
                              byte var214 = ((byte)((var59.dReturningBoolean(var60)) ? 1 : 0));
                              int var166 = var26;
                              byte var165 = var214;
                              var117 = var165;
                              byte var111 = var165;
                              if (var166 != 0) {
                                 break label146;
                              }

                              byte var167 = var111;
                              byte var112 = var167;
                              byte var168 = var112;
                              if (var168 != 0) {
                                 Object[] var64 = new Object[]{50110012447876L};
                                 AutoMace var63 = this;
                                 byte var215 = ((byte)((var63.eReturningBoolean(var64)) ? 1 : 0));
                                 int var170 = var26;
                                 byte var169 = var215;
                                 var117 = var169;
                                 byte var113 = var169;
                                 if (var170 != 0) {
                                    break label146;
                                 }

                                 byte var171 = var113;
                                 byte var114 = var171;
                                 byte var172 = var114;
                                 if (var172 != 0) {
                                    Object[] var68 = new Object[]{22075841648130L};
                                    AutoMace var67 = this;
                                    var28 = var67.dReturningInt(var68);
                                    int var175 = var26;
                                    
                                    var118 = var173;
                                    var119 = var174;
                                    int var115 = var173;
                                    byte var116 = var174;
                                    if (var175 != 0) {
                                       break label147;
                                    }

                                    byte var177 = var116;
                                    int var176 = var115;
                                    if (var176 != var177) {
                                       this.x = dev.prestige.recovery.SourceSupport.asBoolean(1);
                                       return;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }

            Object[] var72 = new Object[]{103258548663873L};
            AutoMace var71 = this;
            var117 = var71.eReturningInt(var72);
         }

         var28 = var117;
         var119 = -1;
         var118 = var28;
      }

      int var126;
      label153: {
         int var180 = var26;
         byte var179 = var119;
         int var178 = var118;
         int var124 = var178;
         int var125 = var179;
         int var120 = var178;
         byte var121 = var179;
         if (var180 == 0) {
            byte var182 = var121;
            int var181 = var120;
            if (var181 == var182) {
               return;
            }

            Object[] var74 = new Object[]{49487520630543L};
            int var216 = InventoryUtil.aReturningInt(var74);
            int var184 = var26;
            int var183 = var216;
            var126 = var183;
            int var122 = var183;
            if (var184 != 0) {
               break label153;
            }

            int var185 = var122;
            int var123 = var185;
            int var187 = var28;
            int var186 = var123;
            var124 = var186;
            var125 = var187;
         }

         int var189 = var125;
         int var188 = var124;
         if (var188 == var189) {
            return;
         }

         MinecraftClient var77 = b;
         byte var190 = ((byte)((var77.crosshairTarget instanceof EntityHitResult) ? 1 : 0));
         var126 = var190;
      }

      int var192 = var26;
      int var191 = var126;
      int var128 = var191;
      int var127 = var191;
      if (var192 == 0) {
         int var193 = var127;
         if (var193 == 0) {
            return;
         }

         MinecraftClient var80 = b;
         ClientPlayerEntity var81 = var80.player;
         double var217 = var81.fallDistance;
         FloatSetting var82 = this.c;
         Float var83 = (Float)var82.aReturningObject();
         double var232;
         int var194 = (var232 = var217 - var83.floatValue()) == 0.0 ? 0 : (var232 < 0.0 ? -1 : 1);
         var128 = var194;
      }

      int var196 = var26;
      int var195 = var128;
      int var130 = var195;
      int var129 = var195;
      if (var196 == 0) {
         int var197 = var129;
         if (var197 <= 0) {
            return;
         }

         Object[] var87 = new Object[]{104640841433456L};
         AutoMace var86 = this;
         var86.kReturningVoid(var87);
         Object[] var10003 = new Object[]{null, 72518082610550L};
         var10003[0] = var28;
         Object[] var88 = var10003;
         InventoryUtil.aReturningVoid(var88);
         BooleanSetting var89 = this.p;
         Boolean var90 = (Boolean)var89.aReturningObject();
         var130 = ((((java.lang.Boolean)(var90)).booleanValue() ? 1 : 0));
      }

      AutoMace var135;
      label155: {
         int var199 = var26;
         int var198 = var130;
         int var134 = var198;
         int var131 = var198;
         if (var199 == 0) {
            int var200 = var131;
            if (var200 == 0) {
               return;
            }

            int var202 = var26;
            AutoMace var201 = this;
            var135 = var201;
            AutoMace var132 = var201;
            if (var202 != 0) {
               break label155;
            }

            AutoMace var203 = var132;
            AutoMace var133 = var203;
            int var204 = var133.z;
            var134 = var204;
         }

         
         if (var205 == var206) {
            return;
         }

         ElapsedTimer var218 = this.v;
         Object[] var95 = new Object[]{42835128969216L};
         ElapsedTimer var94 = var218;
         var94.aReturningVoid(var95);
         AutoMace var207 = this;
         var135 = var207;
      }

      var135.A = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   private PlayerEntity aReturningPlayerEntity(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      var3 = 58647587722062L ^ var3;
      long var5 = var3 ^ 112199131137256L;
      int var10000 = Event.bReturningInt();
      float var8 = var2 * var2;
      int var7 = var10000;
      PlayerEntity var9 = null;
      double var10 = Double.MAX_VALUE;
      MinecraftClient var17 = b;
      ClientWorld var18 = var17.world;
      List var19 = var18.getPlayers();
      Iterator var12 = var19.iterator();

      PlayerEntity var53;
      while (true) {
         Iterator var20 = var12;
         boolean var54 = var20.hasNext();
         if (var54) {
            Iterator var21 = var12;
            PlayerEntity var13 = (PlayerEntity)var21.next();
            int var56 = var7;
            PlayerEntity var55 = var13;
            var53 = var55;
            PlayerEntity var41 = var55;
            if (var56 != 0) {
               break;
            }

            PlayerEntity var22 = var41;
            int var76 = (((var22.isAlive()) ? 1 : 0));
            int var58 = var7;
            boolean var57 = dev.prestige.recovery.SourceSupport.asBoolean(var76);
            boolean var44 = var57;
            boolean var42 = var57;
            if (var58 == 0) {
               boolean var59 = var42;
               boolean var43 = var59;
               boolean var60 = var43;
               if (!var60) {
                  continue;
               }

               MinecraftClient var25 = b;
               ClientPlayerEntity var27 = var25.player;
               PlayerEntity var26 = var13;
               var44 = var26.equals(var27);
            }

            int var62 = var7;
            boolean var61 = var44;
            boolean var46 = var61;
            boolean var45 = var61;
            if (var62 == 0) {
               boolean var63 = var45;
               if (var63) {
                  continue;
               }

               SocialsManager var77 = Prestige.g;
               PlayerEntity var29 = var13;
               Text var30 = var29.getName();
               Object[] var32 = new Object[]{var30.getString(), var5};
               SocialsManager var31 = var77;
               var46 = var31.aReturningBoolean(var32);
            }

            boolean var64 = var46;
            if (var64) {
               int var65 = var7;
               if (var65 == 0) {
                  continue;
               }
            }

            label52: {
               double var51;
               label65: {
                  PlayerEntity var34 = var13;
                  double var10002 = var34.getX();
                  MinecraftClient var35 = b;
                  ClientPlayerEntity var36 = var35.player;
                  double var10003 = var36.getY();
                  PlayerEntity var37 = var13;
                  Vec3d var14 = new Vec3d(var10002, var10003, var37.getZ());
                  MinecraftClient var38 = b;
                  Vec3d var40 = var14;
                  ClientPlayerEntity var39 = var38.player;
                  double var15 = var39.squaredDistanceTo(var40);
                  double var79;
                  var76 = (var79 = var15 - var8) == 0.0 ? 0 : (var79 < 0.0 ? -1 : 1);
                  int var67 = var7;
                  int var66 = var76;
                  int var50 = var66;
                  int var47 = var66;
                  if (var67 == 0) {
                     int var68 = var47;
                     if (var68 > 0) {
                        continue;
                     }

                     int var71 = var7;
                     double var69 = var15;
                     var51 = var69;
                     double var48 = var69;
                     if (var71 != 0) {
                        break label65;
                     }

                     double var80;
                     int var72 = (var80 = var48 - var10) == 0.0 ? 0 : (var80 < 0.0 ? -1 : 1);
                     var50 = var72;
                  }

                  int var73 = var50;
                  if (var73 >= 0) {
                     break label52;
                  }

                  var51 = var15;
               }

               var10 = var51;
               var9 = var13;
            }

            int var74 = var7;
            if (var74 == 0) {
               continue;
            }
         }

         var53 = var9;
         break;
      }

      return var53;
   }

   private boolean fReturningBoolean(Object[] var1) {
      long var4;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      long var18;
      int var20;
      Object var88;
      long var152;
      label118: {
         long var2 = (Long)var1[0];
         var152 = 58647587722062L ^ var2;
         var4 = var152 ^ 69622231066653L;
         long var6 = var152 ^ 97280485475377L;
         var8 = var152 ^ 128466780317179L;
         var10 = var152 ^ 117889564164477L;
         var12 = var152 ^ 133301073552832L;
         var14 = var152 ^ 81693862924883L;
         var16 = var152 ^ 121466611477296L;
         var18 = var152 ^ 31506070852811L;
         var20 = Event.cReturningInt();
         BooleanSetting var25 = this.o;
         Boolean var26 = (Boolean)var25.aReturningObject();
         byte var10000 = ((byte)(((java.lang.Boolean)(var26)).booleanValue() ? 1 : 0));
         int var113 = var20;
         byte var112 = var10000;
         int var87 = var112;
         byte var85 = var112;
         if (var113 != 0) {
            byte var114 = var85;
            if (var114 == 0) {
               return false;
            }

            MinecraftClient var29 = b;
            int var116 = var20;
            ClientPlayerEntity var115 = var29.player;
            var88 = var115;
            ClientPlayerEntity var86 = var115;
            if (var116 == 0) {
               break label118;
            }

            ClientPlayerEntity var30 = var86;
            double var154 = var30.fallDistance;
            FloatSetting var31 = this.c;
            Float var32 = (Float)var31.aReturningObject();
            double var174;
            int var117 = (var174 = var154 - var32.floatValue()) == 0.0 ? 0 : (var174 < 0.0 ? -1 : 1);
            var87 = var117;
         }

         int var118 = var87;
         if (var118 < 0) {
            return false;
         }

         FloatSetting var35 = this.a;
         Float var36 = (Float)var35.aReturningObject();
         float var10001 = var36;
         Object[] var10004 = new Object[]{null, var6};
         var10004[0] = var10001;
         Object[] var38 = var10004;
         AutoMace var37 = this;
         var88 = var37.aReturningPlayerEntity(var38);
      }

      Object var21 = var88;
      int var120 = var20;
      Object var119 = var21;
      Object var90 = var119;
      Object var89 = var119;
      if (var120 != 0) {
         Object var121 = var89;
         if (var121 == null) {
            return false;
         }

         var90 = var21;
      }

      Object var41 = var90;
      int var155 = (((((PlayerEntity)var41).isAlive()) ? 1 : 0));
      int var123 = var20;
      byte var122 = (byte)var155;
      byte var98 = var122;
      byte var91 = var122;
      if (var123 != 0) {
         byte var124 = var91;
         label104:
         if (var124 != 0) {
            MinecraftClient var43 = b;
            Object var45 = var21;
            ClientPlayerEntity var44 = var43.player;
            float var156 = var44.distanceTo((Entity)var45);
            Object[] var46 = new Object[]{var21, var8};
            boolean var126 = EntityUtil.aReturningBoolean(var46);
            float var125 = var156;
            float var94 = var125;
            float var92 = var125;
            float var95;
            float var96;
            if (var126) {
               float var127 = var92;
               float var93 = var127;
               float var129 = 8.0F;
               float var128 = var93;
               var95 = var128;
               var96 = var129;
            } else {
               var96 = 6.0F;
               var95 = var94;
            }

            float var175;
            var155 = (var175 = var95 - var96) == 0.0F ? 0 : (var175 < 0.0F ? -1 : 1);
            int var131 = var20;
            int var130 = var155;
            int var99 = var130;
            int var97 = var130;
            if (var131 != 0) {
               int var132 = var97;
               if (var132 > 0) {
                  break label104;
               }

               Object[] var50 = new Object[]{var4};
               var99 = (((RaycastUtil.aReturningBoolean(var50)) ? 1 : 0));
            }

            int var134 = var20;
            int var133 = var99;
            int var101 = var133;
            int var100 = var133;
            if (var134 != 0) {
               int var135 = var100;
               if (var135 != 0) {
                  MinecraftClient var52 = b;
                  EquipmentSlot var54 = EquipmentSlot.CHEST;
                  ClientPlayerEntity var53 = var52.player;
                  ItemStack var55 = var53.getEquippedStack(var54);
                  Item var158 = var55.getItem();
                  int var137 = var20;
                  Item var136 = var158;
                  Item var103 = var136;
                  Item var102 = var136;
                  if (var137 != 0) {
                     Item var139 = Items.ELYTRA;
                     Item var138 = var102;
                     if (var138 != var139) {
                        return false;
                     }

                     var103 = Items.NETHERITE_CHESTPLATE;
                  }

                  Item var107;
                  label123: {
                     Object[] var58 = new Object[]{var103, var12};
                     Integer var22 = InventoryUtil.aReturningBoxedInteger(var58);
                     int var141 = var20;
                     Integer var140 = var22;
                     Integer var106 = var140;
                     Integer var104 = var140;
                     if (var141 != 0) {
                        Integer var142 = var104;
                        if (var142 != null) {
                           Integer var60 = var22;
                           var155 = var60;
                           Object[] var167 = new Object[]{null, var16};
                           var167[0] = var155;
                           Object[] var61 = var167;
                           InventoryUtil.aReturningVoid(var61);
                           Object[] var62 = new Object[]{Hand.MAIN_HAND, var18};
                           ItemUseUtil.cReturningBoolean(var62);
                           this.B = dev.prestige.recovery.SourceSupport.asBoolean(1);
                           return false;
                        }

                        int var144 = var20;
                        Item var143 = Items.DIAMOND_CHESTPLATE;
                        var107 = var143;
                        Item var105 = var143;
                        if (var144 == 0) {
                           break label123;
                        }

                        Object[] var64 = new Object[]{var105, var12};
                        var22 = InventoryUtil.aReturningBoxedInteger(var64);
                        var106 = var22;
                     }

                     Integer var145 = var106;
                     if (var145 != null) {
                        Integer var65 = var22;
                        var155 = var65;
                        Object[] var10003 = new Object[]{null, var16};
                        var10003[0] = var155;
                        Object[] var66 = var10003;
                        InventoryUtil.aReturningVoid(var66);
                        Object[] var67 = new Object[]{Hand.MAIN_HAND, var18};
                        ItemUseUtil.cReturningBoolean(var67);
                        this.B = dev.prestige.recovery.SourceSupport.asBoolean(1);
                        return false;
                     }

                     var107 = Items.NETHERITE_CHESTPLATE;
                  }

                  Object[] var168 = new Object[]{null, null, var10};
                  var168[1] = false;
                  var168[0] = var107;
                  Object[] var69 = var168;
                  List var23 = InventoryUtil.aReturningList(var69);
                  List var70 = var23;
                  short var160 = ((short)((var70.isEmpty()) ? 1 : 0));
                  int var147 = var20;
                  byte var146 = (byte)var160;
                  byte var109 = var146;
                  byte var108 = var146;
                  if (var147 != 0) {
                     byte var148 = var108;
                     if (var148 == 0) {
                        List var72 = var23;
                        Integer var73 = (Integer)var72.getFirst();
                        int var153 = var73;
                        var160 = 15017;
                        Object[] var173 = new Object[]{null, null, SlotActionType.PICKUP, var14};
                        var173[1] = 0;
                        var173[0] = var153;
                        Object[] var74 = var173;
                        InventoryUtil.eReturningBoolean(var74);
                        long var166 = 7739406628948547087L ^ var152;
                        Object[] var171 = new Object[]{null, null, SlotActionType.PICKUP, var14};
                        var171[1] = 0;
                        var171[0] = 6;
                        Object[] var75 = var171;
                        InventoryUtil.eReturningBoolean(var75);
                        var171 = new Object[]{null, null, SlotActionType.PICKUP, var14};
                        var171[1] = 0;
                        var171[0] = var153;
                        Object[] var76 = var171;
                        InventoryUtil.eReturningBoolean(var76);
                        return true;
                     }

                     Item var161 = Items.DIAMOND_CHESTPLATE;
                     var168 = new Object[]{null, null, var10};
                     var168[1] = false;
                     var168[0] = var161;
                     Object[] var77 = var168;
                     var23 = InventoryUtil.aReturningList(var77);
                     List var78 = var23;
                     var109 = ((byte)((var78.isEmpty()) ? 1 : 0));
                  }

                  int var150 = var20;
                  byte var149 = var109;
                  byte var111 = var149;
                  byte var110 = var149;
                  if (var150 != 0) {
                     byte var151 = var110;
                     if (var151 == 0) {
                        List var80 = var23;
                        Integer var81 = (Integer)var80.getFirst();
                        int var24 = var81;
                        var160 = 25000;
                        Object[] var10006 = new Object[]{null, null, SlotActionType.PICKUP, var14};
                        var10006[1] = 0;
                        var10006[0] = var24;
                        Object[] var82 = var10006;
                        InventoryUtil.eReturningBoolean(var82);
                        long var165 = 5649133085812804876L ^ var152;
                        Object[] var10005 = new Object[]{null, null, SlotActionType.PICKUP, var14};
                        var10005[1] = 0;
                        var10005[0] = 6;
                        Object[] var83 = var10005;
                        InventoryUtil.eReturningBoolean(var83);
                        var10005 = new Object[]{null, null, SlotActionType.PICKUP, var14};
                        var10005[1] = 0;
                        var10005[0] = var24;
                        Object[] var84 = var10005;
                        InventoryUtil.eReturningBoolean(var84);
                        return true;
                     }

                     var111 = 0;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var111);
               }

               var101 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var101);
         }

         var98 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var98);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 5750229855043L;
      RotationManager var10000 = Prestige.o;
      Object[] var9 = new Object[]{this, var4};
      RotationManager var8 = var10000;
      var8.eReturningVoid(var9);
      Object[] var11 = new Object[]{var6};
      AutoMace var10 = this;
      var10.jReturningVoid(var11);
      Object[] var13 = new Object[0];
      AutoMace var12 = this;
      var12.mReturningVoid(var13);
      this.B = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   public int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 58647587722062L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      byte var15;
      while (true) {
         short var10001 = 28506;
         long var10002 = 5299198390694979829L ^ var2;
         byte var17 = 8;
         int var16 = var5;
         if (var16 <= var17) {
            MinecraftClient var6 = b;
            ClientPlayerEntity var7 = var6.player;
            PlayerInventory var26 = var7.getInventory();
            int var9 = var5;
            PlayerInventory var8 = var26;
            ItemStack var10 = var8.getStack(var9);
            byte var27 = ((byte)((var10.getItem() instanceof AxeItem) ? 1 : 0));
            int var19 = var4;
            byte var18 = var27;
            var15 = var18;
            byte var11 = var18;
            if (var19 == 0) {
               break;
            }

            int var21 = var4;
            byte var20 = var11;
            int var14 = var20;
            byte var12 = var20;
            if (var21 == 0) {
               return var14;
            }

            byte var22 = var12;
            int var13 = var22;
            int var23 = var13;
            if (var23 != 0) {
               var14 = var5;
               return var14;
            }

            var5++;
            int var24 = var4;
            if (var24 != 0) {
               continue;
            }
         }

         var15 = -1;
         break;
      }

      return var15;
   }

   public int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 58647587722062L ^ var2;
      long var4 = var2 ^ 102432776449714L;
      long var6 = var2 ^ 65860837631081L;
      long var8 = var2 ^ 89339474265026L;
      int var10000 = Event.cReturningInt();
      ArrayList var11 = new ArrayList();
      int var10 = var10000;
      byte var49;
      while (true) {
         short var10001 = 18281;
         long var10002 = 7984390310937387143L ^ var2;
         byte var62 = 8;
         int var61 = var12;
         if (var61 <= var62) {
            MinecraftClient var17 = b;
            ClientPlayerEntity var18 = var17.player;
            PlayerInventory var90 = var18.getInventory();
            int var20 = var12;
            PlayerInventory var19 = var90;
            Object[] var21 = new Object[]{var19.getStack(var20), var6};
            byte var91 = ((byte)((InventoryUtil.o(var21)) ? 1 : 0));
            int var64 = var10;
            byte var63 = var91;
            var49 = var63;
            byte var45 = var63;
            if (var64 == 0) {
               break;
            }

            int var66 = var10;
            byte var65 = var45;
            byte var46 = var65;
            if (var66 != 0) {
               byte var67 = var46;
               byte var47 = var67;
               byte var68 = var47;
               if (var68 != 0) {
                  int var24 = var12;
                  Integer var26 = var24;
                  ArrayList var25 = var11;
                  boolean var69 = var25.add(var26);
               }
            }

            var12++;
            int var70 = var10;
            if (var70 != 0) {
               continue;
            }
         }

         var12 = -1;
         var49 = -1;
         break;
      }

      int var13 = var49;
      ArrayList var28 = var11;
      Iterator var14 = var28.iterator();

      int var60;
      while (true) {
         Iterator var29 = var14;
         boolean var71 = var29.hasNext();
         if (var71) {
            int var15;
            int var57;
            label55: {
               Iterator var30 = var14;
               Integer var31 = (Integer)var30.next();
               var15 = var31;
               int var73 = var10;
               AutoMace var72 = this;
               AutoMace var56 = var72;
               AutoMace var50 = var72;
               if (var73 != 0) {
                  BooleanSetting var32 = var50.k;
                  Boolean var33 = (Boolean)var32.aReturningObject();
                  int var92 = ((((java.lang.Boolean)(var33)).booleanValue() ? 1 : 0));
                  int var75 = var10;
                  byte var74 = (byte)var92;
                  var60 = var74;
                  byte var51 = var74;
                  if (var75 == 0) {
                     break;
                  }

                  byte var76 = var51;
                  byte var52 = var76;
                  byte var77 = var52;
                  if (var77 != 0) {
                     MinecraftClient var36 = b;
                     ClientPlayerEntity var37 = var36.player;
                     double var95;
                     var92 = (var95 = var37.fallDistance - 7.0) == 0.0 ? 0 : (var95 < 0.0 ? -1 : 1);
                     int var79 = var10;
                     int var78 = var92;
                     int var55 = var78;
                     int var53 = var78;
                     if (var79 == 0) {
                        int var83 = var55;
                        var57 = var83;
                        break label55;
                     }

                     int var80 = var53;
                     int var54 = var80;
                     int var81 = var54;
                     if (var81 <= 0) {
                        Object[] var94 = new Object[]{null, var8};
                        var94[0] = var15;
                        Object[] var41 = var94;
                        AutoMace var40 = this;
                        int var82 = var40.cReturningInt(var41);
                        var57 = var82;
                        break label55;
                     }
                  }

                  var56 = this;
               }

               Object[] var10004 = new Object[]{null, var4};
               var10004[0] = var15;
               Object[] var44 = var10004;
               AutoMace var43 = var56;
               var57 = var43.aReturningInt(var44);
            }

            label45: {
               int var16 = var57;
               int var85 = var10;
               int var84 = var16;
               int var59 = var84;
               int var58 = var84;
               if (var85 != 0) {
                  int var87 = var12;
                  int var86 = var58;
                  if (var86 <= var87) {
                     break label45;
                  }

                  var12 = var16;
                  var59 = var15;
               }

               var13 = var59;
            }

            int var88 = var10;
            if (var88 != 0) {
               continue;
            }
         }

         var60 = var13;
         break;
      }

      return var60;
   }

   public int aReturningInt(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 58647587722062L ^ var3;
      int var32 = Event.cReturningInt();
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      PlayerInventory var10001 = var9.getInventory();
      int var11 = var2;
      PlayerInventory var10 = var10001;
      ItemStack var6 = var10.getStack(var11);
      int var5 = var32;
      int var29 = var5;
      ItemStack var28 = var6;
      Object var27 = var28;
      ItemStack var26 = var28;
      if (var29 != 0) {
         ItemStack var30 = var26;
         if (var30 == null) {
            return 0;
         }

         MinecraftClient var13 = b;
         ClientWorld var14 = var13.world;
         DynamicRegistryManager var33 = var14.getRegistryManager();
         RegistryKey var15 = Enchantments.DENSITY;
         RegistryKey var17 = var15.getRegistryRef();
         DynamicRegistryManager var16 = var33;
         Optional var18 = var16.getOptional(var17);
         Registry var34 = (Registry)var18.get();
         RegistryKey var19 = Enchantments.DENSITY;
         Identifier var21 = var19.getValue();
         Registry var20 = var34;
         Optional var22 = var20.getEntry(var21);
         Object var31 = var22.get();
         var27 = var31;
      }

      RegistryEntry var35 = (RegistryEntry)var27;
      ItemStack var25 = var6;
      RegistryEntry var24 = var35;
      float var7 = EnchantmentHelper.getLevel(var24, var25);
      return (int)var7;
   }

   public int cReturningInt(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 58647587722062L ^ var3;
      int var32 = Event.bReturningInt();
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      PlayerInventory var10001 = var9.getInventory();
      int var11 = var2;
      PlayerInventory var10 = var10001;
      ItemStack var6 = var10.getStack(var11);
      int var5 = var32;
      int var29 = var5;
      ItemStack var28 = var6;
      Object var27 = var28;
      ItemStack var26 = var28;
      if (var29 == 0) {
         ItemStack var30 = var26;
         if (var30 == null) {
            return 0;
         }

         MinecraftClient var13 = b;
         ClientWorld var14 = var13.world;
         DynamicRegistryManager var33 = var14.getRegistryManager();
         RegistryKey var15 = Enchantments.BREACH;
         RegistryKey var17 = var15.getRegistryRef();
         DynamicRegistryManager var16 = var33;
         Optional var18 = var16.getOptional(var17);
         Registry var34 = (Registry)var18.get();
         RegistryKey var19 = Enchantments.BREACH;
         Identifier var21 = var19.getValue();
         Registry var20 = var34;
         Optional var22 = var20.getEntry(var21);
         Object var31 = var22.get();
         var27 = var31;
      }

      RegistryEntry var35 = (RegistryEntry)var27;
      ItemStack var25 = var6;
      RegistryEntry var24 = var35;
      float var7 = EnchantmentHelper.getLevel(var24, var25);
      return (int)var7;
   }

   private boolean lambda$new$9(Float var1) {
      BooleanSetting var4 = this.r;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$8(Integer var1) {
      BooleanSetting var4 = this.p;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$7(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.l;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.m;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$6(Boolean var1) {
      BooleanSetting var4 = this.l;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$5(Integer var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$4(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.e;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Chance";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$2(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.e;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Chance";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$1(Integer var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.e;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Hold Key";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$0(String var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(8813776879772L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[4];
      String var28 = "\u001f\u0016\u0004÷þbè\u009a\u0083$ÒW|\u0092Ã× Þ1®sõDÐ_Zw+ 0´t\u0090gLti©kFv|\u0080å\u0007÷BTÇ";
      int var30 = "\u001f\u0016\u0004÷þbè\u009a\u0083$ÒW|\u0092Ã× Þ1®sõDÐ_Zw+ 0´t\u0090gLti©kFv|\u0080å\u0007÷BTÇ".length();
      char var27 = 16;
      int var35 = -1;

      label72:
      while (true) {
         String var36 = var28.substring(++var35, var35 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var36.getBytes("ISO-8859-1"));
            String var50 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var50;
                  if ((var35 += var27) >= var30) {
                     H = var31;
                     I = new String[4];
                     M = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(8813776879772L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[4];
                     String var15 = "Nó\u0094Ìu¼Å\u001a¨Ñu\u0002¢°¡y";
                     int var16 = "Nó\u0094Ìu¼Å\u001a¨Ñu\u0002¢°¡y".length();
                     label54:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var39 = var17;
                        var10001 = var14++;
                        long var54 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var54;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var62 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var58) {
                              case 0:
                                 var39[var10001] = var62;
                                 if (var13 >= var16) {
                                    K = var17;
                                    L = new Integer[4];
                                    P = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(8813776879772L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[2];
                                    String var4 = "\u001dáØq\u0098i\u009fK\\'Ë£àdâL";
                                    int var5 = "\u001dáØq\u0098i\u009fK\\'Ë£àdâL".length();
                                    do {
                                       int var47 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var47, var2).getBytes("ISO-8859-1");
                                       var47 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var62 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       
                                    } while (var2 < var5);

                                    N = var6;
                                    O = new Long[2];
                                    break;
                                 }
                                 break;
                              default:
                                 var39[var10001] = var62;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "j¦\u0087Õá£²-Ï¯r$j\u0091u\u0091";
                                 var16 = "j¦\u0087Õá£²-Ï¯r$j\u0091u\u0091".length();
                                 var13 = 0;
                           }

                           int var46 = var13;
                           var13 += 8;
                           var18 = var15.substring(var46, var13).getBytes("ISO-8859-1");
                           var39 = var17;
                           var10001 = var14++;
                           var54 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var58 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var35);
                  break;
               default:
                  var31[var29++] = var50;
                  if ((var35 += var27) < var30) {
                     var27 = var28.charAt(var35);
                     continue label72;
                  }

                  var28 = "ÑI²v\u0080\u001d\u007f¾ç\u0083v\u0019ç\u001cô#s\u008eÞ5\u009eïYÛ`Ä\u009ccÃ^ü,\u0010Ú\u0093>B¡Ld\tÓ&õ\t¦wË\u0005";
                  var30 = "ÑI²v\u0080\u001d\u007f¾ç\u0083v\u0019ç\u001cô#s\u008eÞ5\u009eïYÛ`Ä\u009ccÃ^ü,\u0010Ú\u0093>B¡Ld\tÓ&õ\t¦wË\u0005".length();
                  var27 = ' ';
                  var35 = -1;
            }

            var36 = var28.substring(++var35, var35 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13143;
      if (I[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])J.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ea", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = H[var5].getBytes("ISO-8859-1");
         I[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return I[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ea_C0218",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ea" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17123;
      if (L[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = K[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])M.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               M.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ea", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         L[var3] = var15;
      }

      return L[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ea_C0218",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ea" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 85;
      if (O[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = N[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])P.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               P.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ea", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         O[var3] = var15;
      }

      return O[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ea_C0218",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ea" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = R[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = Q[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 47;
            yield var15;
         }
         case 1 -> {
            byte var16 = 40;
            yield var16;
         }
         case 2 -> {
            byte var17 = 8;
            yield var17;
         }
         case 3 -> {
            byte var18 = 19;
            yield var18;
         }
         case 4 -> {
            byte var19 = 34;
            yield var19;
         }
         case 5 -> {
            byte var20 = 10;
            yield var20;
         }
         case 6 -> {
            byte var21 = 28;
            yield var21;
         }
         case 7 -> {
            byte var22 = 26;
            yield var22;
         }
         case 8 -> {
            byte var23 = 14;
            yield var23;
         }
         case 9 -> {
            byte var24 = 0;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 18;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 31;
            yield var29;
         }
         case 15 -> {
            byte var30 = 3;
            yield var30;
         }
         case 16 -> {
            byte var31 = 56;
            yield var31;
         }
         case 17 -> {
            byte var32 = 6;
            yield var32;
         }
         case 18 -> {
            byte var33 = 58;
            yield var33;
         }
         case 19 -> {
            byte var34 = 20;
            yield var34;
         }
         case 20 -> {
            byte var35 = 48;
            yield var35;
         }
         case 21 -> {
            byte var36 = 63;
            yield var36;
         }
         case 22 -> {
            byte var37 = 24;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 25;
            yield var39;
         }
         case 25 -> {
            byte var40 = 11;
            yield var40;
         }
         case 26 -> {
            byte var41 = 5;
            yield var41;
         }
         case 27 -> {
            byte var42 = 38;
            yield var42;
         }
         case 28 -> {
            byte var43 = 15;
            yield var43;
         }
         case 29 -> {
            byte var44 = 27;
            yield var44;
         }
         case 30 -> {
            byte var45 = 60;
            yield var45;
         }
         case 31 -> {
            byte var46 = 43;
            yield var46;
         }
         case 32 -> {
            byte var47 = 46;
            yield var47;
         }
         case 33 -> {
            byte var48 = 13;
            yield var48;
         }
         case 34 -> {
            byte var49 = 17;
            yield var49;
         }
         case 35 -> {
            byte var50 = 12;
            yield var50;
         }
         case 36 -> {
            byte var51 = 39;
            yield var51;
         }
         case 37 -> {
            byte var52 = 52;
            yield var52;
         }
         case 38 -> {
            byte var53 = 2;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 36;
            yield var55;
         }
         case 41 -> {
            byte var56 = 30;
            yield var56;
         }
         case 42 -> {
            byte var57 = 23;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 49;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 62;
            yield var61;
         }
         case 47 -> {
            byte var62 = 35;
            yield var62;
         }
         case 48 -> {
            byte var63 = 1;
            yield var63;
         }
         case 49 -> {
            byte var64 = 21;
            yield var64;
         }
         case 50 -> {
            byte var65 = 59;
            yield var65;
         }
         case 51 -> {
            byte var66 = 42;
            yield var66;
         }
         case 52 -> {
            byte var67 = 54;
            yield var67;
         }
         case 53 -> {
            byte var68 = 22;
            yield var68;
         }
         case 54 -> {
            byte var69 = 7;
            yield var69;
         }
         case 55 -> {
            byte var70 = 57;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 50;
            yield var72;
         }
         case 58 -> {
            byte var73 = 16;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 4;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 29;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            R[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      Q[0] = "x\u007f\u0015bp\u0005sp\u0004-\u001c\u0006}r\u0006b0";
      Q[1] = boolean.class;
      R[1] = "java/lang/Boolean";
      Q[2] = "BnOd\u007fiTnJ>l~C%I8`jRb^/+}`";
      Q[3] = "\u001c%`7\u001ay\u0017*qx{w\u001c!u\"";
      Q[4] = "/W\f\u0003\u0010h9W\tY\u0003\u007f.\u001c\n_\u000fk?[\u001dHD|2";
      Q[5] = "S92jdj&\u00199eu%G\u00172nq\u007f3";
      Q[6] = void.class;
      R[6] = "java/lang/Void";
      Q[7] = "A]sdmLW]v>~[@\u0016u8rOQQb/9_IQ`$c\u0012uJ`9cUB]";
      Q[8] = ",\u000bE\u001f!B'\u0004TP\\Z4\u0003]\u0019";
      Q[9] = "eGGI<wnHV\u0006_z{N";
      Q[10] = float.class;
      R[10] = "java/lang/Float";
      Q[11] = "G`ks0 G`|/</]+|1<:ZZ(ik";
      Q[12] = double.class;
      R[12] = "java/lang/Double";
      Q[13] = "l`OA\u0019\u000bz`J\u001b\n\u001cm+I\u001d\u0006\b|l^\nM\u001ei";
      Q[14] = "Ff\u001dr]oMi\f=>bXd\u0003V\u000b`Iw\u001fz\u001cm";
      Q[15] = "+drtx(=dw.k?*/t(g+;hc?,9\n";
      Q[16] = int.class;
      R[16] = "java/lang/Integer";
      Q[17] = "i\u0007)Jh\u0014b\b8\u0005\u000f\u0016w\u00038N4";
      Q[18] = "$L[{U>$LL'Y1>\u0007L9Y$9v\u001cd\b";
      Q[19] = "=.m%\u0007K6!|joK8.o";
      Q[20] = "\u001d'\u0006\u0015\u0005\u0017\u000b'\u0003O\u0016\u0000\u001cl\u0000I\u001a\u0014\r+\u0017^Q\u0003>";
      Q[21] = "pA8A,\"\u0005a3N=mdo8E97\u0010";
      Q[22] = ",\u001b0jx1:\u001b50k&-P66g2<\u0017!!,'\u0011";
      Q[23] = "3M\u0012\u0006.\u0010Fm\u0019\t?_'c\u0012\u0002;\u0005S";
      Q[24] = "AdM`b\u001cAdZ<n\u0013[/Z\"n\u0006\\^\by6L";
      Q[25] = "L\u001f\u0001e\\\u0012L\u001f\u00169P\u001dVT\u0016'P\bQ%D|\bI";
      Q[26] = "2_7-\u0010k$_2w\u0003|3\u00141q\u000fh\"S&fDx9";
      Q[27] = ",*\u0005ey\u0011Y\n\u000ejh^8\u0004\u0005al\u0004L";
      Q[28] = "Y~PUhX,^[Zy\u0017MPPQ}M9";
      Q[29] = "\u0007 \":;|r\u0000)5*3\u0013\u000e\">.ig";
      Q[30] = "9!p@4 9!g\u001c8/#jg\u00028:$\u001b6]`";
      Q[31] = "\u007f\u0001<_5A\n!7P$\u000ek/<[ T\u001f";
      Q[32] = "F&U\t \u00173\u0006^\u00061XR\bU\r5\u0002&";
      Q[33] = "v3\u0012`c.\u0003\u0013\u0019orab\u001d\u0012dv;\u0016";
      Q[34] = "G>L\u0015\u0010\t2\u001eG\u001a\u0001FS\u0010L\u0011\u0005\u001c'";
      Q[35] = "3[b'\u0016d3[u{\u001ak)\u0010ue\u001a~.a'?N:";
      Q[36] = "\"\u0004\u001c\u001a7\bW$\u0017\u0015&G6*\u001c\u001e\"\u001dB";
      Q[37] = "\u001c\u007fEw\\$\n\u007f@-O3\u001d4C+C'\fsT<\b2-";
      Q[38] = "'?4M;{R\u001f?B*43\u00114I.nG";
      Q[39] = "]Z\u0005\b1\u0007(z\u000e\u0007 HIt\u0005\f$\u0012=";
      Q[40] = "\nS\u007favN\u001cSz;eY\u000b\u0018y=iM\u001a_n*\"_!";
      Q[41] = "]\u00122mV<(29bGsI<2iC)=";
      Q[42] = "&q\u0015U3{SQ\u001eZ\"42_\u0015Q&nF";
      Q[43] = "-\u0004O`Z\u0013-\u0004X<V\u001c7OX\"V\t0>\n|\u000eM";
      Q[44] = "xiC`wZ\rIHof\u0015lGCdbO\u0018";
      Q[45] = ";`\"\u0005\u0006\r;`5Y\n\u0002!+5G\n\u0017&Zd\u0018S";
      Q[46] = "i1\u0007\u0002\b9\u001c\u0011\f\r\u0019v}\u001f\u0007\u0006\u001d,\t";
      Q[47] = "@4K[\u000f\u0012V4N\u0001\u001c\u0005A\u007fM\u0007\u0010\u0011P8Z\u0010[\u0006l";
      Q[48] = "F%u\u0001Zp3\u0005~\u000eK?R\u000bu\u0005Oe&";
      Q[49] = "s\u0018T\u0003\u0010\t\u00068_\f\u0001Fg6T\u0007\u0005\u001c\u0013";
      Q[50] = "\u0005+P{j(\u0013+U!y?\u0004`V'u+\u0015'A0><+";
      Q[51] = "\u000443lWeq\u00148cF*\u0010\u001a3hBpd";
      Q[52] = "fbn\u0001r|pbk[akg)h]m\u007fvn\u007fJ&hI";
      Q[53] = ";&%]X~N\u0006.RI1/\b%YMk[";
      Q[54] = "|nq\u0014|ljntNo{}%wHcolb`_(xU";
      Q[55] = "Fprkp\u007f3Pyda0R^roej&";
      Q[56] = "G\bY2\u001eqG\bNn\u0012~]CNp\u0012kZ2\u001c*E)";
      Q[57] = "XR\t\"^tXR\u001e~R{B\u0019\u001e`RnEhH8\u0006(";
      Q[58] = "k!F\r9wk!QQ5xqjQO5mv\u001b\u0007\u0010f/";
      Q[59] = "l\u0010O7\u001bpr\u0018Uxzur\u0018V8Ti";
      Q[60] = "(\u0015l\u001ajG(\u0015{FfH2^{Xf]5/)\f>\u001d";
      Q[61] = "X|\u0013v\u0002\u0018X|\u0004*\u000e\u0017B7\u00044\u000e\u0002EFQkW";
      Q[62] = "\u001b%]cxd\u001b%J?tk\u0001nJ!t~\u0006\u001f\u001bt#=";
      Q[63] = "\u000bo4\u000fV~\u000bo#SZq\u0011$#MZd\u0016Ur\u0012\f/";
      Q[64] = "q<o\u0005o*q<xYc%kwxGc0l\u0006*\u0013;s";
      Q[65] = "C\\q\u007fb\u0001C\\f#n\u000eY\u0017f=n\u001b^f3i7X";
      Q[66] = "\u0001bh+\u0010\u0018\nmydm\r\u0018w{'";
      Q[67] = long.class;
      R[67] = "java/lang/Long";
      Q[68] = "\rsN\u001bmd\u001bsKA~s\f8HGrg\u001d\u007f_P9w\u0005";
      Q[69] = ";N\u00132HINn\u0018=Y\u0006/`\u00136]\\[";
      Q[70] = "_N\t\u0004LJ*n\u0002\u000b]\u0005K`\t\u0000Y_?";
      Q[71] = "EX\u0019^?00x\u0012Q.\u007fQv\u0019Z*%%";
      Q[72] = "#\u007f\n%\u0015tV_\u0001*\u0004;7Q\n!\u0000aC";
      Q[73] = "\u0016k\u001cQ\n?\bc\u0006\u001eh#\u000f~";
      Q[74] = "WDA\tTgWDVUXhM\u000fVKX}J~\u0004\u0014\t:";
      Q[75] = "\u0015hh\u0000\\_`Hc\u000fM\u0010\u0001Fh\u0004IJu";
      Q[76] = "<^\u001dQDO<^\n\rH@&\u0015\n\u0013HU!dXG\u0019\u0014";
      Q[77] = "8\u0001J`Rr.\u0001O:Ae9JL<Mq(\r[+\u0006ao";
      Q[78] = "\n\u0011\u0018oN4\u007f1\u0013`_{\u001e?\u0018k[!j";
      Q[79] = "jY{}\u000ffjYl!\u0003ip\u0012l?\u0003|wc>dS<";
      Q[80] = "N92^\u0018o;\u00199Q\t Z\u00172Z\rz.";
      Q[81] = "C9\u0018P-QC9\u000f\f!^Yr\u000f\u0012!K^\u0003]Lv\u0000";
      Q[82] = "{(3$|7\u000e\b8+mxo\u00063 i\"\u001b";
      Q[83] = "\u007fu|uv]a}f:\u000bMa";
      Q[84] = "\u0007s\u0000w\u0005#rS\u000bx\u0014l\u0013]\u0000s\u00106g";
      Q[85] = "os\u0015kj\\\u001aS\u001ed{\u0013{]\u0015o\u007fI\u000f";
      Q[86] = "d[J&(!zSPiO kH]3i&";
      Q[87] = "h7R\u0000y\u0006\u001d\u0017Y\u000fhI|\u0019R\u0004l\u0013\b";
      Q[88] = "/\u0013H8YDZ3C7H\u000b;=H<LQO";
      Q[89] = "wc#\u0000,Kac&Z?\\v(%\\3Hgo2Kx_Q";
      Q[90] = "lJiV\u001b \u0019jbY\noxdiR\u000e5\f";
      Q[91] = "HQ 6=[^Q%l.LI\u001a&j\"XX]1}iOT";
      Q[92] = "\bj)38;\u001ej,i+,\t!/o'8\u0018f8xl*\u0000";
      Q[93] = "`]\u0002oW(\u0015}\t`Fgts\u0002kB=\u0000";
      Q[94] = "7U4M>\u00057U#\u00112\n-\u001e#\u000f2\u001f*orW`";
      Q[95] = "\u0003Q%\u0010\u0002Bvq.\u001f\u0013\r\u0017\u007f%\u0014\u0017Wc";
      Q[96] = "\u0006Z\u0012~]\u001fsz\u0019qLP\u0012t\u0012zH\nf";
      Q[97] = ":!Cf%VO\u0001Hi4\u0019.\u000fCb0CZ";
      Q[98] = "\f.#8Q/\f.4d] \u0016e4z]5\u0011\u0014d/\np";
      Q[99] = "(\u0018E7(N]8N89\u0001<6E3=[H";
      Q[100] = "bm\u001bV_\u0015\u0017M\u0010YNZvC\u001bRJ\u0000\u0002";
      Q[101] = "H\u0000foq}= m``2\\.fkdh(";
      Q[102] = "F\u00198Qg6P\u0019=\u000bt!GR>\rx5V\u0015)\u001a3 m";
      Q[103] = "(\u001dH|%5]=Cs4z<3Hx0 H";
      Q[104] = "\u0011]\u0004x\"\u001a\u0011]\u0013$.\u0015\u000b\u0016\u0013:.\u0000\fgBcyB";
      Q[105] = "h}d\u0004u@sl$Q\u001bO\u00126.\u0013e\u001cq?a\u000by\u001c\u00123;Pu\\+u5\\x%";
      Q[106] = "\u001ag>D\u0017\u001d\u0006er\u001dq\u0018e&>_\u000fH\u0006/qG\u0013He`4S\u0014\u0017\t|6\u001fMq";
      Q[107] = "-uX\u0006l\u0000rn\u001c\u0014hx\u007fa\u001d\u0004f\u001eh@\u0006\u001bf=ux\u0003\u001fpx-u\u0006\u001e4\u0002zd\u001e\u001d7x";
      Q[108] = ">j\u001b\u000e,:0?\u000b\u0000^=\u000f6\u0019\u001c ol?V\u0004<o\u000feTYdg1e\u0012\u0019.V";
      Q[109] = "(\u0013R\u001a \u0013v\u0013GL^\u0000\u0013\u0010M] Up\u0019\u0002E<U\u0013\u0015X\u001e0\u0015*SV\u0012=l";
      Q[110] = "-x\u0007+T5.%\u001exAUq.\u0019wB9C\u007f[(\u0018d\u0014zY'D1f\"ZhT'\u0014zX}Gk(<\u001cyY5\u0014";
      Q[111] = "G\buG\u0007\u0015_W&@}\u00165\r7@\u0003FV\u0004xX\u001fF5Fy\u000e\u0004\u0005_^&]\u0003\u007f";
      Q[112] = "@z\u001e hN\u0002rX6, \u0010\u0010\u001a\"j^@s\u0013mrB@\u0010\u001f7)N\u0000)Y9%Cy";
      Q[113] = "\u0004qX)DM_\"CaW3Q$D\nII_/WQ\u000b\fB;H0D\u0002\u000ep8";
      Q[114] = "MQI\u0013?(C\u0004Y\u001dM!|\rK\u00013}\u001f\u0004\u0004\u0019/}|\b^B#=ENPN.D";
      Q[115] = "R3`la^\u00003\"kx>\u0002Ra\"f@R1hm~\\RR'9zE\u0012+%lb>";
      Q[116] = "\"*R{\u0002\u0018`/VeXj~yTfY\u0006L-\u0018:\u0003T\u001b-EaYSw,Fx\u0004\u0001\u001b";
      Q[117] = "\u0000mi]\u0005\tOc%\u0016u\u0005G/|K\u000eh\u0004?\u007fSD\u0019\u0001>s\u0015u\u0017W0nV\f\u0015\u0002(\u0015";
      Q[118] = "NT1BW\"HB7D>6\"\u001f;W@fA\u0016tO\\f\"J;QU6_L-WS_";
      Q[119] = "2#Oly6a|O:([nu\b5s7\\%Hn$[a'Oo%eaa\u000f%\u0014;2)L+igya\bU";
      Q[120] = "\u007f\u000bS\u001e#s/\r\u0000G`O#\u0019\u0016Fy#\u0011MU\u0019.uF\b\u001bEo$/\u001a\t^aO";
      Q[121] = "_\u001fBK8*]L^X=[\b\u001dIQ/\f[L\u001c\u0005Cb\u0005\u001aZN2`V\u0006IK";
      Q[122] = "tjcw2e}czi\"\u0014#dwi'C}='=Kt)c{2;r.dp";
      Q[123] = "UfM5$PQe\u001c<@\u0013\u0002cJc%i[c]m}Y\u0001>V5@";
      Q[124] = ")7#lS4.z,f(<Q\u007f1xVo2v~`JoQ!;w\u0019'k=)t\u0011V";
      Q[125] = "ZK`\f?,AZ YQ  \u0000*\u001b/pC\te\u00033p E)\u0006 \"IW;\u001d.I";
      Q[126] = ">xV\fS\f?e\u000bOG5n\u0001R\u0002]K>b[MEW>\u0001R\n\u001f\u00057o\u0005\u0016[G;\u0001";
      Q[127] = "\u0014\u007f\fc?\u0007H4D'A\u001f\u0019:]<--Kw\u0005jA\u001a\u0010 \\d1\u001c\u0017'W[";
      Q[128] = "r\biPO\n(AhX5\u001a\u0013\nq\u0016KJp\u0003>\u000eWJ\u0013\nn\u000fRJ\u007f\u000bm\u0016\u000f\u0018\u0013";
      Q[129] = "m}>\u0014\u001f*280R\u007f)?|/K\u0013\u001bl9v\u001c\u007fu<f!Q\u0007r+8!I\u007f,k1wR\u0002p y3,";
      Q[130] = "3\u0016\u0017\u000698=C\u0007\bK=\u0002\u001a\u000e\t&=i\u0016\u001c\u0018wTk\u001a\u0004\u0007\"?g\b\u0015VK";
      Q[131] = "G\u007fV.\u0016z\u001d6W&lj&}Nh\u0012:Et\u0001p\u000e:&x[+\u0002z\u001f>U'\u000f\u0003";
      Q[132] = "\u0004MzpTmQR?r\u0002\u0001ZG\u0003,\u0006kA\u0018r)\u0007g\u0007):r\u0012g\u0002EomWeT)";
      Q[133] = "B]EP\u0011\u0003QQM0\u0006XG\u0004FY\naI\u0004V]l@I\u0002PI\u0015B\u001c\u001a+";
      Q[134] = "X:\u0017\u000bp\u0015Ki\u0013\u0018\f\u001a13G^6@\u000f3\u0001\u001e|q";
      Q[135] = "Q}\u0007YLGV6\u0002E_>\u0001\u0006\u0002QM@Qe\u000b\u001eU\\Q\u0006DJQE\u0011\u007fF\u001fI>";
      Q[136] = "\u00155m)H\u001c\u001b`}':\u0019$io;DIG` #XI$:\"~\u0000A\u001a:d>Jp";
      Q[137] = "[ -\u0018:\u0004H> \u0006XWQ2 \u001a\u000f\u0000\u000fexvgDAg$\u00108\u0001O!";
      Q[138] = "\u0011nY\u001du\f\n\u007f\u0019H\u001b\u0000k%\u0013\neP\b,\\\u0012yPkb\n\u000exWWq\u0006H'i";
      Q[139] = "zR\n\"y's[\u0013<iV-\\\u001e<l\u0001y\u0007Kb0V#Y\u00159?&%^\u00122";
      Q[140] = "\u001a?nb_\u0003M#* SmJEk \u0011\u0013\u001a&bo\t\u000f\u001aEm9\u0006R\u0018%k<Q\u0002#";
      Q[141] = ".s50g\u0014 &%>\u0015\u0012\u001f/7\"kA|&x:wA\u001f/?`%Hqx#$gD\u001f";
      Q[142] = "i;$\u000f\u0012'(4'\u001b\u0005A5fe\u001f\t-\u00072!ETzP2&\u0015\u0007!(7)\u0004\u001c|P2$\u0015\f\u007flt`\u0011\u0012!P";
      Q[143] = "PgU,r\u000e\u0003{P18e\thQ\u001a'\u0015\u0015\u0001U5(\u001e\u0010xW`0e";
      Q[144] = "^jmbfV_it?4:\u0006|G`'F\u0016\u0007ul=A\u001e~w9%:";
      Q[145] = "\u0010IP\t\u0002B\u0017^\u000e\t\u001a:GF[\u0003\u0013m\u0017\u001e\t[\u007f\u0003GAX\u001a\u0007\u0004P\u001fX\u0002";
      Q[146] = "w2?m~\u0003|.9vN\rt-8`\t\u001d\u001d#z6tB##<v>sw2?m~\u0003|.9vN";
      Q[147] = ":\nR\u0014^\u001e&\u0018Q\u001c/A0\u000eCBCs`B\u001b\u0018/[4\u0010X\\VYa\b#";
      Q[148] = "HX/\u001cF(\u0017\u001d!Z&+\u001aY>CJ\u0019J\u001af\u001b&w\u000bK\"E\u001b>J[%\u001f&~\u0011^7\u0019\u0016$LUo$";
      Q[149] = "'\u0001\u001fmM\u000e#\u0002Nd)Rp\u0012tcB^&Y\u0014eG\tvbK7@\b\"\u0002M2\u0017X\u0019]\u001f5\u0016\fy[\u001abF7";
      Q[150] = "I\u0018\u001eW\u0003+\u0013Q\u001f_y5(\u001a\u0006\u0011\u0007kK\u0013I\t\u001bk(\\\u001d\r\u0002+Q^H\u0015y";
      Q[151] = "l\u0014-\u000b~fm\u00174V,\n:\u00146\"&p.\u0005JV*`)H;S+loy";
      Q[152] = "RLLP\u00063\r\tB\u0016f0\u0000M]\u000f\n\u0002S\t\u0001Wf5T\u0000\u0005\u0016\u001bi\u001fHAh";
      Q[153] = "&W=?P\t'T$b\u0002evV6XS\buFk)V\ty\u0000Z'\u0000\u0007dC#%U\u001f\u001f";
      Q[154] = "c(ZUS\t\u007f:Y]\"Vi,K\u0003Nd>k\u0010]\u001d346P\r\u001f\u0003nk[U\"";
      Q[155] = "nimrc\u001blt(g\u0005Dflz`[Cfv~\u001c:Ak4(|<D<d\u0013";
      Q[156] = "j\u001c\u0015a idI\u0005oRk[@\u0017s,<8IXk0<[\u0006\fo)|\"\u0004YwR";
      Q[157] = "aYMb\u0019qo\f]lkyP\u0005Op\u0015$3\f\u0000h\t$P\u0000Z3\u0005diFT?\b\u001d";
      Q[158] = "'\u0010\\gqExUR!\u0011Fu\u0011M8}t#T\u0010c!#!V\u0016f|Nr\t\u00160-#";
      Q[159] = "v\fzK~3r\u001cyVC0JJuW/$5\u001e5O8d";
      Q[160] = "8'\u001aNR;6r\n@ :\t{\u0018\\^njrWDBn\t(U\u0019\u001af7(\u0013YPW";
      Q[161] = "G-\u000fXws\u0018h\u0001\u001e\u0017p\u0015,\u001e\u0007{BCnB]+\u0015G;\u0017_,uA>@\u000f\u0017";
      Q[162] = "\u0003t`\u0013_9\u0007w1\u001a;e\\q\u000b\u001dPi\u0002,k\u001bU>R\u00174IR?\u0006w2L\u0005o=(`K\u0004;].e\u001cT\u0000";
      Q[163] = "r\n\u0004XGWs\t\u001d\u0005\u0015;*\u001b\u000eE\u0017G,\u001dc\u0006\u0018D;_\bU\u0004A&\u0015c";
      Q[164] = "\n\u0002hs\u0007\u0001V\u0006c&\r~]^~+\u0006)\u000e\u0007*rZ~\n\u0003#.\u000e\fR\u0000l>\u0018";
      Q[165] = "W~Rw\u000e-Y+By|-f\"Pe\u0002x\u0005+\u001f}\u001exfq\u001d FpXq[`\fA";
      Q[166] = "Gt\u00010v\u000bLh\u0007+F\u001aKs%9\"\u0006@\u000f\u0011o}A\u001c1\u0011)=\u000b-";
      Q[167] = "U;jw>\r\u0006'ojtf\n0e{\u0006\\\u00017i6wY\u0000;/\u0007";
      Q[168] = ")8WM\u001bA5*TEj\u001e#<F\u001b\u0006,u{\u001bCS{w<H\u0000\u000bF>}X\u0007Q{";
      Q[169] = "SA\u00115&Y\u0014\t\u00116a)\u0003xL6 WS\u001bEy8KSxL}:X\u0012\b\u000b5:[Ux";
      Q[170] = "1\u0004\tdGw\"W\rw;zX^\u0014tE*;W[lY*X[\u00017Uja\u001d\u000f;X\u0013";
      Q[171] = "p;u\u0010\u001a5yqp\u0011HY,fe\u001b\u00115\u001e;#AKYp:'\u0007F'8z'D\tY)2(C\b$uy`\u0007v3v0#JH30pi{";
      Q[172] = "Tr\u0007Q-Q\u000e;\u0006YWA5p\u001f\u0017)\u0011VyP\u000f5\u00115#\u0016\u00137\u0018E(\n\u0015,(";
      Q[173] = "N0t,%]\u001apl;e\"\u001eA42 \\N\"=}8@NAr)<Y\u000e8p|$\"";
      Q[174] = "ta\u0004ZtFg\u007f\tD\u0016\u0015~s\tXAB  P4rC/l\u0004Hq\u0006c/";
      Q[175] = "d\u001dFu-qw\u0003KkO\"n\u000fKw\u0018u1R\u0010\u001bvru\u001f\u0013i4wq\u0001I";
      Q[176] = "!Ve0\u0019^/\u0003u>k_\u0010\ng\"\u0015\u000bs\u0003(:\t\u000b\u0010L|>\u0010KiN)&k";
      Q[177] = "'\b\u0010q\u001e=)]\u0000\u007fl8\u0016T\u0012c\u0012hu]]{\u000eh\u0016\n\u0018l] ,\u0016\noUQ";
      Q[178] = "\rdl'\u0005K\u00031|)wE<8n5\t\u001e_1!-\u0015\u001e<={v\u0019^\u0005{uz\u0014'";
      Q[179] = "\u001d\u0001#J;<GH\"BA(|\u0003;\f?|\u001f\nt\u0014#||E \u0010:<\u0005Gu\bA";
      Q[180] = "`\t|\u000ee &Mx\u0010;\u001c6Yjlaq3H'\u001ddp?\u000e\u0016";
      Q[181] = "6\u0016 y2E%E$jNK_\u001fp,t\u0010a\u001f6l>!";
      Q[182] = "0(5O \u0007om;\t@\u000fn8 \u001b\u0017_7l{wp\u0007t<yG*Z\u007fd";
      Q[183] = "x&Kf\u00014d4Hnpkr\"Z0\u001cY%e\u0001mI\u000e/8A>M>ueJfp";
      Q[184] = "[\":\b-\u001aUw*\u0006_\u001aj~8\u001a!O\tww\u0002=Oj8#\u0006$\u000f\u0013:v\u001e_";
      Q[185] = "DV# E\u001a\u0006S'>\u001fh\u0018\u0005%=\u001e\u0004*SafEY}Qb?E\u0019\u001dR?&\u0016\f}";
      Q[186] = "\bl@7\u0007}@)W49)1.]!Eq@+\\-\u0003@";
      Q[187] = "(\u0015\u001cRZ0wP\u0012\u0014:3z\u0014\r\rV\u0001*WV[:*f\u000b\u001c\u0001S8t\u0010\u0012j\u0005=~WV\n\u00038)\u0007m";
      Q[188] = "\u007f\ro\u0010\u0010h=\u0005)\u0006T\u0006-gk\u0012\u0012x\u007f\u0004b]\nd\u007fg-\t\u000e}?\u001e/\\\u0016\u0006";
      Q[189] = "P\t\bu>'\u000fL\u00063^$\u0002\b\u0019*2\u0016QLDr^=\u001e\u0017\b&7/\f\f\u0006M!(\r\u000f\u00004#}\u0015t";
      Q[190] = "s\u007f\\\u0019\u0012|-\u007fIOlnH|C^\u0012:+u\fF\u000e:HyV\u001d\u0002zq?X\u0011\u000f\u0003";
      Q[191] = "nF|\u00059\u001bo\u001b'\\@\r\u0000\u001d6\u0019>]c\u0014y\u0001\"]\u0000\u0018#Z.\u001d9^-V#d";
      Q[192] = "2F,\u0010\fB6V/\r1I\u000e\u0002h\u0018\bPq\\h\r^";
      Q[193] = ".\bCVECtAB^?SO\n[\u0010A\u0003,\u0003\u0014\b]\u0003OY\u0016U\u0005\u000bqYP\u0015O:";
      Q[194] = "{\u001e\\MxE$[R\u000b\u0018F)\u001fM\u0012tt~X\u0016L(#t\u0005V\u001c%\u0013.X]D\u0018";
      Q[195] = "ZcRS?]FqQ[N\u0002PgC\u0005\"0\u0000'\u001c]N]\u0005{[\u00130\u0006V`\u0013\u0000N";
      Q[196] = "Ru1&\u0005T\u0019+euA(\u0005vf}\u0011\u007fT(:!}\u0011\t-4a\u0001ZWyg%";
      Q[197] = "]{*>ij\\&qg\u0010|3 `\"n,P)/:r,3f{>klJd.&\u0010";
      Q[198] = "T{4L\n\u0018]r-R\u001ai\u0003u R\u001f>]$v\rs\t\tr,\t\u0003\u000f\u000eu'";
      Q[199] = "f)!{>^z;\"sO\tx,9.4d;<:6~\u0015>=6pO\u001bh3+36\u0019=+P";
      Q[200] = "C\u0002QR(UMWA\\ZRr^S@$\u0000\u0011W\u001cX8\u0000r^[\u0002j\t\u001c\tGF(\u0005r";
      Q[201] = "\u001a\u000be\u0017B\u001b\u0014^u\u00190\u0014+Wg\u0005NNH^(\u001dRN+RrF^\u000e\u0012\u0014|JSw";
      Q[202] = "=0(kW\u0018a4#>]gjl>3V095jj\u0005g=1c6^\u0015e2,&H";
      Q[203] = "[\u0006B2\u0018<YPLg\bG\u000b>\u0010*\u001f9[]\u0019e\u0007%[>\u0010`\n-\u001bE\u00126\u0004x\u000b>";
      Q[204] = "zrU\u0006\u0017A}?Z\flJ\u0002:G\u0012\u0012\u001aa3\b\n\u000e\u001a\u0002|\\\u000e\u0017Z{~\t\u0016l";
      Q[205] = "y?ut\u0018]!<:d\u000e/%n9u\u001bC\u00179t,C\u0010@:z\u007f\u0015O8?un\u000e\u0012@";
      Q[206] = "-\u00171:K\u001e>\u001bweuG>\u0000+>\u0019ujDreu\u00125\u0007\"dEHh\fzY\u000bI)\u001fue\u0018Eo@K";
      Q[207] = "+|\u007f{\u0003xs\u007f0k\u0015\nw-3z\u0000fE}\u007f X1\u0012ys*\u0006n`!pe\u0016x\u0012";
      Q[208] = "_BHK?\u0002YTNMV\u00143\tB^(FP\u0000\rF4F3OYB-\u0006JM\fZV";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = Q[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(R[var4]);
            Q[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = Q[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = R[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            Q[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  Q[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(243541186180814L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = Q[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = R[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  Q[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(243541186180814L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        Q[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(243541186180814L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 202;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 65;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 198;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 80;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 204;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 66;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 202;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 65;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 198;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ea_C0218",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ea" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoMace var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoMace var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$4", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoMace var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$0", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoMace var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$5", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AutoMace var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$6", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AutoMace var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AutoMace var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$9", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AutoMace var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$3", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(AutoMace var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$1", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10(AutoMace var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ea_C0218;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ea_C0218", "lambda$new$8", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoMace)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
