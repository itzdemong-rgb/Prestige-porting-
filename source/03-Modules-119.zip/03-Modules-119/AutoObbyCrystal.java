package dev.zprestige.prestige.client.modules;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.AttackTargetUpdateEvent;
import dev.zprestige.prestige.api.util.ExpiringValue;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.util.BlockPlacementTarget;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.util.ExplosionDamageUtil;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.InteractionUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.client.modules.state.AutoObbyCrystalState;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.SlotReservation;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.util.Easing;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class AutoObbyCrystal extends Module implements RotationSource {
   private FloatSetting a;
   private FloatSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private ModeSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private BooleanSetting j;
   private FloatSetting k;
   private MinMaxSetting l;
   private MinMaxSetting m;
   private MinMaxSetting n;
   private IntSetting o;
   private FloatSetting p;
   private BooleanSetting q;
   private BooleanSetting r;
   private FloatSetting s;
   private ModeSetting t;
   private FloatSetting u;
   private FloatSetting v;
   private FloatSetting w;
   private BooleanSetting x;
   private BooleanSetting y;
   private BooleanSetting z;
   private IntSetting A;
   private BooleanSetting B;
   private FloatSetting C;
   private FloatSetting D;
   private FloatSetting E;
   private BooleanSetting F;
   private FloatSetting G;
   private FloatSetting H;
   private FloatSetting I;
   private BooleanSetting J;
   private BooleanSetting K;
   private BooleanSetting L;
   private IntSetting M;
   private ColorSetting N;
   private ColorSetting O;
   private ColorSetting P;
   private ColorSetting Q;
   public static boolean R;
   private AutoObbyCrystalState S;
   private ElapsedTimer T;
   private ElapsedTimer U;
   private ElapsedTimer V;
   private ElapsedTimer W;
   private boolean X;
   private boolean Y;
   private PlayerEntity Z;
   private BlockPos aa;
   private BlockPos ab;
   private Direction ac;
   private Vec3d ad;
   private BlockPos ae;
   private int af;
   private boolean ag;
   private boolean ah;
   private int ai;
   private List aj;
   private Vec3d ak;
   private Entity al;
   private Vec3d am;
   private Vec3d an;
   private long ao;
   private static final double ap = 0.5;
   private static final double aq = 0.02;
   private static final double ar = 27.5625;
   private static final float as = 180.0F;
   private static final double at = 900.0;
   private static final float au = 0.6F;
   private static final float av = 0.4F;
   private static final float aw = 0.02F;
   private ExpiringValue ax;
   private ExpiringValue ay;
   private LinkedHashMap az;
   private HashSet aA;
   private BlockPos aB;
   private BlockPos aC;
   private int aD;
   private ElapsedTimer aE;
   private static final long bb = 76073374701881L;
   private static final String[] hb;
   private static final String[] ib;
   private static final Map jb = new HashMap(13);
   private static final long[] kb;
   private static final Integer[] lb;
   private static final Map mb;
   private static final long[] nb;
   private static final Long[] ob;
   private static final Map pb;
   private static final Object[] wb = new Object[420];
   private static final String[] xb = new String[420];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;

   public AutoObbyCrystal() {
      super();
      long var10001 = 79585593507920L ^ 45541294339961L;
      var10001 = 79585593507920L ^ 120800096895760L;
      var10001 = 79585593507920L ^ 50078114978111L;
      var10001 = 79585593507920L ^ 95756928512647L;
      var10001 = 79585593507920L ^ 123039328811954L;
      var10001 = 79585593507920L ^ 42846792094612L;
      var10001 = 79585593507920L ^ 58559535558475L;
      var10001 = 79585593507920L ^ 27078688672764L;

      this.S = AutoObbyCrystalState.IDLE;
      this.T = new ElapsedTimer(106698256430889L);
      this.U = new ElapsedTimer(106698256430889L);
      this.V = new ElapsedTimer(106698256430889L);
      this.W = new ElapsedTimer(106698256430889L);
      this.af = -1;
      this.ai = -1;
      this.aj = new ArrayList();
      this.an = Vec3d.ZERO;
      this.ao = Long.MIN_VALUE;
      this.ax = new ExpiringValue(180.0F, false, Easing.SINE_IN_OUT, 137591480872731L);
      this.ay = new ExpiringValue(180.0F, false, Easing.SINE_IN_OUT, 137591480872731L);
      this.az = new LinkedHashMap();
      this.aA = new HashSet();
      this.aE = new ElapsedTimer(106698256430889L);
      FloatSetting var10000 = this.k;
      Object[] var20 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var19 = var10000;
      var19.aReturningFloatSetting(var20);
      var10000 = this.s;
      Object[] var22 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var21 = var10000;
      var21.aReturningFloatSetting(var22);
      MinMaxSetting var86 = this.n;
      Object[] var24 = new Object[]{invokeBinding3(this), 112057026795887L};
      MinMaxSetting var23 = var86;
      var23.aReturningMinMaxSetting(var24);
      BooleanSetting var87 = this.B;
      Object[] var26 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var25 = var87;
      var25.aReturningBooleanSetting(var26);
      var10000 = this.D;
      Object[] var28 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var27 = var10000;
      var27.aReturningFloatSetting(var28);
      BooleanSetting var89 = this.J;
      Object[] var30 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var29 = var89;
      var29.aReturningBooleanSetting(var30);
      var10000 = this.I;
      Object[] var32 = new Object[]{invokeBinding7(this), 34595201528535L};
      FloatSetting var31 = var10000;
      var31.aReturningFloatSetting(var32);
      var10000 = this.C;
      Object[] var34 = new Object[]{invokeBinding8(this), 34595201528535L};
      FloatSetting var33 = var10000;
      var33.aReturningFloatSetting(var34);
      var10000 = this.p;
      Object[] var36 = new Object[]{invokeBinding9(this), 34595201528535L};
      FloatSetting var35 = var10000;
      var35.aReturningFloatSetting(var36);
      BooleanSetting var93 = this.q;
      Object[] var38 = new Object[]{invokeBinding10(this), 88791076916140L};
      BooleanSetting var37 = var93;
      var37.aReturningBooleanSetting(var38);
      ColorSetting var94 = this.Q;
      Object[] var40 = new Object[]{invokeBinding11(this), 41489415177024L};
      ColorSetting var39 = var94;
      var39.aReturningColorSetting(var40);
      ColorSetting var95 = this.O;
      Object[] var42 = new Object[]{invokeBinding12(this), 41489415177024L};
      ColorSetting var41 = var95;
      var41.aReturningColorSetting(var42);
      ColorSetting var96 = this.P;
      Object[] var44 = new Object[]{invokeBinding13(this), 41489415177024L};
      ColorSetting var43 = var96;
      var43.aReturningColorSetting(var44);
      var10000 = this.v;
      Object[] var46 = new Object[]{invokeBinding14(this), 34595201528535L};
      FloatSetting var45 = var10000;
      var45.aReturningFloatSetting(var46);
      var10000 = this.E;
      Object[] var48 = new Object[]{invokeBinding15(this), 34595201528535L};
      FloatSetting var47 = var10000;
      var47.aReturningFloatSetting(var48);
      var10000 = this.G;
      Object[] var50 = new Object[]{invokeBinding16(this), 34595201528535L};
      FloatSetting var49 = var10000;
      var49.aReturningFloatSetting(var50);
      MinMaxSetting var100 = this.m;
      Object[] var52 = new Object[]{invokeBinding17(this), 112057026795887L};
      MinMaxSetting var51 = var100;
      var51.aReturningMinMaxSetting(var52);
      var10000 = this.w;
      Object[] var54 = new Object[]{invokeBinding18(this), 34595201528535L};
      FloatSetting var53 = var10000;
      var53.aReturningFloatSetting(var54);
      var10000 = this.H;
      Object[] var56 = new Object[]{invokeBinding19(this), 34595201528535L};
      FloatSetting var55 = var10000;
      var55.aReturningFloatSetting(var56);
      IntSetting var103 = this.o;
      Object[] var58 = new Object[]{invokeBinding20(this), 43459238656994L};
      IntSetting var57 = var103;
      var57.aReturningIntSetting(var58);
      BooleanSetting var104 = this.r;
      Object[] var60 = new Object[]{invokeBinding21(this), 88791076916140L};
      BooleanSetting var59 = var104;
      var59.aReturningBooleanSetting(var60);
      ModeSetting var105 = this.t;
      Object[] var62 = new Object[]{invokeBinding22(this), 121607650890692L};
      ModeSetting var61 = var105;
      var61.aReturningModeSetting(var62);
      BooleanSetting var106 = this.z;
      Object[] var64 = new Object[]{invokeBinding23(this), 88791076916140L};
      BooleanSetting var63 = var106;
      var63.aReturningBooleanSetting(var64);
      BooleanSetting var107 = this.L;
      Object[] var66 = new Object[]{invokeBinding24(this), 88791076916140L};
      BooleanSetting var65 = var107;
      var65.aReturningBooleanSetting(var66);
      var10000 = this.u;
      Object[] var68 = new Object[]{invokeBinding25(this), 34595201528535L};
      FloatSetting var67 = var10000;
      var67.aReturningFloatSetting(var68);
      ColorSetting var109 = this.N;
      Object[] var70 = new Object[]{invokeBinding26(this), 41489415177024L};
      ColorSetting var69 = var109;
      var69.aReturningColorSetting(var70);
      MinMaxSetting var110 = this.l;
      Object[] var72 = new Object[]{invokeBinding27(this), 112057026795887L};
      MinMaxSetting var71 = var110;
      var71.aReturningMinMaxSetting(var72);
      IntSetting var111 = this.M;
      Object[] var74 = new Object[]{invokeBinding28(this), 43459238656994L};
      IntSetting var73 = var111;
      var73.aReturningIntSetting(var74);
      BooleanSetting var112 = this.y;
      Object[] var76 = new Object[]{invokeBinding29(this), 88791076916140L};
      BooleanSetting var75 = var112;
      var75.aReturningBooleanSetting(var76);
      IntSetting var113 = this.A;
      Object[] var78 = new Object[]{invokeBinding30(this), 43459238656994L};
      IntSetting var77 = var113;
      var77.aReturningIntSetting(var78);
      BooleanSetting var114 = this.x;
      Object[] var80 = new Object[]{invokeBinding31(this), 88791076916140L};
      BooleanSetting var79 = var114;
      var79.aReturningBooleanSetting(var80);
      BooleanSetting var115 = this.K;
      Object[] var82 = new Object[]{invokeBinding32(this), 88791076916140L};
      BooleanSetting var81 = var115;
      var81.aReturningBooleanSetting(var82);
      BooleanSetting var116 = this.F;
      Object[] var84 = new Object[]{invokeBinding33(this), 88791076916140L};
      BooleanSetting var83 = var116;
      var83.aReturningBooleanSetting(var84);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 76427539039287L;
      long var6 = var2 ^ 38266410274184L;
      Object[] var9 = new Object[]{var4};
      AutoObbyCrystal var8 = this;
      var8.y(var9);
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var6};
      RotationManager var10 = var10000;
      var10.dReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var8;
      RotationManager var40;
      label30: {
         long var4;
         AutoObbyCrystal var39;
         long var2 = (Long)var1[0];
         var4 = var2 ^ 128142750287914L;
         long var6 = var2 ^ 18941404224204L;
         var8 = var2 ^ 64097829662901L;
         long var10 = var2 ^ 43943734930567L;
         long var12 = var2 ^ 4711318931841L;
         int var14 = Event.bReturningInt();
         int var42 = var14;
         AutoObbyCrystal var41 = this;
         var39 = var41;
         AutoObbyCrystal var34 = var41;
         label29:
         if (var42 == 0) {
            // int var43 = var34.af;
            if (var43 != var44) {
               int var46 = var14;
               AutoObbyCrystal var45 = this;
               var39 = var45;
               AutoObbyCrystal var35 = var45;
               if (var46 != 0) {
                  break label29;
               }

               AutoObbyCrystal var47 = var35;
               AutoObbyCrystal var36 = var47;
               BooleanSetting var17 = var36.h;
               Boolean var18 = (Boolean)var17.aReturningObject();
               boolean var48 = var18;
               if (var48) {
                  int var50 = var14;
                  RotationManager var49 = Prestige.o;
                  var40 = var49;
                  RotationManager var37 = var49;
                  if (var50 != 0) {
                     break label30;
                  }

                  RotationManager var51 = var37;
                  RotationManager var38 = var51;
                  Object[] var22 = new Object[0];
                  RotationManager var21 = var38;
                  boolean var52 = var21.fReturningBoolean(var22);
                  if (var52) {
                     RotationManager var10000 = Prestige.o;
                     int var10001 = this.af;
                     Object[] var10004 = new Object[]{null, var10};
                     var10004[0] = var10001;
                     Object[] var25 = var10004;
                     RotationManager var24 = var10000;
                     var24.hReturningVoid(var25);
                     Object[] var26 = new Object[]{this, var6};
                     SlotReservation.aReturningVoid(var26);
                     this.af = -1;
                  }
               }
            }

            Object[] var29 = new Object[]{var12};
            AutoObbyCrystal var28 = this;
            var28.w(var29);
            var39 = this;
         }

         Object[] var31 = new Object[]{var4};
         AutoObbyCrystal var30 = var39;
         var30.y(var31);
         var40 = Prestige.o;
      }

      Object[] var33 = new Object[]{this, var8};
      RotationManager var32 = var40;
      var32.eReturningVoid(var33);
   }

   @Override
   public int a() {
      return 30;
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      long var10001 = 19138582949442L ^ 139273995222794L;
      Object[] var7 = new Object[]{122884608676168L};
      AutoObbyCrystal var6 = this;
      var6.y(var7);
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      label40: {
         int var4;
         AutoObbyCrystal var24;
         label43: {
            var4 = Event.cReturningInt();
            int var26 = var4;
            AutoObbyCrystalState var25 = this.S;
            Object var23 = var25;
            AutoObbyCrystalState var21 = var25;
            if (var26 != 0) {
               AutoObbyCrystalState var28 = AutoObbyCrystalState.IDLE;
               AutoObbyCrystalState var27 = var21;
               if (var27 == var28) {
                  return;
               }

               int var30 = var4;
               AutoObbyCrystal var29 = this;
               var24 = var29;
               AutoObbyCrystal var22 = var29;
               if (var30 == 0) {
                  break label43;
               }

               ModeSetting var9 = var22.f;
               Object var31 = var9.aReturningObject();
               var23 = var31;
            }

            String var10000 = (String)var23;
            String var12 = "Manual";
            String var11 = var10000;
            boolean var32 = var11.equals(var12);
            if (!var32) {
               break label40;
            }

            AutoObbyCrystal var33 = this;
            var24 = var33;
         }

         AutoObbyCrystalState var35 = AutoObbyCrystalState.BREAK_CRYSTAL;
         AutoObbyCrystalState var34 = var24.S;
         if (var34 == var35) {
            MinecraftClient var14 = b;
            HitResult var6 = var14.crosshairTarget;
            int var36 = var4;
            if (var36 == 0) {
               return;
            }

            boolean var37 = var6 instanceof EntityHitResult;
            if (var37) {
               EntityHitResult var5 = (EntityHitResult)var6;
               int var38 = var4;
               if (var38 == 0) {
                  return;
               }

               EntityHitResult var16 = var5;
               boolean var39 = var16.getEntity() instanceof EndCrystalEntity;
               if (var39) {
                  return;
               }
            }
         }
      }

      Object[] var20 = new Object[0];
      AttackInputEvent var19 = var1;
      var19.aReturningVoid(var20);
   }

   @EventListener
   public void a(AttackTargetUpdateEvent var1) {
      AutoObbyCrystalState var7 = AutoObbyCrystalState.IDLE;
      AutoObbyCrystalState var6 = this.S;
      if (var6 != var7) {
         Object[] var5 = new Object[0];
         AttackTargetUpdateEvent var4 = var1;
         var4.aReturningVoid(var5);
      }
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      AutoObbyCrystalState var7 = AutoObbyCrystalState.IDLE;
      AutoObbyCrystalState var6 = this.S;
      if (var6 != var7) {
         Object[] var5 = new Object[0];
         ItemUseEvent var4 = var1;
         var4.aReturningVoid(var5);
      }
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      Object[] var5 = new Object[0];
      PlayerUpdateEvent var4 = var1;
      EventPhase var10000 = var4.aReturningEventPhase(var5);
      EventPhase var11 = EventPhase.PRE;
      EventPhase var10 = var10000;
      if (var10 == var11) {
         MinecraftClient var6 = b;
         ClientPlayerEntity var12 = var6.player;
         if (var12 != null) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            this.ak = var9.getEyePos();
         }
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 40736634816488L ^ 93450466631066L;
      var10001 = 40736634816488L ^ 86564131207076L;
      var10001 = 40736634816488L ^ 131452704171929L;
      var10001 = 40736634816488L ^ 115290366670061L;
      var10001 = 40736634816488L ^ 106471585046469L;
      var10001 = 40736634816488L ^ 53756379821764L;
      var10001 = 40736634816488L ^ 12115809847540L;
      var10001 = 40736634816488L ^ 76498601965419L;
      var10001 = 40736634816488L ^ 120011338810778L;
      int var22 = Event.cReturningInt();
      BooleanSetting var36 = this.i;
      Boolean var37 = (Boolean)var36.aReturningObject();
      boolean var244 = var37;
      if (var244) {
         int var246 = var22;
         MinecraftClient var245 = b;
         MinecraftClient var174 = var245;
         MinecraftClient var172 = var245;
         if (var246 != 0) {
            MinecraftClient var247 = var172;
            MinecraftClient var173 = var247;
            MinecraftClient var39 = var173;
            ClientPlayerEntity var248 = var39.player;
            if (var248 == null) {
               return;
            }

            MinecraftClient var249 = b;
            var174 = var249;
         }

         MinecraftClient var42 = var174;
         ClientWorld var250 = var42.world;
         if (var250 != null) {
            float var23;
            boolean var177;
            label243: {
               label242: {
                  Object[] var44 = new Object[]{24088815448364L};
                  var23 = bReturningFloat(var44);
                  int var252 = var22;
                  AutoObbyCrystal var251 = this;
                  AutoObbyCrystal var176 = var251;
                  AutoObbyCrystal var175 = var251;
                  if (var252 != 0) {
                     BooleanSetting var45 = var175.J;
                     Boolean var46 = (Boolean)var45.aReturningObject();
                     boolean var253 = var46;
                     if (!var253) {
                        break label242;
                     }

                     AutoObbyCrystal var254 = this;
                     var176 = var254;
                  }

                  PlayerEntity var255 = var176.Z;
                  if (var255 != null) {
                     boolean var256 = true;
                     var177 = var256;
                     break label243;
                  }
               }

               var177 = false;
            }

            boolean var24 = var177;
            boolean var257 = var24;
            if (var257) {
               PlayerEntity var50 = this.Z;
               this.aB = var50.getBlockPos();
            }

            boolean var188;
            label233: {
               label232: {
                  AutoObbyCrystal var187;
                  label254: {
                     int var186;
                     ExpiringValue var10000 = this.ax;
                     Object[] var10004 = new Object[]{null, null, 85588463858437L};
                     var10004[1] = var24;
                     var10004[0] = var10000;
                     Object[] var52 = var10004;
                     float var25 = cReturningFloat(var52);
                     BooleanSetting var53 = this.J;
                     Boolean var54 = (Boolean)var53.aReturningObject();
                     byte var361 = ((byte)(((java.lang.Boolean)(var54)).booleanValue() ? 1 : 0));
                     int var259 = var22;
                     byte var258 = var361;
                     var186 = var258;
                     byte var178 = var258;
                     label230:
                     if (var259 != 0) {
                        Object var185;
                        label255: {
                           byte var260 = var178;
                           if (var260 != 0) {
                              float var404;
                              int var362 = (var404 = var25 - 0.01F) == 0.0F ? 0 : (var404 < 0.0F ? -1 : 1);
                              int var262 = var22;
                              int var261 = var362;
                              var186 = var261;
                              int var179 = var261;
                              if (var262 == 0) {
                                 break label230;
                              }

                              int var263 = var179;
                              int var180 = var263;
                              int var264 = var180;
                              if (var264 > 0) {
                                 int var266 = var22;
                                 BlockPos var265 = this.aB;
                                 var185 = var265;
                                 BlockPos var181 = var265;
                                 if (var266 == 0) {
                                    break label255;
                                 }

                                 BlockPos var267 = var181;
                                 BlockPos var182 = var267;
                                 BlockPos var268 = var182;
                                 if (var268 != null) {
                                    ColorSetting var60 = this.P;
                                    Color var363 = (Color)var60.aReturningObject();
                                    Object[] var10005 = new Object[]{null, null, null, 125286838164082L};
                                    var10005[2] = var23;
                                    var10005[1] = var25;
                                    var10005[0] = var363;
                                    Object[] var61 = var10005;
                                    Color var26 = aReturningColor(var61);
                                    Color var62 = var26;
                                    int var364 = var62.getAlpha();
                                    int var270 = var22;
                                    int var269 = var364;
                                    var186 = var269;
                                    int var183 = var269;
                                    if (var270 == 0) {
                                       break label230;
                                    }

                                    int var271 = var183;
                                    if (var271 > 0) {
                                       Object[] var65 = new Object[]{var1, this.aB, var26, 50613273431836L};
                                       AutoObbyCrystal var64 = this;
                                       var64.jReturningVoid(var65);
                                       BlockPos var66 = this.aB;
                                       Object[] var68 = new Object[]{var1, var66.up(), var26, 50613273431836L};
                                       AutoObbyCrystal var67 = this;
                                       var67.jReturningVoid(var68);
                                    }
                                 }
                              }
                           }

                           int var273 = var22;
                           AutoObbyCrystal var272 = this;
                           var187 = var272;
                           AutoObbyCrystal var184 = var272;
                           if (var273 == 0) {
                              break label254;
                           }

                           BooleanSetting var70 = var184.K;
                           Object var274 = var70.aReturningObject();
                           var185 = var274;
                        }

                        Boolean var72 = (Boolean)var185;
                        var186 = ((((java.lang.Boolean)(var72)).booleanValue() ? 1 : 0));
                     }

                     int var275 = var186;
                     if (var275 == 0) {
                        break label232;
                     }

                     var187 = this;
                  }

                  BlockPos var276 = var187.aa;
                  if (var276 != null) {
                     boolean var277 = true;
                     var188 = var277;
                     break label233;
                  }
               }

               var188 = false;
            }

            boolean var353 = var188;
            boolean var278 = var353;
            if (var278) {
               this.aC = this.aa;
            }

            int var228;
            ExpiringValue var365 = this.ay;
            Object[] var393 = new Object[]{null, null, 85588463858437L};
            var393[1] = var353;
            var393[0] = var365;
            Object[] var75 = var393;
            float var27 = cReturningFloat(var75);
            BooleanSetting var76 = this.K;
            Boolean var77 = (Boolean)var76.aReturningObject();
            byte var366 = ((byte)(((java.lang.Boolean)(var77)).booleanValue() ? 1 : 0));
            int var280 = var22;
            byte var279 = var366;
            var228 = var279;
            byte var189 = var279;
            label206:
            if (var280 != 0) {
               Object var227;
               label204: {
                  byte var281 = var189;
                  if (var281 != 0) {
                     float var405;
                     int var367 = (var405 = var27 - 0.01F) == 0.0F ? 0 : (var405 < 0.0F ? -1 : 1);
                     int var283 = var22;
                     int var282 = var367;
                     var228 = var282;
                     int var190 = var282;
                     if (var283 == 0) {
                        break label206;
                     }

                     int var284 = var190;
                     int var191 = var284;
                     int var285 = var191;
                     if (var285 > 0) {
                        int var287 = var22;
                        BlockPos var286 = this.aC;
                        var227 = var286;
                        BlockPos var192 = var286;
                        if (var287 == 0) {
                           break label204;
                        }

                        BlockPos var288 = var192;
                        BlockPos var193 = var288;
                        BlockPos var289 = var193;
                        if (var289 != null) {
                           boolean var199;
                           label197: {
                              boolean var198;
                              Object[] var83 = new Object[]{this.aC, Blocks.OBSIDIAN, 90720632922225L};
                              boolean var368 = BlockUtil.bReturningBoolean(var83);
                              int var291 = var22;
                              boolean var290 = var368;
                              var198 = var290;
                              boolean var194 = var290;
                              label196:
                              if (var291 != 0) {
                                 boolean var292 = var194;
                                 boolean var195 = var292;
                                 boolean var293 = var195;
                                 if (!var293) {
                                    Object[] var86 = new Object[]{this.aC, Blocks.BEDROCK, 90720632922225L};
                                    boolean var369 = BlockUtil.bReturningBoolean(var86);
                                    int var295 = var22;
                                    boolean var294 = var369;
                                    var198 = var294;
                                    boolean var196 = var294;
                                    if (var295 == 0) {
                                       break label196;
                                    }

                                    boolean var296 = var196;
                                    boolean var197 = var296;
                                    boolean var297 = var197;
                                    if (!var297) {
                                       var199 = false;
                                       break label197;
                                    }
                                 }

                                 var198 = true;
                              }

                              boolean var298 = var198;
                              var199 = var298;
                           }

                           AutoObbyCrystal var222;
                           Render3DEvent var223;
                           BlockPos var224;
                           Color var225;
                           boolean var226;
                           label187: {
                              boolean var28 = var199;
                              BlockPos var10002 = this.aC;
                              ColorSetting var89 = this.N;
                              Color var10003 = (Color)var89.aReturningObject();
                              Object[] var10008 = new Object[]{null, null, null, 125286838164082L};
                              var10008[2] = var23;
                              var10008[1] = var27;
                              var10008[0] = var10003;
                              Object[] var90 = var10008;
                              var10003 = aReturningColor(var90);
                              int var304 = var22;
                              boolean var303 = var28;
                              Color var302 = var10003;
                              BlockPos var301 = var10002;
                              Render3DEvent var300 = var1;
                              AutoObbyCrystal var299 = this;
                              AutoObbyCrystal var213 = var299;
                              Render3DEvent var214 = var300;
                              BlockPos var215 = var301;
                              Color var216 = var302;
                              boolean var217 = var303;
                              AutoObbyCrystal var200 = var299;
                              Render3DEvent var201 = var300;
                              BlockPos var202 = var301;
                              Color var203 = var302;
                              boolean var204 = var303;
                              if (var304 != 0) {
                                 boolean var309 = var204;
                                 Color var308 = var203;
                                 BlockPos var307 = var202;
                                 Render3DEvent var306 = var201;
                                 AutoObbyCrystal var305 = var200;
                                 AutoObbyCrystal var218 = var305;
                                 Render3DEvent var219 = var306;
                                 BlockPos var220 = var307;
                                 Color var221 = var308;
                                 AutoObbyCrystal var205 = var305;
                                 Render3DEvent var206 = var306;
                                 BlockPos var207 = var307;
                                 Color var208 = var308;
                                 if (var309) {
                                    var226 = false;
                                    var225 = var221;
                                    var224 = var220;
                                    var223 = var219;
                                    var222 = var218;
                                    break label187;
                                 }

                                 Color var313 = var208;
                                 BlockPos var312 = var207;
                                 Render3DEvent var311 = var206;
                                 AutoObbyCrystal var310 = var205;
                                 AutoObbyCrystal var209 = var310;
                                 Render3DEvent var210 = var311;
                                 BlockPos var211 = var312;
                                 Color var212 = var313;
                                 var217 = true;
                                 var216 = var212;
                                 var215 = var211;
                                 var214 = var210;
                                 var213 = var209;
                              }

                              boolean var318 = var217;
                              Color var317 = var216;
                              BlockPos var316 = var215;
                              Render3DEvent var315 = var214;
                              AutoObbyCrystal var314 = var213;
                              var222 = var314;
                              var223 = var315;
                              var224 = var316;
                              var225 = var317;
                              var226 = var318;
                           }

                           Object[] var401 = new Object[]{null, null, null, null, null, 79349212365426L};
                           var401[4] = var23;
                           var401[3] = var226;
                           var401[2] = var225;
                           var401[1] = var224;
                           var401[0] = var223;
                           Object[] var93 = var401;
                           AutoObbyCrystal var92 = var222;
                           var92.kReturningVoid(var93);
                           BlockPos var94 = this.aC;
                           BlockPos var386 = var94.up();
                           ColorSetting var95 = this.O;
                           Color var390 = (Color)var95.aReturningObject();
                           var401 = new Object[]{null, null, null, 125286838164082L};
                           var401[2] = var23;
                           var401[1] = var27;
                           var401[0] = var390;
                           Object[] var96 = var401;
                           var390 = aReturningColor(var96);
                           var401 = new Object[]{null, null, null, null, null, 79349212365426L};
                           var401[4] = var23;
                           var401[3] = true;
                           var401[2] = var390;
                           var401[1] = var386;
                           var401[0] = var1;
                           Object[] var98 = var401;
                           AutoObbyCrystal var97 = this;
                           var97.kReturningVoid(var98);
                        }
                     }
                  }

                  HashSet var99 = this.aA;
                  var99.clear();
                  BooleanSetting var100 = this.L;
                  var227 = var100.aReturningObject();
               }

               Boolean var101 = (Boolean)var227;
               var228 = ((((java.lang.Boolean)(var101)).booleanValue() ? 1 : 0));
            }

            LinkedHashMap var237;
            int var354;
            label177: {
               AutoObbyCrystal var236;
               label176: {
                  var354 = var228;
                  int var319 = var354;
                  if (var319 != 0) {
                     int var321 = var22;
                     AutoObbyCrystal var320 = this;
                     var236 = var320;
                     AutoObbyCrystal var229 = var320;
                     if (var321 == 0) {
                        break label176;
                     }

                     AutoObbyCrystal var322 = var229;
                     AutoObbyCrystal var230 = var322;
                     AutoObbyCrystalState var324 = AutoObbyCrystalState.IDLE;
                     AutoObbyCrystalState var323 = var230.S;
                     if (var323 == var324) {
                        int var326 = var22;
                        AutoObbyCrystal var325 = this;
                        var236 = var325;
                        AutoObbyCrystal var231 = var325;
                        if (var326 == 0) {
                           break label176;
                        }

                        AutoObbyCrystal var327 = var231;
                        AutoObbyCrystal var232 = var327;
                        List var105 = var232.aj;
                        boolean var328 = var105.isEmpty();
                        if (!var328) {
                           List var107 = this.aj;
                           int var370 = var107.size();
                           IntSetting var108 = this.M;
                           Integer var109 = (Integer)var108.aReturningObject();
                           int var111 = var109;
                           int var110 = var370;
                           int var29 = Math.min(var110, var111);
                           ColorSetting var112 = this.Q;
                           Color var30 = (Color)var112.aReturningObject();
                           int var338;
                           do {
                              int var330 = var29;
                              int var329 = var31;
                              if (var329 >= var330) {
                                 break;
                              }

                              int var114 = var31;
                              List var113 = this.aj;
                              BlockPos var115 = ((BlockPlacementTarget)var113.get(var114)).a;
                              BlockPos var32 = var115.up();
                              BlockPos var117 = var32;
                              HashSet var116 = this.aA;
                              var116.add(var117);
                              int var332 = var22;
                              LinkedHashMap var331 = this.az;
                              var237 = var331;
                              LinkedHashMap var233 = var331;
                              if (var332 == 0) {
                                 break label177;
                              }

                              Function var120 = invokeBinding34();
                              BlockPos var119 = var32;
                              LinkedHashMap var118 = var233;
                              ExpiringValue var33 = (ExpiringValue)var118.computeIfAbsent(var119, var120);
                              Object[] var122 = new Object[0];
                              ExpiringValue var121 = var33;
                              byte var371 = ((byte)((var121.aReturningBoolean(var122)) ? 1 : 0));
                              int var334 = var22;
                              byte var333 = var371;
                              int var235 = var333;
                              byte var234 = var333;
                              if (var334 != 0) {
                                 byte var335 = var234;
                                 if (var335 == 0) {
                                    var393 = new Object[]{null, 118431390085196L};
                                    var393[0] = true;
                                    Object[] var125 = var393;
                                    ExpiringValue var124 = var33;
                                    var124.aReturningVoid(var125);
                                 }

                                 byte var372 = 30;
                                 Color var127 = var30;
                                 int var383 = var127.getAlpha();
                                 Color var128 = var30;
                                 int var387 = var128.getAlpha() * var31;
                                 boolean var392 = true;
                                 int var130 = var29;
                                 int var132 = var383 - var387 / Math.max(1, var130);
                                 var235 = Math.max(30, var132);
                              }

                              int var34 = var235;
                              Object[] var134 = new Object[]{76800015505453L};
                              ExpiringValue var133 = var33;
                              float var384 = var133.aReturningFloat(var134);
                              Object[] var396 = new Object[]{null, null, null, 106238354075779L};
                              var396[2] = var23;
                              var396[1] = var384;
                              var396[0] = var34;
                              Object[] var135 = var396;
                              int var35 = aReturningInt(var135);
                              int var336 = var22;
                              if (var336 != 0) {
                                 int var337 = var35;
                                 if (var337 > 0) {
                                    Color var137 = var30;
                                    int var397 = var137.getRed();
                                    Color var138 = var30;
                                    int var10006 = var138.getGreen();
                                    Color var139 = var30;
                                    Object[] var141 = new Object[]{var1, var32, new Color(var397, var10006, var139.getBlue(), var35), 50613273431836L};
                                    AutoObbyCrystal var140 = this;
                                    var140.jReturningVoid(var141);
                                 }

                                 var31++;
                              }

                              var338 = var22;
                           } while (var338 != 0);
                        }
                     }
                  }

                  var236 = this;
               }

               var237 = var236.az;
            }

            LinkedHashMap var143 = var237;
            Set var144 = var143.entrySet();
            Iterator var355 = var144.iterator();

            while (true) {
               Iterator var145 = var355;
               boolean var339 = var145.hasNext();
               if (!var339) {
                  break;
               }

               Iterator var146 = var355;
               Entry var356 = (Entry)var146.next();
               int var341 = var22;
               HashSet var340 = this.aA;
               Object var239 = var340;
               HashSet var238 = var340;
               if (var341 != 0) {
                  Entry var147 = var356;
                  Object var149 = var147.getKey();
                  HashSet var148 = var238;
                  boolean var342 = var148.contains(var149);
                  if (var342) {
                     continue;
                  }

                  Entry var152 = var356;
                  var239 = var152.getValue();
               }

               ExpiringValue var357 = (ExpiringValue)var239;
               int var344 = var22;
               ExpiringValue var343 = var357;
               ExpiringValue var241 = var343;
               ExpiringValue var240 = var343;
               if (var344 != 0) {
                  Object[] var154 = new Object[0];
                  ExpiringValue var153 = var240;
                  boolean var345 = var153.aReturningBoolean(var154);
                  if (var345) {
                     var393 = new Object[]{null, 118431390085196L};
                     var393[0] = false;
                     Object[] var157 = var393;
                     ExpiringValue var156 = var357;
                     var156.aReturningVoid(var157);
                  }

                  var241 = var357;
               }

               Object[] var160 = new Object[]{76800015505453L};
               ExpiringValue var159 = var241;
               float var358 = var159.aReturningFloat(var160);
               float var406;
               int var373 = (var406 = var358 - 0.01F) == 0.0F ? 0 : (var406 < 0.0F ? -1 : 1);
               int var347 = var22;
               int var346 = var373;
               int var243 = var346;
               int var242 = var346;
               if (var347 != 0) {
                  int var348 = var242;
                  if (var348 < 0) {
                     Iterator var162 = var355;
                     var162.remove();
                     int var349 = var22;
                     if (var349 != 0) {
                        continue;
                     }
                  }

                  var243 = var354;
               }

               int var350 = var243;
               if (var350 != 0) {
                  ColorSetting var164 = this.Q;
                  Color var359 = (Color)var164.aReturningObject();
                  short var374 = 1414;
                  var10001 = 1787662373594693838L;
                  Object[] var398 = new Object[]{null, null, null, 106238354075779L};
                  var398[2] = var23;
                  var398[1] = var358;
                  var398[0] = 30;
                  Object[] var165 = var398;
                  int var360 = aReturningInt(var165);
                  int var351 = var360;
                  if (var351 > 0) {
                     Entry var166 = var356;
                     BlockPos var388 = (BlockPos)var166.getKey();
                     Color var167 = var359;
                     int var399 = var167.getRed();
                     Color var168 = var359;
                     int var400 = var168.getGreen();
                     Color var169 = var359;
                     Object[] var171 = new Object[]{var1, var388, new Color(var399, var400, var169.getBlue(), var360), 50613273431836L};
                     AutoObbyCrystal var170 = this;
                     var170.jReturningVoid(var171);
                  }
               }

               int var352 = var22;
               if (var352 == 0) {
                  break;
               }
            }

            return;
         }
      }
   }

   private static float bReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 76073374701881L ^ var1;
      double var3 = System.currentTimeMillis() / 900.0 * (Math.PI * 2);
      return 0.5F + 0.5F * (float)Math.sin(var3);
   }

   private static float cReturningFloat(Object[] var0) {
      ExpiringValue var4 = (ExpiringValue)var0[0];
      boolean var1 = (Boolean)var0[1];
      long var2 = (Long)var0[2];
      var2 = 76073374701881L ^ var2;
      long var5 = var2 ^ 109203291789936L;
      long var7 = var2 ^ 84932141609489L;
      int var9 = Event.bReturningInt();
      int var21 = var9;
      ExpiringValue var20 = var4;
      ExpiringValue var19 = var20;
      ExpiringValue var18 = var20;
      if (var21 == 0) {
         Object[] var11 = new Object[0];
         ExpiringValue var10 = var18;
         boolean var10000 = var10.aReturningBoolean(var11);
         boolean var23 = var1;
         boolean var22 = var10000;
         if (var22 != var23) {
            Object[] var10004 = new Object[]{null, var5};
            var10004[0] = var1;
            Object[] var14 = var10004;
            ExpiringValue var13 = var4;
            var13.aReturningVoid(var14);
         }

         var19 = var4;
      }

      Object[] var17 = new Object[]{var7};
      ExpiringValue var16 = var19;
      return var16.aReturningFloat(var17);
   }

   private static int aReturningInt(Object[] var0) {
      int var5 = (Integer)var0[0];
      float var2 = (Float)var0[1];
      float var1 = (Float)var0[2];
      long var3 = (Long)var0[3];
      var3 = 76073374701881L ^ var3;
      float var7 = var5 * var2 * (0.6F + 0.4F * var1);
      int var6 = Math.round(var7);
      byte var10000 = 0;
      short var10001 = 31673;
      long var10002 = 4056860321841452878L ^ var3;
      var10001 = 255;
      int var9 = var6;
      int var11 = Math.min(255, var9);
      return Math.max(0, var11);
   }

   private static Color aReturningColor(Object[] var0) {
      Color var5 = (Color)var0[0];
      float var2 = (Float)var0[1];
      float var1 = (Float)var0[2];
      long var3 = (Long)var0[3];
      var3 = 76073374701881L ^ var3;
      long var6 = var3 ^ 92758951408584L;
      Color var8 = var5;
      int var10002 = var8.getRed();
      Color var9 = var5;
      int var10003 = var9.getGreen();
      Color var10 = var5;
      int var10004 = var10.getBlue();
      Color var11 = var5;
      int var10005 = var11.getAlpha();
      Object[] var10010 = new Object[]{null, null, null, var6};
      var10010[2] = var1;
      var10010[1] = var2;
      var10010[0] = var10005;
      Object[] var12 = var10010;
      return new Color(var10002, var10003, var10004, aReturningInt(var12));
   }

   private void jReturningVoid(Object[] var1) {
      Render3DEvent var2 = (Render3DEvent)var1[0];
      BlockPos var4 = (BlockPos)var1[1];
      Color var3 = (Color)var1[2];
      long var5 = (Long)var1[3];
      var5 = 76073374701881L ^ var5;
      long var7 = var5 ^ 12392614544929L;
      RenderContext var10000 = var2.b;
      MeshBufferManager var10001 = var2.a;
      BlockPos var9 = var4;
      float var10002 = var9.getX();
      BlockPos var10 = var4;
      float var10003 = var10.getY();
      BlockPos var11 = var4;
      float var10004 = var11.getZ();
      BlockPos var12 = var4;
      float var10005 = var12.getX() + 1.0F;
      BlockPos var13 = var4;
      float var10006 = var13.getY() + 1.0F;
      BlockPos var14 = var4;
      float var10007 = var14.getZ() + 1.0F;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var3, var7};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var10003;
      var10011[2] = var10002;
      var10011[1] = var10001;
      var10011[0] = var10000;
      Object[] var15 = var10011;
      ShapeRenderer.gReturningVoid(var15);
   }

   private void kReturningVoid(Object[] var1) {
      Render3DEvent var8 = (Render3DEvent)var1[0];
      BlockPos var7 = (BlockPos)var1[1];
      Color var6 = (Color)var1[2];
      boolean var2 = (Boolean)var1[3];
      float var5 = (Float)var1[4];
      long var3 = (Long)var1[5];
      var3 = 76073374701881L ^ var3;
      long var9 = var3 ^ 125263039196299L;
      long var11 = var3 ^ 38562528171095L;
      int var13 = Event.cReturningInt();
      int var32 = var13;
      if (var32 != 0) {
         boolean var33 = var2;
         if (var33) {
            Color var17 = var6;
            int var10002 = var17.getRed();
            Color var18 = var6;
            int var10003 = var18.getGreen();
            Color var19 = var6;
            int var10004 = var19.getBlue();
            byte var10005 = 1;
            Color var20 = var6;
            int var22 = var20.getAlpha() / 4;
            Color var14 = new Color(var10002, var10003, var10004, Math.max(1, var22));
            float var15 = 0.01F * var5;
            RenderContext var10000 = var8.b;
            MeshBufferManager var10001 = var8.a;
            BlockPos var23 = var7;
            float var35 = var23.getX() - var15;
            BlockPos var24 = var7;
            float var36 = var24.getY() - var15;
            BlockPos var25 = var7;
            float var37 = var25.getZ() - var15;
            BlockPos var26 = var7;
            float var38 = var26.getX() + 1.0F + var15;
            BlockPos var27 = var7;
            float var10006 = var27.getY() + 1.0F + var15;
            BlockPos var28 = var7;
            float var10007 = var28.getZ() + 1.0F + var15;
            Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var14, var9};
            var10011[7] = var10007;
            var10011[6] = var10006;
            var10011[5] = var38;
            var10011[4] = var37;
            var10011[3] = var36;
            var10011[2] = var35;
            var10011[1] = var10001;
            var10011[0] = var10000;
            Object[] var29 = var10011;
            ShapeRenderer.hReturningVoid(var29);
         }

         Object[] var31 = new Object[]{var8, var7, var6, var11};
         AutoObbyCrystal var30 = this;
         var30.jReturningVoid(var31);
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 37611513779834L ^ 73011963315512L;
      var10001 = 37611513779834L ^ 101942456860782L;
      var10001 = 37611513779834L ^ 22261120688461L;
      var10001 = 37611513779834L ^ 6731389154414L;
      var10001 = 37611513779834L ^ 93619682790401L;
      var10001 = 37611513779834L ^ 44107301119892L;
      var10001 = 37611513779834L ^ 5223893335674L;
      var10001 = 37611513779834L ^ 124632478268323L;
      var10001 = 37611513779834L ^ 58642528528449L;
      var10001 = 37611513779834L ^ 67298630600345L;
      var10001 = 37611513779834L ^ 81471411649435L;
      var10001 = 37611513779834L ^ 101123058518258L;
      var10001 = 37611513779834L ^ 110438881699691L;
      int var30 = Event.cReturningInt();
      int var198 = var30;
      if (var198 != 0) {
         boolean var138;
         label237: {
            boolean var139;
            label231: {
               MinecraftClient var31 = b;
               ClientPlayerEntity var199 = var31.player;
               label230:
               if (var199 != null) {
                  int var201 = var30;
                  MinecraftClient var200 = b;
                  MinecraftClient var132 = var200;
                  MinecraftClient var130 = var200;
                  if (var201 != 0) {
                     MinecraftClient var202 = var130;
                     MinecraftClient var131 = var202;
                     MinecraftClient var34 = var131;
                     ClientWorld var203 = var34.world;
                     if (var203 == null) {
                        break label230;
                     }

                     MinecraftClient var204 = b;
                     var132 = var204;
                  }

                  int var206 = var30;
                  MinecraftClient var205 = var132;
                  MinecraftClient var134 = var205;
                  MinecraftClient var133 = var205;
                  if (var206 != 0) {
                     MinecraftClient var37 = var133;
                     Screen var207 = var37.currentScreen;
                     if (var207 != null) {
                        break label230;
                     }

                     MinecraftClient var208 = b;
                     var134 = var208;
                  }

                  MinecraftClient var40 = var134;
                  boolean var10000 = var40.isWindowFocused();
                  int var210 = var30;
                  boolean var209 = var10000;
                  var138 = var209;
                  boolean var135 = var209;
                  if (var210 == 0) {
                     break label237;
                  }

                  boolean var211 = var135;
                  if (var211) {
                     MinecraftClient var42 = b;
                     ClientPlayerEntity var43 = var42.player;
                     var10000 = var43.isUsingItem();
                     int var213 = var30;
                     boolean var212 = var10000;
                     var139 = var212;
                     boolean var136 = var212;
                     if (var213 == 0) {
                        break label231;
                     }

                     boolean var214 = var136;
                     boolean var137 = var214;
                     boolean var215 = var137;
                     if (!var215) {
                        var139 = AutoHitCrystal.a;
                        break label231;
                     }
                  }
               }

               var138 = false;
               break label237;
            }

            boolean var216 = var139;
            if (var216) {
               int var218 = var30;
               AutoObbyCrystal var217 = this;
               AutoObbyCrystal var142 = var217;
               AutoObbyCrystal var140 = var217;
               if (var218 != 0) {
                  AutoObbyCrystal var219 = var140;
                  AutoObbyCrystal var141 = var219;
                  AutoObbyCrystalState var221 = AutoObbyCrystalState.IDLE;
                  AutoObbyCrystalState var220 = var141.S;
                  if (var220 != var221) {
                     Object[] var49 = new Object[]{"AutoHitCrystal enabled", 105907195761474L};
                     AutoObbyCrystal var48 = this;
                     var48.v(var49);
                  }

                  var142 = this;
               }

               Object[] var52 = new Object[]{34085700604131L};
               AutoObbyCrystal var51 = var142;
               var51.w(var52);
               R = false;
               return;
            }

            int var224 = var30;
            PlayerEntity var223 = this.Z;
            AutoObbyCrystal var222 = this;
            AutoObbyCrystal var147 = var222;
            PlayerEntity var148 = var223;
            AutoObbyCrystal var143 = var222;
            PlayerEntity var144 = var223;
            AutoObbyCrystal var150;
            PlayerEntity var151;
            if (var224 != 0) {
               PlayerEntity var226 = var144;
               AutoObbyCrystal var225 = var143;
               AutoObbyCrystal var149 = var225;
               AutoObbyCrystal var145 = var225;
               if (var226 != null) {
                  AutoObbyCrystal var227 = var145;
                  AutoObbyCrystal var146 = var227;
                  PlayerEntity var229 = this.Z;
                  AutoObbyCrystal var228 = var146;
                  var150 = var228;
                  var151 = var229;
               } else {
                  Object[] var55 = new Object[]{77260333461777L};
                  var151 = EntityUtil.aReturningPlayerEntity(var55);
                  var150 = var149;
               }
            } else {
               PlayerEntity var231 = var148;
               AutoObbyCrystal var230 = var147;
               var150 = var230;
               var151 = var231;
            }

            Object[] var57 = new Object[]{var151, 59416826869559L};
            AutoObbyCrystal var56 = var150;
            var56.lReturningVoid(var57);
            int var234 = var30;
            AutoObbyCrystalState var233 = AutoObbyCrystalState.IDLE;
            AutoObbyCrystalState var232 = this.S;
            AutoObbyCrystalState var157 = var232;
            AutoObbyCrystalState var158 = var233;
            AutoObbyCrystalState var152 = var232;
            AutoObbyCrystalState var153 = var233;
            if (var234 != 0) {
               AutoObbyCrystal var156;
               label202: {
                  AutoObbyCrystalState var236 = var153;
                  AutoObbyCrystalState var235 = var152;
                  if (var235 != var236) {
                     int var238 = var30;
                     AutoObbyCrystal var237 = this;
                     var156 = var237;
                     AutoObbyCrystal var154 = var237;
                     if (var238 == 0) {
                        break label202;
                     }

                     AutoObbyCrystal var239 = var154;
                     AutoObbyCrystal var155 = var239;
                     Object[] var61 = new Object[]{114538563759585L};
                     AutoObbyCrystal var60 = var155;
                     boolean var240 = var60.mReturningBoolean(var61);
                     if (!var240) {
                        Object[] var64 = new Object[]{"invalid target", 105907195761474L};
                        AutoObbyCrystal var63 = this;
                        var63.v(var64);
                     }
                  }

                  var156 = this;
               }

               var158 = AutoObbyCrystalState.IDLE;
               var157 = var156.S;
            }

            int var243 = var30;
            AutoObbyCrystalState var242 = var158;
            AutoObbyCrystalState var241 = var157;
            AutoObbyCrystalState var164 = var241;
            AutoObbyCrystalState var165 = var242;
            AutoObbyCrystalState var159 = var241;
            AutoObbyCrystalState var160 = var242;
            if (var243 != 0) {
               AutoObbyCrystal var163;
               label194: {
                  AutoObbyCrystalState var245 = var160;
                  AutoObbyCrystalState var244 = var159;
                  if (var244 != var245) {
                     int var247 = var30;
                     AutoObbyCrystal var246 = this;
                     var163 = var246;
                     AutoObbyCrystal var161 = var246;
                     if (var247 == 0) {
                        break label194;
                     }

                     AutoObbyCrystal var248 = var161;
                     AutoObbyCrystal var162 = var248;
                     Object[] var69 = new Object[]{11169413263854L};
                     AutoObbyCrystal var68 = var162;
                     boolean var249 = var68.nReturningBoolean(var69);
                     if (var249) {
                        Object[] var72 = new Object[]{"targetMoved d=" + this.aD, 105907195761474L};
                        AutoObbyCrystal var71 = this;
                        var71.v(var72);
                     }
                  }

                  var163 = this;
               }

               var165 = AutoObbyCrystalState.IDLE;
               var164 = var163.S;
            }

            int var252 = var30;
            AutoObbyCrystalState var251 = var165;
            AutoObbyCrystalState var250 = var164;
            AutoObbyCrystalState var176 = var250;
            AutoObbyCrystalState var177 = var251;
            AutoObbyCrystalState var166 = var250;
            AutoObbyCrystalState var167 = var251;
            if (var252 != 0) {
               AutoObbyCrystal var175;
               label186: {
                  AutoObbyCrystalState var254 = var167;
                  AutoObbyCrystalState var253 = var166;
                  if (var253 != var254) {
                     int var256 = var30;
                     AutoObbyCrystal var255 = this;
                     var175 = var255;
                     AutoObbyCrystal var168 = var255;
                     if (var256 == 0) {
                        break label186;
                     }

                     AutoObbyCrystal var257 = var168;
                     AutoObbyCrystal var169 = var257;
                     ElapsedTimer var310 = var169.V;
                     Object[] var77 = new Object[]{25704775286331L};
                     AutoObbyCrystal var76 = this;
                     float var329 = var76.dReturningFloat(var77);
                     Object[] var10004 = new Object[]{null, 139098136696340L};
                     var10004[0] = var329;
                     Object[] var79 = var10004;
                     ElapsedTimer var78 = var310;
                     boolean var258 = var78.aReturningBoolean(var79);
                     label183:
                     if (var258) {
                        AutoObbyCrystal var174;
                        int var260 = var30;
                        AutoObbyCrystal var259 = this;
                        var174 = var259;
                        AutoObbyCrystal var170 = var259;
                        label181:
                        if (var260 != 0) {
                           AutoObbyCrystal var261 = var170;
                           AutoObbyCrystal var171 = var261;
                           AutoObbyCrystalState var263 = AutoObbyCrystalState.BREAK_CRYSTAL;
                           AutoObbyCrystalState var262 = var171.S;
                           if (var262 == var263) {
                              int var265 = var30;
                              AutoObbyCrystal var264 = this;
                              var174 = var264;
                              AutoObbyCrystal var172 = var264;
                              if (var265 == 0) {
                                 break label181;
                              }

                              AutoObbyCrystal var266 = var172;
                              AutoObbyCrystal var173 = var266;
                              boolean var267 = var173.ag;
                              if (!var267) {
                                 this.ag = true;
                                 this.S = AutoObbyCrystalState.PLACE_CRYSTAL;
                                 var310 = this.V;
                                 Object[] var86 = new Object[]{42835128969216L};
                                 ElapsedTimer var85 = var310;
                                 var85.aReturningVoid(var86);
                                 int var268 = var30;
                                 if (var268 != 0) {
                                    break label183;
                                 }
                              }
                           }

                           AutoObbyCrystal var269 = this;
                           var174 = var269;
                        }

                        Object[] var90 = new Object[]{25704775286331L};
                        AutoObbyCrystal var89 = this;
                        Object[] var92 = new Object[]{"stageTimeout " + (int)var89.dReturningFloat(var90) + "ms", 105907195761474L};
                        AutoObbyCrystal var91 = var174;
                        var91.v(var92);
                     }
                  }

                  var175 = this;
               }

               var177 = AutoObbyCrystalState.IDLE;
               var176 = var175.S;
            }

            AutoObbyCrystal var196;
            label169: {
               label168: {
                  boolean var195;
                  label167: {
                     Object var194;
                     label239: {
                        int var272 = var30;
                        AutoObbyCrystalState var271 = var177;
                        AutoObbyCrystalState var270 = var176;
                        AutoObbyCrystalState var182 = var270;
                        AutoObbyCrystalState var183 = var271;
                        AutoObbyCrystalState var178 = var270;
                        AutoObbyCrystalState var179 = var271;
                        if (var272 != 0) {
                           AutoObbyCrystalState var274 = var179;
                           AutoObbyCrystalState var273 = var178;
                           if (var273 == var274) {
                              Object[] var95 = new Object[]{34085700604131L};
                              AutoObbyCrystal var94 = this;
                              var94.w(var95);
                              Object[] var97 = new Object[]{39764332126740L};
                              AutoObbyCrystal var96 = this;
                              var96.t(var97);
                              int var275 = var30;
                              if (var275 != 0) {
                                 break label168;
                              }
                           }

                           int var277 = var30;
                           AutoObbyCrystalState var276 = this.S;
                           var194 = var276;
                           AutoObbyCrystalState var180 = var276;
                           if (var277 == 0) {
                              break label239;
                           }

                           AutoObbyCrystalState var278 = var180;
                           AutoObbyCrystalState var181 = var278;
                           AutoObbyCrystalState var280 = AutoObbyCrystalState.BREAK_CRYSTAL;
                           AutoObbyCrystalState var279 = var181;
                           var182 = var279;
                           var183 = var280;
                        }

                        AutoObbyCrystalState var282 = var183;
                        AutoObbyCrystalState var281 = var182;
                        if (var281 == var282) {
                           ModeSetting var101 = this.f;
                           String var312 = (String)var101.aReturningObject();
                           String var103 = "Manual";
                           String var102 = var312;
                           boolean var313 = var102.equals(var103);
                           int var284 = var30;
                           boolean var283 = var313;
                           var195 = var283;
                           boolean var184 = var283;
                           if (var284 == 0) {
                              break label167;
                           }

                           boolean var285 = var184;
                           boolean var185 = var285;
                           boolean var286 = var185;
                           if (var286) {
                              int var288 = var30;
                              AutoObbyCrystal var287 = this;
                              var196 = var287;
                              AutoObbyCrystal var186 = var287;
                              if (var288 == 0) {
                                 break label169;
                              }

                              AutoObbyCrystal var289 = var186;
                              AutoObbyCrystal var187 = var289;
                              BlockPos var290 = var187.aa;
                              if (var290 == null) {
                                 break label168;
                              }

                              int var292 = var30;
                              AutoObbyCrystal var291 = this;
                              var196 = var291;
                              AutoObbyCrystal var188 = var291;
                              if (var292 == 0) {
                                 break label169;
                              }

                              AutoObbyCrystal var293 = var188;
                              AutoObbyCrystal var189 = var293;
                              BlockPos var109 = this.aa;
                              Object[] var111 = new Object[]{var109.up(), 133923909688968L};
                              AutoObbyCrystal var110 = var189;
                              boolean var294 = var110.gReturningBoolean(var111);
                              if (var294) {
                                 break label168;
                              }

                              int var296 = var30;
                              AutoObbyCrystal var295 = this;
                              var196 = var295;
                              AutoObbyCrystal var190 = var295;
                              if (var296 == 0) {
                                 break label169;
                              }

                              AutoObbyCrystal var297 = var190;
                              AutoObbyCrystal var191 = var297;
                              ElapsedTimer var314 = var191.U;
                              Object[] var115 = new Object[]{this.m, 130913203968635L};
                              ElapsedTimer var114 = var314;
                              boolean var298 = var114.bReturningBoolean(var115);
                              if (!var298) {
                                 break label168;
                              }

                              this.S = AutoObbyCrystalState.PLACE_CRYSTAL;
                              ElapsedTimer var315 = this.V;
                              Object[] var118 = new Object[]{42835128969216L};
                              ElapsedTimer var117 = var315;
                              var117.aReturningVoid(var118);
                              int var299 = var30;
                              if (var299 != 0) {
                                 break label168;
                              }
                           }
                        }

                        int var301 = var30;
                        AutoObbyCrystal var300 = this;
                        var196 = var300;
                        AutoObbyCrystal var192 = var300;
                        if (var301 == 0) {
                           break label169;
                        }

                        AutoObbyCrystal var302 = var192;
                        AutoObbyCrystal var193 = var302;
                        BooleanSetting var121 = var193.g;
                        Object var303 = var121.aReturningObject();
                        var194 = var303;
                     }

                     Boolean var123 = (Boolean)var194;
                     var195 = var123;
                  }

                  boolean var304 = var195;
                  if (!var304) {
                     RotationManager var316 = Prestige.o;
                     Object[] var125 = new Object[0];
                     RotationManager var124 = var316;
                     boolean var305 = var124.fReturningBoolean(var125);
                     if (var305) {
                        return;
                     }

                     Object[] var129 = new Object[]{91737791081945L};
                     AutoObbyCrystal var128 = this;
                     var128.mReturningVoid(var129);
                  }
               }

               var196 = this;
            }

            AutoObbyCrystalState var307 = AutoObbyCrystalState.IDLE;
            AutoObbyCrystalState var306 = var196.S;
            boolean var197;
            if (var306 != var307) {
               boolean var308 = true;
               var197 = var308;
            } else {
               var197 = false;
            }

            R = var197;
            return;
         }

         R = var138;
      }
   }

   private void lReturningVoid(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 76073374701881L ^ var3;
      long var5 = var3 ^ 4981985262691L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var11 = b;
      ClientWorld var12 = var11.world;
      long var8 = var12.getTime();
      int var7 = var10000;
      int var37 = var7;
      Entity var36 = var2;
      Entity var32 = var36;
      Entity var31 = var36;
      if (var37 == 0) {
         Entity var38 = var31;
         if (var38 == null) {
            this.al = null;
            this.am = null;
            this.an = Vec3d.ZERO;
            this.ao = var8;
            return;
         }

         var32 = var2;
      }

      Object[] var15 = new Object[]{var32, var5};
      Vec3d var10 = RaycastUtil.aReturningVec3d(var15);
      int var39 = var7;
      if (var39 == 0) {
         AutoObbyCrystal var35;
         label31: {
            Entity var41 = this.al;
            Entity var40 = var2;
            if (var40 == var41) {
               int var43 = var7;
               AutoObbyCrystal var42 = this;
               var35 = var42;
               AutoObbyCrystal var33 = var42;
               if (var43 != 0) {
                  break label31;
               }

               AutoObbyCrystal var44 = var33;
               AutoObbyCrystal var34 = var44;
               Vec3d var45 = var34.am;
               if (var45 != null) {
                  long var49 = var8 - this.ao;
                  short var10001 = 6524;
                  long var10002 = 8280080268599794889L ^ var3;
                  long var52;
                  int var46 = (var52 = var49 - 1L) == 0L ? 0 : (var52 < 0L ? -1 : 1);
                  if (!((var46) != 0)) {
                     double var22 = 0.5;
                     Vec3d var21 = this.an;
                     Vec3d var50 = var21.multiply(var22);
                     Vec3d var25 = this.am;
                     Vec3d var24 = var10;
                     Vec3d var51 = var24.subtract(var25);
                     double var27 = 0.5;
                     Vec3d var26 = var51;
                     Vec3d var30 = var26.multiply(var27);
                     Vec3d var29 = var50;
                     this.an = var29.add(var30);
                     this.am = var10;
                     this.ao = var8;
                     return;
                  }
               }
            }

            this.al = var2;
            this.am = var10;
            this.ao = var8;
            AutoObbyCrystal var47 = this;
            var35 = var47;
         }

         var35.an = Vec3d.ZERO;
      }
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 76073374701881L ^ var2;
      int var4 = Event.bReturningInt();
      int var12 = var4;
      PlayerEntity var11 = this.Z;
      Object var8 = var11;
      PlayerEntity var5 = var11;
      if (var12 == 0) {
         PlayerEntity var13 = var5;
         if (var13 == null) {
            return Vec3d.ZERO;
         }

         int var15 = var4;
         AutoObbyCrystal var14 = this;
         AutoObbyCrystal var9 = var14;
         AutoObbyCrystal var6 = var14;
         if (var15 != 0) {
            return var9.an;
         }

         AutoObbyCrystal var16 = var6;
         AutoObbyCrystal var7 = var16;
         Entity var17 = var7.al;
         var8 = var17;
      }

      PlayerEntity var19 = this.Z;
      Object var18 = var8;
      if (var18 == var19) {
         AutoObbyCrystal var20 = this;
         AutoObbyCrystal var22 = var20;
         return var22.an;
      } else {
         return Vec3d.ZERO;
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 76344940504111L;
      int var10000 = Event.bReturningInt();
      Object[] var9 = new Object[]{var4};
      AutoObbyCrystal var8 = this;
      Vec3d var7 = var8.aReturningVec3d(var9);
      int var6 = var10000;
      Vec3d var10 = var7;
      Vec3d var11 = var7;
      double var22 = var10.x * var11.x;
      Vec3d var12 = var7;
      Vec3d var13 = var7;
      double var24;
      var10000 = (var24 = var22 + var12.z * var13.z - 4.0E-4) == 0.0 ? 0 : (var24 < 0.0 ? -1 : 1);
      int var18 = var6;
      int var17 = var10000;
      int var15 = var17;
      int var14 = var17;
      if (var18 == 0) {
         int var19 = var14;
         if (var19 <= 0) {
            return false;
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private double aReturningDouble(Object[] var1) {
      Vec3d var8 = (Vec3d)var1[0];
      Vec3d var3 = (Vec3d)var1[1];
      BlockPos var2 = (BlockPos)var1[2];
      SourceSupport.discard(var1[3]);
      long var6 = (Long)var1[4];
      var6 = 76073374701881L ^ var6;
      long var9 = var6 ^ 62488603745843L;
      ExplosionDamageUtil var10000 = Prestige.f;
      Object[] var12 = new Object[]{this.Z, var8, var3, var2, var9};
      ExplosionDamageUtil var11 = var10000;
      return var11.dReturningDouble(var12);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 135863560898218L;
      long var6 = var2 ^ 138426539507609L;
      long var8 = var2 ^ 101302999366434L;
      long var10 = var2 ^ 77379818547405L;
      long var12 = var2 ^ 92778124915630L;
      long var14 = var2 ^ 3387076146694L;
      long var16 = var2 ^ 25567479746596L;
      long var18 = var2 ^ 101783648619701L;
      int var20 = Event.bReturningInt();
      BooleanSetting var23 = this.g;
      Boolean var24 = (Boolean)var23.aReturningObject();
      boolean var110 = var24;
      if (!var110) {
         return null;
      }

      int var112 = var20;
      MinecraftClient var111 = b;
      MinecraftClient var86 = var111;
      MinecraftClient var85 = var111;
      if (var112 == 0) {
         MinecraftClient var26 = var85;
         ClientPlayerEntity var113 = var26.player;
         if (var113 == null) {
            return null;
         }

         MinecraftClient var114 = b;
         var86 = var114;
      }

      int var116 = var20;
      MinecraftClient var115 = var86;
      MinecraftClient var88 = var115;
      MinecraftClient var87 = var115;
      if (var116 == 0) {
         MinecraftClient var29 = var87;
         ClientWorld var117 = var29.world;
         if (var117 == null) {
            return null;
         }

         MinecraftClient var118 = b;
         var88 = var118;
      }

      int var120 = var20;
      MinecraftClient var119 = var88;
      MinecraftClient var90 = var119;
      MinecraftClient var89 = var119;
      if (var120 == 0) {
         MinecraftClient var32 = var89;
         Screen var121 = var32.currentScreen;
         if (var121 != null) {
            return null;
         }

         MinecraftClient var122 = b;
         var90 = var122;
      }

      MinecraftClient var35 = var90;
      int var10000 = (((var35.isWindowFocused()) ? 1 : 0));
      int var124 = var20;
      boolean var123 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var92 = var123;
      boolean var91 = var123;
      if (var124 == 0) {
         boolean var125 = var91;
         if (!var125) {
            return null;
         }

         MinecraftClient var37 = b;
         ClientPlayerEntity var38 = var37.player;
         boolean var126 = var38.isUsingItem();
         var92 = var126;
      }

      boolean var127 = var92;
      if (!var127) {
         int var129 = var20;
         AutoObbyCrystal var128 = this;
         AutoObbyCrystal var94 = var128;
         AutoObbyCrystal var93 = var128;
         if (var129 == 0) {
            AutoObbyCrystalState var131 = AutoObbyCrystalState.IDLE;
            AutoObbyCrystalState var130 = var93.S;
            if (var130 == var131) {
               return null;
            }

            AutoObbyCrystal var132 = this;
            var94 = var132;
         }

         int var134 = var20;
         AutoObbyCrystal var133 = var94;
         AutoObbyCrystal var96 = var133;
         AutoObbyCrystal var95 = var133;
         if (var134 == 0) {
            BlockPos var135 = var95.aa;
            if (var135 == null) {
               return null;
            }

            AutoObbyCrystal var136 = this;
            var96 = var136;
         }

         PlayerEntity var137 = var96.Z;
         if (var137 != null) {
            int var139 = var20;
            boolean var138 = AutoHitCrystal.a;
            boolean var98 = var138;
            boolean var97 = var138;
            if (var139 == 0) {
               boolean var140 = var97;
               if (var140) {
                  return null;
               }

               RotationManager var164 = Prestige.o;
               Object[] var49 = new Object[0];
               RotationManager var48 = var164;
               var98 = var48.fReturningBoolean(var49);
            }

            AutoObbyCrystal var102;
            label140: {
               int var142 = var20;
               boolean var141 = var98;
               boolean var101 = var141;
               boolean var99 = var141;
               if (var142 == 0) {
                  boolean var143 = var99;
                  if (var143) {
                     return null;
                  }

                  int var145 = var20;
                  AutoObbyCrystal var144 = this;
                  var102 = var144;
                  AutoObbyCrystal var100 = var144;
                  if (var145 != 0) {
                     break label140;
                  }

                  Object[] var53 = new Object[]{var4};
                  AutoObbyCrystal var52 = var100;
                  boolean var146 = var52.eReturningBoolean(var53);
                  var101 = var146;
               }

               boolean var147 = var101;
               if (!var147) {
                  return null;
               }

               var102 = this;
            }

            Object[] var57 = new Object[]{var14};
            AutoObbyCrystal var56 = var102;
            Vec3d var21 = var56.bReturningVec3d(var57);
            int var149 = var20;
            AutoObbyCrystal var148 = this;
            AutoObbyCrystal var104 = var148;
            AutoObbyCrystal var103 = var148;
            if (var149 == 0) {
               Object[] var59 = new Object[]{var21, var16};
               AutoObbyCrystal var58 = var103;
               boolean var150 = var58.aReturningBoolean(var59);
               if (!var150) {
                  Vec3d var152 = var21;
                  if (var152 == null) {
                     return null;
                  }

                  RotationManager var165 = Prestige.o;
                  Object[] var66 = new Object[]{var21, var10};
                  RotationManager var65 = var165;
                  Rotation var22 = var65.aReturningdx_C0210(var66);
                  Object[] var67 = new Object[]{var22, var21, var18};
                  var22 = RotationUtil.dReturningdx_C0210(var67);
                  Object[] var69 = new Object[0];
                  Rotation var68 = var22;
                  float var166 = var68.aReturningFloat(var69);
                  MinecraftClient var70 = b;
                  ClientPlayerEntity var71 = var70.player;
                  float var167 = var166 - var71.getYaw();
                  Object[] var10003 = new Object[]{null, var6};
                  var10003[0] = var167;
                  Object[] var72 = var10003;
                  float var73 = RotationUtil.bReturningFloat(var72);
                  float var168 = Math.abs(var73);
                  FloatSetting var74 = this.s;
                  Float var75 = (Float)var74.aReturningObject();
                  float var172;
                  var10000 = (var172 = var168 - var75) == 0.0F ? 0 : (var172 < 0.0F ? -1 : 1);
                  int var154 = var20;
                  int var153 = var10000;
                  int var107 = var153;
                  int var105 = var153;
                  if (var154 == 0) {
                     int var155 = var105;
                     if (var155 > 0) {
                        short var170 = 29536;
                        long var171 = 4230940713908424410L ^ var2;
                        Object[] var78 = new Object[]{"silentAimFov", var8};
                        AutoObbyCrystal var77 = this;
                        var77.v(var78);
                        return null;
                     }

                     int var157 = var20;
                     Rotation var156 = var22;
                     Rotation var108 = var156;
                     Rotation var106 = var156;
                     if (var157 != 0) {
                        return var108;
                     }

                     Object[] var81 = new Object[0];
                     Rotation var80 = var106;
                     byte var158 = ((byte)((var80.aReturningBoolean(var81)) ? 1 : 0));
                     var107 = var158;
                  }

                  int var159 = var107;
                  if (var159 == 0) {
                     Object[] var84 = new Object[]{var22, var12};
                     AutoObbyCrystal var83 = this;
                     var83.nReturningVoid(var84);
                     AutoObbyCrystalState var161 = AutoObbyCrystalState.IDLE;
                     AutoObbyCrystalState var160 = this.S;
                     Rotation var109;
                     if (var160 == var161) {
                        Object var162 = null;
                        var109 = (Rotation)var162;
                     } else {
                        var109 = var22;
                     }

                     return var109;
                  }

                  return var22;
               }

               AutoObbyCrystal var151 = this;
               var104 = var151;
            }

            short var10001 = 24463;
            long var10002 = 4993656837811855935L ^ var2;
            Object[] var63 = new Object[]{"unreachable", var8};
            AutoObbyCrystal var62 = var104;
            var62.v(var63);
            return null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 89878008240682L;
      long var6 = var2 ^ 129798622062498L;
      long var8 = var2 ^ 54651178634529L;
      long var10 = var2 ^ 113215088471186L;
      long var12 = var2 ^ 138877744820014L;
      long var14 = var2 ^ 45337489205894L;
      long var16 = var2 ^ 67549316533412L;
      int var18 = Event.cReturningInt();
      int var45 = var18;
      AutoObbyCrystal var44 = this;
      AutoObbyCrystal var39 = var44;
      AutoObbyCrystal var38 = var44;
      if (var45 != 0) {
         Object[] var22 = new Object[]{var4};
         AutoObbyCrystal var21 = var38;
         boolean var46 = var21.eReturningBoolean(var22);
         if (!var46) {
            return;
         }

         var39 = this;
      }

      Object[] var26 = new Object[]{var14};
      AutoObbyCrystal var25 = var39;
      Vec3d var19 = var25.bReturningVec3d(var26);
      int var48 = var18;
      AutoObbyCrystal var47 = this;
      AutoObbyCrystal var41 = var47;
      AutoObbyCrystal var40 = var47;
      if (var48 != 0) {
         Object[] var28 = new Object[]{var19, var16};
         AutoObbyCrystal var27 = var40;
         boolean var49 = var27.aReturningBoolean(var28);
         if (!var49) {
            int var52 = var18;
            Vec3d var51 = var19;
            Vec3d var43 = var51;
            Vec3d var42 = var51;
            if (var52 != 0) {
               Vec3d var53 = var42;
               if (var53 == null) {
                  return;
               }

               var43 = var19;
            }

            Object[] var34 = new Object[]{var43, var8};
            Rotation var20 = RotationUtil.aReturningdx_C0210(var34);
            Object[] var35 = new Object[]{var20, var10};
            RotationUtil.aReturningVoid(var35);
            Object[] var37 = new Object[]{var20, var12};
            AutoObbyCrystal var36 = this;
            var36.nReturningVoid(var37);
            return;
         }

         AutoObbyCrystal var50 = this;
         var41 = var50;
      }

      short var10001 = 7124;
      long var10002 = 3799482349637876456L ^ var2;
      Object[] var32 = new Object[]{"unreachable", var6};
      AutoObbyCrystal var31 = var41;
      var31.v(var32);
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 129474468703624L;
      int var6 = Event.cReturningInt();
      int var62 = var6;
      byte var61 = ((byte)((this.X) ? 1 : 0));
      int var48 = var61;
      byte var33 = var61;
      if (var62 != 0) {
         byte var63 = var33;
         if (var63 == 0) {
            AutoObbyCrystal var44;
            label114: {
               int var66 = var6;
               AutoObbyCrystalState var65 = AutoObbyCrystalState.BREAK_CRYSTAL;
               AutoObbyCrystalState var64 = this.S;
               AutoObbyCrystalState var42 = var64;
               AutoObbyCrystalState var43 = var65;
               AutoObbyCrystalState var34 = var64;
               AutoObbyCrystalState var35 = var65;
               if (var66 != 0) {
                  AutoObbyCrystal var40;
                  label72: {
                     AutoObbyCrystalState var68 = var35;
                     AutoObbyCrystalState var67 = var34;
                     AutoObbyCrystalState var36 = var67;
                     AutoObbyCrystalState var37 = var68;
                     AutoObbyCrystalState var70 = var37;
                     AutoObbyCrystalState var69 = var36;
                     if (var69 == var70) {
                        int var72 = var6;
                        AutoObbyCrystal var71 = this;
                        var40 = var71;
                        AutoObbyCrystal var38 = var71;
                        if (var72 == 0) {
                           break label72;
                        }

                        AutoObbyCrystal var73 = var38;
                        AutoObbyCrystal var39 = var73;
                        ModeSetting var11 = var39.f;
                        String var113 = (String)var11.aReturningObject();
                        short var116 = 27518;
                        long var117 = 3697053888215615823L ^ var2;
                        String var13 = "Manual";
                        String var12 = var113;
                        boolean var74 = var12.equals(var13);
                        if (var74) {
                           return false;
                        }
                     }

                     var40 = this;
                  }

                  int var76 = var6;
                  AutoObbyCrystal var75 = var40;
                  var44 = var75;
                  AutoObbyCrystal var41 = var75;
                  if (var76 == 0) {
                     break label114;
                  }

                  AutoObbyCrystalState var78 = AutoObbyCrystalState.IDLE;
                  AutoObbyCrystalState var77 = var41.S;
                  var42 = var77;
                  var43 = var78;
               }

               AutoObbyCrystalState var80 = var43;
               AutoObbyCrystalState var79 = var42;
               if (var79 == var80) {
                  return false;
               }

               var44 = this;
            }

            ElapsedTimer var114 = var44.W;
            Object[] var18 = new Object[]{this.n, var4};
            ElapsedTimer var17 = var114;
            boolean var115 = var17.bReturningBoolean(var18);
            int var82 = var6;
            boolean var81 = var115;
            boolean var46 = var81;
            boolean var45 = var81;
            if (var82 == 0) {
               return var46;
            }

            boolean var83 = var45;
            if (var83) {
               return true;
            }

            return false;
         }

         AutoObbyCrystalState var20 = this.S;
         var48 = var20.ordinal();
      }

      int var86 = var6;
      int var85 = var48;
      int var50 = var85;
      int var49 = var85;
      if (var86 != 0) {
         int var87 = var49;
         switch (var87) {
            case 1:
               var50 = 1;
               break;
            case 2:
               int var90 = var6;
               byte var89 = ((byte)((this.Y) ? 1 : 0));
               byte var54 = var89;
               byte var51 = var89;
               if (var90 != 0) {
                  byte var91 = var51;
                  label101:
                  if (var91 == 0) {
                     ElapsedTimer var111 = this.T;
                     Object[] var24 = new Object[]{this.l, var4};
                     ElapsedTimer var23 = var111;
                     byte var112 = ((byte)((var23.bReturningBoolean(var24)) ? 1 : 0));
                     int var93 = var6;
                     byte var92 = var112;
                     byte var55 = var92;
                     byte var52 = var92;
                     if (var93 != 0) {
                        byte var94 = var52;
                        byte var53 = var94;
                        byte var95 = var53;
                        if (var95 != 0) {
                           break label101;
                        }

                        var55 = 0;
                     }

                     return dev.prestige.recovery.SourceSupport.asBoolean(var55);
                  }

                  var54 = 1;
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var54);
            case 3:
               ModeSetting var27 = this.f;
               String var10000 = (String)var27.aReturningObject();
               short var10001 = 29109;
               long var10002 = 8218088707516175251L ^ var2;
               String var29 = "Manual";
               String var28 = var10000;
               byte var108 = ((byte)((var28.equals(var29)) ? 1 : 0));
               int var99 = var6;
               byte var98 = var108;
               byte var59 = var98;
               byte var56 = var98;
               if (var99 != 0) {
                  byte var100 = var56;
                  if (var100 == 0) {
                     ElapsedTimer var109 = this.U;
                     Object[] var32 = new Object[]{this.m, var4};
                     ElapsedTimer var31 = var109;
                     boolean var110 = var31.bReturningBoolean(var32);
                     int var102 = var6;
                     boolean var101 = var110;
                     boolean var119 = var101;
                     boolean var57 = var101;
                     if (var102 == 0) {
                        return var119;
                     }

                     boolean var103 = var57;
                     boolean var58 = var103;
                     boolean var104 = var58;
                     if (var104) {
                        return true;
                     }
                  }

                  var59 = 0;
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var59);
            default:
               return false;
         }
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var50);
   }

   private Vec3d bReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 18649762382496L;
      long var6 = var2 ^ 79767416055659L;
      long var8 = var2 ^ 76703666444465L;
      int var10 = Event.cReturningInt();
      int var25 = var10;
      AutoObbyCrystal var24 = this;
      AutoObbyCrystal var22 = var24;
      AutoObbyCrystal var21 = var24;
      if (var25 != 0) {
         AutoObbyCrystalState var12 = var21.S;
         int var26 = var12.ordinal();
         switch (var26) {
            case 1:
               AutoObbyCrystal var27 = this;
               var22 = var27;
               break;
            case 2:
               Object[] var15 = new Object[]{this.aa, var6};
               return InteractionUtil.aReturningVec3d(var15);
            case 3:
               Object[] var17 = new Object[]{var4};
               AutoObbyCrystal var16 = this;
               EndCrystalEntity var11 = var16.aReturningEndCrystalEntity(var17);
               EndCrystalEntity var28 = var11;
               Vec3d var23;
               if (var28 == null) {
                  Object var29 = null;
                  var23 = (Vec3d)var29;
               } else {
                  Object[] var20 = new Object[]{var11, var8};
                  AutoObbyCrystal var19 = this;
                  var23 = var19.cReturningVec3d(var20);
               }

               return var23;
            default:
               return null;
         }
      }

      return var22.ad;
   }

   private boolean aReturningBoolean(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 76073374701881L ^ var3;
      int var5 = Event.bReturningInt();
      int var32 = var5;
      AutoObbyCrystal var31 = this;
      AutoObbyCrystal var21 = var31;
      AutoObbyCrystal var20 = var31;
      if (var32 == 0) {
         AutoObbyCrystalState var34 = AutoObbyCrystalState.BREAK_CRYSTAL;
         AutoObbyCrystalState var33 = var20.S;
         if (var33 != var34) {
            int var37 = var5;
            Vec3d var36 = var2;
            Vec3d var23 = var36;
            Vec3d var22 = var36;
            if (var37 == 0) {
               Vec3d var38 = var22;
               if (var38 == null) {
                  return false;
               }

               MinecraftClient var10 = b;
               ClientPlayerEntity var11 = var10.player;
               var23 = var11.getEyePos();
            }

            Vec3d var13 = var2;
            Vec3d var12 = var23;
            double var53;
            int var51 = (var53 = var12.distanceTo(var13) - 4.4) == 0.0 ? 0 : (var53 < 0.0 ? -1 : 1);
            int var40 = var5;
            int var39 = var51;
            int var29 = var39;
            int var24 = var39;
            if (var40 == 0) {
               int var41 = var24;
               if (var41 <= 0) {
                  int var43 = var5;
                  Vec3d var42 = this.ak;
                  Vec3d var27 = var42;
                  Vec3d var25 = var42;
                  if (var43 == 0) {
                     Vec3d var44 = var25;
                     Vec3d var26 = var44;
                     Vec3d var45 = var26;
                     if (var45 == null) {
                        return false;
                     }

                     Vec3d var46 = this.ak;
                     var27 = var46;
                  }

                  Vec3d var19 = var2;
                  Vec3d var18 = var27;
                  double var54;
                  int var52 = (var54 = var18.distanceTo(var19) - 4.4) == 0.0 ? 0 : (var54 < 0.0 ? -1 : 1);
                  int var48 = var5;
                  int var47 = var52;
                  var29 = var47;
                  int var28 = var47;
                  if (var48 != 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var29);
                  }

                  int var49 = var28;
                  if (var49 <= 0) {
                     return false;
                  }
               }

               var29 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var29);
         }

         AutoObbyCrystal var35 = this;
         var21 = var35;
      }

      return var21.ah;
   }

   private void nReturningVoid(Object[] var1) {
      Rotation var2;
      long var9;
      label23: {
         long var7;
         int var11;
         label22: {
            var2 = (Rotation)var1[0];
            long var3 = (Long)var1[1];
            var3 = 76073374701881L ^ var3;
            long var5 = var3 ^ 83181521158664L;
            var7 = var3 ^ 198337520219L;
            var9 = var3 ^ 103410797078246L;
            var11 = Event.cReturningInt();
            int var25 = var11;
            AutoObbyCrystal var24 = this;
            AutoObbyCrystal var23 = var24;
            AutoObbyCrystal var22 = var24;
            if (var25 != 0) {
               AutoObbyCrystalState var12 = var22.S;
               int var26 = var12.ordinal();
               switch (var26) {
                  case 1:
                     AutoObbyCrystal var27 = this;
                     var23 = var27;
                     break;
                  case 2:
                     break label22;
                  case 3:
                     break label23;
                  default:
                     return;
               }
            }

            Object[] var16 = new Object[]{var2, var5};
            AutoObbyCrystal var15 = var23;
            var15.o(var16);
            int var28 = var11;
            if (var28 != 0) {
               return;
            }
         }

         Object[] var18 = new Object[]{var2, var7};
         AutoObbyCrystal var17 = this;
         var17.p(var18);
         int var29 = var11;
         if (var29 != 0) {
            return;
         }
      }

      Object[] var21 = new Object[]{var2, var9};
      AutoObbyCrystal var20 = this;
      var20.q(var21);
   }

   private Vec3d cReturningVec3d(Object[] var1) {
      EndCrystalEntity var2 = (EndCrystalEntity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 76073374701881L ^ var3;
      int var59 = Event.cReturningInt();
      MinecraftClient var10 = b;
      ClientPlayerEntity var11 = var10.player;
      Vec3d var6 = var11.getEyePos();
      int var5 = var59;
      EndCrystalEntity var12 = var2;
      Box var7 = var12.getBoundingBox();
      Vec3d var13 = var6;
      Box var14 = var7;
      Box var15 = var7;
      double var20 = var15.maxX;
      double var18 = var14.minX;
      double var16 = var13.x;
      double var10002 = MathHelper.clamp(var16, var18, var20);
      Vec3d var22 = var6;
      Box var23 = var7;
      Box var24 = var7;
      double var29 = var24.maxY;
      double var27 = var23.minY;
      double var25 = var22.y;
      double var10003 = MathHelper.clamp(var25, var27, var29);
      Vec3d var31 = var6;
      Box var32 = var7;
      Box var33 = var7;
      double var38 = var33.maxZ;
      double var36 = var32.minZ;
      double var34 = var31.z;
      Vec3d var8 = new Vec3d(var10002, var10003, MathHelper.clamp(var34, var36, var38));
      Box var40 = var7;
      Vec3d var60 = var40.getCenter();
      Vec3d var42 = var8;
      Vec3d var41 = var60;
      Vec3d var9 = var41.subtract(var42);
      int var55 = var5;
      Vec3d var54 = var9;
      Vec3d var52 = var54;
      Vec3d var51 = var54;
      Vec3d var53;
      if (var55 != 0) {
         Vec3d var43 = var51;
         double var61;
         int var56 = (var61 = var43.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var61 < 0.0 ? -1 : 1);
         if (var56 > 0) {
            Vec3d var45 = var9;
            Vec3d var10001 = var45.normalize();
            double var47 = 0.15;
            Vec3d var46 = var10001;
            Vec3d var50 = var46.multiply(var47);
            Vec3d var49 = var8;
            Vec3d var57 = var49.add(var50);
            var53 = var57;
         } else {
            var53 = var8;
         }
      } else {
         Vec3d var58 = var52;
         var53 = var58;
      }

      return var53;
   }

   private boolean fReturningBoolean(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 76073374701881L ^ var2;
      long var5 = var2 ^ 137190347013927L;
      long var7 = var2 ^ 131054473416744L;
      long var9 = var2 ^ 30542180307537L;
      int var11 = Event.bReturningInt();
      Object[] var12 = new Object[]{var7};
      int var10000 = InventoryUtil.aReturningInt(var12);
      int var29 = var11;
      int var28 = var10000;
      int var25 = var28;
      int var24 = var28;
      if (var29 == 0) {
         int var31 = var4;
         int var30 = var24;
         if (var30 == var31) {
            return true;
         }

         Object[] var10003 = new Object[]{null, var9};
         var10003[0] = var4;
         Object[] var15 = var10003;
         InventoryUtil.aReturningVoid(var15);
         BooleanSetting var16 = this.r;
         Boolean var17 = (Boolean)var16.aReturningObject();
         var25 = ((((java.lang.Boolean)(var17)).booleanValue() ? 1 : 0));
      }

      int var33 = var11;
      int var32 = var25;
      int var27 = var32;
      int var26 = var32;
      if (var33 == 0) {
         int var34 = var26;
         if (var34 != 0) {
            return true;
         }

         RotationManager var36 = Prestige.o;
         Object[] var21 = new Object[]{true};
         RotationManager var20 = var36;
         var20.fReturningVoid(var21);
         ElapsedTimer var37 = this.V;
         Object[] var23 = new Object[]{var5};
         ElapsedTimer var22 = var37;
         var22.aReturningVoid(var23);
         var27 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var27);
   }

   private void o(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 76073374701881L ^ var2;
      long var5 = var2 ^ 1223145884686L;
      long var7 = var2 ^ 5789465932230L;
      long var9 = var2 ^ 27179525576518L;
      long var11 = var2 ^ 74650078038660L;
      long var13 = var2 ^ 124468835088823L;
      long var15 = var2 ^ 66751787227096L;
      long var17 = var2 ^ 128674942571072L;
      long var19 = var2 ^ 23459299449581L;
      long var21 = var2 ^ 102506037533679L;
      long var23 = var2 ^ 46149310585786L;
      long var25 = var2 ^ 63150542004752L;
      int var27 = Event.bReturningInt();
      int var101 = var27;
      AutoObbyCrystal var100 = this;
      AutoObbyCrystal var82 = var100;
      AutoObbyCrystal var79 = var100;
      if (var101 == 0) {
         Object[] var31 = new Object[]{var79.aa, Blocks.OBSIDIAN, var13};
         boolean var102 = BlockUtil.bReturningBoolean(var31);
         label90:
         if (!var102) {
            AutoObbyCrystal var87;
            label104: {
               Object[] var33 = new Object[]{this.aa, Blocks.BEDROCK, var13};
               byte var10000 = ((byte)((BlockUtil.bReturningBoolean(var33)) ? 1 : 0));
               int var104 = var27;
               boolean var103 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
               boolean var84 = var103;
               boolean var80 = var103;
               if (var104 == 0) {
                  boolean var105 = var80;
                  boolean var81 = var105;
                  boolean var106 = var81;
                  if (var106) {
                     break label90;
                  }

                  int var109 = var27;
                  AutoObbyCrystal var108 = this;
                  var87 = var108;
                  AutoObbyCrystal var83 = var108;
                  if (var109 != 0) {
                     break label104;
                  }

                  Object[] var39 = new Object[]{var83.aa, var9};
                  boolean var110 = BlockUtil.eReturningBoolean(var39);
                  var84 = var110;
               }

               boolean var111 = var84;
               if (!var111) {
                  int var113 = var27;
                  AutoObbyCrystal var112 = this;
                  var87 = var112;
                  AutoObbyCrystal var85 = var112;
                  if (var113 != 0) {
                     break label104;
                  }

                  AutoObbyCrystal var114 = var85;
                  AutoObbyCrystal var86 = var114;
                  BlockPos var10001 = this.aa;
                  Object[] var10005 = new Object[]{null, null, var21};
                  var10005[1] = 1;
                  var10005[0] = var10001;
                  Object[] var43 = var10005;
                  AutoObbyCrystal var42 = var86;
                  boolean var115 = var42.hReturningVoid(var43);
                  if (!var115) {
                     Object[] var48 = new Object[]{Items.OBSIDIAN, var17};
                     Integer var28 = InventoryUtil.aReturningBoxedInteger(var48);
                     int var117 = var27;
                     if (var117 == 0) {
                        Integer var118 = var28;
                        if (var118 != null) {
                           Object[] var53 = new Object[]{var4, var23};
                           HitResult var29 = RotationUtil.aReturningHitResult(var53);
                           int var120 = var27;
                           HitResult var119 = var29;
                           HitResult var89 = var119;
                           HitResult var88 = var119;
                           if (var120 == 0) {
                              boolean var121 = var88 instanceof BlockHitResult;
                              if (!var121) {
                                 return;
                              }

                              HitResult var122 = var29;
                              var89 = var122;
                           }

                           BlockHitResult var30 = (BlockHitResult)var89;
                           BlockHitResult var56 = var30;
                           BlockPos var140 = var56.getBlockPos();
                           BlockPos var58 = this.ab;
                           BlockPos var57 = var140;
                           var10000 = ((byte)((var57.equals(var58)) ? 1 : 0));
                           int var124 = var27;
                           byte var123 = var10000;
                           byte var91 = var123;
                           byte var90 = var123;
                           if (var124 == 0) {
                              byte var125 = var90;
                              if (var125 == 0) {
                                 return;
                              }

                              BlockHitResult var60 = var30;
                              BlockPos var142 = var60.getBlockPos();
                              BlockHitResult var61 = var30;
                              Direction var63 = var61.getSide();
                              BlockPos var62 = var142;
                              BlockPos var143 = var62.offset(var63);
                              BlockPos var65 = this.aa;
                              BlockPos var64 = var143;
                              byte var126 = ((byte)((var64.equals(var65)) ? 1 : 0));
                              var91 = var126;
                           }

                           int var128 = var27;
                           byte var127 = var91;
                           int var93 = var127;
                           byte var92 = var127;
                           if (var128 == 0) {
                              byte var129 = var92;
                              if (var129 == 0) {
                                 return;
                              }

                              var93 = this.af;
                           }

                           AutoObbyCrystal var98;
                           int var99;
                           label107: {
                              int var131 = var27;
                              int var130 = var93;
                              int var97 = var130;
                              int var94 = var130;
                              if (var131 == 0) {
                                 // int var132 = var94;
                                 if (var132 == var133) {
                                    Object[] var69 = new Object[]{this, var19};
                                    this.af = SlotReservation.aReturningInt(var69);
                                 }

                                 Integer var71 = var28;
                                 int var147 = var71;
                                 int var136 = var27;
                                 int var135 = var147;
                                 AutoObbyCrystal var134 = this;
                                 var98 = var134;
                                 var99 = var135;
                                 AutoObbyCrystal var95 = var134;
                                 int var96 = var135;
                                 if (var136 != 0) {
                                    break label107;
                                 }

                                 Object[] var10004 = new Object[]{null, var15};
                                 var10004[0] = var96;
                                 Object[] var73 = var10004;
                                 AutoObbyCrystal var72 = var95;
                                 byte var137 = ((byte)((var72.fReturningBoolean(var73)) ? 1 : 0));
                                 var97 = var137;
                              }

                              int var138 = var97;
                              if (var138 == 0) {
                                 return;
                              }

                              Object[] var76 = new Object[]{var30, var25};
                              AutoObbyCrystal var75 = this;
                              var75.r(var76);
                              var99 = 1;
                              var98 = this;
                           }

                           var98.Y = dev.prestige.recovery.SourceSupport.asBoolean(var99);
                           this.S = AutoObbyCrystalState.PLACE_CRYSTAL;
                           ElapsedTimer var144 = this.V;
                           Object[] var78 = new Object[]{var7};
                           ElapsedTimer var77 = var144;
                           var77.aReturningVoid(var78);
                           return;
                        }

                        short var146 = 8430;
                        long var10002 = 3004896465168952552L ^ var2;
                        Object[] var51 = new Object[]{"No obsidian in hotbar.", var5};
                        AutoObbyCrystal var50 = this;
                        var50.u(var51);
                     }

                     return;
                  }
               }

               AutoObbyCrystal var116 = this;
               var87 = var116;
            }

            short var148 = 16297;
            long var149 = 5164163651198841789L ^ var2;
            Object[] var47 = new Object[]{"base blocked", var11};
            AutoObbyCrystal var46 = var87;
            var46.v(var47);
            return;
         }

         this.S = AutoObbyCrystalState.PLACE_CRYSTAL;
         AutoObbyCrystal var107 = this;
         var82 = var107;
      }

      ElapsedTimer var145 = var82.V;
      Object[] var38 = new Object[]{var7};
      ElapsedTimer var37 = var145;
      var37.aReturningVoid(var38);
   }

   private void p(Object[] var1) {
      Rotation var4;
      long var5;
      long var7;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var25;
      long var27;
      long var29;
      long var31;
      long var33;
      long var35;
      int var37;
      BlockPos var157;
      long var240;
      var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var240 = 76073374701881L ^ var2;
      var5 = var240 ^ 23852562547353L;
      var7 = var240 ^ 9267661859543L;
      long var9 = var240 ^ 64584234850788L;
      var11 = var240 ^ 131102874531723L;
      var13 = var240 ^ 68781232452115L;
      var15 = var240 ^ 24960523795388L;
      var17 = var240 ^ 108241255185385L;
      var19 = var240 ^ 126334203101763L;
      var21 = var240 ^ 41232050128707L;
      var23 = var240 ^ 82007333678173L;
      var25 = var240 ^ 30735628158938L;
      var27 = var240 ^ 86633514553749L;
      var29 = var240 ^ 70722356039005L;
      var31 = var240 ^ 104312204622526L;
      var33 = var240 ^ 19731824863005L;
      var35 = var240 ^ 63095728003940L;
      var37 = Event.bReturningInt();
      int var186 = var37;
      BlockPos var185 = this.aa;
      var157 = var185;
      BlockPos var154 = var185;
      label146:
      if (var186 == 0) {
         Object[] var49 = new Object[]{var154, Blocks.OBSIDIAN, var9};
         boolean var187 = BlockUtil.bReturningBoolean(var49);
         if (!var187) {
            int var189 = var37;
            BlockPos var188 = this.aa;
            var157 = var188;
            BlockPos var155 = var188;
            if (var189 != 0) {
               break label146;
            }

            BlockPos var190 = var155;
            BlockPos var156 = var190;
            Object[] var52 = new Object[]{var156, Blocks.BEDROCK, var9};
            boolean var191 = BlockUtil.bReturningBoolean(var52);
            if (!var191) {
               return;
            }
         }

         BlockPos var55 = this.aa;
         var157 = var55.up();
      }

      BlockPos var38 = var157;
      Object[] var57 = new Object[]{var38, var33};
      AutoObbyCrystal var56 = this;
      int var10000 = (((var56.gReturningBoolean(var57)) ? 1 : 0));
      int var193 = var37;
      boolean var192 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var159 = var192;
      boolean var158 = var192;
      if (var193 == 0) {
         boolean var194 = var158;
         if (var194) {
            this.S = AutoObbyCrystalState.BREAK_CRYSTAL;
            ElapsedTimer var250 = this.V;
            Object[] var60 = new Object[]{var27};
            ElapsedTimer var59 = var250;
            var59.aReturningVoid(var60);
            return;
         }

         MinecraftClient var62 = b;
         BlockPos var64 = var38;
         ClientWorld var63 = var62.world;
         BlockState var65 = var63.getBlockState(var64);
         var159 = var65.isAir();
      }

      AutoObbyCrystal var164;
      label138: {
         label137: {
            int var196 = var37;
            boolean var195 = var159;
            boolean var163 = var195;
            boolean var160 = var195;
            if (var196 == 0) {
               boolean var197 = var160;
               if (!var197) {
                  break label137;
               }

               int var199 = var37;
               AutoObbyCrystal var198 = this;
               var164 = var198;
               AutoObbyCrystal var161 = var198;
               if (var199 != 0) {
                  break label138;
               }

               AutoObbyCrystal var200 = var161;
               AutoObbyCrystal var162 = var200;
               Object[] var10005 = new Object[]{null, null, var15};
               var10005[1] = 2;
               var10005[0] = var38;
               Object[] var69 = var10005;
               AutoObbyCrystal var68 = var162;
               boolean var201 = var68.hReturningVoid(var69);
               var163 = var201;
            }

            boolean var202 = var163;
            if (!var202) {
               Vec3d var39;
               double var167;
               label127: {
                  double var40;
                  label126: {
                     BlockPos var73 = this.aa;
                     double var10002 = var73.getX() + 0.5;
                     BlockPos var74 = this.aa;
                     double var10003 = var74.getY() + 1.0;
                     BlockPos var75 = this.aa;
                     var39 = new Vec3d(var10002, var10003, var75.getZ() + 0.5);
                     ExplosionDamageUtil var241 = Prestige.f;
                     PlayerEntity var10001 = this.Z;
                     BlockPos var10004 = this.aa;
                     Object[] var10008 = new Object[]{null, null, null, null, null, var21};
                     var10008[4] = false;
                     var10008[3] = var10004;
                     var10008[2] = false;
                     var10008[1] = var39;
                     var10008[0] = var10001;
                     Object[] var77 = var10008;
                     ExplosionDamageUtil var76 = var241;
                     var40 = var76.bReturningDouble(var77);
                     BooleanSetting var78 = this.B;
                     Boolean var79 = (Boolean)var78.aReturningObject();
                     var10000 = ((((java.lang.Boolean)(var79)).booleanValue() ? 1 : 0));
                     int var204 = var37;
                     boolean var203 = ((((int)(var10000) & 1) != 0));
                     boolean var166 = var203;
                     boolean var165 = var203;
                     if (var204 == 0) {
                        boolean var205 = var165;
                        if (!var205) {
                           break label126;
                        }

                        Object[] var82 = new Object[]{var5};
                        AutoObbyCrystal var81 = this;
                        boolean var206 = var81.dReturningBoolean(var82);
                        var166 = var206;
                     }

                     boolean var207 = var166;
                     if (var207) {
                        Object[] var85 = new Object[]{var29};
                        AutoObbyCrystal var84 = this;
                        Vec3d var269 = var84.dReturningVec3d(var85);
                        var10004 = this.aa;
                        var10008 = new Object[]{null, null, null, null, var35};
                        var10008[3] = var40;
                        var10008[2] = var10004;
                        var10008[1] = var269;
                        var10008[0] = var39;
                        Object[] var87 = var10008;
                        AutoObbyCrystal var86 = this;
                        double var90 = var86.aReturningDouble(var87);
                        double var88 = var40;
                        double var208 = Math.max(var88, var90);
                        var167 = var208;
                        break label127;
                     }
                  }

                  var167 = var40;
               }

               double var42 = var167;
               ExplosionDamageUtil var243 = Prestige.f;
               MinecraftClient var93 = b;
               ClientPlayerEntity var251 = var93.player;
               BlockPos var273 = this.aa;
               Object[] var276 = new Object[]{null, null, null, null, null, var21};
               var276[4] = false;
               var276[3] = var273;
               var276[2] = false;
               var276[1] = var39;
               var276[0] = var251;
               Object[] var95 = var276;
               ExplosionDamageUtil var94 = var243;
               double var44 = var94.bReturningDouble(var95);
               FloatSetting var96 = this.c;
               Float var97 = (Float)var96.aReturningObject();
               float var252 = var97;
               FloatSetting var98 = this.p;
               Float var99 = (Float)var98.aReturningObject();
               double var277;
               var10000 = (var277 = var42 - var252 * var99) == 0.0 ? 0 : (var277 < 0.0 ? -1 : 1);
               int var211 = var37;
               int var210 = var10000;
               int var170 = var210;
               int var169 = var210;
               if (var211 == 0) {
                  int var212 = var169;
                  if (var212 < 0) {
                     short var258 = 22756;
                     long var265 = 7451376988363633831L ^ var240;
                     Object[] var266 = new Object[1];
                     double var101 = var42;
                     var266[0] = var101;
                     Object[] var104 = var266;
                     String var103 = "%.1f";
                     String var259 = String.format(var103, var104);
                     short var267 = 28476;
                     long var271 = 1264579099793818479L ^ var240;
                     Object[] var106 = new Object[]{"re-gate targetDamage " + var259, var7};
                     AutoObbyCrystal var105 = this;
                     var105.v(var106);
                     return;
                  }

                  FloatSetting var108 = this.d;
                  Float var109 = (Float)var108.aReturningObject();
                  double var278;
                  var170 = (var278 = var44 - var109.floatValue()) == 0.0 ? 0 : (var278 < 0.0 ? -1 : 1);
               }

               label151: {
                  int var214 = var37;
                  int var213 = var170;
                  int var172 = var213;
                  int var171 = var213;
                  if (var214 == 0) {
                     int var215 = var171;
                     if (var215 > 0) {
                        break label151;
                     }

                     BooleanSetting var111 = this.e;
                     Boolean var112 = (Boolean)var111.aReturningObject();
                     byte var216 = ((byte)(((java.lang.Boolean)(var112)).booleanValue() ? 1 : 0));
                     var172 = var216;
                  }

                  label115: {
                     int var218 = var37;
                     int var217 = var172;
                     int var174 = var217;
                     int var173 = var217;
                     if (var218 == 0) {
                        int var219 = var173;
                        if (var219 == 0) {
                           break label115;
                        }

                        MinecraftClient var115 = b;
                        ClientPlayerEntity var116 = var115.player;
                        float var253 = var116.getHealth();
                        MinecraftClient var117 = b;
                        ClientPlayerEntity var118 = var117.player;
                        double var279;
                        int var220 = (var279 = var44 - (var253 + var118.getAbsorptionAmount() - 1.0F)) == 0.0 ? 0 : (var279 < 0.0 ? -1 : 1);
                        var174 = var220;
                     }

                     int var221 = var174;
                     if (var221 >= 0) {
                        break label151;
                     }
                  }

                  Object[] var127 = new Object[]{Items.END_CRYSTAL, var13};
                  Integer var46 = InventoryUtil.aReturningBoxedInteger(var127);
                  int var222 = var37;
                  if (var222 == 0) {
                     Integer var223 = var46;
                     if (var223 != null) {
                        Object[] var132 = new Object[]{var4, var17};
                        HitResult var47 = RotationUtil.aReturningHitResult(var132);
                        int var225 = var37;
                        HitResult var224 = var47;
                        HitResult var176 = var224;
                        HitResult var175 = var224;
                        if (var225 == 0) {
                           boolean var226 = var175 instanceof BlockHitResult;
                           if (!var226) {
                              return;
                           }

                           HitResult var227 = var47;
                           var176 = var227;
                        }

                        BlockHitResult var48 = (BlockHitResult)var176;
                        BlockHitResult var135 = var48;
                        BlockPos var245 = var135.getBlockPos();
                        BlockPos var137 = this.aa;
                        BlockPos var136 = var245;
                        byte var246 = ((byte)((var136.equals(var137)) ? 1 : 0));
                        int var229 = var37;
                        byte var228 = var246;
                        int var178 = var228;
                        byte var177 = var228;
                        if (var229 == 0) {
                           byte var230 = var177;
                           if (var230 == 0) {
                              return;
                           }

                           var178 = this.af;
                        }

                        AutoObbyCrystal var183;
                        int var184;
                        label153: {
                           int var232 = var37;
                           int var231 = var178;
                           int var182 = var231;
                           int var179 = var231;
                           if (var232 == 0) {
                              // int var233 = var179;
                              if (var233 == var234) {
                                 Object[] var140 = new Object[]{this, var31};
                                 this.af = SlotReservation.aReturningInt(var140);
                              }

                              Integer var142 = var46;
                              int var255 = var142;
                              int var237 = var37;
                              int var236 = var255;
                              AutoObbyCrystal var235 = this;
                              var183 = var235;
                              var184 = var236;
                              AutoObbyCrystal var180 = var235;
                              int var181 = var236;
                              if (var237 != 0) {
                                 break label153;
                              }

                              Object[] var274 = new Object[]{null, var11};
                              var274[0] = var181;
                              Object[] var144 = var274;
                              AutoObbyCrystal var143 = var180;
                              byte var238 = ((byte)((var143.fReturningBoolean(var144)) ? 1 : 0));
                              var182 = var238;
                           }

                           int var239 = var182;
                           if (var239 == 0) {
                              return;
                           }

                           Object[] var147 = new Object[]{var48, var19};
                           AutoObbyCrystal var146 = this;
                           var146.r(var147);
                           ElapsedTimer var247 = this.U;
                           Object[] var149 = new Object[]{var27};
                           ElapsedTimer var148 = var247;
                           var148.aReturningVoid(var149);
                           MinMaxSetting var248 = this.m;
                           Object[] var151 = new Object[]{var25};
                           MinMaxSetting var150 = var248;
                           var150.bReturningVoid(var151);
                           var184 = 0;
                           var183 = this;
                        }

                        var183.Y = dev.prestige.recovery.SourceSupport.asBoolean(var184);
                        this.S = AutoObbyCrystalState.BREAK_CRYSTAL;
                        ElapsedTimer var249 = this.V;
                        Object[] var153 = new Object[]{var27};
                        ElapsedTimer var152 = var249;
                        var152.aReturningVoid(var153);
                        return;
                     }

                     short var254 = 28218;
                     long var261 = 1226259376026452590L ^ var240;
                     Object[] var130 = new Object[]{"No end crystals in hotbar.", var23};
                     AutoObbyCrystal var129 = this;
                     var129.u(var130);
                  }

                  return;
               }

               short var256 = 5266;
               long var262 = 1292684453908609236L ^ var240;
               Object[] var263 = new Object[1];
               double var120 = var44;
               var263[0] = var120;
               Object[] var123 = var263;
               String var122 = "%.1f";
               String var257 = String.format(var122, var123);
               short var264 = 8814;
               long var270 = 2565518916821110316L ^ var240;
               Object[] var125 = new Object[]{"re-gate selfDamage " + var257, var7};
               AutoObbyCrystal var124 = this;
               var124.v(var125);
               return;
            }
         }

         var164 = this;
      }

      short var260 = 2827;
      long var268 = 8989779497283643206L ^ var240;
      Object[] var72 = new Object[]{"crystal spawn blocked", var7};
      AutoObbyCrystal var71 = var164;
      var71.v(var72);
   }

   private void q(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 76073374701881L ^ var2;
      long var5 = var2 ^ 101971978172631L;
      long var7 = var2 ^ 135940206396414L;
      long var9 = var2 ^ 69016103148307L;
      long var11 = var2 ^ 38619620843427L;
      long var13 = var2 ^ 76790462137191L;
      long var15 = var2 ^ 18596970976552L;
      long var17 = var2 ^ 29818136214055L;
      long var19 = var2 ^ 131841737750622L;
      int var10000 = Event.cReturningInt();
      Object[] var30 = new Object[]{var5};
      AutoObbyCrystal var29 = this;
      EndCrystalEntity var22 = var29.aReturningEndCrystalEntity(var30);
      int var21 = var10000;
      int var118 = var21;
      EndCrystalEntity var117 = var22;
      EndCrystalEntity var94 = var117;
      EndCrystalEntity var93 = var117;
      if (var118 != 0) {
         EndCrystalEntity var119 = var93;
         if (var119 == null) {
            return;
         }

         var94 = var22;
      }

      EndCrystalEntity var32 = var94;
      Box var23 = var32.getBoundingBox();
      int var121 = var21;
      AutoObbyCrystal var120 = this;
      AutoObbyCrystal var96 = var120;
      AutoObbyCrystal var95 = var120;
      if (var121 != 0) {
         MinecraftClient var33 = b;
         ClientPlayerEntity var34 = var33.player;
         Object[] var36 = new Object[]{var23, var34.getEyePos(), var4, var11};
         AutoObbyCrystal var35 = var95;
         boolean var122 = var35.lReturningBoolean(var36);
         if (!var122) {
            return;
         }

         AutoObbyCrystal var123 = this;
         var96 = var123;
      }

      int var125 = var21;
      Vec3d var124 = var96.ak;
      Vec3d var98 = var124;
      Vec3d var97 = var124;
      if (var125 != 0) {
         Vec3d var126 = var97;
         if (var126 != null) {
            Object[] var41 = new Object[]{var23, this.ak, var4, var11};
            AutoObbyCrystal var40 = this;
            boolean var127 = var40.lReturningBoolean(var41);
            if (!var127) {
               return;
            }
         }

         BlockPos var44 = this.aa;
         double var10002 = var44.getX() + 0.5;
         BlockPos var45 = this.aa;
         double var10003 = var45.getY() + 1.0;
         BlockPos var46 = this.aa;
         var98 = new Vec3d(var10002, var10003, var46.getZ() + 0.5);
      }

      Vec3d var24 = var98;
      ExplosionDamageUtil var165 = Prestige.f;
      MinecraftClient var47 = b;
      ClientPlayerEntity var10001 = var47.player;
      BlockPos var10004 = this.aa;
      Object[] var10008 = new Object[]{null, null, null, null, null, var7};
      var10008[4] = false;
      var10008[3] = var10004;
      var10008[2] = false;
      var10008[1] = var24;
      var10008[0] = var10001;
      Object[] var49 = var10008;
      ExplosionDamageUtil var48 = var165;
      double var25 = var48.bReturningDouble(var49);
      FloatSetting var50 = this.d;
      Float var51 = (Float)var50.aReturningObject();
      double var181;
      var10000 = (var181 = var25 - var51.floatValue()) == 0.0 ? 0 : (var181 < 0.0 ? -1 : 1);
      int var129 = var21;
      int var128 = var10000;
      int var100 = var128;
      int var99 = var128;
      if (var129 != 0) {
         int var130 = var99;
         if (var130 > 0) {
            return;
         }

         BooleanSetting var53 = this.e;
         Boolean var54 = (Boolean)var53.aReturningObject();
         byte var131 = ((byte)(((java.lang.Boolean)(var54)).booleanValue() ? 1 : 0));
         var100 = var131;
      }

      int var104;
      int var133 = var21;
      int var132 = var100;
      var104 = var132;
      int var101 = var132;
      label101:
      if (var133 != 0) {
         int var134 = var101;
         if (var134 != 0) {
            MinecraftClient var57 = b;
            ClientPlayerEntity var58 = var57.player;
            float var177 = var58.getHealth();
            MinecraftClient var59 = b;
            ClientPlayerEntity var60 = var59.player;
            double var182;
            var10000 = (var182 = var25 - (var177 + var60.getAbsorptionAmount() - 1.0F)) == 0.0 ? 0 : (var182 < 0.0 ? -1 : 1);
            int var136 = var21;
            int var135 = var10000;
            var104 = var135;
            int var102 = var135;
            if (var136 == 0) {
               break label101;
            }

            int var137 = var102;
            int var103 = var137;
            int var138 = var103;
            if (var138 >= 0) {
               return;
            }
         }

         var104 = (((AutoCrystal.a) ? 1 : 0));
      }

      int var115;
      label88: {
         AutoObbyCrystal var116;
         label123: {
            int var110;
            int var140 = var21;
            int var139 = var104;
            var110 = var139;
            int var105 = var139;
            label86:
            if (var140 != 0) {
               Object var109;
               label124: {
                  int var141 = var105;
                  if (var141 != 0) {
                     MinecraftClient var64 = b;
                     HitResult var28 = var64.crosshairTarget;
                     byte var168 = ((byte)((var28 instanceof EntityHitResult) ? 1 : 0));
                     int var143 = var21;
                     byte var142 = var168;
                     var110 = var142;
                     byte var106 = var142;
                     if (var143 == 0) {
                        break label86;
                     }

                     byte var144 = var106;
                     if (var144 != 0) {
                        EntityHitResult var27 = (EntityHitResult)var28;
                        EntityHitResult var66 = var27;
                        Entity var169 = var66.getEntity();
                        int var146 = var21;
                        Entity var145 = var169;
                        var109 = var145;
                        Entity var107 = var145;
                        if (var146 == 0) {
                           break label124;
                        }

                        EndCrystalEntity var148 = var22;
                        Entity var147 = var107;
                        if (var147 == var148) {
                           return;
                        }
                     }
                  }

                  int var150 = var21;
                  AutoObbyCrystal var149 = this;
                  var116 = var149;
                  AutoObbyCrystal var108 = var149;
                  if (var150 == 0) {
                     break label123;
                  }

                  ModeSetting var69 = var108.f;
                  Object var151 = var69.aReturningObject();
                  var109 = var151;
               }

               String var170 = (String)var109;
               short var178 = 31099;
               long var179 = 7751846206054175124L ^ var2;
               String var72 = "SwapAttack";
               String var71 = var170;
               var110 = (((var71.equals(var72)) ? 1 : 0));
            }

            int var152 = var110;
            if (var152 != 0) {
               int var154 = var21;
               AutoObbyCrystal var153 = this;
               var116 = var153;
               AutoObbyCrystal var111 = var153;
               if (var154 == 0) {
                  break label123;
               }

               AutoObbyCrystal var155 = var111;
               AutoObbyCrystal var112 = var155;
               // int var156 = var112.af;
               if (var156 != var157) {
                  Object[] var75 = new Object[]{var17};
                  var10000 = InventoryUtil.aReturningInt(var75);
                  int var159 = var21;
                  int var158 = var10000;
                  var115 = var158;
                  int var113 = var158;
                  if (var159 == 0) {
                     break label88;
                  }

                  int var160 = var113;
                  int var114 = var160;
                  int var162 = this.af;
                  int var161 = var114;
                  if (var161 != var162) {
                     int var163 = this.af;
                     var115 = var163;
                     break label88;
                  }
               }
            }

            Object[] var85 = new Object[]{var22, var9};
            AutoObbyCrystal var84 = this;
            var84.s(var85);
            EndCrystalEntity var86 = var22;
            this.ai = var86.getId();
            ElapsedTimer var172 = this.T;
            Object[] var88 = new Object[]{var15};
            ElapsedTimer var87 = var172;
            var87.aReturningVoid(var88);
            MinMaxSetting var173 = this.l;
            Object[] var90 = new Object[]{var13};
            MinMaxSetting var89 = var173;
            var89.bReturningVoid(var90);
            this.ag = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.S = AutoObbyCrystalState.PLACE_CRYSTAL;
            var116 = this;
         }

         ElapsedTimer var176 = var116.V;
         Object[] var92 = new Object[]{var15};
         ElapsedTimer var91 = var176;
         var91.aReturningVoid(var92);
         return;
      }

      Object[] var180 = new Object[]{null, var19};
      var180[0] = var115;
      Object[] var79 = var180;
      InventoryUtil.aReturningVoid(var79);
      RotationManager var174 = Prestige.o;
      Object[] var81 = new Object[]{true};
      RotationManager var80 = var174;
      var80.fReturningVoid(var81);
      ElapsedTimer var175 = this.V;
      Object[] var83 = new Object[]{var15};
      ElapsedTimer var82 = var175;
      var82.aReturningVoid(var83);
   }

   private void r(Object[] var1) {
      BlockHitResult var2 = (BlockHitResult)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 76073374701881L ^ var3;
      MinecraftClient var6 = b;
      MinecraftClient var7 = b;
      BlockHitResult var11 = var2;
      Hand var10 = Hand.MAIN_HAND;
      ClientPlayerEntity var9 = var7.player;
      ClientPlayerInteractionManager var8 = var6.interactionManager;
      ActionResult var12 = var8.interactBlock(var9, var10, var11);
      boolean var5 = var12.isAccepted();
      RotationManager var19 = Prestige.o;
      Object[] var14 = new Object[]{true};
      RotationManager var13 = var19;
      var13.fReturningVoid(var14);
      this.X = dev.prestige.recovery.SourceSupport.asBoolean(1);
      boolean var18 = var5;
      if (var18) {
         MinecraftClient var15 = b;
         Hand var17 = Hand.MAIN_HAND;
         ClientPlayerEntity var16 = var15.player;
         var16.swingHand(var17);
      }
   }

   private void s(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 76073374701881L ^ var2;
      MinecraftClient var5 = b;
      MinecraftClient var6 = b;
      Entity var9 = var4;
      ClientPlayerEntity var8 = var6.player;
      ClientPlayerInteractionManager var7 = var5.interactionManager;
      var7.attackEntity((PlayerEntity)var8, var9);
      MinecraftClient var10 = b;
      Hand var12 = Hand.MAIN_HAND;
      ClientPlayerEntity var11 = var10.player;
      var11.swingHand(var12);
      RotationManager var15 = Prestige.o;
      Object[] var14 = new Object[]{true};
      RotationManager var13 = var15;
      var13.fReturningVoid(var14);
      this.X = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   private boolean gReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 76073374701881L ^ var3;
      int var5 = Event.bReturningInt();
      // int var27 = this.ai;
      if (var27 != var28) {
         MinecraftClient var7 = b;
         int var9 = this.ai;
         ClientWorld var8 = var7.world;
         Entity var29 = var8.getEntityById(var9);
         if (var29 == null) {
            this.ai = -1;
         }
      }

      BlockPos var12 = var2;
      double var10002 = var12.getX();
      BlockPos var13 = var2;
      double var10003 = var13.getY();
      BlockPos var14 = var2;
      double var10004 = var14.getZ();
      BlockPos var15 = var2;
      double var10005 = var15.getX() + 1.0;
      BlockPos var16 = var2;
      double var10006 = var16.getY() + 1.0;
      BlockPos var17 = var2;
      Box var6 = new Box(var10002, var10003, var10004, var10005, var10006, var17.getZ() + 1.0);
      MinecraftClient var18 = b;
      ClientWorld var34 = var18.world;
      Predicate var22 = invokeBinding35(this);
      Box var21 = var6;
      Object var20 = null;
      ClientWorld var19 = var34;
      List var23 = var19.getOtherEntities((Entity)var20, var21, var22);
      byte var35 = ((byte)((var23.isEmpty()) ? 1 : 0));
      int var31 = var5;
      byte var30 = var35;
      byte var25 = var30;
      byte var24 = var30;
      if (var31 == 0) {
         byte var32 = var24;
         if (var32 != 0) {
            return false;
         }

         var25 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var25);
   }

   private boolean h(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      int var3 = (Integer)var1[1];
      long var4 = (Long)var1[2];
      long var10000 = 76073374701881L ^ var4;
      int var27 = Event.cReturningInt();
      BlockPos var8 = var2;
      double var10003 = var8.getX();
      BlockPos var9 = var2;
      double var10004 = var9.getY();
      BlockPos var10 = var2;
      double var10005 = var10.getZ();
      BlockPos var11 = var2;
      double var10006 = var11.getX() + 1.0;
      BlockPos var12 = var2;
      double var10007 = var12.getY() + var3;
      BlockPos var13 = var2;
      Box var7 = new Box(var10003, var10004, var10005, var10006, var10007, var13.getZ() + 1.0);
      int var6 = var27;
      MinecraftClient var14 = b;
      ClientWorld var28 = var14.world;
      Predicate var18 = invokeBinding36(this);
      Box var17 = var7;
      Object var16 = null;
      ClientWorld var15 = var28;
      List var19 = var15.getOtherEntities((Entity)var16, var17, var18);
      byte var29 = ((byte)((var19.isEmpty()) ? 1 : 0));
      int var24 = var6;
      byte var23 = var29;
      byte var21 = var23;
      byte var20 = var23;
      if (var24 != 0) {
         byte var25 = var20;
         if (var25 != 0) {
            return false;
         }

         var21 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var21);
   }

   private boolean i(Object[] var1) {
      BlockPos var4 = (BlockPos)var1[0];
      int var5 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      var2 = 76073374701881L ^ var2;
      long var6 = var2 ^ 107048960118738L;
      long var8 = var2 ^ 107756583963617L;
      int var10 = Event.bReturningInt();
      Object[] var10005 = new Object[]{null, null, var6};
      var10005[1] = var5;
      var10005[0] = var4;
      Object[] var17 = var10005;
      AutoObbyCrystal var16 = this;
      int var10000 = (((var16.hReturningVoid(var17)) ? 1 : 0));
      int var76 = var10;
      byte var75 = (byte)var10000;
      byte var58 = var75;
      byte var57 = var75;
      if (var76 == 0) {
         byte var77 = var57;
         if (var77 == 0) {
            BlockPos var19 = var4;
            double var10002 = var19.getX();
            BlockPos var20 = var4;
            double var10003 = var20.getY();
            BlockPos var21 = var4;
            double var10004 = var21.getZ();
            BlockPos var22 = var4;
            double var117 = var22.getX() + 1.0;
            BlockPos var23 = var4;
            double var10006 = var23.getY() + var5;
            BlockPos var24 = var4;
            Box var11 = new Box(var10002, var10003, var10004, var117, var10006, var24.getZ() + 1.0);
            IntSetting var25 = this.A;
            Integer var26 = (Integer)var25.aReturningObject();
            int var12 = var26;
            int var79 = var10;
            int var78 = var12;
            int var60 = var78;
            int var59 = var78;
            if (var79 == 0) {
               int var80 = var59;
               if (var80 > 0) {
                  Vec3d var13;
                  int var68;
                  label92: {
                     label104: {
                        int var82 = var10;
                        AutoObbyCrystal var81 = this;
                        AutoObbyCrystal var62 = var81;
                        AutoObbyCrystal var61 = var81;
                        if (var82 == 0) {
                           PlayerEntity var83 = var61.Z;
                           if (var83 == null) {
                              break label104;
                           }

                           AutoObbyCrystal var84 = this;
                           var62 = var84;
                        }

                        Object[] var31 = new Object[]{var8};
                        AutoObbyCrystal var30 = var62;
                        var13 = var30.aReturningVec3d(var31);
                        Vec3d var32 = var13;
                        double var118;
                        var10000 = (var118 = var32.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var118 < 0.0 ? -1 : 1);
                        int var86 = var10;
                        int var85 = var10000;
                        var68 = var85;
                        int var63 = var85;
                        if (var86 != 0) {
                           break label92;
                        }

                        int var87 = var63;
                        if (var87 > 0) {
                           PlayerEntity var34 = this.Z;
                           Box var14 = var34.getBoundingBox();
                           int var15 = 1;

                           int var96;
                           do {
                              int var89 = var12;
                              int var88 = var15;
                              if (var88 > var89) {
                                 break;
                              }

                              double var36 = var15;
                              Vec3d var35 = var13;
                              Vec3d var39 = var35.multiply(var36);
                              Box var38 = var14;
                              Box var113 = var38.offset(var39);
                              Box var41 = var11;
                              Box var40 = var113;
                              byte var114 = ((byte)((var40.intersects(var41)) ? 1 : 0));
                              int var91 = var10;
                              byte var90 = var114;
                              var68 = var90;
                              byte var64 = var90;
                              if (var91 != 0) {
                                 break label92;
                              }

                              int var93 = var10;
                              byte var92 = var64;
                              byte var67 = var92;
                              byte var65 = var92;
                              if (var93 != 0) {
                                 return dev.prestige.recovery.SourceSupport.asBoolean(var67);
                              }

                              byte var94 = var65;
                              byte var66 = var94;
                              byte var95 = var66;
                              if (var95 != 0) {
                                 return true;
                              }

                              var15++;
                              var96 = var10;
                           } while (var96 == 0);
                        }
                     }

                     MinecraftClient var44 = b;
                     ClientPlayerEntity var45 = var44.player;
                     var13 = var45.getVelocity();
                     Vec3d var46 = var13;
                     double var119;
                     var68 = (var119 = var46.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var119 < 0.0 ? -1 : 1);
                  }

                  int var98 = var10;
                  int var97 = var68;
                  int var74 = var97;
                  int var69 = var97;
                  if (var98 == 0) {
                     int var99 = var69;
                     if (var99 > 0) {
                        MinecraftClient var48 = b;
                        ClientPlayerEntity var49 = var48.player;
                        Box var110 = var49.getBoundingBox();
                        int var111 = 1;

                        int var108;
                        do {
                           int var101 = var12;
                           int var100 = var111;
                           if (var100 > var101) {
                              break;
                           }

                           double var51 = var111;
                           Vec3d var50 = var13;
                           Vec3d var54 = var50.multiply(var51);
                           Box var53 = var110;
                           Box var115 = var53.offset(var54);
                           Box var56 = var11;
                           Box var55 = var115;
                           boolean var116 = var55.intersects(var56);
                           int var103 = var10;
                           boolean var102 = var116;
                           boolean var122 = var102;
                           boolean var70 = var102;
                           if (var103 != 0) {
                              return var122;
                           }

                           int var105 = var10;
                           boolean var104 = var70;
                           boolean var73 = var104;
                           boolean var71 = var104;
                           if (var105 != 0) {
                              return var73;
                           }

                           boolean var106 = var71;
                           boolean var72 = var106;
                           boolean var107 = var72;
                           if (var107) {
                              return true;
                           }

                           var111++;
                           var108 = var10;
                        } while (var108 == 0);
                     }

                     var74 = 0;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var74);
               }

               var60 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var60);
         }

         var58 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var58);
   }

   private void t(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 20692713473378L;
      long var6 = var2 ^ 79092765987629L;
      long var8 = var2 ^ 30010155761760L;
      long var10 = var2 ^ 43288944364092L;
      int var10000 = Event.bReturningInt();
      Object[] var15 = new Object[]{var10};
      PlayerEntity var13 = EntityUtil.aReturningPlayerEntity(var15);
      int var12 = var10000;
      int var63 = var12;
      PlayerEntity var62 = var13;
      PlayerEntity var48 = var62;
      PlayerEntity var47 = var62;
      if (var63 == 0) {
         PlayerEntity var64 = var47;
         if (var64 == null) {
            return;
         }

         var48 = var13;
      }

      PlayerEntity var17 = var48;
      byte var85 = ((byte)((var17.isAlive()) ? 1 : 0));
      int var66 = var12;
      byte var65 = var85;
      int var50 = var65;
      byte var49 = var65;
      if (var66 == 0) {
         byte var67 = var49;
         if (var67 == 0) {
            return;
         }

         MinecraftClient var19 = b;
         PlayerEntity var21 = var13;
         ClientPlayerEntity var20 = var19.player;
         float var86 = var20.distanceTo((Entity)var21);
         FloatSetting var22 = this.a;
         Float var23 = (Float)var22.aReturningObject();
         float var94;
         int var68 = (var94 = var86 - var23) == 0.0F ? 0 : (var94 < 0.0F ? -1 : 1);
         var50 = var68;
      }

      int var69 = var50;
      if (var69 <= 0) {
         this.Z = var13;
         Object[] var26 = new Object[]{var8};
         AutoObbyCrystal var25 = this;
         BlockPlacementTarget var14 = var25.aReturningai_C0020(var26);
         int var70 = var12;
         if (var70 == 0) {
            BlockPlacementTarget var71 = var14;
            if (var71 == null) {
               this.Z = null;
               return;
            }

            this.aa = var14.a;
            this.ab = var14.b;
            this.ac = var14.c;
            this.ad = var14.d;
            PlayerEntity var29 = this.Z;
            this.ae = var29.getBlockPos();
            this.ag = dev.prestige.recovery.SourceSupport.asBoolean(0);
         }

         AutoObbyCrystal var60;
         AutoObbyCrystalState var61;
         label36: {
            int var74 = var12;
            boolean var73 = var14.f;
            AutoObbyCrystal var72 = this;
            AutoObbyCrystal var56 = var72;
            boolean var57 = var73;
            AutoObbyCrystal var51 = var72;
            boolean var52 = var73;
            if (var74 == 0) {
               boolean var76 = var52;
               AutoObbyCrystal var75 = var51;
               AutoObbyCrystal var55 = var75;
               AutoObbyCrystal var53 = var75;
               if (var76) {
                  AutoObbyCrystal var77 = var53;
                  AutoObbyCrystal var54 = var77;
                  AutoObbyCrystalState var79 = AutoObbyCrystalState.BREAK_CRYSTAL;
                  AutoObbyCrystal var78 = var54;
                  var60 = var78;
                  var61 = var79;
                  break label36;
               }

               var57 = var14.e;
               var56 = var55;
            }

            boolean var81 = var57;
            AutoObbyCrystal var80 = var56;
            AutoObbyCrystal var59 = var80;
            AutoObbyCrystal var58 = var80;
            if (var81) {
               AutoObbyCrystalState var83 = AutoObbyCrystalState.PLACE_OBSIDIAN;
               AutoObbyCrystal var82 = var58;
               var60 = var82;
               var61 = var83;
            } else {
               var61 = AutoObbyCrystalState.PLACE_CRYSTAL;
               var60 = var59;
            }
         }

         var60.S = var61;
         ElapsedTimer var87 = this.V;
         Object[] var34 = new Object[]{var6};
         ElapsedTimer var33 = var87;
         var33.aReturningVoid(var34);
         this.X = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.Y = dev.prestige.recovery.SourceSupport.asBoolean(0);
         ElapsedTimer var88 = this.W;
         Object[] var36 = new Object[]{var6};
         ElapsedTimer var35 = var88;
         var35.aReturningVoid(var36);
         MinMaxSetting var89 = this.n;
         Object[] var38 = new Object[]{var4};
         MinMaxSetting var37 = var89;
         var37.bReturningVoid(var38);
         ElapsedTimer var90 = this.T;
         Object[] var40 = new Object[]{var6};
         ElapsedTimer var39 = var90;
         var39.aReturningVoid(var40);
         ElapsedTimer var91 = this.U;
         Object[] var42 = new Object[]{var6};
         ElapsedTimer var41 = var91;
         var41.aReturningVoid(var42);
         MinMaxSetting var92 = this.l;
         Object[] var44 = new Object[]{var4};
         MinMaxSetting var43 = var92;
         var43.bReturningVoid(var44);
         MinMaxSetting var93 = this.m;
         Object[] var46 = new Object[]{var4};
         MinMaxSetting var45 = var93;
         var45.bReturningVoid(var46);
      }
   }

   private Vec3d dReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 29549714489244L;
      long var6 = var2 ^ 18196675652587L;
      int var10000 = Event.cReturningInt();
      Object[] var17 = new Object[]{this.Z, var4};
      Vec3d var9 = RaycastUtil.aReturningVec3d(var17);
      int var8 = var10000;
      int var72 = var8;
      AutoObbyCrystal var71 = this;
      AutoObbyCrystal var60 = var71;
      AutoObbyCrystal var59 = var71;
      if (var72 != 0) {
         BooleanSetting var18 = var59.B;
         Boolean var19 = (Boolean)var18.aReturningObject();
         boolean var73 = var19;
         if (!var73) {
            return var9;
         }

         var60 = this;
      }

      Object[] var23 = new Object[]{var6};
      AutoObbyCrystal var22 = var60;
      Vec3d var10 = var22.aReturningVec3d(var23);
      Vec3d var24 = var10;
      double var96;
      var10000 = (var96 = var24.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var96 < 0.0 ? -1 : 1);
      int var75 = var8;
      int var74 = var10000;
      int var62 = var74;
      int var61 = var74;
      if (var75 != 0) {
         int var76 = var61;
         if (var76 < 0) {
            return var9;
         }

         var62 = 0;
      }

      int var11 = var62;
      MinecraftClient var27 = b;
      ClientPlayerEntity var28 = var27.player;
      ClientPlayNetworkHandler var91 = var28.networkHandler;
      PlayerEntity var29 = this.Z;
      UUID var31 = var29.getUuid();
      ClientPlayNetworkHandler var30 = var91;
      PlayerListEntry var12 = var30.getPlayerListEntry(var31);
      int var78 = var8;
      PlayerListEntry var77 = var12;
      Object var64 = var77;
      PlayerListEntry var63 = var77;
      if (var78 != 0) {
         PlayerListEntry var79 = var63;
         if (var79 != null) {
            byte var92 = 0;
            PlayerListEntry var33 = var12;
            int var35 = var33.getLatency();
            var11 = Math.max(0, var35);
         }

         FloatSetting var36 = this.C;
         var64 = var36.aReturningObject();
      }

      Float var37 = (Float)var64;
      float var93 = var37;
      float var10001 = var11 / 50.0F;
      FloatSetting var38 = this.D;
      Float var39 = (Float)var38.aReturningObject();
      float var94 = var93 + var10001 * var39;
      float var42 = 20.0F;
      float var41 = 0.0F;
      float var40 = var94;
      float var13 = MathHelper.clamp(var40, var41, var42);
      Vec3d var43 = var10;
      double var10002 = var43.x * var13;
      Vec3d var44 = var10;
      Vec3d var14 = new Vec3d(var10002, 0.0, var44.z * var13);
      FloatSetting var45 = this.E;
      Float var46 = (Float)var45.aReturningObject();
      double var15 = var46.floatValue();
      int var81 = var8;
      Vec3d var80 = var14;
      Vec3d var70 = var80;
      Vec3d var65 = var80;
      if (var81 != 0) {
         Vec3d var47 = var65;
         double var97;
         int var82 = (var97 = var47.lengthSquared() - var15 * var15) == 0.0 ? 0 : (var97 < 0.0 ? -1 : 1);
         if (var82 > 0) {
            int var84 = var8;
            Vec3d var83 = var14;
            Vec3d var68 = var83;
            Vec3d var66 = var83;
            Vec3d var69;
            if (var84 != 0) {
               Vec3d var85 = var66;
               Vec3d var67 = var85;
               Vec3d var50 = var67;
               double var98;
               int var86 = (var98 = var50.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var98 < 0.0 ? -1 : 1);
               if (var86 > 0) {
                  Vec3d var52 = var14;
                  Vec3d var95 = var52.normalize();
                  double var54 = var15;
                  Vec3d var53 = var95;
                  Vec3d var87 = var53.multiply(var54);
                  var69 = var87;
               } else {
                  var69 = Vec3d.ZERO;
               }
            } else {
               Vec3d var88 = var68;
               var69 = var88;
            }

            var14 = var69;
         }

         Vec3d var58 = var14;
         Vec3d var57 = var9;
         var70 = var57.add(var58);
      }

      return var70;
   }

   private Vec3d eReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 76073374701881L ^ var2;
      int var61 = Event.bReturningInt();
      MinecraftClient var10 = b;
      ClientPlayerEntity var11 = var10.player;
      Vec3d var5 = var11.getEyePos();
      int var4 = var61;
      BooleanSetting var12 = this.F;
      Boolean var13 = (Boolean)var12.aReturningObject();
      boolean var48 = var13;
      if (!var48) {
         return var5;
      }

      MinecraftClient var15 = b;
      ClientPlayerEntity var16 = var15.player;
      Vec3d var6 = var16.getVelocity();
      int var50 = var4;
      Vec3d var49 = var6;
      Vec3d var41 = var49;
      Vec3d var40 = var49;
      if (var50 == 0) {
         Vec3d var17 = var40;
         double var64;
         int var51 = (var64 = var17.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var64 < 0.0 ? -1 : 1);
         if (var51 < 0) {
            return var5;
         }

         Vec3d var20 = var6;
         double var10002 = var20.x;
         FloatSetting var21 = this.G;
         Float var22 = (Float)var21.aReturningObject();
         var10002 *= var22.floatValue();
         Vec3d var23 = var6;
         double var10004 = var23.z;
         FloatSetting var24 = this.G;
         Float var25 = (Float)var24.aReturningObject();
         var41 = new Vec3d(var10002, 0.0, var10004 * var25.floatValue());
      }

      Vec3d var7 = var41;
      FloatSetting var26 = this.H;
      Float var27 = (Float)var26.aReturningObject();
      double var8 = var27.floatValue();
      int var53 = var4;
      Vec3d var52 = var7;
      Vec3d var47 = var52;
      Vec3d var42 = var52;
      if (var53 == 0) {
         Vec3d var28 = var42;
         double var65;
         int var54 = (var65 = var28.lengthSquared() - var8 * var8) == 0.0 ? 0 : (var65 < 0.0 ? -1 : 1);
         if (var54 > 0) {
            int var56 = var4;
            Vec3d var55 = var7;
            Vec3d var45 = var55;
            Vec3d var43 = var55;
            Vec3d var46;
            if (var56 == 0) {
               Vec3d var57 = var43;
               Vec3d var44 = var57;
               Vec3d var31 = var44;
               double var66;
               int var58 = (var66 = var31.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var66 < 0.0 ? -1 : 1);
               if (var58 > 0) {
                  Vec3d var33 = var7;
                  Vec3d var62 = var33.normalize();
                  double var35 = var8;
                  Vec3d var34 = var62;
                  Vec3d var59 = var34.multiply(var35);
                  var46 = var59;
               } else {
                  var46 = Vec3d.ZERO;
               }
            } else {
               Vec3d var60 = var45;
               var46 = var60;
            }

            var7 = var46;
         }

         Vec3d var39 = var7;
         Vec3d var38 = var5;
         var47 = var38.add(var39);
      }

      return var47;
   }

   private double bReturningDouble(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      var3 = 76073374701881L ^ var3;
      long var5 = var3 ^ 34125532117890L;
      long var7 = var3 ^ 40187674897622L;
      int var10000 = Event.cReturningInt();
      RotationManager var10001 = Prestige.o;
      Object[] var12 = new Object[]{var2, var7};
      RotationManager var11 = var10001;
      Rotation var10 = var11.aReturningdx_C0210(var12);
      int var9 = var10000;
      int var24 = var9;
      Rotation var23 = var10;
      Rotation var22 = var23;
      Rotation var21 = var23;
      if (var24 != 0) {
         Rotation var25 = var21;
         if (var25 == null) {
            return -1.0;
         }

         var22 = var10;
      }

      Object[] var16 = new Object[0];
      Rotation var15 = var22;
      float var27 = var15.aReturningFloat(var16);
      MinecraftClient var17 = b;
      ClientPlayerEntity var18 = var17.player;
      float var28 = var27 - var18.getYaw();
      Object[] var10003 = new Object[]{null, var5};
      var10003[0] = var28;
      Object[] var19 = var10003;
      float var20 = RotationUtil.bReturningFloat(var19);
      return Math.abs(var20);
   }

   private BlockPlacementTarget aReturningai_C0020(Object[] var1) {
      int var356;
      int var357;

      double var363;
      net.minecraft.util.math.Vec3d var364;
      double var377;
      double var380;
      dev.zprestige.prestige.client.modules.AutoObbyCrystal var384;
      double var385;
      double var399;

      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      long var18;
      long var20;
      long var22;
      long var24;
      long var28;
      long var32;
      long var34;
      int var36;
      BlockPos var37;
      Vec3d var38;
      Vec3d var39;
      Vec3d var40;
      Vec3d var41;
      float var42;
      long var337;
      int var350;
      label498: {
         label501: {
            long var2 = (Long)var1[0];
            var337 = 76073374701881L ^ var2;
            long var4 = var337 ^ 73595115346296L;
            var6 = var337 ^ 4877070970100L;
            var8 = var337 ^ 120824297275909L;
            var10 = var337 ^ 88156718821520L;
            var12 = var337 ^ 62434689773628L;
            var14 = var337 ^ 40465793374006L;
            long var16 = var337 ^ 67108860249597L;
            var18 = var337 ^ 126300970949794L;
            var20 = var337 ^ 139590253720973L;
            var22 = var337 ^ 15092325564992L;
            var24 = var337 ^ 111605988914870L;
            long var26 = var337 ^ 25344565925564L;
            var28 = var337 ^ 76353635525337L;
            long var30 = var337 ^ 51911255280218L;
            var32 = var337 ^ 77706785520892L;
            var34 = var337 ^ 121204904411269L;
            var350 = Event.cReturningInt();
            PlayerEntity var73 = this.Z;
            var37 = var73.getBlockPos();
            Object[] var75 = new Object[]{var26};
            var38 = this.dReturningVec3d(var75);
            var36 = var350;
            MinecraftClient var76 = b;
            ClientPlayerEntity var77 = var76.player;
            var39 = var77.getEyePos();
            Object[] var79 = new Object[]{var30};
            var40 = this.eReturningVec3d(var79);
            Object[] var81 = new Object[]{var38, var16};
            var41 = this.fReturningVec3d(var81);
            MinecraftClient var82 = b;
            ClientPlayerEntity var83 = var82.player;
            float var349 = var83.getHealth();
            MinecraftClient var84 = b;
            ClientPlayerEntity var85 = var84.player;
            var42 = var349 + var85.getAbsorptionAmount();
            BooleanSetting var86 = this.B;
            Boolean var87 = (Boolean)var86.aReturningObject();
            var350 = ((((java.lang.Boolean)(var87)).booleanValue() ? 1 : 0));
            if (var36 != 0) {
               if (var350 == 0) {
                  break label501;
               }

               Object[] var90 = new Object[]{var4};
               var350 = (((this.dReturningBoolean(var90)) ? 1 : 0));
            }

            if (var36 == 0) {
               break label498;
            }

            if (var350 != 0) {
               var350 = 1;
               break label498;
            }
         }

         var350 = 0;
      }

      byte var43 = (byte)var350;
      int var351 = 82;
      BlockPlacementTarget var44 = null;
      long var10001 = 7201190933797480303L ^ var337;
      List var93 = this.aj;
      var93.clear();
      Mutable var45 = new Mutable();
      int var46 = -4;

      label486:
      while (true) {
         var351 = var46;

         label483:
         while (var351 <= 4) {
            if (var36 == 0) {
               return var44;
            }

            int var353 = 20641;
            var10001 = 2973600657995724703L ^ var337;
            int var47 = -4;

            label480:
            while (true) {
               var353 = var47;

               label478:
               while (true) {
                  if (var353 > 4) {
                     break label480;
                  }

                  int var355 = 24049;
                  var10001 = 7789018096339057358L ^ var337;
                  var351 = -2;
                  if (var36 == 0) {
                     continue label483;
                  }

                  int var48 = -2;

                  while (var48 <= 2) {
                     int var390 = var37.getX() + var46;
                     int var10002 = var37.getY() + var48;
                     int var100 = var37.getZ() + var47;
                     int var99 = var10002;
                     int var98 = var390;
                     var45.set(var98, var99, var100);
                     double var49 = var45.getX() + 0.5;
                     double var51 = var45.getY() + 0.5;
                     double var53 = var45.getZ() + 0.5;
                     double var404;
                     var353 = (var404 = var39.squaredDistanceTo(var49, var51, var53) - 27.5625) == 0.0 ? 0 : (var404 < 0.0 ? -1 : 1);
                     if (var36 == 0) {
                        continue label478;
                     }

                     label531: {
                        label471: {
                           if (var36 != 0) {
                              if (var353 <= 0) {
                                 break label471;
                              }

                              double var405;
                              var353 = (var405 = var40.squaredDistanceTo(var49, var51, var53) - 27.5625) == 0.0 ? 0 : (var405 < 0.0 ? -1 : 1);
                           }

                           if (var353 > 0) {
                              break label531;
                           }
                        }

                        BlockPos var55;
                        var55 = var45.up();
                        Object[] var121 = new Object[]{var45, Blocks.OBSIDIAN, var8};
                        var356 = (((BlockUtil.bReturningBoolean(var121)) ? 1 : 0));
                        label462:
                        if (var36 != 0) {
                           if (var356 == 0) {
                              Object[] var123 = new Object[]{var45, Blocks.BEDROCK, var8};
                              var356 = (((BlockUtil.bReturningBoolean(var123)) ? 1 : 0));
                              if (var36 == 0) {
                                 break label462;
                              }

                              if (var356 == 0) {
                                 var356 = 0;
                                 break label462;
                              }
                           }

                           var356 = 1;
                        }

                        byte var56;
                        label454: {
                           label508: {
                              var56 = ((byte)(var356));
                              var357 = var56;
                              if (var36 != 0) {
                                 if (var56 == 0) {
                                    break label508;
                                 }

                                 Object[] var128 = new Object[]{var55, var32};
                                 var357 = (((this.gReturningBoolean(var128)) ? 1 : 0));
                              }

                              if (var36 == 0) {
                                 break label454;
                              }

                              if (var357 != 0) {
                                 var357 = 1;
                                 break label454;
                              }
                           }

                           var357 = 0;
                        }

                        byte var57;
                        label509: {
                           var57 = ((byte)(var357));
                           byte var358 = var57;
                           if (var36 != 0) {
                              if (var57 != 0) {
                                 break label509;
                              }

                              MinecraftClient var132 = b;
                              ClientWorld var133 = var132.world;
                              BlockState var135 = var133.getBlockState(var55);
                              var358 = ((byte)((var135.isAir()) ? 1 : 0));
                           }

                           if (var36 != 0) {
                              if (var358 == 0) {
                                 break label531;
                              }

                              Object[] var10005 = new Object[]{null, null, var24};
                              var10005[1] = 2;
                              var10005[0] = var55;
                              Object[] var139 = var10005;
                              var358 = ((byte)((this.iReturningVoid(var139)) ? 1 : 0));
                           }

                           if (var358 != 0) {
                              break label531;
                           }
                        }

                        BlockPos var58;
                        BlockPos var59;
                        Direction var60;
                        Vec3d var61;
                        label431: {
                           label510: {
                              var58 = var45.toImmutable();
                              var59 = null;
                              var60 = null;
                              int var359 = var56;
                              if (var36 != 0) {
                                 if (var56 != 0) {
                                    if (var57 != 0) {
                                       Vec3d var338;
                                       var338 = new Vec3d(var58.getX() + 0.5, var58.getY() + 1.5, var58.getZ() + 0.5);
                                       double var365 = var39.distanceTo(var338);
                                       FloatSetting var149 = this.I;
                                       Float var150 = (Float)var149.aReturningObject();
                                       double var406;
                                       var359 = (var406 = var365 - (var150.floatValue() + 0.5)) == 0.0 ? 0 : (var406 < 0.0 ? -1 : 1);
                                       label421:
                                       if (var36 != 0) {
                                          if (var359 > 0) {
                                             double var367 = var40.distanceTo(var338);
                                             FloatSetting var154 = this.I;
                                             Float var155 = (Float)var154.aReturningObject();
                                             double var407;
                                             var359 = (var407 = var367 - (var155.floatValue() + 0.5)) == 0.0 ? 0 : (var407 < 0.0 ? -1 : 1);
                                             if (var36 == 0) {
                                                break label421;
                                             }

                                             if (var359 > 0) {
                                                break label531;
                                             }
                                          }

                                          BooleanSetting var158 = this.g;
                                          Boolean var159 = (Boolean)var158.aReturningObject();
                                          var359 = ((((java.lang.Boolean)(var159)).booleanValue() ? 1 : 0));
                                       }

                                       if (var359 != 0) {
                                          RotationManager var368 = Prestige.o;
                                          Object[] var161 = new Object[]{var338, var28};
                                          RotationManager var160 = var368;
                                          Rotation var63 = var160.aReturningdx_C0210(var161);
                                          Rotation var369 = var63;
                                          if (var36 != 0) {
                                             if (var63 == null) {
                                                break label531;
                                             }

                                             var369 = var63;
                                          }

                                          Object[] var164 = new Object[0];
                                          Rotation var163 = var369;
                                          float var370 = var163.aReturningFloat(var164);
                                          MinecraftClient var165 = b;
                                          ClientPlayerEntity var166 = var165.player;
                                          float var371 = var370 - var166.getYaw();
                                          Object[] var10003 = new Object[]{null, var20};
                                          var10003[0] = var371;
                                          Object[] var167 = var10003;
                                          float var168 = RotationUtil.bReturningFloat(var167);
                                          float var372 = Math.abs(var168);
                                          FloatSetting var169 = this.s;
                                          Float var170 = (Float)var169.aReturningObject();
                                          if (var372 > var170) {
                                             break label531;
                                          }
                                       }

                                       var61 = var338;
                                       if (var36 != 0) {
                                          break label510;
                                       }
                                    }

                                    Object[] var172 = new Object[]{var58, var22};
                                    var61 = InteractionUtil.aReturningVec3d(var172);
                                    Object var373 = var61;
                                    if (var36 != 0) {
                                       if (var61 == null) {
                                          break label531;
                                       }

                                       BooleanSetting var174 = this.g;
                                       var373 = var174.aReturningObject();
                                    }

                                    Boolean var175 = (Boolean)var373;
                                    boolean var374 = var175;
                                    if (var36 != 0) {
                                       if (!var374) {
                                          break label510;
                                       }

                                       Object[] var178 = new Object[]{var61, var58, var12};
                                       var374 = this.jReturningBoolean(var178);
                                    }

                                    if (!var374) {
                                       break label531;
                                    }
                                    break label510;
                                 }

                                 BooleanSetting var180 = this.z;
                                 Boolean var181 = (Boolean)var180.aReturningObject();
                                 var359 = ((((java.lang.Boolean)(var181)).booleanValue() ? 1 : 0));
                              }

                              if (var36 != 0) {
                                 if (var359 != 0) {
                                    break label531;
                                 }

                                 Object[] var183 = new Object[]{var58, var6};
                                 var359 = (((BlockUtil.eReturningBoolean(var183)) ? 1 : 0));
                              }

                              if (var36 != 0) {
                                 if (var359 != 0) {
                                    break label531;
                                 }

                                 Object[] var401 = new Object[]{null, null, var24};
                                 var401[1] = 1;
                                 var401[0] = var58;
                                 Object[] var186 = var401;
                                 var359 = (((this.iReturningVoid(var186)) ? 1 : 0));
                              }

                              if (var359 != 0) {
                                 break label531;
                              }

                              var61 = null;
                              double var62 = Double.MAX_VALUE;

                              label514: {
                                 for (Direction var67 : Direction.values()) {
                                    BlockPos var68 = var58.offset(var67);
                                    MinecraftClient var190 = b;
                                    ClientWorld var191 = var190.world;
                                    BlockState var193 = var191.getBlockState(var68);
                                    var359 = (((var193.isReplaceable()) ? 1 : 0));
                                    if (var36 == 0) {
                                       break label514;
                                    }

                                    label400:
                                    if (var359 == 0) {
                                       Direction var69;
                                       Vec3d var70;
                                       double var71;
                                       var69 = var67.getOpposite();
                                       Vec3d var361 = var68.toCenterPos();
                                       double var391 = var69.getOffsetX() * 0.5;
                                       double var205 = var69.getOffsetZ() * 0.5;
                                       double var203 = var69.getOffsetY() * 0.5;
                                       double var201 = var391;
                                       Vec3d var200 = var361;
                                       var70 = var200.add(var201, var203, var205);
                                       var71 = var39.distanceTo(var70);
                                       double var408;
                                       var359 = (var408 = var71 - 4.25) == 0.0 ? 0 : (var408 < 0.0 ? -1 : 1);
                                       label398:
                                       if (var36 != 0) {
                                          if (var359 > 0) {
                                             double var409;
                                             var359 = (var409 = var40.distanceTo(var70) - 4.25) == 0.0 ? 0 : (var409 < 0.0 ? -1 : 1);
                                             if (var36 == 0) {
                                                break label398;
                                             }

                                             if (var359 > 0) {
                                                break label400;
                                             }
                                          }

                                          BooleanSetting var214 = this.g;
                                          Boolean var215 = (Boolean)var214.aReturningObject();
                                          var359 = ((((java.lang.Boolean)(var215)).booleanValue() ? 1 : 0));
                                       }

                                       label517: {
                                          label388:
                                          if (var36 != 0) {
                                             if (var359 != 0) {
                                                Object[] var218 = new Object[]{var70, var68, var12};
                                                var359 = (((this.jReturningBoolean(var218)) ? 1 : 0));
                                                if (var36 == 0) {
                                                   break label388;
                                                }

                                                if (var359 == 0) {
                                                   break label400;
                                                }
                                             }

                                             var363 = var71;
                                             if (var36 == 0) {
                                                break label517;
                                             }

                                             double var410;
                                             var359 = (var410 = var71 - var62) == 0.0 ? 0 : (var410 < 0.0 ? -1 : 1);
                                          }

                                          if (var359 >= 0) {
                                             break label400;
                                          }

                                          var363 = var71;
                                       }

                                       var62 = var363;
                                       var59 = var68;
                                       var60 = var69;
                                       var61 = var70;
                                    }

                                    if (var36 == 0) {
                                       break;
                                    }
                                 }

                                 if (var59 == null) {
                                    break label531;
                                 }

                                 var364 = var39;
                                 if (var36 == 0) {
                                    break label431;
                                 }

                                 Vec3d var392 = var58.toCenterPos();
                                 double var227 = 0.5;
                                 Vec3d var224 = var392;
                                 Vec3d var232 = var224.add(var225, var227, var229);
                                 double var411;
                                 var359 = (var411 = var39.distanceTo(var232) - 4.25) == 0.0 ? 0 : (var411 < 0.0 ? -1 : 1);
                              }

                              if (var359 > 0) {
                                 var364 = var40;
                                 if (var36 == 0) {
                                    break label431;
                                 }

                                 Vec3d var393 = var58.toCenterPos();
                                 double var239 = 0.5;
                                 Vec3d var236 = var393;
                                 Vec3d var244 = var236.add(var237, var239, var241);
                                 if (var40.distanceTo(var244) > 4.25) {
                                    break label531;
                                 }
                              }
                           }

                           var364 = new Vec3d(var58.getX() + 0.5, var58.getY() + 1.0, var58.getZ() + 0.5);
                        }

                        Vec3d var339;
                        double var341;
                        label519: {
                           var339 = var364;
                           ExplosionDamageUtil var375 = Prestige.f;
                           PlayerEntity var394 = this.Z;
                           Object[] var10008 = new Object[]{null, null, null, null, null, var18};
                           var10008[4] = false;
                           var10008[3] = var58;
                           var10008[2] = false;
                           var10008[1] = var339;
                           var10008[0] = var394;
                           Object[] var251 = var10008;
                           ExplosionDamageUtil var250 = var375;
                           double var340 = var250.bReturningDouble(var251);
                           var341 = var340;
                           var355 = var43;
                           label336:
                           if (var36 != 0) {
                              if (var43 != 0) {
                                 FloatSetting var253 = this.c;
                                 Float var254 = (Float)var253.aReturningObject();
                                 double var412;
                                 var355 = (var412 = var340 - var254.floatValue()) == 0.0 ? 0 : (var412 < 0.0 ? -1 : 1);
                                 if (var36 == 0) {
                                    break label336;
                                 }

                                 if (var355 < 0) {
                                    var10008 = new Object[]{null, null, null, null, var34};
                                    var10008[3] = var340;
                                    var10008[2] = var58;
                                    var10008[1] = var38;
                                    var10008[0] = var339;
                                    Object[] var258 = var10008;
                                    double var261 = this.aReturningDouble(var258);
                                    var341 = Math.max(var340, var261);
                                 }
                              }

                              var377 = var341;
                              if (var36 == 0) {
                                 break label519;
                              }

                              FloatSetting var263 = this.c;
                              Float var264 = (Float)var263.aReturningObject();
                              double var413;
                              var355 = (var413 = var341 - var264.floatValue()) == 0.0 ? 0 : (var413 < 0.0 ? -1 : 1);
                           }

                           if (var355 < 0) {
                              break label531;
                           }

                           ExplosionDamageUtil var378 = Prestige.f;
                           MinecraftClient var266 = b;
                           ClientPlayerEntity var395 = var266.player;
                           var10008 = new Object[]{null, null, null, null, null, var18};
                           var10008[4] = false;
                           var10008[3] = var58;
                           var10008[2] = false;
                           var10008[1] = var339;
                           var10008[0] = var395;
                           Object[] var268 = var10008;
                           ExplosionDamageUtil var267 = var378;
                           var377 = var267.bReturningDouble(var268);
                        }

                        double var342 = var377;
                        FloatSetting var269 = this.d;
                        Float var270 = (Float)var269.aReturningObject();
                        double var414;
                        var355 = (var414 = var342 - var270.floatValue()) == 0.0 ? 0 : (var414 < 0.0 ? -1 : 1);
                        if (var36 != 0) {
                           if (var355 > 0) {
                              break label531;
                           }

                           BooleanSetting var272 = this.e;
                           Boolean var273 = (Boolean)var272.aReturningObject();
                           var355 = ((((java.lang.Boolean)(var273)).booleanValue() ? 1 : 0));
                        }

                        label318: {
                           label317: {
                              if (var36 != 0) {
                                 if (var355 == 0) {
                                    break label317;
                                 }

                                 var380 = var342;
                                 if (var36 == 0) {
                                    break label318;
                                 }

                                 double var415;
                                 var355 = (var415 = var342 - (var42 - 1.0F)) == 0.0 ? 0 : (var415 < 0.0 ? -1 : 1);
                              }

                              if (var355 >= 0) {
                                 break label531;
                              }
                           }

                           var380 = var341;
                        }

                        double var343;
                        label306: {
                           var343 = var380;
                           double var381 = var341;
                           PlayerEntity var277 = this.Z;
                           float var396 = var277.getHealth();
                           PlayerEntity var278 = this.Z;
                           double var397 = var396 + var278.getAbsorptionAmount();
                           if (var36 != 0) {
                              if (!(var341 >= var397)) {
                                 break label306;
                              }

                              var381 = var343;
                              var397 = 50.0;
                           }

                           var343 = var381 + var397;
                        }

                        label300: {
                           Object var382 = var41;
                           if (var36 != 0) {
                              if (var41 != null) {
                                 Vec3d var345 = var38.subtract(var339);
                                 var345 = new Vec3d(var345.x, 0.0, var345.z);
                                 double var416;
                                 var355 = (var416 = var345.lengthSquared() - 1.0E-4) == 0.0 ? 0 : (var416 < 0.0 ? -1 : 1);
                                 if (var36 == 0) {
                                    break label300;
                                 }

                                 if (var355 > 0) {
                                    FloatSetting var288 = this.u;
                                    Float var289 = (Float)var288.aReturningObject();
                                    double var398 = var289.floatValue() * 8.0;
                                    Vec3d var291 = var345.normalize();
                                    double var295 = var291.dotProduct(var41);
                                    var343 += var398 * Math.max(var293, var295);
                                 }
                              }

                              BooleanSetting var297 = this.x;
                              var382 = var297.aReturningObject();
                           }

                           Boolean var298 = (Boolean)var382;
                           var355 = ((((java.lang.Boolean)(var298)).booleanValue() ? 1 : 0));
                        }

                        label291:
                        if (var36 != 0) {
                           if (var355 != 0) {
                              Object[] var301 = new Object[]{var58, var37, var10};
                              var355 = (((this.kReturningBoolean(var301)) ? 1 : 0));
                              if (var36 == 0) {
                                 break label291;
                              }

                              if (var355 != 0) {
                                 var343 += 3.0;
                              }
                           }

                           var355 = var56;
                        }

                        label284: {
                           label523: {
                              label524: {
                                 label281:
                                 if (var36 != 0) {
                                    if (var355 != 0) {
                                       BooleanSetting var305 = this.y;
                                       Boolean var306 = (Boolean)var305.aReturningObject();
                                       var355 = ((((java.lang.Boolean)(var306)).booleanValue() ? 1 : 0));
                                       if (var36 == 0) {
                                          break label281;
                                       }

                                       if (var355 != 0) {
                                          var343 += var57 != 0 ? 8.0 : 4.0;
                                       }
                                    }

                                    var384 = this;
                                    if (var36 == 0) {
                                       break label524;
                                    }

                                    FloatSetting var311 = this.v;
                                    Float var312 = (Float)var311.aReturningObject();
                                    float var417;
                                    var355 = (var417 = var312 - 0.0F) == 0.0F ? 0 : (var417 < 0.0F ? -1 : 1);
                                 }

                                 if (var355 <= 0) {
                                    break label523;
                                 }

                                 var384 = this;
                              }

                              Object[] var315 = new Object[]{var61, var14};
                              AutoObbyCrystal var314 = var384;
                              double var347 = var314.bReturningDouble(var315);
                              var385 = var347;
                              var399 = 0.0;
                              if (var36 == 0) {
                                 break label284;
                              }

                              if (var347 >= 0.0) {
                                 FloatSetting var317 = this.v;
                                 Float var318 = (Float)var317.aReturningObject();
                                 double var400 = var318.floatValue();
                                 FloatSetting var319 = this.w;
                                 Float var320 = (Float)var319.aReturningObject();
                                 double var323 = var320.floatValue();
                                 var343 -= var400 * Math.min(var347, var323);
                              }
                           }

                           var385 = var343;
                           var399 = 0.2 * var39.distanceTo(var61);
                        }

                        var343 = var385 - var399;
                        BlockPlacementTarget var348 = new BlockPlacementTarget(var58, var59, var60, var61, var56 == 0, dev.prestige.recovery.SourceSupport.asBoolean(var57), var343);
                        List var328 = this.aj;
                        var328.add(var348);
                        BlockPlacementTarget var386 = var44;
                        if (var36 != 0) {
                           if (var44 != null && !(var343 > var44.g)) {
                              break label531;
                           }

                           var386 = var348;
                        }

                        var44 = var386;
                     }

                     var48++;
                     if (var36 == 0) {
                        break;
                     }
                  }

                  var47++;
                  if (var36 == 0) {
                     break label480;
                  }
                  break;
               }
            }

            var46++;
            if (var36 != 0) {
               continue label486;
            }
            break;
         }

         List var387 = this.aj;
         ToDoubleFunction var333 = invokeBinding37();
         Comparator var334 = Comparator.comparingDouble(var333);
         Comparator var336 = var334.reversed();
         List var335 = var387;
         var335.sort(var336);
         return var44;
      }
   }

   private boolean jReturningBoolean(Object[] var1) {
      Vec3d var4 = (Vec3d)var1[0];
      BlockPos var5 = (BlockPos)var1[1];
      long var2 = (Long)var1[2];
      var2 = 76073374701881L ^ var2;
      long var6 = var2 ^ 3351693761672L;
      long var8 = var2 ^ 62165166459868L;
      long var10 = var2 ^ 80091666811149L;
      int var10000 = Event.cReturningInt();
      RotationManager var10001 = Prestige.o;
      Object[] var17 = new Object[]{var4, var8};
      RotationManager var16 = var10001;
      Rotation var13 = var16.aReturningdx_C0210(var17);
      int var12 = var10000;
      int var52 = var12;
      Rotation var51 = var13;
      Rotation var41 = var51;
      Rotation var40 = var51;
      if (var52 != 0) {
         Rotation var53 = var40;
         if (var53 == null) {
            return false;
         }

         var41 = var13;
      }

      Rotation var45;
      label57: {
         Object[] var21 = new Object[0];
         Rotation var20 = var41;
         float var70 = var20.aReturningFloat(var21);
         MinecraftClient var22 = b;
         ClientPlayerEntity var23 = var22.player;
         float var71 = var70 - var23.getYaw();
         Object[] var10003 = new Object[]{null, var6};
         var10003[0] = var71;
         Object[] var24 = var10003;
         float var25 = RotationUtil.bReturningFloat(var24);
         float var72 = Math.abs(var25);
         FloatSetting var26 = this.s;
         Float var27 = (Float)var26.aReturningObject();
         float var76;
         var10000 = (var76 = var72 - var27) == 0.0F ? 0 : (var76 < 0.0F ? -1 : 1);
         int var55 = var12;
         int var54 = var10000;
         int var44 = var54;
         int var42 = var54;
         if (var55 != 0) {
            int var56 = var42;
            if (var56 > 0) {
               return false;
            }

            int var58 = var12;
            Rotation var57 = var13;
            var45 = var57;
            Rotation var43 = var57;
            if (var58 == 0) {
               break label57;
            }

            Object[] var31 = new Object[0];
            Rotation var30 = var43;
            byte var59 = ((byte)((var30.aReturningBoolean(var31)) ? 1 : 0));
            var44 = var59;
         }

         int var60 = var44;
         if (var60 != 0) {
            return true;
         }

         var45 = var13;
      }

      Object[] var34 = new Object[]{var45, var10};
      HitResult var14 = RotationUtil.aReturningHitResult(var34);
      int var62 = var12;
      HitResult var61 = var14;
      HitResult var47 = var61;
      HitResult var46 = var61;
      if (var62 != 0) {
         boolean var63 = var46 instanceof BlockHitResult;
         if (!var63) {
            return false;
         }

         HitResult var64 = var14;
         var47 = var64;
      }

      BlockHitResult var15 = (BlockHitResult)var47;
      BlockHitResult var37 = var15;
      BlockPos var74 = var37.getBlockPos();
      BlockPos var39 = var5;
      BlockPos var38 = var74;
      boolean var75 = var38.equals(var39);
      int var66 = var12;
      boolean var65 = var75;
      boolean var49 = var65;
      boolean var48 = var65;
      return var66 == 0 ? var49 : var48;
   }

   private Vec3d fReturningVec3d(Object[] var1) {
      Vec3d var4 = (Vec3d)var1[0];
      long var2 = (Long)var1[1];
      var2 = 76073374701881L ^ var2;
      long var5 = var2 ^ 105669548065123L;
      long var7 = var2 ^ 46441159652627L;
      int var10000 = Event.bReturningInt();
      ModeSetting var15 = this.t;
      String var10 = (String)var15.aReturningObject();
      int var9 = var10000;
      int var83 = var9;
      String var82 = var10;
      String var62 = var82;
      String var61 = var82;
      if (var83 == 0) {
         short var10001 = 11463;
         long var10002 = 2819361548422268852L ^ var2;
         String var17 = "None";
         String var16 = var61;
         boolean var84 = var16.equals(var17);
         if (var84) {
            return null;
         }

         var62 = var10;
      }

      int var70;
      String var11 = var62;
      // String var20 = var11;
      var10000 = var20.hashCode();
      int var86 = var9;
      int var85 = var10000;
      var70 = var85;
      int var63 = var85;
      label90:
      if (var86 == 0) {
         int var87 = var63;
         switch (var87) {
            case -2071398544:
               short var131 = 4938;
               long var134 = 5327093324284459047L ^ var2;
               String var23 = "Away From Self";
               String var22 = var11;
               byte var127 = ((byte)((var22.equals(var23)) ? 1 : 0));
               int var89 = var9;
               byte var88 = var127;
               var70 = var88;
               byte var64 = var88;
               if (var89 != 0) {
                  break label90;
               }

               byte var90 = var64;
               byte var65 = var90;
               byte var91 = var65;
               if (var91 == 0) {
                  break;
               }

               var12 = 0;
               int var92 = var9;
               if (var92 == 0) {
                  break;
               }
            case 242606366:
               short var132 = 14746;
               long var135 = 2326486831036322545L ^ var2;
               String var27 = "Toward Center";
               String var26 = var11;
               byte var128 = ((byte)((var26.equals(var27)) ? 1 : 0));
               int var94 = var9;
               byte var93 = var128;
               var70 = var93;
               byte var66 = var93;
               if (var94 != 0) {
                  break label90;
               }

               byte var95 = var66;
               byte var67 = var95;
               byte var96 = var67;
               if (var96 == 0) {
                  break;
               }

               var12 = 1;
               int var97 = var9;
               if (var97 == 0) {
                  break;
               }
            case 1242867657:
               short var133 = 24601;
               long var136 = 4719424677853924204L ^ var2;
               String var31 = "Toward Hole";
               String var30 = var11;
               byte var129 = ((byte)((var30.equals(var31)) ? 1 : 0));
               int var99 = var9;
               byte var98 = var129;
               var70 = var98;
               byte var68 = var98;
               if (var99 != 0) {
                  break label90;
               }

               byte var100 = var68;
               byte var69 = var100;
               byte var101 = var69;
               if (var101 != 0) {
                  var12 = 2;
               }
         }

         var70 = var12;
      }

      int var102 = var70;
      switch (var102) {
         case 0:
            Object[] var34 = new Object[]{var5};
            Vec3d var36 = RaycastUtil.bReturningVec3d(var34);
            Vec3d var35 = var4;
            Vec3d var123 = var35.subtract(var36);
            Vec3d var37 = var123;
            Vec3d var38 = var123;
            var123 = new Vec3d(var37.x, 0.0, var38.z);
            int var104 = var9;
            Vec3d var103 = var123;
            Vec3d var72 = var103;
            Vec3d var71 = var103;
            Vec3d var73;
            if (var104 == 0) {
               Vec3d var39 = var71;
               double var140;
               int var105 = (var140 = var39.lengthSquared() - 1.0E-4) == 0.0 ? 0 : (var140 < 0.0 ? -1 : 1);
               if (var105 > 0) {
                  Vec3d var41 = var123;
                  Vec3d var106 = var41.normalize();
                  var73 = var106;
               } else {
                  var73 = null;
               }
            } else {
               Vec3d var107 = var72;
               var73 = var107;
            }

            return var73;
         case 1:
            Vec3d var43 = var4;
            double var137 = -var43.x;
            Vec3d var44 = var4;
            Vec3d var122 = new Vec3d(var137, 0.0, -var44.z);
            int var109 = var9;
            Vec3d var108 = var122;
            Vec3d var75 = var108;
            Vec3d var74 = var108;
            Vec3d var76;
            if (var109 == 0) {
               Vec3d var45 = var74;
               double var139;
               int var110 = (var139 = var45.lengthSquared() - 1.0E-4) == 0.0 ? 0 : (var139 < 0.0 ? -1 : 1);
               if (var110 > 0) {
                  Vec3d var47 = var122;
                  Vec3d var111 = var47.normalize();
                  var76 = var111;
               } else {
                  var76 = null;
               }
            } else {
               Vec3d var112 = var75;
               var76 = var112;
            }

            return var76;
         case 2:
            Object[] var50 = new Object[]{var7};
            AutoObbyCrystal var49 = this;
            BlockPos var13 = var49.aReturningBlockPos(var50);
            int var114 = var9;
            BlockPos var113 = var13;
            BlockPos var78 = var113;
            BlockPos var77 = var113;
            if (var114 == 0) {
               BlockPos var115 = var77;
               if (var115 == null) {
                  return null;
               }

               var78 = var13;
            }

            BlockPos var53 = var78;
            Vec3d var130 = var53.toCenterPos();
            Vec3d var55 = var4;
            Vec3d var54 = var130;
            Vec3d var14 = var54.subtract(var55);
            Vec3d var56 = var14;
            Vec3d var57 = var14;
            var14 = new Vec3d(var56.x, 0.0, var57.z);
            int var117 = var9;
            Vec3d var116 = var14;
            Vec3d var80 = var116;
            Vec3d var79 = var116;
            Vec3d var81;
            if (var117 == 0) {
               Vec3d var58 = var79;
               double var138;
               int var118 = (var138 = var58.lengthSquared() - 1.0E-4) == 0.0 ? 0 : (var138 < 0.0 ? -1 : 1);
               if (var118 > 0) {
                  Vec3d var60 = var14;
                  Vec3d var119 = var60.normalize();
                  var81 = var119;
               } else {
                  var81 = null;
               }
            } else {
               Vec3d var120 = var80;
               var81 = var120;
            }

            return var81;
         default:
            return null;
      }
   }

   private BlockPos aReturningBlockPos(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 21284163492890L;
      PlayerEntity var19 = this.Z;
      BlockPos var7 = var19.getBlockPos();
      int var10000 = Event.bReturningInt();
      BlockPos var8 = null;
      double var9 = Double.MAX_VALUE;
      Mutable var11 = new Mutable();
      int var6 = var10000;
      short var108 = 31063;
      long var10001 = 5286827937636773505L ^ var2;
      int var12 = -6;

      while (true) {
         int var53 = var12;

         label114:
         while (true) {
            short var114 = 11202;
            long var10002 = 2863931144141618198L ^ var2;
            byte var71 = 6;
            int var70 = var53;
            if (var70 > var71) {
               return var8;
            }

            var108 = 12197;
            var10001 = 232458283751356537L ^ var2;
            int var13 = -6;

            int var104;
            do {
               short var116 = 12463;
               var10002 = 5066232580229834618L ^ var2;
               byte var73 = 6;
               int var72 = var13;
               if (var72 > var73) {
                  break;
               }

               BlockPos var20 = var7;
               int var117 = var20.getX() + var12;
               BlockPos var21 = var7;
               int var119 = var21.getY();
               BlockPos var22 = var7;
               int var26 = var22.getZ() + var13;
               int var25 = var119;
               int var24 = var117;
               Mutable var23 = var11;
               var23.set(var24, var25, var26);
               int var74 = var6;
               label108:
               if (var74 == 0) {
                  MinecraftClient var27 = b;
                  Mutable var29 = var11;
                  ClientWorld var28 = var27.world;
                  BlockState var30 = var28.getBlockState((BlockPos)var29);
                  int var110 = (((var30.isAir()) ? 1 : 0));
                  int var76 = var6;
                  byte var75 = (byte)var110;
                  var53 = var75;
                  byte var54 = var75;
                  if (var76 != 0) {
                     continue label114;
                  }

                  byte var77 = var54;
                  byte var55 = var77;
                  byte var78 = var55;
                  label105:
                  if (var78 != 0) {
                     MinecraftClient var32 = b;
                     ClientWorld var111 = var32.world;
                     Mutable var33 = var11;
                     BlockPos var35 = var33.up();
                     ClientWorld var34 = var111;
                     BlockState var36 = var34.getBlockState(var35);
                     var110 = (((var36.isAir()) ? 1 : 0));
                     int var80 = var6;
                     byte var79 = ((byte)(var110));
                     byte var58 = var79;
                     byte var56 = var79;
                     if (var80 == 0) {
                        byte var81 = var56;
                        byte var57 = var81;
                        byte var82 = var57;
                        if (var82 == 0) {
                           break label105;
                        }

                        Mutable var39 = var11;
                        Object[] var40 = new Object[]{var39.down(), var4};
                        var58 = ((byte)((BlockUtil.eReturningBoolean(var40)) ? 1 : 0));
                     }

                     int var84 = var6;
                     byte var83 = var58;
                     byte var60 = var83;
                     byte var59 = var83;
                     if (var84 == 0) {
                        byte var85 = var59;
                        if (var85 == 0) {
                           break label105;
                        }

                        var60 = 1;
                     }

                     int var14 = var60;
                     Direction[] var15 = Direction.values();
                     int var16 = var15.length;
                     int var67;
                     label92: {
                        int var98;
                        do {
                           int var87 = var16;
                           int var86 = var17;
                           if (var86 >= var87) {
                              break;
                           }

                           Direction var18 = var15[var17];
                           Direction var42 = var18;
                           var110 = var42.getOffsetY();
                           int var89 = var6;
                           int var88 = var110;
                           var67 = var88;
                           int var61 = var88;
                           if (var89 != 0) {
                              break label92;
                           }

                           label125: {
                              int var91 = var6;
                              int var90 = var61;
                              int var64 = var90;
                              int var62 = var90;
                              if (var91 == 0) {
                                 int var92 = var62;
                                 int var63 = var92;
                                 int var93 = var63;
                                 if (var93 != 0) {
                                    break label125;
                                 }

                                 Direction var46 = var18;
                                 Mutable var45 = var11;
                                 Object[] var47 = new Object[]{var45.offset(var46), var4};
                                 var64 = (((BlockUtil.eReturningBoolean(var47)) ? 1 : 0));
                              }

                              int var95 = var6;
                              int var94 = var64;
                              int var66 = var94;
                              int var65 = var94;
                              if (var95 == 0) {
                                 int var96 = var65;
                                 if (var96 != 0) {
                                    break label125;
                                 }

                                 var66 = 0;
                              }

                              var14 = var66;
                              int var97 = var6;
                              if (var97 == 0) {
                                 break;
                              }
                           }

                           var17++;
                           var98 = var6;
                        } while (var98 == 0);

                        var67 = var14;
                     }

                     int var100 = var6;
                     int var99 = var67;
                     int var69 = var99;
                     int var68 = var99;
                     if (var100 == 0) {
                        int var101 = var68;
                        if (var101 == 0) {
                           break label105;
                        }

                        var69 = var12 * var12 + var13 * var13;
                     }

                     double var107 = var69;
                     int var102 = var6;
                     if (var102 != 0) {
                        break label108;
                     }

                     double var120;
                     int var103 = (var120 = var107 - var9) == 0.0 ? 0 : (var120 < 0.0 ? -1 : 1);
                     if (var103 < 0) {
                        var9 = var107;
                        Mutable var52 = var11;
                        var8 = var52.toImmutable();
                     }
                  }

                  var13++;
               }

               var104 = var6;
            } while (var104 == 0);

            var12++;
            int var105 = var6;
            if (var105 != 0) {
               return var8;
            }
            break;
         }
      }
   }

   private boolean kReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      BlockPos var5 = (BlockPos)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 76073374701881L ^ var3;
      int var6 = Event.cReturningInt();
      BlockPos var7 = var2;
      int var39 = var7.getY();
      BlockPos var8 = var5;
      int var10001 = var8.getY();
      int var28 = var6;
      int var27 = var10001;
      int var26 = var39;
      int var22 = var26;
      int var23 = var27;
      int var18 = var26;
      int var19 = var27;
      if (var28 != 0) {
         int var30 = var19;
         int var29 = var18;
         if (var29 != var30) {
            return false;
         }

         BlockPos var10 = var2;
         int var40 = var10.getX();
         BlockPos var11 = var5;
         int var12 = var40 - var11.getX();
         int var41 = Math.abs(var12);
         BlockPos var13 = var2;
         var10001 = var13.getZ();
         BlockPos var14 = var5;
         int var15 = var10001 - var14.getZ();
         int var17 = Math.abs(var15);
         int var16 = var41;
         int var42 = Math.max(var16, var17);
         int var32 = var6;
         int var31 = var42;
         int var24 = var31;
         int var20 = var31;
         if (var32 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var24);
         }

         int var33 = var20;
         int var21 = var33;
         byte var35 = 1;
         int var34 = var21;
         var22 = var34;
         var23 = var35;
      }

      int var37 = var23;
      int var36 = var22;
      if (var36 == var37) {
         byte var44 = 1;
         return dev.prestige.recovery.SourceSupport.asBoolean(var44);
      } else {
         return false;
      }
   }

   private EndCrystalEntity aReturningEndCrystalEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 51442382745884L;
      long var6 = var2 ^ 96960721243819L;
      long var8 = var2 ^ 94966954885710L;
      int var10000 = Event.cReturningInt();
      this.ah = dev.prestige.recovery.SourceSupport.asBoolean(0);
      int var10 = var10000;
      int var80 = var10;
      AutoObbyCrystal var79 = this;
      AutoObbyCrystal var64 = var79;
      AutoObbyCrystal var63 = var79;
      if (var80 != 0) {
         BlockPos var81 = var63.aa;
         if (var81 == null) {
            return null;
         }

         AutoObbyCrystal var82 = this;
         var64 = var82;
      }

      int var84 = var10;
      AutoObbyCrystal var83 = var64;
      AutoObbyCrystal var66 = var83;
      AutoObbyCrystal var65 = var83;
      if (var84 != 0) {
         BlockPos var22 = this.aa;
         Object[] var24 = new Object[]{var22.up(), var8};
         AutoObbyCrystal var23 = var65;
         boolean var85 = var23.gReturningBoolean(var24);
         if (!var85) {
            return null;
         }

         var66 = this;
      }

      BlockPos var27 = var66.aa;
      BlockPos var28 = var27.up();
      Vec3d var11 = var28.toCenterPos();
      MinecraftClient var29 = b;
      ClientPlayerEntity var30 = var29.player;
      Vec3d var12 = var30.getEyePos();
      BlockPos var31 = this.aa;
      Box var112 = new Box(var31.up());
      double var33 = 1.5;
      Box var32 = var112;
      Box var13 = var32.expand(var33);
      MinecraftClient var35 = b;
      ClientWorld var113 = var35.world;
      Predicate var39 = invokeBinding38();
      Box var38 = var13;
      Object var37 = null;
      ClientWorld var36 = var113;
      List var40 = var36.getOtherEntities((Entity)var37, var38, var39);
      Iterator var14 = var40.iterator();

      EndCrystalEntity var16;
      int var110;
      do {
         EndCrystalEntity var78;
         while (true) {
            int var70;
            while (true) {
               Entity var68;
               while (true) {
                  Iterator var41 = var14;
                  boolean var86 = var41.hasNext();
                  if (!var86) {
                     return null;
                  }

                  Iterator var42 = var14;
                  Entity var15 = (Entity)var42.next();
                  int var88 = var10;
                  Entity var87 = var15;
                  var68 = var87;
                  Entity var67 = var87;
                  if (var88 == 0) {
                     break;
                  }

                  boolean var89 = var67 instanceof EndCrystalEntity;
                  if (var89) {
                     var68 = var15;
                     break;
                  }
               }

               var16 = (EndCrystalEntity)var68;
               EndCrystalEntity var44 = var16;
               byte var114 = ((byte)((var44.isAlive()) ? 1 : 0));
               int var91 = var10;
               byte var90 = var114;
               var70 = var90;
               byte var69 = var90;
               if (var91 == 0) {
                  break;
               }

               byte var92 = var69;
               if (var92 != 0) {
                  EndCrystalEntity var46 = var16;
                  var70 = var46.getId();
                  break;
               }
            }

            int var77;
            label101: {
               int var95 = var10;
               int var94 = this.ai;
               int var93 = var70;
               int var74 = var93;
               int var75 = var94;
               int var71 = var93;
               int var72 = var94;
               if (var95 != 0) {
                  int var97 = var72;
                  int var96 = var71;
                  if (var96 == var97) {
                     continue;
                  }

                  EndCrystalEntity var48 = var16;
                  int var99 = var10;
                  int var98 = var48.age;
                  var77 = var98;
                  int var73 = var98;
                  if (var99 == 0) {
                     break label101;
                  }

                  byte var101 = 2;
                  int var100 = var73;
                  var74 = var100;
                  var75 = var101;
               }

               int var103 = var75;
               int var102 = var74;
               if (var102 < var103) {
                  continue;
               }

               int var105 = var10;
               EndCrystalEntity var104 = var16;
               var78 = var104;
               EndCrystalEntity var76 = var104;
               if (var105 == 0) {
                  break;
               }

               Object[] var50 = new Object[]{var76, var6};
               Vec3d var115 = RaycastUtil.aReturningVec3d(var50);
               Vec3d var52 = var11;
               Vec3d var51 = var115;
               double var116;
               int var106 = (var116 = var51.distanceTo(var52) - 1.0) == 0.0 ? 0 : (var116 < 0.0 ? -1 : 1);
               var77 = var106;
            }

            int var107 = var77;
            if (var107 <= 0) {
               var78 = var16;
               break;
            }
         }

         EndCrystalEntity var54 = var78;
         Box var17 = var54.getBoundingBox();
         Object[] var55 = new Object[]{var17, var12, var4};
         double var18 = cReturningDouble(var55);
         Vec3d var108 = this.ak;
         if (var108 != null) {
            Object[] var56 = new Object[]{var17, this.ak, var4};
            double var59 = cReturningDouble(var56);
            double var57 = var18;
            var18 = Math.max(var57, var59);
         }

         FloatSetting var61 = this.I;
         Float var62 = (Float)var61.aReturningObject();
         double var117;
         int var109 = (var117 = var18 - var62.floatValue()) == 0.0 ? 0 : (var117 < 0.0 ? -1 : 1);
         if (var109 <= 0) {
            break;
         }

         this.ah = dev.prestige.recovery.SourceSupport.asBoolean(1);
         var110 = var10;
      } while (var110 != 0);

      return var16;
   }

   private static double cReturningDouble(Object[] var0) {
      Box var1 = (Box)var0[0];
      Vec3d var2 = (Vec3d)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 76073374701881L ^ var3;
      Box var11 = var1;
      Vec3d var12 = var2;
      double var49 = var11.minX - var12.x;
      Vec3d var13 = var2;
      Box var14 = var1;
      double var17 = var13.x - var14.maxX;
      double var21 = Math.max(var15, var17);
      double var19 = var49;
      double var5 = Math.max(var19, var21);
      Box var23 = var1;
      Vec3d var24 = var2;
      double var50 = var23.minY - var24.y;
      Vec3d var25 = var2;
      Box var26 = var1;
      double var29 = var25.y - var26.maxY;
      double var33 = Math.max(var27, var29);
      double var31 = var50;
      double var7 = Math.max(var31, var33);
      Box var35 = var1;
      Vec3d var36 = var2;
      double var51 = var35.minZ - var36.z;
      Vec3d var37 = var2;
      Box var38 = var1;
      double var41 = var37.z - var38.maxZ;
      double var45 = Math.max(var39, var41);
      double var43 = var51;
      double var9 = Math.max(var43, var45);
      double var47 = var5 * var5 + var7 * var7 + var9 * var9;
      return Math.sqrt(var47);
   }

   private boolean lReturningBoolean(Object[] var1) {
      Box var6 = (Box)var1[0];
      Vec3d var3 = (Vec3d)var1[1];
      Rotation var2 = (Rotation)var1[2];
      long var4 = (Long)var1[3];
      var4 = 76073374701881L ^ var4;
      long var7 = var4 ^ 66302359809958L;
      Object[] var10 = new Object[]{var2, var7};
      Vec3d var10001 = RotationUtil.aReturningVec3d(var10);
      double var12 = 6.0;
      Vec3d var11 = var10001;
      Vec3d var15 = var11.multiply(var12);
      Vec3d var14 = var3;
      Vec3d var9 = var14.add(var15);
      Vec3d var18 = var9;
      Vec3d var17 = var3;
      Box var16 = var6;
      Optional var10000 = var16.raycast(var17, var18);
      Function var20 = invokeBinding39(this, var3);
      Optional var19 = var10000;
      var10000 = var19.map(var20);
      byte var27 = 0;
      Boolean var23 = false;
      Optional var22 = var10000;
      Boolean var24 = ((java.lang.Boolean)(Object)(var22.orElse(var23)));
      return var24;
   }

   private boolean mReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 131745438840348L;
      int var6 = Event.bReturningInt();
      int var30 = var6;
      PlayerEntity var29 = this.Z;
      PlayerEntity var21 = var29;
      PlayerEntity var20 = var29;
      if (var30 == 0) {
         PlayerEntity var31 = var20;
         if (var31 == null) {
            return false;
         }

         PlayerEntity var32 = this.Z;
         var21 = var32;
      }

      PlayerEntity var9 = var21;
      byte var10000 = ((byte)((var9.isAlive()) ? 1 : 0));
      int var34 = var6;
      byte var33 = var10000;
      int var23 = var33;
      byte var22 = var33;
      if (var34 == 0) {
         byte var35 = var22;
         if (var35 == 0) {
            return false;
         }

         MinecraftClient var11 = b;
         PlayerEntity var13 = this.Z;
         ClientPlayerEntity var12 = var11.player;
         float var46 = var12.distanceTo((Entity)var13);
         FloatSetting var14 = this.k;
         Float var15 = (Float)var14.aReturningObject();
         float var48;
         int var36 = (var48 = var46 - var15) == 0.0F ? 0 : (var48 < 0.0F ? -1 : 1);
         var23 = var36;
      }

      int var38 = var6;
      int var37 = var23;
      int var25 = var37;
      int var24 = var37;
      if (var38 == 0) {
         int var39 = var24;
         if (var39 > 0) {
            return false;
         }

         PlayerValidationTracker var47 = Prestige.i;
         Object[] var19 = new Object[]{this.Z, var4};
         PlayerValidationTracker var18 = var47;
         byte var40 = ((byte)((var18.aReturningBoolean(var19)) ? 1 : 0));
         var25 = var40;
      }

      int var42 = var6;
      int var41 = var25;
      int var27 = var41;
      int var26 = var41;
      if (var42 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var27);
      } else {
         int var43 = var26;
         if (var43 != 0) {
            byte var49 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var49);
         } else {
            return false;
         }
      }
   }

   private boolean nReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 76073374701881L ^ var2;
      int var4 = Event.bReturningInt();
      int var46 = var4;
      AutoObbyCrystal var45 = this;
      AutoObbyCrystal var32 = var45;
      AutoObbyCrystal var31 = var45;
      if (var46 == 0) {
         BlockPos var47 = var31.ae;
         if (var47 == null) {
            return false;
         }

         AutoObbyCrystal var48 = this;
         var32 = var48;
      }

      int var50 = var4;
      PlayerEntity var49 = var32.Z;
      PlayerEntity var34 = var49;
      PlayerEntity var33 = var49;
      if (var50 == 0) {
         PlayerEntity var51 = var33;
         if (var51 == null) {
            return false;
         }

         var34 = this.Z;
      }

      int var42;
      int var43;
      label29: {
         PlayerEntity var13 = var34;
         BlockPos var5 = var13.getBlockPos();
         BlockPos var14 = var5;
         int var64 = var14.getX();
         BlockPos var15 = this.ae;
         int var16 = var64 - var15.getX();
         int var6 = Math.abs(var16);
         BlockPos var17 = var5;
         int var65 = var17.getY();
         BlockPos var18 = this.ae;
         int var19 = var65 - var18.getY();
         int var7 = Math.abs(var19);
         BlockPos var20 = var5;
         int var66 = var20.getZ();
         BlockPos var21 = this.ae;
         int var22 = var66 - var21.getZ();
         int var8 = Math.abs(var22);
         int var24 = var8;
         int var23 = var7;
         int var26 = Math.max(var23, var24);
         int var25 = var6;
         this.aD = Math.max(var25, var26);
         int var54 = var4;
         AutoObbyCrystalState var53 = this.S;
         int var52 = this.aD;
         int var40 = var52;
         Object var41 = var53;
         int var35 = var52;
         AutoObbyCrystalState var36 = var53;
         if (var54 == 0) {
            AutoObbyCrystalState var57 = AutoObbyCrystalState.PLACE_OBSIDIAN;
            AutoObbyCrystalState var56 = var36;
            int var55 = var35;
            int var39 = var55;
            int var37 = var55;
            if (var56 == var57) {
               int var58 = var37;
               int var38 = var58;
               byte var60 = 2;
               int var59 = var38;
               var42 = var59;
               var43 = var60;
               break label29;
            }

            IntSetting var29 = this.o;
            var41 = var29.aReturningObject();
            var40 = var39;
         }

         Integer var30 = (Integer)var41;
         var43 = var30;
         var42 = var40;
      }

      int var62 = var43;
      int var61 = var42;
      byte var44;
      if (var61 > var62) {
         byte var63 = 1;
         var44 = var63;
      } else {
         var44 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var44);
   }

   private void u(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 76073374701881L ^ var2;
      long var5 = var2 ^ 27591204936421L;
      long var7 = var2 ^ 71945137399025L;
      long var9 = var2 ^ 12266309938552L;
      long var11 = var2 ^ 8822563779154L;
      int var13 = Event.bReturningInt();
      int var26 = var13;
      AutoObbyCrystal var25 = this;
      AutoObbyCrystal var24 = var25;
      AutoObbyCrystal var23 = var25;
      if (var26 == 0) {
         ElapsedTimer var10000 = var23.aE;
         Object[] var10004 = new Object[]{null, var5};
         var10004[0] = 3000.0F;
         Object[] var15 = var10004;
         ElapsedTimer var14 = var10000;
         boolean var27 = var14.aReturningBoolean(var15);
         if (var27) {
            Object[] var17 = new Object[]{this, var4, NotificationType.ERROR, var11};
            ModuleNotificationsWidget.s(var17);
            var10000 = this.aE;
            Object[] var19 = new Object[]{var7};
            ElapsedTimer var18 = var10000;
            var18.aReturningVoid(var19);
         }

         var24 = this;
      }

      Object[] var22 = new Object[]{var9};
      AutoObbyCrystal var21 = var24;
      var21.x(var22);
   }

   private void v(Object[] var1) {
      long var5;
      AutoObbyCrystal var23;
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 76073374701881L ^ var2;
      var5 = var2 ^ 81225939463154L;
      long var7 = var2 ^ 82455646762200L;
      int var9 = Event.cReturningInt();
      int var25 = var9;
      AutoObbyCrystal var24 = this;
      var23 = var24;
      AutoObbyCrystal var20 = var24;
      label20:
      if (var25 != 0) {
         BooleanSetting var10 = var20.q;
         Boolean var11 = (Boolean)var10.aReturningObject();
         boolean var26 = var11;
         if (var26) {
            int var28 = var9;
            AutoObbyCrystal var27 = this;
            var23 = var27;
            AutoObbyCrystal var21 = var27;
            if (var28 == 0) {
               break label20;
            }

            AutoObbyCrystal var29 = var21;
            AutoObbyCrystal var22 = var29;
            AutoObbyCrystalState var31 = AutoObbyCrystalState.IDLE;
            AutoObbyCrystalState var30 = var22.S;
            if (var30 != var31) {
               AutoObbyCrystalState var15 = this.S;
               String var10001 = String.valueOf(var15);
               short var10003 = 18232;
               long var10004 = 8276987271398398093L ^ var2;
               short var33 = 20340;
               long var10005 = 8012077436807614683L ^ var2;
               Object[] var16 = new Object[]{this, "abort: " + var10001 + ", " + var4, NotificationType.INFO, var7};
               ModuleNotificationsWidget.s(var16);
            }
         }

         var23 = this;
      }

      Object[] var19 = new Object[]{var5};
      AutoObbyCrystal var18 = var23;
      var18.x(var19);
   }

   private float dReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 76073374701881L ^ var2;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      ClientPlayNetworkHandler var27 = var7.networkHandler;
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      UUID var11 = var9.getUuid();
      ClientPlayNetworkHandler var10 = var27;
      PlayerListEntry var5 = var10.getPlayerListEntry(var11);
      PlayerListEntry var24 = var5;
      if (var24 != null) {
         byte var28 = 0;
         PlayerListEntry var12 = var5;
         int var14 = var12.getLatency();
         var4 = Math.max(0, var14);
      }

      AutoObbyCrystalState var26 = AutoObbyCrystalState.BREAK_CRYSTAL;
      AutoObbyCrystalState var25 = this.S;
      if (var25 == var26) {
         float var16 = 300.0F + var4 * 1.5F;
         float var15 = 500.0F;
         float var18 = Math.max(var15, var16);
         float var17 = 1500.0F;
         return Math.min(var17, var18);
      } else {
         float var21 = 120.0F + var4 * 0.8F;
         float var20 = 200.0F;
         float var23 = Math.max(var20, var21);
         float var22 = 600.0F;
         return Math.min(var22, var23);
      }
   }

   private void w(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 88248251550324L;
      long var6 = var2 ^ 30530421099692L;
      int var8 = Event.cReturningInt();
      // int var33 = this.af;
      if (var33 != var34) {
         MinecraftClient var10 = b;
         ClientPlayerEntity var35 = var10.player;
         if (var35 == null) {
            Object[] var11 = new Object[]{this, var4};
            SlotReservation.aReturningVoid(var11);
            this.af = -1;
         } else {
            Object[] var13 = new Object[]{this};
            int var10000 = (((SlotReservation.aReturningBoolean(var13)) ? 1 : 0));
            int var37 = var8;
            boolean var36 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
            boolean var28 = var36;
            boolean var27 = var36;
            if (var37 != 0) {
               boolean var38 = var27;
               if (!var38) {
                  this.af = -1;
                  return;
               }

               RotationManager var47 = Prestige.o;
               Object[] var17 = new Object[0];
               RotationManager var16 = var47;
               var28 = var16.fReturningBoolean(var17);
            }

            AutoObbyCrystal var32;
            label42: {
               int var40 = var8;
               boolean var39 = var28;
               boolean var31 = var39;
               boolean var29 = var39;
               if (var40 != 0) {
                  boolean var41 = var29;
                  if (var41) {
                     return;
                  }

                  int var43 = var8;
                  AutoObbyCrystal var42 = this;
                  var32 = var42;
                  AutoObbyCrystal var30 = var42;
                  if (var43 == 0) {
                     break label42;
                  }

                  BooleanSetting var19 = var30.h;
                  Boolean var20 = (Boolean)var19.aReturningObject();
                  boolean var44 = var20;
                  var31 = var44;
               }

               boolean var45 = var31;
               if (var45) {
                  var10000 = this.af;
                  Object[] var10003 = new Object[]{null, var6};
                  var10003[0] = var10000;
                  Object[] var22 = var10003;
                  InventoryUtil.aReturningVoid(var22);
                  RotationManager var49 = Prestige.o;
                  Object[] var24 = new Object[]{true};
                  RotationManager var23 = var49;
                  var23.fReturningVoid(var24);
               }

               Object[] var26 = new Object[]{this, var4};
               SlotReservation.aReturningVoid(var26);
               var32 = this;
            }

            var32.af = -1;
         }
      }
   }

   private void x(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 59981929867347L;
      Object[] var7 = new Object[]{var4};
      AutoObbyCrystal var6 = this;
      var6.w(var7);
      this.S = AutoObbyCrystalState.IDLE;
      this.Z = null;
      this.aa = null;
      this.ab = null;
      this.ac = null;
      this.ad = null;
      this.ae = null;
      this.ag = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.Y = dev.prestige.recovery.SourceSupport.asBoolean(0);
      List var8 = this.aj;
      var8.clear();
      R = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void y(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 76073374701881L ^ var2;
      long var4 = var2 ^ 37391143237224L;
      this.S = AutoObbyCrystalState.IDLE;
      this.Z = null;
      this.aa = null;
      this.ab = null;
      this.ac = null;
      this.ad = null;
      this.ae = null;
      this.af = -1;
      this.ag = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.Y = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.X = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.ai = -1;
      this.ak = null;
      this.al = null;
      this.am = null;
      this.an = Vec3d.ZERO;
      short var10001 = 3709;
      long var10002 = 8741721733482917300L ^ var2;
      this.ao = Long.MIN_VALUE;
      List var6 = this.aj;
      var6.clear();
      R = dev.prestige.recovery.SourceSupport.asBoolean(0);
      ExpiringValue var10000 = this.ax;
      Object[] var8 = new Object[]{var4};
      ExpiringValue var7 = var10000;
      var7.bReturningVoid(var8);
      var10000 = this.ay;
      Object[] var10 = new Object[]{var4};
      ExpiringValue var9 = var10000;
      var9.bReturningVoid(var10);
      LinkedHashMap var11 = this.az;
      var11.clear();
      HashSet var12 = this.aA;
      var12.clear();
      this.aB = null;
      this.aC = null;
   }

   private Boolean lambda$rayWithinReach$38(Vec3d var1, Vec3d var2) {
      int var14;
      label15: {
         int var5 = Event.bReturningInt();
         Vec3d var7 = var2;
         Vec3d var6 = var1;
         double var10000 = var6.distanceTo(var7);
         FloatSetting var8 = this.I;
         Float var9 = (Float)var8.aReturningObject();
         double var20;
         int var19 = (var20 = var10000 - var9.floatValue()) == 0.0 ? 0 : (var20 < 0.0 ? -1 : 1);
         int var16 = var5;
         int var15 = var19;
         int var13 = var15;
         int var12 = var15;
         if (var16 == 0) {
            int var17 = var12;
            if (var17 > 0) {
               var14 = 0;
               break label15;
            }

            var13 = 1;
         }

         int var18 = var13;
         var14 = var18;
      }

      int var11 = var14;
      return Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var11));
   }

   private static boolean lambda$findCrystal$37(Entity var0) {
      return var0 instanceof EndCrystalEntity;
   }

   private static double lambda$search$36(BlockPlacementTarget var0) {
      return var0.g;
   }

   private boolean lambda$blockedByEntity$35(Entity var1) {
      int var4 = Event.bReturningInt();
      int var10000 = (((var1 instanceof ItemEntity) ? 1 : 0));
      int var16 = var4;
      byte var15 = (byte)var10000;
      byte var10 = var15;
      byte var9 = var15;
      if (var16 == 0) {
         byte var17 = var9;
         if (var17 != 0) {
            return false;
         }

         var10 = ((byte)((var1 instanceof EndCrystalEntity) ? 1 : 0));
      }

      int var19 = var4;
      byte var18 = var10;
      int var14 = var18;
      byte var11 = var18;
      if (var19 == 0) {
         byte var20 = var11;
         if (var20 != 0) {
            Entity var8 = var1;
            var10000 = var8.getId();
            int var22 = var4;
            int var21 = var10000;
            var14 = var21;
            int var12 = var21;
            if (var22 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var14);
            }

            int var23 = var12;
            int var13 = var23;
            int var25 = this.ai;
            int var24 = var13;
            if (var24 == var25) {
               return false;
            }
         }

         var14 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var14);
   }

   private boolean lambda$hasLiveCrystal$34(Entity var1) {
      int var4 = Event.bReturningInt();
      byte var10000 = ((byte)((var1 instanceof EndCrystalEntity) ? 1 : 0));
      int var13 = var4;
      byte var12 = var10000;
      int var8 = var12;
      byte var7 = var12;
      if (var13 == 0) {
         byte var14 = var7;
         if (var14 == 0) {
            return false;
         }

         Entity var6 = var1;
         int var15 = var6.getId();
         var8 = var15;
      }

      int var17 = var4;
      int var16 = var8;
      int var10 = var16;
      int var9 = var16;
      if (var17 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var10);
      }

      int var19 = this.ai;
      int var18 = var9;
      return var18 != var19;
   }

   private static ExpiringValue lambda$onRenderWorld$33(BlockPos var0) {
      long var10001 = 98106454375246L ^ 39692796662869L;
      return new ExpiringValue(180.0F, false, Easing.SINE_IN_OUT, 137591480872731L);
   }

   private boolean lambda$new$32(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var22 = var4;
      byte var21 = var10000;
      byte var15 = var21;
      byte var14 = var21;
      if (var22 != 0) {
         byte var23 = var14;
         if (var23 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var24 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var15 = var24;
      }

      int var26 = var4;
      byte var25 = var15;
      byte var17 = var25;
      byte var16 = var25;
      if (var26 != 0) {
         byte var27 = var16;
         if (var27 == 0) {
            return false;
         }

         BooleanSetting var12 = this.L;
         Boolean var13 = (Boolean)var12.aReturningObject();
         byte var28 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
         var17 = var28;
      }

      int var30 = var4;
      byte var29 = var17;
      byte var19 = var29;
      byte var18 = var29;
      if (var30 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var19);
      } else {
         byte var31 = var18;
         if (var31 != 0) {
            var19 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var19);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$31(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var22 = var4;
      byte var21 = var10000;
      byte var15 = var21;
      byte var14 = var21;
      if (var22 != 0) {
         byte var23 = var14;
         if (var23 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var24 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var15 = var24;
      }

      int var26 = var4;
      byte var25 = var15;
      byte var17 = var25;
      byte var16 = var25;
      if (var26 != 0) {
         byte var27 = var16;
         if (var27 == 0) {
            return false;
         }

         BooleanSetting var12 = this.J;
         Boolean var13 = (Boolean)var12.aReturningObject();
         byte var28 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
         var17 = var28;
      }

      int var30 = var4;
      byte var29 = var17;
      byte var19 = var29;
      byte var18 = var29;
      if (var30 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var19);
      } else {
         byte var31 = var18;
         if (var31 != 0) {
            var19 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var19);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$30(Color var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var22 = var4;
      byte var21 = var10000;
      byte var15 = var21;
      byte var14 = var21;
      if (var22 == 0) {
         byte var23 = var14;
         if (var23 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var24 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var15 = var24;
      }

      int var26 = var4;
      byte var25 = var15;
      byte var17 = var25;
      byte var16 = var25;
      if (var26 == 0) {
         byte var27 = var16;
         if (var27 == 0) {
            return false;
         }

         BooleanSetting var12 = this.K;
         Boolean var13 = (Boolean)var12.aReturningObject();
         byte var28 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
         var17 = var28;
      }

      int var30 = var4;
      byte var29 = var17;
      byte var19 = var29;
      byte var18 = var29;
      if (var30 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var19);
      } else {
         byte var31 = var18;
         if (var31 != 0) {
            var19 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var19);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$29(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var22 = var4;
      byte var21 = var10000;
      byte var15 = var21;
      byte var14 = var21;
      if (var22 != 0) {
         byte var23 = var14;
         if (var23 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var24 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var15 = var24;
      }

      int var26 = var4;
      byte var25 = var15;
      byte var17 = var25;
      byte var16 = var25;
      if (var26 != 0) {
         byte var27 = var16;
         if (var27 == 0) {
            return false;
         }

         BooleanSetting var12 = this.K;
         Boolean var13 = (Boolean)var12.aReturningObject();
         byte var28 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
         var17 = var28;
      }

      int var30 = var4;
      byte var29 = var17;
      byte var19 = var29;
      byte var18 = var29;
      if (var30 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var19);
      } else {
         byte var31 = var18;
         if (var31 != 0) {
            var19 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var19);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$28(Integer var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var22 = var4;
      byte var21 = var10000;
      byte var15 = var21;
      byte var14 = var21;
      if (var22 == 0) {
         byte var23 = var14;
         if (var23 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var24 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var15 = var24;
      }

      int var26 = var4;
      byte var25 = var15;
      byte var17 = var25;
      byte var16 = var25;
      if (var26 == 0) {
         byte var27 = var16;
         if (var27 == 0) {
            return false;
         }

         BooleanSetting var12 = this.L;
         Boolean var13 = (Boolean)var12.aReturningObject();
         byte var28 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
         var17 = var28;
      }

      int var30 = var4;
      byte var29 = var17;
      byte var19 = var29;
      byte var18 = var29;
      if (var30 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var19);
      } else {
         byte var31 = var18;
         if (var31 != 0) {
            var19 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var19);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$27(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 == 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$26(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 == 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$25(Boolean var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$24(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$23(Float var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 == 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.F;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$22(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.F;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$21(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$20(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.B;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$19(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.B;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$18(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.B;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$17(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$16(Integer var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$15(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$14(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$13(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$12(Float var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      int var11 = var15;
      byte var10 = var15;
      if (var16 == 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         FloatSetting var8 = this.v;
         Float var9 = (Float)var8.aReturningObject();
         float var23;
         int var18 = (var23 = var9 - 0.0F) == 0.0F ? 0 : (var23 < 0.0F ? -1 : 1);
         var11 = var18;
      }

      int var20 = var4;
      int var19 = var11;
      int var13 = var19;
      int var12 = var19;
      if (var20 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         int var21 = var12;
         if (var21 > 0) {
            byte var24 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var24);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$11(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$10(Float var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.t;
         String var24 = (String)var8.aReturningObject();
         String var10 = "None";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 == 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$9(String var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$8(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.j;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.g;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      int var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$7(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$6(Boolean var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$5(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$4(Integer var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$1(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.j;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(73679622879000L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[26];
      String var28 = "~òë:\u0001\u0014\u00048BÊIëðn~ààÌî._Ø\u0014à[hÄØÐ\u0017_T\u0010\u0002%\u0084ñý»øÿ\u0096²;Í-0Ü\u0007\u0010ËÆ\u0082Y°tµL[J\u0094{\u0092y¶y\u0010\u0080ö¹¦,;\u0019\u0006:Qð\u0015¸\u0010\u00141\u00105«qì\u0010¡\u008ar¾4YÌËe³\u009e\u0018 ;;0aÏ©\u0083\u0006³)RôÔKè\u008eó8Å.\u0088a´\u00108\u008d¢³ÑÅ\u0013ÿ\u0082MÈÑ\u00078õ¾ îÈ°\u0007,\u0015h´&\u000bÙ\u0097Ã1Ñ,\u0099Ì\u001a=ìdÞÒ\u0017#À×ø¦×?\u0018ùWBC\u0018Ï_ñÙ6\u0002Þ\u0010Ý\u009aúPÚ¶\u009bþ\u000fÌ· ;fó&5uÒ<fD7#\u0088¼\u0095*%Ñ¨\u0087²)0ïd\u0092\u0018#J\u009fý®\u0018t¡H¾\u001ai©Yak\u0013`¶\u008b\u000f \u0005}\u008e\u0085W\u000f4\u0091\u0018¬â\u0019TäÏ\u0099_nG\u001e+Õ±nÚG\u0083\u001e\u0011\u0017xaÚ\u0018\u0012°XBß(P\u0082ä_$s*T\u001f\u001e\u001e-¢>N%\u0010\u009d (Ö\u0001J\u0004 x\u001eÌôð\u008b¼Û\u001dAE`¾b\u0019W\u000b\u0015\u001a\u007f^á\u0096=äg \u0016§S\u0097\u0098\u0015©\be|ë:ò\u0080\u0010º°\u0091Í\u0095\u001a1Õ\u001f£ÍÎfO\r¤ÿ(°È\"Xum\u0091ú+¼å Òü²×sÒ\u0090Ú\u001d\u0099=\u00939\u000e+°\u007fº¥-N¸\u0098½ÊZÆ3\u0018¸ÐUñÕ\u000b\u001c[(Ñ\b°Î¨ÿ\"ùMãè\u0096Çÿ¡(*\u0090\u0001\u009b&õK¬áþ]E®®?@\u0007±ì#\u001fZ\u0015lÖ\u0012\\ûîþ!\u001d?Ø°Òk³!O\u00187\u008dµÅm|ÚÆ=PT~$Øë\u001e:øâ#º?$:(\u0003Øí\u0010\u0083ÓÞnçÂ\u009d¶d³Äÿ\u0000c\u0091»ëï¸\\é4eob:õº8\u0088\t7q\fDo\u0010â`Ý¯B\u0097Eü5\u00841\n\u008a÷´#\u0010m\u001c\u0083\u0005%Ü\u001dí\u00015{9\u0092\u0088¿o8\u0002\u009d12\u0086#Vîð ô9\t]\u008eô\u0012Sc~\u0004î\u009aÌ\\Eú^\bv\u009c&jO)\u0016\u008c\u001c\u001dê%§\u009f\u0089/VNþv¶9bù\u0088\u008cä(<\u0083\u0014qn\u001c¢d\u0005\u0000¢ß\u0089´ ÝY\u009cAÿÐ\u0097Ãº±\u0003ê\u0095\u009d/LX]j«Ý\u0015\u0015æ\u009a";
      int var30 = "~òë:\u0001\u0014\u00048BÊIëðn~ààÌî._Ø\u0014à[hÄØÐ\u0017_T\u0010\u0002%\u0084ñý»øÿ\u0096²;Í-0Ü\u0007\u0010ËÆ\u0082Y°tµL[J\u0094{\u0092y¶y\u0010\u0080ö¹¦,;\u0019\u0006:Qð\u0015¸\u0010\u00141\u00105«qì\u0010¡\u008ar¾4YÌËe³\u009e\u0018 ;;0aÏ©\u0083\u0006³)RôÔKè\u008eó8Å.\u0088a´\u00108\u008d¢³ÑÅ\u0013ÿ\u0082MÈÑ\u00078õ¾ îÈ°\u0007,\u0015h´&\u000bÙ\u0097Ã1Ñ,\u0099Ì\u001a=ìdÞÒ\u0017#À×ø¦×?\u0018ùWBC\u0018Ï_ñÙ6\u0002Þ\u0010Ý\u009aúPÚ¶\u009bþ\u000fÌ· ;fó&5uÒ<fD7#\u0088¼\u0095*%Ñ¨\u0087²)0ïd\u0092\u0018#J\u009fý®\u0018t¡H¾\u001ai©Yak\u0013`¶\u008b\u000f \u0005}\u008e\u0085W\u000f4\u0091\u0018¬â\u0019TäÏ\u0099_nG\u001e+Õ±nÚG\u0083\u001e\u0011\u0017xaÚ\u0018\u0012°XBß(P\u0082ä_$s*T\u001f\u001e\u001e-¢>N%\u0010\u009d (Ö\u0001J\u0004 x\u001eÌôð\u008b¼Û\u001dAE`¾b\u0019W\u000b\u0015\u001a\u007f^á\u0096=äg \u0016§S\u0097\u0098\u0015©\be|ë:ò\u0080\u0010º°\u0091Í\u0095\u001a1Õ\u001f£ÍÎfO\r¤ÿ(°È\"Xum\u0091ú+¼å Òü²×sÒ\u0090Ú\u001d\u0099=\u00939\u000e+°\u007fº¥-N¸\u0098½ÊZÆ3\u0018¸ÐUñÕ\u000b\u001c[(Ñ\b°Î¨ÿ\"ùMãè\u0096Çÿ¡(*\u0090\u0001\u009b&õK¬áþ]E®®?@\u0007±ì#\u001fZ\u0015lÖ\u0012\\ûîþ!\u001d?Ø°Òk³!O\u00187\u008dµÅm|ÚÆ=PT~$Øë\u001e:øâ#º?$:(\u0003Øí\u0010\u0083ÓÞnçÂ\u009d¶d³Äÿ\u0000c\u0091»ëï¸\\é4eob:õº8\u0088\t7q\fDo\u0010â`Ý¯B\u0097Eü5\u00841\n\u008a÷´#\u0010m\u001c\u0083\u0005%Ü\u001dí\u00015{9\u0092\u0088¿o8\u0002\u009d12\u0086#Vîð ô9\t]\u008eô\u0012Sc~\u0004î\u009aÌ\\Eú^\bv\u009c&jO)\u0016\u008c\u001c\u001dê%§\u009f\u0089/VNþv¶9bù\u0088\u008cä(<\u0083\u0014qn\u001c¢d\u0005\u0000¢ß\u0089´ ÝY\u009cAÿÐ\u0097Ãº±\u0003ê\u0095\u009d/LX]j«Ý\u0015\u0015æ\u009a"
         .length();
      char var27 = ' ';
      int var35 = -1;

      label72:
      while (true) {
         String var36 = var28.substring(++var35, var35 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var36.getBytes("ISO-8859-1"));
            String var50 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var50;
                  if ((var35 += var27) >= var30) {
                     hb = var31;
                     ib = new String[26];
                     mb = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(73679622879000L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[10];
                     String var15 = "Z+{w\u008b\u0010Õ$ì±ßA tr\u0099³Ø\u008cðp\u0098\u0096b[-ã\u0082\u0099Ú¬ìç«à\u008d\u0086\u0090cìÇÉ\u001açü¼Ä_\u00199i0îó9±8ØØÝ\u008dµ\u0002}";
                     int var16 = "Z+{w\u008b\u0010Õ$ì±ßA tr\u0099³Ø\u008cðp\u0098\u0096b[-ã\u0082\u0099Ú¬ìç«à\u008d\u0086\u0090cìÇÉ\u001açü¼Ä_\u00199i0îó9±8ØØÝ\u008dµ\u0002}"
                        .length();
                     label54:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var39 = var17;
                        var10001 = var14++;
                        long var54 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var54;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var62 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var58) {
                              case 0:
                                 var39[var10001] = var62;
                                 if (var13 >= var16) {
                                    kb = var17;
                                    lb = new Integer[10];
                                    pb = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(73679622879000L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[3];
                                    String var4 = "\u0019a´¬Ê[^7=e*\u0086Dn.820\u001e\u007fI\u009aÞ\u0092";
                                    int var5 = "\u0019a´¬Ê[^7=e*\u0086Dn.820\u001e\u007fI\u009aÞ\u0092".length();
                                    do {
                                       int var47 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var47, var2).getBytes("ISO-8859-1");
                                       var47 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var62 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       // var6[var47] = var62;
                                    } while (var2 < var5);

                                    nb = var6;
                                    ob = new Long[3];
                                    break;
                                 }
                                 break;
                              default:
                                 var39[var10001] = var62;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "\u0088~pì\u0004m\u0091\"\u00ad÷Èè\u009f\t¼\u0016";
                                 var16 = "\u0088~pì\u0004m\u0091\"\u00ad÷Èè\u009f\t¼\u0016".length();
                                 var13 = 0;
                           }

                           int var46 = var13;
                           var13 += 8;
                           var18 = var15.substring(var46, var13).getBytes("ISO-8859-1");
                           var39 = var17;
                           var10001 = var14++;
                           var54 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var58 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var35);
                  break;
               default:
                  var31[var29++] = var50;
                  if ((var35 += var27) < var30) {
                     var27 = var28.charAt(var35);
                     continue label72;
                  }

                  var28 = "\\\u0014¯x\u0005Êf!7¿Ì¦))j]\u0010\f\u007fÜ\"ì{êu\u0007Þ¿è$CÀ\u0001";
                  var30 = "\\\u0014¯x\u0005Êf!7¿Ì¦))j]\u0010\f\u007fÜ\"ì{êu\u0007Þ¿è$CÀ\u0001".length();
                  var27 = 16;
                  var35 = -1;
            }

            var36 = var28.substring(++var35, var35 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21975;
      if (ib[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])jb.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               jb.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eb", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = hb[var5].getBytes("ISO-8859-1");
         ib[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return ib[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eb_C0220",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1359;
      if (lb[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = kb[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])mb.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               mb.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eb", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         lb[var3] = var15;
      }

      return lb[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eb_C0220",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11194;
      if (ob[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = nb[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])pb.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               pb.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eb", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         ob[var3] = var15;
      }

      return ob[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eb_C0220",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = xb[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = wb[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 29;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 49;
            yield var22;
         }
         case 8 -> {
            byte var23 = 16;
            yield var23;
         }
         case 9 -> {
            byte var24 = 58;
            yield var24;
         }
         case 10 -> {
            byte var25 = 46;
            yield var25;
         }
         case 11 -> {
            byte var26 = 12;
            yield var26;
         }
         case 12 -> {
            byte var27 = 53;
            yield var27;
         }
         case 13 -> {
            byte var28 = 0;
            yield var28;
         }
         case 14 -> {
            byte var29 = 7;
            yield var29;
         }
         case 15 -> {
            byte var30 = 17;
            yield var30;
         }
         case 16 -> {
            byte var31 = 25;
            yield var31;
         }
         case 17 -> {
            byte var32 = 19;
            yield var32;
         }
         case 18 -> {
            byte var33 = 55;
            yield var33;
         }
         case 19 -> {
            byte var34 = 24;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 37;
            yield var36;
         }
         case 22 -> {
            byte var37 = 60;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 36;
            yield var39;
         }
         case 25 -> {
            byte var40 = 57;
            yield var40;
         }
         case 26 -> {
            byte var41 = 9;
            yield var41;
         }
         case 27 -> {
            byte var42 = 18;
            yield var42;
         }
         case 28 -> {
            byte var43 = 47;
            yield var43;
         }
         case 29 -> {
            byte var44 = 31;
            yield var44;
         }
         case 30 -> {
            byte var45 = 38;
            yield var45;
         }
         case 31 -> {
            byte var46 = 2;
            yield var46;
         }
         case 32 -> {
            byte var47 = 13;
            yield var47;
         }
         case 33 -> {
            byte var48 = 52;
            yield var48;
         }
         case 34 -> {
            byte var49 = 30;
            yield var49;
         }
         case 35 -> {
            byte var50 = 4;
            yield var50;
         }
         case 36 -> {
            byte var51 = 44;
            yield var51;
         }
         case 37 -> {
            byte var52 = 50;
            yield var52;
         }
         case 38 -> {
            byte var53 = 27;
            yield var53;
         }
         case 39 -> {
            byte var54 = 5;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 11;
            yield var56;
         }
         case 42 -> {
            byte var57 = 1;
            yield var57;
         }
         case 43 -> {
            byte var58 = 63;
            yield var58;
         }
         case 44 -> {
            byte var59 = 26;
            yield var59;
         }
         case 45 -> {
            byte var60 = 39;
            yield var60;
         }
         case 46 -> {
            byte var61 = 42;
            yield var61;
         }
         case 47 -> {
            byte var62 = 34;
            yield var62;
         }
         case 48 -> {
            byte var63 = 20;
            yield var63;
         }
         case 49 -> {
            byte var64 = 59;
            yield var64;
         }
         case 50 -> {
            byte var65 = 14;
            yield var65;
         }
         case 51 -> {
            byte var66 = 43;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 3;
            yield var68;
         }
         case 54 -> {
            byte var69 = 32;
            yield var69;
         }
         case 55 -> {
            byte var70 = 51;
            yield var70;
         }
         case 56 -> {
            byte var71 = 6;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 23;
            yield var73;
         }
         case 59 -> {
            byte var74 = 48;
            yield var74;
         }
         case 60 -> {
            byte var75 = 8;
            yield var75;
         }
         case 61 -> {
            byte var76 = 54;
            yield var76;
         }
         case 62 -> {
            byte var77 = 35;
            yield var77;
         }
         default -> 10;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            xb[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      wb[0] = "30\n]\u0000T%0\u000f\u0007\u0013C2{\f\u0001\u001fW#<\u001b\u0016TE\u0012";
      wb[1] = int.class;
      xb[1] = "java/lang/Integer";
      wb[2] = "YGI\u0011l`RHX^\u0000c\\JZ\u0011,";
      wb[3] = boolean.class;
      xb[3] = "java/lang/Boolean";
      wb[4] = "A\u0002eX\t)W\u0002`\u0002\u001a>@Ic\u0004\u0016*Q\u000et\u0013]=c";
      wb[5] = "Q|N\u001d\u0007TZs_RfZQx[\b";
      wb[6] = "`#yA*zv#|\u001b9mah\u007f\u001d5yp/h\n~of";
      wb[7] = "\u0019\u000e7_Q9\u0012\u0001&\u001024\u0007\f){\u00076\u0016\u001f5W\u0010;";
      wb[8] = "\u0015s\u001e*\u0013y\u001e|\u000fena\r{\u0006,";
      wb[9] = "(qaWmc>qd\r~t):g\u000br`8}p\u001c9p\u007f";
      wb[10] = "p\u0010\u007f%:.\u00050t*+ad>\u007f!/;\u0010";
      wb[11] = "R\u0002\u000f\u0017\u001d\u000fR\u0002\u0018K\u0011\u0000HI\u0018U\u0011\u0015O8I\rC";
      wb[12] = "\n\u001eBj=Q\n\u001eU61^\u0010UU(1K\u0017$\u0007qa\t";
      wb[13] = "I\u0019{\t\u0014YI\u0019lU\u0018VSRlK\u0018CT#8\u0013O";
      wb[14] = "Si ]\u00133&I+R\u0002|GG Y\u0006&3";
      wb[15] = double.class;
      xb[15] = "java/lang/Double";
      wb[16] = "u\u0000bDm]~\u000fs\u000b\u000ePk\t";
      wb[17] = "2\u00046Y|m2\u0004!\u0005pb(O!\u001bpw/>pD)";
      wb[18] = "CGB|\u000fZ6gIs\u001e\u0015WiBx\u001aO#";
      wb[19] = "(r|\"V\u001b(rk~Z\u001429k`Z\u00015H>?\u0003";
      wb[20] = "l3\t\n*8l3\u001eV&7vx\u001eH&\"q\tL\u0016~f";
      wb[21] = "D\u000eH\u0015\u0017dZ\u0006RZ_d@\fJ\u001dV\u007f\u0000?L\u0011]xM\u000eJ\u0011";
      wb[22] = "h\u0018y\r18v\u0010cBS$q\r";
      wb[23] = "xO9g\t8fG#(n9w\\.rH?";
      wb[24] = "tpvgb?tpa;n0n;a%n%iJ1x?";
      wb[25] = "]E`8=9]Ewd16G\u000ewz1#@\u007f&%ch";
      wb[26] = "P_=\u0006}\r[P,I\u0015\rU_?";
      wb[27] = float.class;
      xb[27] = "java/lang/Float";
      wb[28] = "y\u0006\\z\u0019Qr\tM5~Sg\u0002M~E";
      wb[29] = "3i\u0012U>\u000e3i\u0005\t2\u0001)\"\u0005\u00172\u0014.SWMfP";
      wb[30] = "*HDhen_hOgt!>fDlp{J";
      wb[31] = "\u0004hX6\"9qHS93v\u0010FX27,d";
      wb[32] = "\f3!K\u0004U\u0011&yiEX\t ";
      wb[33] = "c^\u001fR^ku^\u001a\bM|b\u0015\u0019\u000eAhsR\u000e\u0019\n\u007fq";
      wb[34] = "\u001fhpiK^jH{fZ\u0011\u000bFpm^K\u007f";
      wb[35] = void.class;
      xb[35] = "java/lang/Void";
      wb[36] = "KA\u0001y}O>a\nvl\u0000_o\u0001}hZ+";
      wb[37] = "X1fUt9N1c\u000fg.Yz`\tk:H=w\u001e (Y";
      wb[38] = "^\"\u0004pax+\u0002\u000f\u007fp7J\f\u0004ttm>";
      wb[39] = "\u000ecAc\u007fr{CJln=\u001aMAgjgn";
      wb[40] = "\u0010\u0011,CtDe1'Le\u000b\u0004?,GaQp";
      wb[41] = "C\u0017)+7\t]\u001f3dQ\u001dZ\u001e\f/m";
      wb[42] = "AxEwC\u001e4XNxRQUVEsV\u000b!";
      wb[43] = "\u0003\u001fB+c\n\u001d\u0017Xd\u0001\u0016\u0007\u0015Q.\u0005\u001e\u001a\u0016y+=";
      wb[44] = "f_6g58p_3=&/g\u00140;*;vS',a*;";
      wb[45] = "B!0nMm7\u0001;a\\\"V\u000f0jXx\"";
      wb[46] = "{(&fuD\u000e\b-id\u000bo\u0006&b`Q\u001b";
      wb[47] = long.class;
      xb[47] = "java/lang/Long";
      wb[48] = "q\u001e2/{4q\u001e%sw;kU%mw.l$p2 ";
      wb[49] = "cT\r\u0001PruT\b[Ceb\u001f\u000b]OqsX\u001cJ\u0004f~";
      wb[50] = "d\n1:!\u0013\u0011*:50\\p$1>4\u0006\u0004";
      wb[51] = "\u0016\u007f.\u001azG\u0016\u007f9FvH\f49Xv]\u000bEk\u0006!\u0016";
      wb[52] = "zQ1$J\u001clQ4~Y\u000b{\u001a7xU\u001fj] o\u001e\u000fr]\"dDBNF\"yD\u0005yQ";
      wb[53] = "=|apI\n=|v,E\u0005'7v2E\u0010 F&k\u0017Q";
      wb[54] = "zk^\b\u000e=zkIT\u00022` IJ\u0002'gQ\u0018\u0014Wb";
      wb[55] = "\u001f(c?Xv\u001f(tcTy\u0005ct}Tl\u0002\u0012%#\u0001'";
      wb[56] = "$uw\u0014Nr2urN]e%>qHQq4yf_\u001aa/";
      wb[57] = ".g8qGZ[G3~V\u0015:I8uRON";
      wb[58] = "'5f=\u001f\u001815cg\f\u000f&~`a\u0000\u001b79wvK\t/";
      wb[59] = "+}\u0001~\u00140^]\nq\u0005\u007f?S\u0001z\u0001%K";
      wb[60] = "\\\nU-.\u001d)*^\"?RH$U);\b<";
      wb[61] = "b\u000b\n\u0017#\u001e\u0017+\u0001\u00182Qv%\n\u00136\u000b\u0002";
      wb[62] = "T\u001c\u007fTv\u001cB\u001cz\u000ee\u000bUWy\bi\u001fD\u0010n\u001f\"\br";
      wb[63] = "9\fNd\u0016\"L,Ek\u0007m-\"N`\u00037Y";
      wb[64] = "\u000b\u000bsP\u0007&\u000b\u000bd\f\u000b)\u0011@d\u0012\u000b<\u001615MS";
      wb[65] = "k&\u001b:\u0013Ik&\ff\u001fFqm\fx\u001fSv\u001c]'K\u0010";
      wb[66] = "\u0018\n\u001c@D:\u0018\n\u000b\u001cH5\u0002A\u000b\u0002H \u00050YV\u0019a";
      wb[67] = "26+\f\u000b\u001526<P\u0007\u001a(}<N\u0007\u000f/\fn\u0015_N";
      wb[68] = "!?\u0004F\u0002'T\u001f\u000fI\u0013h5\u0011\u0004B\u00172A";
      wb[69] = "!+3&<\u0013T\u000b8)-\\5\u00053\")\u0006A";
      wb[70] = ";G6P$B-G3\n7U:\f0\f;A+K'\u001bpT\u0006";
      wb[71] = "l~\u000b+Az\u0019^\u0000$P5xP\u000b/To\f";
      wb[72] = "\u0013uMSnPfUF\\\u007f\u001f\u0007[MW{Es";
      wb[73] = "Rg+\u0001~~Rg<]rqH,<CrdO]l\u0016%\"";
      wb[74] = "j\u007fAs)S|\u007fD):Dk4G/6PzsP8}E@";
      wb[75] = "?o*j$8JO!e5w+A*n1-_";
      wb[76] = "uj[\u0003!Ncj^Y2Yt!]_>MefJHuZ";
      wb[77] = "\u0007ZE\u0015bCrzN\u001as\f\u0013tE\u0011wVg";
      wb[78] = "\u001e\r\u001d6\u0003b((\u001d6\u0014>$'\u0007}\u0014 $2\u0000\fE\u007fpqH";
      wb[79] = "Q\u0003Z\u0015R)Q\u0003MI^&KHMW^3L9\u001c\b\fx\u001b\u0005BZL3`T\u001d\b\u0006";
      wb[80] = "P\u000bP\n\f4P\u000bGV\u0000;J@GH\u0000.M1\u0016\u0012Ym";
      wb[81] = "W8s?\u0007\u000b\"\u0018x0\u0016DC\u0016s;\u0012\u001e7";
      wb[82] = "O2Fb\f6Y2C8\u001f!Ny@>\u00135_>W)X%\u0019";
      wb[83] = "4.\u001e\u000ba{A\u000e\u0015\u0004p4 \u0000\u001e\u000ftnT";
      wb[84] = "7SVSSFBs]\\B\t#}VWFSW";
      wb[85] = "\u007f1Qo.Vi1T5=A~zW31Uo=@$zBW";
      wb[86] = "{:\u007f\n3\\\u000e\u001at\u0005\"\u0013o\u0014\u007f\u000e&I\u001b";
      wb[87] = ";QLs8^NqG|)\u0011/\u007fLw-K[";
      wb[88] = "\u0019nt{B*lN\u007ftSe\r@t\u007fW?y";
      wb[89] = "?-\nd\u001a\u0001J\r\u0001k\u000bN+\u0003\n`\u000f\u0014_";
      wb[90] = "\u000b:']m\"\u001d:\"\u0007~5\nq!\u0001r!\u001b66\u001693\u0017";
      wb[91] = "u\u0002QD\u0010+\u0000\"ZK\u0001da,Q@\u0005>\u0015";
      wb[92] = "DP(FU\u0018DP?\u001aY\u0017^\u001b?\u0004Y\u0002YjoQ\u000eG";
      wb[93] = ".?M\u0007TM[\u001fF\bE\u0002:\u0011M\u0003AXN";
      wb[94] = "eDN\u001a U\u0010dE\u00151\u001aqjN\u001e5@\u0005";
      wb[95] = "k3;Z55\u001e\u00130U$z\u007f\u001d;^  \u000b";
      wb[96] = "psB\u007f{\"\u0005SIpjmd]B{n7\u0010";
      wb[97] = "O/6;X6O/!gT9Ud!yT,R\u0015t!\u0005";
      wb[98] = "\\i>)y\u001e\\i)uu\u0011F\")ku\u0004AS|4 ";
      wb[99] = "\u0005\u0004\tfk\u000f\u001b\f\u0013)\u0010/&!";
      wb[100] = "\u001cY:kLMiy1d]\u0002\bw:oYX|";
      wb[101] = "i\u000fcEm\"\u001c/hJ|m}!cAx7\t";
      wb[102] = "VM\u000b\u001bf\\#m\u0000\u0014w\u0013Bc\u000b\u001fsI6";
      wb[103] = "Jl\u0003%f~?L\b*w1^B\u0003!sk*";
      wb[104] = ".D\\R8\"8DY\b+5/\u000fZ\u000e'!>HM\u0019l4\u001f";
      wb[105] = "T\u0010\u0000v_&!0\u000byNi@>\u0000rJ34";
      wb[106] = "OqC\u001a\t\u0003:QH\u0015\u0018L[_C\u001e\u001c\u0016/";
      wb[107] = "]?G\u001aR<K?B@A+\\tAFM?M3VQ\u0006-P";
      wb[108] = "6F\u001f_|5Cf\u0014Pmz\"h\u001f[i V";
      wb[109] = "BB\u0017\t\u000f\u00167b\u001c\u0006\u001eYVl\u0017\r\u001a\u0003\"";
      wb[110] = "6u\u001e#V@CU\u0015,G\u000f\"[\u001e'CUV";
      wb[111] = "lS6%M\u0015\u0019s=*\\Zx}6!X\u0000\f";
      wb[112] = "hgCi`TchR&\nWwdYm";
      wb[113] = "\u000fft\u001f&\u0015\u0019fqE5\u0002\u000e-rC9\u0016\u001fjeTr\u0001\u0013";
      wb[114] = "^n0S\u0016O+N;\\\u0007\u0000J@0W\u0003Z>";
      wb[115] = "Qp\rIH~$P\u0006FY1E^\rM]k1";
      wb[116] = "3\u0016av11F6jy ~'8ar$$S";
      wb[117] = " tk+V\nUT`$GE4Zk/C\u001f@";
      wb[118] = "\u001e0\u0017s\u0007fk\u0010\u001c|\u0016)\n\u001e\u0017w\u0012s~";
      wb[119] = "}l?\u0011\u000bg\bL4\u001e\u001a(iB?\u0015\u001er\u001d";
      wb[120] = "]Zl \u0015\u000e(zg/\u0004AItl$\u0000\u001b=";
      wb[121] = "MSd?/l8so0>#Y}d;:y-";
      wb[122] = "o\u0013t\tP\u0002\u001a3\u007f\u0006AM{=t\rE\u0017\u000f";
      wb[123] = "\rO1\u0004Rexo:\u000bC*\u0019a1\u0000Gpm";
      wb[124] = "(@\u0016'\u001f+#O\u0007hb>1U\u0005+";
      wb[125] = "-!\rLs[X\u0001\u0006Cb\u00149\u000f\rHfNM";
      wb[126] = "P\r0meDF\r57vSQF61zG@\u0001!&1C";
      wb[127] = "oQ\u000e{GQ\u001aq\u0005tV\u001e{\u007f\u000e\u007fRD\u000f";
      wb[128] = "R,?DP}D,:\u001eCjSg9\u0018O~B .\u000f\u0004lP";
      wb[129] = "\u0018\u001bx\rJ5m;s\u0002[z\f5x\t_ x";
      wb[130] = "np\u0012>o/\u001bP\u00191~`z^\u0012:z:\u000e";
      wb[131] = "*\u0011\u0004\u0014\u001e\u0002_1\u000f\u001b\u000fM>?\u0004\u0010\u000b\u0017J";
      wb[132] = "\u0012y\rV(\u001agY\u0006Y9U\u0006W\rR=\u000fr";
      wb[133] = "|/\naa\u000e|/\u001d=m\u0001fd\u001d#m\u0014a\u0015J|;";
      wb[134] = "\ng\u0019.PJ\u007fG\u0012!A\u0005\u001eI\u0019*E_j";
      wb[135] = "Yrzln|,Rqc\u007f3M\\zh{i9";
      wb[136] = "}7$n\u0001\u001cc?>!l\u0006z&3}N\u001dx$";
      wb[137] = "y\u0017^&#\u0006\f7U)2Im9^\"6\u0013\u0019";
      wb[138] = "\u000f<o=b-z\u001cd2sb\u001b\u0012o9w8o";
      wb[139] = "7U[C\u00052BuPL\u0014}#{[G\u0010'W";
      wb[140] = "u?k\rO\u0001k7qB\u0007\u0001q=i\u0005\u000e\u001a1\nr(\u000e\u0001}2x*\u0014\u001a|*t\u0003\u000f";
      wb[141] = "Db@\b$B1BK\u00075\rPL@\f1W$";
      wb[142] = "!ddmt\u001dTDobeR5Jdia\bA";
      wb[143] = "69\u0007L\u0000a69\u0010\u0010\fn,r\u0010\u000e\f{+\u0003BP[1";
      wb[144] = "]C2\u000f\tM(c9\u0000\u0018\u0002Im2\u000b\u001cX=";
      wb[145] = "\u001b\u0014k\u0015Cw\u0005\u001cqZ>g\u0005";
      wb[146] = "~\u0016u.\u0006\u001c\u000b6~!\u0017Sj8u*\u0013\t\u001e";
      wb[147] = "7ya5\u001e}BYj:\u000f2#Wa1\u000bhW";
      wb[148] = "r2U/iW\u0007\u0012^ x\u0018f\u001cU+|B\u0012";
      wb[149] = "fP5\b#\u001d\u0013p>\u00072Rr~5\f6\b\u0006";
      wb[150] = "\u00012]\u000e~,t\u0012V\u0001oc\u0015\u001c]\nk9a";
      wb[151] = "l%\f\n0\u0017\u0019\u0005\u0007\u0005!Xx\u000b\f\u000e%\u0002\f";
      wb[152] = "7\u0004\u0012E_cB$\u0019JN,#*\u0012AJvW";
      wb[153] = "\u0004\u001a&3\bmq:-<\u0019\"\u00104&7\u001dxd";
      wb[154] = "J\f\u001dUVL?,\u0016ZG\u0003^\"\u001dQCY*";
      wb[155] = "\u007fQ+V$#\nq Y5lk\u007f+R16\u001f";
      wb[156] = "N4ISHC;\u0014B\\Y\fZ\u001aIW]V.";
      wb[157] = "\u0010\u0002v\u0016wEe\"}\u0019f\n\u0004,v\u0012bPp";
      wb[158] = "Gv#%Z\u0003Y~9j9\u0017]3\u0010*\u0000\u0004T";
      wb[159] = "A_\u00165)D4\u007f\u001d:8\u000bUq\u00161<Q!";
      wb[160] = "\u0019FXARL\u0007NB\u000e\u001aL\u001dDZI\u0013W]a[N\u001fM\u001aH@";
      wb[161] = "\u0004\u001eZT:3q>Q[+|\u00100ZP/&d";
      wb[162] = ")o\u000b\u0017\u0006`\\O\u0000\u0018\u0017/=A\u000b\u0013\u0013uI";
      wb[163] = "O\u0010WZd\u0002:0\\UuM[>W^q\u0017/";
      wb[164] = "\rm\u00021o\n\u001bm\u0007k|\u001d\f&\u0004mp\t\u001da\u0013z;\u001e!";
      wb[165] = "Hl_\u000e\u0016e=LT\u0001\u0007*\\B_\n\u0003p(";
      wb[166] = "\u0005\u0002!}\fT\u0013\u0002$'\u001fC\u0004I'!\u0013W\u0015\u000e06X@(";
      wb[167] = "L\u00119)\u0013\u0003912&\u0002LX?9-\u0006\u0016,";
      wb[168] = "\u000fR^-\tv\u0019R[w\u001aa\u000e\u0019Xq\u0016u\u001f^Of]b!";
      wb[169] = "Z4\u0011@?\f/\u0014\u001aO.CN\u001a\u0011D*\u0019:";
      wb[170] = "A\fbSr\f4,i\\cCU\"bWg\u0019!";
      wb[171] = "\u0015q=88S\u0003q8b+D\u0014:;d'P\u0005},slG:";
      wb[172] = "\u0007\u001b7d1Fr;<k \t\u001357`$Sg";
      wb[173] = "$\b^S\u0014\n2\b[\t\u0007\u001d%CX\u000f\u000b\t4\u0004O\u0018@\u001e\r";
      wb[174] = "Z?\u0006N\u0006</\u001f\rA\u0017sN\u0011\u0006J\u0013):";
      wb[175] = ";\u001ew\u007fW+%\u0016m06.%\u0016np\u00182";
      wb[176] = "\u00107\t/8Ae\u0017\u0002 )\u000e\u0004\u0019\t+-Tp";
      wb[177] = "|Yp^\u0006G}E\"FhO\u007fHO\u001dY\u0016/\u0002/\u0015T\u0015/8v\u0015T\u0013,X~\u0018W\u0013\u0016\u0001~\u0018Q\u0010v\ts\u001bQ*";
      wb[178] = "\u00009\u0001,6&[e\u00015\n?<oP~u6F>Q<tc<3D5c<\u0007iY 7Z";
      wb[179] = "lv\u00002K/:uA2U\u00170`6&_zW!\u0019rOz7gFyJ\u0017lxK)Iw*'@,$";
      wb[180] = "\u0012hM\tk]\u0013<V\u0005dlJP\u001c\u00180\u0010\u0017iA\u001eo\bF";
      wb[181] = "<\f\u000bp\u0016\u0003=[\u0006o\u0002ekT\u0000p\u000b2<\rP(_e<\u000fVe\u0017\u000bxDRv\u0001";
      wb[182] = "[x20j<\u001f>;=w\u0004\u000f,+\u001fku`z5lmi\u0000<jgh\u0004";
      wb[183] = "$\u0012\u0016N\u007fz\u007fN\u0016WCe\u0018DG\u001c<jb\u0015F^=?\u0018\u0018SW*`#BNB~\u0006";
      wb[184] = "\u0014_\u0015))\tO\u0003\u00150\u0015\u001a(\tD{j\u0019RXE9kL(\bIq~IVMY'{u";
      wb[185] = "C \u0000mWbT\u007f\nq5{Jj\f\u001c\u000feD`\u0011sMg\u0014q\u001e\u001cRyVy\u0016'\bdC-p";
      wb[186] = "PZFm'9\u000b\u0006Ft\u001b:l\f\u0017?d)\u0016]\u0016}e|lP\u0003tr#W\n\u001ea&E";
      wb[187] = ";{>\t#x(2:\u0015\u001ayK16Gey1`7\u0005d,Km\"\fssp7?\u0019'\u0015";
      wb[188] = "\u000fX|UIC\b\buCE\"]h%Q\u0004]X\u0012tPF\\\rh%\fVKI\t\"\\_]Eh";
      wb[189] = "l\u001b^b\u001722\\Sy*m5^\u0007qV\u0003l\u001b^b\u001722\\Sy*8?\u0014\u001dtPi>V\u001c!*=m\u0018\u0018%\u001bc*\u0015\u0003\u0018";
      wb[190] = "\\u<%[nU++b\u001a\u0013\f\u001bj1Tl\ta;0\u0016m\\\u001bk<^xYe.,\b}e";
      wb[191] = "@C\u0018PT]F\u001f\n\u001e%\u0002F\u0001\u0012HI0\u0012EJ\u0012%W\u0017\u0000\u001dPFYM\u0013\u001b/";
      wb[192] = "2a%doU<;6b\u0010So!8l|a;eb4\u0010_f-'l~Unf*\u000b";
      wb[193] = "\u001aj+;/ED-& \u0012\u0019](~%it\u001f7'*\u007f\u0014Yh,/\u0012NDo|}l\u000bT9yA";
      wb[194] = "d9\r;g5,1I~\u0000<8$Qdl\u000ek`\n9\u0000;ei\\xja6?T\u0003";
      wb[195] = "I\u001c74++N\u001c{ W,1V+u()K\u0007*7)|1\n?>>#\nP\"+jE";
      wb[196] = "\u0007KZ\u0010$!\\\u0017Z\t\u00184;\u001d\u000bBg1AL\n\u0000fd;\u0016\u0004C~2PCZ\u0013\u007f]";
      wb[197] = "\u0015\n61v\u007f\u0012O#!r\u0012I\u001c'!x~{Hd~/(,\u001cg:e`V\u001c?+n\u0012";
      wb[198] = "B\f\u001f$R\u001f\u0012\b\u0012\"\u0003y\u00112IwX\u0006\u0014H\u0018v\u001a\u0007A2HzR\u0012DL\rj\u0004\u0017x";
      wb[199] = "&c5\u000f4\u0010&*\"\u0004%sz63\u0005!\u001fHbr^xH\u001f9\u007fT+\buc,\u0002#s}k~\b=\u0019'8(\u0000F\u0011/j\"\u001e,K|<*e$C.64\u000f~\u0010x>O";
      wb[200] = "o5L\\Ho,,ML%l|!QAr?-t\u0005-W{d=X@\u0014be-";
      wb[201] = "\u0003o` \u00011X3`9=$??l!\r)[\u007f;3_M\u00022?rY)Be- =";
      wb[202] = "3IT\u000f~UwW\u001f\\}9oEZR|U]\u0011\u001e\b%\u0005\n\u0011\u0017\u000e\"\u0003j\u0019\u001a\r\"9";
      wb[203] = "y\u007f\u000be4ya,NrTswiU~8A'%\u000f(T}$\u007fJhn{xm\u0004\u0019";
      wb[204] = "p\u0010Weu/+LW|I8LF\u000676?6\u0017\u0007u7jLMWz&,/C\ri S";
      wb[205] = "D\bSl\u0015\u0004\u0019[\u000f?\u00055\u00147\foDJ\u0011M]n\u0006KD7\r<\u0019\u000bGQ]8\u0014\r\u00167";
      wb[206] = "e#D~=2!=\u000f->^9/J#?2\u000b{\u000eyfe\\{\u0007\u007fad<s\n|a^";
      wb[207] = "Z\u001a/FPf\u0001Pq]l;?Sz\b\u00137E\u0002{J\u0012b?\u000fnC\u0005=\u0004UsVQ[";
      wb[208] = "wX#Hx4w\u00002C\n+w\u00188Uf\u0019'Zb\u0002\nw+Xa\bj\u007f&[a2";
      wb[209] = "\noT\u0019\u001f2\u00045G\u001f`4W/I\u0011\f\u0006\u0003k\u0013G`a\u0006.F\t\u0003o\\=@v";
      wb[210] = "\b9\u0006Tc_\nfG\u0010\nVV;\u0012\u0004cZo5\u0012\u0014g<\u000b<L\u00026BN,\u001a\u0007\n";
      wb[211] = "duRsh-j/Au\u0017+95O{{\u0019mq\u0015\"\u0017~h4@ctp2'F\u001c~*$6Hrt\"o;/";
      wb[212] = "\u0010{BSF\u000b@\u007fOU\u0017mCE\u0014\u0000L\u0012F?E\u0001\u000e\u0013\u0013EM]M\u0000Q/\u0017\u000e\u001b\b*";
      wb[213] = "TGLe\u0010Z\u000f\u001bL|,Zh\u0011\u001d7SJ\u0012@\u001cuR\u001fhM\t|E@S\u0017\u0014i\u0011&";
      wb[214] = "!L\u0007R^mz\u0010\u0007Kbx\u001d\u001aV\u0000\u001d}gKWB\u001c(\u001d\u0011\u0007M\rn~\u001f]^\u000b\u0011";
      wb[215] = "_du1\u0019)\u00048u(%<c2$cZ9\u0019c%![lci\"2^6\u001a8w.EU";
      wb[216] = "S c\u0002\u0013aR<1\u001a}iX'\\AL0\u0000{<IA3\u0000AeIA5\u0003!mDB59xmDD6Yp`GD\f";
      wb[217] = "S\u001e`\u001f@[KM%\b Q]\b>\u0004Lc\rDf^ \u000ePN5_^K@\u00180c";
      wb[218] = "6\r/u\u000f\u000emQ/l3\u0014\n[~'L\u001ep\n\u007feMK\nZs-XNt\u001fc{]r";
      wb[219] = ".E3\u000ev@/Ya\u0016\u0018H-T\f\u0016(\u001c)_fL{J!$nD)@?N4\u0017\u007fHDF<EuV.\u001co\u0013}-";
      wb[220] = "XHN2\u0002.Z\u0011\u00122\u0000\u0015\ft\u0013bTj\r\u000eBc\u0016kXt\u0012o^~]\nW\u007f\b{a";
      wb[221] = "TKsD?\u0011\u000f\u0017s]\u0003\u0000h\u001d\"\u0016|\u0001\u0012L#T}Th\u001c/\u001chQ\u0016Y?Jmm";
      wb[222] = "%G0{%=\u007f\u0002u7~TyUugs8K\u000298-T%Gsv*)n\u0002x`fT%FwlrmuUpepT";
      wb[223] = "wP)[bN`\u000f#G\u0000Eu\fY\u0011b\u001cr\r9W=\u0017w`cJ:G%\u001e&ZlB\u0019";
      wb[224] = ")3?\u0006\u0017b>l5\u001au{&q\"wL1{:u\u0017D<x:O";
      wb[225] = "\u001e.\u007f\u000e{CEr\u007f\u0017GS\"x.\\8SX)/\u001e9\u0006\"y#V,\u0003\\<3\u0000)?";
      wb[226] = "J9J=X'_8Oe?!QfVe^,M\u0000\u0011n\u000f![`W1\u0004$6:J6TvH\u007fZ`QJ";
      wb[227] = "z<\u0012\u0016E\"24VS\"+&!NIN\u0019ue\u0010\u0011\",{lCUHv(:K.";
      wb[228] = "Y!9(q\u0013\u0000}i%|}\u0005}(\"x\u00117)l{\"F`)e/u\u0013\u000ep9\u007fx\u001e`";
      wb[229] = "ki;M?E//2@\"}?=\"\u007f:\u0019-=^\u001a1M;=>\\nF>P";
      wb[230] = "Va:.]B\u0012\u007fq}^.\nm4s_B89p+\t\u0015o9y~R@\u0001`%._Mo`#rCM\u00161vnX.";
      wb[231] = "?\u0004\u00150,Ex\u0004T:-<{SN(.{k:C13CbTI9xN\u0005\u0000\u0014j&S|G\u0014+,R\u0005";
      wb[232] = "3\u0003\tc===Y\u001aeB;nC\u0014k.\t:\u0007N5B7gO\u000bk,=o\u0004\u0006\frb~P\u000bo|8mVt";
      wb[233] = "{x\u0000J.V $\u0000S\u0012CG.Q\u0018mF=\u007fPZl\u0013G/\u0006Qv\u00155yDU~GG";
      wb[234] = "S{\u0015\u0011\u0006*\u0006%E\u0010i$\u000eeD\u0010\u0005\u0016^'\u001eGixR%\u001dM\tp_&\u001dw";
      wb[235] = "`ZWV)(=\\\bNx\u00113:\\G%n6@\rFgoc:]J/zfD\u0018Zy\u007fZ";
      wb[236] = "kC\u001e&{\u0000j_L>\u0015\bhR!5q\u001d~EO?yVs\"H8e\u0012fLB0.\u001f\u0001KE,j\noAMggm";
      wb[237] = "> Nx>a))Ax@h619,8g2MIy|>a-At\u007f>[";
      wb[238] = "Y\u001b*xF\\\fEzy)R\u0004\u0005{yE`TI##)\r\tCp\"WH\u0019\u0015u\u001e";
      wb[239] = "z&\u001bB\u000f\u000b2._\u0007h\u0002&;G\u001d\u00040py\u001bGTg)w\u0016\u0017\u0013\rs$@\u001fh";
      wb[240] = "~U{C[+%\t{Zg>B\u0003*\u0011\u0018;8R+S\u0019nB\u0002'\u001b\fk<G7M\tW";
      wb[241] = "@~1\u0012J4Abc\n$<Ky\u000e\n\u0014hGddPG>O\u001flX\u00154Qu6\u000bC<*}>YI\"@'m\u000fAY";
      wb[242] = "\u001aaP3sT\r>Z/\u0011W\b<Z+mQ\u000eQO\u007fk\\\r=\\&,]t";
      wb[243] = "9J\r\u0017J\u0002n@\u0002L\u0000~k I\u0011B\u0001nZ\u0018\u0010\u0000\u0000; I\u0016\r\u0015:\\\u001e\u001c\u0002Np ";
      wb[244] = ",pR\u000b\r[#{LRq\u0000-aWQ\u001d2p!\t\u0007q\\q!\u000e\f\u0011T|\"\u000e6\u001cY;gEL\u001c\u0001*l7";
      wb[245] = "\u000fh<X\u0007\u0005\u0017rn9\u000bhPn5F\u000e\u0012\u0001owG[h\fz~P\u0004SVgk\u0004b";
      wb[246] = "\bO\u001b\u0011*u\u000e\u0013\t_[!\u0002\u001c\u0015\u0002\fvXKHn2+\u0013\u000e\u0016\u00008#X\u0003";
      wb[247] = "\u0011E>fc6\u0010Yl~\r2\u0011_\u0001~=j\u0016_k$n<\u001e$c,<6\u0000N9\u007fj>{";
      wb[248] = "iBbrc\u0000z\u001b%s\u001a\u0016k\u001a\u007ffwla\u0006cq|W;\u001bv%\u001a";
      wb[249] = "M?\u001f.G4\u0016c\u001f7{*qiN|\u0004$\u000b8O>\u0005qqhCv\u0010t\u000f-S \u0015H";
      wb[250] = "\u0007\u0002\rVY\u0017M\u0010MVe\r\u001a\u001e\u001cQ\t?MRM\beY\u0016^DQ\t\u0011\u001e\u001a\u00016\u0017\u0011\u000e\u0013\u0011[T\b\u000f\u0003|\u000f\b\u0014\t_\u0007OT\b\r\u001d|\f\u001fW\u001d\\\u001dY\u000f\u0019\u0007\u0003|";
      wb[251] = "\u001f@Yv*POS^\u007f(iCS[}+\u0005q\u0004\u0016 }i\u001f\u000f\u001b$v\t\u0017\u0002\u0018$L";
      wb[252] = "\u0016,<\u0013E\f\u00170n\u000b+\u001b\u001b0e\u0005+\u0003L|n\u0012AY\u001f*fi\u0012P@t9\t\u001a]Ct\u0003";
      wb[253] = "\u0015Q}6\u0013fS\u000b(8D]Ej(9I\"@\u0010y8\u000b#\u0015jpl\u001a:P\u0018s0\u00006,";
      wb[254] = "\u0015*/3*3\u0006c+/\u0013>e`'}l2\u001f1&?mge<36z8^f.#.^";
      wb[255] = "AWdYtQG\u000bv\u0017\u0005\u0005K\u0004jJRR\u0011S6&l\u000fZ\u0016iHf\u0007\u0011\u001b";
      wb[256] = "F\u001e\u0003_F8\u0003D\u0016V~kx@\n\u0005\u0001m\u0002\u0011\u000bG\u00008xK[H\u0011~\u001bE\u0001[\u0017\u0001";
      wb[257] = "5(`*pw\"wj6\u0012z6d\u0010b#)b\"pj.*b\u0018+9\"~6xmf){[";
      wb[258] = "\u0006+jx?\u000f[x6+/>U\u00145{nASndz,@\u0006\u0014l&oSD~6u9[?";
      wb[259] = "${x=\u0011`\u007f'x$-f\u0018-)oRpb|(-S%\u0018q=$Dz#+ 1\u0010\u001c";
      wb[260] = ".}tvD4u!tox+\u0012+%$\u0007$hz$f\u0006q\u0012*(.\u0013tlo8x\u0016H";
      wb[261] = "hp\u0014X\u001aDi$\u000fT\u0015u?HFP\tD>%\u0007WK\u001c?";
      wb[262] = "J)\u000e'YoCw\u0019`\u0018\u0012\u001aGX3Vm\u001f=\t2\u0014lJGZoZ+I'RbY+s";
      wb[263] = "A\n,}\u0004UYYijd_O\u001crf\bm\u001f^,>d\u0003]\u001ac?\u0019H\u0018\u0011usd";
      wb[264] = ",B\u0006\u0019\u001dSh\\MJ\u001e?pN\bD\u001fSB\u001aL\u001cH\u0003\u0015C\u001fE\u0003\\l\u0012JY\u0018?";
      wb[265] = "m\u0013%1C\u0006u\twPLk0I i\u001c\u000b8D#i&";
      wb[266] = "K\u000b^5\u0013\u0005A\u0015O#kRE\u001eS0<\u0005\u001bM\u000e\\\u001b\\U\u0013\u000b#QN\u0015\u0013";
      wb[267] = "y\u001a\u000f@\u0002s1\u0012K\u0005eq)\u0016W\u00142$yG\u000fx\\`q\u0007\u0002\u0011\u0006%4KY";
      wb[268] = "FL_\u0013Ma\u0013\u0012\u000f\u0012\"d\u0017C\n\u0019u4N\u0017Tu\u001b;J\u0017T\u0015\u00136I\u0017";
      wb[269] = "Cv&J$Y\u0018*&S\u0018G\u007f w\u0018gI\u0005qvZf\u001c\u007f|cSqCD&~F%%";
      wb[270] = "]^J2RU\u0017L\n2nO@B[5\u0002}\u0017\u000f\u0002bnIG\u0000G2\u0001Q\u0014EPR\u0003\u0016VDI(\u0003NGO;5\u0017QDX\u0000o\nD\u0010>";
      wb[271] = "Z&_8J\u0007XyA-Yx\n@\n)\u0015\u0007\u000f:[(W\u0006Z@\b\"K\u0004\f?\n}U\u0011\u001f@";
      wb[272] = ":PRY\u00021)\u0019VE;2J\u001aZ\u0017D00K[UEeJFN\\R:q\u001cSI\u0006\\";
      wb[273] = "\u0016\u0007wt\u0019\u000b\u0005Nsh \bfM\u007f:_\n\u001c\u001c~x^_fLr0KZ\u0018\tbfNf";
      wb[274] = "\u0010a'\u001cv\b\u0003(#\u0000O\b`+/R0\t\u001az.\u00101\\`w;\u0019&\u0003[-&\fre";
      wb[275] = "UA\u001aL}!S\u001d\b\u0002\fu_\u0012\u0014_[\"\u0005EM3e\u007fN\u0000\u0017]ow\u0005\r";
      wb[276] = "h\u007f!<\u0006\u0002 weya\u000b4b}c\r9g'%8a\u001c gli\f_9f|\u0004\u0006\u0017\"w{?\\\n7#\u001d";
      wb[277] = "L\u001e\u000eg_[\u0015B^jR5\u0010B\u001fmVY\"\u0016[4\r\u0005u\u0016R1\b\u000f\u0015\u001e_2\b5";
      wb[278] = "e\u0007$\u001d,6k]7\u001bS08G9\u0015?\u0002l\u0003cHSeiF6\r0k3U0r:1%D>\u001c09nIY";
      wb[279] = "!\r'a\u001d\u0015~R,)\u001fq}\u0002?0\u0018\u001dOS~l@M\u0018U#j\u0014Mf\u00103<\u0011q";
      wb[280] = "\u0019lEVF\"]r\u000e\u0005ENE`K\u000bD\"w4\u000fQ\u001dv 4\u0006W\u001at@<\u000bT\u001aN";
      wb[281] = "\u0005>\u0019M\u000f#@d\fD7s;`\u0010\u0017HvA1\u0011UI#;kAZXeXe\u001bI^\u001a";
      wb[282] = "7$\u0013r\u0011n2.\u001awsoJz\u001d \fx0+\u001cb\r-J&\tk\u001arq|\u0014~N\u0014";
      wb[283] = "[T*\u001bD\u001eL]%\u001b:\u0017SE^OG\u0015>\u0000%\u0017\u0003B^\b(\u0014\u0003x";
      wb[284] = "Yh$\u0001Qd\u00024$\u0018mqe>uS\u0012t\u001fot\u0011\u0013!el|\u0013\u0012\u007f\u000bftX\u001f\u0018";
      wb[285] = "m[m)YI6\u0007m0eXQ\r<{\u001aY+\\=9\u001b\fQ\u0006m6\nJ2\b7%\f5";
      wb[286] = "+7\u0018\u000fnK%m\u000b\t\u0011Mvw\u0005\u0007}\u007f\"3\\Q\u0011\u0018'v\n\u001fr\u0016}e\f`!\u0014fd\u001a\u0003/Nube";
      wb[287] = "/^o%\u0017ut\u0002o<+m\u0013\b>wTeiY?5U0\u0013\t3}@5mL#+E\t";
      wb[288] = "j~\u0016}\u000eQ1\"\u0016d2UV(G/MA,yFmL\u0014VtSd[Km.Nq\u000f-";
      wb[289] = "2c\u0002\u0011E\\'b\u0007I\"X\"6b\u001b@\u0001%7\u0002]\u001f\n ZX@\u0018Zr$\u001dPN_N";
      wb[290] = "[N`5'W\rM!59o\u0005KcEsTY^+!2\b\\[vEs\u0003\u001bRt}%\u0000ZRjE";
      wb[291] = "\u0016FA\\c\u0011M\u001aAE_\u001c*\u0010\u0010\u000e \u0001PA\u0011L!T*L\u0004E6\u000b\u0011\u0016\u0019Pbm";
      wb[292] = "G\u0016jpZ1AJx>+nAT`hG\\\u0015\u001093+bHX\u007fhEh@\u0013r\u000f@5FWq5FiT\u0019\u0000";
      wb[293] = "9\u0013&O\u0000MyO:KB6e\u0013&QZZWGe\u000e\r\u000e\u0000Gk\\WXn\u001e7\fZU\u0000";
      wb[294] = "0ElWsMt['\u0004p!lIb\nqM^\u001d&R)\u001d\tDu\u000bmBp\u0015 \u0017v!";
      wb[295] = "\u0001;}C\u00019T+3Y^X^,>IX4l{y\u0017\u0001e;{\"\u0013TdE>2EQX";
      wb[296] = "\u001aA>\u000fOm\u001c\u001d,A>9\u0010\u00120\u001cinJEnpW3\u0001\u00003\u001e];J\r";
      wb[297] = "w6T|Ou\"h\u0004} {*(\u0005}LIzd_+ uy>\u001ak\u001as%,T\u001a";
      wb[298] = "b\u0017-z$\u00051\u000b\"8.|3\u0007hys\u001a$&sfs99\u001evbe|'\u001d+|e\u0013e\b);\u001e";
      wb[299] = "b2\u0004\u0005\u0012Z7u\u001f\u0016\u0018a0\u000fO\u001aZ\u001e5u\u001e\u001b\u0018\u001f`\u000fOJ\u001a\u0013!4\u001a\r\u0001\u0000+\u000f";
      wb[300] = "[!d]\u001c;\u0006r8\u000e\f\n\u000b\u001e;^Mu\u000edj_\u000ft[\u001e0\u000f\u0000e\u001d}>U\u0013cb";
      wb[301] = "\b6uK\u0018\\\u0002(d]`\u000b\u0006#xN7\\Xs!\"Z\u0006\u001e\"x\u0018\tT]~\"";
      wb[302] = "faK\u007f\u001dJv1Xw`_|d_;\u001cYZon,\u001bY}}'}\u0002\u0004plG;]\u000fu\u0001\u001c}YH+e]!\\Mv\u0001\u001c$P_vaZ{[Z\u001b";
      wb[303] = "~>LKC<\u007f\"\u001eS-4u9sXI!k8\u001dRAjf_\u001aU].s1\u0010]\u0016#\u00146\u0017AR6z<\u001f\n_Q";
      wb[304] = "}\u0019v:2emIe2Opd\u0014syO|y\u0002set&d\u0017'\u0003";
      wb[305] = "\u000e\t\u000e]\t;\u000f\u0015\\Eg-\u001d\u0012M'\u000e2\u0014\u0017VI\u0004:_\u001a1N\u0003&\u001b\u000f_D\u000bm\u0016h";
      wb[306] = "0\u0001&&WC9_1a\u0016>`op2XAe\u0015!3\u001a@0o,&\u0013WoTv;\u0006\u0003\t";
      wb[307] = "\\G5?8w\u0007\u001b5&\u0004a`\u0011dm{g\u001a@e/z2`Cm-{l\u000eIefv\u000b";
      wb[308] = "yN]jDjy\u0007JaU\t%\u001b[`Qe\u0017O\u001a;\u000b1@\u001fCpIn.\u0015K;D\t)\u0012W\u007fQg#\u001a\u001cr6`$\u0006XgXj,MU\u0000_m0\t@nUe{\u0004'";
      wb[309] = "4x$L7r#q+LI{<i@\u0011%\u0014h$&Est`)%EI";
      wb[310] = "(X\u0018Q,s=Y\u001d\tKu0\f\u0011\u001aKy-\u001a\u0011\u0006p#0\u000fE`";
      wb[311] = ";w+C\u0014tb+{N\u0019\u001a|/\"T\u0017a\u0002\u007f'HCdp9!J\bj\u0002";
      wb[312] = "\n}JY!8Nc\u0001\n\"TVqD\u0004#8d%\u0000\\zn3|S\u0005?7J-\u0006\u0019$T";
      wb[313] = "[4saC^\u0013<7$$W\u0007)/>HeQnrf\u001d2Zi26[QT3!0$";
      wb[314] = "xDs\fW\u0002#\u0018s\u0015k\u0007D\u0012\"^\u0014\u0012>C#\u001c\u0015GDN6\u0015\u0002\u0018\u007f\u0014+\u0000V~";
      wb[315] = "~dgx\u001dX+\u007f4f\u001ce)lcc\u00112w7>>}\\.r>=\u0004\u0006 7ni";
      wb[316] = "C\u0017 LSZMM3J,\\\u001eW=D@nJ\u0013g\u0013,P\u0017[\"DBZ\u001f\u0010/#E]\u0003T:MOUHY]JHI\fL3@@\u0002\u0001+4G\\F\u0014E>O\u0017Ks";
      wb[317] = "EOtaZ\u0004\u0014\u001ahz9\u0018HXu}U*\u001c\u001c/$\u0001}\u001c\u0015)#\u0003\u001d\u0014\u0018*#9";
      wb[318] = "\b\u0017qVE\u001cT\u0012d\u0004E~S\u0010`O\u0016\u0002U\u0016\rZB\u0004X\u0015aI\u001bCYl";
      wb[319] = "~E\u0014\u00155u%\u0019\u0014\f\teB\u0013EGve8BD\u0005w0BJ\u0018Fdr(\u0010K\u0010l\t";
      wb[320] = "kz#\u0001\u007f\u0005:/?\u001a\u001c\u0019fm\"\u001dp+2)zJ |kz#\u0001\u007f\u0005:/?\u001a\u001c";
      wb[321] = "Xw\r\u001azk\u0003+\r\u0003Fgd!\\H9{\u001ep]\n8.d}H\u0003/q_'U\u0016{\u0017";
      wb[322] = "Te\u0016XZXR9\u0004\u0016+\f^6\u0018K|[\u0004aG'B\u0006O$\u001bIH\u000e\u0004)";
      wb[323] = "(L\r\u0002:\u0000.\u0010\u001fLK_.\u000e\u0007\u001a'mrC[} \u0004)\r\u0016G&X;CgG+\u0000(N\u0019\u0002;V-r";
      wb[324] = "j1ZKA!dkIM>'7qGCR\u0015c5\u001d\u001c>rfpH[]|<cN$\u000e~'bXG\u0000$4d'";
      wb[325] = "^/wr\t%I&xrw,V>\u00068\u001a.]BpsKz\u0001\"x~Hz;";
      wb[326] = "b]$\u00072x*U`BUq>@xX9Cm\u0005!\u0002U.3\u0006s\u0003+k#Pv?";
      wb[327] = "\u0019;SB8h\u001e;\u001fVDlaqO\u0003;j\u001b NA:?a-[H-`ZwF]y\u0006";
      wb[328] = "\u0011r<#HGW(i-\u001f|AIi,\u0012\u0003D38-P\u0002\u0011I58Y\u0015Nro%LA(";
      wb[329] = "h9}\fQ\u00044<h^Qf5,\u0001T\tV9/a\u0012V]<B;\u0014\u0017\u0005h g\u0011\u0002WhB";
      wb[330] = "D\u0000%*p_\\\u001awK|2\u001b\u0006,4yHJ\u0007n5,2\u001a\u0005n!eWRQ%6x2";
      wb[331] = "\u00114j*\u0007\u0010Jhj3;\t-b;xD\u0000W3::EU-c6rPPS&&$Ul";
      wb[332] = "K=7=sfS'e\\}\u000b\u0016g2e,k\u001ej1e\u0016";
      wb[333] = "om'\u0010`\u0016=`}\u0010cs<\u0001!\u00120\f:{p\u0013r\ro\u0001 \u001f:\u0018j\u007fe\u000fl\u001dV";
      wb[334] = "7\u0007T?4\u00029]G9K\u000ffVM<\u001cX<\u0006\u0011P\"\u0005wDN>(\r<I";
      wb[335] = "kaBe+na\u007fSsS9etO`\u0004n;#\u0017\fb68!L`*>|d";
      wb[336] = "\u007fIOqT\u00197A\u000b43\u0010#T\u0013._\"w\u0018Lx\u0003u~\u0014\u000e&L\u0016pN\u001d 3";
      wb[337] = "\u001b\u0007y[P\t\b^>Z)\u0005\u001dAE\\Y\u0019t\u0000c\u000bBY\nEs]Ge";
      wb[338] = "w\u0006B=Qp`YH!3sb{W4Oc\u0019\fRvX.gIB ]\u0012";
      wb[339] = "2_0\u007f\u0004~r\u0003,{F\u0005n_0a^i\\\u000bs>\u0006:\u000bR'`Bfr\u0003r|Y\u0005";
      wb[340] = "$wwP\u000e\ry$+\u0003\u001e<qH(S_Cq2yR\u001dB$H)\u0000\u0002\u0002'.y\u0004\u000f\u0004vH";
      wb[341] = "l2N!d\u007f.0\u001e0k\u0010,:Y<\u007fk;;'k`y&6H)b)79'";
      wb[342] = "\u001f\u000e_AYjDR_Xew#X\u000e\u0013\u001azY\t\u000fQ\u001b/#Y\u0003\u0019\u000e*]\u001c\u0013O\u000b\u0016";
      wb[343] = "~w\u0011LB\u0013}g\u0010G\u0006w b\u0004\u001dX\u001e#\u0018QM\u0002N}xY@\u0001NG";
      wb[344] = "\u000f+2S\bP\rrnS\nk\\\u0017o\u0003^\u0014Zm>\u0002\u001c\u0015\u000f\u0017n\u000eT\u0000\ni+\u001e\u0002\u00056";
      wb[345] = "=DP\u001ec09\u001f\\\fxNo{\u0006\u0010)1j\u0001W\u0011k0?{\u0006Bt-|\u0005\u0002\u0019x?g{";
      wb[346] = "U\u000eWhsPE^D`\u000eCN\u0012A UCTn\u0001*rM\u0012\f]/g\u001f\u0012n";
      wb[347] = "o#x,Ap1du7|?8x9;;/Q'&f\u0017,1aym\u0012Ao#x,Ap1du7|";
      wb[348] = ",XG{N9}\r[`-%!OFgA\u0017p\r\u001b=\u001d@|\u000f[oR#rUHi-";
      wb[349] = "\r\ryd*LVQy}\u0016[1[(6i\\K\n)th\t1\u0002u7{K[X&as0";
      wb[350] = "\u0014p&hq&\\xb-\u0016/Hmz7z\u001d\u0018/$o\u0016sZkknk8\u001f`}\"\u0016";
      wb[351] = "\u001eW#4D\fBL'5.S\u001bV.vpT\u001bL*\nL\rN\\<`\u0016^\u0018TG";
      wb[352] = "\u000fSG\u0003NGV\u000f\u0017\u000eC)S\u000fV\tGEa[\u0012P\u001e\u00156[\u001bU\u0019\u0013VS\u0016V\u0019)";
      wb[353] = "\u0004E.WxO\u0017\f*KAKt\u000f&\u0019>N\u000e^'[?\u001bt\u000euD\u007f\u0018\u0012^qIyIt";
      wb[354] = "tk[K\u0012\u00075l\u0019\u0013\u0013j!\u0012\u0018\u0017M\u0015!hI\u0016\u000f\u0014t\u0012J\u001e\r\u0015*|@\u0016F\u0018M";
      wb[355] = "\u0016`\u0012\u001a\u001a\u0011M<\u0012\u0003&\u0007*6CHY\u0001PgB\nXT*=\u0012\u0005I\u0012I3H\u0016Om";
      wb[356] = "|E\fy#\tr\u001f\u001f\u007f\\\u000f!\u0005\u0011q0=uAJ/\\\u0003(\t\u000eq2\t B\u0003\u00165\u000e<\u0006\u0016x?\u0006w\u000bq\u007f8\u001a3\u001e\u001fu0Q>yA*!\u00053\u001aOp2\u0003L";
      wb[357] = "\u001c\u007f'i\u001a7G#'p&\" )v;Y'ZxwyXr +*7\u001fq@#'4\u001fK";
      wb[358] = "{\u000e}C>\u001d R}Z\u0002\rGX,\u0011}\r=\t-S|XGS}\\m\u001e$]'Oka";
      wb[359] = "?\u001c>\u0000e\u0003=C \u0015v|lzk\u0011:\u0003j\u0000:\u0010x\u0002?z7\u0005q\u0015`Am\u0018dA\u0006";
      wb[360] = "Eypa]\u0006\u0018*,2M7\u0015F/b\fH\u0010<~cNIEFsvG^\u001a})kR\n|";
      wb[361] = "\u0014}X\b[8\u0015*U\u0017O^C%S\bF\t\u001cu\u000eS*g\u0017\u007fO\u001cD#\\{\\\n";
      wb[362] = "OU_\u0010\u0006W\u0011\u0012R\u000b;\u0006\u0018\u0011\u0003!\\\n\u001cjZ[\u0007_K\nRV\u0004_q";
      wb[363] = "*L\u0000sRJq\u0010\u0000jn_\u0016\u001aQ!\u0011ZlKPc\u0010\u000f\u0016DQ/^HpSX ^6";
      wb[364] = "=Z\bg\u007f4f\u0006\b~C5\u0001\fY5<${]Xw=q\u0001PM~*.:\nPk~H";
      wb[365] = "\\;.\u0018\b'\u0007g.\u000145`m\u007fJK7\u001a<~\bJb`f.\u0007[$\u0003ht\u0014][";
      wb[366] = "n\u0019\r:k\u0007i\u0019A.\u0017\u0000\u0016S\u0011{h\u0005l\u0002\u00109iP\u0016\nLzz\u0012|P\u001f,ri";
      wb[367] = "!\u001bVk\u00162pNJpu.,\fWw\u0019\u001cxH\u000f!NKxAZz\u001b%!\u001d\nw\u0016K!\u001bVk\u00162pNJpu";
      wb[368] = "\\\u001a*\u0015,gS\u00114LP<]\u000b/O<\u000e\u0000Lt\u0013P4\f\f5Z*4T\u001d>(;gZ\b>\u0012=;HFOFo\"WG%Q+6Rw!\u0018 (R\u00156G*40";
      wb[369] = "[\tU\u0012\u0002G\u0013\u0001\u0011WeN\u0007\u0014\tM\t|WXS\u001be@T\u0002\u0016[_F\b\u0010X*";
      wb[370] = "<+k\"Zf65z4\":>/b,N\bjn<z\"e3iiw\\ #?lK";
      wb[371] = "&K68\u0014C%\u0017,4hP#\u000f\u000b6\fL(slnT\b\u007f\u0013dcW\bE";
      wb[372] = "\u001b(sElq@ts\\Pj'~\"\u0017/a]/#U.4'\"6\\9k\u001cx+Im\r";
      wb[373] = "\u0006@'v<7\u0015\u0019`wE=\u0004\r!\u001c~9Y\u00160|8fR\u0013]";
      wb[374] = "\u0017OS\u007fr9\u000f\u001c\u0016h\u00123\u0019Y\rd~\u0001J\u001dV9\u00124D\u0014\u0000xxn\u0017B\b\u0003";
      wb[375] = "\u001bk\u000f4~[\u001d7\u001dz\u000f\u0004\u001d)\u0005,c6AdZK?]\r:\u001a(1\u0007\u001e<e 1\u000b\u000f$_&m\u0019AU";
      wb[376] = "SOqLI\rTO=X5\n+\u0005m\rJ\u000fQTlOKZ+\u0004`\u0007^_UApQ[c";
      wb[377] = "nr?MLR5.?TpJR$n\u001f\u000fB(uo]\u000e\u0017RxzT\u0019Hi\"gAM.";
      wb[378] = "`q \"]\u0019w.*>?\u0010j,9)?\u001cw:95\u0004Fj/mS";
      wb[379] = "\"i,^0\u0010,3?XO\u001ds85]\u0018J)hk1&\u0017b*6_,\u001f)'";
      wb[380] = "P1\u001ahO{^k\tn0v\u0001`\u0003kg![0^\u0007Y|\u0010r\u0000iSt[\u007f";
      wb[381] = "\u001bZf\u0010I!B\u00066\u001dDOG\u0006w\u001a@#uR3C\u0019r\"R:F\u001euBZ7E\u001eO";
      wb[382] = "R\u0012\u00167)\u0011JAS I\u001b\\\u0004H,%)\u000bD\u0015rt~Q\u0013I0*\u0007\u0000FU+I";
      wb[383] = "dB'vb.9\u0011{%r\u001f4}xu3`1\u0007)tqad}z(m}4\r:scn>}";
      wb[384] = "w3k\u001b\b6}-z\rpay&f\u001e'6'u?rI?v)k\u0002\tdx:a";
      wb[385] = "U\r@i\u007fX_\u0013Q\u007f\u0007\u000f[\u0018MlPX\u0004E\u0016\u0000k\f_HU>d\u0007A\u0011";
      wb[386] = ")pf\u001d\u001a\tr,f\u0004&\u001b\u0015&7OY\u0019ow6\rXL\u0015':EMIkb*\u0013Hu";
      wb[387] = "^I\u001a\tZ%\u0007GL\u0010\u0005T\u000e-\u001a\u0000\u0004+\u000bWK\u0001F*^-\u0011QI;\u0018N\u001f\u000bZ=g";
      wb[388] = "q\u0003<\u000fla V \u0014\u000f}|\u0014=\u0013cO(PgJ4\u0018(YaM5x TbM\u000f";
      wb[389] = "w\u001c@\u007fHq,V\u001edt#\u0012U\u00151\u000b h\u0004\u0014s\nu\u0012\t\u0001z\u001d*)S\u001coIL";
      wb[390] = "bZt\u000f.k=\u0005\u007fG,\u000f>Ul^+c\f\u0002.\u0004u2[\u0002p\u0004'3%G`R\"\u000f";
      wb[391] = "oZf\u0011EynF4\t+}o@YR\u001a(<\u00019Z\u0017+<;`Z\u0017-?[hW\u0014-\u0005";
      wb[392] = "r`?X\u000610boI\t^#b3P\u000e$)c9d\u0000#\"a;(]&st)U\u000b5rwk(];!u7G\u001f9qd8(";
      wb[393] = "\rQ\u0016\u0011\u000e&\u000f\u000eWUg;]P\u001bA +4\u000e\u0006\u0016\fyJK\u0016@\tE\rQ\u0016\u0011\u000e&\u000f\u000eWUg";
      wb[394] = "W_Y[@E\f\u0003YB|Rk\t\b\t\u0003U\u0011X\tK\u0002\u0000k[\u0001I\u0003^\u0005Q\t\u0002\u000e9";
      wb[395] = "rHWG>\u0012sT\u0005_P\u0004yOhT4\u000fgN\u0006^<Dj)\u0001Y \u0000\u007fG\u000bQk\r\u0018";
      wb[396] = " 7\u001f\u0013SO8dZ\u00043E.!A\b_w}e\u001fP3BslL\u0014Y\u0018 :Do";
      wb[397] = "Hd\u0018%dQ\u00191\u0004>\u0007MEs\u00199k\u007f\u00117C`;(\u0011>Eg=H\u00193Fg\u0007";
      wb[398] = "el~\u0013>uc0l]O*c.t\u000b#\u0018?c.l\u007fss=k\u000fq)`;\u0014\\s2a-wR)!gR/\u00004?ajy\u0003u?\u007fR";
      wb[399] = "IQP\u000fY\u0014\rO\u001b\\Zx\u0015]^R[\u0014'\t\u001a\u000b\u0004Cp\t\u0013\u000e\u0005B\u0010\u0001\u001e\r\u0005xI\u0001\u001e\u000b\u0006\u0018A\f\u001d\u000b<AA\f\u001b\b\\IL\u000f\u001b2\u0005\u0019\u0002\rG^A\u0007I^D2";
      wb[400] = "u{<\t\u0015],jvBw[O0nC\u001c_/v1H\u00192";
      wb[401] = "\"<t\r\u0012\u001bj40Hu\u0012~!(R\u0019 .bs\u0004u\u001a/&2G\u000f\u001aw795\u0017G\"03_M\u0014t8H";
      wb[402] = "\u000ePqH8)\\]+H;L^<wJh3[F&K*2\u000e<+^#%Q\u0007qC6q7";
      wb[403] = "a\u0013)}t\u0017:O)dH\u0010]Ex/7\u0007'\u0014ym6R]\u0019ld!\rfCqquk";
      wb[404] = "Q\rYQ \u0004\u0000XEJC\u0010H\u001bQN8}\n\u0004\bA.\u001dL[\u0003DCGQ\\S\u0016=\u0002A\nV*";
      wb[405] = "=@?=A,3\u001a,;>!l\u0011&>iv6AyR\u000esp\u0013=1\u0000)c\u0015";
      wb[406] = "\u0002Sz);\u0007\u0003\u0007a%46\\ka)5H\u0002\u0006r`1T";
      wb[407] = "hxod=\u001f=c<z<\"?pk\u007f1ua*>\"]\u001b8n6!$A6+fu";
      wb[408] = "o\u0018\u0015QR?)B@_\u0005\u0004?#@^\b{:Y\u0011_Jzo#B\u0002\u0004=lCJ\u000f\u0007=V";
      wb[409] = "B.F~/\u0015DrT0^AH}Hm\t\u0016\u0012*\u0010\u00017KYoKo=C\u0012b";
      wb[410] = ";p\u0019n\u0003|`,\u0019w?`\u0007&H<@l}wI~A9\u0007'E6T<ybU`Q\u0000";
      wb[411] = "\u0017?j^=\r\u00184t\u0007AV\u0016.o\u0004-dKi5[AS\u00103t\u00008\u0002E/ocxQ\u001fcm\u0007'\u000e\u0014+oc";
      wb[412] = "}\u0017\u0000V\u001e\u0005<\u0010B\u000e\u001fh.nC\nA\u0017(\u0014\u0012\u000b\u0003\u0016}n\u0011\u0003\u0001\u0017#\u0000\u001b\u000bJ\u001aD";
      wb[413] = "o\fGI\u0012w=\u0001\u001dI\u0011\u0012?`AKBm:\u001a\u0010J\u0000lo`@FHyj\u001e\u0005V\u001e|V";
      wb[414] = "\u00147:\td`\\2r\u0004x_G\u000f1\u000b* Bu`\nh!\u0017\u000fi\f$#N`q_a4.";
      wb[415] = "T/x~aU\u000fsxg]Chy),\"E\u0012((n#\u0010h t-0R\u0002z'{8)";
      wb[416] = "n?I4?l:(M%\"\u0000<V\u000b:k\u007f9,Z;)~lV\u000b>\"c1:_)&r,V";
      wb[417] = "iF5\u0013$\u00152\u001a5\n\u0018\u0017U\u0010dAg\u0005/Ae\u0003fPULp\nq\u000fn\u0016m\u001f%i";
      wb[418] = "\u0001d#_\\+Z8#F`1=2r\r\u001f;GcsO\u001en=nfF\t1\u00064{S]W";
      wb[419] = "\u0018Vyw,,\u0017]g.Pw\u0019G|-<EK\u0006&th\u0012\u000b\\%5+}II'rP";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = wb[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(xb[var4]);
            wb[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = wb[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = xb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            wb[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  wb[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(358934869433931L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = wb[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = xb[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  wb[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(358934869433931L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        wb[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(358934869433931L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 90;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 214;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 120;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 181;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 86;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 206;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 90;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 214;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 120;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eb_C0220",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$8", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$3", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$17", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$19", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$25", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$24", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$18", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$5", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$6", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding11(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache11;
         MethodHandle var4 = bindingCache11;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$32", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding12(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache12;
         MethodHandle var4 = bindingCache12;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache12 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$30", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding13(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache13;
         MethodHandle var4 = bindingCache13;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache13 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$31", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding14(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache14;
         MethodHandle var4 = bindingCache14;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache14 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$11", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding15(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache15;
         MethodHandle var4 = bindingCache15;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache15 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$20", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding16(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache16;
         MethodHandle var4 = bindingCache16;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache16 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$22", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding17(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache17;
         MethodHandle var4 = bindingCache17;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache17 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding18(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache18;
         MethodHandle var4 = bindingCache18;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache18 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$12", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding19(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache19;
         MethodHandle var4 = bindingCache19;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache19 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$23", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding20(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache20;
         MethodHandle var4 = bindingCache20;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache20 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$4", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding21(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache21;
         MethodHandle var4 = bindingCache21;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache21 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$7", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding22(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache22;
         MethodHandle var4 = bindingCache22;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache22 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$9", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding23(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache23;
         MethodHandle var4 = bindingCache23;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache23 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$15", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding24(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache24;
         MethodHandle var4 = bindingCache24;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache24 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$27", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding25(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache25;
         MethodHandle var4 = bindingCache25;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache25 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$10", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding26(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache26;
         MethodHandle var4 = bindingCache26;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache26 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$29", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding27(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache27;
         MethodHandle var4 = bindingCache27;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache27 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding28(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache28;
         MethodHandle var4 = bindingCache28;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache28 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$28", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding29(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache29;
         MethodHandle var4 = bindingCache29;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache29 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$14", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding30(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache30;
         MethodHandle var4 = bindingCache30;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache30 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$16", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding31(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache31;
         MethodHandle var4 = bindingCache31;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache31 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$13", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding32(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache32;
         MethodHandle var4 = bindingCache32;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache32 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$26", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding33(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache33;
         MethodHandle var4 = bindingCache33;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache33 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$new$21", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Function invokeBinding34() {
         MethodHandle var4 = bindingCache34;
         MethodHandle var3 = bindingCache34;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache34 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/eb_C0220",
                     "lambda$onRenderWorld$33",
                     "(Lnet/minecraft/util/math/BlockPos;)Ldev/zprestige/prestige/ae_C0012;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Ldev/zprestige/prestige/ae_C0012;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding35(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache35;
         MethodHandle var4 = bindingCache35;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache35 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$hasLiveCrystal$34", "(Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding36(AutoObbyCrystal var0) {
         MethodHandle var5 = bindingCache36;
         MethodHandle var4 = bindingCache36;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache36 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eb_C0220;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/eb_C0220", "lambda$blockedByEntity$35", "(Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoObbyCrystal)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static ToDoubleFunction invokeBinding37() {
         MethodHandle var4 = bindingCache37;
         MethodHandle var3 = bindingCache37;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache37 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/ToDoubleFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/eb_C0220", "lambda$search$36", "(Ldev/zprestige/prestige/ai_C0020;)D"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ai_C0020;)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ToDoubleFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding38() {
         MethodHandle var4 = bindingCache38;
         MethodHandle var3 = bindingCache38;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache38 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eb_C0220", "lambda$findCrystal$37", "(Lnet/minecraft/entity/Entity;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/Entity;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Function invokeBinding39(AutoObbyCrystal var0, Vec3d var1) {
         MethodHandle var6 = bindingCache39;
         MethodHandle var5 = bindingCache39;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache39 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/eb_C0220;Lnet/minecraft/util/math/Vec3d;)Ljava/util/function/Function;", MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/eb_C0220",
                     "lambda$rayWithinReach$38",
                     "(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Ljava/lang/Boolean;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/Vec3d;)Ljava/lang/Boolean;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var3.invokeExact((AutoObbyCrystal)var0, (Vec3d)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
