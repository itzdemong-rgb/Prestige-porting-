package dev.zprestige.prestige.client.modules;
import dev.zprestige.prestige.api.util.InventoryUtil;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

public class AutoPearlCatch extends Module implements RotationSource {
   private static final float a = 1500.0F;
   private FloatSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private FloatSetting f;
   private boolean i;
   private boolean g;
   private ElapsedTimer h;
   private boolean j;
   private boolean k;
   private float l;
   private Rotation m;
   private boolean n;
   private boolean o;
   private boolean p;
   private boolean q;
   private Object r;
   private Object s;
   private int t;
   private static final long u = 78851316161155L;
   private static final long[] v;
   private static final Integer[] w;
   private static final Map x = new HashMap(13);
   private static final Object[] y = new Object[149];
   private static final String[] z = new String[149];
   private static volatile MethodHandle bindingCache1;

   public AutoPearlCatch() {
      super();
      long var10001 = 50904551785443L ^ 87165221876938L;
      var10001 = 50904551785443L ^ 54129221742900L;

      this.h = new ElapsedTimer(106698256430889L);
      this.t = Integer.MIN_VALUE;
      FloatSetting var10000 = this.f;
      Object[] var8 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var7 = var10000;
      var7.aReturningFloatSetting(var8);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 20344615825906L ^ 66192819459031L;
      var10001 = 20344615825906L ^ 105950523705770L;
      var10001 = 20344615825906L ^ 6702061700307L;
      var10001 = 20344615825906L ^ 118758372780006L;
      var10001 = 20344615825906L ^ 113534684105167L;
      var10001 = 20344615825906L ^ 118296733056496L;
      int var16 = Event.cReturningInt();
      int var92 = var16;
      Object var91 = this.s;
      Object var68 = var91;
      Object var67 = var91;
      if (var92 != 0) {
         MinecraftClient var18 = b;
         ClientWorld var94 = var18.world;
         Object var93 = var67;
         if (var93 != var94) {
            Object[] var21 = new Object[]{129478283851837L};
            AutoPearlCatch var20 = this;
            var20.lReturningVoid(var21);
         }

         BooleanSetting var23 = this.e;
         var68 = var23.aReturningObject();
      }

      Boolean var24 = (Boolean)var68;
      int var10000 = ((((java.lang.Boolean)(var24)).booleanValue() ? 1 : 0));
      int var96 = var16;
      byte var95 = (byte)var10000;
      byte var70 = var95;
      byte var69 = var95;
      if (var96 != 0) {
         byte var97 = var69;
         if (var97 == 0) {
            return;
         }

         Object[] var27 = new Object[]{22645946496289L};
         AutoPearlCatch var26 = this;
         var70 = ((byte)((var26.eReturningBoolean(var27)) ? 1 : 0));
      }

      int var99 = var16;
      byte var98 = var70;
      byte var72 = var98;
      byte var71 = var98;
      if (var99 != 0) {
         byte var100 = var71;
         if (var100 != 0) {
            Object[] var30 = new Object[]{51348194517541L};
            AutoPearlCatch var29 = this;
            var29.jReturningVoid(var30);
            return;
         }

         var72 = ((byte)((this.i) ? 1 : 0));
      }

      int var102 = var16;
      byte var101 = var72;
      int var74 = var101;
      byte var73 = var101;
      if (var102 != 0) {
         byte var103 = var73;
         if (var103 == 0) {
            MinecraftClient var33 = b;
            ClientPlayerEntity var34 = var33.player;
            Rotation var133 = new Rotation(var34.getYaw(), -90.0F);
            FloatSetting var35 = this.f;
            Float var36 = (Float)var35.aReturningObject();
            float var142 = var36 / 2.0F;
            Object[] var10006 = new Object[]{null, null, null, null, 133142968601602L};
            var10006[3] = 0.2F;
            var10006[2] = 0.0F;
            var10006[1] = var142;
            var10006[0] = var133;
            Object[] var37 = var10006;
            boolean var104 = RotationUtil.dReturningBoolean(var37);
            if (!var104) {
               return;
            }

            this.j = dev.prestige.recovery.SourceSupport.asBoolean(1);
            int var105 = var16;
            if (var105 != 0) {
               return;
            }
         }

         MinecraftClient var40 = b;
         ClientPlayerEntity var41 = var40.player;
         Vec3d var42 = var41.getVelocity();
         double var146;
         int var106 = (var146 = var42.x - 0.0) == 0.0 ? 0 : (var146 < 0.0 ? -1 : 1);
         var74 = var106;
      }

      int var79;
      label95: {
         int var78;
         int var108 = var16;
         int var107 = var74;
         var78 = var107;
         int var75 = var107;
         label94:
         if (var108 != 0) {
            int var109 = var75;
            if (var109 == 0) {
               MinecraftClient var45 = b;
               ClientPlayerEntity var46 = var45.player;
               Vec3d var47 = var46.getVelocity();
               double var147;
               var10000 = (var147 = var47.z - 0.0) == 0.0 ? 0 : (var147 < 0.0 ? -1 : 1);
               int var111 = var16;
               int var110 = var10000;
               var78 = var110;
               int var76 = var110;
               if (var111 == 0) {
                  break label94;
               }

               int var112 = var76;
               int var77 = var112;
               int var113 = var77;
               if (var113 == 0) {
                  var79 = 0;
                  break label95;
               }
            }

            var78 = 1;
         }

         int var114 = var78;
         var79 = var114;
      }

      int var17 = var79;
      int var116 = var17;
      ElapsedTimer var115 = this.h;
      ElapsedTimer var81 = var115;
      ElapsedTimer var80 = var115;
      ElapsedTimer var82;
      Float var83;
      if (var116 != 0) {
         FloatSetting var50 = this.d;
         Float var118 = (Float)var50.aReturningObject();
         ElapsedTimer var117 = var80;
         var82 = var117;
         var83 = var118;
      } else {
         FloatSetting var52 = this.c;
         var83 = (Float)var52.aReturningObject();
         var82 = var81;
      }

      AutoPearlCatch var90;
      label112: {
         Float var53 = var83;
         float var143 = var53;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var143;
         Object[] var55 = var10004;
         ElapsedTimer var54 = var82;
         boolean var135 = var54.aReturningBoolean(var55);
         int var120 = var16;
         boolean var119 = var135;
         boolean var86 = var119;
         boolean var84 = var119;
         if (var120 != 0) {
            boolean var121 = var84;
            if (!var121) {
               return;
            }

            int var123 = var16;
            AutoPearlCatch var122 = this;
            var90 = var122;
            AutoPearlCatch var85 = var122;
            if (var123 == 0) {
               break label112;
            }

            boolean var124 = var85.g;
            var86 = var124;
         }

         boolean var125 = var86;
         if (var125) {
            int var127 = var16;
            boolean var126 = this.p;
            boolean var89 = var126;
            boolean var87 = var126;
            if (var127 != 0) {
               boolean var128 = var87;
               boolean var88 = var128;
               boolean var129 = var88;
               if (var129) {
                  return;
               }

               MinecraftClient var60 = b;
               ClientPlayerEntity var61 = var60.player;
               Rotation var136 = new Rotation(var61.getYaw(), this.l);
               FloatSetting var62 = this.f;
               Float var63 = (Float)var62.aReturningObject();
               float var144 = var63 / 2.0F;
               Object[] var145 = new Object[]{null, null, null, null, 133142968601602L};
               var145[3] = 0.2F;
               var145[2] = 0.0F;
               var145[1] = var144;
               var145[0] = var136;
               Object[] var64 = var145;
               var89 = RotationUtil.dReturningBoolean(var64);
            }

            boolean var130 = var89;
            if (!var130) {
               return;
            }

            Object[] var66 = new Object[]{126290808879192L};
            AutoPearlCatch var65 = this;
            var65.aReturningVoid(var66);
            int var131 = var16;
            if (var131 != 0) {
               return;
            }
         }

         AutoPearlCatch var132 = this;
         var90 = var132;
      }

      var90.k = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 20630596880965L;
      long var6 = var2 ^ 44979751378241L;
      long var8 = var2 ^ 127115019997271L;
      long var10 = var2 ^ 73608466808436L;
      long var12 = var2 ^ 90239596536550L;
      long var14 = var2 ^ 36846332478876L;
      long var16 = var2 ^ 103512462602515L;
      long var18 = var2 ^ 86502240407608L;
      long var20 = var2 ^ 5687285470025L;
      long var22 = var2 ^ 82841711375426L;
      long var24 = var2 ^ 29159961624672L;
      long var26 = var2 ^ 81031044501597L;
      long var28 = var2 ^ 62058739966303L;
      int var30 = Event.cReturningInt();
      int var380 = var30;
      AutoPearlCatch var379 = this;
      AutoPearlCatch var264 = var379;
      AutoPearlCatch var263 = var379;
      if (var380 != 0) {
         MinecraftClient var44 = b;
         ClientWorld var382 = var44.world;
         Object var381 = var263.s;
         if (var381 != var382) {
            Object[] var47 = new Object[]{var26};
            AutoPearlCatch var46 = this;
            var46.lReturningVoid(var47);
         }

         var264 = this;
      }

      Object[] var50 = new Object[]{var6};
      AutoPearlCatch var49 = var264;
      boolean var31 = var49.eReturningBoolean(var50);
      RotationManager var10000 = Prestige.o;
      Object[] var52 = new Object[]{var16};
      RotationManager var51 = var10000;
      boolean var604 = var51.eReturningBoolean(var52);
      int var384 = var30;
      boolean var383 = var604;
      boolean var266 = var383;
      boolean var265 = var383;
      if (var384 != 0) {
         boolean var385 = var265;
         if (!var385) {
            Object[] var55 = new Object[]{var26};
            AutoPearlCatch var54 = this;
            var54.lReturningVoid(var55);
            return null;
         }

         var266 = var31;
      }

      int var387 = var30;
      boolean var386 = var266;
      boolean var270 = var386;
      boolean var267 = var386;
      if (var387 != 0) {
         boolean var388 = var267;
         if (!var388) {
            boolean var276;
            label476: {
               label497: {
                  int var396 = var30;
                  AutoPearlCatch var395 = this;
                  AutoPearlCatch var274 = var395;
                  AutoPearlCatch var273 = var395;
                  if (var396 != 0) {
                     Rotation var397 = var273.m;
                     if (var397 == null) {
                        break label497;
                     }

                     AutoPearlCatch var398 = this;
                     var274 = var398;
                  }

                  int var400 = var30;
                  boolean var399 = var274.p;
                  var276 = var399;
                  boolean var275 = var399;
                  if (var400 == 0) {
                     break label476;
                  }

                  boolean var401 = var275;
                  if (var401) {
                     return this.m;
                  }
               }

               MinecraftClient var66 = b;
               var276 = var66.isWindowFocused();
            }

            Object var284;
            label537: {
               AutoPearlCatch var283;
               label499: {
                  int var403 = var30;
                  boolean var402 = var276;
                  boolean var282 = var402;
                  boolean var277 = var402;
                  if (var403 != 0) {
                     boolean var404 = var277;
                     if (var404) {
                        MinecraftClient var68 = b;
                        int var406 = var30;
                        Screen var405 = var68.currentScreen;
                        var284 = var405;
                        Screen var278 = var405;
                        if (var406 == 0) {
                           break label537;
                        }

                        Screen var407 = var278;
                        Screen var279 = var407;
                        Screen var408 = var279;
                        if (var408 == null) {
                           BooleanSetting var75 = this.e;
                           var284 = var75.aReturningObject();
                           break label537;
                        }
                     }

                     int var410 = var30;
                     AutoPearlCatch var409 = this;
                     var283 = var409;
                     AutoPearlCatch var280 = var409;
                     if (var410 == 0) {
                        break label499;
                     }

                     AutoPearlCatch var411 = var280;
                     AutoPearlCatch var281 = var411;
                     boolean var412 = var281.p;
                     var282 = var412;
                  }

                  boolean var413 = var282;
                  if (var413) {
                     return null;
                  }

                  var283 = this;
               }

               Object[] var74 = new Object[]{var20};
               AutoPearlCatch var73 = var283;
               var73.kReturningVoid(var74);
               return null;
            }

            Boolean var76 = (Boolean)var284;
            byte var605 = ((byte)(((java.lang.Boolean)(var76)).booleanValue() ? 1 : 0));
            int var415 = var30;
            byte var414 = var605;
            int var328 = var414;
            byte var285 = var414;
            if (var415 != 0) {
               byte var416 = var285;
               if (((var416) != 0)) {
                  int var289;
                  label333: {
                     int var418 = var30;
                     AutoPearlCatch var417 = this;
                     AutoPearlCatch var288 = var417;
                     AutoPearlCatch var286 = var417;
                     if (var418 != 0) {
                        AutoPearlCatch var419 = var286;
                        AutoPearlCatch var287 = var419;
                        boolean var420 = var287.i;
                        if (var420) {
                           // var289 = var421;
                           break label333;
                        }

                        var288 = this;
                     }

                     Object[] var82 = new Object[]{var8};
                     AutoPearlCatch var81 = var288;
                     var289 = var81.dReturningInt(var82);
                  }

                  label502: {
                     int var299;
                     int var581;
                     int var582;
                     label503: {
                        int var297;
                        byte var298;
                        label504: {
                           var581 = var289;
                           Object[] var84 = new Object[]{var12};
                           AutoPearlCatch var83 = this;
                           var582 = var83.eReturningInt(var84);
                           int var423 = var30;
                           byte var422 = ((byte)((this.i) ? 1 : 0));
                           int var295 = var422;
                           byte var290 = var422;
                           if (var423 != 0) {
                              byte var424 = var290;
                              if (var424 == 0) {
                                 int var427 = var30;
                                 // int var425 = var581;
                                 var297 = var425;
                                 var298 = var426;
                                 int var291 = var425;
                                 byte var292 = var426;
                                 if (var427 == 0) {
                                    break label504;
                                 }

                                 byte var429 = var292;
                                 int var428 = var291;
                                 int var293 = var428;
                                 byte var294 = var429;
                                 byte var431 = var294;
                                 int var430 = var293;
                                 if (var430 == var431) {
                                    break label502;
                                 }
                              }

                              var295 = var582;
                           }

                           int var433 = var30;
                           int var432 = var295;
                           var299 = var432;
                           int var296 = var432;
                           if (var433 == 0) {
                              break label503;
                           }

                           // int var434 = var296;
                           var297 = var434;
                           var298 = var435;
                        }

                        byte var437 = var298;
                        int var436 = var297;
                        if (var436 == var437) {
                           break label502;
                        }

                        var299 = (((this.j) ? 1 : 0));
                     }

                     int var439 = var30;
                     int var438 = var299;
                     int var305 = var438;
                     int var300 = var438;
                     if (var439 != 0) {
                        int var440 = var300;
                        if (var440 != 0) {
                           MinecraftClient var93 = b;
                           ClientPlayerEntity var94 = var93.player;
                           Object[] var96 = new Object[]{new Rotation(var94.getYaw(), -90.0F), var28};
                           AutoPearlCatch var95 = this;
                           Rotation var584 = var95.bReturningdx_C0210(var96);
                           int var443 = var30;
                           int var442 = var581;
                           AutoPearlCatch var441 = this;
                           AutoPearlCatch var303 = var441;
                           int var304 = var442;
                           AutoPearlCatch var301 = var441;
                           int var302 = var442;
                           if (var443 != 0) {
                              Object[] var629 = new Object[]{null, var14};
                              var629[0] = var302;
                              Object[] var98 = var629;
                              AutoPearlCatch var97 = var301;
                              boolean var444 = var97.aReturningBoolean(var98);
                              if (!var444) {
                                 return var584;
                              }

                              this.i = true;
                              byte var446 = 0;
                              AutoPearlCatch var445 = this;
                              var303 = var445;
                              var304 = var446;
                           }

                           var303.j = dev.prestige.recovery.SourceSupport.asBoolean(var304);
                           ElapsedTimer var620 = this.h;
                           Object[] var102 = new Object[]{var24};
                           ElapsedTimer var101 = var620;
                           var101.aReturningVoid(var102);
                           return var584;
                        }

                        var305 = (((this.k) ? 1 : 0));
                     }

                     int var447 = var305;
                     if (var447 != 0) {
                        EnderPearlEntity var583 = null;
                        short var614 = 3803;
                        long var622 = 6502462368239480265L ^ var2;
                        int var586 = Integer.MAX_VALUE;
                        MinecraftClient var103 = b;
                        ClientWorld var104 = var103.world;
                        Iterable var105 = var104.getEntities();
                        Iterator var587 = var105.iterator();

                        AutoPearlCatch var327;
                        label506: {
                           boolean var326;
                           label304:
                           while (true) {
                              Iterator var106 = var587;
                              boolean var448 = var106.hasNext();
                              if (var448) {
                                 label508: {
                                    Iterator var107 = var587;
                                    Entity var592 = (Entity)var107.next();
                                    int var450 = var30;
                                    Entity var449 = var592;
                                    Entity var309 = var449;
                                    Entity var306 = var449;
                                    if (var450 != 0) {
                                       boolean var615 = var306 instanceof EnderPearlEntity;
                                       int var452 = var30;
                                       boolean var451 = var615;
                                       var326 = var451;
                                       boolean var307 = var451;
                                       if (var452 == 0) {
                                          break;
                                       }

                                       boolean var453 = var307;
                                       boolean var308 = var453;
                                       boolean var454 = var308;
                                       if (!var454) {
                                          break label508;
                                       }

                                       var309 = var592;
                                    }

                                    EnderPearlEntity var597 = (EnderPearlEntity)var309;
                                    int var456 = var30;
                                    EnderPearlEntity var455 = var597;
                                    EnderPearlEntity var311 = var455;
                                    EnderPearlEntity var310 = var455;
                                    if (var456 != 0) {
                                       EnderPearlEntity var110 = var310;
                                       Entity var616 = var110.getOwner();
                                       MinecraftClient var111 = b;
                                       ClientPlayerEntity var458 = var111.player;
                                       Entity var457 = var616;
                                       if (var457 != var458) {
                                          break label508;
                                       }

                                       EnderPearlEntity var459 = var597;
                                       var311 = var459;
                                    }

                                    EnderPearlEntity var114 = var311;
                                    int var461 = var30;
                                    int var460 = var114.age;
                                    int var313 = var460;
                                    int var312 = var460;
                                    if (var461 != 0) {
                                       int var463 = var586;
                                       int var462 = var312;
                                       if (var462 >= var463) {
                                          break label508;
                                       }

                                       EnderPearlEntity var116 = var597;
                                       int var464 = var116.age;
                                       var313 = var464;
                                    }

                                    var586 = var313;
                                    var583 = var597;
                                 }

                                 int var465 = var30;
                                 if (var465 != 0) {
                                    continue;
                                 }
                              }

                              EnderPearlEntity var320;
                              int var467 = var30;
                              EnderPearlEntity var466 = var583;
                              var320 = var466;
                              EnderPearlEntity var314 = var466;
                              label283:
                              if (var467 != 0) {
                                 EnderPearlEntity var468 = var314;
                                 if (var468 == null) {
                                    MinecraftClient var119 = b;
                                    ClientWorld var120 = var119.world;
                                    Iterable var121 = var120.getEntities();
                                    var587 = var121.iterator();

                                    int var481;
                                    do {
                                       Iterator var122 = var587;
                                       boolean var469 = var122.hasNext();
                                       if (!var469) {
                                          break;
                                       }

                                       label511: {
                                          Iterator var123 = var587;
                                          Entity var593 = (Entity)var123.next();
                                          int var471 = var30;
                                          Entity var470 = var593;
                                          Entity var318 = var470;
                                          Entity var315 = var470;
                                          if (var471 != 0) {
                                             boolean var617 = var315 instanceof EnderPearlEntity;
                                             int var473 = var30;
                                             boolean var472 = var617;
                                             var326 = var472;
                                             boolean var316 = var472;
                                             if (var473 == 0) {
                                                break label304;
                                             }

                                             boolean var474 = var316;
                                             boolean var317 = var474;
                                             boolean var475 = var317;
                                             if (!var475) {
                                                break label511;
                                             }

                                             var318 = var593;
                                          }

                                          EnderPearlEntity var598 = (EnderPearlEntity)var318;
                                          int var477 = var30;
                                          EnderPearlEntity var476 = var598;
                                          var320 = var476;
                                          EnderPearlEntity var319 = var476;
                                          if (var477 == 0) {
                                             break label283;
                                          }

                                          EnderPearlEntity var126 = var319;
                                          Entity var618 = var126.getOwner();
                                          MinecraftClient var127 = b;
                                          ClientPlayerEntity var479 = var127.player;
                                          Entity var478 = var618;
                                          if (var478 != var479) {
                                             break;
                                          }

                                          var583 = var598;
                                          int var480 = var30;
                                          if (var480 != 0) {
                                             break;
                                          }
                                       }

                                       var481 = var30;
                                    } while (var481 != 0);
                                 }

                                 var320 = var583;
                              }

                              EnderPearlEntity var482 = var320;
                              if (var482 != null) {
                                 Rotation var603;
                                 label248: {
                                    MinecraftClient var130 = b;
                                    ClientPlayerEntity var131 = var130.player;
                                    Vec3d var589 = var131.getVelocity();
                                    MinecraftClient var132 = b;
                                    ClientPlayerEntity var133 = var132.player;
                                    float var594 = var133.getYaw();
                                    double var134 = var594;
                                    double var599 = Math.toRadians(var134);
                                    double var136 = var599;
                                    double var624 = -Math.sin(var136);
                                    double var138 = var599;
                                    Vec3d var140 = new Vec3d(var624, 0.0, Math.cos(var138));
                                    Vec3d var40 = var140.normalize();
                                    Vec3d var141 = var589;
                                    Vec3d var142 = var40;
                                    double var619 = var141.x * var142.x;
                                    Vec3d var143 = var589;
                                    Vec3d var144 = var40;
                                    float var602 = (float)(var619 + var143.z * var144.z);
                                    MinecraftClient var145 = b;
                                    ClientPlayerEntity var146 = var145.player;
                                    Object[] var148 = new Object[]{new Rotation(var146.getYaw(), -90.0F + var602 * 1.6F), var28};
                                    AutoPearlCatch var147 = this;
                                    var603 = var147.bReturningdx_C0210(var148);
                                    int var485 = var30;
                                    int var484 = var582;
                                    AutoPearlCatch var483 = this;
                                    AutoPearlCatch var323 = var483;
                                    int var324 = var484;
                                    AutoPearlCatch var321 = var483;
                                    int var322 = var484;
                                    if (var485 != 0) {
                                       Object[] var628 = new Object[]{null, var14};
                                       var628[0] = var322;
                                       Object[] var150 = var628;
                                       AutoPearlCatch var149 = var321;
                                       boolean var486 = var149.aReturningBoolean(var150);
                                       if (!var486) {
                                          break label248;
                                       }

                                       this.g = true;
                                       byte var488 = 0;
                                       AutoPearlCatch var487 = this;
                                       var323 = var487;
                                       var324 = var488;
                                    }

                                    var323.k = dev.prestige.recovery.SourceSupport.asBoolean(var324);
                                 }

                                 Object[] var154 = new Object[0];
                                 Rotation var153 = var603;
                                 float var625 = var153.aReturningFloat(var154);
                                 Object[] var156 = new Object[0];
                                 Rotation var155 = var603;
                                 return new Rotation(var625, var155.bReturningFloat(var156));
                              }

                              int var490 = var30;
                              AutoPearlCatch var489 = this;
                              var327 = var489;
                              AutoPearlCatch var325 = var489;
                              if (var490 == 0) {
                                 break label506;
                              }

                              Object[] var158 = new Object[]{var22};
                              AutoPearlCatch var157 = var325;
                              boolean var491 = var157.dReturningBoolean(var158);
                              var326 = var491;
                              break;
                           }

                           boolean var492 = var326;
                           if (!var492) {
                              return null;
                           }

                           var327 = this;
                        }

                        Object[] var161 = new Object[]{var18};
                        AutoPearlCatch var160 = var327;
                        var160.aReturningVoid(var161);
                     }

                     return null;
                  }

                  Object[] var90 = new Object[]{var18};
                  AutoPearlCatch var89 = this;
                  var89.aReturningVoid(var90);
                  return null;
               }

               MinecraftClient var162 = b;
               ClientPlayerEntity var163 = var162.player;
               Vec3d var164 = var163.getVelocity();
               double var630;
               var328 = (var630 = var164.x - 0.0) == 0.0 ? 0 : (var630 < 0.0 ? -1 : 1);
            }

            int var333;
            label447: {
               int var332;
               int var494 = var30;
               int var493 = var328;
               var332 = var493;
               int var329 = var493;
               label446:
               if (var494 != 0) {
                  int var495 = var329;
                  if (!((var495) != 0)) {
                     MinecraftClient var166 = b;
                     ClientPlayerEntity var167 = var166.player;
                     Vec3d var168 = var167.getVelocity();
                     double var631;
                     int var606 = (var631 = var168.z - 0.0) == 0.0 ? 0 : (var631 < 0.0 ? -1 : 1);
                     int var497 = var30;
                     int var496 = var606;
                     var332 = var496;
                     int var330 = var496;
                     if (var497 == 0) {
                        break label446;
                     }

                     int var498 = var330;
                     int var331 = var498;
                     int var499 = var331;
                     if (!((var499) != 0)) {
                        var333 = 0;
                        break label447;
                     }
                  }

                  var332 = 1;
               }

               int var500 = var332;
               var333 = var500;
            }

            int var32;
            int var336;
            label437: {
               var32 = var333;
               int var502 = var30;
               AutoPearlCatch var501 = this;
               AutoPearlCatch var335 = var501;
               AutoPearlCatch var334 = var501;
               if (var502 != 0) {
                  boolean var503 = var334.i;
                  if (var503) {
                     // var336 = var504;
                     break label437;
                  }

                  var335 = this;
               }

               Object[] var174 = new Object[]{var8};
               AutoPearlCatch var173 = var335;
               var336 = var173.dReturningInt(var174);
            }

            label539: {
               int var34;
               AutoPearlCatch var352;
               label514: {
                  int var33;
                  int var347;
                  label515: {
                     int var344;
                     byte var345;
                     label516: {
                        var33 = var336;
                        Object[] var176 = new Object[]{var12};
                        AutoPearlCatch var175 = this;
                        var34 = var175.eReturningInt(var176);
                        int var506 = var30;
                        byte var505 = ((byte)((this.i) ? 1 : 0));
                        int var342 = var505;
                        byte var337 = var505;
                        if (var506 != 0) {
                           byte var507 = var337;
                           if (var507 == 0) {
                              int var510 = var30;
                              // int var508 = var33;
                              var344 = var508;
                              var345 = var509;
                              int var338 = var508;
                              byte var339 = var509;
                              if (var510 == 0) {
                                 break label516;
                              }

                              byte var512 = var339;
                              int var511 = var338;
                              int var340 = var511;
                              byte var341 = var512;
                              byte var514 = var341;
                              int var513 = var340;
                              if (var513 == var514) {
                                 break label539;
                              }
                           }

                           var342 = var34;
                        }

                        int var516 = var30;
                        int var515 = var342;
                        var347 = var515;
                        int var343 = var515;
                        if (var516 == 0) {
                           break label515;
                        }

                        // int var517 = var343;
                        var344 = var517;
                        var345 = var518;
                     }

                     byte var520 = var345;
                     int var519 = var344;
                     if (var519 == var520) {
                        break label539;
                     }

                     int var522 = var30;
                     AutoPearlCatch var521 = this;
                     var352 = var521;
                     AutoPearlCatch var346 = var521;
                     if (var522 == 0) {
                        break label514;
                     }

                     byte var523 = ((byte)((var346.i) ? 1 : 0));
                     var347 = var523;
                  }

                  int var524 = var347;
                  if (var524 == 0) {
                     MinecraftClient var185 = b;
                     ClientPlayerEntity var186 = var185.player;
                     Object[] var188 = new Object[]{new Rotation(var186.getYaw(), -90.0F), var28};
                     AutoPearlCatch var187 = this;
                     Rotation var35 = var187.bReturningdx_C0210(var188);
                     int var527 = var30;
                     int var526 = var33;
                     AutoPearlCatch var525 = this;
                     AutoPearlCatch var350 = var525;
                     int var351 = var526;
                     AutoPearlCatch var348 = var525;
                     int var349 = var526;
                     if (var527 != 0) {
                        Object[] var10004 = new Object[]{null, var14};
                        var10004[0] = var349;
                        Object[] var190 = var10004;
                        AutoPearlCatch var189 = var348;
                        boolean var528 = var189.aReturningBoolean(var190);
                        if (!var528) {
                           return var35;
                        }

                        byte var530 = 1;
                        AutoPearlCatch var529 = this;
                        var350 = var529;
                        var351 = var530;
                     }

                     var350.i = dev.prestige.recovery.SourceSupport.asBoolean(var351);
                     ElapsedTimer var607 = this.h;
                     Object[] var194 = new Object[]{var24};
                     ElapsedTimer var193 = var607;
                     var193.aReturningVoid(var194);
                     return var35;
                  }

                  var352 = this;
               }

               int var532 = var32;
               ElapsedTimer var531 = var352.h;
               ElapsedTimer var354 = var531;
               ElapsedTimer var353 = var531;
               ElapsedTimer var355;
               Float var356;
               if (((var532) != 0)) {
                  FloatSetting var195 = this.d;
                  Float var534 = (Float)var195.aReturningObject();
                  ElapsedTimer var533 = var353;
                  var355 = var533;
                  var356 = var534;
               } else {
                  FloatSetting var197 = this.c;
                  var356 = (Float)var197.aReturningObject();
                  var355 = var354;
               }

               Float var198 = var356;
               float var10001 = var198;
               Object[] var626 = new Object[]{null, var10};
               var626[0] = var10001;
               Object[] var200 = var626;
               ElapsedTimer var199 = var355;
               boolean var535 = var199.aReturningBoolean(var200);
               if (!var535) {
                  MinecraftClient var201 = b;
                  ClientPlayerEntity var202 = var201.player;
                  return new Rotation(var202.getYaw(), -90.0F);
               }

               EnderPearlEntity var585 = null;
               short var608 = 31838;
               long var621 = 8185044589718609741L ^ var2;
               int var36 = Integer.MAX_VALUE;
               MinecraftClient var204 = b;
               ClientWorld var205 = var204.world;
               Iterable var206 = var205.getEntities();
               Iterator var37 = var206.iterator();

               AutoPearlCatch var378;
               label517: {
                  boolean var377;
                  label406:
                  while (true) {
                     Iterator var207 = var37;
                     boolean var536 = var207.hasNext();
                     if (var536) {
                        label519: {
                           Iterator var208 = var37;
                           Entity var38 = (Entity)var208.next();
                           int var538 = var30;
                           Entity var537 = var38;
                           Entity var360 = var537;
                           Entity var357 = var537;
                           if (var538 != 0) {
                              boolean var609 = var357 instanceof EnderPearlEntity;
                              int var540 = var30;
                              boolean var539 = var609;
                              var377 = var539;
                              boolean var358 = var539;
                              if (var540 == 0) {
                                 break;
                              }

                              boolean var541 = var358;
                              boolean var359 = var541;
                              boolean var542 = var359;
                              if (!var542) {
                                 break label519;
                              }

                              var360 = var38;
                           }

                           EnderPearlEntity var39 = (EnderPearlEntity)var360;
                           int var544 = var30;
                           EnderPearlEntity var543 = var39;
                           EnderPearlEntity var362 = var543;
                           EnderPearlEntity var361 = var543;
                           if (var544 != 0) {
                              EnderPearlEntity var211 = var361;
                              Entity var610 = var211.getOwner();
                              MinecraftClient var212 = b;
                              ClientPlayerEntity var546 = var212.player;
                              Entity var545 = var610;
                              if (var545 != var546) {
                                 break label519;
                              }

                              EnderPearlEntity var547 = var39;
                              var362 = var547;
                           }

                           EnderPearlEntity var215 = var362;
                           int var549 = var30;
                           int var548 = var215.age;
                           int var364 = var548;
                           int var363 = var548;
                           if (var549 != 0) {
                              int var551 = var36;
                              int var550 = var363;
                              if (var550 >= var551) {
                                 break label519;
                              }

                              EnderPearlEntity var217 = var39;
                              int var552 = var217.age;
                              var364 = var552;
                           }

                           var36 = var364;
                           var585 = var39;
                        }

                        int var553 = var30;
                        if (var553 != 0) {
                           continue;
                        }
                     }

                     EnderPearlEntity var371;
                     int var555 = var30;
                     EnderPearlEntity var554 = var585;
                     var371 = var554;
                     EnderPearlEntity var365 = var554;
                     label385:
                     if (var555 != 0) {
                        EnderPearlEntity var556 = var365;
                        if (var556 == null) {
                           MinecraftClient var220 = b;
                           ClientWorld var221 = var220.world;
                           Iterable var222 = var221.getEntities();
                           var37 = var222.iterator();

                           int var569;
                           do {
                              Iterator var223 = var37;
                              boolean var557 = var223.hasNext();
                              if (!var557) {
                                 break;
                              }

                              label522: {
                                 Iterator var224 = var37;
                                 Entity var595 = (Entity)var224.next();
                                 int var559 = var30;
                                 Entity var558 = var595;
                                 Entity var369 = var558;
                                 Entity var366 = var558;
                                 if (var559 != 0) {
                                    boolean var611 = var366 instanceof EnderPearlEntity;
                                    int var561 = var30;
                                    boolean var560 = var611;
                                    var377 = var560;
                                    boolean var367 = var560;
                                    if (var561 == 0) {
                                       break label406;
                                    }

                                    boolean var562 = var367;
                                    boolean var368 = var562;
                                    boolean var563 = var368;
                                    if (!var563) {
                                       break label522;
                                    }

                                    var369 = var595;
                                 }

                                 EnderPearlEntity var600 = (EnderPearlEntity)var369;
                                 int var565 = var30;
                                 EnderPearlEntity var564 = var600;
                                 var371 = var564;
                                 EnderPearlEntity var370 = var564;
                                 if (var565 == 0) {
                                    break label385;
                                 }

                                 EnderPearlEntity var227 = var370;
                                 Entity var612 = var227.getOwner();
                                 MinecraftClient var228 = b;
                                 ClientPlayerEntity var567 = var228.player;
                                 Entity var566 = var612;
                                 if (var566 != var567) {
                                    break;
                                 }

                                 var585 = var600;
                                 int var568 = var30;
                                 if (var568 != 0) {
                                    break;
                                 }
                              }

                              var569 = var30;
                           } while (var569 != 0);
                        }

                        var371 = var585;
                     }

                     EnderPearlEntity var570 = var371;
                     if (var570 != null) {
                        Rotation var43;
                        label350: {
                           MinecraftClient var231 = b;
                           ClientPlayerEntity var232 = var231.player;
                           Vec3d var591 = var232.getVelocity();
                           MinecraftClient var233 = b;
                           ClientPlayerEntity var234 = var233.player;
                           float var596 = var234.getYaw();
                           double var235 = var596;
                           double var601 = Math.toRadians(var235);
                           double var237 = var601;
                           double var10002 = -Math.sin(var237);
                           double var239 = var601;
                           Vec3d var241 = new Vec3d(var10002, 0.0, Math.cos(var239));
                           Vec3d var41 = var241.normalize();
                           Vec3d var242 = var591;
                           Vec3d var243 = var41;
                           double var613 = var242.x * var243.x;
                           Vec3d var244 = var591;
                           Vec3d var245 = var41;
                           float var42 = (float)(var613 + var244.z * var245.z);
                           MinecraftClient var246 = b;
                           ClientPlayerEntity var247 = var246.player;
                           Object[] var249 = new Object[]{new Rotation(var247.getYaw(), -90.0F + var42 * 1.6F), var28};
                           AutoPearlCatch var248 = this;
                           var43 = var248.bReturningdx_C0210(var249);
                           int var573 = var30;
                           int var572 = var34;
                           AutoPearlCatch var571 = this;
                           AutoPearlCatch var374 = var571;
                           int var375 = var572;
                           AutoPearlCatch var372 = var571;
                           int var373 = var572;
                           if (var573 != 0) {
                              var626 = new Object[]{null, var14};
                              var626[0] = var373;
                              Object[] var251 = var626;
                              AutoPearlCatch var250 = var372;
                              boolean var574 = var250.aReturningBoolean(var251);
                              if (!var574) {
                                 break label350;
                              }

                              byte var576 = 1;
                              AutoPearlCatch var575 = this;
                              var374 = var575;
                              var375 = var576;
                           }

                           var374.q = dev.prestige.recovery.SourceSupport.asBoolean(var375);
                        }

                        Object[] var255 = new Object[0];
                        Rotation var254 = var43;
                        float var623 = var254.aReturningFloat(var255);
                        Object[] var257 = new Object[0];
                        Rotation var256 = var43;
                        return new Rotation(var623, var256.bReturningFloat(var257));
                     }

                     int var578 = var30;
                     AutoPearlCatch var577 = this;
                     var378 = var577;
                     AutoPearlCatch var376 = var577;
                     if (var578 == 0) {
                        break label517;
                     }

                     Object[] var259 = new Object[]{var22};
                     AutoPearlCatch var258 = var376;
                     boolean var579 = var258.dReturningBoolean(var259);
                     var377 = var579;
                     break;
                  }

                  boolean var580 = var377;
                  if (!var580) {
                     return null;
                  }

                  var378 = this;
               }

               Object[] var262 = new Object[]{var18};
               AutoPearlCatch var261 = var378;
               var261.aReturningVoid(var262);
               return null;
            }

            Object[] var182 = new Object[]{var18};
            AutoPearlCatch var181 = this;
            var181.aReturningVoid(var182);
            return null;
         }

         Object[] var59 = new Object[]{var4};
         AutoPearlCatch var58 = this;
         var58.jReturningVoid(var59);
         int var390 = var30;
         AutoPearlCatch var389 = this;
         AutoPearlCatch var271 = var389;
         AutoPearlCatch var268 = var389;
         if (var390 == 0) {
            return var271.m;
         }

         AutoPearlCatch var391 = var268;
         AutoPearlCatch var269 = var391;
         boolean var392 = var269.p;
         var270 = var392;
      }

      boolean var393 = var270;
      if (!var393) {
         return null;
      }

      AutoPearlCatch var632 = this;
      return var632.m;
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      long var4 = var2 ^ 85887953391797L;
      FloatSetting var7 = this.c;
      Float var8 = (Float)var7.aReturningObject();
      float var10000 = var8;
      FloatSetting var9 = this.d;
      Float var10 = (Float)var9.aReturningObject();
      float var12 = var10;
      float var11 = var10000;
      float var6 = Math.max(var11, var12);
      ElapsedTimer var16 = this.h;
      float var10001 = var6 + 1500.0F;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var14 = var10004;
      ElapsedTimer var13 = var16;
      return var13.aReturningBoolean(var14);
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      int var10000 = Event.bReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var8 = var7.player;
      int var5 = var8.age;
      int var4 = var10000;
      MinecraftClient var9 = b;
      ClientPlayerEntity var10 = var9.player;
      byte var50 = ((byte)((var10.isUsingItem()) ? 1 : 0));
      int var29 = var4;
      byte var28 = var50;
      byte var18 = var28;
      byte var15 = var28;
      if (var29 == 0) {
         byte var30 = var15;
         label49:
         if (var30 == 0) {
            MinecraftClient var12 = b;
            GameOptions var13 = var12.options;
            KeyBinding var14 = var13.useKey;
            var50 = ((byte)((var14.isPressed()) ? 1 : 0));
            int var32 = var4;
            byte var31 = var50;
            int var19 = var31;
            byte var16 = var31;
            if (var32 == 0) {
               byte var33 = var16;
               byte var17 = var33;
               byte var34 = var17;
               if (var34 != 0) {
                  break label49;
               }

               var19 = this.t;
            }

            short var10001 = 15516;
            long var10002 = 6640677028603926602L ^ var2;
            int var38 = var4;
            int var37 = Integer.MIN_VALUE;
            int var36 = var19;
            int var22 = var36;
            int var23 = var37;
            int var20 = var36;
            int var21 = var37;
            if (var38 == 0) {
               int var40 = var21;
               int var39 = var20;
               if (var39 == var40) {
                  return false;
               }

               var23 = this.t;
               var22 = var5;
            }

            int var6 = var22 - var23;
            int var42 = var4;
            int var41 = var6;
            int var27 = var41;
            int var24 = var41;
            if (var42 == 0) {
               int var43 = var24;
               if (var43 >= 0) {
                  int var45 = var4;
                  int var44 = var6;
                  var27 = var44;
                  int var25 = var44;
                  if (var45 != 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var27);
                  }

                  int var46 = var25;
                  int var26 = var46;
                  byte var48 = 1;
                  int var47 = var26;
                  if (var47 <= var48) {
                     return true;
                  }
               }

               var10001 = 15516;
               var10002 = 6640677028603926602L ^ var2;
               this.t = Integer.MIN_VALUE;
               var27 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var27);
         }

         this.t = var5;
         byte var35 = 1;
         var18 = var35;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var18);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      long var4 = var2 ^ 88340019266447L;
      int var6 = Event.bReturningInt();
      int var13 = var6;
      AutoPearlCatch var12 = this;
      AutoPearlCatch var11 = var12;
      AutoPearlCatch var10 = var12;
      if (var13 == 0) {
         boolean var14 = var10.p;
         if (!var14) {
            Object[] var9 = new Object[]{var4};
            AutoPearlCatch var8 = this;
            var8.kReturningVoid(var9);
         }

         this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
         var11 = this;
      }

      var11.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      Rotation var2 = (Rotation)var1[0];
      long var3 = (Long)var1[1];
      var3 = 78851316161155L ^ var3;
      long var5 = var3 ^ 12645214686689L;
      int var7 = Event.cReturningInt();
      int var20 = var7;
      Rotation var19 = this.m;
      Rotation var18 = var19;
      Rotation var17 = var19;
      if (var20 != 0) {
         Rotation var21 = var17;
         if (var21 == null) {
            Object[] var10 = new Object[0];
            Rotation var9 = var2;
            float var10003 = var9.aReturningFloat(var10);
            Object[] var12 = new Object[0];
            Rotation var11 = var2;
            this.m = new Rotation(var10003, var11.bReturningFloat(var12));
            this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.o = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
            MinecraftClient var13 = b;
            this.r = var13.world;
         }

         RotationManager var10000 = Prestige.o;
         Object[] var16 = new Object[]{this, this.m, var5};
         RotationManager var15 = var10000;
         var15.cReturningBoolean(var16);
         var18 = this.m;
      }

      return var18;
   }

   private boolean aReturningBoolean(Object[] var1) {
      long var5;
      int var7;
      int var71;
      label108: {
         int var4 = (Integer)var1[0];
         long var2 = (Long)var1[1];
         var2 = 78851316161155L ^ var2;
         var5 = var2 ^ 30449626821129L;
         var7 = Event.cReturningInt();
         AutoPearlCatch var10000 = this;
         if (var7 != 0) {
            if (this.m == null) {
               return dev.prestige.recovery.SourceSupport.asBoolean(0);
            }

            var10000 = this;
         }

         if (var7 == 0) {
            return var10000.n;
         }

         if (var10000.n) {
            if (var7 == 0) {
               return this.p;
            }

            if (!this.p) {
               RotationManager var70 = Prestige.o;
               Object[] var18 = new Object[0];
               RotationManager var17 = var70;
               var71 = (((var17.fReturningBoolean(var18)) ? 1 : 0));
               if (var7 == 0) {
                  break label108;
               }

               if (var71 == 0) {
                  var71 = var4;
                  break label108;
               }
            }
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(0);
      }

      Object[] var10003 = new Object[]{null, var5};
      var10003[0] = var71;
      Object[] var21 = var10003;
      InventoryUtil.aReturningVoid(var21);
      MinecraftClient var22 = b;
      ClientPlayerEntity var23 = var22.player;
      float var8 = var23.getYaw();
      MinecraftClient var24 = b;
      ClientPlayerEntity var25 = var24.player;
      float var9 = var25.getPitch();
      boolean var62 = false ;

      boolean var10;
      try {
         var62 = true;
         MinecraftClient var26 = b;
         ClientPlayerEntity var72 = var26.player;
         Rotation var10001 = this.m;
         Object[] var28 = new Object[0];
         Rotation var27 = var10001;
         float var30 = var27.aReturningFloat(var28);
         ClientPlayerEntity var29 = var72;
         var29.setYaw(var30);
         MinecraftClient var31 = b;
         ClientPlayerEntity var73 = var31.player;
         var10001 = this.m;
         Object[] var33 = new Object[0];
         Rotation var32 = var10001;
         float var35 = var32.bReturningFloat(var33);
         ClientPlayerEntity var34 = var73;
         var34.setPitch(var35);
         MinecraftClient var36 = b;
         MinecraftClient var37 = b;
         Hand var40 = Hand.MAIN_HAND;
         ClientPlayerEntity var39 = var37.player;
         ClientPlayerInteractionManager var38 = var36.interactionManager;
         ActionResult var41 = var38.interactItem((PlayerEntity)var39, var40);
         var10 = var41.isAccepted();
         RotationManager var74 = Prestige.o;
         Object[] var43 = new Object[]{true};
         RotationManager var42 = var74;
         var42.fReturningVoid(var43);
         this.p = dev.prestige.recovery.SourceSupport.asBoolean(1);
         if (var7 == 0) {
            var62 = false;
            return var10;
         }

         if (var10) {
            MinecraftClient var45 = b;
            Hand var47 = Hand.MAIN_HAND;
            ClientPlayerEntity var46 = var45.player;
            var46.swingHand(var47);
            var62 = false;
         } else {
            var62 = false;
         }
      } finally {
         if (var62) {
            MinecraftClient var55 = b;
            ClientPlayerEntity var56 = var55.player;
            var56.setYaw(var8);
            MinecraftClient var58 = b;
            ClientPlayerEntity var59 = var58.player;
            var59.setPitch(var9);
         }
      }

      MinecraftClient var49 = b;
      ClientPlayerEntity var50 = var49.player;
      var50.setYaw(var8);
      MinecraftClient var52 = b;
      ClientPlayerEntity var53 = var52.player;
      var53.setPitch(var9);
      return var10;
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 33630971642803L ^ 119065298566123L;
      var10001 = 33630971642803L ^ 43750671644826L;
      var10001 = 33630971642803L ^ 95246529404398L;
      var10001 = 33630971642803L ^ 125440676891978L;
      int var12 = Event.cReturningInt();
      Rotation var62 = this.m;
      if (var62 != null) {
         Object[] var16 = new Object[0];
         PlayerUpdateEvent var15 = var1;
         EventPhase var10000 = var15.aReturningEventPhase(var16);
         int var65 = var12;
         EventPhase var64 = EventPhase.PRE;
         EventPhase var63 = var10000;
         EventPhase var48 = var63;
         EventPhase var49 = var64;
         EventPhase var46 = var63;
         EventPhase var47 = var64;
         if (var65 != 0) {
            EventPhase var67 = var47;
            EventPhase var66 = var46;
            if (var66 == var67) {
               RotationManager var94 = Prestige.o;
               Object[] var19 = new Object[]{this, this.m, 79397261631069L};
               RotationManager var18 = var94;
               boolean var68 = var18.cReturningBoolean(var19);
               if (!var68) {
                  this.o = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  return;
               }

               Rotation var98 = this.m;
               Object[] var23 = new Object[0];
               Rotation var22 = var98;
               Object[] var25 = new Object[]{var22.aReturningFloat(var23)};
               PlayerUpdateEvent var24 = var1;
               var24.bReturningVoid(var25);
               Rotation var99 = this.m;
               Object[] var27 = new Object[0];
               Rotation var26 = var99;
               Object[] var29 = new Object[]{var26.bReturningFloat(var27)};
               PlayerUpdateEvent var28 = var1;
               var28.cReturningVoid(var29);
               this.o = dev.prestige.recovery.SourceSupport.asBoolean(1);
               return;
            }

            Object[] var31 = new Object[0];
            PlayerUpdateEvent var30 = var1;
            var10000 = var30.aReturningEventPhase(var31);
            var49 = EventPhase.POST;
            var48 = var10000;
         }

         EventPhase var70 = var49;
         EventPhase var69 = var48;
         if (var69 == var70) {
            int var72 = var12;
            boolean var71 = this.o;
            boolean var52 = var71;
            boolean var50 = var71;
            if (var72 != 0) {
               boolean var73 = var50;
               boolean var51 = var73;
               boolean var74 = var51;
               if (!var74) {
                  return;
               }

               this.o = dev.prestige.recovery.SourceSupport.asBoolean(0);
               RotationManager var93 = Prestige.o;
               Object[] var35 = new Object[]{this, 119298033110777L};
               RotationManager var34 = var93;
               var52 = var34.dReturningBoolean(var35);
            }

            AutoPearlCatch var61;
            label96: {
               int var76 = var12;
               boolean var75 = var52;
               boolean var55 = var75;
               boolean var53 = var75;
               if (var76 != 0) {
                  boolean var77 = var53;
                  if (!var77) {
                     return;
                  }

                  int var79 = var12;
                  AutoPearlCatch var78 = this;
                  var61 = var78;
                  AutoPearlCatch var54 = var78;
                  if (var79 == 0) {
                     break label96;
                  }

                  boolean var80 = var54.p;
                  var55 = var80;
               }

               boolean var81 = var55;
               if (var81) {
                  label61: {
                     AutoPearlCatch var60;
                     label90: {
                        boolean var13 = this.q;
                        Object[] var39 = new Object[]{63068057090857L};
                        AutoPearlCatch var38 = this;
                        var38.kReturningVoid(var39);
                        int var83 = var12;
                        boolean var82 = var13;
                        boolean var59 = var82;
                        boolean var56 = var82;
                        if (var83 != 0) {
                           boolean var84 = var56;
                           if (!var84) {
                              break label61;
                           }

                           int var86 = var12;
                           AutoPearlCatch var85 = this;
                           var60 = var85;
                           AutoPearlCatch var57 = var85;
                           if (var86 == 0) {
                              break label90;
                           }

                           AutoPearlCatch var87 = var57;
                           AutoPearlCatch var58 = var87;
                           AutoPearlCatch var42 = var58;
                           boolean var88 = var42.aReturningBoolean();
                           var59 = var88;
                        }

                        boolean var89 = var59;
                        if (!var89) {
                           break label61;
                        }

                        var60 = this;
                     }

                     Object[] var45 = new Object[]{126290808879192L};
                     AutoPearlCatch var44 = var60;
                     var44.aReturningVoid(var45);
                  }

                  int var90 = var12;
                  if (var90 != 0) {
                     return;
                  }
               }

               AutoPearlCatch var91 = this;
               var61 = var91;
            }

            var61.n = dev.prestige.recovery.SourceSupport.asBoolean(1);
         }
      }
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      long var4 = var2 ^ 131225871561923L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.bReturningVoid(var7);
      this.m = null;
      this.r = null;
      this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.o = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.p = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void lReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      long var4 = var2 ^ 12273650129303L;
      long var6 = var2 ^ 22543596030654L;
      int var8 = Event.cReturningInt();
      MinecraftClient var10 = b;
      ClientWorld var26 = var10.world;
      Object var25 = this.s;
      byte var22;
      if (var25 != var26) {
         byte var27 = 1;
         var22 = var27;
      } else {
         var22 = 0;
      }

      label22: {
         byte var9 = var22;
         Object[] var13 = new Object[]{var4};
         AutoPearlCatch var12 = this;
         var12.kReturningVoid(var13);
         this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
         ElapsedTimer var10000 = this.h;
         Object[] var15 = new Object[]{var6};
         ElapsedTimer var14 = var10000;
         var14.aReturningVoid(var15);
         int var29 = var8;
         AutoPearlCatch var28 = this;
         AutoPearlCatch var24 = var28;
         AutoPearlCatch var23 = var28;
         if (var29 != 0) {
            MinecraftClient var16 = b;
            var23.s = var16.world;
            byte var30 = var9;
            if (var30 == 0) {
               break label22;
            }

            AutoPearlCatch var31 = this;
            var24 = var31;
         }

         short var10001 = 15516;
         long var10002 = 6640572807338874198L ^ var2;
         var24.t = Integer.MIN_VALUE;
      }

      MinecraftClient var19 = b;
      ClientPlayerEntity var32 = var19.player;
      if (var32 != null) {
         MinecraftClient var20 = b;
         ClientPlayerEntity var21 = var20.player;
         this.l = var21.getPitch();
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      long var10001 = 96834815495641L ^ 50374058374628L;
      this.t = Integer.MIN_VALUE;
      Object[] var7 = new Object[]{129478283851837L};
      AutoPearlCatch var6 = this;
      var6.lReturningVoid(var7);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      byte var23;
      while (true) {
         short var10001 = 8753;
         long var10002 = 3697861088057625584L ^ var2;
         byte var25 = 9;
         int var24 = var5;
         if (var24 < var25) {
            label26: {
               MinecraftClient var6 = b;
               ClientPlayerEntity var7 = var6.player;
               PlayerInventory var37 = var7.getInventory();
               int var9 = var5;
               PlayerInventory var8 = var37;
               ItemStack var38 = var8.getStack(var9);
               int var27 = var4;
               ItemStack var26 = var38;
               ItemStack var22 = var26;
               ItemStack var19 = var26;
               if (var27 != 0) {
                  ItemStack var10 = var19;
                  byte var39 = ((byte)((var10.isEmpty()) ? 1 : 0));
                  int var29 = var4;
                  byte var28 = var39;
                  var23 = var28;
                  byte var20 = var28;
                  if (var29 == 0) {
                     break;
                  }

                  byte var30 = var20;
                  byte var21 = var30;
                  byte var31 = var21;
                  if (var31 != 0) {
                     break label26;
                  }

                  MinecraftClient var13 = b;
                  ClientPlayerEntity var14 = var13.player;
                  PlayerInventory var40 = var14.getInventory();
                  int var16 = var5;
                  PlayerInventory var15 = var40;
                  ItemStack var32 = var15.getStack(var16);
                  var22 = var32;
               }

               ItemStack var18 = var22;
               Item var41 = var18.getItem();
               Item var34 = Items.ENDER_PEARL;
               Item var33 = var41;
               if (var33 == var34) {
                  return var5;
               }
            }

            var5++;
            int var35 = var4;
            if (var35 != 0) {
               continue;
            }
         }

         var23 = -1;
         break;
      }

      return var23;
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 78851316161155L ^ var2;
      long var4 = var2 ^ 81881199802369L;
      int var10000 = Event.bReturningInt();
      int var6 = var10000;

      byte var26;
      while (true) {
         short var10001 = 13087;
         long var10002 = 2353940170129172589L ^ var2;
         byte var28 = 9;
         int var27 = var7;
         if (var27 < var28) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var41 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var41;
            ItemStack var12 = var10.getStack(var11);
            byte var42 = ((byte)((var12.isEmpty()) ? 1 : 0));
            int var30 = var6;
            byte var29 = var42;
            var26 = var29;
            byte var20 = var29;
            if (var30 != 0) {
               break;
            }

            label43: {
               int var32 = var6;
               byte var31 = var20;
               byte var23 = var31;
               byte var21 = var31;
               if (var32 == 0) {
                  byte var33 = var21;
                  byte var22 = var33;
                  byte var34 = var22;
                  if (var34 != 0) {
                     break label43;
                  }

                  MinecraftClient var15 = b;
                  ClientPlayerEntity var16 = var15.player;
                  PlayerInventory var43 = var16.getInventory();
                  int var18 = var7;
                  PlayerInventory var17 = var43;
                  Object[] var19 = new Object[]{var17.getStack(var18), var4};
                  byte var35 = ((byte)((fReturningBoolean(var19)) ? 1 : 0));
                  var23 = var35;
               }

               int var37 = var6;
               byte var36 = var23;
               int var25 = var36;
               byte var24 = var36;
               if (var37 != 0) {
                  return var25;
               }

               byte var38 = var24;
               if (var38 != 0) {
                  var25 = var7;
                  return var25;
               }
            }

            var7++;
            int var39 = var6;
            if (var39 == 0) {
               continue;
            }
         }

         var26 = -1;
         break;
      }

      return var26;
   }

   public static boolean fReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 78851316161155L ^ var1;
      ItemStack var4 = var3;
      Item var7 = var4.getItem();
      Item var6 = Items.WIND_CHARGE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 105017893678402L;
      long var6 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var9 = new Object[]{this, var6};
      RotationManager var8 = var10000;
      var8.dReturningVoid(var9);
      Object[] var11 = new Object[]{var4};
      AutoPearlCatch var10 = this;
      var10.lReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 37473309549131L;
      Object[] var9 = new Object[]{var6};
      AutoPearlCatch var8 = this;
      var8.kReturningVoid(var9);
      this.s = null;
      short var10001 = 15516;
      long var10002 = 6640598288318787210L ^ var2;
      this.t = Integer.MIN_VALUE;
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var4};
      RotationManager var10 = var10000;
      var10.eReturningVoid(var11);
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(84663426041496L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[6];
      String var6 = "ãàÊg\u0011\u001cx\u008d\u0083T\u0007`É_\u00ad\u0093G_.\bÊn\u0007\u008d\u0096r\u0095\u00ad3Õ\u001aÜ";
      int var7 = "ãàÊg\u0011\u001cx\u008d\u0083T\u0007`É_\u00ad\u0093G_.\bÊn\u0007\u008d\u0096r\u0095\u00ad3Õ\u001aÜ".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     v = var8;
                     w = new Integer[6];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "\u0004a\u008aê\u000b}Á´\"\u0081DËM\u008315";
                  var7 = "\u0004a\u008aê\u000b}Á´\"\u0081DËM\u008315".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2934;
      if (w[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = v[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])x.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               x.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ec", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         w[var3] = var15;
      }

      return w[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ec_C0222",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ec" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 62;
            yield var15;
         }
         case 1 -> {
            byte var16 = 37;
            yield var16;
         }
         case 2 -> {
            byte var17 = 36;
            yield var17;
         }
         case 3 -> {
            byte var18 = 0;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 30;
            yield var20;
         }
         case 6 -> {
            byte var21 = 55;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 52;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 47;
            yield var26;
         }
         case 12 -> {
            byte var27 = 60;
            yield var27;
         }
         case 13 -> {
            byte var28 = 45;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 46;
            yield var30;
         }
         case 16 -> {
            byte var31 = 2;
            yield var31;
         }
         case 17 -> {
            byte var32 = 41;
            yield var32;
         }
         case 18 -> {
            byte var33 = 32;
            yield var33;
         }
         case 19 -> {
            byte var34 = 9;
            yield var34;
         }
         case 20 -> {
            byte var35 = 7;
            yield var35;
         }
         case 21 -> {
            byte var36 = 54;
            yield var36;
         }
         case 22 -> {
            byte var37 = 48;
            yield var37;
         }
         case 23 -> {
            byte var38 = 19;
            yield var38;
         }
         case 24 -> {
            byte var39 = 3;
            yield var39;
         }
         case 25 -> {
            byte var40 = 28;
            yield var40;
         }
         case 26 -> {
            byte var41 = 10;
            yield var41;
         }
         case 27 -> {
            byte var42 = 43;
            yield var42;
         }
         case 28 -> {
            byte var43 = 35;
            yield var43;
         }
         case 29 -> {
            byte var44 = 26;
            yield var44;
         }
         case 30 -> {
            byte var45 = 15;
            yield var45;
         }
         case 31 -> {
            byte var46 = 21;
            yield var46;
         }
         case 32 -> {
            byte var47 = 5;
            yield var47;
         }
         case 33 -> {
            byte var48 = 1;
            yield var48;
         }
         case 34 -> {
            byte var49 = 42;
            yield var49;
         }
         case 35 -> {
            byte var50 = 53;
            yield var50;
         }
         case 36 -> {
            byte var51 = 31;
            yield var51;
         }
         case 37 -> {
            byte var52 = 14;
            yield var52;
         }
         case 38 -> {
            byte var53 = 44;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 8;
            yield var55;
         }
         case 41 -> {
            byte var56 = 34;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 4;
            yield var58;
         }
         case 44 -> {
            byte var59 = 23;
            yield var59;
         }
         case 45 -> {
            byte var60 = 12;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 11;
            yield var62;
         }
         case 48 -> {
            byte var63 = 17;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 51;
            yield var66;
         }
         case 52 -> {
            byte var67 = 59;
            yield var67;
         }
         case 53 -> {
            byte var68 = 18;
            yield var68;
         }
         case 54 -> {
            byte var69 = 13;
            yield var69;
         }
         case 55 -> {
            byte var70 = 61;
            yield var70;
         }
         case 56 -> {
            byte var71 = 6;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 58;
            yield var73;
         }
         case 59 -> {
            byte var74 = 16;
            yield var74;
         }
         case 60 -> {
            byte var75 = 20;
            yield var75;
         }
         case 61 -> {
            byte var76 = 27;
            yield var76;
         }
         case 62 -> {
            byte var77 = 63;
            yield var77;
         }
         default -> 25;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      y[0] = "KQ\fXnK]Q\t\u0002}\\J\u001a\n\u0004qH[]\u001d\u0013:Zj";
      y[1] = int.class;
      z[1] = "java/lang/Integer";
      y[2] = "\u0015]\u0015\u001c'\u0003\u0003]\u0010F4\u0014\u0014\u0016\u0013@8\u0000\u0005Q\u0004Ws\u0016\u0012";
      y[3] = "\t8Q\u0013Xn\u00027@\\;c\u0017:O7\u000ea\u0006)S\u001b\u0019l";
      y[4] = "._h^z4[\u007fcQk{:qhZo!N";
      y[5] = void.class;
      z[5] = "java/lang/Void";
      y[6] = "$RGb%\u0015$RP>)\u001a>\u0019P )\u000f9h\u0004x~";
      y[7] = "\u001b\u0011ggA~\u001b\u0011p;Mq\u0001Zp%Md\u0006+ x\u001c";
      y[8] = "WgOp\u0010\u0006WgX,\u001c\tM,X2\u001c\u001cJ]\boH";
      y[9] = ">\bLSH_>\b[\u000fDP$C[\u0011DE#2\u000bM\u0011";
      y[10] = boolean.class;
      z[10] = "java/lang/Boolean";
      y[11] = "\u001e>'g\u0014\rk\u001e,h\u0005B\n\u0010'c\u0001\u0018~";
      y[12] = "mU \u0012\u0015u{U%H\u0006bl\u001e&N\nv}Y1YAap";
      y[13] = "I\u0019\bV\u001cf<9\u0003Y\r)]7\bR\ts)";
      y[14] = "z9eww0l9`-d'{rc+h3j5t<##r5v7ynN.v*y)y9";
      y[15] = "\n5+\u0016K+\n5<JG$\u0010~<TG1\u0017\u000fn\u000f\u001f{";
      y[16] = "5L9Q\u0011`5L.\r\u001do/\u0007.\u0013\u001dz(v|HE;";
      y[17] = "jryro^jrn.cQp9n0cDwH<d2\u0005";
      y[18] = "\u000evPiU0\u0005yA&4>\u000erE|";
      y[19] = "m,}\u0007W=m,j[[2wgjE['p\u0016?\u001a\u0002";
      y[20] = float.class;
      z[20] = "java/lang/Float";
      y[21] = "Y(d\u0010;KO(aJ(\\XcbL$HI$u[o]d";
      y[22] = "\u001c\u000bH\u0010S5i+C\u001fBz\b%H\u0014F |";
      y[23] = "V+f\u001f &@+cE31W``C?%F'wTt2p";
      y[24] = "K;/II\\>\u001b$FX\u0013_\u0015/M\\I+";
      y[25] = "Z#z<nTZ#m`b[@hm~bNG\u0019<&0";
      y[26] = double.class;
      z[26] = "java/lang/Double";
      y[27] = "\u0015,P8Fz`\f[7W5\u0001\u0002P<Sou";
      y[28] = "\u0005s\u0003lcwpS\bcr8\u0011]\u0003hvbe";
      y[29] = "Ih\u0014HD2<H\u001fGU}]F\u0014LQ')";
      y[30] = "qVLk@HzY]$,Kt[_k\u0000";
      y[31] = "Ma3\u0001\u0011k[a6[\u0002|L*5]\u000eh]m\"JE\u007fx";
      y[32] = "P\u0002*0\u00040%\"!?\u0015\u007fD,*4\u0011%0";
      y[33] = "\u0014/&\u0006=\u0018\u0002/#\\.\u000f\u0015d Z\"\u001b\u0004#7Mi\f6";
      y[34] = "K\u0000`\u0001NM@\u000fqN&MN\u0000b";
      y[35] = "l~\b`,Mgq\u0019/O@rw";
      y[36] = "w7\u001bQjWw7\f\rfXm|\f\u0013fMj\r[L0";
      y[37] = "\u0005\u0017\u0000\u0011g\u0011p7\u000b\u001ev^\u00119\u0000\u0015r\u0004e";
      y[38] = "~=^{Cm\u000b\u001dUtR\"j\u0013^\u007fVx\u001e";
      y[39] = "\b\r\b9i8}-\u00036xw\u001c#\b=|-h";
      y[40] = "\u001fCU\u001aWX\u001fCBF[W\u0005\bBX[B\u0002y\u0010\u0002\u0002\u0005";
      y[41] = "P6\u001aB\u0016\u0007P6\r\u001e\u001a\bJ}\r\u0000\u001a\u001dM\f_^BY";
      y[42] = ">2}Y1\u000f :g\u0016V\u000e1!jLp\b";
      y[43] = "h\u000fcS3\u001f~\u000ff\t \biDe\u000f,\u001cx\u0003r\u0018g\u000bt";
      y[44] = "L=Pzb\u00169\u001d[usYX\u0013P~w\u0003,";
      y[45] = "~_\u001f>\u001akuP\u000eq}sqL\b=Xb";
      y[46] = "c+n\r9v\u0016\u000be\u0002(9w\u0005n\t,c\u0003";
      y[47] = "{Yl#\"\u0011\u000eyg,3^owl'7\u0004\u001b";
      y[48] = "lCoU!w\u0019cdZ08xmoQ4b\f";
      y[49] = "\u0007\u0014P\u007f/5r4[p>z\u0013:P{: g";
      y[50] = "sW;z37eW>   r\u001c=&,4c[*1g%v";
      y[51] = "qkW~\u007fX\u0004K\\qn\u0017eEWzjM\u0011";
      y[52] = "aYntaN\u0014ye{p\u0001uwnpt[\u0001";
      y[53] = "C\u0005[%\t)6%P*\u0018fW+[!\u001c<#";
      y[54] = "DA\t\u00173uRA\fM bE\n\u000fK,vTM\u0018\\gr";
      y[55] = "T0f7Ox!\u0010m8^7@\u001ef3Zm4";
      y[56] = "rv&\rB;\u0007V-\u0002StfX&\tW.\u0012";
      y[57] = "VPR5\u0011q@PWo\u0002fW\u001bTi\u000erF\\C~Eex";
      y[58] = "OSP\u0014\u000e7:s[\u001b\u001fx[}P\u0010\u001b\"/";
      y[59] = "r\u0010Unnjl\u0018O!\u0013zl";
      y[60] = "\ti\rCqd\ti\u001a\u001f}k\u0013\"\u001a\u0001}~\u0014SH[*<";
      y[61] = "\u0018Xe\\\u001bSmxnS\n\u001c\fveX\u000eFx";
      y[62] = "\u0018\u0002\u0017p.!m\"\u001c\u007f?n\f,\u0017t;4x";
      y[63] = "Vy6Fc\u0014Vy!\u001ao\u001bL2!\u0004o\u000eKCsZ8D";
      y[64] = "x\u0018aGOox\u0018v\u001bC`bSv\u0005Cue\"#Z\u0014";
      y[65] = "\nBI=K3\u001cBLgX$\u000b\tOaT0\u001aNXv\u001f \u0001";
      y[66] = "<R\u0002I\u001dfIr\tF\f)(|\u0002M\bs\\";
      y[67] = "Li\u000e\u0003G#9I\u0005\fVlXG\u000e\u0007R6,";
      y[68] = "GOA\u0006,k2oJ\t=$SaA\u00029~'";
      y[69] = "\u000bB\u0010x5l\u000bB\u0007$9c\u0011\t\u0007:9v\u0016xU`m2";
      y[70] = "/?\u0011f\"M/?\u0006:.B5t\u0006$.W2\u0005Tzy\u001c";
      y[71] = "!S\u0014Y\u0012NTs\u001fV\u0003\u00015}\u0014]\u0007[A";
      y[72] = "~ZrTu\u001e(\u001a1Sv%\"\b|OtI\u0010_;\u0011-\u0018GZn\u001faB:\tkL)%";
      y[73] = "#6wl6$sz-3[0L2*5g,'ww6k#L4(:);1g-ia\\";
      y[74] = ",\u001eG>\u0007CpM\u0013j`\u001d}\u000b\u0018h\f/+NE3Px)J\u001de\u001cGr\u0007G7Zx";
      y[75] = "\u0018\u0005/\u0012)sKX,RPeDX/B\u00072\u001a\bv.(1TV*A3:\u0015X";
      y[76] = "s*d\fm(/y0X\nv\"?;ZfDt}g\u00006\u0013\"y?D5u69`Q\n";
      y[77] = "Up+\u0001WWA(8Ui\u000bQk4X\u00059\u0003&j\u0007iQR'&X\u0014\u0002Wtn?";
      y[78] = "\"u%E\tw`w.[5f\u001b>.\u001e\t{p{s\u001d\u0005t\u001b8,\u0011Glfk)B\u000f\u000b";
      y[79] = "\tv*mM\u0006\u0002+j/.W9*<m\u0012KRoan\u001eD9()+H\u0000A|`3I;";
      y[80] = "\u007f\n\u0018\u000eg5,W\u001bN\u001e(/F\u001cUr\u001a{\u0007B\u0003\u001er,\n\u000eUc!)YF2";
      y[81] = "t.\u0018\u0001 j'\"R\u0004dQ$\u0012\u0019Wcm=y\\\n`a2\u0012\u0019\u0007dk1)J\u000b.nu\u0012";
      y[82] = "8`\u001eYGu87]Y8,.-FRT\u001eym\u0017\u000f\u0001I80WSI4*1B\\8";
      y[83] = "g\u0019\u0011bM\u0018;JE6*F6\fN4Ft`N\u0012n\u0017#6JJ*\u0015E\"\n\u0015?*";
      y[84] = "\u0002o\u0013#LV\u00183C)(V\u0002X\u0017*IC\u0003y~'\u0013J\n<\u000f?ET\u001f\u0002\u001f}HE[s\u0007+VPe";
      y[85] = "\rML\b!IAWW\u0004OF\u001cVBy$^JKA\u001a>_\u000fW>";
      y[86] = "\f2\u0018,)<N0\u00132\u0015)5z\u0018.(9D;\u0014+y@\u000f'\u0019ul1N+\u001c$\u0015";
      y[87] = "9V\u0001Xy\u0012#\nQR\u001d\u00059@l\\&\u000e1\u0005\u001dDp\u0010$;\r\u0006}\u0001`J\u0015Pc\u0014^";
      y[88] = "k^x&{Rq_=:\u0004\\y]*/\u007f1k^x&{Rq_=:\u0004\u000en\u00101,y]kCyK";
      y[89] = "\u0002;x-/5\u001f9%<L>\u00035{:\u001biYe%V-k\u00027!'5=\u001c\"";
      y[90] = "\u0019,Pt-:JqS4T,EqP$\u0003{\u001a-\fHi$_l\u0005y0|Hb";
      y[91] = "m6\u0006R\u0017,v#\u0016M{?\u001ct\u0011\tG$w1L\nK+\u001cv\u0004O\u001dod\"MW\u001cT";
      y[92] = "zg1,\rE'?9pnH\u001e9%uRQu|xv^^\u001e;03\b\u001afoy+\t!";
      y[93] = "!g]4ax!0\u001e4\u001e*;;\u00014Izbo_Xf/0(\u001e!t<7";
      y[94] = "\f\u001bsz%+WV)(c\u0014PKjp>xb\u001b*+i\u0014MM|n\"m_^{\u00100sJ\u0018()$+YL\u0016";
      y[95] = "\u0014i@!\u0000\tG4Cay\u001fH4@q.H\u0017i\u001b\u001d\u0015\u0010H?Jd\u001f\fK4";
      y[96] = "\r\u001544\u001a\nO\u0017?*&\u001c4^?o\u001a\u0006_\u001bbl\u0016\t4\u001alo[F^[6,Vv";
      y[97] = "lNk\u001c?\u00065\u0016|\u0012\u000eY0Et\u0000Y\u000e`\u0010,l0Y*Ra\t?V L";
      y[98] = "B1\u001eG\u001eP\u0004aFR\u00182\u0015<MO\u0012eFm\u0018\u001b~\u000b\u0017cLK\u001cMG;YM";
      y[99] = "\u0007+E}5[\b$OcD[T9^`(i\u0000y\u0005;D\u0001WuL`9RR&\u0004\u0007";
      y[100] = "{2e\u001fm\u0019'a1K\nG*':Ifuybc\u0013\n\u001d)k(IwN,8`.";
      y[101] = "\u00015\u0017R\u0019~\u001a \u0007Mulpw\u0000\tIv\u001b2]\nEypu\u0015O\u0013=\b!\\W\u0012\u0006";
      y[102] = "\u000fQT\u001b#\u0013HA\u0012}q)NQ\u0000\u0003`P\\B\u0007}";
      y[103] = "T^=\ntp\b\ri^\u0013%\tZfWDuP\u000e8;k \u0002IyBy3\u0005";
      y[104] = "\u0007j@,;p\u001d6\u0010&_w\u0001a-(dl\u000f9\\02r\u001a\u0007Lr?c^vT$!v`";
      y[105] = "SAe6\u000bT\u0000\u001cfvrB\u000f\u001cef%\u0015QO8\nK\u001c\u0002\u001f?f\u001cT\u0005\fj";
      y[106] = "\r]\n:#\"\u0019\u0005\u0019n\u001d~\tF\u0015cqL[\u000bM5\u001dq\u001c\u0007\u00054\u007f`\u001dE\u0005\u0004";
      y[107] = "J@3R?\u001a\b\u000f Gha\u0014\u0013ZV'Z\u001e\u00029L&\u001f\u0002}c\u00000\u000e\u0015\u0006!O#\u001bB}";
      y[108] = "^-)I\u0000b\b!6N\\\u0005\u000e\u001cqH\u00039\u0017w4\u0015\u00005\u0018\u001cs]Ec\\d'\u0014]bg";
      y[109] = "N&|\u000b\u000f6S$!\u001al6C9{\u0017\u0000\u0004\u0017}!Al3M\"`\u0013\t.O\u007fqp";
      y[110] = "d\u00068?\u00189#\u0016~YI\u0003d\u00019ePh!\\:i_\u0003dW?#Qzl\u00107<M\u0003";
      y[111] = "& \u0017\u0017]$d\"\u001c\ta4\u001fk\u001cL](t.AOQ'\u001f*\u001b\u0019\u001f#f8\b\u001ea";
      y[112] = "L|\u0005$E{\u000blCB\u0016A\r|Q<\u00068\u001foVB";
      y[113] = "^=\r\u0014H\u000e\u0002+_\u00180\u0002Z%X\bY\u000ec+X\u0018]h\u0002,\f\u0017W\u0015Q)__0";
      y[114] = "^^aTV\u0014\u0002\r5\u00001J\u000fK>\u0002]xY\tbX\u000e/\u000f\r:\u001c\u000eI\u001bMe\t1\u0014\u001bN8^I@RV9e";
      y[115] = "(O\tt\u001d4jM\u0002j!%\u0011\u0004\u0002/\u001d8zA_,\u00117\u0011E\u0005z_3hW\u0016}!";
      y[116] = "69n~V\u0011+;3o5\u001a77mibMmg1\u0005TO657tL\u0019( ";
      y[117] = "z4,+D\u0000,od5?\u000f\u001cnjhR\u0019\u007ftk-Nf";
      y[118] = "ZU`\n\u0017<Q\b Htlj\tv\nHq\u0001L+\tD~j\u000ft\u0005\u0006f\u0017\\qVN\u0001";
      y[119] = "xH_H\u0014Vs\u0015\u001f\nw\u0005H\u0014IHK\u001b#Q\u0014KG\u0014H\u0012KG\u0005\f5AN\u0014Mk";
      y[120] = "ki0\u0015\u0019\u000e`4pWz][5&\u0015FC0p{\u0016JL[73S\u001c\b#czK\u001d3";
      y[121] = "&\"\u0007l+7-\u007fG.Hg\u0016~\u0011ltz};Loxu\u0016|\u0004*.1n(M2/\n";
      y[122] = ".zL(M]}'Oh4Kr'Lxc\u001c,p\u0014\u0014\bL,{O/T\u001fx/";
      y[123] = "@joF!i\u001ejyLNn.h{\u0012rwE-&\u0011~x.jnT(<V>'L)\u0007";
      y[124] = "dUs\u000eX?8\u0006'Z?a5@,XSSa\fs\u000e\u000f\u00048_+D\\a%]vU?";
      y[125] = "f|gc)714`p|[:!wmp7\bv:4&[f'2=m\"2.ksy[f 5aw9 pmtq[fsyvq`03:qr[";
      y[126] = ";\u0007J\u007fy{h\t\u00154Gd\nH\u00104x`7CMt:";
      y[127] = "*}LF_fk'\u000fKoeW{\u001f\u0004S|<>B\u0007_sW/I_\u001631;\t\u0000\u0003\f";
      y[128] = "P9fg\u001c&\fj23{x\u0001,91\u0017JRiaj{$\u0000n56\u0019bP6 0{&\u0015)?m\u0003r\\1>V";
      y[129] = "\u0006\u0018\r\u0015uK\n\u0017\u000e\nKL\r\u000b\r\u0000\u001c\u0012R]Ul!ZQ\u0016Y\u000e0[\u0013\u0016";
      y[130] = "\u0000LdV\"\\LV\u007fZLU\u0015\\PJ<I|\u0018x\u0017>R\u0001K}Dv5";
      y[131] = "\u0014\fW{AjV\u000e\\e}u-G\\ AfF\u0002\u0001#Mi-EIf\u001b-U\u0011\u0000~\u001a\u0016";
      y[132] = "q\u0006\u0005_\u0013R-UQ\u000bt\f \u0013Z\t\u0018>vQ\u0006SJi U^\u0017K\u000f4\u0015\u0001\u0002tR4\u0016\\U\f\u0006}\u000e]n";
      y[133] = "+\u0000ON\u001aL ]\u000f\fy\u001b\u001b\\YNE\u0001p\u0019\u0004MI\u000e\u001b^L\b\u001fJc\n\u0005\u0010\u001eq";
      y[134] = "VwK1;\u007f\bw];Tx8u_ehaS0\u0002fdn8s]j&vE X9n\u0011";
      y[135] = "\u0001.*\u007f\u000ep\u001brzuji\u000f3GwPh\u001f|!c\u00107\nC* \u000euY%>`Q`f.}~\u00133\u0000:=!\u0006\f";
      y[136] = "\u0015)mgi#\u0000(0/T(\u0017#z7(.\u0011N|5&8\u0005'0/=4k";
      y[137] = ".Fl]\frlDgC0g\u0017\rg\u0006\f~|H:\u0005\u0000q\u0017\u000be\tBijX`Z\n\u000e";
      y[138] = "8>\\-E\u0016z<W3y\b\u0001uWvE\u001aj0\nuI\u0015\u0001wB0\u001fQy#\u000b(\u001ej";
      y[139] = "pK\u0018\u0000\u000ff1\u0011[\r?f\rMKB\u0003|f\b\u0016A\u000fs\r\u0019\u001d\u0019F3k\r]FS\f";
      y[140] = "AZ\u0005=q\u001dJ\u0007E\u007f\u0012Kq\u0006\u0013=.P\u001aCN>\"_q\u0000\u00112`G\fS\u0014a( ";
      y[141] = "U)\u0002=!sY&\u0001\"\u001ft^:\u0002(H&\u000eoWt\u001fpGj\u0016t}aF(\u0016";
      y[142] = "/Oxcx{$\u00128!\u001b*\u001f\u0013nc'6tV3`+9\u001f\u0015lli!bFi?!F";
      y[143] = "Y^5(b\u0011\u0004\u0006=t\u0001\u001c=\u0006#~s\u0012@U&-;u";
      y[144] = "3a\b,nT,)\u00000\t^0>\n*WY0$\u000eVd\n0 \\0pJo5c";
      y[145] = "\u0002\u001f\u0010)\u00012@\u001d\u001b7=\";T\u001br\u0001>P\u0011Fq\r1;R\u0019}O)F\u0001\u001c.\u0007N";
      y[146] = "\u001bWW\u001d\u000fXYU\\\u00033@\"\u001c\\F\u000fTIY\u0001E\u0003[\"\u001eI\u0000U\u001fZJ\u0000\u0018T$";
      y[147] = "}cg[SZw\u007fdP=F|~fZQt(2?\u0004\u0007#oek\u0004\u0000Izd6L=";
      y[148] = "\b-t!=vJ/\u007f?\u0001d1f\u007fz=zZ#\"y1u1`}usmL3x&;\n";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1306441424735998L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1306441424735998L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1306441424735998L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 118;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 227;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 112;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 219;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 181;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 204;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 118;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 227;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 112;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ec_C0222",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ec" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoPearlCatch var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ec_C0222;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ec_C0222", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
