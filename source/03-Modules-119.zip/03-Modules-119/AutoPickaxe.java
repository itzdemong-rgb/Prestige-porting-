package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public class AutoPickaxe extends Module {
   private BooleanSetting d;
   private BooleanSetting a;
   private MinMaxSetting c;
   private ElapsedTimer e;
   private static final Item[] f;
   private int g;
   private int h;
   private static final long k = 105457121378927L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[87];
   private static final String[] p = new String[87];

   public AutoPickaxe() {
      super();
      long var10001 = 128550668787738L ^ 24052208949043L;

      this.e = new ElapsedTimer(106698256430889L);
      this.g = -1;
      this.h = -1;
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 107379808440014L ^ 118401512305807L;
      var10001 = 107379808440014L ^ 89498384250382L;
      var10001 = 107379808440014L ^ 34269549320410L;
      var10001 = 107379808440014L ^ 84299357358529L;
      var10001 = 107379808440014L ^ 89728667825950L;
      var10001 = 107379808440014L ^ 35584372067256L;
      var10001 = 107379808440014L ^ 113796910804691L;
      var10001 = 107379808440014L ^ 25567057349779L;
      int var20 = Event.bReturningInt();
      int var149 = var20;
      MinecraftClient var148 = b;
      MinecraftClient var114 = var148;
      MinecraftClient var113 = var148;
      if (var149 == 0) {
         MinecraftClient var27 = var113;
         Screen var150 = var27.currentScreen;
         if (var150 != null) {
            return;
         }

         MinecraftClient var151 = b;
         var114 = var151;
      }

      int var153 = var20;
      MinecraftClient var152 = var114;
      MinecraftClient var116 = var152;
      MinecraftClient var115 = var152;
      if (var153 == 0) {
         MinecraftClient var30 = var115;
         boolean var154 = var30.isWindowFocused();
         if (!var154) {
            return;
         }

         var116 = b;
      }

      BlockPos var21;
      int var121;
      label149: {
         label162: {
            MinecraftClient var33 = var116;
            ClientPlayerEntity var34 = var33.player;
            BlockPos var35 = var34.getBlockPos();
            var21 = var35.down();
            BooleanSetting var36 = this.d;
            Boolean var37 = (Boolean)var36.aReturningObject();
            byte var10000 = ((byte)(((java.lang.Boolean)(var37)).booleanValue() ? 1 : 0));
            int var156 = var20;
            byte var155 = var10000;
            int var118 = var155;
            byte var117 = var155;
            if (var156 == 0) {
               byte var157 = var117;
               if (var157 == 0) {
                  break label162;
               }

               MinecraftClient var39 = b;
               Window var40 = var39.getWindow();
               long var41 = var40.getHandle();
               int var158 = GLFW.glfwGetMouseButton(var41, 0);
               var118 = var158;
            }

            int var160 = var20;
            int var159 = var118;
            int var120 = var159;
            int var119 = var159;
            if (var160 != 0) {
               int var164 = var120;
               var121 = var164;
               break label149;
            }

            byte var162 = 1;
            int var161 = var119;
            if (var161 != var162) {
               byte var163 = 1;
               var121 = var163;
               break label149;
            }
         }

         var121 = 0;
      }

      int var131;
      label182: {
         AutoPickaxe var130;
         label164: {
            boolean var129;
            int var22 = var121;
            MinecraftClient var47 = b;
            HitResult var23 = var47.crosshairTarget;
            boolean var209 = var23 instanceof BlockHitResult;
            int var166 = var20;
            boolean var165 = var209;
            var129 = var165;
            boolean var122 = var165;
            label135:
            if (var166 == 0) {
               boolean var167 = var122;
               if (var167) {
                  BlockHitResult var49 = (BlockHitResult)var23;
                  BlockPos var210 = var49.getBlockPos();
                  BlockPos var51 = var21;
                  BlockPos var50 = var210;
                  var209 = var50.equals(var51);
                  int var169 = var20;
                  boolean var168 = var209;
                  var129 = var168;
                  boolean var123 = var168;
                  if (var169 != 0) {
                     break label135;
                  }

                  boolean var170 = var123;
                  boolean var124 = var170;
                  boolean var171 = var124;
                  if (var171) {
                     int var173 = var20;
                     int var172 = var22;
                     var131 = var172;
                     int var125 = var172;
                     if (var173 != 0) {
                        break label182;
                     }

                     int var174 = var125;
                     int var126 = var174;
                     int var175 = var126;
                     if (var175 == 0) {
                        MinecraftClient var62 = b;
                        BlockPos var64 = var21;
                        ClientWorld var63 = var62.world;
                        BlockState var65 = var63.getBlockState(var64);
                        var131 = (((var65.isReplaceable()) ? 1 : 0));
                        break label182;
                     }
                  }
               }

               int var177 = var20;
               AutoPickaxe var176 = this;
               var130 = var176;
               AutoPickaxe var127 = var176;
               if (var177 != 0) {
                  break label164;
               }

               AutoPickaxe var178 = var127;
               AutoPickaxe var128 = var178;
               Object[] var58 = new Object[]{130745314673245L};
               AutoPickaxe var57 = var128;
               boolean var179 = var57.dReturningBoolean(var58);
               var129 = var179;
            }

            boolean var180 = var129;
            if (var180) {
               return;
            }

            var130 = this;
         }

         Object[] var61 = new Object[]{53655821629632L};
         AutoPickaxe var60 = var130;
         var60.jReturningVoid(var61);
         return;
      }

      MinecraftClient var139;
      label183: {
         AutoPickaxe var138;
         label167: {
            int var182 = var20;
            int var181 = var131;
            int var137 = var181;
            int var132 = var181;
            if (var182 == 0) {
               int var183 = var132;
               if (var183 == 0) {
                  int var185 = var20;
                  MinecraftClient var184 = b;
                  var139 = var184;
                  MinecraftClient var133 = var184;
                  if (var185 != 0) {
                     break label183;
                  }

                  MinecraftClient var186 = var133;
                  MinecraftClient var134 = var186;
                  MinecraftClient var68 = var134;
                  BlockPos var70 = var21;
                  ClientWorld var69 = var68.world;
                  BlockState var71 = var69.getBlockState(var70);
                  Block var212 = var71.getBlock();
                  Block var188 = Blocks.BEDROCK;
                  Block var187 = var212;
                  if (var187 != var188) {
                     var139 = b;
                     break label183;
                  }
               }

               int var190 = var20;
               AutoPickaxe var189 = this;
               var138 = var189;
               AutoPickaxe var135 = var189;
               if (var190 != 0) {
                  break label167;
               }

               AutoPickaxe var191 = var135;
               AutoPickaxe var136 = var191;
               Object[] var75 = new Object[]{130745314673245L};
               AutoPickaxe var74 = var136;
               byte var192 = ((byte)((var74.dReturningBoolean(var75)) ? 1 : 0));
               var137 = var192;
            }

            int var193 = var137;
            if (var193 != 0) {
               return;
            }

            var138 = this;
         }

         Object[] var78 = new Object[]{53655821629632L};
         AutoPickaxe var77 = var138;
         var77.jReturningVoid(var78);
         return;
      }

      AutoPickaxe var143;
      label169: {
         MinecraftClient var79 = var139;
         ClientPlayerEntity var80 = var79.player;
         Object[] var81 = new Object[]{var80.getMainHandStack(), 52994964568528L};
         boolean var213 = InventoryUtil.cReturningBoolean(var81);
         int var195 = var20;
         boolean var194 = var213;
         boolean var142 = var194;
         boolean var140 = var194;
         if (var195 == 0) {
            boolean var196 = var140;
            if (var196) {
               Object[] var84 = new Object[]{53655821629632L};
               AutoPickaxe var83 = this;
               var83.jReturningVoid(var84);
               return;
            }

            int var198 = var20;
            AutoPickaxe var197 = this;
            var143 = var197;
            AutoPickaxe var141 = var197;
            if (var198 != 0) {
               break label169;
            }

            ElapsedTimer var214 = var141.e;
            MinMaxSetting var86 = this.c;
            Float var87 = (Float)var86.aReturningObject();
            float var224 = var87;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var224;
            Object[] var89 = var10004;
            ElapsedTimer var88 = var214;
            boolean var199 = var88.aReturningBoolean(var89);
            var142 = var199;
         }

         boolean var200 = var142;
         if (!var200) {
            return;
         }

         var143 = this;
      }

      AutoPickaxe var147;
      label171: {
         Object[] var10005 = new Object[]{null, null, 11024363321921L};
         var10005[1] = 9;
         var10005[0] = 0;
         Object[] var92 = var10005;
         AutoPickaxe var91 = var143;
         Integer var24 = var91.aReturningBoxedInteger(var92);
         int var202 = var20;
         Integer var201 = var24;
         Object var146 = var201;
         Integer var144 = var201;
         if (var202 == 0) {
            Integer var203 = var144;
            if (var203 != null) {
               Object[] var94 = new Object[]{49487520630543L};
               this.g = InventoryUtil.aReturningInt(var94);
               this.h = -1;
               Integer var95 = var24;
               int var216 = var95;
               Object[] var10003 = new Object[]{null, 72518082610550L};
               var10003[0] = var216;
               Object[] var96 = var10003;
               InventoryUtil.aReturningVoid(var96);
               Object[] var98 = new Object[]{53655821629632L};
               AutoPickaxe var97 = this;
               var97.jReturningVoid(var98);
               return;
            }

            int var205 = var20;
            AutoPickaxe var204 = this;
            var147 = var204;
            AutoPickaxe var145 = var204;
            if (var205 != 0) {
               break label171;
            }

            BooleanSetting var100 = var145.a;
            Object var206 = var100.aReturningObject();
            var146 = var206;
         }

         Boolean var102 = (Boolean)var146;
         boolean var207 = var102;
         if (!var207) {
            return;
         }

         var147 = this;
      }

      Object[] var226 = new Object[]{null, null, 11024363321921L};
      var226[1] = 36;
      var226[0] = 9;
      Object[] var105 = var226;
      AutoPickaxe var104 = var147;
      Integer var25 = var104.aReturningBoxedInteger(var105);
      Integer var208 = var25;
      if (var208 != null) {
         Object[] var107 = new Object[]{49487520630543L};
         int var26 = InventoryUtil.aReturningInt(var107);
         this.g = var26;
         Integer var108 = var25;
         this.h = var108;
         Integer var109 = var25;
         int var215 = var109;
         Object[] var225 = new Object[]{null, null, 7516849659933L};
         var225[1] = var26;
         var225[0] = var215;
         Object[] var110 = var225;
         InventoryUtil.fReturningBoolean(var110);
         Object[] var112 = new Object[]{53655821629632L};
         AutoPickaxe var111 = this;
         var111.jReturningVoid(var112);
      }
   }

   private Integer aReturningBoxedInteger(Object[] var1) {
      int var5 = (Integer)var1[0];
      int var2 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 105457121378927L ^ var3;
      int var30 = Event.bReturningInt();
      Item[] var7 = f;
      int var6 = var30;
      int var8 = var7.length;
      while (true) {
         int var21 = var8;
         int var20 = var9;
         if (var20 >= var21) {
            return null;
         }

         Item var18 = var7[var9];

         label31:
         while (true) {
            Item var10 = var18;
            int var11 = var5;

            int var28;
            do {
               int var23 = var2;
               int var22 = var11;
               if (var22 >= var23) {
                  break;
               }

               MinecraftClient var12 = b;
               ClientPlayerEntity var13 = var12.player;
               PlayerInventory var31 = var13.getInventory();
               int var15 = var11;
               PlayerInventory var14 = var31;
               ItemStack var16 = var14.getStack(var15);
               Item var32 = var16.getItem();
               int var25 = var6;
               Item var24 = var32;
               var18 = var24;
               Item var19 = var24;
               if (var25 != 0) {
                  continue label31;
               }

               Item var27 = var10;
               Item var26 = var19;
               if (var26 == var27) {
                  int var17 = var11;
                  return var17;
               }

               var11++;
               var28 = var6;
            } while (var28 == 0);

            var9++;
            int var29 = var6;
            if (var29 != 0) {
               return null;
            }
            break;
         }
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 105457121378927L ^ var2;
      long var4 = var2 ^ 28366555838706L;
      long var6 = var2 ^ 115398469354820L;
      long var8 = var2 ^ 52596260511791L;
      long var10 = var2 ^ 103425921456713L;
      int var12 = Event.bReturningInt();
      int var33 = var12;
      int var32 = this.g;
      int var27 = var32;
      int var26 = var32;
      if (var33 == 0) {
         // int var34 = var26;
         if (var34 == var35) {
            return false;
         }

         ElapsedTimer var10000 = this.e;
         Object[] var16 = new Object[]{this.c, var10};
         ElapsedTimer var15 = var10000;
         var27 = (((var15.bReturningBoolean(var16)) ? 1 : 0));
      }

      int var37 = var12;
      int var36 = var27;
      int var29 = var36;
      int var28 = var36;
      if (var37 == 0) {
         int var38 = var28;
         if (var38 == 0) {
            return true;
         }

         var29 = this.h;
      }

      label32: {
         int var40 = var12;
         int var39 = var29;
         int var31 = var39;
         int var30 = var39;
         if (var40 == 0) {
            // int var41 = var30;
            if (var41 != var42) {
               int var46 = this.h;
               int var10001 = this.g;
               Object[] var10004 = new Object[]{null, null, var8};
               var10004[1] = var10001;
               var10004[0] = var46;
               Object[] var20 = var10004;
               InventoryUtil.fReturningBoolean(var20);
               int var43 = var12;
               if (var43 == 0) {
                  break label32;
               }
            }

            int var44 = this.g;
            var31 = var44;
         }

         Object[] var10003 = new Object[]{null, var6};
         var10003[0] = var31;
         Object[] var23 = var10003;
         InventoryUtil.aReturningVoid(var23);
      }

      this.g = -1;
      this.h = -1;
      Object[] var25 = new Object[]{var4};
      AutoPickaxe var24 = this;
      var24.jReturningVoid(var25);
      return true;
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 105457121378927L ^ var2;
      long var4 = var2 ^ 31811064923360L;
      long var6 = var2 ^ 81158957634223L;
      ElapsedTimer var10000 = this.e;
      Object[] var9 = new Object[]{var6};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      MinMaxSetting var13 = this.c;
      Object[] var11 = new Object[]{var4};
      MinMaxSetting var10 = var13;
      var10.bReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      this.g = -1;
      this.h = -1;
   }

   static {

      {

      f();
      Cipher var0;
      Cipher var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(35975716816685L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[4];
      String var4 = "[;\u0003\u007fÅ´ÞÙ\u008dfV[F\u0010ªe";
      int var5 = "[;\u0003\u007fÅ´ÞÙ\u008dfV[F\u0010ªe".length();
      label23:
      while (true) {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var12 = var6;
         var10001 = var3++;
         long var15 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         // while (true) {
            long var8 = var15;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var19 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var17) {
               case 0:
                  var12[var10001] = var19;
                  if (var2 >= var5) {
                     l = var6;
                     m = new Integer[4];
                     f = new Item[]{
                        Items.NETHERITE_PICKAXE, Items.DIAMOND_PICKAXE, Items.IRON_PICKAXE, Items.STONE_PICKAXE, Items.GOLDEN_PICKAXE, Items.WOODEN_PICKAXE
                     };
                     break;
                  }
                  break;
               default:
                  var12[var10001] = var19;
                  if (var2 < var5) {
                     continue label23;
                  }

                  var4 = "æ§þ\u0091 h\u008e\u0002(\u008dÆ\u009b+\u0093k\u0098";
                  var5 = "æ§þ\u0091 h\u008e\u0002(\u008dÆ\u009b+\u0093k\u0098".length();
                  var2 = 0;
            }

            int var14 = var2;
            var2 += 8;
            var7 = var4.substring(var14, var2).getBytes("ISO-8859-1");
            var12 = var6;
            var10001 = var3++;
            var15 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var17 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6912;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ed", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ed_C0224",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ed" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 19;
            yield var15;
         }
         case 1 -> {
            byte var16 = 58;
            yield var16;
         }
         case 2 -> {
            byte var17 = 42;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 44;
            yield var19;
         }
         case 5 -> {
            byte var20 = 48;
            yield var20;
         }
         case 6 -> {
            byte var21 = 6;
            yield var21;
         }
         case 7 -> {
            byte var22 = 10;
            yield var22;
         }
         case 8 -> {
            byte var23 = 17;
            yield var23;
         }
         case 9 -> {
            byte var24 = 4;
            yield var24;
         }
         case 10 -> {
            byte var25 = 22;
            yield var25;
         }
         case 11 -> {
            byte var26 = 33;
            yield var26;
         }
         case 12 -> {
            byte var27 = 8;
            yield var27;
         }
         case 13 -> {
            byte var28 = 1;
            yield var28;
         }
         case 14 -> {
            byte var29 = 47;
            yield var29;
         }
         case 15 -> {
            byte var30 = 45;
            yield var30;
         }
         case 16 -> {
            byte var31 = 16;
            yield var31;
         }
         case 17 -> {
            byte var32 = 11;
            yield var32;
         }
         case 18 -> {
            byte var33 = 54;
            yield var33;
         }
         case 19 -> {
            byte var34 = 14;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 49;
            yield var37;
         }
         case 23 -> {
            byte var38 = 27;
            yield var38;
         }
         case 24 -> {
            byte var39 = 41;
            yield var39;
         }
         case 25 -> {
            byte var40 = 61;
            yield var40;
         }
         case 26 -> {
            byte var41 = 52;
            yield var41;
         }
         case 27 -> {
            byte var42 = 9;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 12;
            yield var44;
         }
         case 30 -> {
            byte var45 = 0;
            yield var45;
         }
         case 31 -> {
            byte var46 = 26;
            yield var46;
         }
         case 32 -> {
            byte var47 = 43;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 31;
            yield var49;
         }
         case 35 -> {
            byte var50 = 13;
            yield var50;
         }
         case 36 -> {
            byte var51 = 50;
            yield var51;
         }
         case 37 -> {
            byte var52 = 24;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 40;
            yield var55;
         }
         case 41 -> {
            byte var56 = 46;
            yield var56;
         }
         case 42 -> {
            byte var57 = 21;
            yield var57;
         }
         case 43 -> {
            byte var58 = 36;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 32;
            yield var60;
         }
         case 46 -> {
            byte var61 = 39;
            yield var61;
         }
         case 47 -> {
            byte var62 = 25;
            yield var62;
         }
         case 48 -> {
            byte var63 = 15;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 37;
            yield var65;
         }
         case 51 -> {
            byte var66 = 63;
            yield var66;
         }
         case 52 -> {
            byte var67 = 3;
            yield var67;
         }
         case 53 -> {
            byte var68 = 62;
            yield var68;
         }
         case 54 -> {
            byte var69 = 30;
            yield var69;
         }
         case 55 -> {
            byte var70 = 7;
            yield var70;
         }
         case 56 -> {
            byte var71 = 18;
            yield var71;
         }
         case 57 -> {
            byte var72 = 51;
            yield var72;
         }
         case 58 -> {
            byte var73 = 57;
            yield var73;
         }
         case 59 -> {
            byte var74 = 38;
            yield var74;
         }
         case 60 -> {
            byte var75 = 34;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 35;
            yield var77;
         }
         default -> 20;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = ";YW$\u0010Q;Y@x\u001c^!\u0012@f\u001cK&c\u00122M\n";
      o[1] = "\u001d E|\u0015c\u001d R \u0019l\u0007kR>\u0019y\u0000\u001a\u0000eA8";
      o[2] = "\u0001|\u0013\u001b\u0000#\u0017|\u0016A\u00134\u00007\u0015G\u001f \u0011p\u0002PT2 ";
      o[3] = int.class;
      p[3] = "java/lang/Integer";
      o[4] = "K\u000b3\u000ep\\]\u000b6TcKJ@5Ro_[\u0007\"E$O@";
      o[5] = "QVn\u001c_-$ve\u0013NbExn\u0018J81";
      o[6] = void.class;
      p[6] = "java/lang/Void";
      o[7] = "\u00199:H)\u0005\u000f9?\u0012:\u0012\u0018r<\u00146\u0006\t5+\u0003}\u0013$";
      o[8] = "/7\u0010,:'Z\u0017\u001b#+h;\u0019\u0010(/2O";
      o[9] = boolean.class;
      p[9] = "java/lang/Boolean";
      o[10] = "<D\u0001>\u0001\u0005*D\u0004d\u0012\u0012=\u000f\u0007b\u001e\u0006,H\u0010uU\u0010<";
      o[11] = "QdpSV\u0003$D{\\GLEJpWC\u00161";
      o[12] = "|D$\u0003g_wK5L\u0004RbF:'1PsU&\u000b&]";
      o[13] = "\u0003'\n&3_v\u0007\u0001)\"\u0010\u0017\t\n\"&Jc";
      o[14] = "!kd\\l\u0002!ks\u0000`\r; s\u001e`\u0018<Q\"@5]";
      o[15] = "\u0004\u0016hQV`\u0004\u0016\u007f\rZo\u001e]\u007f\u0013Zz\u0019,.M\u000f1";
      o[16] = "FjL5Rd3JG:C+RDL1Gq&";
      o[17] = "\u000b\u001e|\u001d8\u0012~>w\u0012)]\u001f0|\u0019-\u0007k";
      o[18] = "AY\\V5oJVM\u0019Rm_]MRi";
      o[19] = "\r\n\u0017@Sc\r\n\u0000\u001c_l\u0017A\u0000\u0002_y\u00100QX\u0006:";
      o[20] = "YYW`\u001f\u001bYY@<\u0013\u0014C\u0012@\"\u0013\u0001Dc\u0010\u007fB";
      o[21] = "dg\n*g\u0007dg\u001dvk\b~,\u001dhk\u001dy]J7=";
      o[22] = ",s\u000bZ:C'|\u001a\u0015V@)~\u0018Zz";
      o[23] = "W\b3@\u0014sW\b$\u001c\u0018|MC$\u0002\u0018iJ2u]J\"";
      o[24] = "_\u0005a-?\u0011I\u0005dw,\u0006^Ngq \u0012O\tpfk\u0005}";
      o[25] = "\u001e\u0019%St[\u0015\u00164\u001c\u0015U\u001e\u001d0F";
      o[26] = "\r6\\~B@\r6K\"NO\u0017}K<NZ\u0010\f\u001fd\u0019";
      o[27] = "\u0014U8\u001dDwau3\u0012U8\u0000{8\u0019Qbt";
      o[28] = "`NOX$B`NX\u0004(Mz\u0005X\u001a(X}t\nF}\u001a";
      o[29] = "\nEh\u0001\u0012^\nE\u007f]\u001eQ\u0010\u000e\u007fC\u001eD\u0017\u007f/\u0016I\u0002";
      o[30] = "\u0014\u000f '\u0012c\u0014\u000f7{\u001el\u000eD7e\u001ey\t5b:G";
      o[31] = long.class;
      p[31] = "java/lang/Long";
      o[32] = "w)\u0019;N-\u0002\t\u00124_bc\u0007\u0019?[8\u0017";
      o[33] = "Hm8<\u0010'Hm/`\u001c(R&/~\u001c=UW}%Dw";
      o[34] = "\u001b_\u0013P~e\u001b_\u0004\frj\u0001\u0014\u0004\u0012r\u007f\u0006eUM*";
      o[35] = "d\u0017lUP\fo\u0018}\u001a8\fa\u0017n";
      o[36] = float.class;
      p[36] = "java/lang/Float";
      o[37] = ".gF&vA+rM&}Z'b\u000fOVp\u0016";
      o[38] = "QUe\u0006GC$un\tV\fE{e\u0002RV1";
      o[39] = "FI>U\u0005JPI;\u000f\u0016]G\u00028\t\u001aIVE/\u001eQ^n";
      o[40] = "T_JHc#!\u007fAGrl@qJLv64";
      o[41] = "\u0006##MJ>s\u0003(B[q\u0012\r#I_+f";
      o[42] = "k)\rnQLk)\u001a2]Cqb\u001a,]Vv\u0013Hv\n\u0014";
      o[43] = "aj\u0018B\f\r%`WIe\r\u001bx\r\t\u000e\t~zX]\u0015g'mS^\b\f{c\u0011Qe";
      o[44] = "\u001cX^\r^N_E\n\f7\u0014%\u001c\u000e\u0004OCD\u0019\b\u0004Y~";
      o[45] = "i\u0011L?$w0\b\u0012fA~a\u0017Hc\u0016!1J\u0013\u000f++:\u001dI09m~\n";
      o[46] = "vp{\u0003Cerp:\u0015*>zaa\u0018F\f,$<C\u001a[k k\u001cJ!(dn\u0016*";
      o[47] = "R}p4<$Ooh<@/Zqy+,\u001d\b<!}@s^w{%02J\u007fpL";
      o[48] = "H\u0000W]^+J\f\u000e]3xw\u0019\f[Xz\u0012\u001bY\u000fC\u0014I\f\u0013\u000eJ(\u0016\u0012WX3";
      o[49] = "u\u000b\u001d\u001b>Gl\u0002\u001b'mM~\u0001Jp9\u0016+_\u001a':Ei\u0007OW{Qa\f";
      o[50] = "$PE2H\u0005=YC\u000e\u001b\u000f/Z\u0012YEU}\u0001~7\u001c\u0014 W\u000ev\b\u001c+";
      o[51] = "Z*%]2\u0019X&|]_Oe3~[4H\u00001+\u000f/&\u000e: \u001b3D_9#__";
      o[52] = "Ha50*jZ?04\u0016~Is<0zL\u001e1fo*\u001bN4f0s$\\r\"'\u0016";
      o[53] = "!Y\u0019A7g~\u000b\u0019\u0004Im\u001a\u001c\u0012\u0003\"j\u007f\u001eGW9\u0004&\tLT$oz\u0007\u000e[I";
      o[54] = "\u0007QjF\u001bMU\u0001p@{A\u000b\u0007~I,\u0016UW'%\u0015\u0012\u0010\u000bq@\u001bV\u0000P";
      o[55] = "P|\u0011\u001el\rIu\u0017\"?\u0007[vFua]\r/*\u001b8\u001cT{ZZ,\u0014_";
      o[56] = "#nN\u0005:\u001eq>T\u0003Z\u0019#)^\u00016+wh\u0000WZB /P\u001ff\u001d>k\u0006f";
      o[57] = "34;`_?\"8{~!>:4`oH2\u0003:`\u007fLTc=~lXh<#::!";
      o[58] = "\u0017\u001fQ~Su\u001b\u001b\u0012w5.*\u000bH7^*O\t\u001dcED\u0014\u001eWbLxK\u0000\u001345";
      o[59] = "k?jc\bg~2(2qhi,2i\u001dZ=hj1M\rk?jc\bg~2(2q";
      o[60] = "B\u0010-jk4RLea\u0019,\"Hi)w4\u001a\u0011xs!E";
      o[61] = "\u0015B\n9_=DA\t}3>\u0018Lo+W\"\u00130\u000b/U'CQ\u000e)U1~";
      o[62] = "hawZyv:1m\\\u0019zd7cUN-:`;9xy\u007f&n\u0007|y>0";
      o[63] = "k\nIP;gg\u000e\nY]?V\u001eP\u0019683\u001c\u0005M-Vj\u000b\u000eN0=6\u0005LA]";
      o[64] = "{89R\u0005\\\u007f8xDl\u0007w)#I\u00005 i~\u0017Qbu:{C\u0015\b`79\u0012l";
      o[65] = "bF\bNv9wKJ\u001f\u000f>tTYGtSmT\u0001M~k4E[\u001b\u000fmcS^Z32}\u0017\b#";
      o[66] = "okdW|S09d\u0012\u0002YT.o\u0015i^1,:Ar0n8lV?Qk>l@\u0002";
      o[67] = "#iG<~\u000eq9]:\u001e\t#.W8r;th\to%l,(\u0006-&\u0005 +[o\u001e";
      o[68] = "h+FqMHzuCuq\\i9Oq\u001dn8x\u0013)M9:+Ux\b\u0005e5\u0011.q";
      o[69] = "D\u0003U\t\u0011\bETQ_,\bJN[\t@:\u001e\r\u0004Q\u0013mH]\u0003\u0003U\u0007]PAR,";
      o[70] = "X@W9hE\u0004[_zP^QVQ,<l\f\u0011\u000bsPTS\u0012\\2:A^P\rK<UUM\r:.\u000bPI1";
      o[71] = "\u00170xkC:F3{//&\u0015&>}h6|x.vWe\u001d}(vAX\u00170xkC:F3{//";
      o[72] = "8,\u0005xe$4/X:](7*Tm1\u001afj\u00052])#3Ep%s%:\b\n";
      o[73] = "aq7#\u0011\u001fxx1\u001fB\u0015j{`H\u001cO7 \f&E\u000eev|gQ\u0006n";
      o[74] = "\u000esGF\fw\u0002w\u0004Oj/3g^\u000f\u0001(Ve\u000b[\u001aF\rrAZ\u0013zRl\u0005\fj";
      o[75] = "d5\u0018XB$`5YN+\u007fh$\u0002CGM;`^\u001b+\u007fu1\u001aXEbg)\u0012$";
      o[76] = "R\u0011\u0007\u0001X)\u0000A\u001d\u00078%^G\u0013\u000eor\u0000\u0014Jb^-PAOR[$ZH";
      o[77] = "Hf\u000fK%+\u000b\"\nAE4Y'\u0005O)\u0006\tg^\u0018EkY=\u001d\u0015$n_=\u000b( !]#\u0019F=3E+e";
      o[78] = "g\tno=\u00125Yti]\u001ek_z`\nI4\u0002!\f9\u001al@&re\u0001d\u0003";
      o[79] = "E;]H\u001c,\u0018*\fRp<F?\u000bT.;F%\u000f(\u0017 @;\u001dUNkB*b";
      o[80] = "\u0004E\u0013l!E\u001dL\u0015PrO\u000fOD\u0007,\u0012Z\u0010(iuT\u0000BX(a\\\u000b";
      o[81] = "\u0011~R;\u00138\bwT\u0007@2\u001at\u0005P\u001emK/i>G)\u0015y\u0019\u007fS!\u001e";
      o[82] = "\u0017,<EF^S-!_&J\u000b$<iKY*->]Ko\u00126?A@%\u000b3&W\\]Q5/\u001a&\u001f\u0002,;\u001bG\u001a\u0004,-&\u001cH\t2~G\u0019N\t$C";
      o[83] = "@xQ.d\u0014\u001f*Qk\u001a\u001c{=Zlq\u0019\u001e?\u000f8jwE(E9cK\u001a6\u0001o\u001a";
      o[84] = "z;\bIvvx7QI\u001b+E\"SOp'  \u0006\u001bkIy7\r\u0018v\"%9O\u0017\u001b";
      o[85] = "qD\u0013#z(sHJ#\u0017~N\u0016Lr{,%A\u0010f}\u0017~GAr,|)\u001bUt\u0017";
      o[86] = "\u001eZMF\u0010,A\bM\u0003n!%\u001fF\u0004\u0005!@\u001d\u0013P\u001eO\u001b\nYQ\u0017sD\u0014\u001d\u0007n";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1811892545712576L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1811892545712576L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1811892545712576L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 244;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 226;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 75;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 70;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 186;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 246;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 244;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 226;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 75;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ed_C0224",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ed" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
