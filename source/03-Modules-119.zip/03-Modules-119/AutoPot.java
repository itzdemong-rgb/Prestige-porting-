package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

public class AutoPot extends Module {
   private ModeSetting a;
   private FloatSetting c;
   private FloatSetting d;
   private ElapsedTimer e;
   private static final long k = 100607093130905L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long o;
   private static final Object[] p = new Object[49];
   private static final String[] q = new String[49];
   private static volatile MethodHandle bindingCache1;

   public AutoPot() {
      super();
      long var10001 = 119083254949909L ^ 14588471942972L;

      this.e = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.UHC;
      return Set.of(var4);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 13970393469799L ^ 115945225134921L;
      var10001 = 13970393469799L ^ 46462569446247L;
      var10001 = 13970393469799L ^ 125580336022899L;
      var10001 = 13970393469799L ^ 73480212148331L;
      var10001 = 13970393469799L ^ 69949461178858L;
      int var14 = Event.cReturningInt();
      int var74 = var14;
      MinecraftClient var73 = b;
      MinecraftClient var60 = var73;
      MinecraftClient var59 = var73;
      if (var74 != 0) {
         MinecraftClient var17 = var59;
         Screen var75 = var17.currentScreen;
         if (var75 != null) {
            return;
         }

         MinecraftClient var76 = b;
         var60 = var76;
      }

      MinecraftClient var20 = var60;
      int var10000 = (((var20.isWindowFocused()) ? 1 : 0));
      int var78 = var14;
      byte var77 = (byte)var10000;
      byte var62 = var77;
      byte var61 = var77;
      if (var78 != 0) {
         byte var79 = var61;
         if (var79 == 0) {
            return;
         }

         ModeSetting var22 = this.a;
         String var98 = (String)var22.aReturningObject();
         String var24 = "Auto";
         String var23 = var98;
         var62 = ((byte)((var23.equals(var24)) ? 1 : 0));
      }

      byte var15;
      int var66;
      var15 = var62;
      int var81 = var14;
      byte var80 = var15;
      var66 = var80;
      byte var63 = var80;
      label62:
      if (var81 != 0) {
         byte var82 = var63;
         if (var82 != 0) {
            MinecraftClient var26 = b;
            ClientPlayerEntity var27 = var26.player;
            float var99 = var27.getHealth();
            FloatSetting var28 = this.c;
            Float var29 = (Float)var28.aReturningObject();
            float var115;
            var10000 = (var115 = var99 - var29) == 0.0F ? 0 : (var115 < 0.0F ? -1 : 1);
            int var84 = var14;
            int var83 = var10000;
            var66 = var83;
            int var64 = var83;
            if (var84 == 0) {
               break label62;
            }

            int var85 = var64;
            int var65 = var85;
            int var86 = var65;
            if (var86 > 0) {
               ElapsedTimer var102 = this.e;
               Object[] var33 = new Object[]{42835128969216L};
               ElapsedTimer var32 = var102;
               var32.aReturningVoid(var33);
               return;
            }
         }

         ElapsedTimer var101 = this.e;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = 300.0F;
         Object[] var36 = var10004;
         ElapsedTimer var35 = var101;
         var66 = (((var35.aReturningBoolean(var36)) ? 1 : 0));
      }

      int var88 = var14;
      int var87 = var66;
      int var68 = var87;
      int var67 = var87;
      if (var88 != 0) {
         int var89 = var67;
         if (var89 == 0) {
            return;
         }

         var68 = var15;
      }

      label75: {
         int var91 = var14;
         int var90 = var68;
         int var70 = var90;
         int var69 = var90;
         if (var91 != 0) {
            int var92 = var69;
            if (var92 == 0) {
               break label75;
            }

            var70 = 0;
         }

         int var111 = (int)o;
         Object[] var10005 = new Object[]{null, null, StatusEffects.INSTANT_HEALTH, 111906004283438L};
         var10005[1] = var111;
         var10005[0] = var70;
         Object[] var39 = var10005;
         Integer var16 = InventoryUtil.eReturningBoxedInteger(var39);
         int var94 = var14;
         Integer var93 = var16;
         Integer var72 = var93;
         Integer var71 = var93;
         if (var94 != 0) {
            Integer var95 = var71;
            if (var95 == null) {
               return;
            }

            var72 = var16;
         }

         Integer var41 = var72;
         var10000 = var41;
         Runnable var112 = invokeBinding1(this);
         var10005 = new Object[]{null, null, null, 86177674060556L};
         var10005[2] = true;
         var10005[1] = var112;
         var10005[0] = var10000;
         Object[] var42 = var10005;
         InventoryUtil.bReturningVoid(var42);
         ElapsedTimer var104 = this.e;
         Object[] var44 = new Object[]{42835128969216L};
         ElapsedTimer var43 = var104;
         var43.aReturningVoid(var44);
         int var96 = var14;
         if (var96 != 0) {
            return;
         }
      }

      MinecraftClient var45 = b;
      ClientPlayerEntity var46 = var45.player;
      float var97 = var46.getPitch();
      MinecraftClient var47 = b;
      ClientPlayerEntity var105 = var47.player;
      FloatSetting var48 = this.d;
      Float var49 = (Float)var48.aReturningObject();
      float var113 = var49 - 1.0F;
      Random var50 = RandomUtil.a;
      float var52 = var113 + var50.nextFloat();
      ClientPlayerEntity var51 = var105;
      var51.setPitch(var52);
      Object[] var53 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var53);
      MinecraftClient var54 = b;
      float var56 = var97;
      ClientPlayerEntity var55 = var54.player;
      var55.setPitch(var56);
      ElapsedTimer var106 = this.e;
      Object[] var58 = new Object[]{42835128969216L};
      ElapsedTimer var57 = var106;
      var57.aReturningVoid(var58);
   }

   private void lambda$onTick$1() {
      long var10001 = 98356721412345L ^ 116954810471028L;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      float var5 = var7.getPitch();
      MinecraftClient var8 = b;
      ClientPlayerEntity var10000 = var8.player;
      FloatSetting var9 = this.d;
      Float var10 = (Float)var9.aReturningObject();
      float var18 = var10 - 1.0F;
      Random var11 = RandomUtil.a;
      float var13 = var18 + var11.nextFloat();
      ClientPlayerEntity var12 = var10000;
      var12.setPitch(var13);
      Object[] var14 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var14);
      MinecraftClient var15 = b;
      float var17 = var5;
      ClientPlayerEntity var16 = var15.player;
      var16.setPitch(var17);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(28449472191226L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[2];
      String var11 = "\u008a\u0089\u0019ßj·\u0004\u0099vrpók\bÂÑ\u0010\bPéwøNÓÞ\u00adh \u0000×ü:l";
      int var13 = "\u008a\u0089\u0019ßj·\u0004\u0099vrpók\bÂÑ\u0010\bPéwøNÓÞ\u00adh \u0000×ü:l".length();
      char var10 = 16;
      int var9 = -1;

      while (true) {
         byte[] var15 = var7.doFinal(var11.substring(++var9, var9 + var10).getBytes("ISO-8859-1"));
         String var21 = b(var15).intern();
         // var14[var12++] = var21;
         if ((var9 += var10) >= var13) {
            l = var14;
            m = new String[2];
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(28449472191226L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long var19 = -5987491385869851956L;
            byte[] var4 = var0.doFinal(
               new byte[]{
                  (byte)172L,
                  (byte)44264L,
                  (byte)11331624L,
                  (byte)2900895822L,
                  (byte)742629330625L,
                  (byte)190113108640132L,
                  (byte)48668955811873826L,
                  (byte)-5987491385869851956L
               }
            );
            long var24 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            o = var24;
            break;
         }

         var10 = var11.charAt(var9);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5836;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ee", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ee_C0226",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ee" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 44;
            yield var15;
         }
         case 1 -> {
            byte var16 = 54;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 4;
            yield var19;
         }
         case 5 -> {
            byte var20 = 63;
            yield var20;
         }
         case 6 -> {
            byte var21 = 28;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 3;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 42;
            yield var26;
         }
         case 12 -> {
            byte var27 = 51;
            yield var27;
         }
         case 13 -> {
            byte var28 = 33;
            yield var28;
         }
         case 14 -> {
            byte var29 = 39;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 56;
            yield var32;
         }
         case 18 -> {
            byte var33 = 41;
            yield var33;
         }
         case 19 -> {
            byte var34 = 53;
            yield var34;
         }
         case 20 -> {
            byte var35 = 40;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 29;
            yield var37;
         }
         case 23 -> {
            byte var38 = 13;
            yield var38;
         }
         case 24 -> {
            byte var39 = 34;
            yield var39;
         }
         case 25 -> {
            byte var40 = 17;
            yield var40;
         }
         case 26 -> {
            byte var41 = 46;
            yield var41;
         }
         case 27 -> {
            byte var42 = 47;
            yield var42;
         }
         case 28 -> {
            byte var43 = 2;
            yield var43;
         }
         case 29 -> {
            byte var44 = 52;
            yield var44;
         }
         case 30 -> {
            byte var45 = 8;
            yield var45;
         }
         case 31 -> {
            byte var46 = 20;
            yield var46;
         }
         case 32 -> {
            byte var47 = 32;
            yield var47;
         }
         case 33 -> {
            byte var48 = 36;
            yield var48;
         }
         case 34 -> {
            byte var49 = 58;
            yield var49;
         }
         case 35 -> {
            byte var50 = 6;
            yield var50;
         }
         case 36 -> {
            byte var51 = 62;
            yield var51;
         }
         case 37 -> {
            byte var52 = 55;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 37;
            yield var56;
         }
         case 42 -> {
            byte var57 = 45;
            yield var57;
         }
         case 43 -> {
            byte var58 = 30;
            yield var58;
         }
         case 44 -> {
            byte var59 = 21;
            yield var59;
         }
         case 45 -> {
            byte var60 = 38;
            yield var60;
         }
         case 46 -> {
            byte var61 = 15;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 5;
            yield var64;
         }
         case 50 -> {
            byte var65 = 48;
            yield var65;
         }
         case 51 -> {
            byte var66 = 25;
            yield var66;
         }
         case 52 -> {
            byte var67 = 11;
            yield var67;
         }
         case 53 -> {
            byte var68 = 10;
            yield var68;
         }
         case 54 -> {
            byte var69 = 9;
            yield var69;
         }
         case 55 -> {
            byte var70 = 12;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 35;
            yield var72;
         }
         case 58 -> {
            byte var73 = 49;
            yield var73;
         }
         case 59 -> {
            byte var74 = 18;
            yield var74;
         }
         case 60 -> {
            byte var75 = 1;
            yield var75;
         }
         case 61 -> {
            byte var76 = 31;
            yield var76;
         }
         case 62 -> {
            byte var77 = 27;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = ">R\u000b\\Z1(R\u000e\u0006I&?\u0019\r\u0000E2.^\u001a\u0017\u000e\"5";
      p[1] = "j_\u001dUsX\u001f\u007f\u0016Zb\u0017~q\u001dQfM\n";
      p[2] = "dy[]?IovJ\u0012XKz}JYc";
      p[3] = "T\f<\u0012Ek_\u0003-]8sL\u0004$\u0014";
      p[4] = "f(h\u0012\u000f\u0019m'y]n\u0017f,}\u0007";
      p[5] = boolean.class;
      q[5] = "java/lang/Boolean";
      p[6] = "Hu\u000fmCN^u\n7PYI>\t1\\MXy\u001e&\u0017Xu";
      p[7] = "b>qv3]\u0017\u001ezy\"\u0012v\u0010qr&H\u0002";
      p[8] = "G\u0016'\u007fw\fG\u00160#{\u0003]]0={\u0016Z,de,";
      p[9] = float.class;
      q[9] = "java/lang/Float";
      p[10] = "\u0003\\b\u0000)z\u0003\\u\\%u\u0019\u0017uB%`\u001ef'\u001c}'";
      p[11] = "$(8o\t\u0003$(/3\u0005\f>c/-\u0005\u00199\u0012zy\\Z";
      p[12] = "!C05Yr!C'iU};\b'wUh<yw*\u0004";
      p[13] = "\u001c\u0005\\+%o\u001c\u0005Kw)`\u0006NKi)u\u0001?\u001c6\u007f";
      p[14] = "~uJ\u001a\u0007#\u000bUA\u0015\u0016lj[J\u001e\u00126\u001e";
      p[15] = void.class;
      q[15] = "java/lang/Void";
      p[16] = "\b \n\tfL\u001e \u000fSu[\tk\fUyO\u0018,\u001bB2])";
      p[17] = int.class;
      q[17] = "java/lang/Integer";
      p[18] = "\u0006\u0003y/~\\\u0010\u0003|umK\u0007H\u007fsa_\u0016\u000fhd*O\u000e";
      p[19] = "`\u0012\u0000U>z\u00152\u000bZ/5t<\u0000Q+o\u0000";
      p[20] = "\u000f\u001c+^C \u0019\u001c.\u0004P7\u000eW-\u0002\\#\u001f\u0010:\u0015\u00175\u000e";
      p[21] = "3{l.'\u001e8t}aD\u0013-yr\nq\u0011<jn&f\u001c";
      p[22] = "Jr+j>8\\r.0-/K9-6!;Z~:!j,h";
      p[23] = "\u0003>qtMc\b1`;%c\u0006>s";
      p[24] = "\u001a2q\u000e:[o\u0012z\u0001+\u0014\u000e\u001cq\n/Nz";
      p[25] = "C4!^\u0006'C46\u0002\n(Y\u007f6\u001c\n=^\u000edB]v";
      p[26] = "K<L\n-\nU4VEQ\u001eO9U\u0006";
      p[27] = "aY,@*q\u007fQ6\u000fWa\u007f";
      p[28] = "J\u0012v\u000f\u000bwO\u0006cf\r\u001cJ\nuV\u0007`G\u0011:\u0007`%E\u0013>\u0006\u0000wC\u00058f";
      p[29] = "Y\u0016&-w\u000eRHau\t\r\u001aP0(r`X\u0016c*j\u001c\u0007];'\t[\u0005B#,1\u001eZA!L";
      p[30] = "\u001d3\u000b\u0010\\zZp\u0002\b1i!%\u001d\u0001\u0001g](\u0006NP\u0000\u001a,\u0014\tQ8_s\u0017\u000b1";
      p[31] = "<j\r>`Ve|\u001c*QLli\u000e6=~?-UkQ\u00171nU#/Kl(\u0014Q";
      p[32] = "K\u0016r>EM\u0005B{huO\u0015\u0011nk\"\u001cEE7\u0007E\u0019M\u000edjNY\u0016B";
      p[33] = "JiEUXn\u0019fB\u0014f|\u001bo]G1+E?\u0004+W+\u0000;\u0002M\u0000n\u0017?";
      p[34] = "\u000bpp$.\u000f\u0012|}(LP\u0007@ \"vQ\n<\u007fi.\\i\"+rqUQ;'\u007f}7";
      p[35] = "Up\u001e:\u00002Pd\u000bS\u0001YUh\u001dc\f%XsR2k0^`\u00104\u0017aH4^S";
      p[36] = "}^G+dN.Q@jZW I[26et\b\u0005dZ\t+ZA5bLtYCU";
      p[37] = "\u001f\u0012g*\u0007\u001f\u001cKw-~\u001bu\u001fji\u0014\u000e\u001b\u00169nGp";
      p[38] = "d#go'k=5v{\u0016q4 dgzCbb8=)\u0014gl\u007f;dj;19z\u0016}=2{gj,+f5\u0000";
      p[39] = "j\u00170\u001b:Om\u000e+@\u0007O\u0001\u0005&\b7C}\b=Gf$:\f/\u0000g\u001c\u007fS,\u0002\u0007";
      p[40] = "|VTsG'hV@uvp\u0011W\u0014,Hez\u0005V3\u000b\u0019\u007f\tFp\nr-KY3v";
      p[41] = "VoJ\u001aYCXm\u0011\u00159X81KJ_RDn\u0000\u0012R1";
      p[42] = "'Wv>7uuQ`8WtxKWn3hs7bh*\u007f`Yk;-,\u001e";
      p[43] = "s1RxH4*'Cly.#2Qp\u0015\u001cup\r*DKp~J,\u000b5,#\fmy";
      p[44] = "zj!6el)e&w[~+l9$\f)u;aHfo)nl7?y8z";
      p[45] = "I+\nn2U\u001a~\tr\nBB%ZlTEB?^\u00104\u001c]yAnhA\u001b83";
      p[46] = "pE1-y\\7\u000685\u0014OLS'<$A0^<su&%X/1sZtN{\u007f\u0014";
      p[47] = "+X oI=wR&k%-*[>er~{\u000ej\tE-1P6w\u0019'7T";
      p[48] = "wT\u0006H: q@\\\u0007\\,{@\u001ct8-\u007fL`\u0004l1-B\u001eX1wl0";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(313351253105160L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(313351253105160L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(313351253105160L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 225;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 238;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 111;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 205;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 227;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 70;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 225;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 238;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 111;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ee_C0226",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ee" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(AutoPot var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ee_C0226;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ee_C0226", "lambda$onTick$1", "()V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((AutoPot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
