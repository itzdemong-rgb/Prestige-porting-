package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class AutoReMace extends Module {
   private FloatSetting a;
   private FloatSetting c;
   private ElapsedTimer d;
   private boolean i;
   private PlayerEntity e;
   private static final long k = 34304334458536L;
   private static final Object[] l = new Object[56];
   private static final String[] m = new String[56];

   public AutoReMace() {
      super();
      long var10001 = 37603054816154L ^ 73915230960819L;

      this.d = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 7256250071653L ^ 127840321798717L;
      var10001 = 7256250071653L ^ 132058252045425L;
      var10001 = 7256250071653L ^ 36775291061156L;
      var10001 = 7256250071653L ^ 124402517747720L;
      var10001 = 7256250071653L ^ 78680034813064L;
      var10001 = 7256250071653L ^ 80028844820524L;
      int var16 = Event.bReturningInt();
      int var102 = var16;
      AutoReMace var101 = this;
      AutoReMace var78 = var101;
      AutoReMace var77 = var101;
      if (var102 == 0) {
         boolean var103 = var77.i;
         if (!var103) {
            return;
         }

         var78 = this;
      }

      AutoReMace var84;
      int var105 = var16;
      AutoReMace var104 = var78;
      var84 = var104;
      AutoReMace var79 = var104;
      label102:
      if (var105 == 0) {
         PlayerEntity var106 = var79.e;
         if (var106 != null) {
            int var108 = var16;
            AutoReMace var107 = this;
            var84 = var107;
            AutoReMace var80 = var107;
            if (var108 != 0) {
               break label102;
            }

            AutoReMace var109 = var80;
            AutoReMace var81 = var109;
            PlayerEntity var22 = var81.e;
            boolean var110 = var22.isAlive();
            label109:
            if (var110) {
               MinecraftClient var24 = b;
               PlayerEntity var26 = this.e;
               ClientPlayerEntity var25 = var24.player;
               float var161;
               int var10000 = (var161 = var25.distanceTo((Entity)var26) - 100.0F) == 0.0F ? 0 : (var161 < 0.0F ? -1 : 1);
               int var112 = var16;
               int var111 = var10000;
               int var85 = var111;
               int var82 = var111;
               if (var112 == 0) {
                  int var113 = var82;
                  int var83 = var113;
                  int var114 = var83;
                  if (var114 > 0) {
                     break label109;
                  }

                  ElapsedTimer var142 = this.d;
                  Object[] var10004 = new Object[]{null, 139098136696340L};
                  var10004[0] = 1000.0F;
                  Object[] var30 = var10004;
                  ElapsedTimer var29 = var142;
                  var85 = (((var29.aReturningBoolean(var30)) ? 1 : 0));
               }

               label130: {
                  int var91;
                  int var116 = var16;
                  int var115 = var85;
                  var91 = var115;
                  int var86 = var115;
                  label95:
                  if (var116 == 0) {
                     int var117 = var86;
                     if (var117 != 0) {
                        MinecraftClient var32 = b;
                        ClientPlayerEntity var33 = var32.player;
                        byte var143 = ((byte)((var33.isOnGround()) ? 1 : 0));
                        int var119 = var16;
                        byte var118 = var143;
                        byte var89 = var118;
                        byte var87 = var118;
                        if (var119 == 0) {
                           byte var120 = var87;
                           byte var88 = var120;
                           byte var121 = var88;
                           if (var121 != 0) {
                              break label130;
                           }

                           ElapsedTimer var144 = this.d;
                           Object[] var156 = new Object[]{null, 139098136696340L};
                           var156[0] = 5000.0F;
                           Object[] var37 = var156;
                           ElapsedTimer var36 = var144;
                           byte var122 = ((byte)((var36.aReturningBoolean(var37)) ? 1 : 0));
                           var89 = var122;
                        }

                        int var124 = var16;
                        byte var123 = var89;
                        var91 = var123;
                        byte var90 = var123;
                        if (var124 != 0) {
                           break label95;
                        }

                        byte var125 = var90;
                        if (var125 != 0) {
                           break label130;
                        }
                     }

                     ElapsedTimer var145 = this.d;
                     Object[] var157 = new Object[]{null, 139098136696340L};
                     var157[0] = 100.0F;
                     Object[] var42 = var157;
                     ElapsedTimer var41 = var145;
                     var91 = (((var41.aReturningBoolean(var42)) ? 1 : 0));
                  }

                  int var127 = var16;
                  int var126 = var91;
                  int var93 = var126;
                  int var92 = var126;
                  if (var127 == 0) {
                     int var128 = var92;
                     if (var128 == 0) {
                        return;
                     }

                     ElapsedTimer var146 = this.d;
                     Object[] var158 = new Object[]{null, 139098136696340L};
                     var158[0] = 600.0F;
                     Object[] var45 = var158;
                     ElapsedTimer var44 = var146;
                     var93 = (((var44.aReturningBoolean(var45)) ? 1 : 0));
                  }

                  int var130 = var16;
                  int var129 = var93;
                  int var98 = var129;
                  int var94 = var129;
                  if (var130 == 0) {
                     int var131 = var94;
                     if (var131 == 0) {
                        label76: {
                           int var133 = var16;
                           AutoElytra var132 = AutoElytra.v;
                           AutoElytra var97 = var132;
                           AutoElytra var95 = var132;
                           if (var133 == 0) {
                              AutoElytra var134 = var95;
                              AutoElytra var96 = var134;
                              AutoElytra var48 = var96;
                              boolean var135 = var48.aReturningBoolean();
                              if (var135) {
                                 break label76;
                              }

                              AutoElytra var136 = AutoElytra.v;
                              var97 = var136;
                           }

                           Object[] var52 = new Object[]{126290808879192L};
                           AutoElytra var51 = var97;
                           var51.aReturningVoid(var52);
                        }

                        Object[] var53 = new Object[]{this.e, 131657085751917L};
                        Vec3d var148 = RaycastUtil.aReturningVec3d(var53);
                        FloatSetting var54 = this.c;
                        Float var55 = (Float)var54.aReturningObject();
                        double var10002 = var55.floatValue();
                        double var59 = var10002;
                        Vec3d var56 = var148;
                        Object[] var63 = new Object[]{var56.add(var57, var59, var61), 43890541083073L};
                        Rotation var141 = RotationUtil.aReturningdx_C0210(var63);
                        FloatSetting var64 = this.a;
                        Float var65 = (Float)var64.aReturningObject();
                        float var155 = var65 / 2.0F;
                        Object[] var160 = new Object[]{null, null, null, null, 71564451356397L};
                        var160[3] = 0.5F;
                        var160[2] = 0.0F;
                        var160[1] = var155;
                        var160[0] = var141;
                        Object[] var66 = var160;
                        RotationUtil.cReturningBoolean(var66);
                        return;
                     }

                     ElapsedTimer var147 = this.d;
                     Object[] var159 = new Object[]{null, 139098136696340L};
                     var159[0] = 1400.0F;
                     Object[] var68 = var159;
                     ElapsedTimer var67 = var147;
                     var98 = (((var67.aReturningBoolean(var68)) ? 1 : 0));
                  }

                  int var138 = var16;
                  int var137 = var98;
                  int var100 = var137;
                  int var99 = var137;
                  if (var138 == 0) {
                     int var139 = var99;
                     if (var139 == 0) {
                        PlayerEntity var70 = this.e;
                        Object[] var71 = new Object[]{var70.getEyePos(), 43890541083073L};
                        Rotation var17 = RotationUtil.aReturningdx_C0210(var71);
                        FloatSetting var72 = this.a;
                        Float var73 = (Float)var72.aReturningObject();
                        float var154 = var73 / 2.0F;
                        Object[] var10006 = new Object[]{null, null, null, null, 71564451356397L};
                        var10006[3] = 0.5F;
                        var10006[2] = 0.0F;
                        var10006[1] = var154;
                        var10006[0] = var17;
                        Object[] var74 = var10006;
                        RotationUtil.cReturningBoolean(var74);
                        return;
                     }

                     MinecraftClient var75 = b;
                     Object[] var76 = new Object[]{var75.player, 86106861941321L};
                     double var162;
                     var100 = (var162 = RaycastUtil.aReturningDouble(var76) - 1.0) == 0.0 ? 0 : (var162 < 0.0 ? -1 : 1);
                  }

                  int var140 = var100;
                  if (var140 < 0) {
                     this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  }

                  return;
               }

               this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
               return;
            }
         }

         var84 = this;
      }

      var84.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 43837758461476L ^ 1286655196708L;
      var10001 = 43837758461476L ^ 128125726840642L;
      int var10000 = Event.bReturningInt();
      Object[] var12 = new Object[0];
      AttackEntityEvent var11 = var1;
      Entity var9 = var11.aReturningEntity(var12);
      int var8 = var10000;
      int var25 = var8;
      Entity var24 = var9;
      Entity var23 = var24;
      Entity var22 = var24;
      if (var25 == 0) {
         boolean var26 = var22 instanceof PlayerEntity;
         if (!var26) {
            return;
         }

         Entity var27 = var9;
         var23 = var27;
      }

      PlayerEntity var10 = (PlayerEntity)var23;
      int var28 = var8;
      if (var28 == 0) {
         MinecraftClient var15 = b;
         ClientPlayerEntity var16 = var15.player;
         Object[] var17 = new Object[]{var16.getMainHandStack(), 91643301200230L};
         boolean var29 = InventoryUtil.o(var17);
         if (!var29) {
            return;
         }

         this.e = var10;
         this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
      }

      ElapsedTimer var30 = this.d;
      Object[] var21 = new Object[]{42835128969216L};
      ElapsedTimer var20 = var30;
      var20.aReturningVoid(var21);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 22;
            yield var15;
         }
         case 1 -> {
            byte var16 = 32;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 44;
            yield var18;
         }
         case 4 -> {
            byte var19 = 38;
            yield var19;
         }
         case 5 -> {
            byte var20 = 19;
            yield var20;
         }
         case 6 -> {
            byte var21 = 57;
            yield var21;
         }
         case 7 -> {
            byte var22 = 15;
            yield var22;
         }
         case 8 -> {
            byte var23 = 37;
            yield var23;
         }
         case 9 -> {
            byte var24 = 30;
            yield var24;
         }
         case 10 -> {
            byte var25 = 61;
            yield var25;
         }
         case 11 -> {
            byte var26 = 5;
            yield var26;
         }
         case 12 -> {
            byte var27 = 56;
            yield var27;
         }
         case 13 -> {
            byte var28 = 43;
            yield var28;
         }
         case 14 -> {
            byte var29 = 8;
            yield var29;
         }
         case 15 -> {
            byte var30 = 17;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 21;
            yield var32;
         }
         case 18 -> {
            byte var33 = 29;
            yield var33;
         }
         case 19 -> {
            byte var34 = 34;
            yield var34;
         }
         case 20 -> {
            byte var35 = 18;
            yield var35;
         }
         case 21 -> {
            byte var36 = 54;
            yield var36;
         }
         case 22 -> {
            byte var37 = 31;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 0;
            yield var39;
         }
         case 25 -> {
            byte var40 = 59;
            yield var40;
         }
         case 26 -> {
            byte var41 = 23;
            yield var41;
         }
         case 27 -> {
            byte var42 = 1;
            yield var42;
         }
         case 28 -> {
            byte var43 = 52;
            yield var43;
         }
         case 29 -> {
            byte var44 = 7;
            yield var44;
         }
         case 30 -> {
            byte var45 = 11;
            yield var45;
         }
         case 31 -> {
            byte var46 = 60;
            yield var46;
         }
         case 32 -> {
            byte var47 = 25;
            yield var47;
         }
         case 33 -> {
            byte var48 = 35;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 26;
            yield var50;
         }
         case 36 -> {
            byte var51 = 55;
            yield var51;
         }
         case 37 -> {
            byte var52 = 16;
            yield var52;
         }
         case 38 -> {
            byte var53 = 36;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 10;
            yield var55;
         }
         case 41 -> {
            byte var56 = 24;
            yield var56;
         }
         case 42 -> {
            byte var57 = 49;
            yield var57;
         }
         case 43 -> {
            byte var58 = 2;
            yield var58;
         }
         case 44 -> {
            byte var59 = 14;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 46;
            yield var61;
         }
         case 47 -> {
            byte var62 = 51;
            yield var62;
         }
         case 48 -> {
            byte var63 = 40;
            yield var63;
         }
         case 49 -> {
            byte var64 = 62;
            yield var64;
         }
         case 50 -> {
            byte var65 = 13;
            yield var65;
         }
         case 51 -> {
            byte var66 = 58;
            yield var66;
         }
         case 52 -> {
            byte var67 = 3;
            yield var67;
         }
         case 53 -> {
            byte var68 = 27;
            yield var68;
         }
         case 54 -> {
            byte var69 = 28;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 41;
            yield var71;
         }
         case 57 -> {
            byte var72 = 20;
            yield var72;
         }
         case 58 -> {
            byte var73 = 48;
            yield var73;
         }
         case 59 -> {
            byte var74 = 33;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 50;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 47;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u000f7xCT5\u0011?b\f)%\u0011";
      l[1] = "bGT\nh\u001aiHEE\t\u0014bCA\u001f";
      l[2] = "$m\u000b#p~2m\u000eyci%&\r\u007fo}4a\u001ah$ms";
      l[3] = "a \u0001m\b$\u0014\u0000\nb\u0019ku\u000e\u0001i\u001d1\u0001";
      l[4] = "Gr\u001ebdHGr\t>hG]9\t hRZHXx:";
      l[5] = "sg[?\u0004jsgLc\bei,L}\bpn]\u001e'\\4";
      l[6] = boolean.class;
      m[6] = "java/lang/Boolean";
      l[7] = "7z\u00042W\u000b!z\u0001hD\u001c61\u0002nH\b'v\u0015y\u0003\u001a\u0016";
      l[8] = int.class;
      m[8] = "java/lang/Integer";
      l[9] = ".&s^M\b8&v\u0004^\u001f/mu\u0002R\u000b>*b\u0015\u0019\u001c\b";
      l[10] = "w!7\"dj\u0002\u0001<-u%c\u000f7&q\u007f\u0017";
      l[11] = "bU/\u0012mXtU*H~Oc\u001e)Nr[rY>Y9L~";
      l[12] = ".]\u0016\u001f9&8]\u0013E*1/\u0016\u0010C&%>Q\u0007Tm0\u0013";
      l[13] = "Ig~SF#<Gu\\Wl]I~WS6)";
      l[14] = "\u0007k\u0005-\u0014\frK\u000e\"\u0005C\u0013E\u0005)\u0001\u0019g";
      l[15] = double.class;
      m[15] = "java/lang/Double";
      l[16] = "\u0019Bs\u0017O4\u000fBvM\\#\u0018\tuKP7\tNb\\\u001b!\u001b";
      l[17] = "tdj;Tf\u007fk{t7kjft\u001f\u0002i{uh3\u0015d";
      l[18] = " U~\tNB6U{S]U!\u001exUQA0YoB\u001aV\u0015";
      l[19] = "s6C\u001b\u001b \u0006\u0016H\u0014\nog\u0018C\u001f\u000e5\u0013";
      l[20] = void.class;
      m[20] = "java/lang/Void";
      l[21] = "\u001e:D^X\u000f\u001e:S\u0002T\u0000\u0004qS\u001cT\u0015\u0003\u0000\u0007D\u0003";
      l[22] = "&,r<,Y0,wf?N'gt`3Z6 cwxM\u0004";
      l[23] = "\u0004q6^\u0001\u0002\u0004q!\u0002\r\r\u001e:!\u001c\r\u0018\u0019KsBU\\";
      l[24] = float.class;
      m[24] = "java/lang/Float";
      l[25] = "{z\u0012\u001ecy{z\u0005Bova1\u0005\\ocf@U\u0001>";
      l[26] = "f.]3/Bm!L|GBc._";
      l[27] = "\u007fN~!EO\nnu.T\u0000k`~%PZ\u001f";
      l[28] = "uSemfDcS`7uSt\u0018c1yGe_t&2W~";
      l[29] = "\\\u0005\u0005/k\u0005)%\u000e zJH+\u0005+~\u0010<";
      l[30] = "H#JQa\u0000H#]\rm\u000fRh]\u0013m\u001aU\u0019\u000fH5P";
      l[31] = "9\f# m\u000e/\f&z~\u00198G%|r\r)\u00002k9\u001f\u0015";
      l[32] = "H^\ro;,=~\u0006`*c\\p\rk.9(";
      l[33] = "\u0015{<\u007fW.`[7pFa\u0001U<{B;u";
      l[34] = "K`~SPw\u0002apF7rr| R\u000b\u007fB\"2\u0006^\u001bIp(\u0000G&\u001ev>\u00047";
      l[35] = "2:-*K03<.c/)d?1uC\u001b4si//pqxo/D(p$4\u0012";
      l[36] = "?\u001a*IX\";\u001c,\n3p\u0002\u001fo\n\fwiJ3T\n\u001a";
      l[37] = "ljU\u001cj~2|OEWwRgD\u0013kzb9VG>\u001eb1[\u0019<x/mF\u0018W";
      l[38] = "\u0001#\u0016g\u000b\u001f\u000e%\u001d7z\u00111&HaF\u001c\u0001xZ5\u0013x\r8\u001c0G\u0013U9@kz";
      l[39] = "Q$m\u001c,nKvz\u0019\u0015p3 \u007f\u0015)s\u0003~mA|\u0017\u000f>+D(|W?w\u001f\u0015";
      l[40] = "g\u001d% \u0019p.\u001c+5~u^\u0001{!Bxn_iu\u0017\u001c7\u001ak<\u0006s3_r3~";
      l[41] = "j\u000fRKZNh\u0013XN0Vj\u0017\u0002H\\d9S^\u00100Pz\u0011\u0007B]\b|T\r/";
      l[42] = "<\u0006\u00020\nN'\u0017CM\\\u0018[\u0003\fu[N+@B';\u0011'\n\u000f|\u0003\n6Kr";
      l[43] = "\f\u001d'\u001f~mY\n%\u0000\u001e<f\u0011'^$%\u001f\u000b*\u0013xU\f\u0006jTn,\u0016\u000b'\b\u001e";
      l[44] = "\u0013\u007f\u0001ve)\u0005>\u0016q['xa\u0012$g*H?\u0000p2N\u0014x\u001c%j6\u001c?\u001b%[";
      l[45] = "w8d?\t<ays872\u001c|`9\tfw$aeR[";
      l[46] = "m\u0002<G\u00070o\u0012*\u0010`&\t\u001b4\u0016\\+9E&B\tOf@8\u0010\u0010?h\u0019\"\u0014`";
      l[47] = "<t(^qt>h\"[\u001bl<lx]w^k,(\u0000+\tmh#\u0004&b5i\u007f_\u001b";
      l[48] = "x&4L\u0000o*'4W}d\u001641\u000e\u001d5fw\u007f\\}";
      l[49] = "lwTX\u001fonk^]uwlo\u0004[\u0019E<,_\ru}<p\rL\u0005sej\t<\u0015+l-\u0015P\n,;~d";
      l[50] = "Vr)v\u0003eWt*?g|\u0000w5)\u000bNV0hq^\u0019Va2s\u0017$\u0001g$wg";
      l[51] = "Z\u0000P\u000e{tX\u0005IO\u001c|[\u0014P\u0018K+\u0005C\btqv\n\u001d^\tsj\u0000\u0018";
      l[52] = "QWO3\u000fQ[\u0011Pm5XT\u000bVwk_T\u0011R\u000bU\u000f]RNgJ\b\n\u0001?";
      l[53] = "1._1ME>(Ta<K\u0001+\u00017\u0000F1u\u0013cU\"m2\u000f6\rZeu\b6<";
      l[54] = "ko\"\u0007ep<i4\u0003\u0015(=y%]y\u001ai=~\u0003\u0015$-z7Bz hc8:|0/w=Uxu6xESh2\"}*W-+-\u0005~Prp 8)VdtP";
      l[55] = "*?Jq;@t)P(\u0006K\u00142[~:D$lI*o (,\u000f/;Kp-St\u0006";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(75779176148363L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(75779176148363L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(75779176148363L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 82;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 114;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 248;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 228;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 163;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 115;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 82;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 114;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 248;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ef_C0228",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ef" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
