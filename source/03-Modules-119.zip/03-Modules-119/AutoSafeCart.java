package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.util.ExplosionDamageUtil;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.modules.state.SafeCartPlacementTime;
import dev.zprestige.prestige.client.modules.state.SafeCartPlacementTarget;
import dev.zprestige.prestige.client.modules.state.SafeCartDetonationTarget;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class AutoSafeCart extends Module implements RotationSource {
   private ModeSetting a;
   private ModeSetting c;
   private FloatSetting d;
   private FloatSetting e;
   private MultiModeSetting f;
   private IntSetting g;
   private MinMaxSetting h;
   private ModeSetting i;
   private FloatSetting j;
   private FloatSetting k;
   private static final String[] l;
   private Map m;
   private List n;
   private BlockPos o;
   private long p;
   private boolean q;
   private ElapsedTimer r;
   private static final long s = 125758565364168L;
   private static final String[] t;
   private static final String[] u;
   private static final Map v = new HashMap(13);
   private static final long[] w;
   private static final Integer[] x;
   private static final Map y;
   private static final long[] z;
   private static final Long[] A;
   private static final Map B;
   private static final Object[] C = new Object[251];
   private static final String[] D = new String[251];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;

   public AutoSafeCart() {
      super();
      long var10001 = 13942817618490L ^ 120554616835347L;
      var10001 = 13942817618490L ^ 21820615051501L;

      this.m = new HashMap();
      this.n = new ArrayList();
      this.r = new ElapsedTimer(106698256430889L);
      FloatSetting var10000 = this.k;
      Object[] var8 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var7 = var10000;
      var7.aReturningFloatSetting(var8);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      Map var4 = this.m;
      var4.clear();
      List var5 = this.n;
      var5.clear();
      this.o = null;
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 115036890363837L ^ 68634836891295L;
      int var10000 = Event.bReturningInt();
      Object[] var13 = new Object[0];
      PacketSendEvent var12 = var1;
      Packet var8 = var12.aReturningVoid(var13);
      int var6 = var10000;
      int var36 = var6;
      Packet var35 = var8;
      Packet var33 = var35;
      Packet var32 = var35;
      if (var36 == 0) {
         boolean var37 = var32 instanceof PlayerInteractBlockC2SPacket;
         if (!var37) {
            return;
         }

         Packet var38 = var8;
         var33 = var38;
      }

      PlayerInteractBlockC2SPacket var7 = (PlayerInteractBlockC2SPacket)var33;
      PlayerInteractBlockC2SPacket var16 = var7;
      Hand var44 = var16.getHand();
      Hand var18 = Hand.MAIN_HAND;
      Hand var17 = var44;
      boolean var39 = var17.equals(var18);
      ItemStack var34;
      if (var39) {
         MinecraftClient var19 = b;
         ClientPlayerEntity var20 = var19.player;
         ItemStack var40 = var20.getMainHandStack();
         var34 = var40;
      } else {
         MinecraftClient var22 = b;
         ClientPlayerEntity var23 = var22.player;
         var34 = var23.getOffHandStack();
      }

      ItemStack var43 = var34;
      ItemStack var24 = var43;
      Item var45 = var24.getItem();
      Item var42 = Items.TNT_MINECART;
      Item var41 = var45;
      if (var41 == var42) {
         PlayerInteractBlockC2SPacket var25 = var7;
         BlockHitResult var9 = var25.getBlockHitResult();
         long var10 = System.currentTimeMillis();
         List var46 = this.n;
         BlockHitResult var26 = var9;
         SafeCartPlacementTime var28 = new SafeCartPlacementTime(var26.getBlockPos(), var10);
         List var27 = var46;
         var27.add(var28);
         List var47 = this.n;
         Object[] var29 = new Object[]{var9, 95435648532770L};
         SafeCartPlacementTime var31 = new SafeCartPlacementTime(BlockUtil.aReturningBlockPos(var29), var10);
         List var30 = var47;
         var30.add(var31);
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      net.minecraft.util.math.BlockPos var197;

      long var10001 = 68289704740744L ^ 118994961047550L;
      var10001 = 68289704740744L ^ 15458766621564L;
      var10001 = 68289704740744L ^ 36381098202992L;
      var10001 = 68289704740744L ^ 115275722245802L;
      var10001 = 68289704740744L ^ 119406072866809L;
      var10001 = 68289704740744L ^ 85991436744442L;
      var10001 = 68289704740744L ^ 113611181093142L;
      var10001 = 68289704740744L ^ 107304620426601L;
      var10001 = 68289704740744L ^ 14586541270661L;
      var10001 = 68289704740744L ^ 121825859870504L;
      var10001 = 68289704740744L ^ 128850883318349L;
      var10001 = 68289704740744L ^ 80313549266419L;
      int var10000 = Event.bReturningInt();
      Object[] var39 = new Object[]{105055476728545L};
      AutoSafeCart var38 = this;
      var38.kReturningVoid(var39);
      int var28 = var10000;
      ModeSetting var40 = this.a;
      String var198 = (String)var40.aReturningObject();
      String var42 = "Legit";
      String var41 = var198;
      boolean var141 = var41.equals(var42);
      if (var141) {
         int var143 = var28;
         MinecraftClient var142 = b;
         MinecraftClient var115 = var142;
         MinecraftClient var113 = var142;
         if (var143 == 0) {
            MinecraftClient var144 = var113;
            MinecraftClient var114 = var144;
            MinecraftClient var44 = var114;
            ClientPlayerEntity var145 = var44.player;
            if (var145 == null) {
               return;
            }

            MinecraftClient var146 = b;
            var115 = var146;
         }

         int var148 = var28;
         MinecraftClient var147 = var115;
         MinecraftClient var117 = var147;
         MinecraftClient var116 = var147;
         if (var148 == 0) {
            MinecraftClient var47 = var116;
            ClientWorld var149 = var47.world;
            if (var149 == null) {
               return;
            }

            var117 = b;
         }

         MinecraftClient var50 = var117;
         ClientPlayerEntity var51 = var50.player;
         int var199 = (((var51.isUsingItem()) ? 1 : 0));
         int var151 = var28;
         boolean var150 = dev.prestige.recovery.SourceSupport.asBoolean(var199);
         boolean var119 = var150;
         boolean var118 = var150;
         if (var151 == 0) {
            boolean var152 = var118;
            if (var152) {
               return;
            }

            RotationManager var200 = Prestige.o;
            Object[] var54 = new Object[0];
            RotationManager var53 = var200;
            boolean var153 = var53.fReturningBoolean(var54);
            var119 = var153;
         }

         boolean var154 = var119;
         if (!var154) {
            Object[] var57 = new Object[]{88884961466528L};
            AutoSafeCart var56 = this;
            Block var29 = var56.aReturningBlock(var57);
            Block var155 = var29;
            if (var155 != null) {
               Object[] var60 = new Object[]{34142003171576L};
               AutoSafeCart var59 = this;
               List var30 = var59.cReturningList(var60);
               Object[] var62 = new Object[]{var30, 90307122550902L};
               AutoSafeCart var61 = this;
               var61.jReturningVoid(var62);
               List var63 = var30;
               var199 = (((var63.isEmpty()) ? 1 : 0));
               int var157 = var28;
               boolean var156 = ((((int)(var199) & 1) != 0));
               boolean var121 = var156;
               boolean var120 = var156;
               if (var157 == 0) {
                  boolean var158 = var120;
                  if (var158) {
                     return;
                  }

                  ElapsedTimer var202 = this.r;
                  Object[] var66 = new Object[]{this.h, 130913203968635L};
                  ElapsedTimer var65 = var202;
                  boolean var159 = var65.bReturningBoolean(var66);
                  var121 = var159;
               }

               boolean var160 = var121;
               if (var160) {
                  MinecraftClient var68 = b;
                  HitResult var32 = var68.crosshairTarget;
                  int var162 = var28;
                  HitResult var161 = var32;
                  HitResult var123 = var161;
                  HitResult var122 = var161;
                  if (var162 == 0) {
                     boolean var163 = var122 instanceof BlockHitResult;
                     if (!var163) {
                        return;
                     }

                     HitResult var164 = var32;
                     var123 = var164;
                  }

                  BlockHitResult var31 = (BlockHitResult)var123;
                  int var165 = var28;
                  if (var165 == 0) {
                     BlockPos var129;
                     BlockHitResult var72 = var31;
                     BlockPos var203 = var72.getBlockPos();
                     int var167 = var28;
                     BlockPos var166 = var203;
                     BlockPos var127 = var166;
                     BlockPos var124 = var166;
                     label121:
                     if (var167 == 0) {
                        Object[] var73 = new Object[]{var124, Blocks.FIRE, 90720632922225L};
                        boolean var168 = BlockUtil.bReturningBoolean(var73);
                        label118:
                        if (!var168) {
                           int var170 = var28;
                           BlockHitResult var169 = var31;
                           BlockHitResult var128 = var169;
                           BlockHitResult var125 = var169;
                           if (var170 == 0) {
                              BlockHitResult var171 = var125;
                              BlockHitResult var126 = var171;
                              BlockHitResult var76 = var126;
                              BlockPos var204 = var76.getBlockPos();
                              Object[] var77 = new Object[]{82650215142853L};
                              Object[] var78 = new Object[]{var204, BlockUtil.aReturningBlock(var77), 90720632922225L};
                              boolean var172 = BlockUtil.bReturningBoolean(var78);
                              if (var172) {
                                 break label118;
                              }

                              var128 = var31;
                           }

                           Object[] var82 = new Object[]{var128, 95435648532770L};
                           var129 = BlockUtil.aReturningBlockPos(var82);
                           break label121;
                        }

                        BlockHitResult var80 = var31;
                        BlockPos var173 = var80.getBlockPos();
                        var129 = var173;
                     } else {
                        BlockPos var174 = var127;
                        var129 = var174;
                     }

                     BlockPos var134;
                     label162: {
                        var197 = var129;
                        MinecraftClient var83 = b;
                        BlockPos var85 = var197;
                        ClientWorld var84 = var83.world;
                        BlockState var86 = var84.getBlockState(var85);
                        var199 = (((var86.isReplaceable()) ? 1 : 0));
                        int var176 = var28;
                        boolean var175 = ((((int)(var199) & 1) != 0));
                        boolean var133 = var175;
                        boolean var130 = var175;
                        if (var176 == 0) {
                           boolean var177 = var130;
                           if (!var177) {
                              return;
                           }

                           int var179 = var28;
                           BlockPos var178 = var197;
                           var134 = var178;
                           BlockPos var131 = var178;
                           if (var179 != 0) {
                              break label162;
                           }

                           BlockPos var180 = var131;
                           BlockPos var132 = var180;
                           Object[] var89 = new Object[]{var132, 56486840213773L};
                           boolean var181 = BlockUtil.gReturningBoolean(var89);
                           var133 = var181;
                        }

                        boolean var182 = var133;
                        if (var182) {
                           return;
                        }

                        var134 = this.o;
                     }

                     BlockPos var138;
                     int var184 = var28;
                     BlockPos var183 = var134;
                     var138 = var183;
                     BlockPos var135 = var183;
                     label97:
                     if (var184 == 0) {
                        BlockPos var185 = var135;
                        if (var185 != null) {
                           int var187 = var28;
                           BlockPos var186 = this.o;
                           var138 = var186;
                           BlockPos var136 = var186;
                           if (var187 != 0) {
                              break label97;
                           }

                           BlockPos var188 = var136;
                           BlockPos var137 = var188;
                           BlockPos var94 = var197;
                           BlockPos var93 = var137;
                           boolean var189 = var93.equals(var94);
                           if (var189) {
                              return;
                           }
                        }

                        Object[] var98 = new Object[]{52865307299060L};
                        AutoSafeCart var97 = this;
                        var138 = var97.aReturningBlockPos(var98);
                     }

                     BlockPos var33 = var138;
                     List var99 = var30;
                     Iterator var34 = var99.iterator();

                     while (true) {
                        Iterator var100 = var34;
                        boolean var190 = var100.hasNext();
                        if (!var190) {
                           break;
                        }

                        Iterator var101 = var34;
                        SafeCartDetonationTarget var35 = (SafeCartDetonationTarget)var101.next();
                        ExplosionDamageUtil var206 = Prestige.f;
                        MinecraftClient var102 = b;
                        ClientPlayerEntity var219 = var102.player;
                        SafeCartDetonationTarget var103 = var35;
                        Vec3d var10002 = var103.ab();
                        SafeCartDetonationTarget var104 = var35;
                        double var10003 = var104.ac();
                        Block var105 = var29;
                        Object[] var10009 = new Object[]{null, null, null, var33, var197, var105.getDefaultState(), 123345531941234L};
                        var10009[2] = var10003;
                        var10009[1] = var10002;
                        var10009[0] = var219;
                        Object[] var107 = var10009;
                        ExplosionDamageUtil var106 = var206;
                        double var36 = var106.hReturningVoid(var107);
                        SafeCartDetonationTarget var108 = var35;
                        double var220;
                        var199 = (var220 = var36 - (var108.ad() - 0.5)) == 0.0 ? 0 : (var220 < 0.0 ? -1 : 1);
                        int var192 = var28;
                        int var191 = var199;
                        int var140 = var191;
                        int var139 = var191;
                        if (var192 == 0) {
                           int var193 = var139;
                           if (var193 >= 0) {
                              int var194 = var28;
                              if (var194 == 0) {
                                 continue;
                              }
                           }

                           Object[] var112 = new Object[]{var29, new SafeCartPlacementTarget(var197, var31, var36), var35, 98199150835358L};
                           AutoSafeCart var111 = this;
                           var140 = (((var111.aReturningBoolean(var112)) ? 1 : 0));
                        }

                        int var195 = var140;
                        if (var195 != 0) {
                           return;
                        }

                        int var196 = var28;
                        if (var196 != 0) {
                           break;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 27193197287472L;
      long var6 = var2 ^ 121299581480982L;
      long var8 = var2 ^ 39021060978840L;
      long var10 = var2 ^ 111324545834750L;
      long var12 = var2 ^ 77379818547405L;
      long var14 = var2 ^ 119465137090752L;
      long var16 = var2 ^ 59641449638428L;
      long var18 = var2 ^ 82878281429531L;
      int var20 = Event.cReturningInt();
      ModeSetting var29 = this.a;
      String var10000 = (String)var29.aReturningObject();
      short var10001 = 4217;
      long var10002 = 7624072586800750094L ^ var2;
      String var31 = "Silent";
      String var30 = var10000;
      boolean var112 = var30.equals(var31);
      if (var112) {
         int var114 = var20;
         MinecraftClient var113 = b;
         MinecraftClient var97 = var113;
         MinecraftClient var95 = var113;
         if (var114 != 0) {
            MinecraftClient var115 = var95;
            MinecraftClient var96 = var115;
            MinecraftClient var33 = var96;
            ClientPlayerEntity var116 = var33.player;
            if (var116 == null) {
               return null;
            }

            MinecraftClient var117 = b;
            var97 = var117;
         }

         int var119 = var20;
         MinecraftClient var118 = var97;
         MinecraftClient var99 = var118;
         MinecraftClient var98 = var118;
         if (var119 != 0) {
            MinecraftClient var36 = var98;
            ClientWorld var120 = var36.world;
            if (var120 == null) {
               return null;
            }

            var99 = b;
         }

         MinecraftClient var39 = var99;
         ClientPlayerEntity var40 = var39.player;
         boolean var152 = var40.isUsingItem();
         int var122 = var20;
         boolean var121 = var152;
         boolean var101 = var121;
         boolean var100 = var121;
         if (var122 != 0) {
            boolean var123 = var100;
            if (var123) {
               return null;
            }

            RotationManager var153 = Prestige.o;
            Object[] var43 = new Object[0];
            RotationManager var42 = var153;
            boolean var124 = var42.fReturningBoolean(var43);
            var101 = var124;
         }

         boolean var125 = var101;
         if (!var125) {
            Object[] var47 = new Object[]{var14};
            AutoSafeCart var46 = this;
            Block var21 = var46.aReturningBlock(var47);
            Block var126 = var21;
            if (var126 == null) {
               return null;
            }

            Object[] var50 = new Object[]{var8};
            AutoSafeCart var49 = this;
            List var22 = var49.cReturningList(var50);
            Object[] var52 = new Object[]{var22, var6};
            AutoSafeCart var51 = this;
            var51.jReturningVoid(var52);
            List var53 = var22;
            boolean var154 = var53.isEmpty();
            int var128 = var20;
            boolean var127 = var154;
            boolean var103 = var127;
            boolean var102 = var127;
            if (var128 != 0) {
               boolean var129 = var102;
               if (var129) {
                  return null;
               }

               ElapsedTimer var155 = this.r;
               Object[] var56 = new Object[]{this.h, var18};
               ElapsedTimer var55 = var155;
               boolean var130 = var55.bReturningBoolean(var56);
               var103 = var130;
            }

            boolean var131 = var103;
            if (var131) {
               List var59 = var22;
               Iterator var23 = var59.iterator();

               while (true) {
                  Iterator var60 = var23;
                  boolean var132 = var60.hasNext();
                  if (!var132) {
                     break;
                  }

                  Iterator var61 = var23;
                  SafeCartDetonationTarget var24 = (SafeCartDetonationTarget)var61.next();
                  Object[] var63 = new Object[]{var24, var21, var4};
                  AutoSafeCart var62 = this;
                  SafeCartPlacementTarget var25 = var62.aReturninggf_C0336(var63);
                  SafeCartPlacementTarget var133 = var25;
                  if (var133 == null) {
                     int var134 = var20;
                     if (var134 != 0) {
                        continue;
                     }
                  }

                  RotationManager var156 = Prestige.o;
                  SafeCartPlacementTarget var65 = var25;
                  BlockHitResult var66 = var65.y();
                  Object[] var68 = new Object[]{var66.getPos(), var12};
                  RotationManager var67 = var156;
                  Rotation var26 = var67.aReturningdx_C0210(var68);
                  Object[] var70 = new Object[0];
                  Rotation var69 = var26;
                  float var157 = var69.aReturningFloat(var70);
                  MinecraftClient var71 = b;
                  ClientPlayerEntity var72 = var71.player;
                  float var73 = var157 - var72.getYaw();
                  float var27 = MathHelper.wrapDegrees(var73);
                  FloatSetting var74 = this.k;
                  Float var75 = (Float)var74.aReturningObject();
                  float var161;
                  int var158 = (var161 = var27 - var75) == 0.0F ? 0 : (var161 < 0.0F ? -1 : 1);
                  int var136 = var20;
                  int var135 = var158;
                  int var105 = var135;
                  int var104 = var135;
                  if (var136 != 0) {
                     int var137 = var104;
                     if (var137 > 0) {
                        continue;
                     }

                     FloatSetting var77 = this.k;
                     Float var78 = (Float)var77.aReturningObject();
                     float var162;
                     var105 = (var162 = var27 - -var78) == 0.0F ? 0 : (var162 < 0.0F ? -1 : 1);
                  }

                  Rotation var109;
                  label122: {
                     int var139 = var20;
                     int var138 = var105;
                     int var108 = var138;
                     int var106 = var138;
                     if (var139 != 0) {
                        int var140 = var106;
                        if (var140 < 0) {
                           int var141 = var20;
                           if (var141 != 0) {
                              continue;
                           }
                        }

                        int var143 = var20;
                        Rotation var142 = var26;
                        var109 = var142;
                        Rotation var107 = var142;
                        if (var143 == 0) {
                           break label122;
                        }

                        Object[] var82 = new Object[0];
                        Rotation var81 = var107;
                        byte var144 = ((byte)((var81.aReturningBoolean(var82)) ? 1 : 0));
                        var108 = var144;
                     }

                     int var145 = var108;
                     if (var145 != 0) {
                        return var26;
                     }

                     var109 = var26;
                  }

                  Object[] var85 = new Object[]{var109, var16};
                  HitResult var28 = RotationUtil.aReturningHitResult(var85);
                  HitResult var86 = var28;
                  Vec3d var159 = var86.getPos();
                  SafeCartPlacementTarget var87 = var25;
                  BlockHitResult var88 = var87.y();
                  Vec3d var90 = var88.getPos();
                  Vec3d var89 = var159;
                  double var163;
                  int var160 = (var163 = var89.distanceTo(var90) - 0.5) == 0.0 ? 0 : (var163 < 0.0 ? -1 : 1);
                  int var147 = var20;
                  int var146 = var160;
                  int var111 = var146;
                  int var110 = var146;
                  if (var147 != 0) {
                     int var148 = var110;
                     if (var148 > 0) {
                        int var149 = var20;
                        if (var149 != 0) {
                           continue;
                        }
                     }

                     Object[] var94 = new Object[]{var21, var25, var24, var10};
                     AutoSafeCart var93 = this;
                     var111 = (((var93.aReturningBoolean(var94)) ? 1 : 0));
                  }

                  int var150 = var111;
                  if (var150 != 0) {
                     return var26;
                  }

                  int var151 = var20;
                  if (var151 == 0) {
                     break;
                  }
               }

               return null;
            } else {
               return null;
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private List cReturningList(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 125758565364168L ^ var2;
      long var4 = var2 ^ 44078527694583L;
      long var6 = var2 ^ 102776801193412L;
      long var8 = var2 ^ 81570009636579L;
      long var10 = var2 ^ 32176317435970L;
      long var12 = var2 ^ 29484727219037L;
      ArrayList var15 = new ArrayList();
      Object[] var26 = new Object[]{var8};
      Vec3d var16 = RaycastUtil.bReturningVec3d(var26);
      Object[] var28 = new Object[]{var6};
      AutoSafeCart var27 = this;
      BlockPos var17 = var27.aReturningBlockPos(var28);
      int var10000 = Event.bReturningInt();
      MinecraftClient var29 = b;
      ClientWorld var30 = var29.world;
      Iterable var31 = var30.getEntities();
      Iterator var18 = var31.iterator();
      int var14 = var10000;

      while (true) {
         Iterator var32 = var18;
         boolean var88 = var32.hasNext();
         if (var88) {
            Iterator var33 = var18;
            Entity var19 = (Entity)var33.next();
            int var89 = var14;
            if (var89 != 0) {
               break;
            }

            int var91 = var14;
            Entity var90 = var19;
            Entity var79 = var90;
            Entity var77 = var90;
            if (var91 == 0) {
               Entity var92 = var77;
               Entity var78 = var92;
               boolean var93 = var78 instanceof TntMinecartEntity;
               if (!var93) {
                  continue;
               }

               var79 = var19;
            }

            TntMinecartEntity var20 = (TntMinecartEntity)var79;
            Object[] var36 = new Object[]{var20, var12};
            Vec3d var21 = RaycastUtil.aReturningVec3d(var36);
            Vec3d var38 = var21;
            Vec3d var37 = var16;
            double var113 = var37.distanceTo(var38);
            FloatSetting var39 = this.j;
            Float var40 = (Float)var39.aReturningObject();
            double var120;
            var10000 = (var120 = var113 - var40.floatValue()) == 0.0 ? 0 : (var120 < 0.0 ? -1 : 1);
            int var95 = var14;
            int var94 = var10000;
            int var81 = var94;
            int var80 = var94;
            if (var95 == 0) {
               int var96 = var80;
               if (var96 > 0) {
                  continue;
               }

               Object[] var43 = new Object[]{var20, var4};
               AutoSafeCart var42 = this;
               var81 = (((var42.dReturningBoolean(var43)) ? 1 : 0));
            }

            int var98 = var14;
            int var97 = var81;
            int var83 = var97;
            int var82 = var97;
            if (var98 == 0) {
               int var99 = var82;
               if (var99 == 0) {
                  int var100 = var14;
                  if (var100 == 0) {
                     continue;
                  }
               }

               Map var115 = this.m;
               TntMinecartEntity var46 = var20;
               UUID var10001 = var46.getUuid();
               Integer var50 = 0;
               UUID var49 = var10001;
               Map var48 = var115;
               Integer var51 = ((java.lang.Integer)(Object)(var48.getOrDefault(var49, var50)));
               var83 = var51;
            }

            IntSetting var52 = this.g;
            Integer var53 = (Integer)var52.aReturningObject();
            int var102 = var53;
            int var101 = var83;
            if (var101 >= var102) {
               int var103 = var14;
               if (var103 == 0) {
                  continue;
               }
            }

            TntMinecartEntity var55 = var20;
            Vec3d var56 = var55.getVelocity();
            double var116 = var56.x;
            TntMinecartEntity var57 = var20;
            Vec3d var58 = var57.getVelocity();
            double var61 = var58.z;
            double var59 = var116;
            double var22 = Math.hypot(var59, var61);
            ExplosionDamageUtil var117 = Prestige.f;
            MinecraftClient var63 = b;
            ClientPlayerEntity var119 = var63.player;
            Object[] var10009 = new Object[]{null, null, null, var17, null, null, var10};
            var10009[2] = var22;
            var10009[1] = var21;
            var10009[0] = var119;
            Object[] var65 = var10009;
            ExplosionDamageUtil var64 = var117;
            double var24 = var64.hReturningVoid(var65);
            FloatSetting var66 = this.d;
            Float var67 = (Float)var66.aReturningObject();
            double var121;
            var10000 = (var121 = var24 - var67.floatValue()) == 0.0 ? 0 : (var121 < 0.0 ? -1 : 1);
            int var105 = var14;
            int var104 = var10000;
            int var85 = var104;
            int var84 = var104;
            if (var105 == 0) {
               int var106 = var84;
               if (var106 < 0) {
                  continue;
               }

               FloatSetting var69 = this.e;
               Float var70 = (Float)var69.aReturningObject();
               double var122;
               var85 = (var122 = var24 - var70.floatValue()) == 0.0 ? 0 : (var122 < 0.0 ? -1 : 1);
            }

            int var108 = var14;
            int var107 = var85;
            int var86 = var107;
            if (var108 == 0) {
               int var109 = var86;
               if (var109 <= 0) {
                  int var110 = var14;
                  if (var110 == 0) {
                     continue;
                  }
               }

               SafeCartDetonationTarget var74 = new SafeCartDetonationTarget(var20, var21, var22, var24);
               ArrayList var73 = var15;
               boolean var87 = var73.add(var74);
            }

            int var111 = var14;
            if (var111 == 0) {
               continue;
            }
         }

         Comparator var76 = invokeBinding2();
         ArrayList var75 = var15;
         var75.sort(var76);
         break;
      }

      return var15;
   }

   private List bReturningList(Object[] var1) {
      TntMinecartEntity var2 = (TntMinecartEntity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 125758565364168L ^ var3;
      LinkedHashSet var6 = new LinkedHashSet();
      MinecraftClient var16 = b;
      ClientPlayerEntity var17 = var16.player;
      BlockPos var7 = var17.getBlockPos();
      int var61 = Event.cReturningInt();
      TntMinecartEntity var18 = var2;
      BlockPos var8 = var18.getBlockPos();
      BlockPos[] var10001 = new BlockPos[]{var7, null, null, null};
      BlockPos var19 = var7;
      var10001[1] = var19.up();
      var10001[2] = var8;
      BlockPos var20 = var8;
      var10001[3] = var20.up();
      BlockPos[] var9 = var10001;
      BlockPos[] var10 = var9;
      int var5 = var61;
      int var11 = var10.length;
      while (true) {
         int var31 = var12;

         label66:
         while (true) {
            int var40 = var11;
            int var39 = var31;
            if (var39 >= var40) {
               return new ArrayList(var6);
            }

            BlockPos var13 = var10[var12];
            int var14 = -1;

            label63:
            while (true) {
               int var32 = var14;

               label61:
               while (true) {
                  byte var42 = 1;
                  int var41 = var32;
                  if (var41 > var42) {
                     break label63;
                  }

                  int var44 = var5;
                  // var31 = var43;
                  byte var33 = var43;
                  if (var44 == 0) {
                     continue label66;
                  }

                  int var15 = var33;

                  int var58;
                  do {
                     byte var46 = 1;
                     int var45 = var15;
                     if (var45 > var46) {
                        break;
                     }

                     int var48 = var5;
                     int var47 = var14;
                     var32 = var47;
                     int var34 = var47;
                     if (var48 == 0) {
                        continue label61;
                     }

                     int var50 = var5;
                     int var49 = var34;
                     int var35 = var49;
                     label54:
                     if (var50 != 0) {
                        int var51 = var35;
                        if (var51 == 0) {
                           int var53 = var5;
                           int var52 = var15;
                           int var36 = var52;
                           if (var53 == 0) {
                              break label54;
                           }

                           int var54 = var36;
                           int var37 = var54;
                           int var55 = var37;
                           if (var55 == 0) {
                              int var56 = var5;
                              if (var56 != 0) {
                                 break label54;
                              }
                           }
                        }

                        byte var10003 = 0;
                        int var28 = var15;
                        int var26 = var14;
                        BlockPos var25 = var13;
                        BlockPos var30 = var25.add(var26, 0, var28);
                        LinkedHashSet var29 = var6;
                        boolean var57 = var29.add(var30);
                     }

                     var15++;
                     var58 = var5;
                  } while (var58 != 0);

                  var14++;
                  int var59 = var5;
                  if (var59 == 0) {
                     break label63;
                  }
                  break;
               }
            }

            var12++;
            int var60 = var5;
            if (var60 == 0) {
               return new ArrayList(var6);
            }
            break;
         }
      }
   }

   private SafeCartPlacementTarget aReturninggf_C0336(Object[] var1) {
      SafeCartDetonationTarget var5 = (SafeCartDetonationTarget)var1[0];
      Block var2 = (Block)var1[1];
      long var3 = (Long)var1[2];
      var3 = 125758565364168L ^ var3;
      long var6 = var3 ^ 112973513149804L;
      long var8 = var3 ^ 117135939146632L;
      long var10 = var3 ^ 42354910146794L;
      long var12 = var3 ^ 76251676604143L;
      int var10000 = Event.cReturningInt();
      Object[] var23 = new Object[]{var6};
      AutoSafeCart var22 = this;
      BlockPos var15 = var22.aReturningBlockPos(var23);
      int var14 = var10000;
      SafeCartPlacementTarget var16 = null;
      SafeCartDetonationTarget var24 = var5;
      Object[] var26 = new Object[]{var24.aa(), var8};
      AutoSafeCart var25 = this;
      List var27 = var25.bReturningList(var26);
      Iterator var17 = var27.iterator();

      while (true) {
         Iterator var28 = var17;
         boolean var45 = var28.hasNext();
         if (!var45) {
            break;
         }

         Iterator var29 = var17;
         BlockPos var18 = (BlockPos)var29.next();
         Object[] var31 = new Object[]{var18, var12};
         AutoSafeCart var30 = this;
         BlockHitResult var19 = var30.aReturningBlockHitResult(var31);
         BlockHitResult var46 = var19;
         if (var46 == null) {
            int var47 = var14;
            if (var47 != 0) {
               continue;
            }
         }

         ExplosionDamageUtil var57 = Prestige.f;
         MinecraftClient var33 = b;
         ClientPlayerEntity var10001 = var33.player;
         SafeCartDetonationTarget var34 = var5;
         Vec3d var10002 = var34.ab();
         SafeCartDetonationTarget var35 = var5;
         double var10003 = var35.ac();
         Block var36 = var2;
         Object[] var10009 = new Object[]{null, null, null, var15, var18, var36.getDefaultState(), var10};
         var10009[2] = var10003;
         var10009[1] = var10002;
         var10009[0] = var10001;
         Object[] var38 = var10009;
         ExplosionDamageUtil var37 = var57;
         double var20 = var37.hReturningVoid(var38);
         SafeCartDetonationTarget var39 = var5;
         double var58;
         int var48 = (var58 = var20 - (var39.ad() - 0.5)) == 0.0 ? 0 : (var58 < 0.0 ? -1 : 1);
         if (var48 >= 0) {
            int var49 = var14;
            if (var49 != 0) {
               continue;
            }
         }

         label32: {
            int var51 = var14;
            SafeCartPlacementTarget var50 = var16;
            SafeCartPlacementTarget var44 = var50;
            SafeCartPlacementTarget var43 = var50;
            if (var51 != 0) {
               SafeCartPlacementTarget var52 = var43;
               if (var52 != null) {
                  SafeCartPlacementTarget var42 = var16;
                  double var59;
                  int var53 = (var59 = var20 - var42.z()) == 0.0 ? 0 : (var59 < 0.0 ? -1 : 1);
                  if (var53 >= 0) {
                     break label32;
                  }
               }

               SafeCartPlacementTarget var54 = new SafeCartPlacementTarget(var18, var19, var20);
               var44 = var54;
            }

            var16 = var44;
         }

         int var55 = var14;
         if (var55 == 0) {
            break;
         }
      }

      return var16;
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      BlockPos var4;
      long var5;
      int var9;
      BlockPos var73;
      long var107;
      label93: {
         var4 = (BlockPos)var1[0];
         long var2 = (Long)var1[1];
         var107 = 125758565364168L ^ var2;
         var5 = var107 ^ 11351623060099L;
         long var7 = var107 ^ 91040644917170L;
         var9 = Event.cReturningInt();
         MinecraftClient var21 = b;
         BlockPos var23 = var4;
         ClientWorld var22 = var21.world;
         BlockState var24 = var22.getBlockState(var23);
         boolean var10000 = var24.isReplaceable();
         int var80 = var9;
         boolean var79 = var10000;
         boolean var72 = var79;
         boolean var69 = var79;
         if (var80 != 0) {
            boolean var81 = var69;
            if (!var81) {
               return null;
            }

            int var83 = var9;
            BlockPos var82 = var4;
            var73 = var82;
            BlockPos var70 = var82;
            if (var83 == 0) {
               break label93;
            }

            BlockPos var84 = var70;
            BlockPos var71 = var84;
            Object[] var27 = new Object[]{var71, var7};
            boolean var85 = BlockUtil.gReturningBoolean(var27);
            var72 = var85;
         }

         boolean var86 = var72;
         if (var86) {
            return null;
         }

         var73 = this.o;
      }

      label78: {
         int var88 = var9;
         BlockPos var87 = var73;
         BlockPos var75 = var87;
         BlockPos var74 = var87;
         if (var88 != 0) {
            BlockPos var89 = var74;
            if (var89 == null) {
               break label78;
            }

            BlockPos var90 = this.o;
            var75 = var90;
         }

         BlockPos var33 = var4;
         BlockPos var32 = var75;
         boolean var91 = var32.equals(var33);
         if (var91) {
            return null;
         }
      }

      MinecraftClient var35 = b;
      ClientPlayerEntity var36 = var35.player;
      Vec3d var10 = var36.getEyePos();
      short var108 = 24981;
      Object[] var37 = new Object[]{var5};
      float var11 = ItemUseUtil.bReturningFloat(var37);
      long var10001 = 8086651664322599480L ^ var107;
      Direction[] var12 = new Direction[]{Direction.DOWN, Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.UP};
      Direction[] var13 = var12;
      int var14 = var13.length;
      while (true) {
         int var93 = var14;
         int var92 = var15;
         if (var92 >= var93) {
            break;
         }

         BlockPos var17;
         Direction var18;
         Vec3d var19;
         label67: {
            label66: {
               label96: {
                  Direction var16 = var13[var15];
                  Direction var39 = var16;
                  BlockPos var38 = var4;
                  var17 = var38.offset(var39);
                  MinecraftClient var40 = b;
                  BlockPos var42 = var17;
                  ClientWorld var41 = var40.world;
                  BlockState var43 = var41.getBlockState(var42);
                  boolean var94 = var43.isReplaceable();
                  if (var94) {
                     int var95 = var9;
                     if (var95 != 0) {
                        break label96;
                     }
                  }

                  Direction var45 = var16;
                  var18 = var45.getOpposite();
                  BlockPos var46 = var17;
                  Vec3d var109 = var46.toCenterPos();
                  Direction var47 = var18;
                  double var112 = var47.getOffsetX() * 0.5;
                  Direction var48 = var18;
                  double var10002 = var48.getOffsetY() * 0.5;
                  Direction var49 = var18;
                  double var55 = var49.getOffsetZ() * 0.5;
                  double var53 = var10002;
                  double var51 = var112;
                  Vec3d var50 = var109;
                  var19 = var50.add(var51, var53, var55);
                  Vec3d var58 = var19;
                  Vec3d var57 = var10;
                  double var113;
                  int var96 = (var113 = var57.distanceTo(var58) - var11) == 0.0 ? 0 : (var113 < 0.0 ? -1 : 1);
                  if (var96 > 0) {
                     int var97 = var9;
                     if (var97 != 0) {
                        break label96;
                     }
                  }

                  MinecraftClient var60 = b;
                  ClientWorld var110 = var60.world;
                  MinecraftClient var61 = b;
                  RaycastContext var63 = new RaycastContext(var10, var19, ShapeType.COLLIDER, FluidHandling.NONE, var61.player);
                  ClientWorld var62 = var110;
                  BlockHitResult var20 = var62.raycast(var63);
                  int var98 = var9;
                  if (var98 == 0) {
                     break label66;
                  }

                  BlockHitResult var99 = var20;
                  if (var99 != null) {
                     int var101 = var9;
                     BlockHitResult var100 = var20;
                     BlockHitResult var78 = var100;
                     BlockHitResult var76 = var100;
                     if (var101 == 0) {
                        return var78;
                     }

                     BlockHitResult var102 = var76;
                     BlockHitResult var77 = var102;
                     BlockHitResult var66 = var77;
                     Vec3d var111 = ((HitResult)var66).getPos();
                     Vec3d var68 = var19;
                     Vec3d var67 = var111;
                     double var114;
                     int var103 = (var114 = var67.distanceTo(var68) - 0.1F) == 0.0 ? 0 : (var114 < 0.0 ? -1 : 1);
                     if (var103 <= 0) {
                        break label67;
                     }

                     int var104 = var9;
                     if (var104 == 0) {
                        break label67;
                     }
                  }
               }

               var15++;
            }

            int var106 = var9;
            if (var106 != 0) {
               continue;
            }
            break;
         }

         BlockHitResult var105 = new BlockHitResult(var19, var18, var17, false);
         BlockHitResult var115 = var105;
         return var115;
      }

      return null;
   }

   private boolean aReturningBoolean(Object[] var1) {
      SafeCartDetonationTarget var2;
      SafeCartPlacementTarget var5;
      long var11;
      long var15;
      int var17;
      boolean var18;
      label35: {
         Block var6 = (Block)var1[0];
         var5 = (SafeCartPlacementTarget)var1[1];
         var2 = (SafeCartDetonationTarget)var1[2];
         long var3 = (Long)var1[3];
         var3 = 125758565364168L ^ var3;
         long var7 = var3 ^ 36368620799859L;
         long var9 = var3 ^ 48997775165093L;
         var11 = var3 ^ 97737321675033L;
         long var13 = var3 ^ 139492443531785L;
         var15 = var3 ^ 15233774546774L;
         var17 = Event.cReturningInt();
         ModeSetting var19 = this.i;
         String var10000 = (String)var19.aReturningObject();
         short var10001 = 4779;
         long var10002 = 3319023319669584876L ^ var3;
         String var21 = "None";
         String var20 = var10000;
         boolean var68 = var20.equals(var21);
         int var56 = var17;
         boolean var55 = var68;
         boolean var52 = var55;
         boolean var48 = var55;
         if (var56 != 0) {
            boolean var57 = var48;
            if (var57) {
               Block var23 = var6;
               Object[] var24 = new Object[]{var23.asItem(), var9};
               boolean var69 = InventoryUtil.lReturningBoolean(var24);
               int var59 = var17;
               boolean var58 = var69;
               boolean var51 = var58;
               boolean var49 = var58;
               if (var59 != 0) {
                  boolean var60 = var49;
                  boolean var50 = var60;
                  boolean var61 = var50;
                  if (!var61) {
                     return false;
                  }

                  SafeCartPlacementTarget var28 = var5;
                  Object[] var29 = new Object[]{var28.y(), var7};
                  var51 = ItemUseUtil.aReturningBoolean(var29);
               }

               var18 = var51;
               int var62 = var17;
               if (var62 != 0) {
                  break label35;
               }
            }

            Runnable var73 = invokeBinding3(var5);
            ModeSetting var30 = this.i;
            String var75 = (String)var30.aReturningObject();
            short var10003 = 14564;
            long var10004 = 4450404102276487595L ^ var3;
            String var32 = "Silent";
            String var31 = var75;
            boolean var76 = var31.equals(var32);
            Object[] var10005 = new Object[]{null, null, null, var13};
            var10005[2] = var76;
            var10005[1] = var73;
            var10005[0] = var6;
            Object[] var33 = var10005;
            boolean var63 = InventoryUtil.kReturningBoolean(var33);
            var52 = var63;
         }

         var18 = var52;
      }

      int var65 = var17;
      boolean var64 = var18;
      boolean var54 = var64;
      boolean var53 = var64;
      if (var65 != 0) {
         boolean var66 = var53;
         if (var66) {
            Map var70 = this.m;
            SafeCartDetonationTarget var36 = var2;
            TntMinecartEntity var37 = var36.aa();
            UUID var74 = var37.getUuid();
            Integer var77 = 1;
            BiFunction var42 = invokeBinding4();
            Integer var41 = var77;
            UUID var40 = var74;
            Map var39 = var70;
            var39.merge(var40, var41, var42);
            SafeCartPlacementTarget var43 = var5;
            this.o = var43.x();
            this.p = System.currentTimeMillis();
            ElapsedTimer var71 = this.r;
            Object[] var45 = new Object[]{var15};
            ElapsedTimer var44 = var71;
            var44.aReturningVoid(var45);
            MinMaxSetting var72 = this.h;
            Object[] var47 = new Object[]{var11};
            MinMaxSetting var46 = var72;
            var46.bReturningVoid(var47);
         }

         var54 = var18;
      }

      return var54;
   }

   private Block aReturningBlock(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 125758565364168L ^ var2;
      long var4 = var2 ^ 20933284629205L;
      long var6 = var2 ^ 87182046329112L;
      long var8 = var2 ^ 108083402388230L;
      ModeSetting var19 = this.i;
      String var10000 = (String)var19.aReturningObject();
      short var10001 = 6134;
      long var10002 = 5292318584507029644L ^ var2;
      String var21 = "None";
      String var20 = var10000;
      boolean var11 = var20.equals(var21);
      int var98 = Event.cReturningInt();
      String[] var12 = l;
      int var13 = var12.length;
      int var10 = var98;
      int var96;
      do {
         int var64 = var13;
         int var63 = var14;
         if (var63 >= var64) {
            break;
         }

         label84: {
            label101: {
               String var15 = var12[var14];
               MultiModeSetting var99 = this.f;
               Object[] var23 = new Object[]{var15, var8};
               MultiModeSetting var22 = var99;
               boolean var65 = var22.aReturningBoolean(var23);
               if (!var65) {
                  int var66 = var10;
                  if (var66 != 0) {
                     break label101;
                  }
               }

               int var61;
               String var17 = var15;
               // String var25 = var17;
               int var100 = var25.hashCode();
               int var68 = var10;
               int var67 = var100;
               var61 = var67;
               int var52 = var67;
               label61:
               if (var68 != 0) {
                  int var69 = var52;
                  switch (var69) {
                     case 2374095:
                        var10001 = 28608;
                        var10002 = 3448682775294484656L ^ var2;
                        String var28 = "Logs";
                        String var27 = var17;
                        byte var101 = ((byte)((var27.equals(var28)) ? 1 : 0));
                        int var71 = var10;
                        byte var70 = var101;
                        var61 = var70;
                        byte var53 = var70;
                        if (var71 == 0) {
                           break label61;
                        }

                        byte var72 = var53;
                        byte var54 = var72;
                        byte var73 = var54;
                        if (var73 == 0) {
                           break;
                        }

                        var18 = 0;
                        int var74 = var10;
                        if (var74 != 0) {
                           break;
                        }
                     case -1901896079:
                        var10001 = 16554;
                        var10002 = 2263063667122081748L ^ var2;
                        String var32 = "Planks";
                        String var31 = var17;
                        byte var102 = ((byte)((var31.equals(var32)) ? 1 : 0));
                        int var76 = var10;
                        byte var75 = var102;
                        var61 = var75;
                        byte var55 = var75;
                        if (var76 == 0) {
                           break label61;
                        }

                        byte var77 = var55;
                        byte var56 = var77;
                        byte var78 = var56;
                        if (var78 == 0) {
                           break;
                        }

                        var18 = 1;
                        int var79 = var10;
                        if (var79 != 0) {
                           break;
                        }
                     case 1847455552:
                        var10001 = 24706;
                        var10002 = 3037082237218795510L ^ var2;
                        String var36 = "Cobblestone";
                        String var35 = var17;
                        byte var103 = ((byte)((var35.equals(var36)) ? 1 : 0));
                        int var81 = var10;
                        byte var80 = var103;
                        var61 = var80;
                        byte var57 = var80;
                        if (var81 == 0) {
                           break label61;
                        }

                        byte var82 = var57;
                        byte var58 = var82;
                        byte var83 = var58;
                        if (var83 == 0) {
                           break;
                        }

                        var18 = 2;
                        int var84 = var10;
                        if (var84 != 0) {
                           break;
                        }
                     case 416515707:
                        var10001 = 7068;
                        var10002 = 6677498112558945514L ^ var2;
                        String var40 = "Obsidian";
                        String var39 = var17;
                        byte var104 = ((byte)((var39.equals(var40)) ? 1 : 0));
                        int var86 = var10;
                        byte var85 = var104;
                        var61 = var85;
                        byte var59 = var85;
                        if (var86 == 0) {
                           break label61;
                        }

                        byte var87 = var59;
                        byte var60 = var87;
                        byte var88 = var60;
                        if (var88 != 0) {
                           var18 = 3;
                        }
                  }

                  var61 = var18;
               }

               int var89 = var61;

               Block var16 = switch (var89) {
                  case 0 -> {
                     TagKey var112 = ItemTags.LOGS;
                     Object[] var119 = new Object[]{null, null, var6};
                     var119[1] = var11;
                     var119[0] = var112;
                     Object[] var44 = var119;
                     AutoSafeCart var43 = this;
                     Block var90 = var43.cReturningBlock(var44);
                     yield var90;
                  }
                  case 1 -> {
                     TagKey var111 = ItemTags.PLANKS;
                     Object[] var118 = new Object[]{null, null, var6};
                     var118[1] = var11;
                     var118[0] = var111;
                     Object[] var47 = var118;
                     AutoSafeCart var46 = this;
                     Block var91 = var46.cReturningBlock(var47);
                     yield var91;
                  }
                  case 2 -> {
                     Block var110 = Blocks.COBBLESTONE;
                     Object[] var117 = new Object[]{null, null, var4};
                     var117[1] = var11;
                     var117[0] = var110;
                     Object[] var49 = var117;
                     AutoSafeCart var48 = this;
                     Block var92 = var48.bReturningBlock(var49);
                     yield var92;
                  }
                  case 3 -> {
                     Block var109 = Blocks.OBSIDIAN;
                     Object[] var10005 = new Object[]{null, null, var4};
                     var10005[1] = var11;
                     var10005[0] = var109;
                     Object[] var51 = var10005;
                     AutoSafeCart var50 = this;
                     Block var93 = var50.bReturningBlock(var51);
                     yield var93;
                  }
                  default -> null;
               };
               int var94 = var10;
               if (var94 == 0) {
                  break label84;
               }

               Block var95 = var16;
               if (var95 != null) {
                  return var16;
               }
            }

            var14++;
         }

         var96 = var10;
      } while (var96 != 0);

      return null;
   }

   private Block bReturningBlock(Object[] var1) {
      Block var4 = (Block)var1[0];
      boolean var5 = (Boolean)var1[1];
      long var2 = (Long)var1[2];
      var2 = 125758565364168L ^ var2;
      long var6 = var2 ^ 75184838382470L;
      long var8 = var2 ^ 23566886574579L;
      int var10 = Event.cReturningInt();
      int var28 = var10;
      boolean var27 = var5;
      boolean var21 = var27;
      boolean var18 = var27;
      if (var28 != 0) {
         boolean var29 = var18;
         if (!var29) {
            int var37 = var10;
            Block var36 = var4;
            Block var25 = var36;
            Block var24 = var36;
            Block var26;
            if (var37 != 0) {
               Block var16 = var24;
               Object[] var17 = new Object[]{var16.asItem(), var8};
               Integer var38 = InventoryUtil.aReturningBoxedInteger(var17);
               if (var38 != null) {
                  Block var39 = var4;
                  var26 = var39;
               } else {
                  var26 = null;
               }
            } else {
               Block var40 = var25;
               var26 = var40;
            }

            return var26;
         }

         int var31 = var10;
         Block var30 = var4;
         Block var22 = var30;
         Block var19 = var30;
         if (var31 == 0) {
            return var22;
         }

         Block var32 = var19;
         Block var20 = var32;
         Block var13 = var20;
         Object[] var14 = new Object[]{var13.asItem(), var6};
         boolean var33 = InventoryUtil.lReturningBoolean(var14);
         var21 = var33;
      }

      boolean var34 = var21;
      return !var34 ? null : var4;
   }

   private Block cReturningBlock(Object[] var1) {
      TagKey var2 = (TagKey)var1[0];
      byte var3 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var1[1]))))))))) ? 1 : 0);
      long var4 = (Long)var1[2];
      var4 = 125758565364168L ^ var4;
      long var6 = var4 ^ 118062118836854L;
      int var8 = Event.bReturningInt();
      int var26 = var8;
      byte var25 = var3;
      byte var24 = var25;
      byte var23 = var25;
      if (var26 == 0) {
         byte var27 = var23;
         if (var27 != 0) {
            MinecraftClient var12 = b;
            ClientPlayerEntity var13 = var12.player;
            Object[] var15 = new Object[]{var13.getMainHandStack(), var2, var6};
            AutoSafeCart var14 = this;
            return var14.dReturningBlock(var15);
         }

         var24 = 0;
      }

      int var9 = var24;

      int var32;
      do {
         short var10001 = 32575;
         long var10002 = 4664144798893007764L ^ var4;
         byte var29 = 8;
         int var28 = var9;
         if (var28 > var29) {
            break;
         }

         MinecraftClient var17 = b;
         ClientPlayerEntity var18 = var17.player;
         PlayerInventory var34 = var18.getInventory();
         int var20 = var9;
         PlayerInventory var19 = var34;
         Object[] var22 = new Object[]{var19.getStack(var20), var2, var6};
         AutoSafeCart var21 = this;
         Block var10 = var21.dReturningBlock(var22);
         int var30 = var8;
         if (var30 == 0) {
            Block var31 = var10;
            if (var31 != null) {
               return var10;
            }

            var9++;
         }

         var32 = var8;
      } while (var32 == 0);

      return null;
   }

   private Block dReturningBlock(Object[] var1) {
      int var6;
      ItemStack var23;
      label36: {
         ItemStack var3 = (ItemStack)var1[0];
         TagKey var2 = (TagKey)var1[1];
         long var4 = (Long)var1[2];
         long var10000 = 125758565364168L ^ var4;
         var6 = Event.bReturningInt();
         ItemStack var9 = var3;
         boolean var38 = var9.isEmpty();
         int var27 = var6;
         boolean var26 = var38;
         boolean var22 = var26;
         boolean var19 = var26;
         if (var27 == 0) {
            boolean var28 = var19;
            if (var28) {
               return null;
            }

            int var30 = var6;
            ItemStack var29 = var3;
            var23 = var29;
            ItemStack var20 = var29;
            if (var30 != 0) {
               break label36;
            }

            ItemStack var31 = var20;
            ItemStack var21 = var31;
            TagKey var13 = var2;
            ItemStack var12 = var21;
            boolean var32 = var12.isIn(var13);
            var22 = var32;
         }

         boolean var33 = var22;
         if (!var33) {
            return null;
         }

         var23 = var3;
      }

      ItemStack var15 = var23;
      Item var8 = var15.getItem();
      int var35 = var6;
      Item var34 = var8;
      Item var25 = var34;
      Item var24 = var34;
      if (var35 == 0) {
         boolean var36 = var24 instanceof BlockItem;
         if (!var36) {
            return null;
         }

         Item var37 = var8;
         var25 = var37;
      }

      BlockItem var7 = (BlockItem)var25;
      BlockItem var18 = var7;
      return var18.getBlock();
   }

   private boolean dReturningBoolean(Object[] var1) {
      TntMinecartEntity var2 = (TntMinecartEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 125758565364168L ^ var3;
      long var5 = var3 ^ 108873107335266L;
      int var7 = Event.cReturningInt();
      ModeSetting var9 = this.c;
      String var10000 = (String)var9.aReturningObject();
      short var10001 = 29601;
      long var10002 = 1608209908743406522L ^ var3;
      String var11 = "Both";
      String var10 = var10000;
      byte var38 = ((byte)((var10.equals(var11)) ? 1 : 0));
      int var27 = var7;
      byte var26 = var38;
      byte var20 = var26;
      byte var19 = var26;
      if (var27 != 0) {
         byte var28 = var19;
         if (var28 != 0) {
            return true;
         }

         Object[] var15 = new Object[]{var2, var5};
         AutoSafeCart var14 = this;
         var20 = ((byte)((var14.eReturningBoolean(var15)) ? 1 : 0));
      }

      byte var8 = var20;
      ModeSetting var16 = this.c;
      var10000 = (String)var16.aReturningObject();
      var10001 = 27172;
      var10002 = 8505167124310694462L ^ var3;
      String var18 = "Only Self";
      String var17 = var10000;
      byte var40 = ((byte)((var17.equals(var18)) ? 1 : 0));
      int var30 = var7;
      byte var29 = var40;
      byte var22 = var29;
      byte var21 = var29;
      if (var30 != 0) {
         byte var31 = var21;
         if (var31 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var8);
         }

         var22 = var8;
      }

      int var34 = var7;
      byte var33 = var22;
      byte var24 = var33;
      byte var23 = var33;
      if (var34 != 0) {
         byte var35 = var23;
         if (var35 != 0) {
            return false;
         }

         var24 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   private boolean eReturningBoolean(Object[] var1) {
      TntMinecartEntity var2 = (TntMinecartEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 125758565364168L ^ var3;
      long var5 = var3 ^ 89897300794824L;
      Object[] var13 = new Object[]{var2, var5};
      Vec3d var8 = RaycastUtil.aReturningVec3d(var13);
      long var9 = System.currentTimeMillis();
      int var10000 = Event.cReturningInt();
      List var14 = this.n;
      Iterator var11 = var14.iterator();
      int var7 = var10000;

      int var33;
      while (true) {
         Iterator var15 = var11;
         boolean var34 = var15.hasNext();
         if (var34) {
            Iterator var16 = var11;
            SafeCartPlacementTime var12 = (SafeCartPlacementTime)var16.next();
            SafeCartPlacementTime var17 = var12;
            long var47 = var9 - var17.w();
            short var10001 = 23032;
            long var10002 = 8718048768375763070L ^ var3;
            long var50;
            var10000 = (var50 = var47 - 5000L) == 0L ? 0 : (var50 < 0L ? -1 : 1);
            int var36 = var7;
            int var35 = var10000;
            var33 = var35;
            int var27 = var35;
            if (var36 == 0) {
               break;
            }

            int var38 = var7;
            int var37 = var27;
            int var30 = var37;
            int var28 = var37;
            if (var38 != 0) {
               int var39 = var28;
               int var29 = var39;
               int var40 = var29;
               if (var40 > 0) {
                  int var41 = var7;
                  if (var41 != 0) {
                     continue;
                  }
               }

               SafeCartPlacementTime var21 = var12;
               BlockPos var22 = var21.v();
               Vec3d var49 = var22.toCenterPos();
               double var25 = 1.5;
               Vec3d var24 = var49;
               Vec3d var23 = var8;
               var30 = (((var23.isInRange((Position)var24, var25)) ? 1 : 0));
            }

            int var43 = var7;
            int var42 = var30;
            int var32 = var42;
            int var31 = var42;
            if (var43 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var32);
            }

            int var44 = var31;
            if (var44 != 0) {
               byte var51 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var51);
            }

            int var45 = var7;
            if (var45 != 0) {
               continue;
            }
         }

         var33 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var33);
   }

   private void jReturningVoid(Object[] var1) {
      long var5;
      long var7;
      int var9;
      byte var22;
      label34: {
         List var4 = (List)var1[0];
         long var2 = (Long)var1[1];
         var2 = 125758565364168L ^ var2;
         var5 = var2 ^ 91850964965361L;
         var7 = var2 ^ 7384756715966L;
         var9 = Event.cReturningInt();
         List var11 = var4;
         byte var10000 = ((byte)((var11.isEmpty()) ? 1 : 0));
         int var27 = var9;
         byte var26 = var10000;
         byte var21 = var26;
         byte var20 = var26;
         if (var27 != 0) {
            byte var28 = var20;
            if (var28 != 0) {
               var22 = 0;
               break label34;
            }

            var21 = 1;
         }

         byte var29 = var21;
         var22 = var29;
      }

      byte var10 = var22;
      int var30 = var9;
      if (var30 != 0) {
         AutoSafeCart var25;
         label26: {
            byte var31 = var10;
            if (var31 != 0) {
               int var33 = var9;
               AutoSafeCart var32 = this;
               var25 = var32;
               AutoSafeCart var23 = var32;
               if (var33 == 0) {
                  break label26;
               }

               AutoSafeCart var34 = var23;
               AutoSafeCart var24 = var34;
               boolean var35 = var24.q;
               if (!var35) {
                  ElapsedTimer var37 = this.r;
                  Object[] var17 = new Object[]{var7};
                  ElapsedTimer var16 = var37;
                  var16.aReturningVoid(var17);
                  MinMaxSetting var38 = this.h;
                  Object[] var19 = new Object[]{var5};
                  MinMaxSetting var18 = var38;
                  var18.bReturningVoid(var19);
               }
            }

            var25 = this;
         }

         var25.q = dev.prestige.recovery.SourceSupport.asBoolean(var10);
      }
   }

   private BlockPos aReturningBlockPos(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 125758565364168L ^ var2;
      int var4 = Event.cReturningInt();
      BlockPos var13 = this.o;
      if (var13 == null) {
         return null;
      }

      label19: {
         long var10000 = System.currentTimeMillis() - this.p;
         short var10001 = 29227;
         long var10002 = 5336939933019957558L ^ var2;
         long var21;
         int var20 = (var21 = var10000 - 1000L) == 0L ? 0 : (var21 < 0L ? -1 : 1);
         int var15 = var4;
         int var14 = var20;
         int var12 = var14;
         int var11 = var14;
         if (var15 != 0) {
            int var16 = var11;
            if (var16 > 0) {
               break label19;
            }

            MinecraftClient var7 = b;
            BlockPos var9 = this.o;
            ClientWorld var8 = var7.world;
            BlockState var10 = var8.getBlockState(var9);
            byte var17 = ((byte)((var10.isReplaceable()) ? 1 : 0));
            var12 = var17;
         }

         int var18 = var12;
         if (var18 != 0) {
            return this.o;
         }
      }

      this.o = null;
      return null;
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 125758565364168L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var8 = b;
      ClientWorld var32 = var8.world;
      if (var32 != null) {
         Map var10 = this.m;
         boolean var33 = var10.isEmpty();
         label38:
         if (!var33) {
            HashSet var5 = new HashSet();
            MinecraftClient var11 = b;
            ClientWorld var12 = var11.world;
            Iterable var13 = var12.getEntities();
            Iterator var6 = var13.iterator();

            int var42;
            do {
               Iterator var14 = var6;
               boolean var34 = var14.hasNext();
               if (!var34) {
                  break;
               }

               Iterator var15 = var6;
               Entity var7 = (Entity)var15.next();
               boolean var44 = var7 instanceof TntMinecartEntity;
               int var36 = var4;
               boolean var35 = var44;
               boolean var27 = var35;
               if (var36 == 0) {
                  break label38;
               }

               int var38 = var4;
               boolean var37 = var27;
               boolean var28 = var37;
               if (var38 != 0) {
                  boolean var39 = var28;
                  boolean var29 = var39;
                  boolean var40 = var29;
                  if (var40) {
                     Entity var18 = var7;
                     UUID var20 = var18.getUuid();
                     HashSet var19 = var5;
                     boolean var41 = var19.add(var20);
                  }
               }

               var42 = var4;
            } while (var42 != 0);

            Map var22 = this.m;
            Set var45 = var22.keySet();
            Predicate var24 = invokeBinding5(var5);
            Set var23 = var45;
            boolean var31 = var23.removeIf(var24);
         }

         long var43 = System.currentTimeMillis();
         List var46 = this.n;
         Predicate var26 = invokeBinding6(var43);
         List var25 = var46;
         var25.removeIf(var26);
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
      Map var8 = this.m;
      var8.clear();
      List var9 = this.n;
      var9.clear();
      this.o = null;
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private static boolean lambda$pruneCarts$4(long var0, SafeCartPlacementTime var2) {
      int var5 = Event.bReturningInt();
      SafeCartPlacementTime var6 = var2;
      long var14;
      int var10000 = (var14 = var0 - var6.w() - 5000L) == 0L ? 0 : (var14 < 0L ? -1 : 1);
      int var11 = var5;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      if (var11 == 0) {
         int var12 = var7;
         if (var12 <= 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private static boolean lambda$pruneCarts$3(Set var0, UUID var1) {
      int var4 = Event.bReturningInt();
      UUID var6 = var1;
      Set var5 = var0;
      byte var10000 = ((byte)((var5.contains(var6)) ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 == 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private static void lambda$place$2(SafeCartPlacementTarget var0) {
      long var10001 = 53560612173994L ^ 64366542551183L;
      SafeCartPlacementTarget var5 = var0;
      Object[] var6 = new Object[]{var5.y(), 11253043183653L};
      ItemUseUtil.aReturningBoolean(var6);
   }

   private static int lambda$scanThreats$1(SafeCartDetonationTarget var0, SafeCartDetonationTarget var1) {
      SafeCartDetonationTarget var4 = var1;
      double var10000 = var4.ad();
      SafeCartDetonationTarget var5 = var0;
      double var8 = var5.ad();
      double var6 = var10000;
      return Double.compare(var6, var8);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Silent";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(47034332944602L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[15];
      String var26 = "\u0080ËæÞQK\u0014É^LSBß\u0003ÖÝ \u009cIFðûþ(:1¸\u001eË½\u0082QT|¾e·^¸\u0082R\u0002:|üR\u0005½Ü\u0010\u009fòj§0,nxUæÝã<\u0017\u0018\u0081\u0010\u0089cç \u001d3÷ 8u\u009bm]\u009d«/ »Õµ¶(M\u0019l\u0090\u0094h\u0099\u008c5\u000e\u009f\u00871;\u0099z\u0002\u0098»\u0094ü©Ðu¾\u0088Ý\u0010@~90â%\u008bës{âd£xòÅ\u0010.¾ý\u009dégé>Å\u000e+È\u008e\u00931\u0005\u0010qeÿy¶¤\u0083ç0ðÀ\u0013Ä^9À\u0018D\tâ¥\u008b^â(Òýò\u001bS¹Ð>\u0003CiÙ#oÀÀ\u0010|vô·'J\u009aÛ§ù\u008dËoA\u00adK Üï@\u0000ÄùZ\u009aIiÉ³4$º¯ùaGqÎJ\u0098d´©³®\u0001p¸# %\u0089ré92\u0004\u0090\u0016\u0086cÇ\u0011\u0011oAÑ\u0005g6¾\fê\u009e\u008es\u0000Èµ^&r\u0010Â´â@uÓ¼\u0098°Ojé¹\u0006(¡";
      int var28 = "\u0080ËæÞQK\u0014É^LSBß\u0003ÖÝ \u009cIFðûþ(:1¸\u001eË½\u0082QT|¾e·^¸\u0082R\u0002:|üR\u0005½Ü\u0010\u009fòj§0,nxUæÝã<\u0017\u0018\u0081\u0010\u0089cç \u001d3÷ 8u\u009bm]\u009d«/ »Õµ¶(M\u0019l\u0090\u0094h\u0099\u008c5\u000e\u009f\u00871;\u0099z\u0002\u0098»\u0094ü©Ðu¾\u0088Ý\u0010@~90â%\u008bës{âd£xòÅ\u0010.¾ý\u009dégé>Å\u000e+È\u008e\u00931\u0005\u0010qeÿy¶¤\u0083ç0ðÀ\u0013Ä^9À\u0018D\tâ¥\u008b^â(Òýò\u001bS¹Ð>\u0003CiÙ#oÀÀ\u0010|vô·'J\u009aÛ§ù\u008dËoA\u00adK Üï@\u0000ÄùZ\u009aIiÉ³4$º¯ùaGqÎJ\u0098d´©³®\u0001p¸# %\u0089ré92\u0004\u0090\u0016\u0086cÇ\u0011\u0011oAÑ\u0005g6¾\fê\u009e\u008es\u0000Èµ^&r\u0010Â´â@uÓ¼\u0098°Ojé¹\u0006(¡"
         .length();
      char var25 = 16;
      int var32 = -1;

      label64:
      while (true) {
         String var33 = var26.substring(++var32, var32 + var25);
         int var10001 = -1;

         while (true) {
            byte[] var30 = var22.doFinal(var33.getBytes("ISO-8859-1"));
            String var45 = b(var30).intern();
            switch (var10001) {
               case 0:
                  var29[var27++] = var45;
                  if ((var32 += var25) >= var28) {
                     t = var29;
                     u = new String[15];
                     y = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(47034332944602L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[2];
                     String var15 = "2à¤á±¶H\u008bzu¾¾¥ÊÌà";
                     int var16 = "2à¤á±¶H\u008bzu¾¾¥ÊÌà".length();
                     do {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        var10001 = var14++;
                        long var19 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        byte[] var21 = var11.doFinal(
                           new byte[]{
                              (byte)(var19 >>> 56),
                              (byte)(var19 >>> 48),
                              (byte)(var19 >>> 40),
                              (byte)(var19 >>> 32),
                              (byte)(var19 >>> 24),
                              (byte)(var19 >>> 16),
                              (byte)(var19 >>> 8),
                              (byte)var19
                           }
                        );
                        long var10004 = (var21[0] & 255L) << 56
                           | (var21[1] & 255L) << 48
                           | (var21[2] & 255L) << 40
                           | (var21[3] & 255L) << 32
                           | (var21[4] & 255L) << 24
                           | (var21[5] & 255L) << 16
                           | (var21[6] & 255L) << 8
                           | var21[7] & 255L;
                        // var17[var10001] = var10004;
                     } while (var13 < var16);

                     w = var17;
                     x = new Integer[2];
                     B = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(47034332944602L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     String var4 = "7¶,\u0081<àGÃ\u0017ÃåÚäxDþ!\u000bC\u0001ÿmêF";
                     int var5 = "7¶,\u0081<àGÃ\u0017ÃåÚäxDþ!\u000bC\u0001ÿmêF".length();
                     do {
                        int var42 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var42, var2).getBytes("ISO-8859-1");
                        var42 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var54 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var42] = var54;
                     } while (var2 < var5);

                     z = var6;
                     A = new Long[3];
                     l = new String[]{"Logs", "Planks", "Cobblestone", "Obsidian"};
                     break;
                  }

                  var25 = var26.charAt(var32);
                  break;
               default:
                  var29[var27++] = var45;
                  if ((var32 += var25) < var28) {
                     var25 = var26.charAt(var32);
                     continue label64;
                  }

                  var26 = "X¯\t%ÐbÖsÅ]Ã\u008f\u0092ÙÄV\u0010÷dÞ\u008a¡Í»Ô\u0004ÆS½i\u0090ß\u008a";
                  var28 = "X¯\t%ÐbÖsÅ]Ã\u008f\u0092ÙÄV\u0010÷dÞ\u008a¡Í»Ô\u0004ÆS½i\u0090ß\u008a".length();
                  var25 = 16;
                  var32 = -1;
            }

            var33 = var26.substring(++var32, var32 + var25);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9748;
      if (u[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])v.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               v.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eg", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = t[var5].getBytes("ISO-8859-1");
         u[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return u[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eg_C0230",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15634;
      if (x[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = w[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])y.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eg", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         x[var3] = var15;
      }

      return x[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eg_C0230",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 26147;
      if (A[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = z[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])B.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               B.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eg", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         A[var3] = var15;
      }

      return A[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eg_C0230",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = D[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = C[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 35;
            yield var16;
         }
         case 2 -> {
            byte var17 = 30;
            yield var17;
         }
         case 3 -> {
            byte var18 = 8;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 33;
            yield var20;
         }
         case 6 -> {
            byte var21 = 61;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 59;
            yield var23;
         }
         case 9 -> {
            byte var24 = 52;
            yield var24;
         }
         case 10 -> {
            byte var25 = 53;
            yield var25;
         }
         case 11 -> {
            byte var26 = 34;
            yield var26;
         }
         case 12 -> {
            byte var27 = 60;
            yield var27;
         }
         case 13 -> {
            byte var28 = 36;
            yield var28;
         }
         case 14 -> {
            byte var29 = 22;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 20;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 54;
            yield var33;
         }
         case 19 -> {
            byte var34 = 26;
            yield var34;
         }
         case 20 -> {
            byte var35 = 45;
            yield var35;
         }
         case 21 -> {
            byte var36 = 41;
            yield var36;
         }
         case 22 -> {
            byte var37 = 37;
            yield var37;
         }
         case 23 -> {
            byte var38 = 48;
            yield var38;
         }
         case 24 -> {
            byte var39 = 24;
            yield var39;
         }
         case 25 -> {
            byte var40 = 14;
            yield var40;
         }
         case 26 -> {
            byte var41 = 56;
            yield var41;
         }
         case 27 -> {
            byte var42 = 63;
            yield var42;
         }
         case 28 -> {
            byte var43 = 27;
            yield var43;
         }
         case 29 -> {
            byte var44 = 2;
            yield var44;
         }
         case 30 -> {
            byte var45 = 11;
            yield var45;
         }
         case 31 -> {
            byte var46 = 39;
            yield var46;
         }
         case 32 -> {
            byte var47 = 5;
            yield var47;
         }
         case 33 -> {
            byte var48 = 31;
            yield var48;
         }
         case 34 -> {
            byte var49 = 32;
            yield var49;
         }
         case 35 -> {
            byte var50 = 55;
            yield var50;
         }
         case 36 -> {
            byte var51 = 15;
            yield var51;
         }
         case 37 -> {
            byte var52 = 13;
            yield var52;
         }
         case 38 -> {
            byte var53 = 57;
            yield var53;
         }
         case 39 -> {
            byte var54 = 28;
            yield var54;
         }
         case 40 -> {
            byte var55 = 23;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 38;
            yield var57;
         }
         case 43 -> {
            byte var58 = 17;
            yield var58;
         }
         case 44 -> {
            byte var59 = 18;
            yield var59;
         }
         case 45 -> {
            byte var60 = 9;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 46;
            yield var62;
         }
         case 48 -> {
            byte var63 = 16;
            yield var63;
         }
         case 49 -> {
            byte var64 = 3;
            yield var64;
         }
         case 50 -> {
            byte var65 = 1;
            yield var65;
         }
         case 51 -> {
            byte var66 = 0;
            yield var66;
         }
         case 52 -> {
            byte var67 = 7;
            yield var67;
         }
         case 53 -> {
            byte var68 = 49;
            yield var68;
         }
         case 54 -> {
            byte var69 = 44;
            yield var69;
         }
         case 55 -> {
            byte var70 = 50;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 51;
            yield var72;
         }
         case 58 -> {
            byte var73 = 58;
            yield var73;
         }
         case 59 -> {
            byte var74 = 42;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 62;
            yield var77;
         }
         default -> 29;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            D[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      C[0] = "\u0011\u001aS[oe\u001a\u0015B\u0014\u0012}\t\u0012K]";
      C[1] = "oY\u0017@$ZdV\u0006\u000fETo]\u0002U";
      C[2] = boolean.class;
      D[2] = "java/lang/Boolean";
      C[3] = ")cDn\u0019#?cA4\n4((B2\u0006 9oU%M7\u000b";
      C[4] = "kI<0\u0002\u0000}I9j\u0011\u0017j\u0002:l\u001d\u0003{E-{V\u0017h";
      C[5] = double.class;
      D[5] = "java/lang/Double";
      C[6] = "\u0007\u0016HJ<\u0003\f\u0019Y\u0005V\u0000\u0018\u0015RN";
      C[7] = int.class;
      D[7] = "java/lang/Integer";
      C[8] = "\u0002|J,%\u0010\u0002|]p)\u001f\u00187]n)\n\u001fF\f0|A";
      C[9] = "\"Ns#\u007f1\"Nd\u007fs>8\u0005das+?t5;*h";
      C[10] = "R\u0000ln\u001f\u0016D\u0000i4\f\u0001SKj2\u0000\u0015B\f}%K\u0007s";
      C[11] = "K\rE\u0016Y\\]\r@LJKJFCJF_[\u0001T]\rMC";
      C[12] = "u\r>IX0\u0000-5FI\u007fa#>MM%\u0015";
      C[13] = "b/\t^+\u0000b/\u001e\u0002'\u000fxd\u001e\u001c'\u001a\u007f\u0015OCuQ";
      C[14] = "&\u0017OR:j0\u0017J\b)}'\\I\u000e%i6\u001b^\u0019n\u007f%";
      C[15] = "\u001bA\u001dEAHna\u0016JP\u0007\u000fo\u001dAT]{";
      C[16] = "^P\rq82@X\u0017>Z.GE";
      C[17] = "yol4#nggv{Dov|{!bi";
      C[18] = "iPp\u0007\u0000f\u007fPu]\u0013qh\u001bv[\u001fey\\aLTpT";
      C[19] = "\n2\u000f8qQ\u007f\u0012\u00047`\u001e\u001e\u001c\u000f<dDj";
      C[20] = "\u0012:9r9\fg\u001a2}(C\u0006\u00149v,\u0019r";
      C[21] = "unI\u0011\u0002_cnLK\u0011Ht%OM\u001d\\ebXZVKh";
      C[22] = "X\u0018UoI&-8^`XiL6Uk\\38";
      C[23] = "~W# \u0007K~W4|\u000bDd\u001c4b\u000bQcmd?Z";
      C[24] = "KMqjaYKMf6mVQ\u0006f(mCVw2p:";
      C[25] = "R7o\u0011\u0003y'\u0017d\u001e\u00126F\u0019o\u0015\u0016l2";
      C[26] = "~\u001c'^o{h\u001c\"\u0004|l\u007fW!\u0002pxn\u00106\u0015;hv\u00104\u001ea%J\u000b4\u0003ab}\u001c";
      C[27] = "\u001cKP\"\u0016qik[-\u0007>\beP&\u0003d|";
      C[28] = "P:\u0001\u001e\u000b9P:\u0016B\u00076Jq\u0016\\\u0007#M\u0000F\tPe";
      C[29] = ":-Pr\u0010~:-G.\u001cq fG0\u001cd'\u0017\u0012oE";
      C[30] = "\u0006G\u001fUHU\u0006G\b\tDZ\u001c\f\b\u0017DO\u001b}YO\u0016";
      C[31] = "&c0\u001b~\u0006SC;\u0014oI2M0\u001fk\u0013F";
      C[32] = void.class;
      D[32] = "java/lang/Void";
      C[33] = "9x\u0001\ryr2w\u0010B\u001a\u007f'z\u001f)/}6i\u0003\u00058p";
      C[34] = "%(\u000bn\\\u0013P\b\u0000aM\\1\u0006\u000bjI\u0006E";
      C[35] = "\u0007\u0001w6d\u0004\u0007\u0001`jh\u000b\u001dJ`th\u001e\u001a;1+0";
      C[36] = "_k\u00100UV*K\u001b?D\u0019KE\u00104@C?";
      C[37] = "\u0014\n:C\tV\u0002\n?\u0019\u001aA\u0015A<\u001f\u0016U\u0004\u0006+\b]G\b";
      C[38] = "x}Y\b/]\r]R\u0007>\u0012lSY\f:H\u0018";
      C[39] = "J\u0015k\u001f\u0014\u0004?5`\u0010\u0005K^;k\u001b\u0001\u0011*";
      C[40] = "'\u0013`1W''\u0013wm[(=Xws[=:)&-\u000ex";
      C[41] = ")]O)\b\u0018\\}D&\u0019W=sO-\u001d\rI";
      C[42] = "\u001cWE<,\u0019\nW@f?\u000e\u001d\u001cC`3\u001a\f[Twx\n\u0017";
      C[43] = "r>H;\u0003&\u0007\u001eC4\u0012if\u0010H?\u00163\u0012";
      C[44] = "K;\u001d\n\u0005c@4\fEbaU?\f\u000eY";
      C[45] = "\u001a;\u0005@}oo\u001b\u000eOl \u000e\u0015\u0005Dhzz";
      C[46] = "T\">rY\u0006T\").U\tNi)0U\u001cI\u0018{k\r]";
      C[47] = "\u00108\u0010u\u0004J\u00068\u0015/\u0017]\u0011s\u0016)\u001bI\u00004\u0001>P^>";
      C[48] = "\u001a\u001f7\u0012\u0019\u0011o?<\u001d\b^\u000e17\u0016\f\u0004z";
      C[49] = "\\$jH&\"J$o\u001255]ol\u00149!L({\u0003r1\u000b";
      C[50] = "m\u0001m$IL\u0018!f+X\u0003y/m \\Y\r";
      C[51] = "tB;^u\u0018bB>\u0004f\u000fu\t=\u0002j\u001bdN*\u0015!\u000fu";
      C[52] = "t9$;M\ft93gA\u0003nr3yA\u0016i\u0003b&\u0017Q";
      C[53] = "\u0005\u0005)AN\u0016\u000e\n8\u000e3\u0003\u001c\u0010:M";
      C[54] = long.class;
      D[54] = "java/lang/Long";
      C[55] = "%.}#2a;&glza!,\u007f+sza\u001fy'x},.\u007f'";
      C[56] = "b\u000eM\u0011\u00141|\u0006W^i!|";
      C[57] = "F*V|r\u0012M%G3\u0015\nI9A\u007f0\u001b";
      C[58] = ",K-]z\t2C7\u0012\u0019\u001d6";
      C[59] = "3]Q\u0004-E3]FX!J)\u0016FF!_.g\u0014\u0018y\u001b";
      C[60] = "\u0017h\u001b\u0017\u0017^\t`\u0001Xl~4M";
      C[61] = "\u001dE\u000bxc\u0019\u001dE\u001c$o\u0016\u0007\u000e\u001c:o\u0003\u0000\u007fNa:G";
      C[62] = "iypS0diyg\u000f<ks2g\u0011<~tC5Jd4";
      C[63] = "o\u001exjq\u000eo\u001eo6}\u0001uUo(}\u0014r$:|*U";
      C[64] = "JTQ`xQ\\TT:kFK\u001fW<gRZX@+,FH";
      C[65] = "<\u0004Z?e$*\u0004_ev3=O\\cz',\bKt174";
      C[66] = "{6F\u001cjV\u000e\u0016M\u0013{\u0019o\u0018F\u0018\u007fC\u001b";
      C[67] = ";Az}C\u0016;Am!O\u0019!\nm?O\f&{?e\u0018N";
      C[68] = "3>@X\u0007\u0006F\u001eKW\u0016I'\u0010@\\\u0012\u0013S";
      C[69] = "\tq:jOa\tq-6Cn\u0013:-(C{\u0014K\u007f|\u0012:";
      C[70] = "\u000eh7\u0003n7\u000eh _b8\u0014# Ab-\u0013Rq\u0015;k";
      C[71] = "wWzT\n?wWm\b\u00060m\u001cm\u0016\u0006%jm?HQn";
      C[72] = "v~Z\u0001*>`~_[9)w5\\]5=frKJ~,w";
      C[73] = "u-\u0005\"D\u0005\u0000\r\u000e-UJa\u0003\u0005&Q\u0010\u0015";
      C[74] = "\u0010\u0012!6\u000b\u0019\u0010\u00126j\u0007\u0016\nY6t\u0007\u0003\r(g-_F";
      C[75] = "S)LD#@S)[\u0018/OIb[\u0006/ZN\u0013\nY{\u0019";
      C[76] = "\u0018\bJ[H\u0019\u0018\b]\u0007D\u0016\u0002C]\u0019D\u0003\u00052\rL\u0010IR\u000eR\u0014V\u0003)^\u0007C\u0015";
      C[77] = "\u0015n[m\u0017)\u0015nL1\u001b&\u000f%L/\u001b3\bT\u001czOy_hC\"\t3$9\u001bq";
      C[78] = "Zc+-\u000b~Zc<q\u0007q@(<o\u0007dGYl:S.";
      C[79] = "\t]5y\u0013\u001a|}>v\u0002U\u001ds5}\u0006\u000fi";
      C[80] = float.class;
      D[80] = "java/lang/Float";
      C[81] = "FsNeS\u001f3SEjBPR]NaF\n&";
      C[82] = "\u0001(\u0002Q\u0003St\b\t^\u0012\u001c\u0015\u0006\u0002U\u0016Fa";
      C[83] = "-)rCVD-)e\u001fZK7be\u0001Z^0\u00135Y\u0003\u0014";
      C[84] = "\u001b\u001fa*mx\r\u001fdp~o\u001aTgvr{\u000b\u0013pa9l1";
      C[85] = "z#(\r^t\u000f\u0003#\u0002O;n\r(\tKa\u001a";
      C[86] = "l\r\u0000\b~5\u0019-\u000b\u0007ozx#\u0000\fk \f";
      C[87] = "3\b5rcKF(>}r\u0004'&5vv^S";
      C[88] = "MK\u0011.+\b8k\u001a!:GYe\u0011*>\u001d-";
      C[89] = "\u001e+\\FL{\u001e+K\u001a@t\u0004`K\u0004@a\u0003\u0011\u0019_\u0011#";
      C[90] = "\u0018d\u0013\u0014\u0004n\u000ed\u0016N\u0017y\u0019/\u0015H\u001bm\bh\u0002_Pz0";
      C[91] = "N=`rw>;\u001dk}fqZ\u0013`vb+.";
      C[92] = "V<l\u000flV#\u001cg\u0000}\u0019B\u0012l\u000byC6";
      C[93] = "\u007fou\u001dp \nO~\u0012aokAu\u0019e5\u001f";
      C[94] = "\u0010i1D{q\u000ea+\u000b3q\u0014k3L:jTJ.c j\u0019|.J;";
      C[95] = "\u0011RZMTTdrQBE\u001b\u0005|ZIAAq";
      C[96] = "_\tlfKo*)giZ K'lb^z?";
      C[97] = "\u000e%\u0011S\u0013e{\u0005\u001a\\\u0002*\u001a\u000b\u0011W\u0006pn";
      C[98] = "\u001ez\u00032W^\bz\u0006hDI\u001f1\u0005nH]\u000ev\u0012y\u0003J\u0002";
      C[99] = "-\u0018[E\u0018\bX8PJ\tG96[A\r\u001dM";
      C[100] = "\u0011\u000ejS\u0013?\u0011\u000e}\u000f\u001f0\u000bE}\u0011\u001f%\f4-HMd";
      C[101] = "\u000eZ\u0016\u0012\u001d\u0000\u0018Z\u0013H\u000e\u0017\u000f\u0011\u0010N\u0002\u0003\u001eV\u0007YI\u0014(";
      C[102] = "&\u0012\t%e\bS2\u0002*tG2<\t!p\u001dF";
      C[103] = "FG\u0004/:;3g\u000f +tRi\u0004+/.&";
      C[104] = "Zbff\u000f]Qmw)g]_bd";
      C[105] = "\u001b\u0001#DIkn!(KX$\u000f/#@\\~{";
      C[106] = "Z>2\fkO/\u001e9\u0003z\u0000N\u00102\b~Z:";
      C[107] = "\u001fU(3\\(\u0001]2|12\u0018D? \u0013)\u001aF";
      C[108] = "x~U @xsqDo#ufw";
      C[109] = "SD\u0000Q.m&d\u000b^?\"Gj\u0000U;x3";
      C[110] = "u\u007f\u000f@dLtbO\u0011 \"\"{^\u0019suu'\u000eF.\"u*\u000b\u0012|]rz_\u0014f";
      C[111] = "Y\u0014\u0011\u0014\u0003]\u001fP\u000b@b\rB\u0002\u0010\u00155Z\u001bRHAb^Q\r\r\u001d\u001d\u0002I\u000f\r";
      C[112] = "g\u0014\u0006\u001ayUdW\u0007\u0003\u0001D\u000e\u0011Q\u000b0\u0014t\u0015\u001b\u000bhS\u000eA\u000b\u001ceFlI\u000f\fs/";
      C[113] = "W(RZfD\u0002a\rFXN\u0001Y\t\u0018>LUfK\u001a9_m";
      C[114] = "&\u001f\u000f^\u0014)~\u001c\nIHLtZ\bXF*c{\u0013GF\t~C\u0016CPL&\u001dHE[6uF\f\\DL";
      C[115] = "{'\u0005\u001d.ws#\u0015\u000bGnv<\u0014y}/j%\u0017\u00067kw{\ry\"sz>\u000e\u0006)u|(h";
      C[116] = "WBX6*KZE]:\u0013V9@\n2\"\u0001CD@2zF9\u001fW#k\\F\u0014Q%}:";
      C[117] = "\u0003\u000720hO\u0018I3%\f\u001cs\u0001l.=N\t\u0005&.e\tsKk1h\u0011IP%0}u";
      C[118] = "\t.u/lp\nmt6\u0014c`+\">%1\u001a/h>}v`(x{v6\u001f|g{t\n";
      C[119] = "R}(i$DQqiz\u0018D_h3mtv\b(n3%!\u0003}c:&]\u0002%l0\u0018";
      C[120] = "$\\-\u0006\u007f\u0013'\u001f,\u001f\u0007\u0003MYz\u00176R7]0\u0017n\u0015M\t \u0000c\u0000/\u0001$\u0010ui";
      C[121] = "L]F\u001er;\u0004PR\u0011+\u0001\u001b\\Z\u0019!VL\u0006\u000bMM8\u0015LTBwp\u0018X[\u001b";
      C[122] = "iP\u0010V\u000f3<\u0019OJ199!\u0013\u0013[\"(^OS\u0000.S";
      C[123] = "4\u0007onvN7\u000b.}JN9\u0012tj&|oU)2s+0P~\u007f1Tl\u0010%sJ";
      C[124] = "^(L>\u0004I]kM'|Z7r_8\u0017MG)\u001b.\u001d3RhM>\u0002C\t,[4|";
      C[125] = "A,:Ed(A+(\"9mQ! YT-\u001d!9I;p^##\"mu\u0013*x]9j\u0013(D";
      C[126] = "\u0018G'TQz\u001b\u0004&M)kqBpE\u0018;\u000bF:E@|qE9]Pd\u000e\u0019!_P\u0000";
      C[127] = "\u0001<.~\u001c]\t</t[3]81n\u0007_ohq5P3\u0005d67\u0001\rRk}b`\n\u00076?s\u0011\u0002Cl}e`";
      C[128] = "F\u0011eDl\u0016GIjNR\u000f\u001a\u00045\u0013>=N@mDnjF\u0011eDl\u0016GIjNR";
      C[129] = "ajyZl\u0004b-p\b-51\u0015-\n,\u0004co)@,\\$\u0015.PiWdjzOiUX";
      C[130] = "u7N}@\u0001 `Gx\u0018z'kF8\u0018\u001b*w }@\u00131gO \u0003\u0011+\f\u0019%N\u0018psM:N\u001aL";
      C[131] = "\u0006\u00191C\u000bpCN!D\f\rQ\u0017<\u0019\u001eZ\u0006OiFL\r\u0006\u00191C\u000bpCN!D\f";
      C[132] = "\u001c?\u0004{(pX\u007fYav\u0019@oF`tur?\u0004>,\u0019\u001c<\u0002|v{C9Azp\u0019";
      C[133] = "8:dkH{>8,k\bJo7p4\u001b\u001d<f%`wsm/&oFuog&/";
      C[134] = "\u0015}\u000bF\u000eWUcS\t|Sm8QLM\b\u0017<\u001bL\u0015Om>SP\u0017\u000bR|QW\u00043";
      C[135] = ";qt\u00195n88u@.\u0014k@!G%%9:%\r%}~@\"\u001d`v>?v\u0002`t\u0002";
      C[136] = "m#)\u0016=In/h\u0005\u0001I`62\u0012m{3skH\u0001\u0015lu0I~Asu2u";
      C[137] = "y\u000f\b\u0011L\u0019.\rZH\u001a!?7\t\u0011\u001dF0MZJY_/7";
      C[138] = "\u0012?\u001f7{U\u0011|\u001e.\u0003C{:H&2\u0014\u0001>\u0002&jS{9\u0012ca\u0013\u0004m\rcc/";
      C[139] = "3\u0019T\u0012SdvND\u0015T\u0019d\u0017YHFN3O\f\u0017\u0011\u00193\u0019T\u0012SdvND\u0015T";
      C[140] = "[S[\f\u007f\u0001S\u0017\u0001Nip\u0007\u0001D\u001ee\u001c5S\tF3p\u001dUXFl\u001e\u0005\u0010TD\u0002";
      C[141] = "&\u001f$y N%Uri0 n/)k/K\u007f\u001evf\"\u0018\u001f";
      C[142] = "oq=[~m)5'\u000f\u001f=tg<ZHj-6d\u000b\u001fngh!R`2\u007fj!";
      C[143] = "\u001d\u001cb!O\u001aHKk$\u0017aCI\f!O\bYLc|\f\nC'5#\u0010X\u0015\\`t\u0019]M'";
      C[144] = "<gbh|6||%+\u0007`\u00033.m>j=d!&k\u000b";
      C[145] = "tf\u00116n?a#\r \u0014>\u0018eK<%oba\u0001<}(\u0018f\u0011yvhg2\u000eytT";
      C[146] = "\u0012s\u0017BM2N3LN6#\u0017 \u0019\\atMpE0\nt\u0010&E\u000fHv\u00175";
      C[147] = "THf\u0011\u0011\u0017\u0002Y7\u0010a\u0012[Wb\f6E\u0005\u0000:`\u0001\u0015AY:\u0005\u0002\u0019\u0000J";
      C[148] = "m&\u0019P$o8oFL\u001ae>WGS}56f\u0015\u0010w3>W";
      C[149] = "<e<k@l?\"59\u0001]l\u001ah;\u0000l>`lq\u00004y\u001akb\u0001\">u,k@my\u001a";
      C[150] = "\b{\u001aX\u0004\u007f]yZDuy\u000b|\"O\u0005eb>\u0005\u001d\u0017%\u001dj\u001a\u001d\u0015\u0019";
      C[151] = "+;\u000e&{(\u007f$\u0014\"rO|:\t+'\u0018+dYr{O+;\u000e&{(\u007f$\u0014\"r";
      C[152] = "^r\u0018?JqVv\b)#rO^\u0010#_b4*\u0014dA/K~\u000bdC\u0013";
      C[153] = "BaFQw\u0001\u001dlK\u0002\u0017UMa[]{g\u0019\"\u0004\u0005(0\u0011t\u000b\n)L\u0010,\u0004\u0000\u0017";
      C[154] = "\u0011kSe\u0003NG8\u0003\u007f\u0002%A\u0006X5\b\u0014\u0013|\\\u007f\bLT\u0006[`\t\\Dc\u001fi\u0013TQ\u0006";
      C[155] = "H+\u0002\u0011\u0010AKh\u0003\bhR!.U\u0000Y\u0000[*\u001f\u0000\u0001G!v\u0012\u0007\u0003[\u0010)\u001f\nP;";
      C[156] = "\u001f\u0006\nc\u001f\u001b\u0013\\Tw%\u0004\u000b\u0003Iub\u0014bZ\u0005c\u001c\u001b\\\r\n(Iz\u001f\u0006\nc\u001f\u001b\u0013\\Tw%";
      C[157] = "'<Gfq\f$\u007fF\u007f\t\u001cN9\u0010w8M4=Zw`\nN>Yop\u00121bAmpv";
      C[158] = "l*a\u001fYM;n,G_<0ymNFP\u0002+.\u0017\u0018<hfsWEC4~qW!";
      C[159] = "6\u0017{mP]w\u001e!.;S\u0006D'i\n\u0002|@miRE\u0006G},Y\u0005y\u0013b,[9";
      C[160] = "W,~\u000bUMP/u\u00130\u0017+s*\u000f\u0001HQw`\u000fY\u000f+ppJROT$oJPs";
      C[161] = "'<QPn/$0\u0010CR/*)JT>\u001dym\u0016\fRsx6XN#{<l\u001aXR";
      C[162] = "\f\u001e\t1X(YWV-f\"]oRs\u0000 \u000eP\u0010q\u000736";
      C[163] = "r\u0014\f7!&qW\r.Y5\u001b\u0011[&hga\u0015\u0011&0 \u001b\u0016\u0012> 8dJ\n< \\";
      C[164] = "M\"UGx\u0006E&EQ\u0011\rK/8\u001a \rZ(WGc\u000f@C\u0001B.\u0006\u001b<U].\u0004'";
      C[165] = "[,))\b;T|7z50U1-,Y\u0002\u0001rrw\u000fU\u0001,(.\t%Cv1&RUZ10 Ud\u0005<=s5";
      C[166] = ")0t\u001et\u000bp2'\u0011xgu6j\u0017y\u000bGb,J\"Y\u0010bz\u000e%X!dxF%\u0018\u0010";
      C[167] = "\u001c/\u001bY\b'\u001dw\u0014S6>@:K\u000eZ\f\u0011x\u0016T\u0006[IxA\u001bM$\u00158\u001a\u00176";
      C[168] = "\u007f!aU\u0019z\"zy\u001c\u001b\u0019%ptw\u0013eF$>BG(=qiKBpF";
      C[169] = "\u001fu\"d-rZ\"2c*\u000fCw>:3cq#zci4&#-:jv[fz*mq&";
      C[170] = "\u001c~:\u0004?>E\u007f(Eb_H\"4\u001ds\u0001O\".\u0019\u000ffD=,O`!M|c\b\u000f";
      C[171] = "(0?(\u0017fmg//\u0010\u001bt2#v\twFfg/P'\u0011bnmWz/5a&\u0002\u001b";
      C[172] = ")D;)\u000b\u0000t\u001f#`\tc{\u001c29\u0016cu\u001e4(\n\u001c~\u00182>l";
      C[173] = "^V@h\u0018f\u0003\rX!\u001a\u0005\u0002\u0007^~\u0012\u0005^[Ml\u0014j\u0003\u0018Ov\u007f<V\u0003Yz\u0010a\u0015\u0001C\u0011Fy\u0004\rCc\u0011{\u001c\u000fE\u0011F4\u000e\u0017O~\u001bw\f\r$";
      C[174] = "'ls7\\\u0011*kv;e\tIn!3T[3jk3\f\u001cIme'\u000eZxn\".\\\u001bI";
      C[175] = "Y1C0@\u0011_3\u000b0\u0000 \r$Gb\u001b[`d\u000bb\u0002K\u000f9H`\u0018 Y<\u0005iC_\r#\u0005k\u007f";
      C[176] = "\u00184-\u0011-SDtv\u001dVI\u0011v'\u0004:{E2|ZV\u0010El,[iRGk?cj\u0015\u001aa\u007f\\(\u0017\u001drG_oJ\u00172x\u001dmM\u0004\n#]<^\u0007u\u007f\u001dgR|";
      C[177] = "LMeI~F\rD?\n\u0015K|\u001e9M$\u0019\u0006\u001asM|^|\u0019pUlF\u0003EhWl\"";
      C[178] = "r<y+l\u000esdv!R\u0017.))|>%zmq%cr~d2\"3L)kywROr.pzl\u0018}e%\u001boC8l(%8Ls9I*;Bsk5+cMyU";
      C[179] = "<F7nn>?\u00056w\u0016-UC`\u007f'\u007f/G*\u007f\u007f8U@kjx6;C!<h&U";
      C[180] = "\u001f\u0012}R}OC\n\u007fR\u0019UO\u001c\u007fLug\u0013]!\u0017\u0019\u000eHY$OeTK\u001e`+";
      C[181] = "\\K$;Q\u0010TO4-8\b[O.!U3X*peZ\u0016S\u0011-cC\n_*p>\u0007\u0010\nU$!\u0007\u00126";
      C[182] = "j\rb\u0006o'+\u0019=M8\u00199t9\r\u007f(h\u000e=G\u007fp/tfPna5\u000bmVhwS";
      C[183] = "\f\u0002GD\u007f1\u000f\u000e\u0006WC1\u0001\u0017\\@/\u0003WR\u0001\u001bsTU\u0002_W?:]\u0002^]xT";
      C[184] = "}\u0011M.q\n/RG(y;!\u0004VwwW\u0013S\u0016*)\u0006DXC' \u00058Y\u001b(*;";
      C[185] = "p\u0001$S_~%V-V\u0007\u00053W/\r\u0010h\bTJSTg-_q\u000eR~1SJS\u000f:+\u00065\u0007\u0010:):";
      C[186] = "\ncD1Zf\ndVV\n3\u001cgq1\u00067g:\u000b-S;Ym\u0004f\u0006Z";
      C[187] = "\b=XD2\u0010MjHC5m_3U\u001e':\bk\u0000Avm\b=XD2\u0010MjHC5";
      C[188] = "BD{bo)C\u001cthQ0\u001eQ+5=\u0002J\u0015scjUJB+l((\u000f\u0015;k/UBD{bo)C\u001cthQ";
      C[189] = "?l |I\u0005<&vlYkt\\s+]\u0000>c1)Z\u0013\u0006";
      C[190] = ":M?\u001fli9A~\fPi7X$\u001b<[a\u001axAl\fcF?\u0003kc$O~L,\f";
      C[191] = "gW8G)ro\u0013b\u0005?\u0003;\u0005'U3o\tWj\u000bl\u0003g\tdWh|3\u0016dUT";
      C[192] = "o\u0015 0O^g\u00110&&]y\u00197=Z[\u007ft'(XFt\u0012r*\u0018Z\u0005";
      C[193] = "y'~^eYzd\u007fG\u001dJ\u0010\")O,\u0018j&cOt_\u0010){\u0005-\u001dl(#\n'#";
      C[194] = "\u0015P2!47\u0019\nl5\u000e7\u000eMR3j+\u000511kuo\t\u000ffd>:h";
      C[195] = "m9J\u0019N\u001fa&X\u001b5\u0006g:J\u0011Y43y\u0015F\tcnx@\u0004N\u001c28\u001b\b5";
      C[196] = "Ehu\u0001Mq\u0010j5\u001d<qBdw{\u0005&Fi`\u0014XeDs\u000b";
      C[197] = "\tnFe%qT,\u001aaI`R4Re3f5m\u0013j\"3\n/\u0011m1\u000b\thLgq4KjKtI6\u0004*\u0013mwa\u000baF\f";
      C[198] = "f\u0016u\r.M;\u0006y\t4!:\u000bxT)M\b_9\u000f\u007f\u001a__fO1\u001a0\u0018o\u000e~]__fO1\u001a0\u0018o\u000e~]_";
      C[199] = "ixgWb1j;fN\u001a)\u0000}0F+pzyzFs7\u0000\"mWb-\u007f)kQtK";
      C[200] = "^+Uc#\u001d\u001b|Ed$`\t%X967^}\rff`^+Uc#\u001d\u001b|Ed$";
      C[201] = "U\u0016R1\r\t]\u0012B'd\u0000[\u001aV/d\u000eY\u001cG3\u001b\u0005_\u001aQU";
      C[202] = "|\u000b\"\fOK9\\2\u000bH6 \t>RQZ\u0012]z\u000b\b\u000bEYsI\u000fW{\u000e|\u0002Z6";
      C[203] = "\fjOK`VP*\u0014G\u001bG\t9AUL\u0010Si\u001f9'\u0010\u000e?\u001d\u0006e\u0012\t,";
      C[204] = "\u001a\u0000\r<f\u001cF@V0\u001d\u0006\u0013B\u0007)q4D\u0002Wv'cG\u0006\bw`\u001a\u0019E\u001a+mcB\u0007\u0001%%\\\u0000\u0005\u00066\u001dZ\u001f\u0001\u0005rb\u000e\u0000\u0001\u0007N";
      C[205] = "\\%3\r9\b[&8\u0015\\_ zg\tm\rZ~-\t5J ==M'\fA1g\u001336";
      C[206] = "+zB2\u0007\u0004(0\u0014\"\u0017jbJ\u001c5EZ,6\u001dmJP\u0012";
      C[207] = "?D{\u001c\u00179l\u0005\u007fX\f_o5yZ\tn=O}\u0010\t6z5$\u001e\u00130}I(\u0001\u00012\u0006";
      C[208] = "|u\u001ft{r*dNu\u000bwsj\u001bi\\ -9B\u0005lfrh\u0004y`y`j";
      C[209] = "J\u00176%f\u0002Q\n4i^\u001a;BpcoKAF:c7\f;\u001cus,\u000bD@5( p";
      C[210] = "+#\u0006*3T}2W+CQ$<\u00027\u0014\u0006{aY[ ^!3[5/\u000e?`";
      C[211] = "Sj8=\u0007{Pfy.;{^\u007f#9WI\r;|o;'\f`1#J/H:s5;";
      C[212] = "\u0005N*2[U\u0004Sjc\u001f;RJ{kLl\u0005\u0016+4\u001f;\u0005\u001b.`CD\u0002KzfY";
      C[213] = "2j)afm:.s#p\u001cn86s|p\\ns.$'\u000blz+t\u007ftk*\u007fre\u000bl+,y t84,{\u001c";
      C[214] = "k\u00041=H{hG0$0b\u0002\u0001f,\u0001:x\u0005,,Y}\u0002^;=Hg}U=;^\u0001";
      C[215] = "\r946\u007f\u001b\u000ez5/\u0007\fd<c'6Z\u001e8)'n\u001dd?9be]\u001bk&bga";
      C[216] = "\u007fX\u0011p*w`\u0000SsM)\u001eAQq=5z\u0001O)r";
      C[217] = "\u0012\u0017##\u001fvR\fd`d!-Co&]*\u0013\u0014`m\bK";
      C[218] = "\\\u0001\u0010\u001cT#\u000b\u0003BE\u0002\u001b\u001b9\u0019O\u000f+[E\u0018\u0017\u0000!e";
      C[219] = "\u0001*t\u0007}~Iq}\fkAQO(\\}p\u00035,\u0016}(DO+\u00068#\u00040\u007f\u00198!8";
      C[220] = "\u007fe$\u0018T->l~[? O6x\u001c\u000er522\u001cV5O=*V\u000fw3<rY\u0005I";
      C[221] = "b\u000e0\u0003s6?U(JqU:I\u0019\u001fl)*2m\u001b+7gM9\u0004+5[";
      C[222] = "<?\u0003F^{n|\t@VJ`*\u0018\u001fX&R~T@\u000ez\u0005#Z\u0015M1z\u007f\u001aNAJ";
      C[223] = "<+~p>r;(uh[/@t*tjw:p`t20@wp19p?#o1;L";
      C[224] = "\u0017J;| <MJh&!D@@;~4\u0013\u001e\u0019h+X;\u0017Ant6#RMl";
      C[225] = "H(Z.a\r\u001d\u007fS+9v\u0018\u007fX\u0017iG\u0018n_x4\u0004\u001at4.1I\u0013/Kz.I\u0011\u0013";
      C[226] = "zNm/C-q\nc'&\u007f@L-<[}/\u0011n>A\u0016";
      C[227] = "=\"\u001e\f{T0%\u001b\u0000BKS L\bs\u001e)$\u0006\b+YS#\u0016M \u0019,w\tM\"%";
      C[228] = "#G/e,?.@*i\u0015#ME}a$u7A7a|2M\u001a pm(2\u0011&v{N";
      C[229] = ".Q\u000eN96wS]A5ZrW\u0010G46@\u0003V\u001aoa\u0017X\u0010Z8:&\u0007\u001dWkZ";
      C[230] = "\u0006?}\u0011H`\u0013za\u00072bj<'\u001b\u00030\u00108m\u001b[wjcz\nJm\u0015h|\f\\\u000b";
      C[231] = "ed1;Edd<>1{u-pho\u0000\u0018m<hv\u0010w0\u007fjl{!52c7\u0004u*2a\u000b";
      C[232] = "U/jO{\u0013Jw(L\u001cD4 mFb\u001aE-jCn";
      C[233] = ".dJe:Zk3Zb='rfV;$K@2\u0012b\u007f\u0017\u00176\u001b zF)a\u0014k/'";
      C[234] = "1\u0002\u007f\fOGmB$\u00004]8@u\u0019Xol\u0004/D4\\kVg\u0005K\u0000+\rk~\b\u00013W-AJ\u00034D\u0015";
      C[235] = "fy\u0011HpQ<zV\f\u0014H5oH\u0014xzd.\u0014L(-ar\u0017\u0011(R5m\u0017\u0013\u0014";
      C[236] = "+X\u0014g\"#jQN$I(\u001b\u000bHcx|a\u000f\u0002c ;\u001b\b\u0012&+{d\\\r&)G";
      C[237] = "U\u0017\u0015\u007f\u00020ZG\u000b,?;[\n\u0011zS\t\u0006MK%?o_FA#Cn\u0007IK\u001d\u00014\u000fM\u0015a[7H\tq";
      C[238] = "EvSgD\u0017\u0000!C`Cj\u0012x^=Q=E \u000bb\fjEvSgD\u0017\u0000!C`C";
      C[239] = "]1o1\u0010^\u0001)m1tD\r?m/\u0018vPx=yt^Y#5&\u001aF\u001c/7H";
      C[240] = "A/piRx\u0004x`nU\u0005\u0016!}3GRAy(k\u0010\u0005A/piRx\u0004x`nU";
      C[241] = "\u000f&L<a=\u0014;NpY&~s\nzht\u0004w@z03~-\u000fj+4\u0001qO1'O";
      C[242] = "\f\u0019\u001c\u001b-xQB\u0004R/\u001bZH\u0004%0WXK\u0011\u001f.g5\u001cI\u000b7pZA\n\t-\u001b\f\u0014\u0011\u001f!tQW\u0013\u0005J\"\u0004L\u0005\t%\u007fGN\u001fb";
      C[243] = "r\t\u0016(\u000f[ J\u001c.\u0007j.\u001c\rq\t\u0006\u001cLO/QjrOIm\u000b\b-J\nk\rj";
      C[244] = "\u0004xi\u0019M&@/e\u0019RA\\?u\u0007J=Z9\u0018\u0017_?G2~B]\u007f[C";
      C[245] = "[~~\u0004X<\u0000{n\bK\u0002\u00014iSN\u0002]|w_\n=\u001f~pL2>X#z\f\r|Z$i4\u000e;\u0007.)\u000bL9\u0000=\u0011";
      C[246] = "k\u0000\u007f:aghC~#\u0019q\u0002\u0005(+(&x\u0001b+pa\u0002\u0002a3`y}^y1`\u001d";
      C[247] = "v|\u0012j\u0004z)q\u001f9d.y|\u000ff\b\u001c-?P1XKp>\u0005s\u001f4,~^\u007fd";
      C[248] = "M\u000ftz/\"NFu#4X\u001e>!$?iOD%n?1\b>\"}>'OQet\u007fh\b>";
      C[249] = "\u0001\u001fCW\u0000\u0002G[Y\u0003aR\u001a\tBV6\u0005C\\\u001d\u0004a\u0001\t\u0006_^\u001e]\u0011\u0004_";
      C[250] = "&48~42)d&-\t9()<{e\u000b|ee%3\\|n-xg;89!xx\\";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = C[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(D[var4]);
            C[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = C[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            C[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  C[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(127799644440120L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = C[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  C[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(127799644440120L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        C[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(127799644440120L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 199;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 222;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 210;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 119;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 73;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 72;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 199;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 222;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 210;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eg_C0230",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoSafeCart var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eg_C0230;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eg_C0230", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoSafeCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Comparator invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "compare",
                  SourceSupport.methodType("()Ljava/util/Comparator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)I", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/eg_C0230",
                     "lambda$scanThreats$1",
                     "(Ldev/zprestige/prestige/gg_C0338;Ldev/zprestige/prestige/gg_C0338;)I"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gg_C0338;Ldev/zprestige/prestige/gg_C0338;)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Comparator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Runnable invokeBinding3(SafeCartPlacementTarget var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gf_C0336;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/eg_C0230", "lambda$place$2", "(Ldev/zprestige/prestige/gf_C0336;)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((SafeCartPlacementTarget)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static BiFunction invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/BiFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "java/lang/Integer", "sum", "(II)I"),
                  SourceSupport.methodType("(Ljava/lang/Integer;Ljava/lang/Integer;)Ljava/lang/Integer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding5(Set var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ljava/util/Set;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eg_C0230", "lambda$pruneCarts$3", "(Ljava/util/Set;Ljava/util/UUID;)Z"
                  ),
                  SourceSupport.methodType("(Ljava/util/UUID;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Set)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(long var0) {
         MethodHandle var6 = bindingCache6;
         MethodHandle var5 = bindingCache6;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(J)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eg_C0230", "lambda$pruneCarts$4", "(JLdev/zprestige/prestige/ge_C0334;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ge_C0334;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var3.invokeExact((long)var0);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
