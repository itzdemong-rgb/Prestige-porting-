package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.KeyBindingAccessor;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.ShieldEntityEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AutoShield extends Module {
   private FloatSetting a;
   private FloatSetting c;
   private FloatSetting d;
   private FloatSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private ElapsedTimer h;
   private ElapsedTimer i;
   private ElapsedTimer j;
   private boolean k;
   public static boolean l;
   private static final long m = 94876005962654L;
   private static final long[] n;
   private static final Integer[] o;
   private static final Map p = new HashMap(13);
   private static final Object[] q = new Object[117];
   private static final String[] r = new String[117];
   private static volatile MethodHandle bindingCache1;

   public AutoShield() {
      super();
      long var10001 = 110265382910141L ^ 5788396851092L;
      var10001 = 110265382910141L ^ 57760337359633L;

      this.h = new ElapsedTimer(106698256430889L);
      this.i = new ElapsedTimer(106698256430889L);
      this.j = new ElapsedTimer(106698256430889L);
      this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
      BooleanSetting var10000 = this.g;
      Object[] var8 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var7 = var10000;
      var7.aReturningBooleanSetting(var8);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      AutoShield var136;
      label193: {
         int var24;
         Object var137;
         long var10001 = 71749273970370L ^ 88898351570262L;
         var10001 = 71749273970370L ^ 89739400208537L;
         var10001 = 71749273970370L ^ 70107337994454L;
         var10001 = 71749273970370L ^ 48749377678781L;
         var10001 = 71749273970370L ^ 19895154042788L;
         var10001 = 71749273970370L ^ 21854802775596L;
         var10001 = 71749273970370L ^ 53456362041195L;
         var10001 = 71749273970370L ^ 83308733445564L;
         var10001 = 71749273970370L ^ 85713913249910L;
         var10001 = 71749273970370L ^ 89025295612286L;
         var24 = Event.bReturningInt();
         int var171 = var24;
         AutoShield var170 = this;
         var137 = var170;
         AutoShield var133 = var170;
         label173:
         if (var171 == 0) {
            label181: {
               boolean var172 = var133.k;
               if (var172) {
                  int var174 = var24;
                  AutoShield var173 = this;
                  var136 = var173;
                  AutoShield var134 = var173;
                  if (var174 != 0) {
                     break label193;
                  }

                  AutoShield var175 = var134;
                  AutoShield var135 = var175;
                  ElapsedTimer var10000 = var135.j;
                  Object[] var10004 = new Object[]{null, 139098136696340L};
                  var10004[0] = 5000.0F;
                  Object[] var30 = var10004;
                  ElapsedTimer var29 = var10000;
                  boolean var176 = var29.aReturningBoolean(var30);
                  if (!var176) {
                     break label181;
                  }

                  this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  l = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  int var177 = var24;
                  if (var177 != 0) {
                     break label181;
                  }
               }

               FloatSetting var36 = this.c;
               var137 = var36.aReturningObject();
               break label173;
            }

            AutoShield var178 = this;
            var136 = var178;
            break label193;
         }

         Float var37 = (Float)var137;
         float var242 = var37;
         Object[] var10003 = new Object[]{null, 11569543664510L};
         var10003[0] = var242;
         Object[] var38 = var10003;
         PlayerEntity var25 = EntityUtil.bReturningPlayerEntity(var38);
         ElapsedTimer var243 = this.i;
         Object[] var264 = new Object[]{null, 139098136696340L};
         var264[0] = 100.0F;
         Object[] var40 = var264;
         ElapsedTimer var39 = var243;
         boolean var179 = var39.aReturningBoolean(var40);
         if (!var179) {
            return;
         }

         PlayerEntity var180 = var25;
         if (var180 == null) {
            Object[] var43 = new Object[]{13974727222964L};
            AutoShield var42 = this;
            var42.lReturningVoid(var43);
            return;
         }

         MinecraftClient var45 = b;
         int var182 = var24;
         ClientPlayerEntity var181 = var45.player;
         ClientPlayerEntity var139 = var181;
         ClientPlayerEntity var138 = var181;
         if (var182 == 0) {
            PlayerEntity var47 = var25;
            ClientPlayerEntity var46 = var138;
            var242 = var46.distanceTo((Entity)var47);
            FloatSetting var48 = this.a;
            Float var49 = (Float)var48.aReturningObject();
            float var266;
            int var183 = (var266 = var242 - var49) == 0.0F ? 0 : (var266 < 0.0F ? -1 : 1);
            if (var183 > 0) {
               Object[] var52 = new Object[]{13974727222964L};
               AutoShield var51 = this;
               var51.lReturningVoid(var52);
               return;
            }

            MinecraftClient var54 = b;
            var139 = var54.player;
         }

         label197: {
            byte var146;
            label163: {
               label190: {
                  ClientPlayerEntity var55 = var139;
                  ItemStack var56 = var55.getMainHandStack();
                  Item var245 = var56.getItem();
                  int var186 = var24;
                  Item var185 = Items.SHIELD;
                  Item var184 = var245;
                  Item var142 = var184;
                  Item var143 = var185;
                  Item var140 = var184;
                  Item var141 = var185;
                  if (var186 == 0) {
                     Item var188 = var141;
                     Item var187 = var140;
                     if (var187 == var188) {
                        break label190;
                     }

                     MinecraftClient var58 = b;
                     ClientPlayerEntity var59 = var58.player;
                     ItemStack var60 = var59.getOffHandStack();
                     Item var246 = var60.getItem();
                     Item var190 = Items.SHIELD;
                     Item var189 = var246;
                     var142 = var189;
                     var143 = var190;
                  }

                  Item var192 = var143;
                  Item var191 = var142;
                  if (var191 != var192) {
                     break label197;
                  }

                  Object[] var62 = new Object[]{119946435234687L};
                  byte var247 = ((byte)((ItemUseUtil.eReturningBoolean(var62)) ? 1 : 0));
                  int var194 = var24;
                  byte var193 = var247;
                  var146 = var193;
                  byte var144 = var193;
                  if (var194 != 0) {
                     break label163;
                  }

                  byte var195 = var144;
                  byte var145 = var195;
                  byte var196 = var145;
                  if (var196 != 0) {
                     break label197;
                  }
               }

               Object[] var68 = new Object[]{18551992649307L};
               var146 = ((byte)((RaycastUtil.aReturningBoolean(var68)) ? 1 : 0));
            }

            int var198 = var24;
            byte var197 = var146;
            byte var148 = var197;
            byte var147 = var197;
            if (var198 == 0) {
               byte var199 = var147;
               if (var199 != 0) {
                  Object[] var71 = new Object[]{13974727222964L};
                  AutoShield var70 = this;
                  var70.lReturningVoid(var71);
                  return;
               }

               PlayerEntity var73 = var25;
               ItemStack var74 = var73.getMainHandStack();
               var148 = ((byte)((var74.getItem() instanceof AxeItem) ? 1 : 0));
            }

            int var201 = var24;
            byte var200 = var148;
            byte var150 = var200;
            byte var149 = var200;
            if (var201 == 0) {
               byte var202 = var149;
               if (var202 != 0) {
                  Object[] var77 = new Object[]{125203304974761L};
                  AutoShield var76 = this;
                  var76.kReturningVoid(var77);
                  return;
               }

               PlayerEntity var79 = var25;
               Object[] var80 = new Object[]{var79.getMainHandStack(), 19476550655932L};
               var150 = ((byte)((InventoryUtil.aReturningBoolean(var80)) ? 1 : 0));
            }

            byte var154;
            int var204 = var24;
            byte var203 = var150;
            var154 = var203;
            byte var151 = var203;
            label145:
            if (var204 == 0) {
               byte var205 = var151;
               if (var205 == 0) {
                  PlayerEntity var82 = var25;
                  Object[] var83 = new Object[]{var82.getMainHandStack(), 91643301200230L};
                  byte var248 = ((byte)((InventoryUtil.o(var83)) ? 1 : 0));
                  int var207 = var24;
                  byte var206 = var248;
                  var154 = var206;
                  byte var152 = var206;
                  if (var207 != 0) {
                     break label145;
                  }

                  byte var208 = var152;
                  byte var153 = var208;
                  byte var209 = var153;
                  if (var209 == 0) {
                     Object[] var87 = new Object[]{125203304974761L};
                     AutoShield var86 = this;
                     var86.kReturningVoid(var87);
                     return;
                  }
               }

               ElapsedTimer var249 = this.h;
               FloatSetting var89 = this.e;
               Float var90 = (Float)var89.aReturningObject();
               float var263 = 625.0F * (0.94F - var90 / 100.0F);
               var264 = new Object[]{null, 139098136696340L};
               var264[0] = var263;
               Object[] var92 = var264;
               ElapsedTimer var91 = var249;
               var154 = ((byte)((var91.aReturningBoolean(var92)) ? 1 : 0));
            }

            int var160;
            byte var26 = var154;
            MinecraftClient var93 = b;
            ClientPlayerEntity var94 = var93.player;
            byte var250 = ((byte)((var94.isOnGround()) ? 1 : 0));
            int var211 = var24;
            byte var210 = var250;
            var160 = var210;
            byte var155 = var210;
            label137:
            if (var211 == 0) {
               byte var212 = var155;
               if (var212 == 0) {
                  MinecraftClient var96 = b;
                  ClientPlayerEntity var97 = var96.player;
                  double var267;
                  int var251 = (var267 = var97.fallDistance - 0.0) == 0.0 ? 0 : (var267 < 0.0 ? -1 : 1);
                  int var214 = var24;
                  int var213 = var251;
                  var160 = var213;
                  int var156 = var213;
                  if (var214 != 0) {
                     break label137;
                  }

                  int var215 = var156;
                  int var157 = var215;
                  int var216 = var157;
                  if (var216 > 0) {
                     MinecraftClient var100 = b;
                     float var102 = 0.0F;
                     ClientPlayerEntity var101 = var100.player;
                     float var268;
                     int var252 = (var268 = var101.getAttackCooldownProgress(var102) - 0.94F) == 0.0F ? 0 : (var268 < 0.0F ? -1 : 1);
                     int var218 = var24;
                     int var217 = var252;
                     var160 = var217;
                     int var158 = var217;
                     if (var218 != 0) {
                        break label137;
                     }

                     int var219 = var158;
                     int var159 = var219;
                     int var220 = var159;
                     if (var220 > 0) {
                        Object[] var106 = new Object[]{125203304974761L};
                        AutoShield var105 = this;
                        var105.kReturningVoid(var106);
                        int var221 = var24;
                        if (var221 == 0) {
                           return;
                        }
                     }
                  }
               }

               byte var222 = var26;
               var160 = var222;
            }

            int var167;
            int var224 = var24;
            int var223 = var160;
            var167 = var223;
            int var161 = var223;
            label124:
            if (var224 == 0) {
               int var225 = var161;
               label122:
               if (var225 != 0) {
                  int var227 = var24;
                  AutoShield var226 = this;
                  AutoShield var166 = var226;
                  AutoShield var162 = var226;
                  if (var227 == 0) {
                     AutoShield var228 = var162;
                     AutoShield var163 = var228;
                     Object[] var112 = new Object[]{var25, 19358211799956L};
                     AutoShield var111 = var163;
                     boolean var229 = var111.aReturningBoolean(var112);
                     if (!var229) {
                        MinecraftClient var114 = b;
                        PlayerEntity var116 = var25;
                        ClientPlayerEntity var115 = var114.player;
                        float var269;
                        int var253 = (var269 = var115.distanceTo((Entity)var116) - 3.0F) == 0.0F ? 0 : (var269 < 0.0F ? -1 : 1);
                        int var231 = var24;
                        int var230 = var253;
                        var167 = var230;
                        int var164 = var230;
                        if (var231 != 0) {
                           break label124;
                        }

                        int var232 = var164;
                        int var165 = var232;
                        int var233 = var165;
                        if (var233 > 0) {
                           break label122;
                        }
                     }

                     var166 = this;
                  }

                  Object[] var120 = new Object[]{90851883444462L};
                  AutoShield var119 = var166;
                  var119.jReturningVoid(var120);
                  int var234 = var24;
                  if (var234 == 0) {
                     return;
                  }
               }

               MinecraftClient var121 = b;
               ClientPlayerEntity var122 = var121.player;
               byte var235 = ((byte)((var122.isOnGround()) ? 1 : 0));
               var167 = var235;
            }

            label109: {
               int var237 = var24;
               int var236 = var167;
               int var169 = var236;
               int var168 = var236;
               if (var237 == 0) {
                  int var238 = var168;
                  if (var238 != 0) {
                     break label109;
                  }

                  MinecraftClient var125 = b;
                  ClientPlayerEntity var126 = var125.player;
                  double var270;
                  int var239 = (var270 = var126.fallDistance - 0.0) == 0.0 ? 0 : (var270 < 0.0 ? -1 : 1);
                  var169 = var239;
               }

               int var240 = var169;
               if (var240 <= 0) {
                  Object[] var129 = new Object[]{90851883444462L};
                  AutoShield var128 = this;
                  var128.jReturningVoid(var129);
                  int var241 = var24;
                  if (var241 == 0) {
                     return;
                  }
               }
            }

            Object[] var132 = new Object[]{125203304974761L};
            AutoShield var131 = this;
            var131.kReturningVoid(var132);
            return;
         }

         Object[] var66 = new Object[]{13974727222964L};
         AutoShield var65 = this;
         var65.lReturningVoid(var66);
         return;
      }

      Object[] var35 = new Object[]{13974727222964L};
      AutoShield var34 = var136;
      var34.lReturningVoid(var35);
   }

   @EventListener
   public void a(ShieldEntityEvent var1) {
      long var10001 = 108706994575648L ^ 74951565422880L;
      var10001 = 108706994575648L ^ 121409857470356L;
      var10001 = 108706994575648L ^ 38664357157974L;
      var10001 = 108706994575648L ^ 126894492731036L;
      int var12 = Event.bReturningInt();
      BooleanSetting var14 = this.f;
      Boolean var15 = (Boolean)var14.aReturningObject();
      boolean var40 = var15;
      if (var40) {
         int var42 = var12;
         LivingEntity var41 = var1.a;
         Object var35 = var41;
         LivingEntity var34 = var41;
         if (var42 == 0) {
            MinecraftClient var17 = b;
            ClientPlayerEntity var44 = var17.player;
            LivingEntity var43 = var34;
            if (var43 != var44) {
               return;
            }

            ElapsedTimer var10000 = this.j;
            Object[] var21 = new Object[]{42835128969216L};
            ElapsedTimer var20 = var10000;
            var20.aReturningVoid(var21);
            this.k = dev.prestige.recovery.SourceSupport.asBoolean(1);
            l = dev.prestige.recovery.SourceSupport.asBoolean(1);
            Object[] var23 = new Object[]{13974727222964L};
            AutoShield var22 = this;
            var22.lReturningVoid(var23);
            BooleanSetting var24 = this.g;
            var35 = var24.aReturningObject();
         }

         Boolean var25 = (Boolean)var35;
         byte var55 = ((byte)(((java.lang.Boolean)(var25)).booleanValue() ? 1 : 0));
         int var46 = var12;
         byte var45 = var55;
         byte var37 = var45;
         byte var36 = var45;
         if (var46 == 0) {
            byte var47 = var36;
            if (var47 == 0) {
               return;
            }

            var37 = 0;
         }

         int var13 = var37;

         int var54;
         do {
            byte var49 = 9;
            int var48 = var13;
            if (var48 >= var49) {
               break;
            }

            label37: {
               MinecraftClient var27 = b;
               ClientPlayerEntity var28 = var27.player;
               PlayerInventory var56 = var28.getInventory();
               int var30 = var13;
               PlayerInventory var29 = var56;
               Object[] var31 = new Object[]{var29.getStack(var30), 19476550655932L};
               var55 = ((byte)((InventoryUtil.aReturningBoolean(var31)) ? 1 : 0));
               int var51 = var12;
               byte var50 = var55;
               int var39 = var50;
               byte var38 = var50;
               if (var51 == 0) {
                  byte var52 = var38;
                  if (var52 == 0) {
                     break label37;
                  }

                  var39 = var13;
               }

               Object[] var10003 = new Object[]{null, 72518082610550L};
               var10003[0] = var39;
               Object[] var33 = var10003;
               InventoryUtil.aReturningVoid(var33);
               int var53 = var12;
               if (var53 == 0) {
                  break;
               }
            }

            var13++;
            var54 = var12;
         } while (var54 == 0);
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 55729177400442L ^ 22377341123706L;
      var10001 = 55729177400442L ^ 61756451374852L;
      int var8 = Event.bReturningInt();
      MinecraftClient var12 = b;
      ClientWorld var46 = var12.world;
      if (var46 != null) {
         Object[] var15 = new Object[0];
         PacketReceiveEvent var14 = var1;
         byte var10000 = ((byte)((var14.aReturningVoid(var15) instanceof PlayerRespawnS2CPacket) ? 1 : 0));
         int var48 = var8;
         byte var47 = var10000;
         byte var39 = var47;
         byte var38 = var47;
         if (var48 == 0) {
            byte var49 = var38;
            if (var49 != 0) {
               this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
               l = dev.prestige.recovery.SourceSupport.asBoolean(0);
               return;
            }

            Object[] var19 = new Object[0];
            PacketReceiveEvent var18 = var1;
            var39 = ((byte)((var18.aReturningVoid(var19) instanceof EntityAnimationS2CPacket) ? 1 : 0));
         }

         int var51 = var8;
         byte var50 = var39;
         int var41 = var50;
         byte var40 = var50;
         if (var51 == 0) {
            byte var52 = var40;
            if (var52 == 0) {
               return;
            }

            Object[] var22 = new Object[0];
            PacketReceiveEvent var21 = var1;
            EntityAnimationS2CPacket var23 = (EntityAnimationS2CPacket)var21.aReturningVoid(var22);
            int var53 = var23.getEntityId();
            var41 = var53;
         }

         int var9 = var41;
         MinecraftClient var25 = b;
         int var27 = var9;
         ClientWorld var26 = var25.world;
         Entity var10 = var26.getEntityById(var27);
         int var55 = var8;
         Entity var54 = var10;
         Object var43 = var54;
         Entity var42 = var54;
         if (var55 == 0) {
            boolean var56 = var42 instanceof PlayerEntity;
            if (!var56) {
               return;
            }

            FloatSetting var29 = this.c;
            Object var57 = var29.aReturningObject();
            var43 = var57;
         }

         Float var31 = (Float)var43;
         float var62 = var31;
         Object[] var10003 = new Object[]{null, 11569543664510L};
         var10003[0] = var62;
         Object[] var32 = var10003;
         PlayerEntity var11 = EntityUtil.bReturningPlayerEntity(var32);
         int var59 = var8;
         PlayerEntity var58 = var11;
         PlayerEntity var45 = var58;
         PlayerEntity var44 = var58;
         if (var59 == 0) {
            PlayerEntity var60 = var44;
            if (var60 == null) {
               return;
            }

            var45 = var11;
         }

         Entity var35 = var10;
         PlayerEntity var34 = var45;
         boolean var61 = var34.equals(var35);
         if (var61) {
            ElapsedTimer var63 = this.h;
            Object[] var37 = new Object[]{42835128969216L};
            ElapsedTimer var36 = var63;
            var36.aReturningVoid(var37);
         }
      }
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 116420753476158L ^ 86960286900798L;
      int var6 = Event.bReturningInt();
      int var15 = var6;
      if (var15 == 0) {
         MinecraftClient var7 = b;
         ClientPlayerEntity var8 = var7.player;
         boolean var16 = var8.isUsingItem();
         if (var16) {
            Object[] var11 = new Object[0];
            AttackEntityEvent var10 = var1;
            var10.aReturningVoid(var11);
         }

         ElapsedTimer var10000 = this.i;
         Object[] var14 = new Object[]{42835128969216L};
         ElapsedTimer var13 = var10000;
         var13.aReturningVoid(var14);
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 94876005962654L ^ var3;
      long var5 = var3 ^ 106188333357017L;
      long var7 = var3 ^ 53244309043815L;
      int var10000 = Event.cReturningInt();
      PlayerEntity var17 = var2;
      double var10003 = var17.getX();
      PlayerEntity var18 = var2;
      var10003 -= var18.lastX;
      PlayerEntity var19 = var2;
      double var10004 = var19.getY();
      PlayerEntity var20 = var2;
      var10004 -= var20.lastY;
      PlayerEntity var21 = var2;
      double var10005 = var21.getZ();
      PlayerEntity var22 = var2;
      Vec3d var10 = new Vec3d(var10003, var10004, var10005 - var22.lastZ);
      int var9 = var10000;
      Vec3d var23 = var10;
      double var11 = var23.length();
      FloatSetting var24 = this.d;
      Float var25 = (Float)var24.aReturningObject();
      double var53;
      var10000 = (var53 = var11 - var25 / 10.0F) == 0.0 ? 0 : (var53 < 0.0 ? -1 : 1);
      int var41 = var9;
      int var40 = var10000;
      int var36 = var40;
      int var35 = var40;
      if (var41 != 0) {
         int var42 = var35;
         if (var42 >= 0) {
            Object[] var27 = new Object[]{var5};
            Vec3d var49 = RaycastUtil.bReturningVec3d(var27);
            Object[] var28 = new Object[]{var2, var7};
            Vec3d var30 = RaycastUtil.aReturningVec3d(var28);
            Vec3d var29 = var49;
            Vec3d var31 = var29.subtract(var30);
            Vec3d var13 = var31.normalize();
            Vec3d var32 = var10;
            Vec3d var14 = var32.normalize();
            Vec3d var34 = var13;
            Vec3d var33 = var14;
            double var15 = var33.dotProduct(var34);
            double var54;
            var10000 = (var54 = var15 - 0.0) == 0.0 ? 0 : (var54 < 0.0 ? -1 : 1);
            int var44 = var9;
            int var43 = var10000;
            int var38 = var43;
            int var37 = var43;
            if (var44 != 0) {
               int var45 = var37;
               if (var45 <= 0) {
                  return false;
               }

               var38 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var38);
         }

         var36 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var36);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 26377487695830L;
      this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
      l = dev.prestige.recovery.SourceSupport.asBoolean(0);
      Object[] var7 = new Object[]{var4};
      AutoShield var6 = this;
      var6.lReturningVoid(var7);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 94876005962654L ^ var2;
      MinecraftClient var4 = b;
      GameOptions var5 = var4.options;
      KeyBinding var6 = var5.useKey;
      var6.setPressed(true);
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 94876005962654L ^ var2;
      MinecraftClient var4 = b;
      GameOptions var5 = var4.options;
      KeyBinding var6 = var5.useKey;
      var6.setPressed(false);
   }

   private void lReturningVoid(Object[] var1) {
      int var8;
      label40: {
         int var45;
         label39: {
            int var44;
            label42: {
               long var2 = (Long)var1[0];
               var2 = 94876005962654L ^ var2;
               long var4 = var2 ^ 64399680762833L;
               int var10000 = Event.bReturningInt();
               MinecraftClient var9 = b;
               GameOptions var10 = var9.options;
               KeyBindingAccessor var10001 = new KeyBindingAccessor(var10.useKey);
               Object[] var12 = new Object[]{var4};
               KeyBindingAccessor var11 = var10001;
               Key var13 = var11.aReturningVoid(var12);
               int var7 = var13.getCode();
               int var6 = var10000;
               short var72 = 2405;
               long var10002 = 1103198724599428228L ^ var2;
               int var48 = var6;
               byte var47 = 8;
               int var46 = var7;
               int var42 = var46;
               byte var43 = var47;
               int var34 = var46;
               byte var35 = var47;
               if (var48 == 0) {
                  byte var50 = var35;
                  int var49 = var34;
                  if (var49 < var50) {
                     MinecraftClient var15 = b;
                     Window var16 = var15.getWindow();
                     long var68 = var16.getHandle();
                     int var19 = var7;
                     long var17 = var68;
                     var10000 = GLFW.glfwGetMouseButton(var17, var19);
                     int var52 = var6;
                     int var51 = var10000;
                     int var38 = var51;
                     int var36 = var51;
                     int var39;
                     if (var52 == 0) {
                        int var53 = var36;
                        int var37 = var53;
                        byte var55 = 1;
                        int var54 = var37;
                        if (var54 == var55) {
                           byte var56 = 1;
                           var39 = var56;
                        } else {
                           var39 = 0;
                        }
                     } else {
                        int var57 = var38;
                        var39 = var57;
                     }

                     var8 = var39;
                     int var58 = var6;
                     if (var58 == 0) {
                        break label40;
                     }
                  }

                  MinecraftClient var23 = b;
                  Window var24 = var23.getWindow();
                  long var70 = var24.getHandle();
                  int var27 = var7;
                  long var25 = var70;
                  var10000 = GLFW.glfwGetKey(var25, var27);
                  int var60 = var6;
                  int var59 = var10000;
                  var44 = var59;
                  int var40 = var59;
                  if (var60 != 0) {
                     break label42;
                  }

                  int var61 = var40;
                  int var41 = var61;
                  byte var63 = 1;
                  int var62 = var41;
                  var42 = var62;
                  var43 = var63;
               }

               byte var65 = var43;
               int var64 = var42;
               if (var64 != var65) {
                  var45 = 0;
                  break label39;
               }

               var44 = 1;
            }

            int var66 = var44;
            var45 = var66;
         }

         var8 = var45;
      }

      MinecraftClient var30 = b;
      GameOptions var31 = var30.options;
      int var33 = var8;
      KeyBinding var32 = var31.useKey;
      var32.setPressed(dev.prestige.recovery.SourceSupport.asBoolean(var33));
   }

   private boolean lambda$new$0(Boolean var1) {
      BooleanSetting var4 = this.f;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(137583116883271L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "dø\u009eT¬ô¤!l´í!Þf\u0081ô";
      int var7 = "dø\u009eT¬ô¤!l´í!Þf\u0081ô".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      n = var8;
      o = new Integer[2];
      l = dev.prestige.recovery.SourceSupport.asBoolean(0);
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 18635;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])p.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eh", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         o[var3] = var15;
      }

      return o[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eh_C0232",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = r[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = q[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 6;
            yield var15;
         }
         case 1 -> {
            byte var16 = 16;
            yield var16;
         }
         case 2 -> {
            byte var17 = 42;
            yield var17;
         }
         case 3 -> {
            byte var18 = 25;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 47;
            yield var20;
         }
         case 6 -> {
            byte var21 = 17;
            yield var21;
         }
         case 7 -> {
            byte var22 = 0;
            yield var22;
         }
         case 8 -> {
            byte var23 = 56;
            yield var23;
         }
         case 9 -> {
            byte var24 = 40;
            yield var24;
         }
         case 10 -> {
            byte var25 = 46;
            yield var25;
         }
         case 11 -> {
            byte var26 = 26;
            yield var26;
         }
         case 12 -> {
            byte var27 = 36;
            yield var27;
         }
         case 13 -> {
            byte var28 = 63;
            yield var28;
         }
         case 14 -> {
            byte var29 = 49;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 9;
            yield var32;
         }
         case 18 -> {
            byte var33 = 14;
            yield var33;
         }
         case 19 -> {
            byte var34 = 20;
            yield var34;
         }
         case 20 -> {
            byte var35 = 5;
            yield var35;
         }
         case 21 -> {
            byte var36 = 43;
            yield var36;
         }
         case 22 -> {
            byte var37 = 39;
            yield var37;
         }
         case 23 -> {
            byte var38 = 62;
            yield var38;
         }
         case 24 -> {
            byte var39 = 18;
            yield var39;
         }
         case 25 -> {
            byte var40 = 29;
            yield var40;
         }
         case 26 -> {
            byte var41 = 32;
            yield var41;
         }
         case 27 -> {
            byte var42 = 59;
            yield var42;
         }
         case 28 -> {
            byte var43 = 60;
            yield var43;
         }
         case 29 -> {
            byte var44 = 57;
            yield var44;
         }
         case 30 -> {
            byte var45 = 22;
            yield var45;
         }
         case 31 -> {
            byte var46 = 58;
            yield var46;
         }
         case 32 -> {
            byte var47 = 15;
            yield var47;
         }
         case 33 -> {
            byte var48 = 19;
            yield var48;
         }
         case 34 -> {
            byte var49 = 13;
            yield var49;
         }
         case 35 -> {
            byte var50 = 50;
            yield var50;
         }
         case 36 -> {
            byte var51 = 53;
            yield var51;
         }
         case 37 -> {
            byte var52 = 37;
            yield var52;
         }
         case 38 -> {
            byte var53 = 44;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 12;
            yield var55;
         }
         case 41 -> {
            byte var56 = 54;
            yield var56;
         }
         case 42 -> {
            byte var57 = 4;
            yield var57;
         }
         case 43 -> {
            byte var58 = 11;
            yield var58;
         }
         case 44 -> {
            byte var59 = 3;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 10;
            yield var61;
         }
         case 47 -> {
            byte var62 = 24;
            yield var62;
         }
         case 48 -> {
            byte var63 = 51;
            yield var63;
         }
         case 49 -> {
            byte var64 = 2;
            yield var64;
         }
         case 50 -> {
            byte var65 = 7;
            yield var65;
         }
         case 51 -> {
            byte var66 = 35;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 21;
            yield var68;
         }
         case 54 -> {
            byte var69 = 48;
            yield var69;
         }
         case 55 -> {
            byte var70 = 1;
            yield var70;
         }
         case 56 -> {
            byte var71 = 52;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 33;
            yield var73;
         }
         case 59 -> {
            byte var74 = 30;
            yield var74;
         }
         case 60 -> {
            byte var75 = 34;
            yield var75;
         }
         case 61 -> {
            byte var76 = 41;
            yield var76;
         }
         case 62 -> {
            byte var77 = 8;
            yield var77;
         }
         default -> 28;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            r[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      q[0] = "\u0007\u00115-~\b\u0007\u0011\"qr\u0007\u001dZ\"or\u0012\u001a+r2#";
      q[1] = "\u0019|o~&0\u0019|x\"*?\u00037x<**\u0004F(a~";
      q[2] = "\u00061\u0015\"=W\u00061\u0002~1X\u001cz\u0002`1M\u001b\u000bR<d";
      q[3] = boolean.class;
      r[3] = "java/lang/Boolean";
      q[4] = void.class;
      r[4] = "java/lang/Void";
      q[5] = "uze4v\bcz`ne\u001ft1chi\u000bevt\u007f\"\u0019T";
      q[6] = int.class;
      r[6] = "java/lang/Integer";
      q[7] = "M0\u000b\u000el\u000eM0\u001cR`\u0001W{\u001cL`\u0014P\nH\u00147";
      q[8] = "5vFgN\u007f5vQ;Bp/=Q%Be(L\u0003\u007f\u0015'";
      q[9] = "\u0001mn E.\u0017mkzV9\u0000&h|Z-\u0011a\u007fk\u0011;\r";
      q[10] = "\u0017tlB :bTgM1u\u0003ZlF5/w";
      q[11] = "\rDXia[\u001bD]3rL\f\u000f^5~X\u001dHI\"5H\u0006";
      q[12] = "-5,4g&X\u0015';vi9\u001b,0r3M";
      q[13] = "\u001a\u0011@_\u00017\u0011\u001eQ\u0010m4\u001f\u001cS_A";
      q[14] = "[W<Kh}[W+\u0017drA\u001c+\tdgFmyR<-";
      q[15] = "\u0004\u001eR2\u001aP\u0012\u001eWh\tG\u0005UTn\u0005S\u0014\u0012CyND&";
      q[16] = "YY\"\tg\u0003RV3F\u0006\rY]7\u001c";
      q[17] = "O}k}\u0001\u001cY}n'\u0012\u000bN6m!\u001e\u001f_qz6U\nr";
      q[18] = "\rF\"J]$xf)ELk\u0019h\"NH1m";
      q[19] = "mGf/$\u0004fHw`G\tsEx\u000br\u000bbVd'e\u0006";
      q[20] = "\fdo\u000ewCyDd\u0001f\f\u0018Jo\nbVl";
      q[21] = "q:Gn`\u0017\u0004\u001aLaqXe\u0014Gju\u0002\u0011";
      q[22] = "\u0007-k/J7\u0019%q`7'\u0019";
      q[23] = "~\u000bG\b\\\"h\u000bBRO5\u007f@ATC!n\u0007VC\b1)";
      q[24] = "4@e`f\u0010A`now_ neds\u0005T";
      q[25] = "POBeGhPOU9KgJ\u0004U'KrMu\u0004\u007f\u0019";
      q[26] = "qBEy~WqBR%rXk\tR;rMlx\u0000a&\t";
      q[27] = double.class;
      r[27] = "java/lang/Double";
      q[28] = "Os&Rr\u001b:S-]cT[]&Vg\u000e/";
      q[29] = "A *8;{J/;wS{D (";
      q[30] = float.class;
      r[30] = "java/lang/Float";
      q[31] = "\u0017v6HV9\u0017v!\u0014Z6\r=!\nZ#\nLtU\u0003";
      q[32] = "OY\u001aZq9OY\r\u0006}6U\u0012\r\u0018}#Rc_F%g";
      q[33] = "rbj]k#rb}\u0001g,h)}\u001fg9oX,E7|";
      q[34] = ")PDS\u0005\u0012?PA\t\u0016\u0005(\u001bB\u000f\u001a\u00119\\U\u0018Q\u0000)";
      q[35] = "p\u001exXUu\u0005>sWD:d0x\\@`\u0010";
      q[36] = "\\\n[ZJR\\\nL\u0006F]FAL\u0018FHA0\u001dA\u001e\r";
      q[37] = "K}O/e\u001d]}Juv\nJ6Isz\u001e[q^d1\u000bz";
      q[38] = "a\u001efP3P\u0014>m_\"\u001fu0fT&E\u0001";
      q[39] = "hd\u000e8r*hd\u0019d~%r/\u0019z~0u^K&+r";
      q[40] = long.class;
      r[40] = "java/lang/Long";
      q[41] = "\bOf\u0016^-\u001eOcLM:\t\u0004`JA.\u0018Cw]\n\u0011";
      q[42] = "W0?=9@\"\u001042(\u000fC\u001e?9,U7";
      q[43] = "p\b0}}{p\b'!qtjC'?qam2we'':\u000e(2caA^te";
      q[44] = " ,\\>\u0002f%9W>\t}))\u0015W\"W\u0018";
      q[45] = "\b\u000b{\u0014\u001du\u001e\u000b~N\u000eb\t@}H\u0002v\u0018\u0007j_Ia$";
      q[46] = "Oo_\b_V:OT\u0007N\u0019[A_\fJC/";
      q[47] = "#r\u000b+wfVR\u0000$f)7\\\u000b/bsC";
      q[48] = "x\u0000Z)5V\r Q&$\u0019l.Z- C\u0018";
      q[49] = "*u\u00052\u000bH*u\u0012n\u0007G0>\u0012p\u0007R7O@+_\u0013";
      q[50] = "A 3\u0004cVA $XoY[k$FoL\\\u001av\u0012>\r";
      q[51] = "\u0006<P0=\u001es\u001c[?,Q\u0012\u0012P4(\u000bf";
      q[52] = "4(AUN,A\bJZ_c \u0006AQ[9T";
      q[53] = "\u0016\u0014\u0002tGT\u0000\u0014\u0007.TC\u0017_\u0004(XW\u0006\u0018\u0013?\u0013G\u001e";
      q[54] = "|;UW\u007fk\t\u001b^Xn$h\u0015USj~\u001c";
      q[55] = ">CD#uJKcO,d\u0005*mD'`_^";
      q[56] = "v\n0\f[)\u0003*;\u0003Jfb$0\bN<\u0016";
      q[57] = "g\u001e}\u000ea\r;\u0003-G\u0018\u00177\u000f \u0019t%aJ}B(rdI|\u001de\u0012jK9N\u0018";
      q[58] = "mk`\u001d&zomr[Iu\u00132%]&nb;}N$y\u0013u\u007f^usuwyL3\u001c";
      q[59] = "5uOJLz8<\u001eZ=y${@MQKp;\u001c\u0016= 0}\\VOv6=N*";
      q[60] = "[\u0019j\u001cp\u0015\u0007\u0004:U\t\u000f\u000b\b7\u000be=\\HgV9j\\\u001f*\u0006s\u0007\u0003\u000e1\u0011\t";
      q[61] = "dpH\u001fG\u000f9zX\\(\u0011Z#\u001f^G\u0001+*GME\u0016Z!OA\u0018\f#bZ\u001eRs";
      q[62] = "r\u0019[yU\u007f/\u0013K::`LJ\f8Uq=CT+WfLH\\'\n|5\u000bIx@\u0003";
      q[63] = "A\u001c|8\f\u0019CMs9i\u0006IXu;\u00054\u0014\u0018+mi_]^i \u001b\t[\u001e{\\\f\u0019B\u001al$\u0011\u001dBV\u0015";
      q[64] = "\u0017b4#b/\u0015:>{R%,=>c=>]4fp?),?n|b3U|{#(L";
      q[65] = "YxR \"h\ntL[5xH(S7\u0007/\u000ev\u0004`PoZ!^f?vE'\u000e[";
      q[66] = "TX,\fzs\nH1\u0005\u0010e;\u0003g\u001c\u007f~J\n?\u000f}i;\u00006\u001dzvV_'\u0006m\f";
      q[67] = "H5h\r9\u0014\u001b9vv%\bHab!rW\u0014=\u000eO \u0019A5k\t\"\u0005[";
      q[68] = "ilQs@c4fA0/{W?\u00062@m&6^!BzW=V-\u001f`.~CrU\u001f";
      q[69] = "Pt\u0000~\u007f-\u000ed\u001dw\u00158?/Knz N&\u0013}x7?v\nxgl\\u\u001f+yR";
      q[70] = "$/\ne\u0015X*-O6h]wiVa\u0004o')\r6h\u0004coJz\u001aRe/X\u0006YF'zFzUHdl6";
      q[71] = "ri8A\u0006;!e&:\u001a'r=2mMx/f^_L/{<$]\u001d z";
      q[72] = "h\u001dbkB]4\u00002\";G8\f?|WukH`*;\u0013+M0kG\u001f%\u000e&\u001b";
      q[73] = "2\u0006EM\u001b@t\u0004YW+Kj\u0000QE|\u001c:U\t)\u0012ZdTLU\u0017\u001bbT";
      q[74] = "\t-\\\u0007\u001b}\t/M]|#\u0010%Cs\u001101,AG\u0011\u0006\t7@[\u001aL\u000e:\u0002\u0003\u001c/\u001et\u0001\u0005|p\r1@@\u000e&\u000bqR<@5\u000e7@N\u00163N%<";
      q[75] = "ZF=\u0012\u0004#\u001eG?\u0011B\u001c\u000e\u007fmTBs\u0011\u000ed\fQq\u0006\u007fn\u0005Cv\u0019\u00121\u0014Xac";
      q[76] = "y@\u0019S\fr$J\t\u0010cgGF\u001eR\u0003a.F\u0013\u0005\u0019\u000e+@H\u000e\fg+M\u001f\u0014c";
      q[77] = "\u0000J?\bN:\u0003_l\u0016p<\rM5\u001d\u001c\u000eY\toBp9\u001b['D\u0013:\u000e\b9z\u0010\"\nCk\u0019\u00137Y]U";
      q[78] = "\u000b\u0017m\u0007\u0007>\u0018B<Ha5r\u00158\t\u000e-\u0003\u001c`\u001a\f:rM;N\u00059KBd\u001bX_";
      q[79] = "(\u0017\u0006\\\\m}SW_;}\u0017T\u0003BTff][QVq\u0017WRCQnz\bCXF\u0014";
      q[80] = "\b=\u0011\t\u001f&T A@f<X,L\u001e\n\u000e\u000bi\u0015Dfc^-F\u0003\u000b<O6Qy";
      q[81] = "*FR%V&(\u001eX}f/\u0011\u001c\u001bc\u001a9cJ\u001d#\bE";
      q[82] = "u5s0\u0018Lzj&m~\u001bua,8)H%2yT\u001cDljr5\u001e\u0014-5";
      q[83] = ">(\u0002BC01wW\u001f%l2mYAI^e*\u0002\u001c\u001c\t= A@\u001fh?p\u0000\u001f%";
      q[84] = "\u00147X-\r#\u00189\u001b;}:H5\u0005%\u0011\b\u001ax]s}.Kp\u0019 CfH5\tB";
      q[85] = "\u0001(\u0003{b\u001d]5S2\u001b\f](ZgL\\\u0004|\u0001\u000bySD#\u0004j{\u0003\u0005|";
      q[86] = "|S4|\u001fo*U*a/x|?\"kJnxY3=Vy\u0012U%c^utDs\u007fI\u001f|S4|\u001fo*U*a/";
      q[87] = "Y=RwU2Z(\u0001ik4T:Xb\u0007\u0006\u0000~\u0003>k3\b>^?\n1X\u007f\u0001\u0005";
      q[88] = "\u0003Wth\u0010&V\u0013%kw6<\u0014qv\u0018-M\u001d)e\u001a:<\u0016!iG EU46\r_";
      q[89] = "M\u0010^\\K N\u0005\rBu&@\u0017TI\u0019\u0014\u0014S\u000e\u001fu#V\u0001F\u0010\u0016 CRX.";
      q[90] = "\u0007Z/.H\u0012\u0007X>t/L\u001eR0ZB_9Q>\u0015URD\u0003/vE\u001cG\u0005O)VY\u0006@=\u007fP\u0019\u0014<slU_\u0006N%j\u0015Mz";
      q[91] = "Y[[\"Y+\u0010DD:>=\u000f^^-W16P^=SWRRG*D:\rC\\=>";
      q[92] = "I\btL9aKP~\u0014\tirR=\nu~\u0000\u0004;Jg\u0002";
      q[93] = "?&\u0002o%\u0006l2\f;G\u0015V=\r:6\u00160,[&!|";
      q[94] = "|\u001aN!r\u000f \u0007\u001eh\u000b\u0015,\u000b\u00136g'|HH`\u000b\u0015;\u0011M(s\b?\u0011\u0001Qo\u001c<\u001a\u0012kgM!\u0007s";
      q[95] = "NS8\nOm\u0012NhC6w\u001eBe\u001dZEL\u0004;C6v\u001fCh\u001b\f~N^uzR~\u000eSd@Z/\u0013N\u0005";
      q[96] = "-\u0007m3XG.\u0012>-fA \u0000g&\nstD=\u007ffD6\u0016u\u007f\u0005G#EkA\u0004\u00155\u001a= \u0006EtE\u0007";
      q[97] = "FJCYS-\u0015F]\"O1F\u001eIu\u0018o\u0011F%\u001fLm[\u0003ZCQ=\u0012";
      q[98] = "$\u0013TtJ92\u001f\u0017\"1(O\u0017_d^3>\u001e\u0007w\\$O\u0015\u000f{\u0001>6V\u001a$KA";
      q[99] = "_n\u0019xcvP1L%\u0005*S+B{i\u0018\u0000o\u001e#\u0005~@jMlyrN)[\u001c";
      q[100] = "~;|\u0017\u0011\u0001 +a\u001e{\u0017\u0011`7\u0007\u0014\f`io\u0014\u0016\u001b\u00119v\u0011\t@r:cB\u0017~";
      q[101] = "6\u001e0kCP/\u00016;~Z!\f9f\u0012hpLh9~E=Nfa\u001dUsM`\u0001";
      q[102] = "lp+\u0013%vc/~NC!l$t\u001b\u0014q5p,w!~u/*\u0016#.4p";
      q[103] = "j(\u0015Q\u001b\t?lDR|\u0017Uk\u0010O\u0013\u0002$bH\\\u0011\u0015UhAN\u0016\n87PU\u0001p";
      q[104] = "\u001e\u001d_0w\u0010\b\u0011\u001cf\f\u0001u\u0019T c\u001a\u0004\u0010\f3a\ru\u001a\u0005!f\u0012\u0018E\u0014:qh";
      q[105] = "@'\u0012\u0005x$OxGX\u001epXc@\u0005e\u001dKsL\u0010t{Z%P\u0007\u001e'JcC\u001bsx[xTa";
      q[106] = ",\u0015l\t&Sp\b<@_I|\u00041\u001e3{/@mF_\u001doE>\t#\u0011a\u0006(y";
      q[107] = "F~/vP~Fily=y=7j4RbL>2'Pu=r\"']a[\u007fkvM\u0010";
      q[108] = "\u0005&\u001b6GE\nyNk!\u0019\tc@5M+^$\u001bk\u0011|\u0006.X4\u001b\u001d\u0004~\u0019k!";
      q[109] = "9\r\r\u0002g36RX_\u0001d9YR\nV4`\u000f\bfc; R\f\u0007aka\r";
      q[110] = "o\u001bY=\u0019\u0000jZ_=`\u0019;\u0018Vc\f+l_\n4Y|l\u000fKn\u001a\u00113\u001ePy`G<\u0007\u0006{\u0019\u0004)XL\u0004";
      q[111] = "D\u0000N\u001bA\u0007K_\u001bF'[HE\u0015\u0018Ki\u001f\u0002NF\u0018>G\b\r\u0019\u001d_EXLF'";
      q[112] = "?IG\u001bC\u0013&CO\f!F,NM\nv\u0018w\u001e\u0014fPFt_KX\u0018E1O";
      q[113] = "\u001f \rk\u0015\u0007\r=\u000f8k\u0000\u0018 \u001a/5\u0007\u0018:\u001eS\u000f\u0002\u0001*\u0012i\u0007S\u001c7s";
      q[114] = "U$r3l\nNv~bP\u0002^5b?<0\np8fag\u000f0x$,\u0015Y686P";
      q[115] = "\u000b%OPW?SvH@10l!\u0010L^+\u001d(H_\\<l`\u0011S\u0001:\u001c&\u0013@NY";
      q[116] = " \u0003{\u0010\u001c\u001e}\tkSs\u000b\u001eP,Q\u001c\u0010oYtB\u001e\u0007\u001eS}P\u0019\u0018s\flK\u000eb";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = q[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(r[var4]);
            q[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            q[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  q[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1158453789336815L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  q[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1158453789336815L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        q[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1158453789336815L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 181;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 234;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 205;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 255;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 228;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 222;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 181;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 234;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 205;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eh_C0232",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoShield var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eh_C0232;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eh_C0232", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoShield)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
