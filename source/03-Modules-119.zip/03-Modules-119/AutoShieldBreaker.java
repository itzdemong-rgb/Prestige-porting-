package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.client.management.NotificationManager;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

public class AutoShieldBreaker extends Module implements RotationSource {
   private ModeSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private BooleanSetting e;
   private MinMaxSetting f;
   private MinMaxSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private FloatSetting j;
   private int k;
   private int l;
   private boolean m;
   private ElapsedTimer n;
   private ElapsedTimer o;
   private ElapsedTimer p;
   private static final long q = 50203956162942L;
   private static final String[] r;
   private static final String[] s;
   private static final Map t = new HashMap(13);
   private static final long[] u;
   private static final Integer[] v;
   private static final Map w;
   private static final long x;
   private static final Object[] y = new Object[131];
   private static final String[] z = new String[131];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   public AutoShieldBreaker() {
      super();
      long var10001 = 41021968978870L ^ 75066168550559L;
      var10001 = 41021968978870L ^ 71079102335705L;
      var10001 = 41021968978870L ^ 64020670390625L;
      var10001 = 41021968978870L ^ 129254414800922L;

      this.k = -1;
      this.l = -1;
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.n = new ElapsedTimer(106698256430889L);
      this.o = new ElapsedTimer(106698256430889L);
      this.p = new ElapsedTimer(106698256430889L);
      BooleanSetting var10000 = this.d;
      Object[] var12 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var11 = var10000;
      var11.aReturningBooleanSetting(var12);
      MinMaxSetting var27 = this.g;
      Object[] var14 = new Object[]{invokeBinding2(this), 112057026795887L};
      MinMaxSetting var13 = var27;
      var13.aReturningMinMaxSetting(var14);
      var10000 = this.h;
      Object[] var16 = new Object[]{invokeBinding3(this), 88791076916140L};
      BooleanSetting var15 = var10000;
      var15.aReturningBooleanSetting(var16);
      var10000 = this.i;
      Object[] var18 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var17 = var10000;
      var17.aReturningBooleanSetting(var18);
      FloatSetting var30 = this.j;
      Object[] var20 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var19 = var30;
      var19.aReturningFloatSetting(var20);
      FloatSetting var31 = this.c;
      Object[] var22 = new Object[]{invokeBinding6(this), 34595201528535L};
      FloatSetting var21 = var31;
      var21.aReturningFloatSetting(var22);
      MinMaxSetting var32 = this.f;
      Object[] var24 = new Object[]{invokeBinding7(this), 112057026795887L};
      MinMaxSetting var23 = var32;
      var23.aReturningMinMaxSetting(var24);
      var10000 = this.e;
      Object[] var26 = new Object[]{invokeBinding8(this), 88791076916140L};
      BooleanSetting var25 = var10000;
      var25.aReturningBooleanSetting(var26);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 6874214163169L ^ 132777975559413L;
      var10001 = 6874214163169L ^ 118024421894558L;
      var10001 = 6874214163169L ^ 78842338879383L;
      var10001 = 6874214163169L ^ 646932628220L;
      var10001 = 6874214163169L ^ 104842254647765L;
      int var14 = Event.cReturningInt();
      MinecraftClient var15 = b;
      ClientPlayerEntity var16 = var15.player;
      byte var10000 = ((byte)((var16.isAlive()) ? 1 : 0));
      int var82 = var14;
      byte var81 = var10000;
      int var56 = var81;
      byte var55 = var81;
      if (var82 != 0) {
         byte var83 = var55;
         if (var83 == 0) {
            this.k = -1;
            this.l = -1;
            this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
            return;
         }

         MinecraftClient var19 = b;
         ClientPlayerEntity var20 = var19.player;
         double var140;
         var56 = (var140 = var20.fallDistance - 2.0) == 0.0 ? 0 : (var140 < 0.0 ? -1 : 1);
      }

      int var85 = var14;
      int var84 = var56;
      int var58 = var84;
      int var57 = var84;
      if (var85 != 0) {
         int var86 = var57;
         if (var86 > 0) {
            return;
         }

         var58 = (((this.m) ? 1 : 0));
      }

      int var62;
      int var88 = var14;
      int var87 = var58;
      var62 = var87;
      int var59 = var87;
      label113:
      if (var88 != 0) {
         int var89 = var59;
         if (var89 != 0) {
            ElapsedTimer var127 = this.p;
            MinMaxSetting var136 = this.f;
            Object[] var24 = new Object[0];
            MinMaxSetting var23 = var136;
            float var137 = var23.eReturningFloat(var24) + 400.0F;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var137;
            Object[] var26 = var10004;
            ElapsedTimer var25 = var127;
            var10000 = ((byte)((var25.aReturningBoolean(var26)) ? 1 : 0));
            int var91 = var14;
            byte var90 = var10000;
            var62 = var90;
            byte var60 = var90;
            if (var91 == 0) {
               break label113;
            }

            byte var92 = var60;
            byte var61 = var92;
            byte var93 = var61;
            if (var93 != 0) {
               this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
            }
         }

         var62 = this.k;
      }

      MinecraftClient var76;
      label106: {
         label105: {
            int var95 = var14;
            int var94 = var62;
            int var64 = var94;
            int var63 = var94;
            if (var95 != 0) {
               
               if (var96 == var97) {
                  break label105;
               }

               byte var98 = ((byte)((this.m) ? 1 : 0));
               var64 = var98;
            }

            int var99 = var64;
            if (var99 == 0) {
               int var101 = var14;
               MinecraftClient var100 = b;
               var76 = var100;
               MinecraftClient var65 = var100;
               if (var101 == 0) {
                  break label106;
               }

               MinecraftClient var102 = var65;
               MinecraftClient var66 = var102;
               MinecraftClient var33 = var66;
               Screen var103 = var33.currentScreen;
               label98:
               if (var103 == null) {
                  AutoShieldBreaker var75;
                  label123: {
                     Object[] var35 = new Object[]{119946435234687L};
                     int var129 = (((ItemUseUtil.eReturningBoolean(var35)) ? 1 : 0));
                     int var105 = var14;
                     boolean var104 = dev.prestige.recovery.SourceSupport.asBoolean(var129);
                     boolean var71 = var104;
                     boolean var67 = var104;
                     if (var105 != 0) {
                        boolean var106 = var67;
                        boolean var68 = var106;
                        boolean var107 = var68;
                        if (var107) {
                           break label98;
                        }

                        int var109 = var14;
                        AutoShieldBreaker var108 = this;
                        var75 = var108;
                        AutoShieldBreaker var69 = var108;
                        if (var109 == 0) {
                           break label123;
                        }

                        AutoShieldBreaker var110 = var69;
                        AutoShieldBreaker var70 = var110;
                        BooleanSetting var39 = var70.h;
                        Boolean var40 = (Boolean)var39.aReturningObject();
                        boolean var111 = var40;
                        var71 = var111;
                     }

                     boolean var112 = var71;
                     label88:
                     if (var112) {
                        int var114 = var14;
                        int var113 = this.l;
                        int var74 = var113;
                        int var72 = var113;
                        if (var114 != 0) {
                           int var115 = var72;
                           int var73 = var115;
                           
                           if (var116 != var117) {
                              var129 = this.l;
                              int var138 = this.k;
                              Object[] var139 = new Object[]{null, null, 7516849659933L};
                              var139[1] = var138;
                              var139[0] = var129;
                              Object[] var44 = var139;
                              InventoryUtil.fReturningBoolean(var44);
                              int var118 = var14;
                              if (var118 != 0) {
                                 break label88;
                              }
                           }

                           int var119 = this.k;
                           var74 = var119;
                        }

                        Object[] var10003 = new Object[]{null, 72518082610550L};
                        var10003[0] = var74;
                        Object[] var47 = var10003;
                        InventoryUtil.aReturningVoid(var47);
                     }

                     this.k = -1;
                     var75 = this;
                  }

                  var75.l = -1;
               }
            }
         }

         var76 = b;
      }

      MinecraftClient var48 = var76;
      int var121 = var14;
      Entity var120 = var48.targetedEntity;
      Entity var78 = var120;
      Entity var77 = var120;
      if (var121 != 0) {
         Entity var122 = var77;
         if (var122 == null) {
            return;
         }

         MinecraftClient var50 = b;
         var78 = var50.targetedEntity;
      }

      boolean var131 = var78 instanceof PlayerEntity;
      int var124 = var14;
      boolean var123 = var131;
      boolean var79 = var123;
      if (var124 != 0) {
         boolean var125 = var79;
         if (var125) {
            MinecraftClient var52 = b;
            Object[] var54 = new Object[]{(PlayerEntity)var52.targetedEntity, 97972403528500L};
            AutoShieldBreaker var53 = this;
            boolean var126 = var53.dReturningBoolean(var54);
         }
      }
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 117811730097897L ^ 63080989863942L;
      var10001 = 117811730097897L ^ 54874353542189L;
      var10001 = 117811730097897L ^ 87475999152952L;
      var10001 = 117811730097897L ^ 77120839885286L;
      var10001 = 117811730097897L ^ 47082519880607L;
      var10001 = 117811730097897L ^ 138972873301917L;
      int var16 = Event.bReturningInt();
      ModeSetting var19 = this.a;
      String var10000 = (String)var19.aReturningObject();
      String var21 = "On Hit";
      String var20 = var10000;
      boolean var77 = var20.equals(var21);
      if (var77) {
         int var79 = var16;
         MinecraftClient var78 = b;
         MinecraftClient var57 = var78;
         MinecraftClient var56 = var78;
         if (var79 == 0) {
            MinecraftClient var23 = var56;
            Entity var80 = var23.targetedEntity;
            if (var80 == null) {
               return;
            }

            MinecraftClient var81 = b;
            var57 = var81;
         }

         int var83 = var16;
         MinecraftClient var82 = var57;
         MinecraftClient var59 = var82;
         MinecraftClient var58 = var82;
         if (var83 == 0) {
            MinecraftClient var26 = var58;
            Screen var84 = var26.currentScreen;
            if (var84 != null) {
               return;
            }

            MinecraftClient var85 = b;
            var59 = var85;
         }

         int var87 = var16;
         MinecraftClient var86 = var59;
         MinecraftClient var61 = var86;
         MinecraftClient var60 = var86;
         if (var87 == 0) {
            MinecraftClient var29 = var60;
            boolean var88 = var29.isWindowFocused();
            if (!var88) {
               return;
            }

            var61 = b;
         }

         MinecraftClient var32 = var61;
         Entity var18 = var32.targetedEntity;
         int var90 = var16;
         Entity var89 = var18;
         Entity var63 = var89;
         Entity var62 = var89;
         if (var90 == 0) {
            boolean var91 = var62 instanceof PlayerEntity;
            if (!var91) {
               return;
            }

            Entity var92 = var18;
            var63 = var92;
         }

         PlayerEntity var17 = (PlayerEntity)var63;
         int var93 = var16;
         if (var93 == 0) {
            SocialsManager var117 = Prestige.g;
            PlayerEntity var36 = var17;
            Text var37 = var36.getName();
            Object[] var39 = new Object[]{var37.getString(), 40309233401297L};
            SocialsManager var38 = var117;
            byte var118 = ((byte)((var38.aReturningBoolean(var39)) ? 1 : 0));
            int var95 = var16;
            byte var94 = var118;
            byte var65 = var94;
            byte var64 = var94;
            if (var95 == 0) {
               byte var96 = var64;
               if (var96 != 0) {
                  return;
               }

               PlayerValidationTracker var119 = Prestige.i;
               Object[] var42 = new Object[]{var17, 99841884226244L};
               PlayerValidationTracker var41 = var119;
               var65 = ((byte)((var41.aReturningBoolean(var42)) ? 1 : 0));
            }

            int var98 = var16;
            byte var97 = var65;
            byte var67 = var97;
            byte var66 = var97;
            if (var98 == 0) {
               byte var99 = var66;
               if (var99 == 0) {
                  return;
               }

               Object[] var45 = new Object[]{var17, 23377690343796L};
               AutoShieldBreaker var44 = this;
               var67 = ((byte)((var44.aReturningBoolean(var45)) ? 1 : 0));
            }

            int var101 = var16;
            byte var100 = var67;
            int var69 = var100;
            byte var68 = var100;
            if (var101 == 0) {
               byte var102 = var68;
               if (var102 == 0) {
                  return;
               }

               Object[] var48 = new Object[]{90679672608495L};
               AutoShieldBreaker var47 = this;
               int var103 = var47.dReturningInt(var48);
               var69 = var103;
            }

            int var76;
            label103: {
               int var116 = var69;
               int var106 = var16;
               
               int var74 = var104;
               byte var75 = var105;
               int var70 = var104;
               byte var71 = var105;
               if (var106 == 0) {
                  byte var108 = var71;
                  int var107 = var70;
                  if (var107 == var108) {
                     return;
                  }

                  int var110 = var16;
                  int var109 = this.k;
                  var76 = var109;
                  int var72 = var109;
                  if (var110 != 0) {
                     break label103;
                  }

                  int var111 = var72;
                  int var73 = var111;
                  
                  var74 = var112;
                  var75 = var113;
               }

               byte var115 = var75;
               int var114 = var74;
               if (var114 == var115) {
                  Object[] var53 = new Object[]{49487520630543L};
                  this.k = InventoryUtil.aReturningInt(var53);
                  this.l = -1;
               }

               var76 = var116;
            }

            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var76;
            Object[] var55 = var10003;
            InventoryUtil.aReturningVoid(var55);
         }
      }
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 50203956162942L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      byte var15;
      while (true) {
         short var10001 = 29206;
         long var10002 = 2999207317575992755L ^ var2;
         byte var17 = 8;
         int var16 = var5;
         if (var16 <= var17) {
            MinecraftClient var6 = b;
            ClientPlayerEntity var7 = var6.player;
            PlayerInventory var26 = var7.getInventory();
            int var9 = var5;
            PlayerInventory var8 = var26;
            ItemStack var10 = var8.getStack(var9);
            byte var27 = ((byte)((var10.getItem() instanceof AxeItem) ? 1 : 0));
            int var19 = var4;
            byte var18 = var27;
            var15 = var18;
            byte var11 = var18;
            if (var19 == 0) {
               break;
            }

            int var21 = var4;
            byte var20 = var11;
            int var14 = var20;
            byte var12 = var20;
            if (var21 == 0) {
               return var14;
            }

            byte var22 = var12;
            byte var13 = var22;
            byte var23 = var13;
            if (var23 != 0) {
               var14 = var5;
               return var14;
            }

            var5++;
            int var24 = var4;
            if (var24 != 0) {
               continue;
            }
         }

         var15 = -1;
         break;
      }

      return var15;
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 50203956162942L ^ var2;
      int var10000 = Event.bReturningInt();
      short var10001 = 3210;
      long var10002 = 1381952047528162331L ^ var2;
      int var5 = 9;
      int var4 = var10000;

      byte var15;
      while (true) {
         var10001 = 5109;
         var10002 = 695865385635228518L ^ var2;
         byte var17 = 35;
         int var16 = var5;
         if (var16 <= var17) {
            MinecraftClient var6 = b;
            ClientPlayerEntity var7 = var6.player;
            PlayerInventory var26 = var7.getInventory();
            int var9 = var5;
            PlayerInventory var8 = var26;
            ItemStack var10 = var8.getStack(var9);
            byte var27 = ((byte)((var10.getItem() instanceof AxeItem) ? 1 : 0));
            int var19 = var4;
            byte var18 = var27;
            var15 = var18;
            byte var11 = var18;
            if (var19 != 0) {
               break;
            }

            int var21 = var4;
            byte var20 = var11;
            int var14 = var20;
            byte var12 = var20;
            if (var21 != 0) {
               return var14;
            }

            byte var22 = var12;
            byte var13 = var22;
            byte var23 = var13;
            if (var23 != 0) {
               var14 = var5;
               return var14;
            }

            var5++;
            int var24 = var4;
            if (var24 == 0) {
               continue;
            }
         }

         var15 = -1;
         break;
      }

      return var15;
   }

   private boolean aReturningBoolean(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 50203956162942L ^ var2;
      int var5 = Event.cReturningInt();
      int var15 = var5;
      PlayerEntity var14 = var4;
      PlayerEntity var12 = var14;
      PlayerEntity var11 = var14;
      if (var15 != 0) {
         PlayerEntity var6 = var11;
         boolean var16 = var6.isUsingItem();
         if (!var16) {
            return false;
         }

         PlayerEntity var17 = var4;
         var12 = var17;
      }

      PlayerEntity var9 = var12;
      ItemStack var10 = var9.getActiveItem();
      Item var21 = var10.getItem();
      Item var19 = Items.SHIELD;
      Item var18 = var21;
      return var18 == var19;
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var4;
      long var6;
      long var10;
      int var12;
      Object var58;
      label65: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 112967329376932L;
         var6 = var2 ^ 30352829501857L;
         long var8 = var2 ^ 60429099907870L;
         var10 = var2 ^ 111510165490516L;
         var12 = Event.cReturningInt();
         BooleanSetting var16 = this.i;
         Boolean var17 = (Boolean)var16.aReturningObject();
         byte var10000 = ((byte)(((java.lang.Boolean)(var17)).booleanValue() ? 1 : 0));
         int var67 = var12;
         byte var66 = var10000;
         int var57 = var66;
         byte var55 = var66;
         if (var67 != 0) {
            byte var68 = var55;
            if (var68 == 0) {
               return null;
            }

            MinecraftClient var20 = b;
            int var70 = var12;
            ClientPlayerEntity var69 = var20.player;
            var58 = var69;
            ClientPlayerEntity var56 = var69;
            if (var70 == 0) {
               break label65;
            }

            ClientPlayerEntity var21 = var56;
            double var93;
            int var71 = (var93 = var21.fallDistance - 2.0) == 0.0 ? 0 : (var93 < 0.0 ? -1 : 1);
            var57 = var71;
         }

         int var72 = var57;
         if (var72 > 0) {
            return null;
         }

         FloatSetting var24 = this.j;
         Float var25 = (Float)var24.aReturningObject();
         float var87 = var25;
         Object[] var10003 = new Object[]{null, var8};
         var10003[0] = var87;
         Object[] var26 = var10003;
         var58 = EntityUtil.bReturningPlayerEntity(var26);
      }

      Object var13 = var58;
      Object var73 = var13;
      if (var73 != null) {
         MinecraftClient var27 = b;
         Object var29 = var13;
         ClientPlayerEntity var28 = var27.player;
         float var94;
         int var88 = (var94 = var28.distanceTo((Entity)var29) - 3.0F) == 0.0F ? 0 : (var94 < 0.0F ? -1 : 1);
         int var75 = var12;
         int var74 = var88;
         int var61 = var74;
         int var59 = var74;
         if (var75 != 0) {
            int var76 = var59;
            int var60 = var76;
            int var77 = var60;
            if (var77 > 0) {
               return null;
            }

            MinecraftClient var32 = b;
            Object var34 = var13;
            ClientPlayerEntity var33 = var32.player;
            byte var78 = ((byte)((var33.canSee((Entity)var34)) ? 1 : 0));
            var61 = var78;
         }

         int var80 = var12;
         int var79 = var61;
         int var63 = var79;
         int var62 = var79;
         if (var80 != 0) {
            int var81 = var62;
            if (var81 == 0) {
               return null;
            }

            PlayerValidationTracker var89 = Prestige.i;
            Object[] var39 = new Object[]{var13, var4};
            PlayerValidationTracker var38 = var89;
            var63 = (((var38.aReturningBoolean(var39)) ? 1 : 0));
         }

         int var82 = var63;
         if (var82 == 0) {
            return null;
         }

         Object var41 = var13;
         Object[] var42 = new Object[]{((PlayerEntity)var41).getEyePos(), var6};
         Rotation var14 = RotationUtil.aReturningdx_C0210(var42);
         Object[] var44 = new Object[0];
         Rotation var43 = var14;
         float var90 = var43.aReturningFloat(var44);
         MinecraftClient var45 = b;
         ClientPlayerEntity var46 = var45.player;
         float var47 = var90 - var46.getYaw();
         float var15 = MathHelper.wrapDegrees(var47);
         float var48 = var15;
         float var91 = Math.abs(var48);
         FloatSetting var49 = this.j;
         Float var50 = (Float)var49.aReturningObject();
         float var95;
         var88 = (var95 = var91 - var50) == 0.0F ? 0 : (var95 < 0.0F ? -1 : 1);
         int var84 = var12;
         int var83 = var88;
         int var65 = var83;
         int var64 = var83;
         if (var84 != 0) {
            int var85 = var64;
            if (var85 > 0) {
               return null;
            }

            Object[] var54 = new Object[]{var13, var10};
            AutoShieldBreaker var53 = this;
            var65 = (((var53.dReturningBoolean(var54)) ? 1 : 0));
         }

         int var86 = var65;
         if (var86 != 0) {
            return var14;
         }
      }

      return null;
   }

   public boolean dReturningBoolean(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 50203956162942L ^ var3;
      long var5 = var3 ^ 88075942227867L;
      long var7 = var3 ^ 23757923434782L;
      long var9 = var3 ^ 58581478774588L;
      long var11 = var3 ^ 107687519710014L;
      long var13 = var3 ^ 4000320751665L;
      long var15 = var3 ^ 42653305193637L;
      long var17 = var3 ^ 51117605867662L;
      long var19 = var3 ^ 5824416720539L;
      long var21 = var3 ^ 8213990583301L;
      long var23 = var3 ^ 90463454575178L;
      long var25 = var3 ^ 28195556186421L;
      long var27 = var3 ^ 98620110067013L;
      long var29 = var3 ^ 125781767434839L;
      long var31 = var3 ^ 62955121609616L;
      long var33 = var3 ^ 21299051439522L;
      long var35 = var3 ^ 87883732441285L;
      int var37 = Event.cReturningInt();
      int var176 = var37;
      MinecraftClient var175 = b;
      MinecraftClient var136 = var175;
      MinecraftClient var135 = var175;
      if (var176 != 0) {
         MinecraftClient var40 = var135;
         ClientPlayerEntity var41 = var40.player;
         double var268;
         int var177 = (var268 = var41.fallDistance - 2.0) == 0.0 ? 0 : (var268 < 0.0 ? -1 : 1);
         if (var177 > 0) {
            return false;
         }

         var136 = b;
      }

      int var179 = var37;
      MinecraftClient var178 = var136;
      MinecraftClient var138 = var178;
      MinecraftClient var137 = var178;
      if (var179 != 0) {
         MinecraftClient var44 = var137;
         Screen var180 = var44.currentScreen;
         if (var180 != null) {
            return false;
         }

         MinecraftClient var181 = b;
         var138 = var181;
      }

      MinecraftClient var47 = var138;
      int var10000 = (((var47.isWindowFocused()) ? 1 : 0));
      int var183 = var37;
      byte var182 = (byte)var10000;
      byte var140 = var182;
      byte var139 = var182;
      if (var183 != 0) {
         byte var184 = var139;
         if (var184 == 0) {
            return false;
         }

         Object[] var50 = new Object[]{var25};
         var140 = ((byte)((ItemUseUtil.eReturningBoolean(var50)) ? 1 : 0));
      }

      int var186 = var37;
      byte var185 = var140;
      byte var142 = var185;
      byte var141 = var185;
      if (var186 != 0) {
         byte var187 = var141;
         if (var187 != 0) {
            return false;
         }

         MinecraftClient var53 = b;
         ClientPlayerEntity var54 = var53.player;
         var142 = ((byte)((var54.isUsingItem()) ? 1 : 0));
      }

      int var189 = var37;
      byte var188 = var142;
      int var148 = var188;
      byte var143 = var188;
      if (var189 != 0) {
         byte var190 = var143;
         if (var190 == 0) {
            int var10001 = 14176;
            long var10002 = 9134167556950373660L ^ var3;
            Object[] var10004 = new Object[]{null, null, var19};
            var10004[1] = 100;
            var10004[0] = 0;
            Object[] var56 = var10004;
            float var242 = RandomUtil.aReturningInt(var56);
            FloatSetting var57 = this.c;
            Float var58 = (Float)var57.aReturningObject();
            float var269;
            var10000 = (var269 = var242 - var58) == 0.0F ? 0 : (var269 < 0.0F ? -1 : 1);
            int var192 = var37;
            int var191 = var10000;
            var148 = var191;
            int var144 = var191;
            if (var192 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var148);
            }

            int var193 = var144;
            int var145 = var193;
            int var194 = var145;
            label166:
            if (var194 <= 0) {
               ElapsedTimer var244 = this.n;
               Object[] var62 = new Object[]{this.g, var13};
               ElapsedTimer var61 = var244;
               boolean var245 = var61.bReturningBoolean(var62);
               int var196 = var37;
               boolean var195 = var245;
               boolean var149 = var195;
               boolean var146 = var195;
               if (var196 != 0) {
                  boolean var197 = var146;
                  boolean var147 = var197;
                  boolean var198 = var147;
                  if (!var198) {
                     break label166;
                  }

                  ModeSetting var65 = this.a;
                  String var246 = (String)var65.aReturningObject();
                  var10001 = (short)31977;
                  var10002 = 142960245201254136L ^ var3;
                  String var67 = "Automatic";
                  String var66 = var246;
                  var149 = var66.equals(var67);
               }

               int var200 = var37;
               boolean var199 = var149;
               boolean var151 = var199;
               boolean var150 = var199;
               if (var200 != 0) {
                  boolean var201 = var150;
                  if (!var201) {
                     return false;
                  }

                  SocialsManager var247 = Prestige.g;
                  PlayerEntity var70 = var2;
                  Text var71 = var70.getName();
                  Object[] var73 = new Object[]{var71.getString(), var5};
                  SocialsManager var72 = var247;
                  var151 = var72.aReturningBoolean(var73);
               }

               int var203 = var37;
               boolean var202 = var151;
               boolean var153 = var202;
               boolean var152 = var202;
               if (var203 != 0) {
                  boolean var204 = var152;
                  if (var204) {
                     return false;
                  }

                  PlayerValidationTracker var248 = Prestige.i;
                  Object[] var77 = new Object[]{var2, var17};
                  PlayerValidationTracker var76 = var248;
                  var153 = var76.aReturningBoolean(var77);
               }

               int var206 = var37;
               boolean var205 = var153;
               boolean var155 = var205;
               boolean var154 = var205;
               if (var206 != 0) {
                  boolean var207 = var154;
                  if (!var207) {
                     return false;
                  }

                  Object[] var81 = new Object[]{var2, var11};
                  AutoShieldBreaker var80 = this;
                  var155 = var80.aReturningBoolean(var81);
               }

               int var209 = var37;
               boolean var208 = var155;
               boolean var174 = var208;
               boolean var156 = var208;
               if (var209 != 0) {
                  boolean var210 = var156;
                  if (var210) {
                     MinecraftClient var83 = b;
                     ClientPlayerEntity var84 = var83.player;
                     ItemStack var85 = var84.getMainHandStack();
                     var245 = var85.getItem() instanceof AxeItem;
                     int var212 = var37;
                     boolean var211 = var245;
                     boolean var167 = var211;
                     boolean var157 = var211;
                     if (var212 != 0) {
                        boolean var213 = var157;
                        boolean var158 = var213;
                        boolean var214 = var158;
                        if (!var214) {
                           int var216 = var37;
                           byte var215 = ((byte)((this.m) ? 1 : 0));
                           int var161 = var215;
                           byte var159 = var215;
                           if (var216 != 0) {
                              byte var217 = var159;
                              byte var160 = var217;
                              byte var218 = var160;
                              if (var218 != 0) {
                                 return false;
                              }

                              Object[] var92 = new Object[]{var15};
                              AutoShieldBreaker var91 = this;
                              var161 = var91.dReturningInt(var92);
                           }

                           label193: {
                              int var38 = var161;
                              int var220 = var37;
                              int var219 = var38;
                              int var163 = var219;
                              int var162 = var219;
                              if (var220 != 0) {
                                 
                                 if (var221 != var222) {
                                    Object[] var94 = new Object[]{var27};
                                    this.k = InventoryUtil.aReturningInt(var94);
                                    this.l = -1;
                                    Object[] var266 = new Object[]{null, var9};
                                    var266[0] = var38;
                                    Object[] var95 = var266;
                                    InventoryUtil.aReturningVoid(var95);
                                    this.m = true;
                                    ElapsedTimer var255 = this.p;
                                    Object[] var97 = new Object[]{var23};
                                    ElapsedTimer var96 = var255;
                                    var96.aReturningVoid(var97);
                                    int var223 = var37;
                                    if (var223 != 0) {
                                       break label193;
                                    }
                                 }

                                 BooleanSetting var99 = this.e;
                                 Boolean var100 = (Boolean)var99.aReturningObject();
                                 byte var224 = ((byte)(((java.lang.Boolean)(var100)).booleanValue() ? 1 : 0));
                                 var163 = var224;
                              }

                              int var226 = var37;
                              int var225 = var163;
                              int var166 = var225;
                              int var164 = var225;
                              if (var226 == 0) {
                                 return dev.prestige.recovery.SourceSupport.asBoolean(var166);
                              }

                              int var227 = var164;
                              if (var227 != 0) {
                                 Object[] var104 = new Object[]{var31};
                                 AutoShieldBreaker var103 = this;
                                 int var39 = var103.eReturningInt(var104);
                                 int var229 = var37;
                                 int var228 = var39;
                                 var166 = var228;
                                 int var165 = var228;
                                 if (var229 == 0) {
                                    return dev.prestige.recovery.SourceSupport.asBoolean(var166);
                                 }

                                 
                                 if (var230 != var231) {
                                    Object[] var106 = new Object[]{var27};
                                    this.k = InventoryUtil.aReturningInt(var106);
                                    this.l = var39;
                                    var10001 = this.k;
                                    var10004 = new Object[]{null, null, var29};
                                    var10004[1] = var10001;
                                    var10004[0] = var39;
                                    Object[] var107 = var10004;
                                    InventoryUtil.fReturningBoolean(var107);
                                    this.m = true;
                                    ElapsedTimer var256 = this.p;
                                    Object[] var109 = new Object[]{var23};
                                    ElapsedTimer var108 = var256;
                                    var108.aReturningVoid(var109);
                                 }
                              }
                           }

                           ElapsedTimer var257 = this.o;
                           Object[] var112 = new Object[]{var23};
                           ElapsedTimer var111 = var257;
                           var111.aReturningVoid(var112);
                           MinMaxSetting var258 = this.f;
                           Object[] var114 = new Object[]{var21};
                           MinMaxSetting var113 = var258;
                           var113.bReturningVoid(var114);
                           return false;
                        }

                        ElapsedTimer var250 = this.o;
                        Object[] var116 = new Object[]{this.f, var13};
                        ElapsedTimer var115 = var250;
                        var167 = var115.bReturningBoolean(var116);
                     }

                     int var233 = var37;
                     boolean var232 = var167;
                     boolean var169 = var232;
                     boolean var168 = var232;
                     if (var233 != 0) {
                        boolean var234 = var168;
                        if (!var234) {
                           return false;
                        }

                        Object[] var119 = new Object[]{var2, var33};
                        ItemUseUtil.aReturningVoid(var119);
                        BooleanSetting var120 = this.d;
                        Boolean var121 = (Boolean)var120.aReturningObject();
                        var169 = var121;
                     }

                     int var236 = var37;
                     boolean var235 = var169;
                     boolean var171 = var235;
                     boolean var170 = var235;
                     if (var236 != 0) {
                        boolean var237 = var170;
                        if (var237) {
                           Object[] var123 = new Object[]{var2, var33};
                           ItemUseUtil.aReturningVoid(var123);
                        }

                        ModuleNotificationsWidget var251 = ModuleNotificationsWidget.a;
                        Object[] var126 = new Object[]{var35};
                        ModuleNotificationsWidget var125 = var251;
                        var171 = var125.eReturningBoolean(var126);
                     }

                     int var239 = var37;
                     boolean var238 = var171;
                     boolean var173 = var238;
                     boolean var172 = var238;
                     if (var239 != 0) {
                        boolean var240 = var172;
                        if (var240) {
                           NotificationManager var252 = Prestige.v;
                           short var260 = 8351;
                           var10002 = 8862822821063813769L ^ var3;
                           short var264 = 26991;
                           long var10003 = 2121291771930682237L ^ var3;
                           var10003 = x;
                           Object[] var10007 = new Object[]{null, null, null, NotificationType.INFO, var7};
                           var10007[2] = var10003;
                           var10007[1] = "Broke target's shield!";
                           var10007[0] = "AutoShieldBreaker";
                           Object[] var129 = var10007;
                           NotificationManager var128 = var252;
                           var128.aReturningVoid(var129);
                        }

                        this.m = false;
                        ElapsedTimer var253 = this.n;
                        Object[] var132 = new Object[]{var23};
                        ElapsedTimer var131 = var253;
                        var131.aReturningVoid(var132);
                        MinMaxSetting var254 = this.g;
                        Object[] var134 = new Object[]{var21};
                        MinMaxSetting var133 = var254;
                        var133.bReturningVoid(var134);
                        var173 = true;
                     }

                     return var173;
                  }

                  var174 = false;
               }

               return var174;
            }
         }

         var148 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var148);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
      this.k = -1;
      this.l = -1;
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private boolean lambda$new$7(Float var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Automatic";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.i;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$6(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$5(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$4(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$3(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$2(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(116872748450705L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[5];
      String var22 = "Ö?Ä4°ø{ìOÁÃ\u0098Bpå\u0083^\u001eÛ\u00859V\u008b\u009d¶\u0010{\r?Þ\u0016ñ _fÝd\u0081\u0005î QP\u001d\u0016ÖBæ²êC\u00175d[\u008c¥ôÓ&Àê\u008c\u0086\u0018\u0007\u0014\u0017,\u008b\u009buö\u0010O\u007fãï3ûê\u0001\u0082\u0083©\u009eà\u0001\u0014'";
      int var24 = "Ö?Ä4°ø{ìOÁÃ\u0098Bpå\u0083^\u001eÛ\u00859V\u008b\u009d¶\u0010{\r?Þ\u0016ñ _fÝd\u0081\u0005î QP\u001d\u0016ÖBæ²êC\u00175d[\u008c¥ôÓ&Àê\u008c\u0086\u0018\u0007\u0014\u0017,\u008b\u009buö\u0010O\u007fãï3ûê\u0001\u0082\u0083©\u009eà\u0001\u0014'"
         .length();
      char var21 = '(';
      int var29 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var29, var29 + var21);
         int var10001 = -1;

         while (true) {
            byte[] var26 = var18.doFinal(var30.getBytes("ISO-8859-1"));
            String var44 = b(var26).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var44;
                  if ((var29 += var21) >= var24) {
                     r = var25;
                     s = new String[5];
                     w = new HashMap(13);
                     Cipher var5;
                     var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(116872748450705L << var6 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[4];
                     String var9 = "ì\u001a\u0012Çç_G\u0013ª_5¯\u0012áRK";
                     int var10 = "ì\u001a\u0012Çç_G\u0013ª_5¯\u0012áRK".length();
                     label46:
                     while (true) {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
                        long[] var33 = var11;
                        var10001 = var8++;
                        long var48 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        
                           long var13 = var48;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var56 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var33[var10001] = var56;
                                 if (var7 >= var10) {
                                    u = var11;
                                    v = new Integer[4];
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(116872748450705L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long var41 = 310805894213087761L;
                                    byte[] var4 = var0.doFinal(
                                       new byte[]{
                                          (byte)4L,
                                          (byte)1104L,
                                          (byte)282676L,
                                          (byte)72365136L,
                                          (byte)18525474918L,
                                          (byte)4742521579179L,
                                          (byte)1214085524269874L,
                                          (byte)310805894213087761L
                                       }
                                    );
                                    long var51 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    
                                    break;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var56;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = ",nÈù°ÑÄñmpUÕê\u0084vT";
                                 var10 = ",nÈù°ÑÄñmpUÕê\u0084vT".length();
                                 var7 = 0;
                           }

                           int var40 = var7;
                           var7 += 8;
                           var12 = var9.substring(var40, var7).getBytes("ISO-8859-1");
                           var33 = var11;
                           var10001 = var8++;
                           var48 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var29);
                  break;
               default:
                  var25[var23++] = var44;
                  if ((var29 += var21) < var24) {
                     var21 = var22.charAt(var29);
                     continue label64;
                  }

                  var22 = "U\u0097h!ôH\u0017(IÙ\u009dó\u0093ñ\u00863Úãäw~r\u0099\u008c(¤ÈÂ\u007fYùÎ(\u009a-¶\u0084\u0010VäTÜf\u0098IEÑ¡Ý4FZ\u0099>ËÒ¢1õ\u000b«\u0085ÀàícB\u0001j{¿Pú";
                  var24 = "U\u0097h!ôH\u0017(IÙ\u009dó\u0093ñ\u00863Úãäw~r\u0099\u008c(¤ÈÂ\u007fYùÎ(\u009a-¶\u0084\u0010VäTÜf\u0098IEÑ¡Ý4FZ\u0099>ËÒ¢1õ\u000b«\u0085ÀàícB\u0001j{¿Pú"
                     .length();
                  var21 = ' ';
                  var29 = -1;
            }

            var30 = var22.substring(++var29, var29 + var21);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6232;
      if (s[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])t.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ei", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = r[var5].getBytes("ISO-8859-1");
         s[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return s[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ei_C0234",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ei" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20534;
      if (v[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = u[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])w.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               w.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ei", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         v[var3] = var15;
      }

      return v[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ei_C0234",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ei" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 31;
            yield var15;
         }
         case 1 -> {
            byte var16 = 6;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 33;
            yield var18;
         }
         case 4 -> {
            byte var19 = 24;
            yield var19;
         }
         case 5 -> {
            byte var20 = 12;
            yield var20;
         }
         case 6 -> {
            byte var21 = 8;
            yield var21;
         }
         case 7 -> {
            byte var22 = 10;
            yield var22;
         }
         case 8 -> {
            byte var23 = 1;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 44;
            yield var25;
         }
         case 11 -> {
            byte var26 = 26;
            yield var26;
         }
         case 12 -> {
            byte var27 = 38;
            yield var27;
         }
         case 13 -> {
            byte var28 = 50;
            yield var28;
         }
         case 14 -> {
            byte var29 = 54;
            yield var29;
         }
         case 15 -> {
            byte var30 = 20;
            yield var30;
         }
         case 16 -> {
            byte var31 = 46;
            yield var31;
         }
         case 17 -> {
            byte var32 = 14;
            yield var32;
         }
         case 18 -> {
            byte var33 = 35;
            yield var33;
         }
         case 19 -> {
            byte var34 = 39;
            yield var34;
         }
         case 20 -> {
            byte var35 = 25;
            yield var35;
         }
         case 21 -> {
            byte var36 = 53;
            yield var36;
         }
         case 22 -> {
            byte var37 = 11;
            yield var37;
         }
         case 23 -> {
            byte var38 = 62;
            yield var38;
         }
         case 24 -> {
            byte var39 = 13;
            yield var39;
         }
         case 25 -> {
            byte var40 = 55;
            yield var40;
         }
         case 26 -> {
            byte var41 = 63;
            yield var41;
         }
         case 27 -> {
            byte var42 = 37;
            yield var42;
         }
         case 28 -> {
            byte var43 = 41;
            yield var43;
         }
         case 29 -> {
            byte var44 = 5;
            yield var44;
         }
         case 30 -> {
            byte var45 = 43;
            yield var45;
         }
         case 31 -> {
            byte var46 = 61;
            yield var46;
         }
         case 32 -> {
            byte var47 = 0;
            yield var47;
         }
         case 33 -> {
            byte var48 = 18;
            yield var48;
         }
         case 34 -> {
            byte var49 = 45;
            yield var49;
         }
         case 35 -> {
            byte var50 = 59;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 17;
            yield var52;
         }
         case 38 -> {
            byte var53 = 42;
            yield var53;
         }
         case 39 -> {
            byte var54 = 4;
            yield var54;
         }
         case 40 -> {
            byte var55 = 32;
            yield var55;
         }
         case 41 -> {
            byte var56 = 57;
            yield var56;
         }
         case 42 -> {
            byte var57 = 3;
            yield var57;
         }
         case 43 -> {
            byte var58 = 29;
            yield var58;
         }
         case 44 -> {
            byte var59 = 56;
            yield var59;
         }
         case 45 -> {
            byte var60 = 48;
            yield var60;
         }
         case 46 -> {
            byte var61 = 30;
            yield var61;
         }
         case 47 -> {
            byte var62 = 22;
            yield var62;
         }
         case 48 -> {
            byte var63 = 27;
            yield var63;
         }
         case 49 -> {
            byte var64 = 2;
            yield var64;
         }
         case 50 -> {
            byte var65 = 7;
            yield var65;
         }
         case 51 -> {
            byte var66 = 16;
            yield var66;
         }
         case 52 -> {
            byte var67 = 47;
            yield var67;
         }
         case 53 -> {
            byte var68 = 9;
            yield var68;
         }
         case 54 -> {
            byte var69 = 40;
            yield var69;
         }
         case 55 -> {
            byte var70 = 36;
            yield var70;
         }
         case 56 -> {
            byte var71 = 34;
            yield var71;
         }
         case 57 -> {
            byte var72 = 60;
            yield var72;
         }
         case 58 -> {
            byte var73 = 51;
            yield var73;
         }
         case 59 -> {
            byte var74 = 52;
            yield var74;
         }
         case 60 -> {
            byte var75 = 49;
            yield var75;
         }
         case 61 -> {
            byte var76 = 23;
            yield var76;
         }
         case 62 -> {
            byte var77 = 15;
            yield var77;
         }
         default -> 21;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      y[0] = "k~8t0V`q);MNsv r";
      y[1] = "TCh!{@_Lyn\u001aNTG}4";
      y[2] = boolean.class;
      z[2] = "java/lang/Boolean";
      y[3] = "Pa1\u0005!jFa4_2}Q*7Y>i@m Nu~r";
      y[4] = "C,.)B\u001eU,+sQ\tBg(u]\u001dS ?b\u0016\rK =iL@w;=tL\u0007@,";
      y[5] = ")\u000513i\u001e?\u00054iz\t(N7ov\u001d9\t x=\u000f+";
      y[6] = "\u007fW<Bi[\nw7Mx\u0014ky<F|N\u001f";
      y[7] = "n\u0015|hiYx\u0015y2zNo^z4vZ~\u0019m#=MH";
      y[8] = "J\u0006-h>i?&&g/&^(-l+|*";
      y[9] = "q\u0005\u0000,GHg\u0005\u0005vT_pN\u0006pXKa\t\u0011g\u0013\\m";
      y[10] = "\u0016r\u0006\f\u0005\u001e\u0016r\u0011P\t\u0011\f9\u0011N\t\u0004\u000bHE\u0016^";
      y[11] = double.class;
      z[11] = "java/lang/Double";
      y[12] = float.class;
      z[12] = "java/lang/Float";
      y[13] = "5\u0001\u000b,]0>\u000e\u001ac130\f\u0018,\u001d";
      y[14] = "|v\u0012\r\u0014\u001cjv\u0017W\u0007\u000b}=\u0014Q\u000b\u001flz\u0003F@\r]";
      y[15] = int.class;
      z[15] = "java/lang/Integer";
      y[16] = "\u000f;$HcT\u000f;3\u0014o[\u0015p3\noN\u0012\u0001aT7\n";
      y[17] = "%9T<@r%9C`L}?rC~Lh8\u0003\u0011$\u0018,";
      y[18] = "X\u0018M(SMX\u0018Zt_BBSZj_WE\"\u000b2\r";
      y[19] = "yB*x\u007fYyB=$sVc\t=:sCdxmg\"";
      y[20] = "\u0002}\u0003|\u0015<\tr\u00123}<\u0007}\u0001";
      y[21] = "vh\u0011S\u001b\u001d`h\u0014\t\b\nw#\u0017\u000f\u0004\u001efd\u0000\u0018O\b{";
      y[22] = "#O\u0000|\u0016.Vo\u000bs\u0007a7a\u0000x\u0003;C";
      y[23] = "zk(6Y\n\u000fK#9HEnE(2L\u001f\u001a";
      y[24] = "@\"_}\u0017$K-N2t)^+";
      y[25] = "\n\u000b\u001a\t\u000f&\n\u000b\rU\u0003)\u0010@\rK\u0003<\u00171]\u0012Q}";
      y[26] = "9\r+.G\r2\u0002:a$\u0000'\u000f5\n\u0011\u00026\u001c)&\u0006\u000f";
      y[27] = "\fd~\u0019N\b\u001ad{C]\u001f\r/xEQ\u000b\u001choR\u001a\u001e=";
      y[28] = "\u001ch,\\RCiH'SC\f\bF,XGV|";
      y[29] = "4;\u0015,\u000b0A\u001b\u001e#\u001a\u007f \u0015\u0015(\u001e%T";
      y[30] = "\u0011`@t\u000f4\u0007`E.\u001c#\u0010+F(\u00107\u0001lQ?[\":";
      y[31] = "\b<!\u00126\u001b\b<6N:\u0014\u0012w6P:\u0001\u0015\u0006a\u000fl";
      y[32] = "\b\\\u000e\t^&\u001e\\\u000bSM1\t\u0017\bUA%\u0018P\u001fB\n5\u0003";
      y[33] = "\u0000d\u001f \r\u007fuD\u0014/\u001c0\u0014J\u001f$\u0018j`";
      y[34] = void.class;
      z[34] = "java/lang/Void";
      y[35] = "&._R}JS\u000eT]l\u00052\u0000_Vh_F";
      y[36] = "E\u0018j\u0018\u0010\u001dE\u0018}D\u001c\u0012_S}Z\u001c\u0007X\",\u0003KE";
      y[37] = "\u000bY<'5'~y7($h\u001fw<# 2k";
      y[38] = "K3$Hu\u0003>\u0013/GdL_\u001d$L`\u0016+";
      y[39] = "#(|\u000f.55(yU=\"\"czS163$mDz!>";
      y[40] = "\u0017kG\u0012{ubKL\u001dj:\u0003EG\u0016n`w";
      y[41] = "<`x{$\u0003I@st5L(Nx\u007f1\u0016\\";
      y[42] = "$/\u0015\u00039\b:'\u000fLD\u0018:";
      y[43] = "L\u0010H\u0002S.L\u0010_^_!V[_@_4Q*\r\u001b\u0007~";
      y[44] = "fP\u0010\\p0fP\u0007\u0000|?|\u001b\u0007\u001e|*{jUE$k";
      y[45] = "\n:%2}\u0016\n:2nq\u0019\u0010q2pq\f\u0017\u0000`$ M";
      y[46] = "\b\\xMo=\u001e\\}\u0017|*\t\u0017~\u0011p>\u0018Pi\u0006;) ";
      y[47] = "Z=v+\u001a+/\u001d}$\u000bdN\u0013v/\u000f>:";
      y[48] = "s\\;u[\fe\\>/H\u001br\u0017=)D\u000fcP*>\u000f\u001aN";
      y[49] = "b\u0018p,n,\u00178{#\u007fcv6p({9\u0002";
      y[50] = "\u0007@\u0000I\u000e\u0015\u0011@\u0005\u0013\u001d\u0002\u0006\u000b\u0006\u0015\u0011\u0016\u0017L\u0011\u0002Z\u0006\u000f";
      y[51] = "\u0001FK\u007f\u0002(tf@p\u0013g\u0015hK{\u0017=a";
      y[52] = "Y\u0014\u0005\u001c\u0003_,4\u000e\u0013\u0012\u0010M:\u0005\u0018\u0016J9";
      y[53] = "<KvQ\u000b<Ik}^\u001as(evU\u001e)\\";
      y[54] = "x#q#\u0014,n#ty\u0007;yhw\u007f\u000b/h/`h@?S";
      y[55] = "U3\b\u001c\u0014g \u0013\u0003\u0013\u0005(A\u001d\b\u0018\u0001r5";
      y[56] = "PC\u001aK\u0015'FC\u001f\u0011\u00060Q\b\u001c\u0017\n$@O\u000b\u0000A5\u0005";
      y[57] = "3}\u001br_WF]\u0010}N\u0018'S\u001bvJBS";
      y[58] = "5[\u00062'I#[\u0003h4^4\u0010\u0000n8J%W\u0017ys]8";
      y[59] = "kodgX\r\u001eOohIB\u007fAdcM\u0018\u000b";
      y[60] = "Q#3\"\u001f\u0015$\u00038-\u000eZE\r3&\n\u00001";
      y[61] = "q\u001dP\u007f\u0006\u0017\u0004=[p\u0017Xe3P{\u0013\u0002\u0011";
      y[62] = "^\\.g;rH\\+=(e_\u0017(;$qNP?,ofr";
      y[63] = "5\u0014NznY@4Eu\u007f\u0016!:N~{LU";
      y[64] = "\u0018C$`\u0011s\u000eC!:\u0002d\u0019\b\"<\u000ep\bO5+Eg6";
      y[65] = "]R\t\u001cA](r\u0002\u0013P\u0012I|\t\u0018TH=";
      y[66] = "J\u0018oB4\u000f?8dM%@^6oF!\u001a*";
      y[67] = "/\u0013*%\u0013h/\u0013=y\u001fg5X=g\u001fr2)o=H0";
      y[68] = "\u001b>|7q]n\u001ew8`\u0012\u000f\u0010|3dH{";
      y[69] = "\u007fR,N9k\nr'A($k|,J,~\u001f";
      y[70] = "y\r4}!8-\r,&M)B\u000f6f+u#\u000fw!}";
      y[71] = "X\u0012;~\u001dQXS|( YcQ*!R@S\u0011\u007f}FBcQ<%KV\u0013\u0015/z[0";
      y[72] = "/ns@L?n/+Su%Pj!\u0014\u0007?`*tH\u0013=P58]\u001bsh23C\u001bO";
      y[73] = "]R:\u0004*\u0007\u0019\u000e6XH\u001e\u000f\u00123\u000e$,YWnUx{[\u0007!\u0003.\u0014\u0006\u001f8\u0000!{";
      y[74] = "w_U(t\u0005#_Ms\u0018\u001aL\u0005Q0wIs\fI9w";
      y[75] = "\u0016f*F[-L4;\u0014NQFXa\u0012\u001e#_h!GB7]XaGUnS$;\u0015D<FX";
      y[76] = "V\u000bpf\u0011:V\u0005(!)8[\u0001,2~o\u0005Qu^M/@\u001e&&GlJ\t";
      y[77] = "v6TH>\u00122jX\u0014\\\u000b$v]B09r4\u0001\u0018`nyw\u0003\u0019;Q+e\u0007U\\";
      y[78] = ";0={LS$z&o0\u0007A85?B\u001bqx`cV\u0019Ag,v^Wy`'h^k";
      y[79] = "gH_\u00136|gF\u0007T\u000eufS\u0007LbG2\u0012Y\u001a\u000e)v\u0012\fM~meM\u001c+";
      y[80] = "I0\u0002fy3\u0002}\u0001i>I\u0019\u0000Jp{;\u00000\n%'/\u0002\u0000J+34Kz\u0001f0;\f\u0000";
      y[81] = "}romac4:c?\u000b7\f2eoy.<r03m,\fm|&eb4jw8e^";
      y[82] = "/Z@.+b'\u0014R\u007fO?(T]w#\r~\u0013\u0000/vZ.H[tw+9Q@{O";
      y[83] = "\u001e]s3\u0012X\u001bO11bG\u000bHZ)\u0018I\u0000[\u00016\u001d\u0018\u0000Ro,\u0019Sf";
      y[84] = "KfXvq\u0003K:[#\u001dU%g^\"oI\u0015'\u000b~{K%gH&v_U#[yf9";
      y[85] = "`\u001aL\\\u0005zc\u000bH\tlbe\u0010s\\\u001153\fL\u000e\u00031\u007fkC\u0011R7hT\u0011\u0003V{\u000f";
      y[86] = "#\u001fm0\u0019>-\rn($*.\u000eo+H\u0018zO4}\u001fOs\u000f1pCp!\u001d5<$\u007f>L3+\u001b-,H\u007fL";
      y[87] = "\bc\u0018\u0003!\u000b\\c\u0000XM\u00053cY\u0002vCB=\u001f\u0002\"\u0006";
      y[88] = "\\Q;c*WFUp\u0005!@BGo~L\u0000T\u0017yw0\u0003UKe\u0005uD\u0002Emu1W]U\u000b";
      y[89] = "\u0014\u0016\rN:Z\u001d\u000e\u0004N\u0006\fwS\u001f\u0018t\u0015G\u0013JD`\u0017wS\t\u001cm\u0003\u0007\u0017\u001aC}e";
      y[90] = "\u00123$(*zSr|;\u0013gm7v|az]w# uxm>`{/mRlr\u007fc\n";
      y[91] = "\u0016$E2V)K<\\1YFJ K8W*xp\u000bc\u0000FF=G(Aw\u0010wS50:_3\r1\u000e$T<YX";
      y[92] = "\u0010<$C,M\u00102|\u0004\u0014O\u001d6x\u0017C\u0018Bj&{~G\u0018:`D-\u001b\u000e)";
      y[93] = "q\u0001$\u0011v)9P%\u0001#\u0017%:!\u001b+e8\naNwq::!\r/|.Je\u001eplH";
      y[94] = "uD?n\u001a%<\f3<pu\u0004\u00045l\u0002h4D`0\u0016j\u0004\u0004#h\u001b~t@07\u000b\u0018";
      y[95] = "\u0018\u0018$CgvE\f!M]~zK&\u001e/dJ\u000bsB;fz\u0018?ZcpB\u0010qH2\u0014";
      y[96] = ",&\u0000\u0005\np$h\u0012Tn-+(\u001d\\\u0002\u001fxmD\u0006nq;i\u0016]\u001e5(6\u0006;";
      y[97] = "Xw57\"R\u001c+9k@K\n7<=,yYreg@\u0017\u001av7<0S\t)'Z";
      y[98] = "6\u001aug\u001dc7\na&\"7SLo!P)c\f:}D+SLy%I?#\bjzYY";
      y[99] = "e6q0\u001bl4|mhchX5|4\u0011qhu)h\u0005sX2k6X>%~f7\u0007\u0001";
      y[100] = "}\u0003hh@,uEjs&\"\u0014U sV9%\u0003jgKH";
      y[101] = "\u001f^ra\u00168\u001f\u0002q4zkq_t5\brA\u001f!i\u001cpq_b1\u0011d\u0001\u001bqn\u0001\u0002";
      y[102] = "v1Wd]\u00022m[8?\u0010(`Zeh@q4\u0001\t\u0000\u00036sD2\u0006\u001f8=";
      y[103] = "vF\u0007D\tFhM\b\u0010`\u001dgJ\u0019\u0019\f/5\u0007AO`\u0005m\u000b\u0018\u001eY\u001a;\\\u001d~";
      y[104] = "\n*KlF@\u000b:_-y\u0013o|Q*\u000b\n_<\u0004v\u001f\bo#Hc\u0017FW$C}\u0017z";
      y[105] = "#@\f(\u0006v;E\u000b)`/1+Q/Y:-WR.\u0005&_W\u0003 \f.aO\u0006'\rH";
      y[106] = "y(PyWky=Yzin/ \u0004(\u0000b\u0016.\u00048\u0004\u0004q:].\u000ft5)\u0002>i";
      y[107] = "y(7\\m/qn5G\u000b \u0010~\u007fG{:!(5SfK";
      y[108] = ".2oZDzb&oT( ^n>\tZ:n.kUN8^n(\rC,.*;RSJ";
      y[109] = "\u0007\u0004\b++qFEP8\u0012hx\u0000Z\u007f`qH@\u000f#tsxF\f\u007f\u007f8\b\u0007M'l\u0001";
      y[110] = "etK\u007f!z?~UdSx_(Z;!c#+[g=\u0011";
      y[111] = "E\f{K\u0011\u0007\u0001Pw\u0017s\u001e\u0017LrA\u001f,G\u000f)\u0017s\u0011\u001cTsZLB@B`&C\u0006D\fu\u0019\u0011\u0014@@\u0012";
      y[112] = "\bdDHPmL8H\u00142tZ$MB^F\t`\u0010\u001a2{Q<LY\r(\r*_%\u000bl\n3KUO\u007fU#-";
      y[113] = "$z\u0007NPL;0\u001cZ,\u0019^r\u000f\n^\u0004n2ZVJ\u0006^-\u0016CBHf*\u001d]Bt";
      y[114] = "\u0002E]!5;\n\u000bOpQf\u0005K@x=TV\u000f\u001b'Q\u007f\u0018I\u001avoa\u0013FN\u001f";
      y[115] = "P^U7E$\u0014\u0002Yk'=\u0002\u001e\\=K\u000fRR\u0004g'a\u0012_W<W%\u0001\u0000GZ";
      y[116] = "@[\u000f7%W@UWp\u001dUMQScJ\u0002\u0013\u0006\u000b\u000f\"\u0007EQUsf[I\r";
      y[117] = "\u001d[|!a\rQO|/\rTm\u0007-r\u007fM]Gx.kOmX4;c\u0001U_?%c=";
      y[118] = "\u0010b\u0005\u000e\u001d\u0005\\o\u0004Q\"\u0011.'U\fP\b\u001eg\u0000PD\n..C\u000b\u001e\u001f\u0011|Q\u000fRx";
      y[119] = "\u00126\u0017/\u001b&F6\u000ftw1)u^-\n*\u0011j\u00146\u001e";
      y[120] = "\u0011m)k\t{\u00111*>e,\u007fl/?\u00171O,zc\u00033\u007f<4v\u00150Nj~b\bA";
      y[121] = "\r\u0013\nTV.\f\u0003\u001e\u0015i}hE\u0010\u0012\u001bdX\u0005EN\u000ffh\u0015\u000b[\u0019eYCAO\u0004\u0014";
      y[122] = "N\u001d27,1NA1b@g \u001c4c2{\u0010\\a?&y L/*0z\u0011\u001ae>-\u000b";
      y[123] = "\u000ej(8!4P,(ldE^Sqh 7Gc1=|#ES.qi+\u000bk)zw+7";
      y[124] = "26uFwr2jv\u0013\u001b!\\o&[x'.sq\u0010uH=0hHt:!g#E\u001b";
      y[125] = ",:\u0000Yac$t\u0012\b\u0005>+4\u001d\u0000i\f{tBX\u0005#/:\u001b\u0017u&=x\u0019g";
      y[126] = "4.^vv\u0010x:^x\u001aIDr\u000f%hPt2Zy|RDr\u0019!qF46\n~a ";
      y[127] = "\u0014\u001e<h0WPB04RNF^5b>|\u0015\u001ai:RW[\\ollIPS;\u0005";
      y[128] = "<j\u000eo\u000f\u0004=oUas\u0014#gTl$Jx7\r\u0000\u000e\u001d\u007fkP9\u0011K(n";
      y[129] = "L\u001bu'O;]B\u007f!15E\u001c&8o2E\u0006\"D\u0001&\u001fG({S4\u001b\u000bO";
      y[130] = "nk_\u0019BU2>\u0001B\u0010i>W\u0005\u0016E\u001b'gEC\u0019\u000f%WU\r\f\u0019&f\u0003G\u0018\u0004W";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(135569992237143L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(135569992237143L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(135569992237143L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 211;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 238;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 101;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 98;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 107;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 196;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 211;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 238;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 101;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ei_C0234",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ei" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$4", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$6", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$3", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AutoShieldBreaker var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ei_C0234;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ei_C0234", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoShieldBreaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
