package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class AutoShortPearl extends Module implements RotationSource {
   private MinMaxSetting a;
   private ElapsedTimer c;
   private boolean i;
   private static final long k = 131342451054885L;
   private static final String l;
   private static final Object[] m = new Object[69];
   private static final String[] n = new String[69];
   private static volatile MethodHandle bindingCache1;

   public AutoShortPearl() {
      super();
      long var10001 = 86571516359685L ^ 52459264721708L;

      this.c = new ElapsedTimer(106698256430889L);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 38900117421308L ^ 88693941846707L;
      var10001 = 38900117421308L ^ 6135210530044L;
      int var10000 = Event.bReturningInt();
      Object[] var13 = new Object[0];
      PacketReceiveEvent var12 = var1;
      Packet var10 = var12.aReturningVoid(var13);
      int var8 = var10000;
      int var41 = var8;
      Packet var40 = var10;
      Packet var37 = var40;
      Packet var36 = var40;
      if (var41 == 0) {
         boolean var42 = var36 instanceof EntityDamageS2CPacket;
         if (!var42) {
            return;
         }

         Packet var43 = var10;
         var37 = var43;
      }

      EntityDamageS2CPacket var9 = (EntityDamageS2CPacket)var37;
      MinecraftClient var16 = b;
      ClientWorld var52 = var16.world;
      EntityDamageS2CPacket var17 = var9;
      int var19 = var17.entityId();
      ClientWorld var18 = var52;
      Entity var51 = var18.getEntityById(var19);
      int var45 = var8;
      Entity var44 = var51;
      Entity var39 = var44;
      Entity var38 = var44;
      if (var45 == 0) {
         Entity var46 = var38;
         if (var46 == null) {
            return;
         }

         var39 = var51;
      }

      MinecraftClient var21 = b;
      ClientPlayerEntity var48 = var21.player;
      Entity var47 = var39;
      if (var47 == var48) {
         MinecraftClient var23 = b;
         ClientWorld var25 = var23.world;
         EntityDamageS2CPacket var24 = var9;
         DamageSource var26 = var24.createDamageSource((World)var25);
         DamageType var27 = var26.getType();
         String var11 = var27.msgId();
         int var49 = var8;
         if (var49 == 0) {
            String var29 = var11;
            String var28 = l;
            boolean var50 = var28.equals(var29);
            if (!var50) {
               return;
            }

            this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
            ElapsedTimer var53 = this.c;
            Object[] var32 = new Object[]{42835128969216L};
            ElapsedTimer var31 = var53;
            var31.aReturningVoid(var32);
         }

         MinMaxSetting var54 = this.a;
         Object[] var35 = new Object[]{127318019014223L};
         MinMaxSetting var34 = var54;
         var34.bReturningVoid(var35);
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 73608466808436L;
      long var6 = var2 ^ 137095829889339L;
      int var8 = Event.bReturningInt();
      int var34 = var8;
      boolean var33 = this.i;
      boolean var27 = var33;
      boolean var26 = var33;
      if (var34 == 0) {
         boolean var35 = var26;
         if (!var35) {
            return null;
         }

         ElapsedTimer var10000 = this.c;
         MinMaxSetting var11 = this.a;
         Float var12 = (Float)var11.aReturningObject();
         float var10001 = var12;
         Object[] var10004 = new Object[]{null, var4};
         var10004[0] = var10001;
         Object[] var14 = var10004;
         ElapsedTimer var13 = var10000;
         boolean var36 = var13.aReturningBoolean(var14);
         var27 = var36;
      }

      MinecraftClient var32;
      label38: {
         int var38 = var8;
         boolean var37 = var27;
         boolean var31 = var37;
         boolean var28 = var37;
         if (var38 == 0) {
            boolean var39 = var28;
            if (!var39) {
               return null;
            }

            int var41 = var8;
            MinecraftClient var40 = b;
            var32 = var40;
            MinecraftClient var29 = var40;
            if (var41 != 0) {
               break label38;
            }

            MinecraftClient var42 = var29;
            MinecraftClient var30 = var42;
            MinecraftClient var18 = var30;
            boolean var43 = var18.isWindowFocused();
            var31 = var43;
         }

         boolean var44 = var31;
         if (!var44) {
            return null;
         }

         var32 = b;
      }

      MinecraftClient var20 = var32;
      Screen var45 = var20.currentScreen;
      if (var45 == null) {
         Random var22 = RandomUtil.a;
         float var9 = 89.0F + var22.nextFloat() * 2.0F;
         Item var46 = Items.ENDER_PEARL;
         Runnable var47 = invokeBinding1(var9);
         Object[] var10005 = new Object[]{null, null, null, var6};
         var10005[2] = true;
         var10005[1] = var47;
         var10005[0] = var46;
         Object[] var23 = var10005;
         InventoryUtil.jReturningBoolean(var23);
         this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
         MinecraftClient var24 = b;
         ClientPlayerEntity var25 = var24.player;
         return new Rotation(var25.getYaw(), var9);
      } else {
         return null;
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private static void lambda$calculate$0(float var0) {
      long var10001 = 101990366309931L ^ 123045026190502L;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      float var5 = var7.getPitch();
      MinecraftClient var8 = b;
      float var10 = var0;
      ClientPlayerEntity var9 = var8.player;
      var9.setPitch(var10);
      Object[] var11 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var11);
      MinecraftClient var12 = b;
      float var14 = var5;
      ClientPlayerEntity var13 = var12.player;
      var13.setPitch(var14);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(79063581954256L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var2.doFinal("\u0089w´\r\u008b\u000fûí".getBytes("ISO-8859-1"));
      String var5 = b(var4).intern();
      // l = var5;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 58;
            yield var15;
         }
         case 1 -> {
            byte var16 = 36;
            yield var16;
         }
         case 2 -> {
            byte var17 = 46;
            yield var17;
         }
         case 3 -> {
            byte var18 = 24;
            yield var18;
         }
         case 4 -> {
            byte var19 = 42;
            yield var19;
         }
         case 5 -> {
            byte var20 = 3;
            yield var20;
         }
         case 6 -> {
            byte var21 = 30;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 7;
            yield var24;
         }
         case 10 -> {
            byte var25 = 35;
            yield var25;
         }
         case 11 -> {
            byte var26 = 21;
            yield var26;
         }
         case 12 -> {
            byte var27 = 14;
            yield var27;
         }
         case 13 -> {
            byte var28 = 50;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 47;
            yield var30;
         }
         case 16 -> {
            byte var31 = 55;
            yield var31;
         }
         case 17 -> {
            byte var32 = 22;
            yield var32;
         }
         case 18 -> {
            byte var33 = 9;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 18;
            yield var35;
         }
         case 21 -> {
            byte var36 = 43;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 39;
            yield var38;
         }
         case 24 -> {
            byte var39 = 17;
            yield var39;
         }
         case 25 -> {
            byte var40 = 20;
            yield var40;
         }
         case 26 -> {
            byte var41 = 60;
            yield var41;
         }
         case 27 -> {
            byte var42 = 0;
            yield var42;
         }
         case 28 -> {
            byte var43 = 49;
            yield var43;
         }
         case 29 -> {
            byte var44 = 15;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 37;
            yield var46;
         }
         case 32 -> {
            byte var47 = 26;
            yield var47;
         }
         case 33 -> {
            byte var48 = 45;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 57;
            yield var50;
         }
         case 36 -> {
            byte var51 = 4;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 2;
            yield var54;
         }
         case 40 -> {
            byte var55 = 32;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 56;
            yield var58;
         }
         case 44 -> {
            byte var59 = 16;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 10;
            yield var61;
         }
         case 47 -> {
            byte var62 = 62;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 12;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 27;
            yield var66;
         }
         case 52 -> {
            byte var67 = 8;
            yield var67;
         }
         case 53 -> {
            byte var68 = 51;
            yield var68;
         }
         case 54 -> {
            byte var69 = 29;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 61;
            yield var71;
         }
         case 57 -> {
            byte var72 = 41;
            yield var72;
         }
         case 58 -> {
            byte var73 = 33;
            yield var73;
         }
         case 59 -> {
            byte var74 = 6;
            yield var74;
         }
         case 60 -> {
            byte var75 = 31;
            yield var75;
         }
         case 61 -> {
            byte var76 = 28;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 1;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "(]5\u00016'(]\"]:(2\u0016\"C:=5gv\u001bm";
      m[1] = float.class;
      n[1] = "java/lang/Float";
      m[2] = void.class;
      n[2] = "java/lang/Void";
      m[3] = "x\u0001iu\u001axn\u0001l/\toyJo)\u0005{h\rx>Nkp";
      m[4] = "\u0012 \t.rjg\u0000\u0002!c%\u0006\u000e\t*g\u007fr";
      m[5] = boolean.class;
      n[5] = "java/lang/Boolean";
      m[6] = "=w\\\u001d\u007f\u0013=wKAs\u001c'<K_s\t M\u001b\u0002\"";
      m[7] = "e\u0004<7\u0010;e\u0004+k\u001c4\u007fO+u\u001c!x>y+Kj";
      m[8] = "\b&(#*Q\u001e&-y9F\tm.\u007f5R\u0018*9h~@)";
      m[9] = int.class;
      n[9] = "java/lang/Integer";
      m[10] = "|\u0002I\u001eL^j\u0002LD_I}IOBS]l\u000eXU\u0018HA";
      m[11] = "\u0010Q>%<\u0004eq5*-K\u0004\u007f>!)\u0011p";
      m[12] = "No\\q\u0005\u0017NoK-\t\u0018T$K3\t\rSU\u001cl_";
      m[13] = "RP4\r\\fDP1WOqS\u001b2QCeB\\%F\bs\\";
      m[14] = "i\r\u0003\u00071|b\u0002\u0012HRqw\u000f\u001d#gsf\u001c\u0001\u000fp~";
      m[15] = "/\u000e=\u0017{\u00049\u000e8Mh\u0013.E;Kd\u0007?\u0002,\\/\u0010\r";
      m[16] = "\u000e+*\u0007|@\u0005$;H\u001dN\u000e/?\u0012";
      m[17] = ";pk~Z.0\u007fz12.>pi";
      m[18] = "@n\u0011X#DVn\u0014\u00020SA%\u0017\u0004<GPb\u0000\u0013wWK";
      m[19] = "L7~j\u0017\u001d9\u0017ue\u0006RX\u0019~n\u0002\b,";
      m[20] = "Z\u0007\u001f?y\u0011Z\u0007\bcu\u001e@L\b}u\u000bG=Z)$J";
      m[21] = "tOxB~\u007ftOo\u001erpn\u0004o\u0000reiu=[*$";
      m[22] = "\u001e\u0005\u0019{B~\u0000\r\u00034>j\u001a\u0000\u0000w";
      m[23] = "2E\\2dJ$EYhw]3\u000eZn{I\"IMy0^/";
      m[24] = "\u000e.4W96{\u000e?X(y\u001a\u00004S,#n";
      m[25] = "P*E\u0014[/F*@NH8QaCHD,@&T_\u000f<X&VTUqd=VIU6S*";
      m[26] = "Q\u0019<5)\u0000$97:8OE7<1<\u00151";
      m[27] = "`,aLnI`,v\u0010bFzgv\u000ebS}\u0016-S2\u0010";
      m[28] = "\u0004\u007fj\u0014%'\u000fp{[X?\u001cwr\u0012";
      m[29] = "\u007f'I+%>i'Lq6)~lOw:=o+X`q*W";
      m[30] = "zTY%s2\u000ftR*b}nzY!f'\u001a";
      m[31] = "\u001fxhW*n\u001fx\u007f\u000b&a\u00053\u007f\u0015&t\u0002B$Hs4";
      m[32] = "H\u000evrB\u0014H\u000ea.N\u001bREa0N\u000eU43e\u001cJ";
      m[33] = "?4b`=Z?4u<1U%\u007fu\"1@\"\u000e'|h\u0001";
      m[34] = "\u001a+o,fn\u001a+xpja\u0000`xnjt\u0007\u0011-13";
      m[35] = "\u001e\u001c\u0000\"J\u001ek<\u000b-[Q\n2\u0000&_\u000b~";
      m[36] = "F\u0013F,>\u0015F\u0013Qp2\u001a\\XQn2\u000f[)\u00030jK";
      m[37] = "mm\u0011\u0006I7{m\u0014\\Z l&\u0017ZV4}a\u0000M\u001d%m";
      m[38] = "r\u001f\rVJ<\u0007?\u0006Y[sf1\rR_)\u0012";
      m[39] = "\u0011R\n\nM\u000e\u0011R\u001dVA\u0001\u000b\u0019\u001dHA\u0014\fhL\u0011\u0019Q";
      m[40] = "Ney\u0002`.G~/\u000e\u0011+-\u007f$\u0018o'Q:'\u001d/A\u0014v\u007f\u0013{pTl$\u0016\u0011";
      m[41] = "\u001c|R\u000b\tb^=\u000eYj0!=\u0003E\u0000?\u001ds\u000bW\u0015Z";
      m[42] = "\u000f-3$\u001b=Oq-wijR 2p>=\fpk\u001cY`]5.e\u0000b]\"";
      m[43] = "Z;,t^\u000fG~ \u0006\\\u0012B\"(jnD\u0000~r:9FW<$iD\u0013L\"3\u0006";
      m[44] = "\u0007\u0003^veS\u0004\u0011_6\u0014\\\u0004\u001eF[-\r]D>2zI\t\u001e\u0002|r[\u001c{";
      m[45] = "\u000f$p3a%\u00046gi\u00075`3gey?\u001cvd`9YY:<nmh\u0019 gk\u0007";
      m[46] = "\u0015\u0011io^\u007f\bTe\u001d\\b\r\bmqn4OT7\"96\u0018\u0016arDc\u0003\bv\u001d\u0000\u007fO\b`,@e\u0014\r\n";
      m[47] = "H_?\u00192B\b\u0003!J@\u001e\u0019C:F,,M\u0002d\u0010@@\u0015\u0004j\u001a>\u0003\u001eP:!";
      m[48] = "6pGB\u0005.}-\\\u0017d*\foY\u0013\u001a'p*Z\u0016ZA7w\u0007H_?t|S\u0018d";
      m[49] = "S=\bzZ=E9\u0006|5h:3\u001ckOk\u0005<\u00068\u000e\u0001";
      m[50] = "B_\u0012?,J_\u001a\u001eM.WZF\u0016!\u001c\u0001\u0018\u001aLpK\u0003OX\u001a\"6VTF\rM";
      m[51] = ";\u0014\u0016mo\u001c0\u0006\u00017\t\rT\u0003\u0001;w\u0006(F\u0002>7`m\nZ0cQ-\u0010\u00015\t";
      m[52] = "Uj@F\u0011{\u00156^\u0015c,\bgA\u00124{V0\u0019~\u0007;\nxB\u000e\u001a~\u0006";
      m[53] = "3!\u0003\u0003X\"m~\u0000\u0003#+\f9[Q]$p|XT\u001dB50\u0000ZIsu*[_#";
      m[54] = "=$b(\u0004dn7o{?~V?e)Az*zf,\u0001\u001cm';r\u0004b.,o\"?";
      m[55] = "s[\"<DOz\b}`.MxDs:B\u007f%\u0004-l.\u0016{Fy8\u0012XsTl]V\u0012(\u0001\"a\\OkU\u0013";
      m[56] = "\u001b/_g(yG%\u00059W!{-\u000b+j \u0007&\u0019<0";
      m[57] = "HfHRJLZaA\\8BD0G^o\u001c\u001bf\u001f2USY3@VJ\u001dT3";
      m[58] = "\n43\n]G\u0017'2\u0005bW\u000f=r\"[\u0006Tb\n\u0017\u001eB\u0011ar\u0019X\u0002\u0011X";
      m[59] = "%DYfT=+\u0002\u0019fm(>EN{\u0016E-AKe\u0007z\"[\u0018$m~&\u0003\u0017$\u0013=-WG\u001f";
      m[60] = "\u0000*8*UX^u;*.Q?2`xP^Cwc}\u00108\u0004*>#\u0015FG!js.";
      m[61] = "\u0012\u0018!6kU\u0011\n v\u001aT\u001b\u001c!+vfJQys#1\u0013\u0007{%|QO^zr\u001aWJ\u000f.&h\r\n\u00048L";
      m[62] = "0D}RZ:b\u001fnW8l\u0001\u0012u\u0004\u0000=q\u0019`S\t\u00050Q6\r\u0000u;Da\u00048";
      m[63] = "%6\u0007z\u0011pej\u0019)c'x;\u0006.4p'f]B\u0005*(7\b%\fywk";
      m[64] = "\"(IAq\f$)I^\u001a\u000e,2]MD\t,(Y1#\t6>[Lv\u0012()4";
      m[65] = "\u001ey[jR\u0017\u0018w^v DB{Zxw\u0017\u0013.\u000e\u0014\u001dEFhL)\u001bKCt";
      m[66] = "c\u001b\u0007\u000e\u0004>9[\f\u0018n)h[\b\u0006\u0002\u001b9\u0017WPTLgKQ\u001eQ7zXP\u0011n";
      m[67] = "\u0001Egz\rSBOe4fVyZz.\u0018Y\u0005\u001fy+X?\u0003N'&[[\u001eRg}f";
      m[68] = "`Rx9.\u0007>Eq9\u001e\u000fcNv\u0014z\u000egB\ncw\u0017eQw6l\tr>";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1191586566140607L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1191586566140607L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1191586566140607L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 107;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 208;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 223;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 231;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 73;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 243;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 107;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 208;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 223;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ej_C0236",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ej" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(float var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(F)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/ej_C0236", "lambda$calculate$0", "(F)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((float)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
