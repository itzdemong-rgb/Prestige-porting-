package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.StringSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;

public class AutoText extends Module {
   private StringSetting a;
   private static final Object[] k = new Object[25];
   private static final String[] l = new String[25];

   @Override
   public void dReturningVoid(Object[] var1) {
      long var4;
      label17: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 97434553232679L;
         int var10000 = Event.cReturningInt();
         StringSetting var8 = this.a;
         String var9 = (String)var8.aReturningObject();
         String var7 = var9.toString();
         int var6 = var10000;
         int var30 = var6;
         String var29 = var7;
         Object var28 = var29;
         String var27 = var29;
         if (var30 != 0) {
            String var11 = "/";
            String var10 = var27;
            boolean var31 = var10.startsWith(var11);
            if (var31) {
               MinecraftClient var13 = b;
               ClientPlayNetworkHandler var14 = var13.getNetworkHandler();
               ClientPlayNetworkHandler var34 = Objects.requireNonNull(var14);
               String var15 = var7;
               String var18 = var15.substring(1);
               ClientPlayNetworkHandler var17 = var34;
               var17.sendChatCommand(var18);
               int var32 = var6;
               if (var32 != 0) {
                  break label17;
               }
            }

            MinecraftClient var20 = b;
            ClientPlayNetworkHandler var21 = var20.getNetworkHandler();
            Object var33 = Objects.requireNonNull(var21);
            var28 = var33;
         }

         ClientPlayNetworkHandler var35 = (ClientPlayNetworkHandler)var28;
         String var24 = var7;
         ClientPlayNetworkHandler var23 = var35;
         var23.sendChatMessage(var24);
      }

      Object[] var26 = new Object[]{var4};
      AutoText var25 = this;
      var25.aReturningVoid(var26);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   static {
      f();
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = l[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = k[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 13;
            yield var15;
         }
         case 1 -> {
            byte var16 = 37;
            yield var16;
         }
         case 2 -> {
            byte var17 = 12;
            yield var17;
         }
         case 3 -> {
            byte var18 = 43;
            yield var18;
         }
         case 4 -> {
            byte var19 = 55;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 19;
            yield var21;
         }
         case 7 -> {
            byte var22 = 28;
            yield var22;
         }
         case 8 -> {
            byte var23 = 40;
            yield var23;
         }
         case 9 -> {
            byte var24 = 18;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 15;
            yield var26;
         }
         case 12 -> {
            byte var27 = 6;
            yield var27;
         }
         case 13 -> {
            byte var28 = 57;
            yield var28;
         }
         case 14 -> {
            byte var29 = 39;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 46;
            yield var31;
         }
         case 17 -> {
            byte var32 = 11;
            yield var32;
         }
         case 18 -> {
            byte var33 = 50;
            yield var33;
         }
         case 19 -> {
            byte var34 = 34;
            yield var34;
         }
         case 20 -> {
            byte var35 = 23;
            yield var35;
         }
         case 21 -> {
            byte var36 = 48;
            yield var36;
         }
         case 22 -> {
            byte var37 = 0;
            yield var37;
         }
         case 23 -> {
            byte var38 = 47;
            yield var38;
         }
         case 24 -> {
            byte var39 = 26;
            yield var39;
         }
         case 25 -> {
            byte var40 = 51;
            yield var40;
         }
         case 26 -> {
            byte var41 = 44;
            yield var41;
         }
         case 27 -> {
            byte var42 = 4;
            yield var42;
         }
         case 28 -> {
            byte var43 = 7;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 31;
            yield var45;
         }
         case 31 -> {
            byte var46 = 20;
            yield var46;
         }
         case 32 -> {
            byte var47 = 41;
            yield var47;
         }
         case 33 -> {
            byte var48 = 54;
            yield var48;
         }
         case 34 -> {
            byte var49 = 29;
            yield var49;
         }
         case 35 -> {
            byte var50 = 24;
            yield var50;
         }
         case 36 -> {
            byte var51 = 3;
            yield var51;
         }
         case 37 -> {
            byte var52 = 61;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 32;
            yield var54;
         }
         case 40 -> {
            byte var55 = 33;
            yield var55;
         }
         case 41 -> {
            byte var56 = 58;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 35;
            yield var58;
         }
         case 44 -> {
            byte var59 = 27;
            yield var59;
         }
         case 45 -> {
            byte var60 = 62;
            yield var60;
         }
         case 46 -> {
            byte var61 = 10;
            yield var61;
         }
         case 47 -> {
            byte var62 = 60;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 22;
            yield var64;
         }
         case 50 -> {
            byte var65 = 8;
            yield var65;
         }
         case 51 -> {
            byte var66 = 45;
            yield var66;
         }
         case 52 -> {
            byte var67 = 5;
            yield var67;
         }
         case 53 -> {
            byte var68 = 42;
            yield var68;
         }
         case 54 -> {
            byte var69 = 16;
            yield var69;
         }
         case 55 -> {
            byte var70 = 2;
            yield var70;
         }
         case 56 -> {
            byte var71 = 14;
            yield var71;
         }
         case 57 -> {
            byte var72 = 17;
            yield var72;
         }
         case 58 -> {
            byte var73 = 56;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 1;
            yield var75;
         }
         case 61 -> {
            byte var76 = 21;
            yield var76;
         }
         case 62 -> {
            byte var77 = 30;
            yield var77;
         }
         default -> 38;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            l[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      k[0] = "z\u007fqA\u0000Ldwk\u000ea[z{dT]";
      k[1] = "|jhn\u0001Fwey!`H|n}{";
      k[2] = "\u0007$S6\u0012T\u0011$Vl\u0001C\u0006oUj\rW\u0017(B}FE&";
      k[3] = int.class;
      l[3] = "java/lang/Integer";
      k[4] = "\u0017\u000eY2hh\u0001\u000e\\h{\u007f\u0016E_nwk\u0007\u0002Hy<|\"";
      k[5] = "\u0014\u0016fL$za6mC55\u00008fH1ot";
      k[6] = void.class;
      l[6] = "java/lang/Void";
      k[7] = "#m\f*Nt#m\u001bvB{9&\u001bhBn>WK5\u0013";
      k[8] = "r\"\u0010\u0010\u000f{r\"\u0007L\u0003thi\u0007R\u0003ao\u0018R\rV";
      k[9] = "$4\"}Db24''Wu%\u007f$![a4836\u0010v\u0006";
      k[10] = "KQ)u\u001d?@^8:`'SY1s";
      k[11] = boolean.class;
      l[11] = "java/lang/Boolean";
      k[12] = "\nt`\u0016/$\u001cteL<3\u000b?fJ0'\u001axq]{1\u0005";
      k[13] = "[^C|\u0007\u0003PQR3d\u000eE\\]XQ\fTOAtF\u0001";
      k[14] = "\u0000\tMj)B_\u0017P{IO>\u0013Xd9\u001c^\u0010EuI";
      k[15] = "{Bq.n1'X0O)9d@(5>\u0012z[\u000f270\u001dF9=#n}E$,S/mO9u3,p^I";
      k[16] = "`H\u007f%wV5[`6\u001c\u0015\"Cz2f\u000f9F\u0001t}Ro\u0013n)d\u0016o)>/b\u00054\u0011k<}\u0016_";
      k[17] = "e/j\u001a\bh1.-\u0017va6m5M\u001aSg,j\u0010G\u0004dp+A\u001d<1c4Rv8'*h\u0015F46nh*";
      k[18] = "YP\n\\\"O\rQMQ\\F\n\u0012U\u000b0t[S\nWd#X\u000fK\u00077\u001b\r\u001cT\u0014\\\u001f\u001bU\bSl\u0013\n\u0011\bl";
      k[19] = "s\u001d,`MM&\u000e3s&\t+'.qG\u0013#|mjX\u001e'D8yG\rL";
      k[20] = "v$h)|N#7w:\u0017\r5,l>l)(9vB(\u00177.}z}\u0004(=\u0016r,J;|/rw\u0011%E";
      k[21] = "fw|\u0012[Bc<s^jF\\t{RZ\u00173)b\u0016Z-";
      k[22] = "N\u0012%]u\u0014\u0018V3\u0006O\u001ftQr\r#\u0019K\u0001#\u0006.vH\u0011qPpFD\u00005PO";
      k[23] = "\\\u0001M#f\u0010\u0005O\r;\u001e@lAX:oXP\u0015Kfs)]\u001eW*o\u0015\t\r\u000b6\u001e";
      k[24] = "=\r\u000f\\a\u0000{^\u0003\u000b\u001eYm\u0018^Urk9Y\u0000\b\u001e\u0002>[\u000eLrV?\u001c\u00032";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = k[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = k[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            k[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  k[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(81655281774812L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = k[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  k[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(81655281774812L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        k[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(81655281774812L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 110;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 220;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 202;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 225;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 113;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 164;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 110;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 220;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 202;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ek_C0238",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ek" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
