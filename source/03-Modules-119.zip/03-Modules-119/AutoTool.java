package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.AirBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

public class AutoTool extends Module {
   private int a = -1;
   private static final long k = 41515558005279L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[62];
   private static final String[] p = new String[62];

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 9385584860485L ^ 76793992394231L;
      var10001 = 9385584860485L ^ 41280917019210L;
      var10001 = 9385584860485L ^ 80802008160307L;
      int var10 = Event.bReturningInt();
      MinecraftClient var14 = b;
      int var46 = var10;
      HitResult var45 = var14.crosshairTarget;
      HitResult var38 = var45;
      HitResult var37 = var45;
      if (var46 == 0) {
         boolean var47 = var37 instanceof BlockHitResult;
         if (!var47) {
            return;
         }

         MinecraftClient var17 = b;
         var38 = var17.crosshairTarget;
      }

      BlockHitResult var11 = (BlockHitResult)var38;
      BlockHitResult var18 = var11;
      BlockPos var12 = var18.getBlockPos();
      MinecraftClient var19 = b;
      BlockPos var21 = var12;
      ClientWorld var20 = var19.world;
      BlockState var22 = var20.getBlockState(var21);
      byte var10000 = ((byte)((var22.isAir()) ? 1 : 0));
      int var49 = var10;
      byte var48 = var10000;
      int var40 = var48;
      byte var39 = var48;
      if (var49 == 0) {
         byte var50 = var39;
         if (var50 != 0) {
            return;
         }

         Object[] var25 = new Object[]{var12, 85069323610290L};
         AutoTool var24 = this;
         var40 = var24.aReturningInt(var25);
      }

      int var44;
      int var13 = var40;
      int var52 = var10;
      int var51 = var13;
      var44 = var51;
      int var41 = var51;
      label39:
      if (var52 == 0) {
         // int var53 = var41;
         if (var53 != var54) {
            MinecraftClient var27 = b;
            GameOptions var28 = var27.options;
            KeyBinding var29 = var28.attackKey;
            var10000 = ((byte)((var29.isPressed()) ? 1 : 0));
            int var56 = var10;
            byte var55 = var10000;
            var44 = var55;
            byte var42 = var55;
            if (var56 != 0) {
               break label39;
            }

            byte var57 = var42;
            byte var43 = var57;
            byte var58 = var43;
            if (var58 != 0) {
               Object[] var32 = new Object[]{49487520630543L};
               this.a = InventoryUtil.aReturningInt(var32);
               Object[] var10003 = new Object[]{null, 72518082610550L};
               var10003[0] = var13;
               Object[] var33 = var10003;
               InventoryUtil.aReturningVoid(var33);
               int var59 = var10;
               if (var59 == 0) {
                  return;
               }
            }
         }

         int var60 = this.a;
         var44 = var60;
      }

      Object[] var64 = new Object[]{null, 72518082610550L};
      var64[0] = var44;
      Object[] var36 = var64;
      InventoryUtil.aReturningVoid(var36);
   }

   private int aReturningInt(Object[] var1) {
      BlockPos var4 = (BlockPos)var1[0];
      long var2 = (Long)var1[1];
      var2 = 41515558005279L ^ var2;
      int var10000 = Event.cReturningInt();
      int var6 = -1;
      float var7 = 1.0F;
      int var5 = var10000;

      int var55;
      while (true) {
         short var10001 = 2598;
         long var10002 = 7076147288535645598L ^ var2;
         byte var57 = 8;
         int var56 = var8;
         if (var56 <= var57) {
            MinecraftClient var12 = b;
            ClientPlayerEntity var13 = var12.player;
            PlayerInventory var78 = var13.getInventory();
            int var15 = var8;
            PlayerInventory var14 = var78;
            ItemStack var9 = var14.getStack(var15);
            int var58 = var5;
            if (var58 != 0) {
               ItemStack var16 = var9;
               int var79 = (((var16.isEmpty()) ? 1 : 0));
               int var60 = var5;
               byte var59 = (byte)var79;
               var55 = var59;
               byte var46 = var59;
               if (var60 == 0) {
                  break;
               }

               byte var61 = var46;
               byte var47 = var61;
               byte var62 = var47;
               label53:
               if (var62 == 0) {
                  ItemStack var19 = var9;
                  var79 = var19.getMaxDamage();
                  ItemStack var20 = var9;
                  var79 -= var20.getDamage();
                  int var64 = var5;
                  int var63 = var79;
                  int var50 = var63;
                  int var48 = var63;
                  if (var64 != 0) {
                     int var65 = var48;
                     int var49 = var65;
                     var10001 = 9868;
                     var10002 = 4366738484669059381L ^ var2;
                     byte var67 = 10;
                     int var66 = var49;
                     if (var66 <= var67) {
                        int var68 = var5;
                        if (var68 != 0) {
                           break label53;
                        }
                     }

                     MinecraftClient var24 = b;
                     ClientWorld var25 = var24.world;
                     DynamicRegistryManager var82 = var25.getRegistryManager();
                     RegistryKey var26 = Enchantments.EFFICIENCY;
                     RegistryKey var28 = var26.getRegistryRef();
                     DynamicRegistryManager var27 = var82;
                     Optional var29 = var27.getOptional(var28);
                     Registry var83 = (Registry)var29.get();
                     RegistryKey var30 = Enchantments.EFFICIENCY;
                     Identifier var32 = var30.getValue();
                     Registry var31 = var83;
                     Optional var33 = var31.getEntry(var32);
                     RegistryEntry var84 = (RegistryEntry)var33.get();
                     ItemStack var35 = var9;
                     RegistryEntry var34 = var84;
                     int var69 = EnchantmentHelper.getLevel(var34, var35);
                     var50 = var69;
                  }

                  float var10 = var50;
                  MinecraftClient var37 = b;
                  BlockPos var39 = var4;
                  ClientWorld var38 = var37.world;
                  BlockState var41 = var38.getBlockState(var39);
                  ItemStack var40 = var9;
                  float var11 = var40.getMiningSpeedMultiplier(var41);
                  MinecraftClient var42 = b;
                  BlockPos var44 = var4;
                  ClientWorld var43 = var42.world;
                  BlockState var45 = var43.getBlockState(var44);
                  byte var85 = ((byte)((var45.getBlock() instanceof AirBlock) ? 1 : 0));
                  int var71 = var5;
                  byte var70 = var85;
                  int var52 = var70;
                  byte var51 = var70;
                  if (var71 != 0) {
                     byte var72 = var51;
                     if (var72 != 0) {
                        return -1;
                     }

                     float var88;
                     var52 = (var88 = var10 + var11 - var7) == 0.0F ? 0 : (var88 < 0.0F ? -1 : 1);
                  }

                  int var74 = var5;
                  int var73 = var52;
                  int var54 = var73;
                  int var53 = var73;
                  if (var74 != 0) {
                     int var75 = var53;
                     if (var75 <= 0) {
                        break label53;
                     }

                     var7 = var10 + var11;
                     var54 = var8;
                  }

                  var6 = var54;
               }

               var8++;
            }

            int var76 = var5;
            if (var76 != 0) {
               continue;
            }
         }

         var55 = var6;
         break;
      }

      return var55;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(62168303485186L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "\u0015yD\u0003¹\u000fïG\u0013ç¿[gæ\u009eK";
      int var7 = "\u0015yD\u0003¹\u000fïG\u0013ç¿[gæ\u009eK".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Integer[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29973;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/el", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/el_C0240",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/el" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 14;
            yield var15;
         }
         case 1 -> {
            byte var16 = 63;
            yield var16;
         }
         case 2 -> {
            byte var17 = 48;
            yield var17;
         }
         case 3 -> {
            byte var18 = 19;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 29;
            yield var20;
         }
         case 6 -> {
            byte var21 = 21;
            yield var21;
         }
         case 7 -> {
            byte var22 = 0;
            yield var22;
         }
         case 8 -> {
            byte var23 = 59;
            yield var23;
         }
         case 9 -> {
            byte var24 = 44;
            yield var24;
         }
         case 10 -> {
            byte var25 = 62;
            yield var25;
         }
         case 11 -> {
            byte var26 = 46;
            yield var26;
         }
         case 12 -> {
            byte var27 = 9;
            yield var27;
         }
         case 13 -> {
            byte var28 = 34;
            yield var28;
         }
         case 14 -> {
            byte var29 = 8;
            yield var29;
         }
         case 15 -> {
            byte var30 = 42;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 60;
            yield var32;
         }
         case 18 -> {
            byte var33 = 2;
            yield var33;
         }
         case 19 -> {
            byte var34 = 1;
            yield var34;
         }
         case 20 -> {
            byte var35 = 11;
            yield var35;
         }
         case 21 -> {
            byte var36 = 58;
            yield var36;
         }
         case 22 -> {
            byte var37 = 43;
            yield var37;
         }
         case 23 -> {
            byte var38 = 17;
            yield var38;
         }
         case 24 -> {
            byte var39 = 22;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 16;
            yield var41;
         }
         case 27 -> {
            byte var42 = 40;
            yield var42;
         }
         case 28 -> {
            byte var43 = 12;
            yield var43;
         }
         case 29 -> {
            byte var44 = 37;
            yield var44;
         }
         case 30 -> {
            byte var45 = 6;
            yield var45;
         }
         case 31 -> {
            byte var46 = 45;
            yield var46;
         }
         case 32 -> {
            byte var47 = 54;
            yield var47;
         }
         case 33 -> {
            byte var48 = 24;
            yield var48;
         }
         case 34 -> {
            byte var49 = 35;
            yield var49;
         }
         case 35 -> {
            byte var50 = 20;
            yield var50;
         }
         case 36 -> {
            byte var51 = 47;
            yield var51;
         }
         case 37 -> {
            byte var52 = 26;
            yield var52;
         }
         case 38 -> {
            byte var53 = 28;
            yield var53;
         }
         case 39 -> {
            byte var54 = 52;
            yield var54;
         }
         case 40 -> {
            byte var55 = 50;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 61;
            yield var57;
         }
         case 43 -> {
            byte var58 = 53;
            yield var58;
         }
         case 44 -> {
            byte var59 = 18;
            yield var59;
         }
         case 45 -> {
            byte var60 = 7;
            yield var60;
         }
         case 46 -> {
            byte var61 = 25;
            yield var61;
         }
         case 47 -> {
            byte var62 = 10;
            yield var62;
         }
         case 48 -> {
            byte var63 = 23;
            yield var63;
         }
         case 49 -> {
            byte var64 = 51;
            yield var64;
         }
         case 50 -> {
            byte var65 = 3;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 55;
            yield var67;
         }
         case 53 -> {
            byte var68 = 36;
            yield var68;
         }
         case 54 -> {
            byte var69 = 38;
            yield var69;
         }
         case 55 -> {
            byte var70 = 49;
            yield var70;
         }
         case 56 -> {
            byte var71 = 57;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 13;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 5;
            yield var75;
         }
         case 61 -> {
            byte var76 = 15;
            yield var76;
         }
         case 62 -> {
            byte var77 = 33;
            yield var77;
         }
         default -> 31;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "\u0015W2sr0\u0003W7)a'\u0014\u001c4/m3\u0005[#8&%\u001d";
      o[1] = "SX\u0011].\u0014&x\u001aR?[Gv\u0011Y;\u00013";
      o[2] = int.class;
      p[2] = "java/lang/Integer";
      o[3] = "@3h\u001e.KV3mD=\\AxnB1HP?yUzZa";
      o[4] = "\u0000ZIC|\b\u0000Z^\u001fp\u0007\u001a\u0011^\u0001p\u0012\u001d`\u000e\\!";
      o[5] = "-?a\nt4-?vVx;7tvHx.0\u0005&\u0015,";
      o[6] = "C=Unt;U=P4g,BvS2k8S1D% (H";
      o[7] = "w$KnY8\u0002\u0004@aHwc\nKjL-\u0017";
      o[8] = void.class;
      p[8] = "java/lang/Void";
      o[9] = "\u0002\t\fBh8\t\u0006\u001d\r\u000b5\u001c\u000b\u0012f>7\r\u0018\u000eJ):";
      o[10] = "rU\u0010\u001f+zrU\u0007C'uh\u001e\u0007]'`ooV\u0002\u007f";
      o[11] = "q=~o\b?q=i3\u00040kvi-\u0004%l\u0007<r]";
      o[12] = "rZ~\u0011tGrZiMxHh\u0011iSx]o`9\u000f-";
      o[13] = boolean.class;
      p[13] = "java/lang/Boolean";
      o[14] = "t5 \u0007EQ\u0001\u0015+\bT\u001e`\u001b \u0003PD\u0014";
      o[15] = "\u007f\\&F\u007ft\u007f\\1\u001as{e\u00171\u0004snbf`^*-";
      o[16] = "\u001d;MAfo\u001d;Z\u001dj`\u0007pZ\u0003ju\u0000\u0001\nV=3";
      o[17] = "jb\u001d3\\mjb\noPbp)\nqPwwX[.\u0002<";
      o[18] = ",,R<C$,,E`O+6gE~O>1\u0016\u0017%\u0017t";
      o[19] = "B[2\u0005_\nB[%YS\u0005X\u0010%GS\u0010_aq\u001f\u0004";
      o[20] = "\u0016\u001f\u000fS1\u001a\u0016\u001f\u0018\u000f=\u0015\fT\u0018\u0011=\u0000\u000b%JKjB";
      o[21] = float.class;
      p[21] = "java/lang/Float";
      o[22] = "(#\u001ctyr(#\u000b(u}2h\u000b6uh5\u0019Zh #";
      o[23] = "m^]\u0010\u000bYm^JL\u0007Vw\u0015JR\u0007Cpd\u0018\u0006_\u0003";
      o[24] = "B3\bw6ZB3\u001f+:UXx\u001f5:@_\tIji\u0002";
      o[25] = "jcgR\u00051jcp\u000e\t>p(p\u0010\t+wY&H]m";
      o[26] = ":I\u0017'/y$A\rhN|$A\u000e(``";
      o[27] = "EoR{\t\u001dEoE'\u0005\u0012_$E9\u0005\u0007XU\u0014lRD";
      o[28] = "\u001aA!\u0004JX\u001aA6XFW\u0000\n6FFB\u0007{g\u0019\u0010\t";
      o[29] = "T3)`\u001e\u0001_<8/\u007f\u000fT7<u";
      o[30] = "\u0015jd0\n=\u0015jsl\u00062\u000f!sr\u0006'\bP!&^d";
      o[31] = "h\u000fO7(jh\u000fXk$erDXu$pu5\r!}3";
      o[32] = "1_\u0013t;P5@V=\u0002\u0006\u000b\u0000\u0005 aRu\u0003U?kl";
      o[33] = "u\u0015-$,\u0012)\bmvC\u0015t\u00125r/'\"Wh)spt\u0000:t&\u0015|\u0003h,C";
      o[34] = "#K\u0016C\u001dky\u0010\f\u0017,c%U\u0010I@Qw\u0018K\u0010,?'M\u0013\u0010R<wR\u0019.";
      o[35] = "v\r_%\u00000,VEq18p\u0013Y/]\n\"^\u0003t14zQ@7C;`\u0005_H_a'T\u0002r^9#\u00049";
      o[36] = "57(\f5b:-|\u0013Ju1,v\u0012&Gfn,Mv\u00102:vM1~74z\u001bJ";
      o[37] = "\n\u0013\u000e4@YF\u0011\u00177/I6E\u0010,@\u001a_T\u0017<N \u000bP\u0017*\u0012IL]\u0007~/";
      o[38] = "rb;\u0004fPc97gc0 !-\\0Kn8%Z\n\u000ee*f]q@|\"`g";
      o[39] = "mC\u0000=UOr[X{7\u0010b_]i`O:\t\u0000\u0005X\u0007}MC8V\u0012bX";
      o[40] = "\u0011,\u00193B Kw\u0003gs(\u00172\u001f9\u001f\u001aE\u007fAfs|CuB3\u0017$\u0017'\u0012^";
      o[41] = "\u007f>r\u0005[~{!7Lb)EadQ\u0001|;b4N\u000bB";
      o[42] = "%FB*efuY\u0010v\\z(ENu0Hy\u0007\u0011/m\u001f*@Pm&\"$UOx\\~t\\M|2z8\b\u0014\u0012";
      o[43] = "\ryr[*o\u0003m/\u0013Ng_c+E\"U\t'p\u001e\u007f\u0002R`'\u001aw{\u0002\u007fuFN";
      o[44] = "f9WNV'lj\u0006Yi7<:\\G>`bm\u0004+\u0005\"%fWIY?e4";
      o[45] = "Y#J3'D\u0015!S0HTeuT+'\u0007\fdS;)=\\s\\!vC_#C+H";
      o[46] = "fF\u001ag Ev\u001aOfLMi_\u0014` \u007f=\u001bN=w(e_I` W>_HaLI5F\u0017i\"My\u0012N\u0007";
      o[47] = "o@x\u0006/\u0006f\u0001'\u0012_\u0012h\r\u007f\u000b3 <N S`wnOp\u00069\u0007j\rp\u0002_";
      o[48] = "\u0014\u007f\u000fY{G\u001akR\u0011\u001fOFeVGs}\u001b\"\f\u0018\u001fA\u0015v\\FoEWvX vM\u0015`IRyWA\u007f6";
      o[49] = "Ryf\u0005{A]v:\u0006\u0006\u001e\\x=\u001aj,\u0001>g@\u0006\u001fA?g\u0019dDR;>}m\u0019Wil\u00107BM=]Di\u001fR:#G9\u0000X\u0004";
      o[50] = "\u0004\u0007K~C/D\u0006Td2 ^\u0011Imew\u000fL\u0013\u0001\u0002<\\\u001eRa\u000f+Q\u0007";
      o[51] = "FzB\u0013\tvW!Np\f\u0016C.M\u001f_\u007fR)]\u0011e/E&GN\u001b,\u00159Mp";
      o[52] = "\t.B3%hSuXg\u0014`\u000f0D9xR]}\u001do\u0014<\r(G`j?]7M^";
      o[53] = "kj\"a>\na9sv\u0001\u001a1i)hVMn5u\u0004:\u000f6{<ez\u000e)a";
      o[54] = "\u0012=\u007fv\u001cu\u0018n.a#eH>t\u007ft2\u0016m-\u0013\u001c`\u0016>}kFmT9";
      o[55] = ".\u0004=C3v&\u0007o\u001bVv.\u00162E:D~Vi\u0012V*,\u000e1\u001c()|\u0011;\"=q%\u0007cOg*?SR";
      o[56] = "ecw<(xo0&+\u0017h?`|5@?`='Y(`gt|4&t:<";
      o[57] = "Tia\u0016\u0016_Y~l\u000fiZ\tgb\u0013\u0005h]'9Hi\u000e] ?\u0019\rV\trot";
      o[58] = "hD;\fDig^o\u0013;~l_e\u0012WL;\u001d?L\u0006\u001b0\u001a>HV\u007fhNl\u0018;";
      o[59] = "hI_t\rlf\\@aw4jLAl\u001b\u0006=\u0001\u00184HQfL\u001cl\u001b.=L\u001dmw";
      o[60] = "\u0011O&:IW\u0015\u0003rc'V\u001d\u0002C:HG\u001bF!aB\u0005\u0012~";
      o[61] = "ytU-z\u007fwaJ8\u0000'{qK5l\u0015+=\u0011m;BytU-z\u007fwaJ8\u0000";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2078792334304003L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2078792334304003L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2078792334304003L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 225;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 238;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 79;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 36;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 203;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 193;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 225;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 238;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 79;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/el_C0240",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/el" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
