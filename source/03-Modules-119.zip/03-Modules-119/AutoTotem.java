package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.HandledScreenAccessor;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.client.modules.state.TotemDamageSample;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.PacketUtil;
import dev.zprestige.prestige.client.management.NotificationManager;
import dev.zprestige.prestige.api.reflect.ReflectedField;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.client.modules.state.AutoTotemState;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.MovementEvaluationUtil;
import dev.zprestige.prestige.api.util.PredictionResult;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.ui.InventoryInputScreen;
import dev.zprestige.prestige.client.management.PacketQueueResult;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.util.PredictionType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.GraphicsEnvironment;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Robot;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageEffects;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.BundlePacket;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntry.Type;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class AutoTotem extends Module {
   private static final long a;
   private ModeSetting c;
   private MinMaxSetting d;
   private BooleanSetting e;
   private MultiModeSetting f;
   private MultiModeSetting g;
   private IntSetting h;
   private BooleanSetting i;
   private MinMaxSetting j;
   private BooleanSetting k;
   private MinMaxSetting l;
   private MinMaxSetting m;
   private MultiModeSetting n;
   private FloatSetting o;
   private BooleanSetting p;
   private BooleanSetting q;
   private ElapsedTimer r;
   private ElapsedTimer s;
   private boolean t;
   private boolean u;
   private InventoryScreen v;
   private int w;
   private int x;
   private AutoTotemState y;
   private int z;
   private int A;
   private long B;
   private float C;
   private Deque D;
   private static final long E;
   private float F;
   private Robot G;
   private Random H;
   private Slot I;
   private ElapsedTimer J;
   private List K;
   private int L;
   private Point M;
   private ElapsedTimer N;
   private volatile long O;
   private static final long P = 102652054115815L;
   private static final String[] Q;
   private static final String[] R;
   private static final Map S = new HashMap(13);
   private static final long[] T;
   private static final Integer[] U;
   private static final Map V;
   private static final long[] W;
   private static final Long[] X;
   private static final Map Y;
   private static final Object[] Z = new Object[296];
   private static final String[] ab = new String[296];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;

   public AutoTotem() {
      super();
      long var10001 = 40455680236889L ^ 76698684959344L;
      var10001 = 40455680236889L ^ 121269746145166L;
      var10001 = 40455680236889L ^ 71610479789110L;
      var10001 = 40455680236889L ^ 65685095034766L;
      var10001 = 40455680236889L ^ 3633375110843L;
      var10001 = 40455680236889L ^ 127586750060277L;

      this.r = new ElapsedTimer(106698256430889L);
      this.s = new ElapsedTimer(106698256430889L);
      this.t = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.u = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.w = -1;
      this.x = -1;
      this.y = AutoTotemState.NONE;
      this.z = -1;
      this.A = 0;
      this.B = 0L;
      this.C = Float.NaN;
      this.D = new ArrayDeque();
      this.F = Float.NaN;
      this.H = new Random();
      this.J = new ElapsedTimer(106698256430889L);
      this.K = new ArrayList();
      this.L = 0;
      this.M = null;
      this.N = new ElapsedTimer(106698256430889L);
      this.O = 0L;
      MultiModeSetting var10000 = this.g;
      Object[] var16 = new Object[]{invokeBinding1(this), 81913655528151L};
      MultiModeSetting var15 = var10000;
      var15.aReturningMultiModeSetting(var16);
      MinMaxSetting var41 = this.m;
      Object[] var18 = new Object[]{invokeBinding2(this), 112057026795887L};
      MinMaxSetting var17 = var41;
      var17.aReturningMinMaxSetting(var18);
      FloatSetting var42 = this.o;
      Object[] var20 = new Object[]{invokeBinding3(this), 34595201528535L};
      FloatSetting var19 = var42;
      var19.aReturningFloatSetting(var20);
      BooleanSetting var43 = this.q;
      Object[] var22 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var21 = var43;
      var21.aReturningBooleanSetting(var22);
      var10000 = this.f;
      Object[] var24 = new Object[]{invokeBinding5(this), 81913655528151L};
      MultiModeSetting var23 = var10000;
      var23.aReturningMultiModeSetting(var24);
      BooleanSetting var45 = this.i;
      Object[] var26 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var25 = var45;
      var25.aReturningBooleanSetting(var26);
      BooleanSetting var46 = this.k;
      Object[] var28 = new Object[]{invokeBinding7(this), 88791076916140L};
      BooleanSetting var27 = var46;
      var27.aReturningBooleanSetting(var28);
      var10000 = this.n;
      Object[] var30 = new Object[]{invokeBinding8(this), 81913655528151L};
      MultiModeSetting var29 = var10000;
      var29.aReturningMultiModeSetting(var30);
      IntSetting var48 = this.h;
      Object[] var32 = new Object[]{invokeBinding9(this), 43459238656994L};
      IntSetting var31 = var48;
      var31.aReturningIntSetting(var32);
      MinMaxSetting var49 = this.j;
      Object[] var34 = new Object[]{invokeBinding10(this), 112057026795887L};
      MinMaxSetting var33 = var49;
      var33.aReturningMinMaxSetting(var34);
      MinMaxSetting var50 = this.l;
      Object[] var36 = new Object[]{invokeBinding11(this), 112057026795887L};
      MinMaxSetting var35 = var50;
      var35.aReturningMinMaxSetting(var36);
      BooleanSetting var51 = this.p;
      Object[] var38 = new Object[]{invokeBinding12(this), 88791076916140L};
      BooleanSetting var37 = var51;
      var37.aReturningBooleanSetting(var38);
      BooleanSetting var52 = this.e;
      Object[] var40 = new Object[]{invokeBinding13(this), 88791076916140L};
      BooleanSetting var39 = var52;
      var39.aReturningBooleanSetting(var40);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      AutoTotem var4 = this;
      var4.fReturningVoid();
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 29452612396766L;
      Object[] var7 = new Object[]{var4};
      AutoTotem var6 = this;
      var6.jReturningVoid(var7);
      AutoTotem var8 = this;
      var8.fReturningVoid();
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      AutoTotem var4 = this;
      var4.fReturningVoid();
   }

   private void f() {
      long var10001 = 50821452419975L ^ 103299396513224L;
      var10001 = 50821452419975L ^ 9679215999879L;
      var10001 = 50821452419975L ^ 130674796510150L;
      var10001 = 50821452419975L ^ 111835468225650L;
      int var11 = Event.bReturningInt();
      int var34 = var11;
      if (var34 == 0) {
         PacketQueueManager var35 = Prestige.u;
         if (var35 != null) {
            PacketQueueManager var10000 = Prestige.u;
            Object[] var14 = new Object[]{this, 97726919206977L};
            PacketQueueManager var13 = var10000;
            var13.aReturningInt(var14);
         }

         this.t = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.u = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.O = 0L;
         this.w = -1;
         this.x = -1;
         Object[] var17 = new Object[]{83075199733749L};
         AutoTotem var16 = this;
         var16.mReturningVoid(var17);
         Deque var18 = this.D;
         var18.clear();
         this.F = Float.NaN;
         this.C = Float.NaN;
         this.v = null;
         this.I = null;
         List var19 = this.K;
         var19.clear();
         this.L = 0;
         this.M = null;
         MinMaxSetting var36 = this.d;
         Object[] var21 = new Object[]{127318019014223L};
         MinMaxSetting var20 = var36;
         var20.bReturningVoid(var21);
         var36 = this.j;
         Object[] var23 = new Object[]{127318019014223L};
         MinMaxSetting var22 = var36;
         var22.bReturningVoid(var23);
         var36 = this.m;
         Object[] var25 = new Object[]{127318019014223L};
         MinMaxSetting var24 = var36;
         var24.bReturningVoid(var25);
         ElapsedTimer var39 = this.r;
         Object[] var27 = new Object[]{42835128969216L};
         ElapsedTimer var26 = var39;
         var26.aReturningVoid(var27);
         ElapsedTimer var40 = this.s;
         Object[] var29 = new Object[]{42835128969216L};
         ElapsedTimer var28 = var40;
         var28.aReturningVoid(var29);
         ElapsedTimer var41 = this.J;
         Object[] var31 = new Object[]{42835128969216L};
         ElapsedTimer var30 = var41;
         var30.aReturningVoid(var31);
         ElapsedTimer var42 = this.N;
         Object[] var33 = new Object[]{42835128969216L};
         ElapsedTimer var32 = var42;
         var32.aReturningVoid(var33);
      }
   }

   private void jReturningVoid(Object[] var1) {
      long var4;
      int var6;
      InventoryScreen var7;
      MinecraftClient var25;
      label36: {
         long var2 = (Long)var1[0];
         var2 = 102652054115815L ^ var2;
         var4 = var2 ^ 53008842965407L;
         int var10000 = Event.cReturningInt();
         var7 = this.v;
         var6 = var10000;
         this.v = null;
         int var29 = var6;
         InventoryScreen var28 = var7;
         Object var24 = var28;
         InventoryScreen var21 = var28;
         if (var29 != 0) {
            InventoryScreen var30 = var21;
            if (var30 == null) {
               return;
            }

            int var32 = var6;
            MinecraftClient var31 = b;
            var25 = var31;
            MinecraftClient var22 = var31;
            if (var32 == 0) {
               break label36;
            }

            MinecraftClient var33 = var22;
            MinecraftClient var23 = var33;
            MinecraftClient var10 = var23;
            Screen var34 = var10.currentScreen;
            var24 = var34;
         }

         InventoryScreen var36 = var7;
         Object var35 = var24;
         if (var35 != var36) {
            return;
         }

         var25 = b;
      }

      int var38 = var6;
      MinecraftClient var37 = var25;
      MinecraftClient var27 = var37;
      MinecraftClient var26 = var37;
      if (var38 != 0) {
         MinecraftClient var13 = var26;
         ClientPlayNetworkHandler var39 = var13.getNetworkHandler();
         if (var39 != null) {
            InventoryScreen var15 = var7;
            PlayerScreenHandler var16 = (PlayerScreenHandler)var15.getScreenHandler();
            Object[] var17 = new Object[]{new CloseHandledScreenC2SPacket(var16.syncId), var4};
            PacketUtil.aReturningVoid(var17);
         }

         var27 = b;
      }

      Object var20 = null;
      MinecraftClient var19 = var27;
      var19.setScreen((Screen)var20);
   }

   private void kReturningVoid(Object[] var1) {
      HandledScreen var2 = (HandledScreen)var1[0];
      long var3 = (Long)var1[1];
      var3 = 102652054115815L ^ var3;
      long var5 = var3 ^ 46675528243290L;
      int var10000 = Event.bReturningInt();
      HandledScreen var8 = var2;
      ScreenHandler var9 = var8.getScreenHandler();
      Object[] var10 = new Object[]{new CloseHandledScreenC2SPacket(var9.syncId), var5};
      PacketUtil.aReturningVoid(var10);
      int var7 = var10000;
      Object var12 = null;
      MinecraftClient var11 = b;
      var11.setScreen((Screen)var12);
      int var16 = var7;
      AutoTotem var15 = this;
      AutoTotem var14 = var15;
      AutoTotem var13 = var15;
      if (var16 == 0) {
         HandledScreen var18 = var2;
         InventoryScreen var17 = var13.v;
         if (var17 != var18) {
            return;
         }

         AutoTotem var19 = this;
         var14 = var19;
      }

      var14.v = null;
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 52901852751895L;
      int var6 = Event.bReturningInt();
      int var18 = var6;
      byte var17 = ((byte)((this.u) ? 1 : 0));
      byte var12 = var17;
      byte var11 = var17;
      if (var18 == 0) {
         byte var19 = var11;
         if (var19 != 0) {
            label34: {
               int var21 = var6;
               PacketQueueManager var20 = Prestige.u;
               PacketQueueManager var14 = var20;
               PacketQueueManager var13 = var20;
               if (var21 == 0) {
                  PacketQueueManager var22 = var13;
                  if (var22 == null) {
                     break label34;
                  }

                  var14 = Prestige.u;
               }

               Object[] var10 = new Object[]{var4};
               PacketQueueManager var9 = var14;
               boolean var10000 = var9.aReturningBoolean(var10);
               int var24 = var6;
               boolean var23 = var10000;
               boolean var16 = var23;
               boolean var15 = var23;
               if (var24 != 0) {
                  return var16;
               }

               boolean var25 = var15;
               if (var25) {
                  return true;
               }
            }

            this.u = dev.prestige.recovery.SourceSupport.asBoolean(0);
            return false;
         }

         var12 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var12);
   }

   private boolean aReturningBoolean(Object[] var1) {
      int var4 = (Integer)var1[0];
      int var5 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      var2 = 102652054115815L ^ var2;
      long var6 = var2 ^ 49129486602492L;
      long var8 = var2 ^ 89378268989045L;
      int var10 = Event.cReturningInt();
      int var25 = var10;
      PacketQueueManager var24 = Prestige.u;
      PacketQueueManager var18 = var24;
      PacketQueueManager var17 = var24;
      if (var25 != 0) {
         PacketQueueManager var26 = var17;
         if (var26 == null) {
            Object[] var10004 = new Object[]{null, null, var6};
            var10004[1] = var5;
            var10004[0] = var4;
            Object[] var13 = var10004;
            return InventoryUtil.fReturningBoolean(var13);
         }

         var18 = Prestige.u;
      }

      Object[] var10006 = new Object[]{null, null, null, var8};
      var10006[2] = var5;
      var10006[1] = var4;
      var10006[0] = this;
      Object[] var16 = var10006;
      PacketQueueManager var15 = var18;
      PacketQueueResult var11 = var15.cReturningp_C0432(var16);
      PacketQueueResult var29 = PacketQueueResult.QUEUED;
      PacketQueueResult var28 = var11;
      AutoTotem var27 = this;
      AutoTotem var20 = var27;
      AutoTotem var19 = var27;
      AutoTotem var21;
      byte var22;
      if (var28 == var29) {
         byte var31 = 1;
         AutoTotem var30 = var19;
         var21 = var30;
         var22 = var31;
      } else {
         var22 = 0;
         var21 = var20;
      }

      var21.u = dev.prestige.recovery.SourceSupport.asBoolean(var22);
      PacketQueueResult var33 = PacketQueueResult.REJECTED;
      PacketQueueResult var32 = var11;
      byte var23;
      if (var32 != var33) {
         byte var34 = 1;
         var23 = var34;
      } else {
         var23 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var23);
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 65971068353401L;
      long var6 = var2 ^ 89326996001946L;
      int var8 = Event.bReturningInt();
      AutoTotemState var26 = AutoTotemState.NONE;
      AutoTotemState var25 = this.y;
      if (var25 == var26) {
         return false;
      }

      int var22;
      label35: {
         label39: {
            int var28 = var8;
            PacketQueueManager var27 = Prestige.u;
            PacketQueueManager var20 = var27;
            PacketQueueManager var19 = var27;
            if (var28 == 0) {
               PacketQueueManager var29 = var19;
               if (var29 == null) {
                  break label39;
               }

               var20 = Prestige.u;
            }

            Object[] var12 = new Object[]{var4};
            PacketQueueManager var11 = var20;
            byte var10000 = ((byte)((var11.aReturningBoolean(var12)) ? 1 : 0));
            int var31 = var8;
            byte var30 = var10000;
            var22 = var30;
            byte var21 = var30;
            if (var31 != 0) {
               break label35;
            }

            byte var32 = var21;
            if (var32 != 0) {
               this.A = 0;
               return true;
            }
         }

         var22 = this.A++;
      }

      int var34 = var8;
      int var33 = var22;
      int var24 = var33;
      int var23 = var33;
      if (var34 == 0) {
         int var35 = var23;
         if (var35 == 0) {
            return true;
         }

         Object[] var18 = new Object[]{var6};
         AutoTotem var17 = this;
         var17.mReturningVoid(var18);
         var24 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   private boolean fReturningBoolean(Object[] var1) {
      int var5 = (Integer)var1[0];
      AutoTotemState var4 = (AutoTotemState)var1[1];
      long var2 = (Long)var1[2];
      var2 = 102652054115815L ^ var2;
      long var6 = var2 ^ 84660236009999L;
      long var8 = var2 ^ 20616484896715L;
      long var10 = var2 ^ 60901687751133L;
      long var12 = var2 ^ 134396297649717L;
      int var14 = Event.cReturningInt();
      int var43 = var14;
      AutoTotem var42 = this;
      AutoTotem var35 = var42;
      AutoTotem var34 = var42;
      if (var43 != 0) {
         AutoTotemState var45 = AutoTotemState.NONE;
         AutoTotemState var44 = var34.y;
         if (var44 != var45) {
            return false;
         }

         var35 = this;
      }

      short var10002 = 14319;
      long var10003 = 254556457532365149L ^ var2;
      long var15 = ++var35.B;
      this.y = var4;
      this.z = var5;
      this.A = 0;
      int var47 = var14;
      PacketQueueManager var46 = Prestige.u;
      PacketQueueManager var37 = var46;
      PacketQueueManager var36 = var46;
      if (var47 != 0) {
         PacketQueueManager var48 = var36;
         if (var48 == null) {
            short var10001 = 19310;
            long var57 = 8723597661809667769L ^ var2;
            Object[] var59 = new Object[]{null, null, var12};
            var59[1] = 40;
            var59[0] = var5;
            Object[] var21 = var59;
            InventoryUtil.fReturningBoolean(var21);
            Object[] var60 = new Object[]{null, null, null, var6};
            var60[2] = var5;
            var60[1] = var4;
            var60[0] = var15;
            Object[] var23 = var60;
            AutoTotem var22 = this;
            var22.lReturningVoid(var23);
            return true;
         }

         var37 = Prestige.u;
      }

      short var58 = 16349;
      long var10004 = 8881568651270691339L ^ var2;
      Object[] var10007 = new Object[]{null, null, null, invokeBinding14(this, var15, var4, var5), var8};
      var10007[2] = 40;
      var10007[1] = var5;
      var10007[0] = this;
      Object[] var26 = var10007;
      PacketQueueManager var25 = var37;
      PacketQueueResult var17 = var25.dReturningp_C0432(var26);
      int var51 = var14;
      PacketQueueResult var50 = PacketQueueResult.IMMEDIATE;
      PacketQueueResult var49 = var17;
      PacketQueueResult var40 = var49;
      PacketQueueResult var41 = var50;
      PacketQueueResult var38 = var49;
      PacketQueueResult var39 = var50;
      if (var51 != 0) {
         PacketQueueResult var53 = var39;
         PacketQueueResult var52 = var38;
         if (var52 == var53) {
            Object[] var10006 = new Object[]{null, null, null, var6};
            var10006[2] = var5;
            var10006[1] = var4;
            var10006[0] = var15;
            Object[] var29 = var10006;
            AutoTotem var28 = this;
            var28.lReturningVoid(var29);
            return true;
         }

         var41 = PacketQueueResult.QUEUED;
         var40 = var17;
      }

      PacketQueueResult var55 = var41;
      PacketQueueResult var54 = var40;
      if (var54 == var55) {
         return true;
      }

      Object[] var33 = new Object[]{var10};
      AutoTotem var32 = this;
      var32.mReturningVoid(var33);
      return false;
   }

   private void lReturningVoid(Object[] var1) {
      long var4 = (Long)var1[0];
      AutoTotemState var3 = (AutoTotemState)var1[1];
      int var2 = (Integer)var1[2];
      long var6 = (Long)var1[3];
      var6 = 102652054115815L ^ var6;
      long var8 = var6 ^ 42606931551797L;
      int var10 = Event.cReturningInt();
      AutoTotem var11 = this;
      byte var10000 = ((byte)((var11.aReturningBoolean()) ? 1 : 0));
      int var34 = var10;
      byte var33 = var10000;
      int var25 = var33;
      byte var24 = var33;
      if (var34 != 0) {
         byte var35 = var24;
         if (!((var35) != 0)) {
            return;
         }

         long var57;
         int var36 = (var57 = var4 - this.B) == 0L ? 0 : (var57 < 0L ? -1 : 1);
         var25 = var36;
      }

      int var37 = var25;
      if (!((var37) != 0)) {
         int var39 = var10;
         AutoTotem var38 = this;
         AutoTotem var28 = var38;
         AutoTotem var26 = var38;
         if (var39 != 0) {
            AutoTotem var40 = var26;
            AutoTotem var27 = var40;
            AutoTotemState var42 = var3;
            AutoTotemState var41 = var27.y;
            if (var41 != var42) {
               return;
            }

            AutoTotem var43 = this;
            var28 = var43;
         }

         int var45 = var2;
         int var44 = var28.z;
         if (var44 == var45) {
            label31: {
               int var48 = var10;
               AutoTotemState var47 = AutoTotemState.EQUIP;
               AutoTotemState var46 = var3;
               AutoTotemState var31 = var46;
               AutoTotemState var32 = var47;
               AutoTotemState var29 = var46;
               AutoTotemState var30 = var47;
               if (var48 != 0) {
                  AutoTotemState var50 = var30;
                  AutoTotemState var49 = var29;
                  if (var49 == var50) {
                     this.w = var2;
                     int var51 = var10;
                     if (var51 != 0) {
                        break label31;
                     }
                  }

                  AutoTotemState var53 = AutoTotemState.RESTORE;
                  AutoTotemState var52 = var3;
                  var31 = var52;
                  var32 = var53;
               }

               AutoTotemState var55 = var32;
               AutoTotemState var54 = var31;
               if (var54 == var55) {
                  this.w = -1;
               }
            }

            Object[] var23 = new Object[]{var8};
            AutoTotem var22 = this;
            var22.mReturningVoid(var23);
            return;
         }
      }
   }

   private void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      this.y = AutoTotemState.NONE;
      this.z = -1;
      this.A = 0;
      short var10002 = 5721;
      long var10003 = 7555105798216080594L ^ var2;
      this.B++;
   }

   private boolean gReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 11699058134028L;
      int var10000 = Event.bReturningInt();
      long var7 = this.O;
      short var10002 = 27093;
      long var10003 = 4978006901350969120L ^ var2;
      this.O = 0L;
      int var6 = var10000;
      MultiModeSetting var31 = this.n;
      short var10001 = 1771;
      long var34 = 8566475341448762144L ^ var2;
      Object[] var10 = new Object[]{"Anti Totem Guard Test", var4};
      MultiModeSetting var9 = var31;
      byte var32 = ((byte)((var9.aReturningBoolean(var10)) ? 1 : 0));
      int var19 = var6;
      byte var18 = var32;
      int var12 = var18;
      byte var11 = var18;
      if (var19 == 0) {
         byte var20 = var11;
         if (var20 == 0) {
            return false;
         }

         var10001 = 27093;
         long var35 = 4978006901350969120L ^ var2;
         long var36;
         int var21 = (var36 = var7 - 0L) == 0L ? 0 : (var36 < 0L ? -1 : 1);
         var12 = var21;
      }

      int var23 = var6;
      int var22 = var12;
      int var14 = var22;
      int var13 = var22;
      if (var23 == 0) {
         int var24 = var13;
         if (var24 == 0) {
            return false;
         }

         long var37;
         int var25 = (var37 = System.currentTimeMillis() - var7) == 0L ? 0 : (var37 < 0L ? -1 : 1);
         var14 = var25;
      }

      int var27 = var6;
      int var26 = var14;
      int var16 = var26;
      int var15 = var26;
      if (var27 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var16);
      } else {
         int var28 = var15;
         if (var28 <= 0) {
            byte var38 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var38);
         } else {
            return false;
         }
      }
   }

   private float bReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 104339986071309L;
      long var6 = var2 ^ 5227383036123L;
      long var8 = var2 ^ 22126967428581L;
      long var10 = var2 ^ 29919370117210L;
      long var12 = var2 ^ 32473191344933L;
      int var10000 = Event.cReturningInt();
      Object[] var26 = new Object[]{var12};
      PlayerEntity var15 = EntityUtil.aReturningPlayerEntity(var26);
      int var14 = var10000;
      PlayerEntity var123 = var15;
      if (var123 != null) {
         MinecraftClient var27 = b;
         PlayerEntity var29 = var15;
         ClientPlayerEntity var28 = var27.player;
         float var166 = var28.distanceTo((Entity)var29);
         int var126 = var14;
         float var125 = 20.0F;
         float var124 = var166;
         float var101 = var124;
         float var102 = var125;
         float var97 = var124;
         float var98 = var125;
         if (var126 != 0) {
            float var128 = var98;
            float var127 = var97;
            float var99 = var127;
            float var100 = var128;
            float var187;
            int var129 = (var187 = var99 - var100) == 0.0F ? 0 : (var187 < 0.0F ? -1 : 1);
            if (var129 > 0) {
               return 0.0F;
            }

            MinecraftClient var33 = b;
            ClientPlayerEntity var34 = var33.player;
            float var167 = var34.getHealth();
            MinecraftClient var35 = b;
            ClientPlayerEntity var36 = var35.player;
            var102 = var36.getAbsorptionAmount();
            var101 = var167;
         }

         float var16 = var101 + var102;
         MinecraftClient var37 = b;
         PlayerEntity var39 = var15;
         ClientPlayerEntity var38 = var37.player;
         float var17 = var38.distanceTo((Entity)var39);
         MinecraftClient var40 = b;
         ClientPlayerEntity var41 = var40.player;
         double var10002 = var41.getY();
         PlayerEntity var42 = var15;
         double var45 = (var10002 - var42.getY()) / 100.0;
         double var43 = 1.0;
         double var49 = Math.min(var43, var45);
         float var18 = (float)Math.max(var47, var49);
         float var19 = 0.0F;
         MultiModeSetting var168 = this.f;
         short var10001 = 16491;
         long var181 = 4213572565529090544L ^ var2;
         Object[] var52 = new Object[]{"Health", var10};
         MultiModeSetting var51 = var168;
         byte var169 = ((byte)((var51.aReturningBoolean(var52)) ? 1 : 0));
         int var131 = var14;
         byte var130 = var169;
         byte var104 = var130;
         byte var103 = var130;
         if (var131 != 0) {
            byte var132 = var103;
            if (var132 != 0) {
               float var55 = (20.0F - var16) / 18.0F;
               float var54 = 1.0F;
               float var57 = Math.min(var54, var55);
               float var56 = 0.0F;
               var19 += Math.max(var56, var57);
               var20++;
            }

            MultiModeSetting var170 = this.f;
            var10001 = 11776;
            long var182 = 466122286135654290L ^ var2;
            Object[] var59 = new Object[]{"Distance", var10};
            MultiModeSetting var58 = var170;
            var104 = ((byte)((var58.aReturningBoolean(var59)) ? 1 : 0));
         }

         int var134 = var14;
         byte var133 = var104;
         byte var106 = var133;
         byte var105 = var133;
         if (var134 != 0) {
            byte var135 = var105;
            if (var135 != 0) {
               float var62 = (10.0F - var17) / 6.0F;
               float var61 = 1.0F;
               float var64 = Math.min(var61, var62);
               float var63 = 0.0F;
               var19 += Math.max(var63, var64);
               var20++;
            }

            MultiModeSetting var171 = this.f;
            var10001 = 24237;
            long var183 = 8556995901960668960L ^ var2;
            Object[] var66 = new Object[]{"Y Level", var10};
            MultiModeSetting var65 = var171;
            var106 = ((byte)((var65.aReturningBoolean(var66)) ? 1 : 0));
         }

         int var137 = var14;
         byte var136 = var106;
         byte var108 = var136;
         byte var107 = var136;
         if (var137 != 0) {
            byte var138 = var107;
            if (var138 != 0) {
               var19 += var18;
               var20++;
            }

            MultiModeSetting var172 = this.f;
            var10001 = 18536;
            long var184 = 3748009894460936678L ^ var2;
            Object[] var69 = new Object[]{"Nearby Threats", var10};
            MultiModeSetting var68 = var172;
            var108 = ((byte)((var68.aReturningBoolean(var69)) ? 1 : 0));
         }

         int var140 = var14;
         byte var139 = var108;
         byte var119 = var139;
         byte var109 = var139;
         if (var140 != 0) {
            byte var141 = var109;
            if (var141 != 0) {
               PredictionType var73 = PredictionType.OBSIDIAN;
               PredictionType var72 = PredictionType.ANCHOR;
               PredictionType var71 = PredictionType.CRYSTAL;
               Object[] var74 = new Object[]{var15, EnumSet.of(var71, var72, var73), var4};
               PredictionResult var21 = MovementEvaluationUtil.bReturningVoid(var74);
               float var22 = 0.0F;
               int var142 = var14;
               if (var142 != 0) {
                  float var117;
                  float var118;
                  label99: {
                     Object[] var76 = new Object[0];
                     PredictionResult var75 = var21;
                     boolean var143 = var75.aReturningBoolean(var76);
                     label98:
                     if (var143) {
                        Object[] var10004 = new Object[]{null, var6};
                        var10004[0] = var16;
                        Object[] var79 = var10004;
                        PredictionResult var78 = var21;
                        var169 = ((byte)((var78.bReturningBoolean(var79)) ? 1 : 0));
                        int var145 = var14;
                        byte var144 = var169;
                        int var116 = var144;
                        byte var110 = var144;
                        if (var145 != 0) {
                           byte var146 = var110;
                           byte var111 = var146;
                           byte var147 = var111;
                           if (var147 != 0) {
                              var22 = 1.0F;
                              int var148 = var14;
                              if (var148 != 0) {
                                 break label98;
                              }
                           }

                           var10004 = new Object[]{null, var8};
                           var10004[0] = var16;
                           Object[] var83 = var10004;
                           PredictionResult var82 = var21;
                           float var174 = var82.aReturningFloat(var83);
                           int var151 = var14;
                           float var150 = 6.0F;
                           float var149 = var174;
                           var117 = var149;
                           var118 = var150;
                           float var112 = var149;
                           float var113 = var150;
                           if (var151 == 0) {
                              break label99;
                           }

                           float var153 = var113;
                           float var152 = var112;
                           float var114 = var152;
                           float var115 = var153;
                           float var188;
                           int var154 = (var188 = var114 - var115) == 0.0F ? 0 : (var188 < 0.0F ? -1 : 1);
                           var116 = var154;
                        }

                        int var155 = var116;
                        if (var155 < 0) {
                           var22 = 0.6F;
                        }
                     }

                     var118 = var22;
                     var117 = var19;
                  }

                  var19 = var117 + var118;
               }

               var20++;
            }

            MultiModeSetting var175 = this.f;
            var10001 = 19058;
            long var185 = 7817179448417899515L ^ var2;
            Object[] var87 = new Object[]{"Recent Damage Rate", var10};
            MultiModeSetting var86 = var175;
            var119 = ((byte)((var86.aReturningBoolean(var87)) ? 1 : 0));
         }

         int var157 = var14;
         byte var156 = var119;
         int var121 = var156;
         byte var120 = var156;
         if (var157 != 0) {
            byte var158 = var120;
            if (var158 != 0) {
               long var165 = System.currentTimeMillis();
               Deque var176 = this.D;
               Predicate var90 = invokeBinding15(var165);
               Deque var89 = var176;
               var89.removeIf(var90);
               float var23 = 0.0F;
               Deque var91 = this.D;
               Iterator var24 = var91.iterator();

               while (true) {
                  Iterator var92 = var24;
                  boolean var159 = var92.hasNext();
                  if (var159) {
                     Iterator var93 = var24;
                     TotemDamageSample var25 = (TotemDamageSample)var93.next();
                     var23 += var25.recoveryAccess_read_b();
                     int var160 = var14;
                     if (var160 == 0) {
                        break;
                     }

                     int var161 = var14;
                     if (var161 != 0) {
                        continue;
                     }
                  }

                  float var96 = var23 / 20.0F;
                  float var95 = 1.0F;
                  var19 += Math.min(var95, var96);
                  break;
               }

               var20++;
            }

            var121 = var20;
         }

         int var162 = var121;
         float var122;
         if (var162 > 0) {
            float var163 = var19 / var20 * 100.0F;
            var122 = var163;
         } else {
            var122 = 0.0F;
         }

         return var122;
      } else {
         return 0.0F;
      }
   }

   private List bReturningList(Object[] var1) {
      Point var4;
      Point var5;
      int var8;
      ArrayList var9;
      double var10;
      int var13;
      double var14;
      double var16;
      double var18;
      double var153;
      byte var155;
      label100: {
         var4 = (Point)var1[0];
         var5 = (Point)var1[1];
         long var2 = (Long)var1[2];
         var2 = 102652054115815L ^ var2;
         long var6 = var2 ^ 113480069170955L;
         int var10000 = Event.bReturningInt();
         var9 = new ArrayList();
         Point var48 = var5;
         Point var47 = var4;
         var10 = var47.distance(var48);
         var8 = var10000;
         MinMaxSetting var229 = this.l;
         Object[] var50 = new Object[]{var6};
         MinMaxSetting var49 = var229;
         float var12 = var49.fReturningFloat(var50);
         double var53 = var10 / var12 * 3.5;
         double var51 = 60.0;
         double var57 = Math.min(var51, var53);
         double var55 = 8.0;
         var13 = (int)Math.max(var55, var57);
         Point var59 = var5;
         Point var60 = var4;
         double var230 = var59.y - var60.y;
         Point var61 = var5;
         Point var62 = var4;
         double var65 = var61.x - var62.x;
         double var63 = var230;
         var14 = Math.atan2(var63, var65);
         var16 = var14 + (Math.PI / 2);
         double var231 = var10 * 0.18;
         double var69 = 22.0;
         double var67 = var231;
         var18 = Math.min(var67, var69);
         Random var71 = this.H;
         double var232 = var71.nextGaussian() * 0.4;
         Random var72 = this.H;
         byte var10001 = ((byte)((var72.nextBoolean()) ? 1 : 0));
         int var182 = var8;
         byte var181 = var10001;
         double var179 = var232;
         double var148 = var179;
         byte var150 = var181;
         double var141 = var179;
         byte var143 = var181;
         if (var182 == 0) {
            byte var185 = var143;
            double var183 = var141;
            double var151 = var183;
            double var144 = var183;
            if (var185 == 0) {
               var155 = -1;
               var153 = var151;
               break label100;
            }

            double var186 = var144;
            double var146 = var186;
            var150 = 1;
            var148 = var146;
         }

         byte var190 = var150;
         double var188 = var148;
         var153 = var188;
         var155 = var190;
      }

      double var24;
      double var26;
      double var28;
      double var30;
      int var160;
      label94: {
         int var159;
         label93: {
            label103: {
               double var233 = (var153 + var155) * var18;
               Random var74 = this.H;
               double var20 = var233 * (0.4 + var74.nextDouble() * 0.6);
               Random var75 = this.H;
               double var22 = var75.nextGaussian() * 0.3 * var18 * 0.5;
               Point var76 = var4;
               var233 = var76.x;
               Point var77 = var5;
               Point var78 = var4;
               double var250 = var77.x - var78.x;
               Random var79 = this.H;
               var233 += var250 * (0.25 + var79.nextDouble() * 0.15);
               double var80 = var16;
               var24 = var233 + Math.cos(var80) * var20;
               Point var82 = var4;
               var233 = var82.y;
               Point var83 = var5;
               Point var84 = var4;
               var250 = var83.y - var84.y;
               Random var85 = this.H;
               var233 += var250 * (0.25 + var85.nextDouble() * 0.15);
               double var86 = var16;
               var26 = var233 + Math.sin(var86) * var20;
               Point var88 = var4;
               var233 = var88.x;
               Point var89 = var5;
               Point var90 = var4;
               var250 = var89.x - var90.x;
               Random var91 = this.H;
               var233 += var250 * (0.6 + var91.nextDouble() * 0.15);
               double var92 = var16;
               var28 = var233 + Math.cos(var92) * var22;
               Point var94 = var4;
               var233 = var94.y;
               Point var95 = var5;
               Point var96 = var4;
               var250 = var95.y - var96.y;
               Random var97 = this.H;
               var233 += var250 * (0.6 + var97.nextDouble() * 0.15);
               double var98 = var16;
               var30 = var233 + Math.sin(var98) * var22;
               Random var100 = this.H;
               double var258;
               int var242 = (var258 = var100.nextDouble() - 0.25) == 0.0 ? 0 : (var258 < 0.0 ? -1 : 1);
               int var192 = var8;
               int var191 = var242;
               int var157 = var191;
               int var156 = var191;
               if (var192 == 0) {
                  int var193 = var156;
                  if (var193 >= 0) {
                     break label103;
                  }

                  double var259;
                  int var194 = (var259 = var10 - 30.0) == 0.0 ? 0 : (var259 < 0.0 ? -1 : 1);
                  var157 = var194;
               }

               int var196 = var8;
               int var195 = var157;
               var159 = var195;
               int var158 = var195;
               if (var196 != 0) {
                  break label93;
               }

               int var197 = var158;
               if (var197 > 0) {
                  var159 = 1;
                  break label93;
               }
            }

            var160 = 0;
            break label94;
         }

         int var198 = var159;
         var160 = var198;
      }

      int var32 = var160;
      int var199 = var32;
      double var161;
      if (var199 != 0) {
         Random var104 = this.H;
         double var200 = 3.0 + var104.nextDouble() * 5.0;
         var161 = var200;
      } else {
         var161 = 0.0;
      }

      double var33 = var161;
      Random var106 = this.H;
      double var35 = var14 + var106.nextGaussian() * 0.15;
      int var202 = var32;
      Point var163;
      if (var202 != 0) {
         Point var107 = var5;
         double var10002 = var107.x;
         double var108 = var35;
         int var257 = (int)(var10002 + Math.cos(var108) * var33);
         Point var110 = var5;
         double var10003 = var110.y;
         double var111 = var35;
         Point var203 = new Point(var257, (int)(var10003 + Math.sin(var111) * var33));
         var163 = var203;
      } else {
         var163 = var5;
      }

      Point var37 = var163;
      int var176;
      while (true) {
         int var205 = var13;
         int var204 = var38;
         if (var204 <= var205) {
            double var174;
            label76: {
               double var39 = (double)var38 / var13;
               int var210 = var8;
               double var208 = 0.5;
               double var206 = var39;
               double var170 = var206;
               double var172 = var208;
               double var164 = var206;
               double var166 = var208;
               if (var210 == 0) {
                  double var260;
                  int var243 = (var260 = var164 - var166) == 0.0 ? 0 : (var260 < 0.0 ? -1 : 1);
                  int var212 = var8;
                  int var211 = var243;
                  var176 = var211;
                  int var168 = var211;
                  if (var212 != 0) {
                     break;
                  }

                  int var213 = var168;
                  int var169 = var213;
                  int var214 = var169;
                  if (var214 < 0) {
                     double var215 = 4.0 * var39 * var39 * var39;
                     var174 = var215;
                     break label76;
                  }

                  double var254 = -2.0 * var39 + 2.0;
                  double var119 = 3.0;
                  double var117 = var254;
                  var172 = Math.pow(var117, var119) / 2.0;
                  var170 = 1.0;
               }

               var174 = var170 - var172;
            }

            double var41 = var174;
            double var43 = 1.0 - var41;
            double var244 = var43 * var43 * var43;
            Point var121 = var4;
            var244 = var244 * var121.x + 3.0 * var43 * var43 * var41 * var24 + 3.0 * var43 * var41 * var41 * var28;
            double var255 = var41 * var41 * var41;
            Point var122 = var37;
            int var45 = (int)(var244 + var255 * var122.x);
            var244 = var43 * var43 * var43;
            Point var123 = var4;
            var244 = var244 * var123.y + 3.0 * var43 * var43 * var41 * var26 + 3.0 * var43 * var41 * var41 * var30;
            var255 = var41 * var41 * var41;
            Point var124 = var37;
            int var46 = (int)(var244 + var255 * var124.y);
            Point var126 = new Point(var45, var46);
            ArrayList var125 = var9;
            var125.add(var126);
            var38++;
            int var217 = var8;
            if (var217 == 0) {
               continue;
            }
         }

         var176 = var32;
         break;
      }

      int var219 = var8;
      int var218 = var176;
      int var177 = var218;
      if (var219 == 0) {
         int var220 = var177;
         if (var220 != 0) {
            Random var128 = this.H;
            var38 = 4 + var128.nextInt(4);
            int var227 = 1;

            int var224;
            do {
               int var222 = var38;
               int var221 = var227;
               if (var221 > var222) {
                  break;
               }

               double var40 = (double)var227 / var38;
               double var42 = var40 * var40 * (3.0 - 2.0 * var40);
               Point var130 = var37;
               double var248 = var130.x;
               Point var131 = var5;
               Point var132 = var37;
               int var44 = (int)(var248 + (var131.x - var132.x) * var42);
               Point var133 = var37;
               var248 = var133.y;
               Point var134 = var5;
               Point var135 = var37;
               int var228 = (int)(var248 + (var134.y - var135.y) * var42);
               Point var137 = new Point(var44, var228);
               ArrayList var136 = var9;
               var136.add(var137);
               var227++;
               int var223 = var8;
               if (var223 != 0) {
                  return var9;
               }

               var224 = var8;
            } while (var224 == 0);
         }

         Point var140 = var5;
         ArrayList var139 = var9;
         boolean var178 = var139.add(var140);
      }

      return var9;
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 58798808613578L ^ 17532578373117L;
      var10001 = 58798808613578L ^ 56801031805499L;
      var10001 = 58798808613578L ^ 23110729656255L;
      var10001 = 58798808613578L ^ 72973098608588L;
      var10001 = 58798808613578L ^ 51397790721203L;
      var10001 = 58798808613578L ^ 65568976354641L;
      var10001 = 58798808613578L ^ 55824709780281L;
      var10001 = 58798808613578L ^ 139139341475628L;
      var10001 = 58798808613578L ^ 80024926524710L;
      var10001 = 58798808613578L ^ 125134664297969L;
      var10001 = 58798808613578L ^ 83530220508382L;
      var10001 = 58798808613578L ^ 117515632402617L;
      var10001 = 58798808613578L ^ 109727582095692L;
      var10001 = 58798808613578L ^ 83421396373496L;
      var10001 = 58798808613578L ^ 128154384730044L;
      var10001 = 58798808613578L ^ 73026005440689L;
      var10001 = 58798808613578L ^ 77728763231365L;
      var10001 = 58798808613578L ^ 10720999377111L;
      var10001 = 58798808613578L ^ 75341492499995L;
      var10001 = 58798808613578L ^ 21507027544778L;
      var10001 = 58798808613578L ^ 84963348707768L;
      var10001 = 58798808613578L ^ 129194172848292L;
      int var48 = Event.bReturningInt();
      MinecraftClient var75 = b;
      int var10000 = (((var75.isWindowFocused()) ? 1 : 0));
      int var598 = var48;
      boolean var597 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var437 = var597;
      boolean var436 = var597;
      if (var598 == 0) {
         boolean var599 = var436;
         if (!var599) {
            return;
         }

         ModeSetting var77 = this.c;
         String var916 = (String)var77.aReturningObject();
         String var79 = "SMP";
         String var78 = var916;
         var437 = var78.equals(var79);
      }

      int var601 = var48;
      boolean var600 = var437;
      boolean var439 = var600;
      boolean var438 = var600;
      if (var601 == 0) {
         boolean var602 = var438;
         if (var602) {
            return;
         }

         var439 = this.t;
      }

      int var604 = var48;
      boolean var603 = var439;
      boolean var441 = var603;
      boolean var440 = var603;
      if (var604 == 0) {
         boolean var605 = var440;
         if (!var605) {
            return;
         }

         Object[] var83 = new Object[]{105119720907379L};
         AutoTotem var82 = this;
         boolean var606 = var82.hReturningVoid(var83);
         var441 = var606;
      }

      int var608 = var48;
      boolean var607 = var441;
      boolean var443 = var607;
      boolean var442 = var607;
      if (var608 == 0) {
         boolean var609 = var442;
         if (var609) {
            return;
         }

         BooleanSetting var86 = this.k;
         Boolean var87 = (Boolean)var86.aReturningObject();
         var443 = var87;
      }

      int var611 = var48;
      boolean var610 = var443;
      boolean var448 = var610;
      boolean var444 = var610;
      if (var611 == 0) {
         boolean var612 = var444;
         label725:
         if (var612) {
            int var614 = var48;
            AutoTotem var613 = this;
            AutoTotem var447 = var613;
            AutoTotem var445 = var613;
            if (var614 == 0) {
               AutoTotem var615 = var445;
               AutoTotem var446 = var615;
               Robot var616 = var446.G;
               if (var616 != null) {
                  break label725;
               }

               AutoTotem var617 = this;
               var447 = var617;
            }

            Object[] var93 = new Object[]{64356679343927L};
            AutoTotem var92 = var447;
            var92.nReturningVoid(var93);
         }

         Object[] var94 = new Object[]{Items.SHIELD, 8519502184947L};
         var448 = InventoryUtil.lReturningBoolean(var94);
      }

      boolean var453;
      label718: {
         boolean var452;
         label717: {
            label747: {
               int var619 = var48;
               boolean var618 = var448;
               boolean var450 = var618;
               boolean var449 = var618;
               if (var619 == 0) {
                  boolean var620 = var449;
                  if (!var620) {
                     break label747;
                  }

                  MinecraftClient var96 = b;
                  ClientPlayerEntity var97 = var96.player;
                  boolean var621 = var97.isUsingItem();
                  var450 = var621;
               }

               int var623 = var48;
               boolean var622 = var450;
               var452 = var622;
               boolean var451 = var622;
               if (var623 != 0) {
                  break label717;
               }

               boolean var624 = var451;
               if (var624) {
                  var452 = true;
                  break label717;
               }
            }

            var453 = false;
            break label718;
         }

         boolean var625 = var452;
         var453 = var625;
      }

      boolean var49 = var453;
      boolean var626 = var49;
      if (!var626) {
         Integer var50;
         Item var459;
         label704: {
            Object[] var101 = new Object[]{Items.TOTEM_OF_UNDYING, 95321893129094L};
            var50 = InventoryUtil.aReturningBoxedInteger(var101);
            Integer var627 = var50;
            if (var627 != null) {
               MinecraftClient var102 = b;
               Screen var628 = var102.currentScreen;
               label702:
               if (var628 == null) {
                  MultiModeSetting var917 = this.g;
                  Object[] var105 = new Object[]{"Double Hand", 71444480285294L};
                  MultiModeSetting var104 = var917;
                  var10000 = (((var104.aReturningBoolean(var105)) ? 1 : 0));
                  int var630 = var48;
                  boolean var629 = ((((int)(var10000) & 1) != 0));
                  boolean var458 = var629;
                  boolean var454 = var629;
                  if (var630 == 0) {
                     boolean var631 = var454;
                     boolean var455 = var631;
                     boolean var632 = var455;
                     if (!var632) {
                        break label702;
                     }

                     int var634 = var48;
                     Item var633 = Items.TOTEM_OF_UNDYING;
                     var459 = var633;
                     Item var456 = var633;
                     if (var634 != 0) {
                        break label704;
                     }

                     Item var635 = var456;
                     Item var457 = var635;
                     Object[] var109 = new Object[]{var457, 8519502184947L};
                     boolean var636 = InventoryUtil.lReturningBoolean(var109);
                     var458 = var636;
                  }

                  boolean var637 = var458;
                  if (!var637) {
                     Integer var111 = var50;
                     var10000 = var111;
                     Object[] var10003 = new Object[]{null, 72518082610550L};
                     var10003[0] = var10000;
                     Object[] var112 = var10003;
                     InventoryUtil.aReturningVoid(var112);
                     Object[] var114 = new Object[]{16322445639579L};
                     AutoTotem var113 = this;
                     boolean var638 = var113.iReturningVoid(var114);
                     if (var638) {
                        return;
                     }
                  }
               }
            }

            var459 = Items.TOTEM_OF_UNDYING;
         }

         Object[] var10004 = new Object[]{null, null, 75544266747707L};
         var10004[1] = true;
         var10004[0] = var459;
         Object[] var117 = var10004;
         List var51 = InventoryUtil.aReturningList(var117);
         List var118 = var51;
         int var920 = (((var118.isEmpty()) ? 1 : 0));
         int var640 = var48;
         boolean var639 = dev.prestige.recovery.SourceSupport.asBoolean(var920);
         boolean var461 = var639;
         boolean var460 = var639;
         if (var640 == 0) {
            boolean var641 = var460;
            if (!var641) {
               byte var470;
               label678: {
                  byte var469;
                  label677: {
                     Integer var651 = var50;
                     if (var651 == null) {
                        MultiModeSetting var922 = this.g;
                        Object[] var132 = new Object[]{"Refill Hotbar Totem", 71444480285294L};
                        MultiModeSetting var131 = var922;
                        var920 = (((var131.aReturningBoolean(var132)) ? 1 : 0));
                        int var653 = var48;
                        byte var652 = ((byte)(var920));
                        var469 = var652;
                        byte var467 = var652;
                        if (var653 != 0) {
                           break label677;
                        }

                        byte var654 = var467;
                        byte var468 = var654;
                        byte var655 = var468;
                        if (var655 != 0) {
                           var469 = 1;
                           break label677;
                        }
                     }

                     var470 = 0;
                     break label678;
                  }

                  byte var656 = var469;
                  var470 = var656;
               }

               byte var52;
               byte var476;
               label669: {
                  byte var475;
                  label668: {
                     var52 = var470;
                     MinecraftClient var135 = b;
                     Screen var657 = var135.currentScreen;
                     label667:
                     if (var657 == null) {
                        int var659 = var48;
                        byte var658 = var52;
                        var475 = var658;
                        byte var471 = var658;
                        if (var659 != 0) {
                           break label668;
                        }

                        byte var660 = var471;
                        byte var472 = var660;
                        byte var661 = var472;
                        if (var661 == 0) {
                           Object[] var138 = new Object[]{Items.TOTEM_OF_UNDYING, 35728906855797L};
                           var920 = (((InventoryUtil.mReturningBoolean(var138)) ? 1 : 0));
                           int var663 = var48;
                           byte var662 = ((byte)(var920));
                           var475 = var662;
                           byte var473 = var662;
                           if (var663 != 0) {
                              break label668;
                           }

                           byte var664 = var473;
                           byte var474 = var664;
                           byte var665 = var474;
                           if (var665 != 0) {
                              break label667;
                           }
                        }

                        var475 = 1;
                        break label668;
                     }

                     var476 = 0;
                     break label669;
                  }

                  byte var666 = var475;
                  var476 = var666;
               }

               byte var495;
               byte var53 = var476;
               MultiModeSetting var925 = this.n;
               Object[] var142 = new Object[]{"Only Inventory on Both Pops", 71444480285294L};
               MultiModeSetting var141 = var925;
               var920 = (((var141.aReturningBoolean(var142)) ? 1 : 0));
               int var668 = var48;
               byte var667 = ((byte)(var920));
               var495 = var667;
               byte var477 = var667;
               label655:
               if (var668 == 0) {
                  byte var669 = var477;
                  if (var669 != 0) {
                     byte var483;
                     label651: {
                        byte var482;
                        label784: {
                           MinecraftClient var144 = b;
                           Screen var670 = var144.currentScreen;
                           label648:
                           if (var670 == null) {
                              int var672 = var48;
                              byte var671 = var52;
                              byte var480 = var671;
                              byte var478 = var671;
                              if (var672 == 0) {
                                 byte var673 = var478;
                                 byte var479 = var673;
                                 byte var674 = var479;
                                 if (var674 == 0) {
                                    break label648;
                                 }

                                 Object[] var148 = new Object[]{Items.TOTEM_OF_UNDYING, 35728906855797L};
                                 byte var675 = ((byte)((InventoryUtil.mReturningBoolean(var148)) ? 1 : 0));
                                 var480 = var675;
                              }

                              int var677 = var48;
                              byte var676 = var480;
                              var482 = var676;
                              byte var481 = var676;
                              if (var677 != 0) {
                                 break label784;
                              }

                              byte var678 = var481;
                              if (var678 == 0) {
                                 var482 = 1;
                                 break label784;
                              }
                           }

                           var483 = 0;
                           break label651;
                        }

                        byte var679 = var482;
                        var483 = var679;
                     }

                     var53 = var483;
                     int var681 = var48;
                     byte var680 = var53;
                     var495 = var680;
                     byte var484 = var680;
                     if (var681 != 0) {
                        break label655;
                     }

                     byte var682 = var484;
                     if (var682 == 0) {
                        MinecraftClient var152 = b;
                        Screen var683 = var152.currentScreen;
                        label635:
                        if (var683 == null) {
                           int var685 = var48;
                           byte var684 = var52;
                           byte var489 = var684;
                           byte var485 = var684;
                           if (var685 == 0) {
                              byte var686 = var485;
                              byte var486 = var686;
                              byte var687 = var486;
                              if (var687 == 0) {
                                 Object[] var156 = new Object[]{Items.TOTEM_OF_UNDYING, 35728906855797L};
                                 var920 = (((InventoryUtil.mReturningBoolean(var156)) ? 1 : 0));
                                 int var689 = var48;
                                 byte var688 = ((byte)(var920));
                                 var495 = var688;
                                 byte var487 = var688;
                                 if (var689 != 0) {
                                    break label655;
                                 }

                                 byte var690 = var487;
                                 byte var488 = var690;
                                 byte var691 = var488;
                                 if (var691 != 0) {
                                    break label635;
                                 }
                              }

                              var489 = var52;
                           }

                           int var693 = var48;
                           byte var692 = var489;
                           byte var493 = var692;
                           byte var490 = var692;
                           if (var693 == 0) {
                              byte var694 = var490;
                              if (var694 != 0) {
                                 Object[] var160 = new Object[]{Items.TOTEM_OF_UNDYING, 35728906855797L};
                                 var920 = (((InventoryUtil.mReturningBoolean(var160)) ? 1 : 0));
                                 int var696 = var48;
                                 byte var695 = ((byte)(var920));
                                 var495 = var695;
                                 byte var491 = var695;
                                 if (var696 != 0) {
                                    break label655;
                                 }

                                 byte var697 = var491;
                                 byte var492 = var697;
                                 byte var698 = var492;
                                 if (var698 == 0) {
                                    break label635;
                                 }
                              }

                              Object[] var164 = new Object[]{16322445639579L};
                              AutoTotem var163 = this;
                              byte var699 = ((byte)((var163.iReturningVoid(var164)) ? 1 : 0));
                              var493 = var699;
                           }

                           int var701 = var48;
                           byte var700 = var493;
                           var495 = var700;
                           byte var494 = var700;
                           if (var701 != 0) {
                              break label655;
                           }

                           byte var702 = var494;
                           if (var702 != 0) {
                              return;
                           }
                        }
                     }
                  }

                  var495 = var53;
               }

               int var704 = var48;
               byte var703 = var495;
               byte var501 = var703;
               byte var496 = var703;
               if (var704 == 0) {
                  byte var705 = var496;
                  if (var705 != 0) {
                     ElapsedTimer var929 = this.J;
                     Object[] var169 = new Object[]{42835128969216L};
                     ElapsedTimer var168 = var929;
                     var168.aReturningVoid(var169);
                     MinMaxSetting var930 = this.m;
                     Object[] var171 = new Object[]{127318019014223L};
                     MinMaxSetting var170 = var930;
                     var170.bReturningVoid(var171);
                     this.K = new ArrayList();
                     this.L = 0;
                     this.M = null;
                     this.I = null;
                     MultiModeSetting var931 = this.g;
                     Object[] var173 = new Object[]{"Open Inventory", 71444480285294L};
                     MultiModeSetting var172 = var931;
                     boolean var932 = var172.aReturningBoolean(var173);
                     int var707 = var48;
                     boolean var706 = var932;
                     boolean var499 = var706;
                     boolean var497 = var706;
                     if (var707 == 0) {
                        boolean var708 = var497;
                        boolean var498 = var708;
                        boolean var709 = var498;
                        if (!var709) {
                           return;
                        }

                        MultiModeSetting var933 = this.g;
                        Object[] var177 = new Object[]{"Switch", 71444480285294L};
                        MultiModeSetting var176 = var933;
                        boolean var710 = var176.aReturningBoolean(var177);
                        var499 = var710;
                     }

                     boolean var711 = var499;
                     InventoryScreen var500;
                     if (var711) {
                        MinecraftClient var179 = b;
                        InventoryInputScreen var712 = new InventoryInputScreen(var179.player);
                        var500 = var712;
                     } else {
                        MinecraftClient var181 = b;
                        var500 = new InventoryScreen(var181.player);
                     }

                     InventoryScreen var54 = var500;
                     InventoryScreen var183 = var54;
                     MinecraftClient var182 = b;
                     var182.setScreen((Screen)var183);
                     MinecraftClient var184 = b;
                     InventoryScreen var714 = var54;
                     Screen var713 = var184.currentScreen;
                     if (var713 == var714) {
                        this.v = var54;
                     }

                     Object[] var187 = new Object[]{16322445639579L};
                     AutoTotem var186 = this;
                     boolean var715 = var186.iReturningVoid(var187);
                     if (var715) {
                        return;
                     }

                     int var716 = var48;
                     if (var716 != 0) {
                        return;
                     }
                  }

                  MinecraftClient var190 = b;
                  var501 = ((byte)((var190.currentScreen instanceof InventoryScreen) ? 1 : 0));
               }

               label804: {
                  label805: {
                     AutoTotem var596;
                     label756: {
                        int var595;
                        label757: {
                           label785: {
                              int var718 = var48;
                              byte var717 = var501;
                              byte var505 = var717;
                              byte var502 = var717;
                              if (var718 == 0) {
                                 byte var719 = var502;
                                 if (var719 == 0) {
                                    MinecraftClient var192 = b;
                                    var920 = (((var192.currentScreen instanceof InventoryInputScreen) ? 1 : 0));
                                    int var721 = var48;
                                    byte var720 = ((byte)(var920));
                                    var595 = var720;
                                    byte var503 = var720;
                                    if (var721 != 0) {
                                       break label757;
                                    }

                                    byte var722 = var503;
                                    byte var504 = var722;
                                    byte var723 = var504;
                                    if (var723 == 0) {
                                       break label785;
                                    }
                                 }

                                 Object[] var196 = new Object[]{83501900373478L};
                                 AutoTotem var195 = this;
                                 byte var724 = ((byte)((var195.dReturningBoolean(var196)) ? 1 : 0));
                                 var505 = var724;
                              }

                              int var726 = var48;
                              byte var725 = var505;
                              byte var507 = var725;
                              byte var506 = var725;
                              if (var726 == 0) {
                                 byte var727 = var506;
                                 if (var727 != 0) {
                                    return;
                                 }

                                 BooleanSetting var199 = this.k;
                                 Boolean var200 = (Boolean)var199.aReturningObject();
                                 var507 = ((byte)(((java.lang.Boolean)(var200)).booleanValue() ? 1 : 0));
                              }

                              int var541;
                              int var729 = var48;
                              byte var728 = var507;
                              var541 = var728;
                              byte var508 = var728;
                              label515:
                              if (var729 == 0) {
                                 Item var540;
                                 label578: {
                                    byte var730 = var508;
                                    if (var730 != 0) {
                                       ElapsedTimer var935 = this.J;
                                       Object[] var203 = new Object[]{this.m, 130913203968635L};
                                       ElapsedTimer var202 = var935;
                                       var920 = (((var202.bReturningBoolean(var203)) ? 1 : 0));
                                       int var732 = var48;
                                       byte var731 = ((byte)(var920));
                                       var541 = var731;
                                       byte var509 = var731;
                                       if (var732 != 0) {
                                          break label515;
                                       }

                                       byte var733 = var509;
                                       byte var510 = var733;
                                       byte var734 = var510;
                                       label575:
                                       if (var734 != 0) {
                                          MinecraftClient var206 = b;
                                          HandledScreenAccessor var905 = new HandledScreenAccessor((HandledScreen)var206.currentScreen);
                                          Object[] var208 = new Object[]{132200035924850L};
                                          HandledScreenAccessor var207 = var905;
                                          Slot var937 = var207.aReturningSlot(var208);
                                          int var736 = var48;
                                          Slot var735 = var937;
                                          Slot var514 = var735;
                                          Slot var511 = var735;
                                          if (var736 == 0) {
                                             Slot var737 = var511;
                                             if (var737 != null) {
                                                Object[] var211 = new Object[]{132200035924850L};
                                                HandledScreenAccessor var210 = var905;
                                                Slot var212 = var210.aReturningSlot(var211);
                                                ItemStack var213 = var212.getStack();
                                                Item var938 = var213.getItem();
                                                int var739 = var48;
                                                Item var738 = var938;
                                                var540 = var738;
                                                Item var512 = var738;
                                                if (var739 != 0) {
                                                   break label578;
                                                }

                                                Item var740 = var512;
                                                Item var513 = var740;
                                                Item var742 = Items.TOTEM_OF_UNDYING;
                                                Item var741 = var513;
                                                if (var741 == var742) {
                                                   break label575;
                                                }
                                             }

                                             Slot var743 = this.I;
                                             var514 = var743;
                                          }

                                          Slot var518;
                                          int var745 = var48;
                                          Slot var744 = var514;
                                          var518 = var744;
                                          Slot var515 = var744;
                                          label565:
                                          if (var745 == 0) {
                                             Slot var746 = var515;
                                             if (var746 != null) {
                                                int var748 = var48;
                                                Slot var747 = this.I;
                                                var518 = var747;
                                                Slot var516 = var747;
                                                if (var748 != 0) {
                                                   break label565;
                                                }

                                                Slot var749 = var516;
                                                Slot var517 = var749;
                                                Slot var219 = var517;
                                                ItemStack var220 = var219.getStack();
                                                Item var939 = var220.getItem();
                                                Item var751 = Items.TOTEM_OF_UNDYING;
                                                Item var750 = var939;
                                                if (var750 != var751) {
                                                   this.I = null;
                                                }
                                             }

                                             var518 = this.I;
                                          }

                                          int var753 = var48;
                                          Slot var752 = var518;
                                          Slot var530 = var752;
                                          Slot var519 = var752;
                                          if (var753 == 0) {
                                             Slot var754 = var519;
                                             if (var754 == null) {
                                                ArrayList var55 = new ArrayList();
                                                MinecraftClient var224 = b;
                                                HandledScreen var225 = (HandledScreen)var224.currentScreen;
                                                ScreenHandler var226 = var225.getScreenHandler();
                                                DefaultedList var227 = var226.slots;
                                                Iterator var56 = var227.iterator();

                                                int var529;
                                                label553: {
                                                   while (true) {
                                                      Iterator var228 = var56;
                                                      boolean var755 = var228.hasNext();
                                                      if (!var755) {
                                                         break;
                                                      }

                                                      Iterator var229 = var56;
                                                      Slot var57 = (Slot)var229.next();
                                                      Slot var230 = var57;
                                                      int var757 = var48;
                                                      int var756 = var230.id;
                                                      var529 = var756;
                                                      int var520 = var756;
                                                      if (var757 != 0) {
                                                         break label553;
                                                      }

                                                      Slot var528;
                                                      label765: {
                                                         int var760 = var48;
                                                         byte var759 = 45;
                                                         int var758 = var520;
                                                         int var526 = var758;
                                                         int var527 = var759;
                                                         int var521 = var758;
                                                         byte var522 = var759;
                                                         if (var760 == 0) {
                                                            byte var762 = var522;
                                                            int var761 = var521;
                                                            int var523 = var761;
                                                            byte var524 = var762;
                                                            byte var764 = var524;
                                                            int var763 = var523;
                                                            if (var763 == var764) {
                                                               continue;
                                                            }

                                                            int var766 = var48;
                                                            Slot var765 = var57;
                                                            var528 = var765;
                                                            Slot var525 = var765;
                                                            if (var766 != 0) {
                                                               break label765;
                                                            }

                                                            Slot var233 = var525;
                                                            var920 = var233.id;
                                                            IntSetting var234 = this.h;
                                                            Integer var235 = (Integer)var234.aReturningObject();
                                                            int var768 = 36 + (var235 - 1);
                                                            int var767 = var920;
                                                            var526 = var767;
                                                            var527 = var768;
                                                         }

                                                         int var770 = var527;
                                                         int var769 = var526;
                                                         if (var769 == var770) {
                                                            continue;
                                                         }

                                                         var528 = var57;
                                                      }

                                                      Slot var237 = var528;
                                                      ItemStack var238 = var237.getStack();
                                                      Item var941 = var238.getItem();
                                                      Item var772 = Items.TOTEM_OF_UNDYING;
                                                      Item var771 = var941;
                                                      if (var771 == var772) {
                                                         Slot var240 = var57;
                                                         ArrayList var239 = var55;
                                                         var239.add(var240);
                                                      }

                                                      int var773 = var48;
                                                      if (var773 != 0) {
                                                         break;
                                                      }
                                                   }

                                                   ArrayList var242 = var55;
                                                   var529 = (((var242.isEmpty()) ? 1 : 0));
                                                }

                                                int var774 = var529;
                                                if (var774 == 0) {
                                                   Random var10002 = this.H;
                                                   ArrayList var243 = var55;
                                                   int var245 = var243.size();
                                                   Random var244 = var10002;
                                                   int var247 = var244.nextInt(var245);
                                                   ArrayList var246 = var55;
                                                   this.I = (Slot)var246.get(var247);
                                                }
                                             }

                                             var530 = this.I;
                                          }

                                          Slot var775 = var530;
                                          if (var775 != null) {
                                             label529: {
                                                AutoTotem var536;
                                                MinecraftClient var249 = b;
                                                Window var250 = var249.getWindow();
                                                double var907 = var250.getScaleFactor();
                                                MinecraftClient var251 = b;
                                                Window var252 = var251.getWindow();
                                                int var914 = var252.getX();
                                                MinecraftClient var253 = b;
                                                Window var254 = var253.getWindow();
                                                int var58 = var254.getY();
                                                Object[] var255 = new Object[]{HandledScreen.class, "x", 138205257553900L};
                                                ReflectedField var942 = ReflectedField.aReturningcR_C0145(var255);
                                                MinecraftClient var256 = b;
                                                Object[] var258 = new Object[]{(InventoryScreen)var256.currentScreen, 139247749909810L};
                                                ReflectedField var257 = var942;
                                                Integer var259 = (Integer)var257.aReturningObject(var258);
                                                int var59 = var259;
                                                Object[] var260 = new Object[]{HandledScreen.class, "y", 138205257553900L};
                                                ReflectedField var943 = ReflectedField.aReturningcR_C0145(var260);
                                                MinecraftClient var261 = b;
                                                Object[] var263 = new Object[]{(InventoryScreen)var261.currentScreen, 139247749909810L};
                                                ReflectedField var262 = var943;
                                                Integer var264 = (Integer)var262.aReturningObject(var263);
                                                int var60 = var264;
                                                Slot var265 = this.I;
                                                int var61 = var59 + var265.x + 8;
                                                Slot var266 = this.I;
                                                int var62 = var60 + var266.y + 8;
                                                int var63 = var914 + (int)(var61 * var907);
                                                int var64 = var58 + (int)(var62 * var907);
                                                Point var65 = new Point(var63, var64);
                                                PointerInfo var267 = MouseInfo.getPointerInfo();
                                                Point var66 = var267.getLocation();
                                                int var777 = var48;
                                                AutoTotem var776 = this;
                                                var536 = var776;
                                                AutoTotem var531 = var776;
                                                label528:
                                                if (var777 == 0) {
                                                   Point var778 = var531.M;
                                                   if (var778 != null) {
                                                      int var780 = var48;
                                                      AutoTotem var779 = this;
                                                      var536 = var779;
                                                      AutoTotem var532 = var779;
                                                      if (var780 != 0) {
                                                         break label528;
                                                      }

                                                      AutoTotem var781 = var532;
                                                      AutoTotem var533 = var781;
                                                      Point var271 = var65;
                                                      Point var270 = var533.M;
                                                      boolean var782 = var270.equals(var271);
                                                      if (var782) {
                                                         int var784 = var48;
                                                         AutoTotem var783 = this;
                                                         var536 = var783;
                                                         AutoTotem var534 = var783;
                                                         if (var784 != 0) {
                                                            break label528;
                                                         }

                                                         AutoTotem var785 = var534;
                                                         AutoTotem var535 = var785;
                                                         var920 = var535.L;
                                                         List var274 = this.K;
                                                         int var787 = var274.size();
                                                         int var786 = var920;
                                                         if (var786 < var787) {
                                                            break label529;
                                                         }
                                                      }
                                                   }

                                                   this.M = var65;
                                                   Object[] var277 = new Object[]{var66, var65, 66769683597853L};
                                                   AutoTotem var276 = this;
                                                   this.K = var276.bReturningList(var277);
                                                   AutoTotem var788 = this;
                                                   var536 = var788;
                                                }

                                                var536.L = 0;
                                             }

                                             MinMaxSetting var995 = this.l;
                                             Object[] var280 = new Object[]{7504101316849L};
                                             MinMaxSetting var279 = var995;
                                             float var67 = (21.0F - var279.fReturningFloat(var280)) * 2.0F;
                                             int var790 = var48;
                                             int var789 = this.L;
                                             var541 = var789;
                                             int var537 = var789;
                                             if (var790 != 0) {
                                                break label515;
                                             }

                                             List var281 = this.K;
                                             int var792 = var281.size();
                                             int var791 = var537;
                                             if (var791 < var792) {
                                                ElapsedTimer var945 = this.N;
                                                var10004 = new Object[]{null, 139098136696340L};
                                                var10004[0] = var67;
                                                Object[] var284 = var10004;
                                                ElapsedTimer var283 = var945;
                                                byte var946 = ((byte)((var283.aReturningBoolean(var284)) ? 1 : 0));
                                                int var794 = var48;
                                                byte var793 = var946;
                                                var541 = var793;
                                                byte var538 = var793;
                                                if (var794 != 0) {
                                                   break label515;
                                                }

                                                byte var795 = var538;
                                                byte var539 = var795;
                                                byte var796 = var539;
                                                if (var796 != 0) {
                                                   int var288 = this.L;
                                                   List var287 = this.K;
                                                   Point var68 = (Point)var287.get(var288);
                                                   double var947 = this.L;
                                                   List var289 = this.K;
                                                   double var69 = var947 / var289.size();
                                                   double var292 = 1.0 - var69 * 2.5;
                                                   double var71 = Math.max(var290, var292);
                                                   Random var294 = this.H;
                                                   int var73 = (int)(var294.nextGaussian() * 0.8 * var71);
                                                   Random var295 = this.H;
                                                   int var74 = (int)(var295.nextGaussian() * 0.8 * var71);
                                                   Point var296 = var68;
                                                   int var996 = var296.x + var73;
                                                   Point var297 = var68;
                                                   int var300 = var297.y + var74;
                                                   int var299 = var996;
                                                   Robot var298 = this.G;
                                                   var298.mouseMove(var299, var300);
                                                   this.L++;
                                                   ElapsedTimer var948 = this.N;
                                                   Object[] var302 = new Object[]{42835128969216L};
                                                   ElapsedTimer var301 = var948;
                                                   var301.aReturningVoid(var302);
                                                }
                                             }
                                          }
                                       }
                                    }

                                    var540 = Items.TOTEM_OF_UNDYING;
                                 }

                                 Object[] var303 = new Object[]{var540, 35728906855797L};
                                 var541 = (((InventoryUtil.mReturningBoolean(var303)) ? 1 : 0));
                              }

                              int var568;
                              int var906;
                              var906 = var541;
                              int var798 = var48;
                              int var797 = var906;
                              var568 = var797;
                              int var542 = var797;
                              label479:
                              if (var798 == 0) {
                                 int var799 = var542;
                                 if (var799 == 0) {
                                    MultiModeSetting var949 = this.g;
                                    Object[] var306 = new Object[]{"Switch", 71444480285294L};
                                    MultiModeSetting var305 = var949;
                                    byte var950 = ((byte)((var305.aReturningBoolean(var306)) ? 1 : 0));
                                    int var801 = var48;
                                    byte var800 = var950;
                                    var568 = var800;
                                    byte var543 = var800;
                                    if (var801 != 0) {
                                       break label479;
                                    }

                                    byte var802 = var543;
                                    byte var544 = var802;
                                    byte var803 = var544;
                                    label502:
                                    if (var803 != 0) {
                                       label770: {
                                          label499: {
                                             BooleanSetting var309 = this.i;
                                             Boolean var310 = (Boolean)var309.aReturningObject();
                                             boolean var951 = var310;
                                             int var805 = var48;
                                             boolean var804 = var951;
                                             boolean var547 = var804;
                                             boolean var545 = var804;
                                             if (var805 == 0) {
                                                boolean var806 = var545;
                                                boolean var546 = var806;
                                                boolean var807 = var546;
                                                if (var807) {
                                                   break label499;
                                                }

                                                BooleanSetting var313 = this.k;
                                                Boolean var314 = (Boolean)var313.aReturningObject();
                                                boolean var808 = var314;
                                                var547 = var808;
                                             }

                                             boolean var809 = var547;
                                             if (!var809) {
                                                break label770;
                                             }
                                          }

                                          MinecraftClient var316 = b;
                                          HandledScreenAccessor var908 = new HandledScreenAccessor((HandledScreen)var316.currentScreen);
                                          int var810 = var48;
                                          if (var810 != 0) {
                                             return;
                                          }

                                          Object[] var318 = new Object[]{132200035924850L};
                                          HandledScreenAccessor var317 = var908;
                                          Slot var811 = var317.aReturningSlot(var318);
                                          if (var811 == null) {
                                             break label804;
                                          }

                                          Object[] var321 = new Object[]{132200035924850L};
                                          HandledScreenAccessor var320 = var908;
                                          Slot var322 = var320.aReturningSlot(var321);
                                          ItemStack var323 = var322.getStack();
                                          Item var952 = var323.getItem();
                                          Item var813 = Items.TOTEM_OF_UNDYING;
                                          Item var812 = var952;
                                          if (var812 != var813) {
                                             break label804;
                                          }

                                          label771: {
                                             ElapsedTimer var953 = this.s;
                                             Object[] var326 = new Object[]{this.j, 130913203968635L};
                                             ElapsedTimer var325 = var953;
                                             boolean var954 = var325.bReturningBoolean(var326);
                                             int var815 = var48;
                                             boolean var814 = var954;
                                             boolean var550 = var814;
                                             boolean var548 = var814;
                                             if (var815 == 0) {
                                                boolean var816 = var548;
                                                boolean var549 = var816;
                                                boolean var817 = var549;
                                                if (!var817) {
                                                   break label771;
                                                }

                                                Object[] var330 = new Object[]{132200035924850L};
                                                HandledScreenAccessor var329 = var908;
                                                Slot var331 = var329.aReturningSlot(var330);
                                                int var997 = var331.id;
                                                Object[] var10005 = new Object[]{null, null, 130998474319110L};
                                                var10005[1] = 40;
                                                var10005[0] = var997;
                                                Object[] var333 = var10005;
                                                AutoTotem var332 = this;
                                                boolean var818 = var332.aReturningBoolean(var333);
                                                var550 = var818;
                                             }

                                             int var820 = var48;
                                             boolean var819 = var550;
                                             boolean var552 = var819;
                                             boolean var551 = var819;
                                             if (var820 == 0) {
                                                boolean var821 = var551;
                                                if (!var821) {
                                                   break label771;
                                                }

                                                Object[] var337 = new Object[]{16322445639579L};
                                                AutoTotem var336 = this;
                                                boolean var822 = var336.iReturningVoid(var337);
                                                var552 = var822;
                                             }

                                             boolean var823 = var552;
                                             if (var823) {
                                                return;
                                             }
                                          }

                                          int var824 = var48;
                                          if (var824 == 0) {
                                             break label502;
                                          }
                                       }

                                       Item var955 = Items.TOTEM_OF_UNDYING;
                                       var10004 = new Object[]{null, null, 75544266747707L};
                                       var10004[1] = false;
                                       var10004[0] = var955;
                                       Object[] var343 = var10004;
                                       List var909 = InventoryUtil.aReturningList(var343);
                                       int var826 = var48;
                                       List var825 = var909;
                                       List var554 = var825;
                                       List var553 = var825;
                                       List var555;
                                       if (var826 == 0) {
                                          List var344 = var553;
                                          boolean var827 = var344.isEmpty();
                                          if (var827) {
                                             List var828 = var51;
                                             var555 = var828;
                                          } else {
                                             var555 = var909;
                                          }
                                       } else {
                                          List var829 = var554;
                                          var555 = var829;
                                       }

                                       List var911 = var555;
                                       List var347 = var911;
                                       int var1000 = var347.size() - 1;
                                       Object[] var1008 = new Object[]{null, null, 125343872349393L};
                                       var1008[1] = var1000;
                                       var1008[0] = 0;
                                       Object[] var348 = var1008;
                                       int var350 = RandomUtil.aReturningInt(var348);
                                       List var349 = var911;
                                       Integer var351 = (Integer)var349.get(var350);
                                       int var915 = var351;
                                       List var352 = var909;
                                       byte var998 = ((byte)((var352.isEmpty()) ? 1 : 0));
                                       int var832 = var48;
                                       byte var831 = var998;
                                       AutoTotem var830 = this;
                                       AutoTotem var560 = var830;
                                       byte var561 = var831;
                                       AutoTotem var556 = var830;
                                       byte var557 = var831;
                                       AutoTotem var563;
                                       int var564;
                                       if (var832 == 0) {
                                          byte var834 = var557;
                                          AutoTotem var833 = var556;
                                          AutoTotem var562 = var833;
                                          AutoTotem var558 = var833;
                                          if (var834 != 0) {
                                             AutoTotem var835 = var558;
                                             AutoTotem var559 = var835;
                                             int var837 = 36 + var915;
                                             AutoTotem var836 = var559;
                                             var563 = var836;
                                             var564 = var837;
                                          } else {
                                             var564 = var915;
                                             var563 = var562;
                                          }
                                       } else {
                                          byte var839 = var561;
                                          AutoTotem var838 = var560;
                                          var563 = var838;
                                          var564 = var839;
                                       }

                                       var1008 = new Object[]{null, null, 130998474319110L};
                                       var1008[1] = 40;
                                       var1008[0] = var564;
                                       Object[] var356 = var1008;
                                       AutoTotem var355 = var563;
                                       var950 = ((byte)((var355.aReturningBoolean(var356)) ? 1 : 0));
                                       int var841 = var48;
                                       byte var840 = var950;
                                       var568 = var840;
                                       byte var565 = var840;
                                       if (var841 != 0) {
                                          break label479;
                                       }

                                       byte var842 = var565;
                                       if (var842 != 0) {
                                          Object[] var359 = new Object[]{16322445639579L};
                                          AutoTotem var358 = this;
                                          var950 = ((byte)((var358.iReturningVoid(var359)) ? 1 : 0));
                                          int var844 = var48;
                                          byte var843 = var950;
                                          var568 = var843;
                                          byte var566 = var843;
                                          if (var844 != 0) {
                                             break label479;
                                          }

                                          byte var845 = var566;
                                          byte var567 = var845;
                                          byte var846 = var567;
                                          if (var846 != 0) {
                                             return;
                                          }
                                       }
                                    }
                                 }

                                 var568 = var52;
                              }

                              int var586;
                              int var848 = var48;
                              int var847 = var568;
                              var586 = var847;
                              int var569 = var847;
                              label469:
                              if (var848 == 0) {
                                 int var849 = var569;
                                 if (var849 != 0) {
                                    MultiModeSetting var960 = this.g;
                                    Object[] var364 = new Object[]{"Switch", 71444480285294L};
                                    MultiModeSetting var363 = var960;
                                    int var961 = (((var363.aReturningBoolean(var364)) ? 1 : 0));
                                    int var851 = var48;
                                    byte var850 = (byte)var961;
                                    var586 = var850;
                                    byte var570 = var850;
                                    if (var851 != 0) {
                                       break label469;
                                    }

                                    byte var852 = var570;
                                    byte var571 = var852;
                                    byte var853 = var571;
                                    if (var853 != 0) {
                                       Item var962 = Items.TOTEM_OF_UNDYING;
                                       var10004 = new Object[]{null, null, 75544266747707L};
                                       var10004[1] = false;
                                       var10004[0] = var962;
                                       Object[] var367 = var10004;
                                       List var910 = InventoryUtil.aReturningList(var367);
                                       List var368 = var910;
                                       var961 = var368.size();
                                       int var855 = var48;
                                       int var854 = var961;
                                       var586 = var854;
                                       int var572 = var854;
                                       if (var855 != 0) {
                                          break label469;
                                       }

                                       int var856 = var572;
                                       label463:
                                       if (var856 > 0) {
                                          int var582;
                                          label461: {
                                             label773: {
                                                label774: {
                                                   BooleanSetting var370 = this.i;
                                                   Boolean var371 = (Boolean)var370.aReturningObject();
                                                   byte var964 = ((byte)(((java.lang.Boolean)(var371)).booleanValue() ? 1 : 0));
                                                   int var858 = var48;
                                                   byte var857 = var964;
                                                   byte var575 = var857;
                                                   byte var573 = var857;
                                                   if (var858 == 0) {
                                                      byte var859 = var573;
                                                      byte var574 = var859;
                                                      byte var860 = var574;
                                                      if (var860 != 0) {
                                                         break label774;
                                                      }

                                                      BooleanSetting var374 = this.k;
                                                      Boolean var375 = (Boolean)var374.aReturningObject();
                                                      byte var861 = ((byte)(((java.lang.Boolean)(var375)).booleanValue() ? 1 : 0));
                                                      var575 = var861;
                                                   }

                                                   int var863 = var48;
                                                   byte var862 = var575;
                                                   var582 = var862;
                                                   byte var576 = var862;
                                                   if (var863 != 0) {
                                                      break label461;
                                                   }

                                                   byte var864 = var576;
                                                   if (var864 == 0) {
                                                      break label773;
                                                   }
                                                }

                                                MinecraftClient var378 = b;
                                                HandledScreenAccessor var912 = new HandledScreenAccessor((HandledScreen)var378.currentScreen);
                                                int var865 = var48;
                                                if (var865 != 0) {
                                                   return;
                                                }

                                                Object[] var380 = new Object[]{132200035924850L};
                                                HandledScreenAccessor var379 = var912;
                                                Slot var866 = var379.aReturningSlot(var380);
                                                if (var866 == null) {
                                                   break label805;
                                                }

                                                Object[] var383 = new Object[]{132200035924850L};
                                                HandledScreenAccessor var382 = var912;
                                                Slot var384 = var382.aReturningSlot(var383);
                                                ItemStack var385 = var384.getStack();
                                                Item var965 = var385.getItem();
                                                Item var868 = Items.TOTEM_OF_UNDYING;
                                                Item var867 = var965;
                                                if (var867 != var868) {
                                                   break label805;
                                                }

                                                label775: {
                                                   ElapsedTimer var966 = this.s;
                                                   Object[] var388 = new Object[]{this.j, 130913203968635L};
                                                   ElapsedTimer var387 = var966;
                                                   boolean var967 = var387.bReturningBoolean(var388);
                                                   int var870 = var48;
                                                   boolean var869 = var967;
                                                   boolean var579 = var869;
                                                   boolean var577 = var869;
                                                   if (var870 == 0) {
                                                      boolean var871 = var577;
                                                      boolean var578 = var871;
                                                      boolean var872 = var578;
                                                      if (!var872) {
                                                         break label775;
                                                      }

                                                      Object[] var392 = new Object[]{132200035924850L};
                                                      HandledScreenAccessor var391 = var912;
                                                      Slot var393 = var391.aReturningSlot(var392);
                                                      int var999 = var393.id;
                                                      IntSetting var394 = this.h;
                                                      Integer var395 = (Integer)var394.aReturningObject();
                                                      int var1001 = var395 - 1;
                                                      Object[] var1010 = new Object[]{null, null, 130998474319110L};
                                                      var1010[1] = var1001;
                                                      var1010[0] = var999;
                                                      Object[] var397 = var1010;
                                                      AutoTotem var396 = this;
                                                      boolean var873 = var396.aReturningBoolean(var397);
                                                      var579 = var873;
                                                   }

                                                   int var875 = var48;
                                                   boolean var874 = var579;
                                                   boolean var581 = var874;
                                                   boolean var580 = var874;
                                                   if (var875 == 0) {
                                                      boolean var876 = var580;
                                                      if (!var876) {
                                                         break label775;
                                                      }

                                                      Object[] var401 = new Object[]{16322445639579L};
                                                      AutoTotem var400 = this;
                                                      boolean var877 = var400.iReturningVoid(var401);
                                                      var581 = var877;
                                                   }

                                                   boolean var878 = var581;
                                                   if (var878) {
                                                      return;
                                                   }
                                                }

                                                int var879 = var48;
                                                if (var879 == 0) {
                                                   break label463;
                                                }
                                             }

                                             List var407 = var910;
                                             int var1002 = var407.size() - 1;
                                             Object[] var1011 = new Object[]{null, null, 125343872349393L};
                                             var1011[1] = var1002;
                                             var1011[0] = 0;
                                             Object[] var408 = var1011;
                                             int var410 = RandomUtil.aReturningInt(var408);
                                             List var409 = var910;
                                             Integer var411 = (Integer)var409.get(var410);
                                             int var880 = var411;
                                             var582 = var880;
                                          }

                                          int var913 = var582;
                                          IntSetting var413 = this.h;
                                          Integer var414 = (Integer)var413.aReturningObject();
                                          int var1003 = var414 - 1;
                                          Object[] var1012 = new Object[]{null, null, 130998474319110L};
                                          var1012[1] = var1003;
                                          var1012[0] = var913;
                                          Object[] var416 = var1012;
                                          AutoTotem var415 = this;
                                          byte var968 = ((byte)((var415.aReturningBoolean(var416)) ? 1 : 0));
                                          int var882 = var48;
                                          byte var881 = var968;
                                          var586 = var881;
                                          byte var583 = var881;
                                          if (var882 != 0) {
                                             break label469;
                                          }

                                          byte var883 = var583;
                                          if (var883 != 0) {
                                             Object[] var419 = new Object[]{16322445639579L};
                                             AutoTotem var418 = this;
                                             var968 = ((byte)((var418.iReturningVoid(var419)) ? 1 : 0));
                                             int var885 = var48;
                                             byte var884 = var968;
                                             var586 = var884;
                                             byte var584 = var884;
                                             if (var885 != 0) {
                                                break label469;
                                             }

                                             byte var886 = var584;
                                             byte var585 = var886;
                                             byte var887 = var585;
                                             if (var887 != 0) {
                                                return;
                                             }
                                          }
                                       }
                                    }
                                 }

                                 MultiModeSetting var970 = this.g;
                                 Object[] var423 = new Object[]{"Close Inventory", 71444480285294L};
                                 MultiModeSetting var422 = var970;
                                 var586 = (((var422.aReturningBoolean(var423)) ? 1 : 0));
                              }

                              int var889 = var48;
                              int var888 = var586;
                              int var588 = var888;
                              int var587 = var888;
                              if (var889 == 0) {
                                 int var890 = var587;
                                 if (var890 == 0) {
                                    return;
                                 }

                                 var588 = var52;
                              }

                              int var892 = var48;
                              int var891 = var588;
                              int var590 = var891;
                              int var589 = var891;
                              if (var892 == 0) {
                                 int var893 = var589;
                                 if (var893 != 0) {
                                    return;
                                 }

                                 var590 = var906;
                              }

                              int var895 = var48;
                              int var894 = var590;
                              int var592 = var894;
                              int var591 = var894;
                              if (var895 == 0) {
                                 int var896 = var591;
                                 if (var896 == 0) {
                                    return;
                                 }

                                 MinecraftClient var427 = b;
                                 Object[] var429 = new Object[]{(HandledScreen)var427.currentScreen, 30532135495289L};
                                 AutoTotem var428 = this;
                                 var428.kReturningVoid(var429);
                                 Object[] var431 = new Object[]{16322445639579L};
                                 AutoTotem var430 = this;
                                 byte var897 = ((byte)((var430.iReturningVoid(var431)) ? 1 : 0));
                                 var592 = var897;
                              }

                              int var899 = var48;
                              int var898 = var592;
                              var595 = var898;
                              int var593 = var898;
                              if (var899 != 0) {
                                 break label757;
                              }

                              int var900 = var593;
                              if (var900 != 0) {
                                 return;
                              }
                           }

                           int var902 = var48;
                           AutoTotem var901 = this;
                           var596 = var901;
                           AutoTotem var594 = var901;
                           if (var902 != 0) {
                              break label756;
                           }

                           ElapsedTimer var973 = var594.r;
                           var10004 = new Object[]{null, 139098136696340L};
                           var10004[0] = 150.0F;
                           Object[] var435 = var10004;
                           ElapsedTimer var434 = var973;
                           byte var903 = ((byte)((var434.aReturningBoolean(var435)) ? 1 : 0));
                           var595 = var903;
                        }

                        int var904 = var595;
                        if (var904 == 0) {
                           return;
                        }

                        var596 = this;
                     }

                     var596.t = false;
                     return;
                  }

                  ElapsedTimer var971 = this.s;
                  Object[] var404 = new Object[]{42835128969216L};
                  ElapsedTimer var403 = var971;
                  var403.aReturningVoid(var404);
                  MinMaxSetting var972 = this.j;
                  Object[] var406 = new Object[]{127318019014223L};
                  MinMaxSetting var405 = var972;
                  var405.bReturningVoid(var406);
                  return;
               }

               ElapsedTimer var958 = this.s;
               Object[] var340 = new Object[]{42835128969216L};
               ElapsedTimer var339 = var958;
               var339.aReturningVoid(var340);
               MinMaxSetting var959 = this.j;
               Object[] var342 = new Object[]{127318019014223L};
               MinMaxSetting var341 = var959;
               var341.bReturningVoid(var342);
               return;
            }

            MinecraftClient var120 = b;
            boolean var642 = var120.currentScreen instanceof InventoryScreen;
            var461 = var642;
         }

         AutoTotem var466;
         label691: {
            label690: {
               int var644 = var48;
               boolean var643 = var461;
               boolean var465 = var643;
               boolean var462 = var643;
               if (var644 == 0) {
                  boolean var645 = var462;
                  if (!var645) {
                     break label690;
                  }

                  int var647 = var48;
                  AutoTotem var646 = this;
                  var466 = var646;
                  AutoTotem var463 = var646;
                  if (var647 != 0) {
                     break label691;
                  }

                  AutoTotem var648 = var463;
                  AutoTotem var464 = var648;
                  MultiModeSetting var921 = var464.g;
                  Object[] var125 = new Object[]{"Close Inventory", 71444480285294L};
                  MultiModeSetting var124 = var921;
                  boolean var649 = var124.aReturningBoolean(var125);
                  var465 = var649;
               }

               boolean var650 = var465;
               if (var650) {
                  MinecraftClient var127 = b;
                  Object[] var129 = new Object[]{(HandledScreen)var127.currentScreen, 30532135495289L};
                  AutoTotem var128 = this;
                  var128.kReturningVoid(var129);
               }
            }

            var466 = this;
         }

         var466.t = false;
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 15766618996401L ^ 612807442730L;
      var10001 = 15766618996401L ^ 107522467823634L;
      var10001 = 15766618996401L ^ 27848172371252L;
      var10001 = 15766618996401L ^ 86502879470815L;
      int var12 = Event.bReturningInt();
      int var148 = var12;
      if (var148 == 0) {
         Object[] var19 = new Object[0];
         PacketReceiveEvent var18 = var1;
         boolean var149 = var18.aReturningVoid(var19) instanceof PlayerRespawnS2CPacket;
         if (!var149) {
            int var151 = var12;
            MinecraftClient var150 = b;
            MinecraftClient var112 = var150;
            MinecraftClient var111 = var150;
            if (var151 == 0) {
               MinecraftClient var24 = var111;
               ClientWorld var152 = var24.world;
               if (var152 == null) {
                  return;
               }

               MinecraftClient var153 = b;
               var112 = var153;
            }

            MinecraftClient var27 = var112;
            ClientPlayerEntity var154 = var27.player;
            if (var154 != null) {
               Object var14;
               int var128;
               label167: {
                  Object var127;
                  label166: {
                     Object var126;
                     label165: {
                        MultiModeSetting var227 = this.n;
                        Object[] var30 = new Object[]{"Anti Totem Guard Test", 71444480285294L};
                        MultiModeSetting var29 = var227;
                        boolean var155 = var29.aReturningBoolean(var30);
                        if (var155) {
                           Object[] var32 = new Object[0];
                           PacketReceiveEvent var31 = var1;
                           var14 = var31.aReturningVoid(var32);
                           byte var228 = ((byte)((var14 instanceof EntityDamageS2CPacket) ? 1 : 0));
                           int var157 = var12;
                           byte var156 = var228;
                           var128 = var156;
                           byte var113 = var156;
                           if (var157 != 0) {
                              break label167;
                           }

                           byte var158 = var113;
                           if (var158 != 0) {
                              EntityDamageS2CPacket var13 = (EntityDamageS2CPacket)var14;
                              EntityDamageS2CPacket var34 = var13;
                              int var229 = var34.entityId();
                              int var160 = var12;
                              int var159 = var229;
                              var128 = var159;
                              int var114 = var159;
                              if (var160 != 0) {
                                 break label167;
                              }

                              MinecraftClient var35 = b;
                              ClientPlayerEntity var36 = var35.player;
                              int var162 = var36.getId();
                              int var161 = var114;
                              if (var161 == var162) {
                                 int var164 = var12;
                                 EntityDamageS2CPacket var163 = var13;
                                 var127 = var163;
                                 EntityDamageS2CPacket var115 = var163;
                                 if (var164 != 0) {
                                    break label166;
                                 }

                                 EntityDamageS2CPacket var165 = var115;
                                 EntityDamageS2CPacket var116 = var165;
                                 EntityDamageS2CPacket var39 = var116;
                                 RegistryEntry var40 = var39.sourceType();
                                 DamageType var224 = (DamageType)var40.value();
                                 DamageType var41 = var224;
                                 String var230 = var41.msgId();
                                 String var43 = "generic";
                                 String var42 = var230;
                                 boolean var166 = var42.equals(var43);
                                 label158:
                                 if (var166) {
                                    DamageType var44 = var224;
                                    float var240;
                                    int var231 = (var240 = var44.exhaustion() - 0.0F) == 0.0F ? 0 : (var240 < 0.0F ? -1 : 1);
                                    int var168 = var12;
                                    int var167 = var231;
                                    int var119 = var167;
                                    int var117 = var167;
                                    if (var168 == 0) {
                                       int var169 = var117;
                                       int var118 = var169;
                                       int var170 = var118;
                                       if (var170 != 0) {
                                          break label158;
                                       }

                                       DamageType var47 = var224;
                                       DamageEffects var232 = var47.effects();
                                       DamageEffects var49 = DamageEffects.HURT;
                                       DamageEffects var48 = var232;
                                       byte var171 = ((byte)((var48.equals(var49)) ? 1 : 0));
                                       var119 = var171;
                                    }

                                    int var173 = var12;
                                    int var172 = var119;
                                    int var123 = var172;
                                    int var120 = var172;
                                    if (var173 == 0) {
                                       int var174 = var120;
                                       if (var174 == 0) {
                                          break label158;
                                       }

                                       int var176 = var12;
                                       EntityDamageS2CPacket var175 = var13;
                                       var126 = var175;
                                       EntityDamageS2CPacket var121 = var175;
                                       if (var176 != 0) {
                                          break label165;
                                       }

                                       EntityDamageS2CPacket var177 = var121;
                                       EntityDamageS2CPacket var122 = var177;
                                       EntityDamageS2CPacket var53 = var122;
                                       int var178 = var53.sourceCauseId();
                                       var123 = var178;
                                    }

                                    
                                    if (var179 == var180) {
                                       int var182 = var12;
                                       EntityDamageS2CPacket var181 = var13;
                                       var126 = var181;
                                       EntityDamageS2CPacket var124 = var181;
                                       if (var182 != 0) {
                                          break label165;
                                       }

                                       EntityDamageS2CPacket var183 = var124;
                                       EntityDamageS2CPacket var125 = var183;
                                       EntityDamageS2CPacket var56 = var125;
                                       RegistryEntry var57 = var56.sourceType();
                                       Type var233 = var57.getType();
                                       Type var59 = Type.REFERENCE;
                                       Type var58 = var233;
                                       boolean var184 = var58.equals(var59);
                                       if (var184) {
                                          Object[] var61 = new Object[]{
                                             this, "Detected a manual totem check, ignoring pop.", NotificationType.WARNING, 122717772283555L
                                          };
                                          ModuleNotificationsWidget.s(var61);
                                          MinecraftClient var62 = b;
                                          MinecraftClient var63 = b;
                                          MinecraftClient var64 = b;
                                          float var71 = 5.0F;
                                          float var70 = 13.0F;
                                          SoundCategory var69 = SoundCategory.AMBIENT;
                                          SoundEvent var68 = SoundEvents.BLOCK_ANVIL_PLACE;
                                          ClientPlayerEntity var67 = var64.player;
                                          ClientPlayerEntity var66 = var63.player;
                                          ClientWorld var65 = var62.world;
                                          var65.playSoundFromEntity((Entity)var66, (Entity)var67, var68, var69, var70, var71);
                                          this.O = System.currentTimeMillis() + 500L;
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        Object[] var74 = new Object[0];
                        PacketReceiveEvent var73 = var1;
                        var126 = var73.aReturningVoid(var74);
                     }

                     var14 = var126;
                     var127 = var14;
                  }

                  var128 = (((var127 instanceof EntityStatusS2CPacket) ? 1 : 0));
               }

               Object var140;
               label184: {
                  int var186 = var12;
                  int var185 = var128;
                  int var139 = var185;
                  int var129 = var185;
                  if (var186 == 0) {
                     Object var137;
                     label131: {
                        Object var136;
                        label130: {
                           int var187 = var129;
                           if (var187 != 0) {
                              EntityStatusS2CPacket var222 = (EntityStatusS2CPacket)var14;
                              int var189 = var12;
                              EntityStatusS2CPacket var188 = var222;
                              var137 = var188;
                              EntityStatusS2CPacket var130 = var188;
                              if (var189 != 0) {
                                 break label131;
                              }

                              MinecraftClient var76 = b;
                              ClientWorld var78 = var76.world;
                              EntityStatusS2CPacket var77 = var130;
                              Entity var225 = var77.getEntity((World)var78);
                              MinecraftClient var79 = b;
                              ClientPlayerEntity var191 = var79.player;
                              Entity var190 = var225;
                              if (var190 == var191) {
                                 int var193 = var12;
                                 EntityStatusS2CPacket var192 = var222;
                                 var136 = var192;
                                 EntityStatusS2CPacket var131 = var192;
                                 if (var193 != 0) {
                                    break label130;
                                 }

                                 EntityStatusS2CPacket var194 = var131;
                                 EntityStatusS2CPacket var132 = var194;
                                 EntityStatusS2CPacket var81 = var132;
                                 byte var234 = var81.getStatus();
                                 byte var196 = 35;
                                 byte var195 = var234;
                                 if (var195 == var196) {
                                    Object[] var84 = new Object[]{25310709056389L};
                                    AutoTotem var83 = this;
                                    boolean var235 = var83.gReturningBoolean(var84);
                                    int var198 = var12;
                                    boolean var197 = var235;
                                    boolean var133 = var197;
                                    if (var198 == 0) {
                                       boolean var199 = var133;
                                       boolean var134 = var199;
                                       boolean var200 = var134;
                                       if (var200) {
                                          return;
                                       }

                                       Object[] var88 = new Object[]{16322445639579L};
                                       AutoTotem var87 = this;
                                       boolean var135 = var87.iReturningVoid(var88);
                                    }

                                    this.t = dev.prestige.recovery.SourceSupport.asBoolean(1);
                                 }
                              }
                           }

                           Object[] var90 = new Object[0];
                           PacketReceiveEvent var89 = var1;
                           var136 = var89.aReturningVoid(var90);
                        }

                        var14 = var136;
                        var137 = var14;
                     }

                     int var202 = var12;
                     Object var201 = var137;
                     var140 = var201;
                     Object var138 = var201;
                     if (var202 != 0) {
                        break label184;
                     }

                     byte var203 = ((byte)((var138 instanceof BundlePacket) ? 1 : 0));
                     var139 = var203;
                  }

                  int var204 = var139;
                  if (var204 == 0) {
                     return;
                  }

                  var140 = var14;
               }

               BundlePacket var223 = (BundlePacket)var140;
               BundlePacket var92 = var223;
               Iterable var93 = var92.getPackets();
               Iterator var226 = var93.iterator();

               int var221;
               do {
                  Iterator var94 = var226;
                  boolean var205 = var94.hasNext();
                  if (!var205) {
                     break;
                  }

                  label111: {
                     Iterator var95 = var226;
                     Packet var15 = (Packet)var95.next();
                     int var207 = var12;
                     Packet var206 = var15;
                     Packet var142 = var206;
                     Packet var141 = var206;
                     if (var207 == 0) {
                        boolean var208 = var141 instanceof EntityStatusS2CPacket;
                        if (!var208) {
                           break label111;
                        }

                        Packet var209 = var15;
                        var142 = var209;
                     }

                     EntityStatusS2CPacket var16 = (EntityStatusS2CPacket)var142;
                     MinecraftClient var98 = b;
                     ClientWorld var100 = var98.world;
                     EntityStatusS2CPacket var99 = var16;
                     Entity var17 = var99.getEntity((World)var100);
                     MinecraftClient var101 = b;
                     ClientPlayerEntity var211 = var101.player;
                     Entity var210 = var17;
                     label106:
                     if (var210 == var211) {
                        EntityStatusS2CPacket var102 = var16;
                        byte var236 = var102.getStatus();
                        int var213 = var12;
                        byte var212 = var236;
                        byte var145 = var212;
                        byte var143 = var212;
                        if (var213 == 0) {
                           byte var214 = var143;
                           byte var144 = var214;
                           byte var216 = 35;
                           byte var215 = var144;
                           if (var215 != var216) {
                              break label106;
                           }

                           Object[] var106 = new Object[]{25310709056389L};
                           AutoTotem var105 = this;
                           byte var217 = ((byte)((var105.gReturningBoolean(var106)) ? 1 : 0));
                           var145 = var217;
                        }

                        int var219 = var12;
                        byte var218 = var145;
                        byte var146 = var218;
                        if (var219 == 0) {
                           byte var220 = var146;
                           if (var220 != 0) {
                              return;
                           }

                           Object[] var110 = new Object[]{16322445639579L};
                           AutoTotem var109 = this;
                           boolean var147 = var109.iReturningVoid(var110);
                        }

                        this.t = dev.prestige.recovery.SourceSupport.asBoolean(1);
                     }
                  }

                  var221 = var12;
               } while (var221 == 0);

               return;
            }

            return;
         }

         MinecraftClient var10000 = b;
         Runnable var22 = invokeBinding16(this);
         MinecraftClient var21 = var10000;
         var21.execute(var22);
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 27976875563550L ^ 62736981032811L;
      var10001 = 27976875563550L ^ 26016800580997L;
      var10001 = 27976875563550L ^ 103100062233893L;
      var10001 = 27976875563550L ^ 77974194190445L;
      var10001 = 27976875563550L ^ 87686122475928L;
      var10001 = 27976875563550L ^ 101730381308934L;
      var10001 = 27976875563550L ^ 132326660688202L;
      var10001 = 27976875563550L ^ 97331227074408L;
      var10001 = 27976875563550L ^ 129308510302682L;
      var10001 = 27976875563550L ^ 104029084112022L;
      var10001 = 27976875563550L ^ 62401046229457L;
      var10001 = 27976875563550L ^ 57672446270737L;
      var10001 = 27976875563550L ^ 98456377262192L;
      var10001 = 27976875563550L ^ 104682529876751L;
      int var32 = Event.cReturningInt();
      BooleanSetting var37 = this.e;
      Boolean var38 = (Boolean)var37.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var38)).booleanValue() ? 1 : 0));
      int var232 = var32;
      boolean var231 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var179 = var231;
      boolean var176 = var231;
      if (var232 != 0) {
         boolean var233 = var176;
         if (var233) {
            MinecraftClient var40 = b;
            ClientPlayerEntity var41 = var40.player;
            float var344 = var41.getHealth();
            MinecraftClient var42 = b;
            ClientPlayerEntity var43 = var42.player;
            float var33 = var344 + var43.getAbsorptionAmount();
            int var235 = var32;
            AutoTotem var234 = this;
            AutoTotem var178 = var234;
            AutoTotem var177 = var234;
            if (var235 != 0) {
               float var44 = var177.F;
               boolean var236 = Float.isNaN(var44);
               if (!var236) {
                  float var47 = this.F - var33;
                  float var46 = 0.0F;
                  float var34 = Math.max(var46, var47);
                  float var388;
                  int var237 = (var388 = var34 - 0.0F) == 0.0F ? 0 : (var388 < 0.0F ? -1 : 1);
                  if (var237 > 0) {
                     Deque var345 = this.D;
                     TotemDamageSample var49 = new TotemDamageSample(System.currentTimeMillis(), var34);
                     Deque var48 = var345;
                     var48.addLast(var49);
                  }
               }

               var178 = this;
            }

            var178.F = var33;
         }

         ModeSetting var51 = this.c;
         String var346 = (String)var51.aReturningObject();
         String var53 = "SMP";
         String var52 = var346;
         var179 = var52.equals(var53);
      }

      int var239 = var32;
      boolean var238 = var179;
      boolean var228 = var238;
      boolean var180 = var238;
      if (var239 != 0) {
         boolean var240 = var180;
         if (var240) {
            MinecraftClient var55 = b;
            var10000 = (((var55.isWindowFocused()) ? 1 : 0));
            int var242 = var32;
            byte var241 = ((byte)(var10000));
            byte var183 = var241;
            byte var181 = var241;
            if (var242 != 0) {
               byte var243 = var181;
               byte var182 = var243;
               byte var244 = var182;
               if (var244 == 0) {
                  return;
               }

               Object[] var59 = new Object[]{79083083927176L};
               AutoTotem var58 = this;
               var183 = ((byte)((var58.eReturningBoolean(var59)) ? 1 : 0));
            }

            int var246 = var32;
            byte var245 = var183;
            byte var185 = var245;
            byte var184 = var245;
            if (var246 != 0) {
               byte var247 = var184;
               if (var247 != 0) {
                  return;
               }

               var185 = 0;
            }

            byte var197;
            int var340;
            var340 = var185;
            BooleanSetting var61 = this.q;
            Boolean var62 = (Boolean)var61.aReturningObject();
            var10000 = ((((java.lang.Boolean)(var62)).booleanValue() ? 1 : 0));
            int var249 = var32;
            byte var248 = ((byte)(var10000));
            var197 = var248;
            byte var186 = var248;
            label251:
            if (var249 != 0) {
               byte var250 = var186;
               if (var250 != 0) {
                  Object[] var64 = new Object[]{76915021413912L};
                  var10000 = (((ItemUseUtil.dReturningBoolean(var64)) ? 1 : 0));
                  int var252 = var32;
                  byte var251 = ((byte)(var10000));
                  var197 = var251;
                  byte var187 = var251;
                  if (var252 == 0) {
                     break label251;
                  }

                  byte var253 = var187;
                  byte var188 = var253;
                  byte var254 = var188;
                  if (var254 == 0) {
                     Object[] var67 = new Object[]{77260333461777L};
                     PlayerEntity var341 = EntityUtil.aReturningPlayerEntity(var67);
                     PlayerEntity var255 = var341;
                     if (var255 != null) {
                        int var257 = var32;
                        AutoTotem var256 = this;
                        AutoTotem var196 = var256;
                        AutoTotem var189 = var256;
                        if (var257 != 0) {
                           AutoTotem var258 = var189;
                           AutoTotem var190 = var258;
                           float var69 = var190.C;
                           boolean var259 = Float.isNaN(var69);
                           label242:
                           if (!var259) {
                              PlayerEntity var71 = var341;
                              double var389;
                              var10000 = (var389 = var71.getY() - this.C - 0.4F) == 0.0 ? 0 : (var389 < 0.0 ? -1 : 1);
                              int var261 = var32;
                              int var260 = var10000;
                              int var193 = var260;
                              int var191 = var260;
                              if (var261 != 0) {
                                 int var262 = var191;
                                 int var192 = var262;
                                 int var263 = var192;
                                 if (var263 < 0) {
                                    break label242;
                                 }

                                 MinecraftClient var74 = b;
                                 ClientPlayerEntity var75 = var74.player;
                                 double var353 = var75.getY();
                                 PlayerEntity var76 = var341;
                                 double var390;
                                 int var264 = (var390 = var353 - var76.getY()) == 0.0 ? 0 : (var390 < 0.0 ? -1 : 1);
                                 var193 = var264;
                              }

                              int var265 = var193;
                              label236:
                              if (var265 < 0) {
                                 PlayerEntity var78 = var341;
                                 double var10002 = var78.getX();
                                 MinecraftClient var79 = b;
                                 ClientPlayerEntity var80 = var79.player;
                                 double var383 = var80.getY();
                                 PlayerEntity var81 = var341;
                                 Vec3d var35 = new Vec3d(var10002, var383, var81.getZ());
                                 MinecraftClient var82 = b;
                                 Vec3d var84 = var35;
                                 ClientPlayerEntity var83 = var82.player;
                                 double var85 = var83.squaredDistanceTo(var84);
                                 double var391;
                                 var10000 = (var391 = Math.sqrt(var85) - 8.0) == 0.0 ? 0 : (var391 < 0.0 ? -1 : 1);
                                 int var267 = var32;
                                 int var266 = var10000;
                                 int var195 = var266;
                                 int var194 = var266;
                                 if (var267 != 0) {
                                    int var268 = var194;
                                    if (var268 >= 0) {
                                       break label236;
                                    }

                                    var195 = 1;
                                 }

                                 var340 = var195;
                                 NotificationManager var355 = Prestige.v;
                                 Object[] var10007 = new Object[]{null, null, null, NotificationType.WARNING, 106826240627540L};
                                 var10007[2] = 3000L;
                                 var10007[1] = "Detected mace look, switching to totem!";
                                 var10007[0] = "Auto Totem";
                                 Object[] var89 = var10007;
                                 NotificationManager var88 = var355;
                                 var88.aReturningVoid(var89);
                              }
                           }

                           var196 = this;
                        }

                        PlayerEntity var90 = var341;
                        var196.C = (float)var90.getY();
                     }
                  }
               }

               Object[] var92 = new Object[]{105119720907379L};
               AutoTotem var91 = this;
               var197 = ((byte)((var91.hReturningVoid(var92)) ? 1 : 0));
            }

            int var201;
            int var270 = var32;
            byte var269 = var197;
            var201 = var269;
            byte var198 = var269;
            label225:
            if (var270 != 0) {
               byte var271 = var198;
               if (var271 != 0) {
                  int var273 = var32;
                  int var272 = var340;
                  var201 = var272;
                  int var199 = var272;
                  if (var273 == 0) {
                     break label225;
                  }

                  int var274 = var199;
                  int var200 = var274;
                  int var275 = var200;
                  if (var275 == 0) {
                     return;
                  }
               }

               var201 = this.x;
            }

            int var277 = var32;
            int var276 = var201;
            int var203 = var276;
            int var202 = var276;
            if (var277 != 0) {
               
               if (var278 != var279) {
                  var10000 = this.x;
                  Object[] var386 = new Object[]{null, 72518082610550L};
                  var386[0] = var10000;
                  Object[] var97 = var386;
                  InventoryUtil.aReturningVoid(var97);
                  this.x = -1;
                  return;
               }

               BooleanSetting var99 = this.p;
               Boolean var100 = (Boolean)var99.aReturningObject();
               var203 = ((((java.lang.Boolean)(var100)).booleanValue() ? 1 : 0));
            }

            int var207;
            int var281 = var32;
            int var280 = var203;
            var207 = var280;
            int var204 = var280;
            label217:
            if (var281 != 0) {
               int var282 = var204;
               if (var282 != 0) {
                  Object[] var102 = new Object[]{76915021413912L};
                  byte var356 = ((byte)((ItemUseUtil.dReturningBoolean(var102)) ? 1 : 0));
                  int var284 = var32;
                  byte var283 = var356;
                  var207 = var283;
                  byte var205 = var283;
                  if (var284 == 0) {
                     break label217;
                  }

                  byte var285 = var205;
                  byte var206 = var285;
                  byte var286 = var206;
                  if (var286 != 0) {
                     return;
                  }
               }

               MinecraftClient var105 = b;
               ClientPlayerEntity var106 = var105.player;
               float var357 = var106.getHealth();
               MinecraftClient var107 = b;
               ClientPlayerEntity var108 = var107.player;
               float var358 = var357 + var108.getAbsorptionAmount();
               FloatSetting var109 = this.o;
               Float var110 = (Float)var109.aReturningObject();
               float var392;
               var207 = (var392 = var358 - var110) == 0.0F ? 0 : (var392 < 0.0F ? -1 : 1);
            }

            int var219;
            int var288 = var32;
            int var287 = var207;
            var219 = var287;
            int var208 = var287;
            label210:
            if (var288 != 0) {
               int var289 = var208;
               if (var289 > 0) {
                  int var291 = var32;
                  int var290 = var340;
                  var219 = var290;
                  int var209 = var290;
                  if (var291 == 0) {
                     break label210;
                  }

                  int var292 = var209;
                  int var210 = var292;
                  int var293 = var210;
                  if (var293 == 0) {
                     int var295 = var32;
                     int var294 = this.w;
                     int var211 = var294;
                     if (var295 != 0) {
                        int var296 = var211;
                        int var212 = var296;
                        
                        if (var297 != var298) {
                           MinecraftClient var116 = b;
                           ClientPlayerEntity var117 = var116.player;
                           int var359 = (((var117.isUsingItem()) ? 1 : 0));
                           int var300 = var32;
                           boolean var299 = dev.prestige.recovery.SourceSupport.asBoolean(var359);
                           boolean var213 = var299;
                           if (var300 == 0) {
                              return;
                           }

                           boolean var301 = var213;
                           boolean var214 = var301;
                           boolean var302 = var214;
                           if (!var302) {
                              int var304 = var32;
                              int var303 = this.w;
                              int var215 = var303;
                              label176:
                              if (var304 != 0) {
                                 int var305 = var215;
                                 int var216 = var305;
                                 byte var307 = 9;
                                 int var306 = var216;
                                 if (var306 < var307) {
                                    Object[] var122 = new Object[]{49487520630543L};
                                    this.x = InventoryUtil.aReturningInt(var122);
                                    int var308 = var32;
                                    if (var308 != 0) {
                                       Object[] var124 = new Object[]{49487520630543L};
                                       var359 = InventoryUtil.aReturningInt(var124);
                                       int var310 = this.w;
                                       int var309 = var359;
                                       if (var309 != var310) {
                                          var359 = this.w;
                                          Object[] var384 = new Object[]{null, 72518082610550L};
                                          var384[0] = var359;
                                          Object[] var126 = var384;
                                          InventoryUtil.aReturningVoid(var126);
                                          Object[] var127 = new Object[]{49487520630543L};
                                          Object[] var128 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var127)), 119757183937476L};
                                          PacketUtil.aReturningVoid(var128);
                                       }

                                       Object[] var130 = new Object[]{
                                          new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN), 119757183937476L
                                       };
                                       PacketUtil.aReturningVoid(var130);
                                       this.w = -1;
                                    }

                                    int var311 = var32;
                                    if (var311 != 0) {
                                       break label176;
                                    }
                                 }

                                 int var381 = this.w;
                                 Object[] var10005 = new Object[]{null, AutoTotemState.RESTORE, 37045159029711L};
                                 var10005[0] = var381;
                                 Object[] var132 = var10005;
                                 AutoTotem var131 = this;
                                 boolean var312 = var131.fReturningBoolean(var132);
                              }
                           }
                        }

                        Object[] var135 = new Object[]{16322445639579L};
                        AutoTotem var134 = this;
                        boolean var218 = var134.iReturningVoid(var135);
                     }

                     return;
                  }
               }

               Object[] var136 = new Object[]{Items.TOTEM_OF_UNDYING, 35728906855797L};
               var219 = (((InventoryUtil.mReturningBoolean(var136)) ? 1 : 0));
            }

            int var314 = var32;
            int var313 = var219;
            int var220 = var313;
            if (var314 != 0) {
               int var315 = var220;
               if (var315 == 0) {
                  int var317 = var32;
                  int var316 = this.w;
                  int var221 = var316;
                  if (var317 == 0) {
                     return;
                  }

                  int var318 = var221;
                  int var222 = var318;
                  
                  if (var319 == var320) {
                     Item var362 = Items.TOTEM_OF_UNDYING;
                     Object[] var10004 = new Object[]{null, null, 75544266747707L};
                     var10004[1] = true;
                     var10004[0] = var362;
                     Object[] var143 = var10004;
                     List var342 = InventoryUtil.aReturningList(var143);
                     List var144 = var342;
                     Iterator var343 = var144.iterator();
                     Iterator var145 = var343;
                     int var363 = (((var145.hasNext()) ? 1 : 0));
                     int var323 = var32;
                     boolean var322 = dev.prestige.recovery.SourceSupport.asBoolean(var363);
                     boolean var224 = var322;
                     if (var323 != 0) {
                        boolean var324 = var224;
                        if (var324) {
                           Iterator var147 = var343;
                           Integer var36 = (Integer)var147.next();
                           Integer var148 = var36;
                           var363 = var148;
                           int var326 = var32;
                           int var325 = var363;
                           int var225 = var325;
                           label190:
                           if (var326 != 0) {
                              byte var328 = 9;
                              int var327 = var225;
                              if (var327 < var328) {
                                 Object[] var150 = new Object[]{49487520630543L};
                                 this.x = InventoryUtil.aReturningInt(var150);
                                 int var329 = var32;
                                 if (var329 != 0) {
                                    Object[] var152 = new Object[]{49487520630543L};
                                    var363 = InventoryUtil.aReturningInt(var152);
                                    Integer var153 = var36;
                                    int var331 = var153;
                                    int var330 = var363;
                                    if (var330 != var331) {
                                       Integer var155 = var36;
                                       var363 = var155;
                                       Object[] var385 = new Object[]{null, 72518082610550L};
                                       var385[0] = var363;
                                       Object[] var156 = var385;
                                       InventoryUtil.aReturningVoid(var156);
                                       Object[] var157 = new Object[]{49487520630543L};
                                       Object[] var158 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var157)), 119757183937476L};
                                       PacketUtil.aReturningVoid(var158);
                                    }

                                    Object[] var160 = new Object[]{
                                       new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN), 119757183937476L
                                    };
                                    PacketUtil.aReturningVoid(var160);
                                    Integer var161 = var36;
                                    this.w = var161;
                                 }

                                 int var332 = var32;
                                 if (var332 != 0) {
                                    break label190;
                                 }
                              }

                              Integer var162 = var36;
                              int var382 = var162;
                              Object[] var387 = new Object[]{null, AutoTotemState.EQUIP, 37045159029711L};
                              var387[0] = var382;
                              Object[] var164 = var387;
                              AutoTotem var163 = this;
                              boolean var333 = var163.fReturningBoolean(var164);
                           }
                        }

                        Object[] var167 = new Object[]{16322445639579L};
                        AutoTotem var166 = this;
                        boolean var227 = var166.iReturningVoid(var167);
                     }

                     return;
                  }
               }

               Object[] var141 = new Object[]{16322445639579L};
               AutoTotem var140 = this;
               boolean var321 = var140.iReturningVoid(var141);
            }

            return;
         }

         MultiModeSetting var347 = this.n;
         Object[] var169 = new Object[]{"Double Hand On GUI", 71444480285294L};
         MultiModeSetting var168 = var347;
         var228 = var168.aReturningBoolean(var169);
      }

      boolean var334 = var228;
      if (var334) {
         MinecraftClient var170 = b;
         Screen var335 = var170.currentScreen;
         if (var335 != null) {
            Object[] var172 = new Object[]{Items.TOTEM_OF_UNDYING, 95321893129094L};
            Integer var339 = InventoryUtil.aReturningBoxedInteger(var172);
            int var337 = var32;
            Integer var336 = var339;
            Integer var230 = var336;
            Integer var229 = var336;
            if (var337 != 0) {
               Integer var338 = var229;
               if (var338 == null) {
                  return;
               }

               var230 = var339;
            }

            Integer var174 = var230;
            var10000 = var174;
            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var10000;
            Object[] var175 = var10003;
            InventoryUtil.aReturningVoid(var175);
         }
      }
   }

   private boolean h(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 129566406602223L;
      int var6 = Event.bReturningInt();
      ElapsedTimer var10000 = this.r;
      Object[] var8 = new Object[]{this.d, var4};
      ElapsedTimer var7 = var10000;
      byte var17 = ((byte)((var7.bReturningBoolean(var8)) ? 1 : 0));
      int var13 = var6;
      byte var12 = var17;
      byte var10 = var12;
      byte var9 = var12;
      if (var13 == 0) {
         byte var14 = var9;
         if (var14 != 0) {
            return false;
         }

         var10 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var10);
   }

   private boolean i(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 93836342817421L;
      long var6 = var2 ^ 35525283124275L;
      long var8 = var2 ^ 93544624760239L;
      long var10 = var2 ^ 129130373775996L;
      int var10000 = Event.cReturningInt();
      MinMaxSetting var10001 = this.d;
      Object[] var18 = new Object[]{var6};
      MinMaxSetting var17 = var10001;
      var17.bReturningVoid(var18);
      int var12 = var10000;
      BooleanSetting var19 = this.e;
      Boolean var20 = (Boolean)var19.aReturningObject();
      byte var55 = ((byte)(((java.lang.Boolean)(var20)).booleanValue() ? 1 : 0));
      int var48 = var12;
      byte var47 = var55;
      byte var46 = var47;
      byte var43 = var47;
      if (var48 != 0) {
         byte var49 = var43;
         if (var49 != 0) {
            ModeSetting var22 = this.c;
            String var56 = (String)var22.aReturningObject();
            short var63 = 11887;
            long var10002 = 5788754885017831359L ^ var2;
            String var24 = "Crystal";
            String var23 = var56;
            boolean var57 = var23.equals(var24);
            int var51 = var12;
            boolean var50 = var57;
            boolean var65 = var50;
            boolean var44 = var50;
            if (var51 == 0) {
               return var65;
            }

            boolean var52 = var44;
            boolean var45 = var52;
            boolean var53 = var45;
            if (var53) {
               Object[] var28 = new Object[]{var8};
               AutoTotem var27 = this;
               float var13 = var27.bReturningFloat(var28);
               MinMaxSetting var58 = this.d;
               Object[] var30 = new Object[]{var4};
               MinMaxSetting var29 = var58;
               float var14 = var29.fReturningFloat(var30);
               MinMaxSetting var31 = this.d;
               float var59 = var14 - var31.cReturningVoid();
               double var64 = var13 / 100.0F;
               double var34 = 2.0;
               double var32 = var64;
               float var15 = var59 * (float)Math.pow(var32, var34);
               MinMaxSetting var36 = this.d;
               float var60 = var36.cReturningVoid();
               float var38 = var14 - var15;
               float var37 = var60;
               float var16 = Math.max(var37, var38);
               MinMaxSetting var61 = this.d;
               Object[] var40 = new Object[]{var16};
               MinMaxSetting var39 = var61;
               var39.cReturningVoid(var40);
            }
         }

         ElapsedTimer var62 = this.r;
         Object[] var42 = new Object[]{var10};
         ElapsedTimer var41 = var62;
         var41.aReturningVoid(var42);
         var46 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var46);
   }

   private void nReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 102652054115815L ^ var2;
      long var4 = var2 ^ 29028970011964L;
      long var6 = var2 ^ 87695774768949L;

      try {
         short var10001 = 12084;
         long var10002 = 7997422446462608977L ^ var2;
         Object[] var9 = new Object[]{GraphicsEnvironment.class, "headless", var4};
         ReflectedField var10000 = ReflectedField.aReturningcR_C0145(var9);
         Object[] var12 = new Object[]{false, var6};
         ReflectedField var11 = var10000;
         var11.cReturningVoid(var12);
         this.G = new Robot();
      } catch (Exception var14) {
      }
   }

   private static boolean lambda$computeDangerScore$14(long var0, TotemDamageSample var2) {
      int var5 = Event.cReturningInt();
      long var13;
      int var10000 = (var13 = var0 - var2.recoveryAccess_read_a() - 5000L) == 0L ? 0 : (var13 < 0L ? -1 : 1);
      int var10 = var5;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      if (var10 != 0) {
         int var11 = var6;
         if (var11 <= 0) {
            return false;
         }

         var7 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private void lambda$requestSmpInventorySwap$13(long var1, AutoTotemState var3, int var4) {
      long var10001 = 58202831052182L ^ 5487574213041L;
      Object[] var10006 = new Object[]{null, null, null, 52857289620519L};
      var10006[2] = var4;
      var10006[1] = var3;
      var10006[0] = var1;
      Object[] var10 = var10006;
      AutoTotem var9 = this;
      var9.lReturningVoid(var10);
   }

   private boolean lambda$new$12(Boolean var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "SMP";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$11(Boolean var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "SMP";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$10(Float var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "SMP";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$9(String var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$8(Float var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.c;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Crystal";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.k;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$7(Float var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.c;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Crystal";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.k;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$6(Boolean var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$5(Float var1) {
      long var10001 = 83103547250777L ^ 12573444899383L;
      int var6 = Event.bReturningInt();
      ModeSetting var7 = this.c;
      String var10000 = (String)var7.aReturningObject();
      String var9 = "Crystal";
      String var8 = var10000;
      byte var36 = ((byte)((var8.equals(var9)) ? 1 : 0));
      int var25 = var6;
      byte var24 = var36;
      byte var18 = var24;
      byte var17 = var24;
      if (var25 == 0) {
         byte var26 = var17;
         if (var26 == 0) {
            return false;
         }

         BooleanSetting var11 = this.i;
         Boolean var12 = (Boolean)var11.aReturningObject();
         byte var27 = ((byte)(((java.lang.Boolean)(var12)).booleanValue() ? 1 : 0));
         var18 = var27;
      }

      int var29 = var6;
      byte var28 = var18;
      byte var20 = var28;
      byte var19 = var28;
      if (var29 == 0) {
         byte var30 = var19;
         if (var30 == 0) {
            return false;
         }

         MultiModeSetting var37 = this.g;
         Object[] var16 = new Object[]{"Switch", 71444480285294L};
         MultiModeSetting var15 = var37;
         byte var31 = ((byte)((var15.aReturningBoolean(var16)) ? 1 : 0));
         var20 = var31;
      }

      int var33 = var6;
      byte var32 = var20;
      byte var22 = var32;
      byte var21 = var32;
      if (var33 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var22);
      } else {
         byte var34 = var21;
         if (var34 != 0) {
            var22 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var22);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$4(Boolean var1) {
      long var10001 = 44729162637665L ^ 114710641376015L;
      int var6 = Event.bReturningInt();
      ModeSetting var7 = this.c;
      String var10000 = (String)var7.aReturningObject();
      String var9 = "Crystal";
      String var8 = var10000;
      byte var26 = ((byte)((var8.equals(var9)) ? 1 : 0));
      int var19 = var6;
      byte var18 = var26;
      byte var14 = var18;
      int var13 = var18;
      if (var19 == 0) {
         int var20 = var13;
         if (var20 == 0) {
            return false;
         }

         MultiModeSetting var27 = this.g;
         Object[] var12 = new Object[]{"Switch", 71444480285294L};
         MultiModeSetting var11 = var27;
         byte var21 = ((byte)((var11.aReturningBoolean(var12)) ? 1 : 0));
         var14 = var21;
      }

      int var23 = var6;
      byte var22 = var14;
      byte var16 = var22;
      byte var15 = var22;
      if (var23 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var16);
      } else {
         byte var24 = var15;
         if (var24 != 0) {
            var16 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var16);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$3(Integer var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$2(String var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(String var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.c;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Crystal";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.e;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      int var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Crystal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      h();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(15750673335936L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[25];
      String var28 = "%Û\u0094\u009eZBN\u0081\u009c\u0019\u001bÃFÉÝø\u0011\u0004#\u0087\u000fVhH\u0010à\u0002$#Ü@#|Á\u0082Áñm«`\u0010¯e&\u009e\u0091ÿ>húÄXãðc\u0014ó\u0010å6õ@æo%\u009d\u0015ìæ \u008e%\u0094¿\u0010\u0088ääxW\u0002Åf\u0092\u0088\u0007\u009e\u000f\u008as\u0099(¤\u009b)\u0002ZLsa¹\u0015U¹¹ùÿx£ÌJU\u0085l;Íå@z³ú\u0013UWT´\u0012ÿ\u0080¥Ö\u00930\u000eò\u0019ï.x\u0091\u000e4*6 \u0096\u0088\u0007çs\u0089È7\u009c_\u009e\u0086ÞW-èàsS\u0019ÝCz4\tM:´®Ô\u0015\u0092\u0016[z\u0080\u0010Õ\u008aÌ«a\u0082ÌÒx\u0090ÈH\u0011n>,@©\u009cîfSäï¾Ø\u0014vMÏOIXÃÿj¦LCúà\\\u0006à!êwpAµT¢3@\u0083Ã\u0001${\u001eRølÔþuºðÞÏ\u007f\u008dÍ8µ(\u001c)\u0082^6(²\u0004ô*S4ºá?ÕGü!ÿ»£@²¯ù3²O\f\tÙæ³3«&\u0002·á\u0090àæG\u0081¿\u0010©\rÇÇ.3e\u0082\u0097\u0097{rê\"Ó{ \tü\u0087\\ÊÑËÒ$Çi\t¦9>\u0097\u0015Ä\u0083\u009a\u0087á\u0090 +\u0087\u0086¢¢\u001bù®\u0018Í\u000be\u0082¸híÅ¾9\u0095ÿ`ÈÒ3!q·\u0088|+Lû \u0000Ê\u0002ÏTg\u0088ÂÄ\u001bt5Rj£.Ûõâ\u0091è\u0019\u00996\u008eÁ¼¤JÅ¦&\u0010Ây\u0012§eí®ý\fhÂü?\u001f\u008a\"\u0018¤MúÚ¨!ÕÀÆý)ZD\u008bókÇ\u0086×á\u0097\u000fû\u001b\u0010M\u0004ÀÏÄ\u008bE¶¹½\u0002àî¤²v(\u0019<`eäEûò¸4gi\u0007\u0090\u0005$QÅ\u0089¹q\u0012ØÉ5Í\u001c\"?ÅÂ\u0082vÅÞÙa\u0019îF \u0082\u0081²Í{ì\u0085NëiùE°ªÄzÌÉ7\u008ei2²\u009eVÁEzH«\t_\u0010\u0007¦¢¸Ö3»qï'?\u0017\b\u000e°& \u0091\u009eí\u0094v\u0006\u0091ëXGy\u00906KÏe\u0085;\u00adMÖ£¡iÉ:¾j\u0094bèÃ\u0010\u0098\u0010c¬K{\u0088\u008eßÄ\u009bu\b}ÆuP\u0092îeO.Ð\u0003\u009e®C\u0006J\u0013ö\u0003g=\u0098[[fPQBÛùÖÊÇ\u0088´1ºØÐß\u0013ö}¸gC\u0097\u007fJ\u0016Y|»¼\u008dÞ{¯\u0093CÈÇ÷^jSÕe]Õã\ty\u009bÖ½\u0080ºâü\u0089\u0005oc0ÂÊÄñÕ\u0094E\u001a©©\u0099\u0012oiç¡ÁÌ\u0096!c!cä-\\\u000bá\rÝ\u0099ýËô0ç·¾esÿ\u0095\u009eÑ\u0011«\n\u0086";
      int var30 = "%Û\u0094\u009eZBN\u0081\u009c\u0019\u001bÃFÉÝø\u0011\u0004#\u0087\u000fVhH\u0010à\u0002$#Ü@#|Á\u0082Áñm«`\u0010¯e&\u009e\u0091ÿ>húÄXãðc\u0014ó\u0010å6õ@æo%\u009d\u0015ìæ \u008e%\u0094¿\u0010\u0088ääxW\u0002Åf\u0092\u0088\u0007\u009e\u000f\u008as\u0099(¤\u009b)\u0002ZLsa¹\u0015U¹¹ùÿx£ÌJU\u0085l;Íå@z³ú\u0013UWT´\u0012ÿ\u0080¥Ö\u00930\u000eò\u0019ï.x\u0091\u000e4*6 \u0096\u0088\u0007çs\u0089È7\u009c_\u009e\u0086ÞW-èàsS\u0019ÝCz4\tM:´®Ô\u0015\u0092\u0016[z\u0080\u0010Õ\u008aÌ«a\u0082ÌÒx\u0090ÈH\u0011n>,@©\u009cîfSäï¾Ø\u0014vMÏOIXÃÿj¦LCúà\\\u0006à!êwpAµT¢3@\u0083Ã\u0001${\u001eRølÔþuºðÞÏ\u007f\u008dÍ8µ(\u001c)\u0082^6(²\u0004ô*S4ºá?ÕGü!ÿ»£@²¯ù3²O\f\tÙæ³3«&\u0002·á\u0090àæG\u0081¿\u0010©\rÇÇ.3e\u0082\u0097\u0097{rê\"Ó{ \tü\u0087\\ÊÑËÒ$Çi\t¦9>\u0097\u0015Ä\u0083\u009a\u0087á\u0090 +\u0087\u0086¢¢\u001bù®\u0018Í\u000be\u0082¸híÅ¾9\u0095ÿ`ÈÒ3!q·\u0088|+Lû \u0000Ê\u0002ÏTg\u0088ÂÄ\u001bt5Rj£.Ûõâ\u0091è\u0019\u00996\u008eÁ¼¤JÅ¦&\u0010Ây\u0012§eí®ý\fhÂü?\u001f\u008a\"\u0018¤MúÚ¨!ÕÀÆý)ZD\u008bókÇ\u0086×á\u0097\u000fû\u001b\u0010M\u0004ÀÏÄ\u008bE¶¹½\u0002àî¤²v(\u0019<`eäEûò¸4gi\u0007\u0090\u0005$QÅ\u0089¹q\u0012ØÉ5Í\u001c\"?ÅÂ\u0082vÅÞÙa\u0019îF \u0082\u0081²Í{ì\u0085NëiùE°ªÄzÌÉ7\u008ei2²\u009eVÁEzH«\t_\u0010\u0007¦¢¸Ö3»qï'?\u0017\b\u000e°& \u0091\u009eí\u0094v\u0006\u0091ëXGy\u00906KÏe\u0085;\u00adMÖ£¡iÉ:¾j\u0094bèÃ\u0010\u0098\u0010c¬K{\u0088\u008eßÄ\u009bu\b}ÆuP\u0092îeO.Ð\u0003\u009e®C\u0006J\u0013ö\u0003g=\u0098[[fPQBÛùÖÊÇ\u0088´1ºØÐß\u0013ö}¸gC\u0097\u007fJ\u0016Y|»¼\u008dÞ{¯\u0093CÈÇ÷^jSÕe]Õã\ty\u009bÖ½\u0080ºâü\u0089\u0005oc0ÂÊÄñÕ\u0094E\u001a©©\u0099\u0012oiç¡ÁÌ\u0096!c!cä-\\\u000bá\rÝ\u0099ýËô0ç·¾esÿ\u0095\u009eÑ\u0011«\n\u0086"
         .length();
      char var27 = '(';
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     Q = var31;
                     R = new String[25];
                     V = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(15750673335936L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[11];
                     String var15 = "-\u001a\u008fÆ\u001dí\u009c~\u0002\u00872=ív'\n~F\u0091R±há\u0091Ç_æ\u0082\u0091âð\u0095\u0081ß^B>Å\u0093DVó&ÿP6\u0086ò\u0084 §C°ý@\u008b±\u0080ú@ªP@\u0013\u001co\u00ad&\u0007\u0019ºw";
                     int var16 = "-\u001a\u008fÆ\u001dí\u009c~\u0002\u00872=ív'\n~F\u0091R±há\u0091Ç_æ\u0082\u0091âð\u0095\u0081ß^B>Å\u0093DVó&ÿP6\u0086ò\u0084 §C°ý@\u008b±\u0080ú@ªP@\u0013\u001co\u00ad&\u0007\u0019ºw"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    T = var17;
                                    U = new Integer[11];
                                    Y = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(15750673335936L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[9];
                                    String var4 = "9\u007f9ºmð¼0\u0088\u0018x\u0011Kú\u007f¼\u0018ªã\u000f-\u0012U\u000b\u008b\tl´\u009b`©qú~\u0014{§ó\u0090\u0004\u0093M,¾SVp\u0080}?tÁØ.°&";
                                    int var5 = "9\u007f9ºmð¼0\u0088\u0018x\u0011Kú\u007f¼\u0018ªã\u000f-\u0012U\u000b\u008b\tl´\u009b`©qú~\u0014{§ó\u0090\u0004\u0093M,¾SVp\u0080}?tÁØ.°&"
                                       .length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   W = var6;
                                                   X = new Long[9];
                                                   E = 5000L;
                                                   a = 500L;
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "gm\u001c;µ³¿\u008e5¸iê!QÊÿ";
                                                var5 = "gm\u001c;µ³¿\u008e5¸iê!QÊÿ".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "\u000fQ\u001a\u001dXÖAï\u001b\u00902ÉÝ\u001br[";
                                 var16 = "\u000fQ\u001a\u001dXÖAï\u001b\u00902ÉÝ\u001br[".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "\u000e÷Z\u0080xîwTJa¹{$CEòÛ\tàV\u009b\u008e\\¸\u009eº\u0089*u±Û\u0007 ï\u009d°\u0006,Ü\u001e\u001aT\u0096÷¶ë\u0018ÑÜøßC»éu2Zô\u0012ü\u0017\u008d**ü";
                  var30 = "\u000e÷Z\u0080xîwTJa¹{$CEòÛ\tàV\u009b\u008e\\¸\u009eº\u0089*u±Û\u0007 ï\u009d°\u0006,Ü\u001e\u001aT\u0096÷¶ë\u0018ÑÜøßC»éu2Zô\u0012ü\u0017\u008d**ü"
                     .length();
                  var27 = ' ';
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 17325;
      if (R[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])S.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               S.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/em", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = Q[var5].getBytes("ISO-8859-1");
         R[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return R[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/em_C0242",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/em" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23551;
      if (U[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = T[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])V.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               V.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/em", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         U[var3] = var15;
      }

      return U[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/em_C0242",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/em" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20639;
      if (X[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = W[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])Y.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               Y.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/em", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         X[var3] = var15;
      }

      return X[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/em_C0242",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/em" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = ab[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = Z[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 30;
            yield var15;
         }
         case 1 -> {
            byte var16 = 55;
            yield var16;
         }
         case 2 -> {
            byte var17 = 57;
            yield var17;
         }
         case 3 -> {
            byte var18 = 22;
            yield var18;
         }
         case 4 -> {
            byte var19 = 44;
            yield var19;
         }
         case 5 -> {
            byte var20 = 18;
            yield var20;
         }
         case 6 -> {
            byte var21 = 33;
            yield var21;
         }
         case 7 -> {
            byte var22 = 36;
            yield var22;
         }
         case 8 -> {
            byte var23 = 0;
            yield var23;
         }
         case 9 -> {
            byte var24 = 45;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 34;
            yield var26;
         }
         case 12 -> {
            byte var27 = 43;
            yield var27;
         }
         case 13 -> {
            byte var28 = 12;
            yield var28;
         }
         case 14 -> {
            byte var29 = 50;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 56;
            yield var31;
         }
         case 17 -> {
            byte var32 = 26;
            yield var32;
         }
         case 18 -> {
            byte var33 = 59;
            yield var33;
         }
         case 19 -> {
            byte var34 = 5;
            yield var34;
         }
         case 20 -> {
            byte var35 = 11;
            yield var35;
         }
         case 21 -> {
            byte var36 = 39;
            yield var36;
         }
         case 22 -> {
            byte var37 = 29;
            yield var37;
         }
         case 23 -> {
            byte var38 = 15;
            yield var38;
         }
         case 24 -> {
            byte var39 = 10;
            yield var39;
         }
         case 25 -> {
            byte var40 = 6;
            yield var40;
         }
         case 26 -> {
            byte var41 = 17;
            yield var41;
         }
         case 27 -> {
            byte var42 = 62;
            yield var42;
         }
         case 28 -> {
            byte var43 = 63;
            yield var43;
         }
         case 29 -> {
            byte var44 = 2;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 8;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 14;
            yield var48;
         }
         case 34 -> {
            byte var49 = 3;
            yield var49;
         }
         case 35 -> {
            byte var50 = 13;
            yield var50;
         }
         case 36 -> {
            byte var51 = 7;
            yield var51;
         }
         case 37 -> {
            byte var52 = 58;
            yield var52;
         }
         case 38 -> {
            byte var53 = 9;
            yield var53;
         }
         case 39 -> {
            byte var54 = 31;
            yield var54;
         }
         case 40 -> {
            byte var55 = 24;
            yield var55;
         }
         case 41 -> {
            byte var56 = 52;
            yield var56;
         }
         case 42 -> {
            byte var57 = 38;
            yield var57;
         }
         case 43 -> {
            byte var58 = 42;
            yield var58;
         }
         case 44 -> {
            byte var59 = 35;
            yield var59;
         }
         case 45 -> {
            byte var60 = 4;
            yield var60;
         }
         case 46 -> {
            byte var61 = 54;
            yield var61;
         }
         case 47 -> {
            byte var62 = 19;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 61;
            yield var64;
         }
         case 50 -> {
            byte var65 = 21;
            yield var65;
         }
         case 51 -> {
            byte var66 = 28;
            yield var66;
         }
         case 52 -> {
            byte var67 = 25;
            yield var67;
         }
         case 53 -> {
            byte var68 = 20;
            yield var68;
         }
         case 54 -> {
            byte var69 = 47;
            yield var69;
         }
         case 55 -> {
            byte var70 = 41;
            yield var70;
         }
         case 56 -> {
            byte var71 = 16;
            yield var71;
         }
         case 57 -> {
            byte var72 = 27;
            yield var72;
         }
         case 58 -> {
            byte var73 = 49;
            yield var73;
         }
         case 59 -> {
            byte var74 = 48;
            yield var74;
         }
         case 60 -> {
            byte var75 = 60;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 40;
            yield var77;
         }
         default -> 46;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            ab[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void h() {
      Z[0] = "B\u00031!\u0018dT\u00034{\u000bsCH7}\u0007gR\u000f jLpj";
      Z[1] = "\u0014p3ZHqaP8UY>\u0000^3^]dt";
      Z[2] = void.class;
      ab[2] = "java/lang/Void";
      Z[3] = "\u0002Xb.w9\u001cPxa\u0015%\u001bM";
      Z[4] = "nW\u000fr\b}xW\n(\u001bjo\u001c\t.\u0017~~[\u001e9\\lO";
      Z[5] = int.class;
      ab[5] = "java/lang/Integer";
      Z[6] = "A\rG,\u00157W\rBv\u0006 @FAp\n4Q\u0001VgA$I\u0001Tl\u001biu\u001aTq\u001b.B\r";
      Z[7] = "\u0017\u001c] J \u0001\u001cXzY7\u0016W[|U#\u0007\u0010Lk\u001e2%";
      Z[8] = "ajQ-|Q\u0014JZ\"m\u001euDQ)iD\u0001";
      Z[9] = "Ee>v8*[m$9R:^q-";
      Z[10] = "\u001eDS';)\bDV}(>\u001f\u000fU{$*\u000eHBlo?#";
      Z[11] = "BJo}@,7jdrQcVdoyU9\"";
      Z[12] = "\bz<M\u0015\u0014\u001ez9\u0017\u0006\u0003\t1:\u0011\n\u0017\u0018v-\u0006A\u0001\u0001";
      Z[13] = "Rq\rs\b\u000b'Q\u0006|\u0019DF_\rw\u001d\u001e2";
      Z[14] = "G+ \u0004\u001f$L$1K|)Y)> I+H:\"\f^&";
      Z[15] = "$\u0000L;*\nQ G4;E0.L??\u001fD";
      Z[16] = boolean.class;
      ab[16] = "java/lang/Boolean";
      Z[17] = "GFn0\u0011#GFyl\u001d,]\ryr\u001d9Z|(-Iz";
      Z[18] = "?.E&&\u007f).@|5h>eCz9|/\"Tmrk\u0015";
      Z[19] = "lM*LW\u000b\u0019m!CFDxc*HB\u001e\f";
      Z[20] = "J~0y\u000e\u0018J~'%\u0002\u0017P5';\u0002\u0002WDuaVF";
      Z[21] = double.class;
      ab[21] = "java/lang/Double";
      Z[22] = "\u001d\fXU-}\u000b\f]\u000f>j\u001cG^\t2~\r\u0000I\u001eyn\u0016";
      Z[23] = "0\u0003\u0005k..E#\u000ed?a$-\u0005o;;P";
      Z[24] = "($@:7@#+QuJU11S6";
      Z[25] = long.class;
      ab[25] = "java/lang/Long";
      Z[26] = "\fQ\u001ag{j\fQ\r;we\u0016\u001a\r%wp\u0011k]x&";
      Z[27] = "7/x~\bG7/o\"\u0004H-do<\u0004]*\u00158cR";
      Z[28] = "-\u00174<MIX7?3\\\u00069948X\\M";
      Z[29] = "\fe \u0006@E\u0007j1I(E\te\"";
      Z[30] = float.class;
      ab[30] = "java/lang/Float";
      Z[31] = "z|GH\u007f*dt]\u0007\u0018+uoP]>-";
      Z[32] = "cX./e\u000fhW?`\t\ffU=/%";
      Z[33] = "J^U9\u007f]J^BesRP\u0015B{sGWd\u0013$!\f";
      Z[34] = "H\u0012^{JpH\u0012I'F\u007fRYI9FjU(\u0018m\u0013/\u0002\u0014F4TjyE\u0012a\u0010";
      Z[35] = "\u007f\u00124\u007fI\u007fi\u00121%Zh~Y2#V|o\u001e%4\u001dk]";
      Z[36] = "\u0003;V\u0017\u001a:\b4GX{4\u0003?C\u0002";
      Z[37] = "w!V_\f+|.G\u0010k)i%G[P";
      Z[38] = "+6%\u0011\u001aO+62M\u0016@1}2S\u0016U6\ff\u000bA";
      Z[39] = "\b\u0012S33R}2X<\"\u001d\u001c<S7&Gh";
      Z[40] = "B.E\u0014sb7\u000eN\u001bb-V\u0000E\u0010fw\"";
      Z[41] = "\"[`b8|)Tq-[q<R";
      Z[42] = ",dEd\n\\:d@>\u0019K-/C8\u0015_<hT/^O\u0007";
      Z[43] = "Jz\u0004{\tX?Z\u000ft\u0018\u0017^T\u0004\u007f\u001cM*";
      Z[44] = ";<V\f\r(-<SV\u001e?:wPP\u0012++0GGY;o";
      Z[45] = "\u00103d\u0000,\"e\u0013o\u000f=m\u0004\u001dd\u000497p";
      Z[46] = "V_i\u0003{\u0015#\u007fb\fjZBqi\u0007n\u00006";
      Z[47] = "`z4ud,`z#)h#z1#7h6}@ro:";
      Z[48] = "=6 eiM691*\u0014U%>8c";
      Z[49] = "4!-F\u0013QA\u0001&I\u0002\u001e \u000f-B\u0006DT";
      Z[50] = "\u001f\f+X$\u0011\t\f.\u00027\u0006\u001eG-\u0004;\u0012\u000f\u0000:\u0013p\u0002\u0017";
      Z[51] = ";+\u0012fu>N\u000b\u0019idq/\u0005\u0012b`+[";
      Z[52] = "\u000b#p;\u0015\u000e~\u0003{4\u0004A\u001f\rp?\u0000\u001bk";
      Z[53] = ">la\u000e{M(ldThZ?'gRdN.`pE/[\u000f";
      Z[54] = "\u0016Ym\u000ez>cyf\u0001kq\u0002wm\no+v";
      Z[55] = "`>^\t\u0006\u0006`>IU\n\tzuIK\n\u001c}\u0004\u001b\u001f[]";
      Z[56] = "xs\u0002G)%xs\u0015\u001b%*b8\u0015\u0005%?eIG^}~";
      Z[57] = "\"pM/X WPF Io6^M+M5B";
      Z[58] = "(dq6\u000b>(dfj\u000712/ft\u0007$5^1!V";
      Z[59] = "[t{J9\u0014[tl\u00165\u001bA?l\b5\u000eFN>SdN";
      Z[60] = "\u000bf2\u001fda\u000bf%Chn\u0011-%]h{\u0016\\p\u0002=";
      Z[61] = ";;Z*|);;Mvp&!pMhp3&\u0001\u001f3#s";
      Z[62] = "aSo\u0004T4\u0014sd\u000bE{u}o\u0000A!\u0001";
      Z[63] = "R}\u000e$(\u0018']\u0005+9WFS\u000e =\r2";
      Z[64] = "i\tl5s9\u001c)g:bv}'l1f,\t";
      Z[65] = "M!C2?C8\u0001H=.\fY\u000fC6*V-";
      Z[66] = "n\u000bfo{hx\u000bc5h\u007fo@`3dk~\u0007w$/{X";
      Z[67] = "p\n|,Hg\u0005*w#Y(d$|(]r\u0010";
      Z[68] = "\u0006p5iu;sP>fdt\u0012^5m`.f";
      Z[69] = "Z(-dX$/\b&kIkN\u0006-`M1:";
      Z[70] = "7' P[T7'7\fW[-l7\u0012WN*\u001dfM\u0001\f";
      Z[71] = "\u007fHS\u001f\u00184\u007fHDC\u0014;e\u0003D]\u0014.br\u0013\u0007@";
      Z[72] = "\u00188(b8\u0017\u00188?>4\u0018\u0002s? 4\r\u0005\u0002m|aO";
      Z[73] = "n9\u0006`w1s,^Q69j,\u0015s\u0010>b7";
      Z[74] = "\u001a-Ul!\u0010\u00078\r]`\u0018\u001e8";
      Z[75] = "E\b_\\f\u00020(TSwMQ&_Xs\u0017%";
      Z[76] = "1J\\TTO/BF\u001b([5OEX";
      Z[77] = "R5\u000eXy\u0011R5\u0019\u0004u\u001eH~\u0019\u001au\u000bO\u000fKA'M";
      Z[78] = "l\u0002F] tq\u0017\u001eqa`u\u0006yRhz";
      Z[79] = "k\\\u0000j\u001e?vIXY_<nI";
      Z[80] = "/@Y9_P9@\\cLG.\u000b_e@S?LHr\u000bh";
      Z[81] = ">{2\u0002UxK[9\rD7*U2\u0006@m^";
      Z[82] = "\u0000m-m-C\u0000m:1!L\u001a&:/!Y\u001dWhty\u0013";
      Z[83] = "&>O\u0015\u007f\u0007S\u001eD\u001anH2\u0010O\u0011j\u0012F";
      Z[84] = "|\u0015%\f\f\u001b\t5.\u0003\u001dTh;%\b\u0019\u000e\u001c";
      Z[85] = "'\u0016\"\u0015m]R6)\u001a|\u001238\"\u0011xHG";
      Z[86] = "?sy\u0010%RJSr\u001f4\u001d+]y\u00140G_";
      Z[87] = "\u0010l*Qj:eL!^{u\u0004B*U\u007f/p";
      Z[88] = "<\rE\u0012`\rI-N\u001dqB(#E\u0016u\u0018\\";
      Z[89] = "x+\u007f33[\r\u000bt<\"\u0014l\u0005\u007f7&N\u0018";
      Z[90] = "\u0006/*b<&\u0010
      Z[91] = "\u0011,V\bmNd\f]\u0007|\u0001\u0005\u0002V\fx[q";
      Z[92] = "$D[}\u001dNQdPr\f\u00010j[y\b[D";
      Z[93] = "\u0011=]\u000f|zd\u001dV\u0000m5\u0005\u0013]\u000bioq";
      Z[94] = "\u0003\u0016l\u0006\u0002\u0001v6g\t\u0013N\u00178l\u0002\u0017\u0014c";
      Z[95] = "\u0010pQ_O\"\u0006pT\u0005\\5\u0011;W\u0003P!\u0000|@\u0014\u001b\"";
      Z[96] = ">\u0015GcN\u0002(\u0015B9]\u0015?^A?Q\u0001.\u0019V(\u001a\u0016\u000b";
      Z[97] = "7go5*g!gjo9p6,ii5d'k~~~s\u001b";
      Z[98] = "85\u0010\u0013e]M\u0015\u001b\u001ct\u0012,\u001b\u0010\u0017pHX";
      Z[99] = "j=b`|\u0012|=g:o\u0005kvd<c\u0011z1s+(\u0006D";
      Z[100] = ";}?'\r\u0007N]4(\u001cH/S?#\u0018\u0012[";
      Z[101] = "B?zF\u0018H7\u001fqI\t\u0007V\u0011zB\r]\"";
      Z[102] = "S\u0018&\u0017K\u0011E\u0018#MX\u0006RS KT\u0012C\u00147\\\u001f\u0005|";
      Z[103] = "l\u0011~%VW\u00191u*G\u0018x?~!CB\f";
      Z[104] = "d\\#S|o\u0011|(\\m pr#Wiz\u0004";
      Z[105] = "\rk>>PyxK51A6\u0019E>:Elm";
      Z[106] = "\u0007\u0019i>\\\n\u0007\u0019~bP\u0005\u001dR~|P\u0010\u001a#%!\u0005P";
      Z[107] = "?>)>\u0017?J\u001e\"1\u0006p+\u0010):\u0002*_";
      Z[108] = "~\u001dy02t~\u001dnl>{dVnr>nc';&g-";
      Z[109] = "V \u0017\t91V \u0000U5>Lk\u0000K5+K\u001aU\u001flh\u001c&\u000fF'+gs[\u001ff";
      Z[110] = "\u000eVnaU\u0007\u000eVy=Y\b\u0014\u001dy#Y\u001d\u0013l\"~\bY";
      Z[111] = "s($pPZs(3,\\Uic32\\@n\u0012ho\f\u0003";
      Z[112] = "yJ4\u0005`NyJ#YlAc\u0001#GlTdpv\u00185";
      Z[113] = "\u0019;\u0010'Vk\u0019;\u0007{Zd\u0003p\u0007eZq\u0004\u0001U;\u00025";
      Z[114] = "e\\2cple\\%?|c\u007f\u0017%!|vxfuy,1";
      Z[115] = "%$s\u0016\u0015\r%$dJ\u0019\u0002?odT\u0019\u00178\u001e4\fI]";
      Z[116] = "\u0013Q\u000e\u0019\n\u001d\u0005Q\u000bC\u0019\n\u0012\u001a\bE\u0015\u001e\u0003]\u001fR^\u000fN";
      Z[117] = "1>n}b<D\u001eerss%\u0010nyw)Q";
      Z[118] = "VFs(:\u001d]Ibg]\u0005YUd+x\u0014";
      Z[119] = "fq$\u000eZffq3RVi|:3LV|{Kh\u0010\u00047";
      Z[120] = "c\t]\u001a\u0012\u000ec\tJF\u001e\u0001yBJX\u001e\u0014~3\u001a\u0000NP";
      Z[121] = "p\u0012+-\u0018\u001bp\u0012<q\u0014\u0014jY<o\u0014\u0001m(m5CA";
      Z[122] = "ZH7\u0016\\jZH JPe@\u0003 TPpGrr\u0001\u00024";
      Z[123] = "^_\u000f\"\u00005H_\nx\u0013\"_\u0014\t~\u001f6NS\u001eiT'^";
      Z[124] = ".c\u0003bSJ[C\bmB\u0005:M\u0003fF_N";
      Z[125] = ">lU\f\u0011X>lBP\u001dW$'BN\u001dB#V\u0013\u0017E\u0007";
      Z[126] = byte.class;
      ab[126] = "java/lang/Byte";
      Z[127] = "\u0012@@t{,\u0019OQ;\u00075\u0016OWw9%";
      Z[128] = "\u0001&<@>Qt\u00067O/\u001e\u0015\b<D+Da";
      Z[129] = " =;\u0018\\N6=>BOY!v=DCM01*S\bX\u001c";
      Z[130] = "9*[\r<\u0011L\nP\u0002-^-\u0004[\t)\u0004Y";
      Z[131] = "lN'rm]\u0019n,}|\u0012x`'vxH\f";
      Z[132] = "\u0019\u0015Ji#%l5Af2j\r;Jm60y";
      Z[133] = "\u000fx[YY/\u0011pA\u0016\u0011/\u000bzYQ\u00184KI_]\u00133\u0006xY]";
      Z[134] = "WL}-PMALxwCZV\u0007{qONG@lf\u0004[d";
      Z[135] = "Ve\t\u0006z\u0013#E\u0002\tk\\BK\t\u0002o\u00066";
      Z[136] = "\b\u00197.\u0013+\u0016\u0011-ax0\u0017\u0015\u0012*I";
      Z[137] = "p9{^\u0002u{6j\u0011iwo5";
      Z[138] = "4'm6{`)2500n3hK8<o*t_";
      Z[139] = "0?y./owr4-\u0013:\r5avmk509-#-\r3?`-(iqbsxS";
      Z[140] = "7\u0003l4|w1_tun\u0007gc'-ey5[\"u>7scwy8e2\u0003yt9n\r";
      Z[141] = "R\u0002_6\rr\u0015\nIo\t\u001b\r\u0000W+||\u0016\u0007C:0v\u001b\t];\fp\u0014\u001dJW";
      Z[142] = "JJ\tT\u0002\u000fUA\u0004\u0002:\u0016XA\u000f\b\\\u0001yZ\u0010\b\u007f\u001cA_\u0014\u001e:\u001d@VD\u0003\u0000\u0016\u001bF\u000be";
      Z[143] = "JRCl`_\u0002ASny&\u001a,\u0014wtXK\u0014\u0011
      Z[144] = "')xhX\u0017!(,)Eivt' bP'-sX\tSo-9<K\u000e|xB";
      Z[145] = "\u0006\u0002\u0006(\u001eKV\\\u0002)cF\u0006\n\u000494\u0011XZ]U\u0001\u0014\u0017\u0005_>\tM\u001b\u0003";
      Z[146] = "\u0011v\u000bJKdV2K\u001dH\u000fF*X\u001f\u001cX\u0017t\u000b@p3\u00129\u000b\u0000\u0014qO*^";
      Z[147] = "kZE\u0004`\u0005c\\JPYX\u007f^EZ5j/\u001c\u001f\rY\u0001(P\u001bF=CuCN=";
      Z[148] = "%8\u000e.p\"12\u0010e\u000et\"?\u00068Y#{cRl\u000e|)>\u0018*6h# S";
      Z[149] = ">{35hG8z>9\u0006G\"bN6v[?qr0yO(\u001d#+bE)!%$vREp>?|Syv1+k?";
      Z[150] = "\u00030(d:}D)kr9\u001bS@,j?e\u0002x)2d+D@/~eq[&hg&gX@";
      Z[151] = "xh\\\u0010%`'/W\u000fO~\u007f}T\u0006\u0018)$!\u000e[Ovf|J\u0000?)!wU";
      Z[152] = "\u000f3t]\u0000D\t2yQnY\u00153\t^\u001eX\u000e95X\u0011L\u0019UdC\nF\u0018ibL\u001eQt8yW\u0014PH>vC\u0003<";
      Z[153] = "o\u0003\u0000f0Qa\u0011\u001bc\u000eA_I\u0005~p\u0017gL]%>Q_\u0019Q#l\u0010?\u0017\\\"g/";
      Z[154] = "\u0013NsTy\n\u0015O~X\u0017\t\u0011Rr:z\u0002\fRb\u0006|\r\u0018E\u000eWg\u0016\u0012D2Qh\u0002\u0005(";
      Z[155] = "\u0016>+ c\u0019Qsf#_L+43x!\u001d\u00131k#o[+dg%=\u001aKjj$6%";
      Z[156] = "bX\u0014\u0019Tl8\u001cN\u000bJ\u00163\u0002\u001b\u000ex/bYBvK}6\u001d\u0011\b^':\u0014~";
      Z[157] = "[\u00057'iTU\u0017,\"WHkO2?)\u0012SJjdgTkL6`4\u0012\u0004\u001f9?i*";
      Z[158] = "Q|Tg:\u0015Q-G'1j\u0005kV2n\u0011hjN=n\u0000\tsV%pj\u0002\"\u001295\n\f/\u00132\n";
      Z[159] = "\u0015\b\u001814M\u001b\u001a\u00034\nW%B\u001d)t\u000b\u001dGEr:M%A\u0019vi\u000bJ\u0012\u0016)43";
      Z[160] = "s\tkT,9/\u0002~KU)O\u001eoI5gt\r{O8";
      Z[161] = "DZx,LbYFr/\"rMF}-Y\u001fL^r-H~UFj3\"u\u0004\u0002vvB{\t\u0003}I";
      Z[162] = "mTR\ty eR]]@}yPRW,O*\u0014\t\n@|\u007fBJ_>i%NC0";
      Z[163] = "\u0016\u0014\u0000~zyUD\u0006jF)d\u001f\u0000d8}\\\u001aX?v;dOT9$z\u0004AY8/E";
      Z[164] = "|\u0013E!?&;\u001bSx;O#\u0011M<C)9|\u0001zpq>\u0018C'c$E@\u00072<4!\u0002Z!iO";
      Z[165] = "0\u0014p\"Y\u00145\u0006u\u007f\u0006mo\u00121$\u0005\u0001]Ftx\\\\\nE&5\f\f0\u0004*$\u0003\u0013\nEs'R\u000bfF,\"\f\u000f\n";
      Z[166] = "X8u%\u0018CZ=72\u0007?\u000f9f(\u0012h^h4v~\u0003[*57\u001aA\u00069`";
      Z[167] = "\n+&[m.\nz5\u001bfQBEe]/oH!'\u0000<:";
      Z[168] = "f9\u0017\u0013\u001f'eiQ\u0003\nD05U*\u0004%9$D\b\"\"1?)K\r{2>\u0014\u001e\u001d{b()";
      Z[169] = "\u001f?\u000eT\f!\\jZ]\fLKb\\\tX\u001b\u001e=\rQ\nL\u001f?\u000eT\f!\\jZ]\f";
      Z[170] = "p\u000f\u0012m\u001b>r\nPz\u0004B'\u000e\u0001`\u0011\u0015v_S8}~s\u001dR\u007f\u0019<.\u000e\u0007";
      Z[171] = "\u007f dMMyq2\u007fHsbOjaU\r?wo9\u000eCyOie\n\u0010? :jUM\u0007";
      Z[172] = "*CD0S\f$Q_5m\u001c\u001a\nEw\u000eJuYJ(Sr";
      Z[173] = "nY\u0016d\u0002:tE\u001bjim\u0005\u001c\u0016b\u0017<=\u0019N9Yz\u0005M\rb\u000bo;W\u0011o\u0005\u0004";
      Z[174] = "\u0013w\u0002~r\tVy\u001cnbmOq\u0004{q(Mh\u0014\u0000 WX(\u0002db\nK}y<&\u001f\u0014m\u001d~{\fA\u0016@`'\u000e\u0012y\u0013oxS*";
      Z[175] = "4<W \u000b\u0004wi\u0003)\u000bicy\u0015pW\u0012\u000ex\r\u007fW\u0003oa\u0015gIid0Q{\f\tj=Pp3";
      Z[176] = "&nkHgN.hd\u001c^\u00132jk\u00162!a/2L^\u001co/iN>\u0012b.bq";
      Z[177] = "\u0014\u0000'*\r\u001e\u001bT\u007fui\rzT{~\u0017[BQ#%Y\u001dz\u0004/#\u000b\\\u001a\n\"\"\u0000c";
      Z[178] = ")rt\t\u0010!y,p\bm/8zy\t\u0011/H-}\u0014\r\")v+\u0016\r9H.rO\u000ez'}}\u0010SB";
      Z[179] = "8 &=zo;6}'\u001c?31r:Khkd-m\u001c;.l}0\"887g";
      Z[180] = "^\u0012,3,W\u000eI#oA[\u001c\u0019hf=]\u001atvt?\u0005[O,i=\u0006`";
      Z[181] = "\u0012{\u00027;mQ|\u0016$z\\Nr\u0015>$0| Xfr\\\u0012$\u0007<<-P\"\u0004o:\\";
      Z[182] = "\u001aN\u0005\u0014:\u0013\u0015\u001a]K^\u0007t\u001aY@ VL\u001f\u0001\u001bn\u0010t\u001aR[;\fECPM n";
      Z[183] = "\n:\u000f?L1\u0005nW`(%dnSkVt\\k\u000b0\u00182dmW4Kt\u000b>Xk\u0016L";
      Z[184] = "l:2E\u0017\u001dlk!\u0005\u001cb%TqCU\\.03\u001eF\t";
      Z[185] = "Ny0T1OGrr\u0006,>\u001e\u00101\r'@O(4U|\u000e\t\u0010s\f%Z\u001dqj\u0014=Dw";
      Z[186] = "x=\u0006\u0010i[x8\u000f\u0010\u000fK`\u001a\u00170\u000fNp2\u0006\u0019q[*>\u000fve\u001a\">A\u0016k\u0017#5~";
      Z[187] = "|7-q\u0015?#55!{h~36#\u0012dG=63\u0016\u0002sdk,Db}ij'{";
      Z[188] = "aL?},l)Df(O?[\u0001bcq/?C?p$T";
      Z[189] = "\u000bj#|\u0012=Sf.=n'4<)'\u0010u\f9q|^34l}z\frTbp{\u0007M";
      Z[190] = ")\u001b.`X\u0004\u007fFi'H4vMh<QXD\u001c,f\r\r\u0013\u001a(c\u000f\f~Y}7\u0006\f\u0013";
      Z[191] = "Y\r4\r[L\tS0\f&AY\u00056\u001cq\u0016\u0007Rnp_WXQkHWQW\u0005";
      Z[192] = "jh?#M2dz$&s&Z\":;\rtb'b`C2Z\"1 \u0016.k{36\rL";
      Z[193] = "{4V\u0007\u0010v#)HK\u000fN'4EW\r\"\u0015e\u0005\bUN~cK\t\u0011*<>X\\j";
      Z[194] = "6\u000e\u0005Ss\u0003l\u0013\u0007PHX;\u000e=\u00018DR\u001fKU*\u00072\u0011FT!8";
      Z[195] = "\u0005`CZo\u000f\\bUA\r_DBYGqO?e\f\u0006o\u0001_k\u0001\u0007d>";
      Z[196] = "1D\fgcH:Z\u0012q{ua'D|~\u000b3\u001fA$%Eu'Dxk\bvWB$sId'";
      Z[197] = "~F+\u001ajl>\u0001k]\u0013;\u0003\u00051\u0000mj;\u0000i[#,\u0003\u00065_pjlU:\u0000-R";
      Z[198] = "%8Z\u001d|\u000bb0LDxbz:R\u0000\u000e\u000ba,Y\u001d(\u0004\u001c:R\u0018;\u000e <]\f,b";
      Z[199] = "se1\u000fGB4(|\f{\u0015No)W\u0005Fvjq\fK\u0000Nl1B\u001a\u0005)h=\f\u0015\u000fN";
      Z[200] = "Tb\bGjT\u000e&RUt.\u00058\u0007PF\u0017TcX(aO\u0002:\fU|S\b9b";
      Z[201] = "\rrnq~C\u000b.v0l3^\u0012%hgM\u000f* 0<\u0003I\u0012u<:Q\br{1;Z7";
      Z[202] = "}\u007f u8juy/!\u00017i{ +m\u000598xs\u0001\"<\u007f:)g2};~Ll\"`},pj-tj@";
      Z[203] = "l \u001f\u001e\fkb2\u0004\u001b2v\\j\u001a\u0006L-doB]\u0002k\\i\u001eYQ-3:\u0011\u0006\f\u0015";
      Z[204] = "w.\bh7Hq/\u0005dYUe8ub2^t'\u000bwhR}H\u0011m7Hc6\u00047;A\f,\u001eh!_r9Dd(0";
      Z[205] = "M-vGJYC?mBtK}gs_\n\u001fEb+\u0004DY}7'\u0002\u0016\u0018\u001d9*\u0003\u001d'";
      Z[206] = "\\\u0015\u0001\b \u0012R\u0007\u001a\r\u001e\fl_\u0004\u0010`TTZ\\K.\u0012l\u000fPM|S\f\u0001]Lwl";
      Z[207] = "U8 KC\u0015Zlx\u0014'\f;l|\u001fYP\u0003i$D\u0017\u0016;<(BEW[2%CNh";
      Z[208] = ")u\\<~ms$Wg%\f~.\u0000cv[ u]7\u001a5+!\u000fxkw-\"\\~";
      Z[209] = "\u000bb4}hUWm8#\t\f\u000b 3 e>\\gh~9i\u000b,7=eU\r##*\t";
      Z[210] = "n6c\u0016\u001ex>hg\u0017c~b/e\f\u000fL6n=Tcy3#gT\bqj/akZ{40=\u0004\ttkm\u0005";
      Z[211] = "P{/:G:\u0002)wxE\u0002\bl$2E~\u000ejI,W|V+rvJ~U\u0010";
      Z[212] = "\\\u0010\u0004\u0017rn\u001b\u0018\u0012Nv\u0007\u0003\u0012\f\n\u0005`\u0002\u001b\u0011\u001f)\u0007\u000fOE\u0014pg\u0001BD\u001fO";
      Z[213] = "ZvAEY\u007f\u0003tW^;'\fu>X^(\u0004s_AF0\u001a\u0019T\u0010\u0002,_yZ\u001d\u0003'`";
      Z[214] = "\u0015(\u0019\u000eH\u001fL*\u000f\u0015*UN5\u000bk\u0016\u0014]y\u001d\u000fTIN,f";
      Z[215] = "\r\u0006juE\u0017]]e)(\u0011W\r=3(CS[7qG\u0010\\\u0004jI";
      Z[216] = "f+i%+q:$e{J(finx&\u001a1.5&uMfeje&q`j~rJ";
      Z[217] = "x f'[k\"qm|\u0000\n/{:xS]q j!?3zt5cNq|wfe";
      Z[218] = "]\u007f)R$u]z RBjZy8H\u001cmZc<4&oPf>J35\\oQ";
      Z[219] = " P3o9*(V<;\u0000w4T31lEg\u0010mi\u0000v2F+9~chJ\"V";
      Z[220] = ",!@t_^(<I\u0004J5#:\\|NK6`Pu!";
      Z[221] = "\u0002\b\u000bhF0\u0000\rI\u007fYLU\t\u0018eL\u001b\u0004XJ: p\u0001\u001aKzD2\\\t\u001e";
      Z[222] = "\u0010x_z@[\u0012}\u001dm_'Lu]sAK~'\u001f,\u0019'\u0010|Jz^\u0016S{^i\u001f'";
      Z[223] = "\rjax.B\u0003xz}\u0010U=sk4i\u0001\u0002#8fq<Tq0}-\u0003\u0004\"be\u0010";
      Z[224] = "\u0000g:e\u0019pG*wf% =m\"=[t\u0005hzf\u00152=n:(D7Zj6fK==";
      Z[225] = "B\bo%zQ\u000bX2&3n\u001eYs|d\u0002,\r0!<Q{\r2\"2U\u0010JvbeV{";
      Z[226] = "m\u0016Q'\\Lc\u0004J\"bT]\\T?\u001c\neY\fdRL]_P`\u0001\n2\f_?\\2";
      Z[227] = "J\u0017]\u001d\u0018&N\nTm\fM\u001b\u0003K\u0013^u\u001e[\u0010]\u0018M\u0018\u0007\u0014\u000e^\"K\bKSf";
      Z[228] = "5a_nT\u0012;sDkj\r\u0005+Zv\u0014T=.\u0002-Z\u0012\u0005{\u000e+\bSeu\u0003*\u0003l";
      Z[229] = "n\u0001\u000bD{>)EK\u0013xU9]X\u0011,\u0002h\u0003\u000bL@l<ZG\u001ex>n\u0002\u0005\u001c";
      Z[230] = "\\7W\u0014n?\u0001*HHh\u0006\u00006KI3j2b\b\u0014k9eb\n\u0017e=\u000e%NW2>e";
      Z[231] = "K\u0014rTGZM\u0015\u007fX)GY\u0002\u000fWYFJ\u001e3QVR]rbJMX\\NdEYO0\u001f\u007f^SN\f\u0019pJD\"";
      Z[232] = "U\u0004\u000e\"0RQ\u0019\u0007R%9\u0004\u0010\u0018,v\u0001\u0001HCb09\u0007\u0014G1vVT\u001b\u0018lN";
      Z[233] = "7N\u000ep7\u00001O\u0003|Y\u001d-Nsz2\u00164G\roh\u001a=(\u0017u7\u0000#V\u0002/;\tLL\u0018p!\u00172YB|(x";
      Z[234] = "<.qk\u0004[e,gpf\u000bz,tg\u001a\r|Aju\u0018U=z0h\u001aV\u0006";
      Z[235] = "N4+\u0013@3\u001ej/\u0012=5B--\tQ\u0007\u0016ls_=:\u001fh/Q]4\u0012i$n";
      Z[236] = "<&wym\u001elxsx\u0010\u00180?qc|*d~/>\u0010Dc{p; \u00044?r~\u0010";
      Z[237] = "\bhM2T5\u00124F5/%\u0017/)?K9\u001cSKl]z\n7\t1N/q";
      Z[238] = "9S|\f\n\u0011cN~\u000f1L0X~3IO;LhRPW#R\u0002";
      Z[239] = "\u0007)#T\u007fk\u0001(.X\u0011x\u001b4^Waw\u0006#bQnc\u0011O3Jui\u0010s5Ea~|";
      Z[240] = "\u000e!\u0005AfP^\u007f\u0001@\u001bV\u00028\u0003[wdU~]\f 3V)\f\fa\u000b\u000e4\u0012@~3";
      Z[241] = "\u0014%a/E\u0004A5a\u007fS9B&\"\u0006DRD7?%E9\u0014%!~\u0013F\u0014t2>\u00189";
      Z[242] = "O\u000b\u0019OI\t\u0016UA\tFx\u001bV\u0010RC/I\rG\t\u0012xO\u000b\u0019OI\t\u0016UA\tF";
      Z[243] = "b\bc_]pl\u001axZcgRBfG\u001d6jG>\u001cSpR\u00122\u001a\u000112\u001c?\u001b\n\u000e";
      Z[244] = "\u000b]:`u,R_,{\u0017vU_,\u007f\u0017$Q\t&=xw^V{\u0005";
      Z[245] = "2mn\"\u000bn=96}ov\\92v\u0011+d<j-_m\\if+\r,<gk*\u0006\u0013";
      Z[246] = "'.\b'm_{%\u001d8\u0014L\u001bxV)(\r'?\u001bd+";
      Z[247] = "L\u0007IfC3CS\u00119''\"S\u00152Yv\u001aVMi\u00170\"\u0010JlC5S\n\u0016gDN";
      Z[248] = "\u0005R\u001a \u0002\u0003S\u000f]g\u00123T\u000eEd;\b\u0003X d\tU[\u0003A}\u0011MEi";
      Z[249] = "Jp p0dJ<=u:Y\u001d/++l\u000eLqxt\u0000eI<x4d'\u0014/-";
      Z[250] = "r+\u00115?^+)\u0007.]\u0000%8nlg\u001dv?\n.:\u000e#D\u00165;\u000b\"%\u000f-#\u0015H";
      Z[251] = "PT\u0016b^M\u0000\n\u0012c#@P\\\u0014st\u0017\u000f\u0001O\u001f\u0019\u0010\u000b\u000f\n}GOZ\\\u0001";
      Z[252] = "\u0013^}y=`I\u001a'k#\u001aB\u0004rn\u0011#\u0013_*\u0016|&M\u001aqg%x\u0015\\~\u0016";
      Z[253] = "#Ja5\u0016\u0014s\u0011ni{\u0003pI8w\u00168s,ej\u001c\u001feA8{\u0000\u0018},59B\u001b\"L;4C\u0010\u001d";
      Z[254] = "Zd\u001djXS\u0002y\u0003&Gk\u0006d\u000e:E\u000745Nk\u001fk_3\u0000dY\u000f\u001dn\u00131\"";
      Z[255] = "5\u0002\u0015hrU;\u0010\u000emLF\u0005H\u0010p2\u0013=MH+|U\u0005\u0018D-.\u0014e\u0016I,%+";
      Z[256] = "/\tV\u0002&u+\u0014_r6\u001e~\u001d@\f`&{E\u001bB&\u001e \u0012J\n7`5HF\u0003X";
      Z[257] = "@\tS0^_@X@pU \u0015\u0006Wp\u0007F\u0012\n,6\t\u001c\bVVwT@\u0013W,a\u001eD\u0003\u000b\u0010g\u0011P\u0014g";
      Z[258] = "\u0000A\u0005d\u0016\u0002P\u001a\n8{\u0006RK\u007f1\u0000\u0013>_^>\u001f\u0005_FF&\u0001o\u0007G\u0000;C\u0000TH_f{";
      Z[259] = "41\u0016\t;h3=\u0013\u0005'P``\u0017\u0001&\u00077<@XtP41\u0016\t;h3=\u0013\u0005'";
      Z[260] = "\f['[[l\tI\"\u0006\u0004\u0015S]f]\u0007ya\t#\u0001_-6\ntV\u0001+OQ \u0004\u0002s6";
      Z[261] = "\u0011E\rJ\u001b\u0013LQ\u000fGE)LNu\u0012L@\u0014\u001c\u0013\u0010Z\u0017K^u\u0012L@\u0014\u001c\u0013\u0010Z\u0017K^u\u0012L@\u0014\u001c\u0013\u0010Z\u0017K^u\u0012OQI\u0011OO[SDOu";
      Z[262] = "8\u0013X?t\"p\u001b\u0001j\u0017p\u0002^\u0005!)af\u001cX2|\u001a";
      Z[263] = "E\u000f;KG\u0007_\u00136E,P.J;MR\u0001\u0016Oc\u0016\u001cG.\u001ao\u0010N\u0006N\u0014b\u0011E9";
      Z[264] = "t\u0004\r>o<+\u0006\u0015n\u0001\u007fx\u0003\u000flFo\u0011\rB8c>q\u0003O9h\u0001t\u0004\r>o<+\u0006\u0015n\u0001";
      Z[265] = "\u0004\u0013~hE)P\f|jEETp~q@;\u0005H{)\u001buCp}uZ,[\f\u007fp\u0018;Dp";
      Z[266] = "M&(+LxK'%'\"{W&U(RdL,i.]p[@85FzZ|>:Rm6";
      Z[267] = "(rpQ_~t}|\u000f>'(0w\fR\u0015\u007fw,Q\u0007B(<s\u0011R~.3g\u0006>";
      Z[268] = "cV0[J9mD+^t(S\u001c5C\n\u007fk\u0019m\u0018D9SLa\u001e\u0016x3Bl\u001f\u001dG";
      Z[269] = "\u001d\u0002tMHS\u001b\u0003 \fU-L_+\u0005r\u0014\u001d\u0006q}\u0019\u0017U\u00065\u0019[JFSN";
      Z[270] = "XI47H9QBveUH\n 5n^6Y\u001806\u0005x\u001f 6j\u0001+YOee^va";
      Z[271] = "BHW,&jFU^\\1\u0001\u0013\\A\"`9\u0016\u0004\u001al&\u0001BHW,&jFU^\\";
      Z[272] = "\u0015\r\u0005-\u000f:\u0010\u001c\u0004-7+r\u001b\u001f S(\u0013\u0002\u00078MB";
      Z[273] = "\u0007\u001b5IB\u000f\u000f\u001d:\u001d{R\u0013\u001f5\u0017\u0017`C\\nA{\r@\u0000e\u0016\u0017\u000e\u001f\u0005;\u0012{S\u0015\r-\u001f\u0005FO\u0001$p";
      Z[274] = "-hsr\fVud~3pO\u0012>y)\u000e\u001e*;!r@X\u0012=}v\u0013\u001e}nr)N&";
      Z[275] = "J\u000byW #E_!\bD7$_%\u0003:f\u001cZ}Xt $Y{\u0015z%@\u001b&\u0006/^";
      Z[276] = "\u0002.H/o\u0005\n(G{VX\u0016*Hq:jAm\u0013/f=\u0016&Ll:\u0001\u0010)X{V";
      Z[277] = "bH-\"p\u000b;\u0016ud\u007fz5\r42r\u0001X\f,=r\u00109\u00154%lz2Dp9)\u001a<Iq2\u0016";
      Z[278] = "83]-\u0019c+'[ )1DcV)W`|f\u000er\u0019&D`RvJ`+3])\u0017X";
      Z[279] = "\u000e-d;O`Pr5hD\u0002Q~\"eRnc/e<\u000f34)`f\u0005dX*?c[`4)`f\u0005dX*?c[`4)a;\fkSx0x\u000e:4)niYs\f.blUo4w5kMmJbogD\u0002Px0}Z|E\"<t5;T(==Zh[w`\u0005";
      Z[280] = "@F\u0006'k&FGRfvX\u0011\u001bYoQa@B\f\u0017<c@@R'j>\u0007\u0007B\u0017";
      Z[281] = "~hP.v}&uNbiE\"hC~k)\u00109\u0003/=E{?M w!9b^u\f";
      Z[282] = "wSD\\[\u0001/_I\u001d'\u0018H\u0005N\u0007YIp\u0000\u0016\\\u0017\u000fHU\u001aZEN([\u0017[Nq";
      Z[283] = "In`aL4\f0dkLK\b^ uU5Kf%-\u000e{\r^#q\n(K1p~Uus";
      Z[284] = "\u001a`\u001e_O`\u0014r\u0005Zqt**\u001bG\u000f&\u0012/C\u001cA`*t\u0014M\tqTaNA\u0000\u001e";
      Z[285] = "\u0018*&<\u0005=\u001c-#`HYC?!y\u001d%E9Lg\u000f'\u001dxw=\u0012%\u001eC";
      Z[286] = "4;#>I/=0alT^dR\"g_ 5j'?\u0004nsR!j\u0000c\u007f#(aB1bR";
      Z[287] = "\u0000(_=F5Gr\u0007=\u001cK_/\u0019%@'m~U~\u001dw:x\f/\u0018:^|\u000b*Dw:";
      Z[288] = "*oK.\u0017\u000bqnL|\fwzW\bz\u0010\t+o\r\"KGmW_ \u0013Mrk\u0003/\u001f\u0013\u0013";
      Z[289] = "#pL4w3%,TueCp\u0010\u0007-n=!(\u0002u5sg\u0010Y\"d;vnLxh2\u0019";
      Z[290] = "KX=v\fTMY0zbELW&\"bA@Z:t^GON-\u0018\u000f\\TD,$\tS@S@u\u0012HJR|s\u001d\\]>";
      Z[291] = "t&\u0011D/k1v\nZmV -\u001eR~\u0001wpL\u0006/VtsM\u000f{1%\"\u000e\r*";
      Z[292] = "$gm7\u0005gph0x\u0016\u0001t\u001a`xRc\"znuSh\u001d";
      Z[293] = "\u0017Jn<\u0014#J\u00074?PAG8m?\t?\u0016\u0000hgRqP8n)T&WZ3d\u000e%\u00138";
      Z[294] = "a\u0017B).\u001dhPXy$y1n\u001cw#\u0007`V\u0019/xI&n\u001a)5G#\nXt&\u0012X";
      Z[295] = "\u0001@C\u001ct\u0010ZTM['.R,HF/P\u0003\u0014M\u001et\u001eE,HLpG\u0000]\n\u001epS\u0004,";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = Z[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(ab[var4]);
            Z[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = Z[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = ab[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            Z[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  Z[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2602912119118551L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = Z[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = ab[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  Z[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2602912119118551L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        Z[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2602912119118551L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 186;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 68;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 109;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 106;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 213;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 242;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 186;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 68;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 109;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/em_C0242",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/em" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(AutoTotem var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$2", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(AutoTotem var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$8", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(AutoTotem var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$10", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(AutoTotem var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$12", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(AutoTotem var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$1", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(AutoTotem var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$4", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(AutoTotem var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$6", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(AutoTotem var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$9", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(AutoTotem var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$3", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10(AutoTotem var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$5", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding11(AutoTotem var0) {
         MethodHandle var5 = bindingCache11;
         MethodHandle var4 = bindingCache11;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding12(AutoTotem var0) {
         MethodHandle var5 = bindingCache12;
         MethodHandle var4 = bindingCache12;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache12 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$11", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding13(AutoTotem var0) {
         MethodHandle var5 = bindingCache13;
         MethodHandle var4 = bindingCache13;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache13 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding14(AutoTotem var0, long var1, AutoTotemState var3, int var4) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;JLdev/zprestige/prestige/e_C0216;I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "lambda$requestSmpInventorySwap$13", "(JLdev/zprestige/prestige/e_C0216;I)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var6.invokeExact((AutoTotem)var0, (long)var1, (AutoTotemState)var3, (int)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Predicate invokeBinding15(long var0) {
         MethodHandle var6 = bindingCache15;
         MethodHandle var5 = bindingCache15;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache15 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(J)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/em_C0242", "lambda$computeDangerScore$14", "(JLdev/zprestige/prestige/aj_C0022;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/aj_C0022;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var3.invokeExact((long)var0);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Runnable invokeBinding16(AutoTotem var0) {
         MethodHandle var5 = bindingCache16;
         MethodHandle var4 = bindingCache16;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache16 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/em_C0242;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/em_C0242", "f", "()V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((AutoTotem)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
