package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.management.TimedPacket;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.runtime.SwitchBootstraps;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPosition;
import net.minecraft.entity.TrackedPosition;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPositionS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPositionSyncS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.GameStateChangeS2CPacket;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class Backtrack extends Module {
   private MinMaxSetting a;
   private MinMaxSetting c;
   private BooleanSetting d;
   private ConcurrentLinkedQueue e;
   private TrackedPosition f;
   private ElapsedTimer g;
   private Vec3d h;
   private Vec3d i;
   private Entity j;
   private float k;
   private static final long l = 14146175880597L;
   private static final long m;
   private static final long[] n;
   private static final Long[] o;
   private static final Map p;
   private static final Object[] q = new Object[129];
   private static final String[] r = new String[129];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public Backtrack() {
      super();
      long var10001 = 36733866500238L ^ 70791173265319L;

      this.e = new ConcurrentLinkedQueue();
      this.g = new ElapsedTimer(106698256430889L);
      this.h = new Vec3d(0.0, 0.0, 0.0);
      this.i = new Vec3d(0.0, 0.0, 0.0);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 18677768017176L ^ 49903245663297L;
      var10001 = 18677768017176L ^ 70499199636136L;
      var10001 = 18677768017176L ^ 59414784458008L;
      var10001 = 18677768017176L ^ 61289211472587L;
      var10001 = 18677768017176L ^ 28376146225522L;
      var10001 = 18677768017176L ^ 78732454091244L;
      int var16 = Event.bReturningInt();
      int var172 = var16;
      MinecraftClient var171 = b;
      MinecraftClient var125 = var171;
      MinecraftClient var124 = var171;
      if (var172 == 0) {
         MinecraftClient var28 = var124;
         ClientWorld var173 = var28.world;
         if (var173 == null) {
            return;
         }

         MinecraftClient var174 = b;
         var125 = var174;
      }

      MinecraftClient var31 = var125;
      int var176 = var16;
      ClientPlayerEntity var175 = var31.player;
      ClientPlayerEntity var127 = var175;
      ClientPlayerEntity var126 = var175;
      if (var176 == 0) {
         ClientPlayerEntity var177 = var126;
         if (var177 == null) {
            return;
         }

         MinecraftClient var33 = b;
         var127 = var33.player;
      }

      ClientPlayerEntity var34 = var127;
      int var179 = (int)m;
      int var178 = var34.age;
      if (var178 < var179) {
         Object[] var281 = new Object[]{null, 67756338792793L};
         var281[0] = true;
         Object[] var36 = var281;
         Backtrack var35 = this;
         var35.kReturningVoid(var36);
      } else {
         Object[] var39 = new Object[0];
         PacketReceiveEvent var38 = var1;
         Packet var17 = var38.aReturningVoid(var39);
         int var180 = var16;
         if (var180 == 0) {
            boolean var181 = var17 instanceof PlayerPositionLookS2CPacket;
            label215:
            if (!var181) {
               int var10000 = (((var17 instanceof PlayerRespawnS2CPacket) ? 1 : 0));
               int var183 = var16;
               boolean var182 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
               boolean var130 = var182;
               boolean var128 = var182;
               if (var183 == 0) {
                  boolean var184 = var128;
                  boolean var129 = var184;
                  boolean var185 = var129;
                  if (var185) {
                     break label215;
                  }

                  boolean var186 = var17 instanceof GameStateChangeS2CPacket;
                  var130 = var186;
               }

               int var188 = var16;
               boolean var187 = var130;
               boolean var132 = var187;
               boolean var131 = var187;
               if (var188 == 0) {
                  boolean var189 = var131;
                  if (var189) {
                     break label215;
                  }

                  boolean var190 = var17 instanceof DisconnectS2CPacket;
                  var132 = var190;
               }

               int var192 = var16;
               boolean var191 = var132;
               boolean var134 = var191;
               boolean var133 = var191;
               if (var192 == 0) {
                  boolean var193 = var133;
                  if (var193) {
                     break label215;
                  }

                  Object[] var52 = new Object[]{var17, 96102347902196L};
                  var134 = eReturningBoolean(var52);
               }

               Backtrack var138;
               label234: {
                  int var195 = var16;
                  boolean var194 = var134;
                  boolean var137 = var194;
                  boolean var135 = var194;
                  if (var195 == 0) {
                     boolean var196 = var135;
                     if (var196) {
                        return;
                     }

                     int var198 = var16;
                     Backtrack var197 = this;
                     var138 = var197;
                     Backtrack var136 = var197;
                     if (var198 != 0) {
                        break label234;
                     }

                     Object[] var55 = new Object[]{10110749899882L};
                     Backtrack var54 = var136;
                     boolean var199 = var54.dReturningBoolean(var55);
                     var137 = var199;
                  }

                  boolean var200 = var137;
                  if (!var200) {
                     return;
                  }

                  var138 = this;
               }

               int var202 = var16;
               Backtrack var201 = var138;
               Backtrack var169 = var201;
               Backtrack var139 = var201;
               if (var202 == 0) {
                  Entity var203 = var139.j;
                  if (var203 != null) {
                     Entity var58 = this.j;
                     var10000 = (((var58.isAlive()) ? 1 : 0));
                     int var205 = var16;
                     boolean var204 = ((((int)(var10000) & 1) != 0));
                     boolean var140 = var204;
                     if (var205 != 0) {
                        return;
                     }

                     boolean var206 = var140;
                     boolean var141 = var206;
                     boolean var207 = var141;
                     if (var207) {
                        int var147;
                        label184: {
                           label237: {
                              var10000 = (((var17 instanceof EntityPositionS2CPacket) ? 1 : 0));
                              int var209 = var16;
                              byte var208 = ((byte)(var10000));
                              int var144 = var208;
                              byte var142 = var208;
                              if (var209 == 0) {
                                 byte var210 = var142;
                                 byte var143 = var210;
                                 byte var211 = var143;
                                 if (var211 == 0) {
                                    break label237;
                                 }

                                 EntityPositionS2CPacket var63 = (EntityPositionS2CPacket)var17;
                                 int var212 = var63.entityId();
                                 var144 = var212;
                              }

                              int var214 = var16;
                              int var213 = var144;
                              int var146 = var213;
                              int var145 = var213;
                              if (var214 != 0) {
                                 int var218 = var146;
                                 var147 = var218;
                                 break label184;
                              }

                              Entity var65 = this.j;
                              int var216 = var65.getId();
                              int var215 = var145;
                              if (var215 == var216) {
                                 byte var217 = 1;
                                 var147 = var217;
                                 break label184;
                              }
                           }

                           var147 = 0;
                        }

                        int var18;
                        int var152;
                        label173: {
                           label238: {
                              var18 = var147;
                              var10000 = (((var17 instanceof EntityPositionSyncS2CPacket) ? 1 : 0));
                              int var220 = var16;
                              byte var219 = ((byte)(var10000));
                              int var149 = var219;
                              byte var148 = var219;
                              if (var220 == 0) {
                                 byte var221 = var148;
                                 if (var221 == 0) {
                                    break label238;
                                 }

                                 EntityPositionSyncS2CPacket var69 = (EntityPositionSyncS2CPacket)var17;
                                 int var222 = var69.id();
                                 var149 = var222;
                              }

                              int var224 = var16;
                              int var223 = var149;
                              int var151 = var223;
                              int var150 = var223;
                              if (var224 != 0) {
                                 int var228 = var151;
                                 var152 = var228;
                                 break label173;
                              }

                              Entity var71 = this.j;
                              int var226 = var71.getId();
                              int var225 = var150;
                              if (var225 == var226) {
                                 byte var227 = 1;
                                 var152 = var227;
                                 break label173;
                              }
                           }

                           var152 = 0;
                        }

                        int var19;
                        byte var155;
                        label162: {
                           label161: {
                              var19 = var152;
                              int var230 = var16;
                              Packet var229 = var17;
                              Packet var154 = var229;
                              Packet var153 = var229;
                              if (var230 == 0) {
                                 boolean var231 = var153 instanceof EntityS2CPacket;
                                 if (!var231) {
                                    break label161;
                                 }

                                 Packet var232 = var17;
                                 var154 = var232;
                              }

                              EntityS2CPacket var266 = (EntityS2CPacket)var154;
                              MinecraftClient var76 = b;
                              ClientWorld var78 = var76.world;
                              EntityS2CPacket var77 = var266;
                              Entity var267 = var77.getEntity((World)var78);
                              Entity var234 = this.j;
                              Entity var233 = var267;
                              if (var233 == var234) {
                                 byte var235 = 1;
                                 var155 = var235;
                                 break label162;
                              }
                           }

                           var155 = 0;
                        }

                        int var162;
                        label153: {
                           int var161;
                           byte var20 = var155;
                           int var237 = var16;
                           byte var236 = var20;
                           var161 = var236;
                           byte var156 = var236;
                           label152:
                           if (var237 == 0) {
                              byte var238 = var156;
                              if (var238 == 0) {
                                 int var240 = var16;
                                 int var239 = var18;
                                 var161 = var239;
                                 int var157 = var239;
                                 if (var240 != 0) {
                                    break label152;
                                 }

                                 int var241 = var157;
                                 int var158 = var241;
                                 int var242 = var158;
                                 if (var242 == 0) {
                                    int var244 = var16;
                                    int var243 = var19;
                                    var161 = var243;
                                    int var159 = var243;
                                    if (var244 != 0) {
                                       break label152;
                                    }

                                    int var245 = var159;
                                    int var160 = var245;
                                    int var246 = var160;
                                    if (var246 == 0) {
                                       var162 = 0;
                                       break label153;
                                    }
                                 }
                              }

                              var161 = 1;
                           }

                           int var247 = var161;
                           var162 = var247;
                        }

                        int var21 = var162;
                        int var249 = var16;
                        int var248 = var21;
                        int var163 = var248;
                        if (var249 != 0) {
                           return;
                        }

                        int var250 = var163;
                        if (var250 != 0) {
                           Vec3d var22 = new Vec3d(0.0, 0.0, 0.0);
                           Packet var23 = var17;
                           var10000 = invokeBinding1(var23, 0);
                           int var252 = var16;
                           int var251 = var10000;
                           int var165 = var251;
                           int var164 = var251;
                           if (var252 == 0) {
                              int var253 = var164;
                              switch (var253) {
                                 case 0:
                                    EntityS2CPacket var25 = (EntityS2CPacket)var23;
                                    TrackedPosition var269 = this.f;
                                    EntityS2CPacket var88 = var25;
                                    var10001 = var88.getDeltaX();
                                    EntityS2CPacket var89 = var25;
                                    long var10002 = var89.getDeltaY();
                                    EntityS2CPacket var90 = var25;
                                    long var96 = var90.getDeltaZ();
                                    long var94 = var10002;
                                    long var92 = var10001;
                                    TrackedPosition var91 = var269;
                                    var22 = var91.withDelta(var92, var94, var96);
                                    int var254 = var16;
                                    if (var254 == 0) {
                                       break;
                                    }
                                 case 1:
                                    EntityPositionS2CPacket var26 = (EntityPositionS2CPacket)var23;
                                    EntityPositionS2CPacket var98 = var26;
                                    EntityPosition var99 = var98.change();
                                    Vec3d var27 = var99.position();
                                    Vec3d var100 = var27;
                                    double var279 = var100.getX();
                                    Vec3d var101 = var27;
                                    double var10003 = var101.getY();
                                    Vec3d var102 = var27;
                                    var22 = new Vec3d(var279, var10003, var102.getZ());
                                    int var255 = var16;
                                    if (var255 == 0) {
                                       break;
                                    }
                                 case 2:
                                    EntityPositionSyncS2CPacket var262 = (EntityPositionSyncS2CPacket)var23;
                                    EntityPositionSyncS2CPacket var103 = var262;
                                    EntityPosition var104 = var103.values();
                                    var22 = var104.position();
                              }

                              Vec3d var106 = new Vec3d(0.0, 0.0, 0.0);
                              Vec3d var105 = var22;
                              var165 = (((var105.equals(var106)) ? 1 : 0));
                           }

                           int var257 = var16;
                           int var256 = var165;
                           int var167 = var256;
                           int var166 = var256;
                           if (var257 == 0) {
                              int var258 = var166;
                              if (var258 != 0) {
                                 return;
                              }

                              Vec3d var109 = var22;
                              TrackedPosition var108 = this.f;
                              var108.setPos(var109);
                              this.h = var22;
                              MinecraftClient var110 = b;
                              Entity var112 = this.j;
                              ClientPlayerEntity var111 = var110.player;
                              double var270 = var111.distanceTo(var112);
                              Object[] var113 = new Object[]{43167644123091L};
                              Vec3d var115 = RaycastUtil.bReturningVec3d(var113);
                              Vec3d var114 = var22;
                              double var282;
                              var167 = (var282 = var270 - var114.distanceTo(var115)) == 0.0 ? 0 : (var282 < 0.0 ? -1 : 1);
                           }

                           int var260 = var16;
                           int var259 = var167;
                           int var168 = var259;
                           if (var260 != 0) {
                              return;
                           }

                           int var261 = var168;
                           if (var261 > 0) {
                              Object[] var10004 = new Object[]{null, 88934251628464L};
                              var10004[0] = true;
                              Object[] var118 = var10004;
                              Backtrack var117 = this;
                              var117.jReturningVoid(var118);
                              return;
                           }
                        }
                     }
                  }

                  Object[] var121 = new Object[0];
                  PacketReceiveEvent var120 = var1;
                  var120.aReturningVoid(var121);
                  var169 = this;
               }

               ConcurrentLinkedQueue var271 = var169.e;
               TimedPacket var123 = new TimedPacket(var17, System.currentTimeMillis());
               ConcurrentLinkedQueue var122 = var271;
               boolean var170 = var122.add(var123);
               return;
            }

            Object[] var280 = new Object[]{null, 67756338792793L};
            var280[0] = true;
            Object[] var48 = var280;
            Backtrack var47 = this;
            var47.kReturningVoid(var48);
            ElapsedTimer var272 = this.g;
            Object[] var50 = new Object[]{42835128969216L};
            ElapsedTimer var49 = var272;
            var49.aReturningVoid(var50);
         }
      }
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 22834438980169L ^ 45472129387280L;
      var10001 = 22834438980169L ^ 1796363318836L;
      var10001 = 22834438980169L ^ 32944969760291L;
      int var10000 = Event.bReturningInt();
      Object[] var13 = new Object[0];
      AttackEntityEvent var12 = var1;
      Entity var11 = var12.aReturningEntity(var13);
      int var10 = var10000;
      int var41 = var10;
      Entity var40 = var11;
      Entity var35 = var40;
      Entity var34 = var40;
      if (var41 == 0) {
         Entity var42 = var34;
         if (var42 == null) {
            return;
         }

         var35 = var11;
      }

      boolean var53 = var35 instanceof PlayerEntity;
      int var44 = var10;
      boolean var43 = var53;
      boolean var37 = var43;
      boolean var36 = var43;
      if (var44 == 0) {
         boolean var45 = var36;
         if (!var45) {
            return;
         }

         Object[] var17 = new Object[]{var11, 23530800886909L};
         Backtrack var16 = this;
         boolean var46 = var16.aReturningBoolean(var17);
         var37 = var46;
      }

      int var48 = var10;
      boolean var47 = var37;
      boolean var39 = var47;
      boolean var38 = var47;
      if (var48 == 0) {
         boolean var49 = var38;
         if (!var49) {
            return;
         }

         Object[] var21 = new Object[]{10110749899882L};
         Backtrack var20 = this;
         var39 = var20.dReturningBoolean(var21);
      }

      boolean var50 = var39;
      if (var50) {
         Entity var52 = this.j;
         Entity var51 = var11;
         if (var51 != var52) {
            this.i = new Vec3d(0.0, 0.0, 0.0);
            this.h = new Vec3d(0.0, 0.0, 0.0);
            Object[] var10004 = new Object[]{null, 67756338792793L};
            var10004[0] = true;
            Object[] var23 = var10004;
            Backtrack var22 = this;
            var22.kReturningVoid(var23);
            this.f = new TrackedPosition();
            TrackedPosition var54 = this.f;
            Entity var24 = var11;
            TrackedPosition var25 = var24.getTrackedPosition();
            Vec3d var33 = var25.withDelta(0L, 0L, 0L);
            TrackedPosition var32 = var54;
            var32.setPos(var33);
         }

         this.j = var11;
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 30701972957441L ^ 42277991899224L;
      var10001 = 30701972957441L ^ 82526761332401L;
      var10001 = 30701972957441L ^ 15989848022396L;
      var10001 = 30701972957441L ^ 20745960215915L;
      var10001 = 30701972957441L ^ 119097595870060L;
      int var14 = Event.bReturningInt();
      int var71 = var14;
      if (var71 == 0) {
         MinecraftClient var15 = b;
         ClientWorld var72 = var15.world;
         label83:
         if (var72 != null) {
            MinecraftClient var17 = b;
            int var74 = var14;
            ClientPlayerEntity var73 = var17.player;
            ClientPlayerEntity var56 = var73;
            ClientPlayerEntity var54 = var73;
            if (var74 == 0) {
               ClientPlayerEntity var75 = var54;
               ClientPlayerEntity var55 = var75;
               ClientPlayerEntity var76 = var55;
               if (var76 == null) {
                  break label83;
               }

               MinecraftClient var23 = b;
               var56 = var23.player;
            }

            Backtrack var70;
            label90: {
               int var78 = var14;
               ClientPlayerEntity var77 = var56;
               Object var59 = var77;
               ClientPlayerEntity var57 = var77;
               if (var78 == 0) {
                  ClientPlayerEntity var24 = var57;
                  boolean var79 = var24.isAlive();
                  if (!var79) {
                     Object[] var111 = new Object[]{null, 67756338792793L};
                     var111[0] = true;
                     Object[] var27 = var111;
                     Backtrack var26 = this;
                     var26.kReturningVoid(var27);
                     return;
                  }

                  int var81 = var14;
                  Backtrack var80 = this;
                  var70 = var80;
                  Backtrack var58 = var80;
                  if (var81 != 0) {
                     break label90;
                  }

                  Entity var82 = var58.j;
                  var59 = var82;
               }

               Object var83 = var59;
               if (var83 != null) {
                  int var85 = var14;
                  Backtrack var84 = this;
                  var70 = var84;
                  Backtrack var60 = var84;
                  if (var85 != 0) {
                     break label90;
                  }

                  Backtrack var86 = var60;
                  Backtrack var61 = var86;
                  Entity var31 = var61.j;
                  boolean var87 = var31.isAlive();
                  if (var87) {
                     int var89 = var14;
                     Backtrack var88 = this;
                     var70 = var88;
                     Backtrack var62 = var88;
                     if (var89 != 0) {
                        break label90;
                     }

                     Backtrack var90 = var62;
                     Backtrack var63 = var90;
                     Entity var91 = var63.j;
                     if (var91 != null) {
                        int var93 = var14;
                        Backtrack var92 = this;
                        var70 = var92;
                        Backtrack var64 = var92;
                        if (var93 != 0) {
                           break label90;
                        }

                        Backtrack var94 = var64;
                        Backtrack var65 = var94;
                        Object[] var37 = new Object[]{this.j, 23530800886909L};
                        Backtrack var36 = var65;
                        boolean var95 = var36.aReturningBoolean(var37);
                        if (var95) {
                           int var97 = var14;
                           Backtrack var96 = this;
                           var70 = var96;
                           Backtrack var66 = var96;
                           if (var97 != 0) {
                              break label90;
                           }

                           Backtrack var98 = var66;
                           Backtrack var67 = var98;
                           Object[] var41 = new Object[]{10110749899882L};
                           Backtrack var40 = var67;
                           boolean var99 = var40.dReturningBoolean(var41);
                           if (var99) {
                              int var101 = var14;
                              Backtrack var100 = this;
                              var70 = var100;
                              Backtrack var68 = var100;
                              if (var101 != 0) {
                                 break label90;
                              }

                              Backtrack var102 = var68;
                              Backtrack var69 = var102;
                              Object[] var44 = new Object[]{var69.j, 131657085751917L};
                              Vec3d var10000 = RaycastUtil.aReturningVec3d(var44);
                              Vec3d var46 = this.h;
                              Vec3d var45 = var10000;
                              boolean var103 = var45.equals(var46);
                              if (!var103) {
                                 Object[] var10004 = new Object[]{null, 88934251628464L};
                                 var10004[0] = false;
                                 Object[] var49 = var10004;
                                 Backtrack var48 = this;
                                 var48.jReturningVoid(var49);
                                 int var104 = var14;
                                 if (var104 == 0) {
                                    return;
                                 }
                              }
                           }
                        }
                     }
                  }
               }

               Backtrack var105 = this;
               var70 = var105;
            }

            Object[] var110 = new Object[]{null, 67756338792793L};
            var110[0] = true;
            Object[] var53 = var110;
            Backtrack var52 = var70;
            var52.kReturningVoid(var53);
            return;
         }

         Object[] var112 = new Object[]{null, 67756338792793L};
         var112[0] = false;
         Object[] var21 = var112;
         Backtrack var20 = this;
         var20.kReturningVoid(var21);
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      long var10001 = 10702417976352L ^ 57329648342393L;
      Object[] var10004 = new Object[]{null, 67756338792793L};
      var10004[0] = false;
      Object[] var7 = var10004;
      Backtrack var6 = this;
      var6.kReturningVoid(var7);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 14146175880597L ^ var2;
      long var4 = var2 ^ 14778006039953L;
      long var6 = var2 ^ 95343442407577L;
      long var8 = var2 ^ 22372527386179L;
      int var10 = Event.cReturningInt();
      BooleanSetting var12 = this.d;
      Boolean var13 = (Boolean)var12.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
      int var33 = var10;
      byte var32 = var10000;
      byte var24 = var32;
      byte var23 = var32;
      if (var33 != 0) {
         byte var34 = var23;
         if (var34 != 0) {
            MinecraftClient var15 = b;
            ClientPlayerEntity var16 = var15.player;
            ItemStack var11 = var16.getMainHandStack();
            Object[] var17 = new Object[]{var11, var8};
            var10000 = ((byte)((InventoryUtil.aReturningBoolean(var17)) ? 1 : 0));
            int var36 = var10;
            byte var35 = var10000;
            byte var30 = var35;
            byte var25 = var35;
            if (var36 != 0) {
               byte var37 = var25;
               if (var37 == 0) {
                  Object[] var19 = new Object[]{var11, var4};
                  byte var49 = ((byte)((InventoryUtil.bReturningBoolean(var19)) ? 1 : 0));
                  int var39 = var10;
                  boolean var38 = dev.prestige.recovery.SourceSupport.asBoolean(var49);
                  byte var51 = ((byte)((var38) ? 1 : 0));
                  boolean var26 = var38;
                  if (var39 == 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var51);
                  }

                  boolean var40 = var26;
                  boolean var27 = var40;
                  boolean var41 = var27;
                  if (!var41) {
                     Object[] var22 = new Object[]{var11, var6};
                     var49 = ((byte)((InventoryUtil.o(var22)) ? 1 : 0));
                     int var43 = var10;
                     byte var42 = var49;
                     var51 = var42;
                     byte var28 = var42;
                     if (var43 == 0) {
                        return dev.prestige.recovery.SourceSupport.asBoolean(var51);
                     }

                     byte var44 = var28;
                     byte var29 = var44;
                     byte var45 = var29;
                     if (var45 == 0) {
                        return false;
                     }
                  }
               }

               var30 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var30);
         }

         var24 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 116156197076504L ^ 118494907964458L;
      var10001 = 116156197076504L ^ 115412458554459L;
      var10001 = 116156197076504L ^ 10614093412397L;
      var10001 = 116156197076504L ^ 23448135731672L;
      var10001 = 116156197076504L ^ 10830798712348L;
      int var14 = Event.cReturningInt();
      Vec3d var18 = this.h;
      int var78 = var14;
      double var74 = var18.y;
      double var66 = var74;
      double var68 = var76;
      double var62 = var74;
      double var64 = var76;
      if (var78 != 0) {
         double var104;
         int var79 = (var104 = var62 - var64) == 0.0 ? 0 : (var104 < 0.0 ? -1 : 1);
         if (!((var79) != 0)) {
            return;
         }

         Vec3d var22 = this.h;
         Vec3d var21 = this.i;
         double var10000 = var21.distanceTo(var22) * 0.1;
         Object[] var23 = new Object[]{105570054506037L};
         var68 = GameRenderUtil.aReturningFloat(var23);
         var66 = var10000;
      }

      double var26 = var68;
      double var24 = var66;
      double var15 = Math.min(var24, var26);
      Vec3d var29 = this.h;
      Vec3d var28 = this.i;
      double var32 = var28.distanceTo(var29) * 0.01;
      double var30 = var15;
      var15 = Math.min(var30, var32);
      double var36 = var15;
      Vec3d var35 = this.h;
      Vec3d var34 = this.i;
      this.i = var34.lerp(var35, var36);
      int var81 = var14;
      Backtrack var80 = this;
      Backtrack var71 = var80;
      Backtrack var70 = var80;
      if (var81 != 0) {
         Vec3d var39 = this.h;
         Vec3d var38 = var70.i;
         double var105;
         int var82 = (var105 = var38.distanceTo(var39) - 10.0) == 0.0 ? 0 : (var105 < 0.0 ? -1 : 1);
         if (var82 > 0) {
            this.i = this.h;
         }

         var71 = this;
      }

      int var84 = var14;
      Backtrack var83 = var71;
      Backtrack var73 = var83;
      Backtrack var72 = var83;
      if (var84 != 0) {
         Entity var85 = var72.j;
         if (var85 == null) {
            return;
         }

         var73 = this;
      }

      Vec3d var17 = var73.h;
      RenderContext var87 = var1.b;
      MeshBufferManager var93 = var1.a;
      Vec3d var44 = var17;
      float var10002 = (float)(var44.getX() - 0.25);
      Vec3d var45 = var17;
      float var10003 = (float)var45.getY();
      Vec3d var46 = var17;
      float var10004 = (float)(var46.getZ() - 0.25);
      Vec3d var47 = var17;
      float var10005 = (float)(var47.getX() + 0.25);
      Vec3d var48 = var17;
      float var10006 = (float)(var48.getY() + 2.0);
      Vec3d var49 = var17;
      float var10007 = (float)(var49.getZ() + 0.25);
      Object[] var50 = new Object[]{2617886958130L};
      Color var10008 = ClientUiUtil.dReturningColor(var50);
      Object[] var10012 = new Object[]{null, null, 1456904419907L};
      var10012[1] = 0.3F;
      var10012[0] = var10008;
      Object[] var51 = var10012;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, ClientUiUtil.bReturningColor(var51), 137403672065984L};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var10003;
      var10011[2] = var10002;
      var10011[1] = var93;
      var10011[0] = var87;
      Object[] var52 = var10011;
      ShapeRenderer.hReturningVoid(var52);
      var87 = var1.b;
      MeshBufferManager var94 = var1.a;
      Vec3d var53 = var17;
      var10002 = (float)(var53.getX() - 0.25);
      Vec3d var54 = var17;
      var10003 = (float)var54.getY();
      Vec3d var55 = var17;
      var10004 = (float)(var55.getZ() - 0.25);
      Vec3d var56 = var17;
      var10005 = (float)(var56.getX() + 0.25);
      Vec3d var57 = var17;
      var10006 = (float)(var57.getY() + 2.0);
      Vec3d var58 = var17;
      var10007 = (float)(var58.getZ() + 0.25);
      Object[] var59 = new Object[]{2617886958130L};
      var10008 = ClientUiUtil.dReturningColor(var59);
      var10012 = new Object[]{null, null, 1456904419907L};
      var10012[1] = 1.0F;
      var10012[0] = var10008;
      Object[] var60 = var10012;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, ClientUiUtil.bReturningColor(var60), 106090074574852L};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var10003;
      var10011[2] = var10002;
      var10011[1] = var94;
      var10011[0] = var87;
      Object[] var61 = var10011;
      ShapeRenderer.gReturningVoid(var61);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 26242814532646L;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = false;
      Object[] var7 = var10004;
      Backtrack var6 = this;
      var6.kReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 42704909045819L;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = true;
      Object[] var7 = var10004;
      Backtrack var6 = this;
      var6.kReturningVoid(var7);
      this.i = new Vec3d(0.0, 0.0, 0.0);
      this.h = new Vec3d(0.0, 0.0, 0.0);
   }

   private void jReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      long var3 = (Long)var1[1];
      var3 = 14146175880597L ^ var3;
      long var5 = var3 ^ 80648860925528L;
      int var7 = Event.cReturningInt();
      int var37 = var7;
      Backtrack var36 = this;
      Backtrack var34 = var36;
      Backtrack var29 = var36;
      if (var37 != 0) {
         Entity var38 = var29.j;
         if (var38 != null) {
            Entity var9 = this.j;
            boolean var10000 = var9.isAlive();
            int var40 = var7;
            boolean var39 = var10000;
            boolean var30 = var39;
            if (var40 == 0) {
               return;
            }

            boolean var41 = var30;
            boolean var31 = var41;
            boolean var42 = var31;
            if (var42) {
               Object[] var13 = new Object[]{this.j, var5};
               Backtrack var12 = this;
               var10000 = var12.aReturningBoolean(var13);
               int var44 = var7;
               boolean var43 = var10000;
               boolean var32 = var43;
               if (var44 == 0) {
                  return;
               }

               boolean var45 = var32;
               boolean var33 = var45;
               boolean var46 = var33;
               if (var46) {
                  MinecraftClient var16 = b;
                  Entity var18 = this.j;
                  ClientPlayerEntity var17 = var16.player;
                  float var10001 = var17.distanceTo(var18);
                  MinMaxSetting var19 = this.c;
                  float var10002 = var19.bReturningVoid();
                  MinMaxSetting var20 = this.c;
                  var10001 *= (var10002 - var20.aReturningVoid()) / 4.0F;
                  MinMaxSetting var21 = this.c;
                  var10002 = var21.cReturningVoid();
                  MinMaxSetting var22 = this.c;
                  float var25 = var22.dReturningVoid();
                  float var24 = var10002;
                  float var23 = var10001;
                  this.k = MathHelper.clamp(var23, var24, var25);
               }
            }
         }

         var34 = this;
      }

      ConcurrentLinkedQueue var49 = var34.e;
      Predicate var28 = invokeBinding2(this, var2);
      ConcurrentLinkedQueue var27 = var49;
      boolean var35 = var27.removeIf(var28);
   }

   private void kReturningVoid(Object[] var1) {
      label18: {
         label17: {
            boolean var2 = (Boolean)var1[0];
            long var3 = (Long)var1[1];
            var3 = 14146175880597L ^ var3;
            long var5 = var3 ^ 107343969944444L;
            int var7 = Event.cReturningInt();
            int var13 = var7;
            if (var13 != 0) {
               boolean var14 = var2;
               if (!var14) {
                  break label17;
               }

               Object[] var10004 = new Object[]{null, var5};
               var10004[0] = true;
               Object[] var10 = var10004;
               Backtrack var9 = this;
               var9.jReturningVoid(var10);
            }

            int var15 = var7;
            if (var15 != 0) {
               break label18;
            }
         }

         ConcurrentLinkedQueue var12 = this.e;
         var12.clear();
      }

      this.j = null;
      this.f = null;
   }

   private boolean aReturningBoolean(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 14146175880597L ^ var3;
      int var27 = Event.cReturningInt();
      MinecraftClient var8 = b;
      Entity var10 = var2;
      ClientPlayerEntity var9 = var8.player;
      double var6 = var9.distanceTo(var10);
      int var5 = var27;
      MinMaxSetting var11 = this.a;
      double var29;
      int var28 = (var29 = var6 - var11.cReturningVoid()) == 0.0 ? 0 : (var29 < 0.0 ? -1 : 1);
      int var20 = var5;
      int var19 = var28;
      int var15 = var19;
      int var14 = var19;
      if (var20 != 0) {
         int var21 = var14;
         if (var21 < 0) {
            return false;
         }

         MinMaxSetting var13 = this.a;
         double var30;
         int var22 = (var30 = var6 - var13.dReturningVoid()) == 0.0 ? 0 : (var30 < 0.0 ? -1 : 1);
         var15 = var22;
      }

      int var24 = var5;
      int var23 = var15;
      int var17 = var23;
      int var16 = var23;
      if (var24 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var17);
      } else {
         int var25 = var16;
         if (var25 <= 0) {
            byte var31 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var31);
         } else {
            return false;
         }
      }
   }

   private static boolean eReturningBoolean(Object[] var0) {
      Packet var3 = (Packet)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 14146175880597L ^ var1;
      int var4 = Event.cReturningInt();
      byte var60 = ((byte)((var3 instanceof KeepAliveS2CPacket) ? 1 : 0));
      int var25 = var4;
      byte var24 = var60;
      byte var22 = var24;
      byte var5 = var24;
      if (var25 != 0) {
         byte var26 = var5;
         if (var26 == 0) {
            boolean var61 = var3 instanceof CommonPingS2CPacket;
            int var28 = var4;
            boolean var27 = var61;
            byte var69 = ((byte)((var27) ? 1 : 0));
            boolean var6 = var27;
            if (var28 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var69);
            }

            boolean var29 = var6;
            boolean var7 = var29;
            boolean var30 = var7;
            if (!var30) {
               boolean var62 = var3 instanceof EntityVelocityUpdateS2CPacket;
               int var32 = var4;
               boolean var31 = var62;
               var69 = ((byte)((var31) ? 1 : 0));
               boolean var8 = var31;
               if (var32 == 0) {
                  return ((((int)(var69) & 1) != 0));
               }

               boolean var33 = var8;
               boolean var9 = var33;
               boolean var34 = var9;
               if (!var34) {
                  boolean var63 = var3 instanceof ExplosionS2CPacket;
                  int var36 = var4;
                  boolean var35 = var63;
                  var69 = ((byte)((var35) ? 1 : 0));
                  boolean var10 = var35;
                  if (var36 == 0) {
                     return ((((int)(var69) & 1) != 0));
                  }

                  boolean var37 = var10;
                  boolean var11 = var37;
                  boolean var38 = var11;
                  if (!var38) {
                     boolean var64 = var3 instanceof EntityDamageS2CPacket;
                     int var40 = var4;
                     boolean var39 = var64;
                     var69 = ((byte)((var39) ? 1 : 0));
                     boolean var12 = var39;
                     if (var40 == 0) {
                        return ((((int)(var69) & 1) != 0));
                     }

                     boolean var41 = var12;
                     boolean var13 = var41;
                     boolean var42 = var13;
                     if (!var42) {
                        boolean var65 = var3 instanceof EntityStatusS2CPacket;
                        int var44 = var4;
                        boolean var43 = var65;
                        var69 = ((byte)((var43) ? 1 : 0));
                        boolean var14 = var43;
                        if (var44 == 0) {
                           return ((((int)(var69) & 1) != 0));
                        }

                        boolean var45 = var14;
                        boolean var15 = var45;
                        boolean var46 = var15;
                        if (!var46) {
                           boolean var66 = var3 instanceof GameMessageS2CPacket;
                           int var48 = var4;
                           boolean var47 = var66;
                           var69 = ((byte)((var47) ? 1 : 0));
                           boolean var16 = var47;
                           if (var48 == 0) {
                              return ((((int)(var69) & 1) != 0));
                           }

                           boolean var49 = var16;
                           boolean var17 = var49;
                           boolean var50 = var17;
                           if (!var50) {
                              boolean var67 = var3 instanceof PlaySoundS2CPacket;
                              int var52 = var4;
                              boolean var51 = var67;
                              var69 = ((byte)((var51) ? 1 : 0));
                              boolean var18 = var51;
                              if (var52 == 0) {
                                 return ((((int)(var69) & 1) != 0));
                              }

                              boolean var53 = var18;
                              boolean var19 = var53;
                              boolean var54 = var19;
                              if (!var54) {
                                 byte var68 = ((byte)((var3 instanceof HealthUpdateS2CPacket) ? 1 : 0));
                                 int var56 = var4;
                                 byte var55 = var68;
                                 var69 = var55;
                                 byte var20 = var55;
                                 if (var56 == 0) {
                                    return dev.prestige.recovery.SourceSupport.asBoolean(var69);
                                 }

                                 byte var57 = var20;
                                 byte var21 = var57;
                                 byte var58 = var21;
                                 if (var58 == 0) {
                                    return false;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         var22 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var22);
   }

   private boolean lambda$processPacketQueue$1(boolean var1, TimedPacket var2) {
      int var5 = Event.bReturningInt();
      int var17 = var5;
      byte var16 = ((byte)((var1) ? 1 : 0));
      byte var14 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         label23:
         if (var18 == 0) {
            float var25;
            int var10000 = (var25 = (float)(System.currentTimeMillis() - var2.recoveryAccess_read_af()) - this.k) == 0.0F ? 0 : (var25 < 0.0F ? -1 : 1);
            int var20 = var5;
            int var19 = var10000;
            int var15 = var19;
            int var12 = var19;
            if (var20 == 0) {
               int var21 = var12;
               int var13 = var21;
               int var22 = var13;
               if (var22 >= 0) {
                  break label23;
               }

               var15 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var15);
         }

         MinecraftClient var24 = b;
         Runnable var10 = invokeBinding3(var2);
         MinecraftClient var9 = var24;
         var9.execute(var10);
         byte var23 = 1;
         var14 = var23;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var14);
   }

   private static void lambda$processPacketQueue$0(TimedPacket var0) {
         MinecraftClient var4 = b;
         ClientPlayNetworkHandler var9 = var4.getNetworkHandler();
         if (var9 != null) {
            Packet var10000 = var0.recoveryAccess_read_ae();
            MinecraftClient var5 = b;
            ClientPlayNetworkHandler var7 = var5.getNetworkHandler();
            Packet var6 = var10000;
            var6.apply((PacketListener)var7);
         }
      } catch (Exception var10) {
      }
   }

   static {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(66425982788888L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -3015950201723904014L;
      byte[] var17 = var13.doFinal(
         new byte[]{
            (byte)214L,
            (byte)54821L,
            (byte)14034225L,
            (byte)3592761669L,
            (byte)919746987341L,
            (byte)235455228759546L,
            (byte)60276538562443935L,
            (byte)-3015950201723904014L
         }
      );
      long var22 = (var17[0] & 255L) << 56
         | (var17[1] & 255L) << 48
         | (var17[2] & 255L) << 40
         | (var17[3] & 255L) << 32
         | (var17[4] & 255L) << 24
         | (var17[5] & 255L) << 16
         | (var17[6] & 255L) << 8
         | var17[7] & 255L;
      // m = var22;
      p = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(66425982788888L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      String var4 = "à8»\u009fM6¦\u0096\u0092Ï\u0007ª èÛO";
      int var5 = "à8»\u009fM6¦\u0096\u0092Ï\u0007ª èÛO".length();
      do {
         int var20 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var20, var2).getBytes("ISO-8859-1");
         int var21 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         // var6[var21] = var10004;
      } while (var2 < var5);

      n = var6;
      o = new Long[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14650;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])p.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/en", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         o[var3] = var15;
      }

      return o[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/en_C0244",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/en" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = r[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = q[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 37;
            yield var15;
         }
         case 1 -> {
            byte var16 = 11;
            yield var16;
         }
         case 2 -> {
            byte var17 = 8;
            yield var17;
         }
         case 3 -> {
            byte var18 = 24;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 9;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 2;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 43;
            yield var25;
         }
         case 11 -> {
            byte var26 = 51;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 23;
            yield var28;
         }
         case 14 -> {
            byte var29 = 63;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 47;
            yield var31;
         }
         case 17 -> {
            byte var32 = 58;
            yield var32;
         }
         case 18 -> {
            byte var33 = 54;
            yield var33;
         }
         case 19 -> {
            byte var34 = 5;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 21;
            yield var36;
         }
         case 22 -> {
            byte var37 = 22;
            yield var37;
         }
         case 23 -> {
            byte var38 = 28;
            yield var38;
         }
         case 24 -> {
            byte var39 = 61;
            yield var39;
         }
         case 25 -> {
            byte var40 = 12;
            yield var40;
         }
         case 26 -> {
            byte var41 = 59;
            yield var41;
         }
         case 27 -> {
            byte var42 = 57;
            yield var42;
         }
         case 28 -> {
            byte var43 = 38;
            yield var43;
         }
         case 29 -> {
            byte var44 = 16;
            yield var44;
         }
         case 30 -> {
            byte var45 = 7;
            yield var45;
         }
         case 31 -> {
            byte var46 = 50;
            yield var46;
         }
         case 32 -> {
            byte var47 = 3;
            yield var47;
         }
         case 33 -> {
            byte var48 = 41;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 35;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 52;
            yield var53;
         }
         case 39 -> {
            byte var54 = 10;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 31;
            yield var56;
         }
         case 42 -> {
            byte var57 = 29;
            yield var57;
         }
         case 43 -> {
            byte var58 = 36;
            yield var58;
         }
         case 44 -> {
            byte var59 = 26;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 60;
            yield var61;
         }
         case 47 -> {
            byte var62 = 18;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 19;
            yield var64;
         }
         case 50 -> {
            byte var65 = 30;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 6;
            yield var67;
         }
         case 53 -> {
            byte var68 = 53;
            yield var68;
         }
         case 54 -> {
            byte var69 = 55;
            yield var69;
         }
         case 55 -> {
            byte var70 = 4;
            yield var70;
         }
         case 56 -> {
            byte var71 = 42;
            yield var71;
         }
         case 57 -> {
            byte var72 = 45;
            yield var72;
         }
         case 58 -> {
            byte var73 = 32;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 40;
            yield var76;
         }
         case 62 -> {
            byte var77 = 17;
            yield var77;
         }
         default -> 13;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            r[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      q[0] = ".L\u00001U\\.L\u0017mYS4\u0007\u0017sYF3vG.\b";
      q[1] = "\u0014Y\u0018F\u0002K\u0014Y\u000f\u001a\u000eD\u000e\u0012\u000f\u0004\u000eQ\tcZ[[";
      q[2] = "]r\u0015\u0015R?]r\u0002I^0G9\u0002W^%@HS\u000e\u0006`";
      q[3] = "\u0001Wy\u0010w1\u0001WnL{>\u001b\u001cnR{+\u001cm?\u000b.o";
      q[4] = void.class;
      r[4] = "java/lang/Void";
      q[5] = "\u0005\u0019I%$#\u0013\u0019L\u007f74\u0004ROy; \u0015\u0015Xnp6\u000f";
      q[6] = "T>p^G\u0019_1a\u0011$\u0014J<nz\u0011\u0016[/rV\u0006\u001b";
      q[7] = "\u0019@\u000b5U\u0003\u000f@\u000eoF\u0014\u0018\u000b\riJ\u0000\tL\u001a~\u0001\u00171";
      q[8] = float.class;
      r[8] = "java/lang/Float";
      q[9] = "H\"P)0a^\"Us#vIiVu/bX.Abdpi";
      q[10] = int.class;
      r[10] = "java/lang/Integer";
      q[11] = "$\u0005\u00034Nf$\u0005\u0014hBi>N\u0014vB|9?@.\u0015";
      q[12] = "z_-##'z_:\u007f/(`\u0014:a/=geh?wy";
      q[13] = "cnJDO\u0004unO\u001e\\\u0013b%L\u0018P\u0007sb[\u000f\u001b\u0017h";
      q[14] = "\u0017\u001b<}>\u0004b;7r/K\u00035<y+\u0011w";
      q[15] = boolean.class;
      r[15] = "java/lang/Boolean";
      q[16] = "!M\u0005HAu!M\u0012\u0014Mz;\u0006\u0012\nMo<w@Q\u0015%";
      q[17] = "Om(3\u001d\"Db9|q!J`;3]";
      q[18] = "\u000f\u001f9\fFO\u0019\u001f<VUX\u000eT?PYL\u001f\u0013(G\u0012[-";
      q[19] = "\t-\u001f`#^\u0002\"\u000e/BP\t)\nu";
      q[20] = "c\u007f @\u0003t\u0016_+O\u0012;wQ D\u0016a\u0003";
      q[21] = "c~\u001aNi?\u0016^\u0011AxpwP\u001aJ|*\u0003";
      q[22] = "3jj>`@3j}blO)!}|lZ.P,$>";
      q[23] = "\u00177&\u001cuq\u001c87S\bd\u000e\"5\u0010";
      q[24] = long.class;
      r[24] = "java/lang/Long";
      q[25] = "r|)c\u001f(r|>?\u0013'h7>!\u00132oFozEv";
      q[26] = "\u0001kT\u0002\bc\u0001kC^\u0004l\u001b C@\u0004y\u001cQ\u0011\u001cT2]";
      q[27] = double.class;
      r[27] = "java/lang/Double";
      q[28] = "/\u0013ABR\u001e1\u001b[\r\u001f\u0004+\u0011BQ\u000e\u000e+\u0006\u0019`\u0013\u0005&\u0007EQ\u0019\u00051>^M\u0017\u000e!#BF\t\u000e";
      q[29] = "\brk\u0019/m\br|E#b\u00129|[#w\u0015H(\u0003p6";
      q[30] = ".qz\bE:8q\u007fRV-/:|TZ9>}kC\u0011,\u0013";
      q[31] = "#\u0001\t@\u007fdV!\u0002On+7/\tDjqC";
      q[32] = "\b.\u0019 e.}\u000e\u0012/ta\u001c\u0000\u0019$p;h";
      q[33] = "Qi\u001an@\u0016Qi\r2L\u0019K\"\r,L\fLS\\v\u0015K";
      q[34] = short.class;
      r[34] = "java/lang/Short";
      q[35] = "z>K\u0015-Az>\\I!N`u\\W![g\u0004\u000e\u000br\u001e ";
      q[36] = "?%\u0005;\u000eH!-\u001fto_?!\u0010.S";
      q[37] = "\u001d&^\u0000\u000e9\u001d&I\\\u00026\u0007mIB\u0002#\u0000\u001c\u001b\u0017Pg";
      q[38] = "CpzMS,Up\u007f\u0017@;B;|\u0011L/S|k\u0006\u0007?\u0014";
      q[39] = "si\u001aNWn\u0006I\u0011AF!gG\u001aJB{\u0013";
      q[40] = "\u001a;c&\u000f\u0006\u001a;tz\u0003\t\u0000ptd\u0003\u001c\u0007\u0001!;Z";
      q[41] = "\u0007U\u001b\u0018curu\u0010\u0017r:\u0013{\u001b\u001cv`g";
      q[42] = "e5@Qx!\u0010\u0015K^inq\u001b@Um4\u0005";
      q[43] = "q\u0016iG|N\u00046bHm\u0001e8iCi[\u0011";
      q[44] = "[;\u001f,>\u0002M;\u001av-\u0015Zp\u0019p!\u0001K7\u000egj\u0010[";
      q[45] = "&2V(\u001c\rS\u0012]'\rB2\u001cV,\t\u0018F";
      q[46] = "8\u0013\u0018\u001amJM3\u0013\u0015|\u0005,=\u0018\u001ex_X";
      q[47] = "?)x\u0013!B))}I2U>b~O>A/%iXuS\u0019";
      q[48] = "\t5\"^#d|\u0015)Q2+\u001d\u001b\"Z6qi";
      q[49] = "\u001d\u0012i&#.\u0000\u00071\u0004b#\u0018\u0001";
      q[50] = "\u0003YKc\u0001\u0012\u0015YN9\u0012\u0005\u0002\u0012M?\u001e\u0011\u0013UZ(U\u0006\u0011";
      q[51] = "-\u001a3\u001c\u0012OX:8\u0013\u0003\u0000943\u0018\u0007ZM";
      q[52] = "p\u0005XY>\u0000f\u0005]\u0003-\u0017qN^\u0005!\u0003`\tI\u0012j\u0014c";
      q[53] = "\n\u000bT\u0005`\f\u007f+_\nqC\u001e%T\u0001u\u0019j";
      q[54] = "=x\u0003\u007fDTHX\bpU\u001b)V\u0003{QA]";
      q[55] = "uOd\u000f:3~@u@Y>kF";
      q[56] = "$%L\u0013_JQ\u0005G\u001cN\u00050\u000bL\u0017J_D";
      q[57] = "\u001fDHtB jdC{So\u000bjHpW5\u007f";
      q[58] = "O+V,l^O+Ap`QU`An`DR\u0011\u001172\u0005";
      q[59] = "Xyg\u001dKBFq}R\u0003B\\{e\u0015\nY\u001cHc\u0019\u0001^Qye\u0019";
      q[60] = "e\u0019P!\bcn\u0016Antza\u0016G\"Jj";
      q[61] = ":e\u001b\u0018j=OE\u0010\u0017{r.K\u001b\u001c\u007f(Z";
      q[62] = "\"\u0017\u0016`\u007f74\u0017\u0013:l #\\\u0010<`42\u001b\u0007++&\u000e";
      q[63] = "7'g#f6B\u0007l,wy#\tg's#W";
      q[64] = "\"kLn?Bd+X6\u000fR\u001e(C&4\u0006#%U=p8";
      q[65] = "5nS|>\u0007eg\u0000+G\u0003&eG !\u0014\u0007~X \u0002\t?{\\6G\u0007'sE,-\u0016' \u0006M";
      q[66] = "\u000e\u0002~\f2#\bB\u007f\t\u0003#\u0000\u0016E\fj-\u0000\n7\u0006{*\u0013z,\u0007r&\u001e\u0019\u007fXz!l";
      q[67] = "THX,4\u007f_MBP>sLBN<\f'\r\u001c\u0013PbuNBM<c YI)";
      q[68] = "_L Z\nm\u000fM)Y_\u0013\u000fsv\u0014Wb\u001fC/AS#[s\u007f@\ta^\u000bv\u0016\u0000mf";
      q[69] = "~n\u0013^J#zq\u0016\r%,y{\u0016f\u001e}%!n\u000eH,.ySP\u001c#p\u001e";
      q[70] = "\u00071j}S9W{km\u0011R[jm\u0003\u000f)R`kqW,\u0002`\u000bb\u0015>Uky:\u0010nU\u000bjx\u00029^y2}R9>";
      q[71] = "JW\tB`\u0006\u0002WKM\u0007\u001c{PLYv\u000fK\t\u0019]7K{\u0000\u0014Nk\u0004\u0018SKFlv";
      q[72] = "P\u0007[5\u001b'R\t\u0004<~)n\u000f\u0001j\u000f9^VTnN}n\rRm\u001d;\u0011U_mA@";
      q[73] = "\u0018m5Y\f\u0000Dt9\u0018g\u0019\u0010c2B\u000b+F!k\u0018_|\u001a#9\u001e\u0018\u0007D|.Gg";
      q[74] = "X\\_xNkG\u0006\u0015otdXZ\u0017WO5\u0005\u0004o?\u0019d\u000fXRaMkQ?";
      q[75] = "\u001e3\u0005-\u0016_Xs\u0011u&I\"p\ne\u001d\u001b\u001f}\u001c~Y%";
      q[76] = "\u0011\u0017s/G\u0019G\u00015|~\u0014\u001e\u0007h))CDW5E\u001f\u0001\u0013\u0001l7G\u0004C\u0001";
      q[77] = "-_ck#;qFo*H\"%Qdp$\u0010s\u0013=*rG/\u0011o,7<qNxuH";
      q[78] = "i\u001eWaBBo^Vds@o\u000b\u0005ws\u0010g\u0007\u000fv\fHj\u0007S\r";
      q[79] = ",zq\u0018p\"%,x\u0014H?qm)\r$\r *rZyZ\u007fkp\u0011t6fht\u001bH";
      q[80] = "\u000b\u0001z\r0\t]\u0017<^\t\u000f\b\u0000e\u0000e=^A8V1j\u000b\u0001z\r0\t]\u0017<^\t\u000b\u001e\u0010n\u0007{S\u001b@ngg\u0017\u001a\u0016<\u00041\u0001\\E\u0005";
      q[81] = "=\u0013\u000e,Di8NQo]\u0012m+SmIc}\u001b\n8M\"9+W6_):\u0016Z Dm\u0004";
      q[82] = "yEgkvH/S!8ONzDxf#|.\u0000\"8s+vCtj/Y.F$jO";
      q[83] = "\faWv\u0010v\u0015bS|,\u007f\u0002g\u000ej@MS R<\u0010\u001a\u0001f\u0011g\u0015yWpW4,!\u0003z\rvSy\u000ezQ\r";
      q[84] = "\u0001\u0004(&]\n\u0013\u000eitf\u001cxLh*\u0017\u000fH\u0015=.VKx\u001b*3\fO\u001bM<u_v";
      q[85] = "|0\u0014D\u000eF:p\u0000\u001c>U@s\u001b\f\u0005\u0002}~\r\u0017A<";
      q[86] = "_[bMkAT^x1jAVU\u007ff=\u001e\u000b\u000e\u0013J4_\u0006^,M`A\u0004";
      q[87] = "4,^(RJwkG}\n0h}[v\r\\Z)\u001a-T\u000b\r-CfQ\u000e0 U}\u001500tW-T\r=bLij\ri`\u001c(W\u0000\u007f{X\u0016WT}+\u0019+ZBfo'";
      q[88] = "T\u001d'B*\u0004\u0014[rW\u001b\u0012o[\"_j\u0007_\u0002w[+Co\u000bzHw\f\fX%@p~";
      q[89] = "Ylof~\u0014\u0012x~b\u0011\u0010(*.a`\u0006\u0018s{e!B((}fr\u0004Wppf.\u007f";
      q[90] = "\u000evGP\u001e/\u0011,\rG$ \u000ep\u000f\u007f\u001fqS)wIM!\n)IAYq\f\u0015";
      q[91] = "\u0011\"\u0012E~~QdGPOi*d\u0017X>}\u001a=B\\\u007f9*4OO#vIg\u0010G$\u0004";
      q[92] = "|VuM\u0014m4V7BstMQ0V\u0002d}\beRC M\u0001hA\u001fo.R7I\u0018\u001d";
      q[93] = "Q\b\u0001\u001dA6Z\r\u001baC'X\t\r\u001dCW\f_\u0002\u0000H'\t\u001c\t\rLW\u000e\u000e\u0011\u0002U(V\u0003\u0011^.";
      q[94] = "Xh\u0002/\u001c)\u000e~D|%'Oh\u0014!^JZ|\u001a)U8Pm\u001d:%#Qd\u00117Fp\u000el\u0016E";
      q[95] = "WB8gCxULgn&uiL05\u0016xT\u0012d:H\u001f";
      q[96] = "\u000f\u007fnu\u0016\"\b<u9t|Qkph#,\b?.\u0004K\u007f[6s9\u0015+Th";
      q[97] = "0+Lp\u001b$pm\u0019e*7\u000bmIm[';4\u001ci\u001ac\u000b=\u0011zF,hnNrA^";
      q[98] = "\u001f9\u0000\u0003\u0007\u0013T-\u0011\u0007h\u0018n\u007fA\u0004\u0019\u0001^&\u0014\u0000XEn}\u0012\u0003\u000b\u0003\u0011%\u001f\u0003Wx";
      q[99] = "[OM[\u001e\u0001R\u0019DW&\u001c\u0006X\u0015NJ.V\u001aO\u0019&F\u0006OEN\u001b\u0018R@\u001b)";
      q[100] = "\u000baL\u0003hE\u000f~IP\u0007J\ftI;<\u001bP!1\rnK\b-\u000f\u0005z\u001b\u000e\u0011";
      q[101] = "s>H%\u000e_%(\u000ev7Yp?W([k${\rv\t<|8[$WN$=\u000b$7";
      q[102] = "\r{<\u001dn}\u000fuc\u0014\u000bq3u4O;}\u000e+`@e\u001a";
      q[103] = ")0M>CD.#Dv$B%8I+MN\u001c6I;I(+8\\*VKxgT-$";
      q[104] = "yMOj\u0016^p\u001bFf.C$Z\u0017\u007fBqt\u0016O%.O.W\u001bjM\u001cq_\u001c\u0018";
      q[105] = "N&C\u0013VxIeX_4-\u001c#Y\u0005X\u001fL`\u0002S4x\u001agKZLqLnGb\t,\u0001d\u0007_\u0004:\u001a 9";
      q[106] = "ohW*zN?t\u001dv\u0003Y\u0004eE-o@voT*|0";
      q[107] = "(e\u0018l!,~s^?\u0018*+d\u0007at\u0018\u007f ]?%O'c\u000bmx=\u007ff[m\u0018";
      q[108] = "\u0010\u0005\u0001KpU\t\u0006\u0005AL\\\u001e\u0003XW nOD\u0004\u0000}9\u001c\u0003TH-S\r\u0003\u0007\u000bLV\u000f\u0013@Q&G\u000f@\u00030#E\u001f\u0007YZ2ELD8^1F\u0019F[\b'\u0000J\u007f";
      q[109] = "\b\u0001hQ;~\u000eAiT\nm\u0007\u001c4CgV\u0004yj\u0000k}\bC/@zn\u0005y:Z{{\u0018\u001ai\u0005s|j";
      q[110] = "J&6\u0007{\fMe-K\u0019Y\u0018#,\u0011ukHotK\u0019U\u0012. \u0004z\u0006M&'v";
      q[111] = "I\u007fd\f_&Bz~p^&@qy'\tx\u0017)\u0015OI=\\w%H\n&\u0010";
      q[112] = "\u000eW\u0006\u0011*U\u0000\u001a\u0000\nFNjSD\u000b7^Z\n\u0011\u000fv\u001ajQ\u0017\f%\\\u0015\t\u001a\fy'";
      q[113] = "y\u00154\u0019\u0003i/\u0003rJ:oz\u0014+\u0014V].PqI:dj\u0017!JY2|Qrs[q{\u0003+\u0001\u0003t+\u0003K";
      q[114] = "W\u0016ax7\u001eE\u001c *\f\u000b.^!t}\u001b\u001e\u0007tp<_.\tcmf[M_u+5b";
      q[115] = "\u0003\r&?\u0006\rCKs*7\u001e8Ne#G\u000eI\u000b|$\u000ew\u0004\u000b{4N\u0006A\u0012|}7";
      q[116] = "t\u001cw+\u001f(9\u001e(?/'\u0004\u0019.<^24@{8\u001fv\u0004Qp>\u001e i\u001bp>EK";
      q[117] = "YL\u007f=P4\u0011L=27#hK:&F=X\u0012o\"\u0007yh\u001bb1[6\u000bH=9\\D";
      q[118] = "\u00065]\tvl\u0000(^Z\u0015v\u0013/\u0019\u0007oa81\u0002 hh\u001aV\b\u000fr`\u000e$\u0002\u001eus~:\r\u0001y|\f0\u001c\u0006j\f";
      q[119] = "{J\u0001OH@'S\r\u000e#YsD\u0006TOk'\u0001X\u000f\u001e<fG\nC\u001a\r$Q[R#\fu\u0000\u0014\u000b[\u0005#\t\u00183";
      q[120] = "SG[VP\u0011T\u0004@\u001a2D\u0001BA@^vR\u0006\u001d\u00182K\u0005Z\\A\rXQDY'";
      q[121] = "@\bj>l\u0015\r\n5*\\\u001c0\r3)-\u000f\u0000Tf-lK0Em+m\u001d]\u000fm+6v";
      q[122] = "CO\"\u001e}.\u0003\tw\u000bL6x\t'\u0003=-HPr\u0007|ix\u000bt\u0004//\u0007Sy\u0004sT";
      q[123] = "k[`\u0019[*+\u001d5\fj3P\u001de\u0004\u001b)`D0\u0000ZmP\u001f6\u0003\t+/G;\u0003UP";
      q[124] = "\u001af~\u00017j\\&jY\u0007{&%qI<.\u001b(gRx\u0010";
      q[125] = "t\u000foFN22\u0013mI23 \b\u007f\u001f^\u0001sI'H\u000bVwKf@M+t\u000ev\t2m!\u0015|\u0003M5,\u0015 x";
      q[126] = "npK\u0002\u0007{`*N\u0019dh\u0010u\n\u001f\u0015x ,_\u001bT<\u0010uN\tZ}t3R\u000bU\u0001";
      q[127] = "\n9o&\u0007\u0001\u0002-? ;T\f5}\u0012\u0000\u0006W`\u0005+F@\u0001if}P\u0006RP";
      q[128] = "=*P\u0006J\u0017a3\\G!\u000e5$W\u001dM<cf\u000eG\u0018k?d\\A^\u0010a;K\u0018!";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = q[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(r[var4]);
            q[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            q[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  q[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1350401629149140L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  q[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1350401629149140L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        q[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1350401629149140L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 65;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 84;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 255;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 201;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 103;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 77;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 65;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 84;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 255;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/en_C0244",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/en" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(Object var0, int var1) {
         MethodHandle var6 = bindingCache1;
         MethodHandle var5 = bindingCache1;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache1 = SwitchBootstraps.typeSwitch(
                  MethodHandles.lookup(),
                  "typeSwitch",
                  SourceSupport.methodType("(Ljava/lang/Object;I)I", MethodHandles.lookup()),
                  EntityS2CPacket.class,
                  EntityPositionS2CPacket.class,
                  EntityPositionSyncS2CPacket.class
               )
               .dynamicInvoker();
         }

         try {
            return (int)var3.invokeExact((Object)var0, (int)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Predicate invokeBinding2(Backtrack var0, boolean var1) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/en_C0244;Z)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/en_C0244", "lambda$processPacketQueue$1", "(ZLdev/zprestige/prestige/gh_C0340;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gh_C0340;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var3.invokeExact((Backtrack)var0, (boolean)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Runnable invokeBinding3(TimedPacket var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gh_C0340;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/en_C0244", "lambda$processPacketQueue$0", "(Ldev/zprestige/prestige/gh_C0340;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((TimedPacket)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
