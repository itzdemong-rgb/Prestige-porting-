package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.PostAttackEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public class BreachSwap extends Module {
   private FloatSetting a;
   private int c = -1;
   private int d = 0;
   private static final long k = 127337207808121L;
   private static final long l;
   private static final Object[] m = new Object[69];
   private static final String[] n = new String[69];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 6494396421594L ^ 74889041858732L;
      int var6 = Event.cReturningInt();
      int var18 = var6;
      BreachSwap var17 = this;
      BreachSwap var16 = var17;
      BreachSwap var12 = var17;
      if (var18 != 0) {
         int var19 = var12.d;
         if (var19 == 0) {
            int var21 = var6;
            int var20 = this.c;
            int var15 = var20;
            int var13 = var20;
            if (var21 != 0) {
               int var22 = var13;
               int var14 = var22;
               // int var23 = var14;
               if (var23 == var24) {
                  return;
               }

               int var25 = this.c;
               var15 = var25;
            }

            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var15;
            Object[] var11 = var10003;
            InventoryUtil.aReturningVoid(var11);
            this.c = -1;
            int var26 = var6;
            if (var26 != 0) {
               return;
            }
         }

         BreachSwap var27 = this;
         var16 = var27;
      }

      var16.d--;
   }

   @EventListener
   public void a(PostAttackEvent var1) {
      long var10001 = 33326047698423L ^ 124899288011176L;
      var10001 = 33326047698423L ^ 56407502789368L;
      var10001 = 33326047698423L ^ 105257798588545L;
      var10001 = 33326047698423L ^ 17566145577547L;
      int var12 = Event.cReturningInt();
      Random var14 = RandomUtil.a;
      float var10000 = var14.nextFloat() * 100.0F;
      FloatSetting var15 = this.a;
      Float var16 = (Float)var15.aReturningObject();
      float var75;
      int var71 = (var75 = var10000 - var16) == 0.0F ? 0 : (var75 < 0.0F ? -1 : 1);
      int var49 = var12;
      int var48 = var71;
      int var37 = var48;
      int var36 = var48;
      if (var49 != 0) {
         int var50 = var36;
         if (var50 > 0) {
            this.d = 1;
         }

         var37 = this.d;
      }

      int var52 = var12;
      int var51 = var37;
      int var39 = var51;
      int var38 = var51;
      if (var52 != 0) {
         int var53 = var38;
         if (var53 > 0) {
            return;
         }

         MinecraftClient var20 = b;
         ClientPlayerEntity var21 = var20.player;
         double var76;
         var39 = (var76 = var21.fallDistance - 1.5) == 0.0 ? 0 : (var76 < 0.0 ? -1 : 1);
      }

      int var55 = var12;
      int var54 = var39;
      int var41 = var54;
      int var40 = var54;
      if (var55 != 0) {
         int var56 = var40;
         if (var56 > 0) {
            return;
         }

         var41 = this.c;
      }

      int var58 = var12;
      int var57 = var41;
      int var43 = var57;
      int var42 = var57;
      if (var58 != 0) {
         // int var59 = var42;
         if (var59 != var60) {
            return;
         }

         MinecraftClient var24 = b;
         ClientPlayerEntity var25 = var24.player;
         Object[] var26 = new Object[]{var25.getMainHandStack(), 19476550655932L};
         byte var61 = ((byte)((InventoryUtil.aReturningBoolean(var26)) ? 1 : 0));
         var43 = var61;
      }

      int var63 = var12;
      int var62 = var43;
      int var45 = var62;
      int var44 = var62;
      if (var63 != 0) {
         int var64 = var44;
         if (var64 == 0) {
            return;
         }

         Object[] var29 = new Object[]{49487520630543L};
         this.c = InventoryUtil.aReturningInt(var29);
         Object[] var31 = new Object[]{122970056805471L};
         BreachSwap var30 = this;
         int var65 = var30.aReturningInt(var31);
         var45 = var65;
      }

      int var13 = var45;
      int var67 = var12;
      int var66 = var13;
      int var47 = var66;
      int var46 = var66;
      if (var67 != 0) {
         // int var68 = var46;
         if (var68 == var69) {
            return;
         }

         int var70 = var13;
         var47 = var70;
      }

      Object[] var10003 = new Object[]{null, 72518082610550L};
      var10003[0] = var47;
      Object[] var35 = var10003;
      InventoryUtil.aReturningVoid(var35);
      this.d = 1;
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 116616137152979L ^ 6429530641804L;
      var10001 = 116616137152979L ^ 78125345578716L;
      var10001 = 116616137152979L ^ 48359752850597L;
      var10001 = 116616137152979L ^ 136036437722735L;
      int var12 = Event.bReturningInt();
      Random var14 = RandomUtil.a;
      float var10000 = var14.nextFloat() * 100.0F;
      FloatSetting var15 = this.a;
      Float var16 = (Float)var15.aReturningObject();
      float var75;
      int var71 = (var75 = var10000 - var16) == 0.0F ? 0 : (var75 < 0.0F ? -1 : 1);
      int var49 = var12;
      int var48 = var71;
      int var37 = var48;
      int var36 = var48;
      if (var49 == 0) {
         int var50 = var36;
         if (var50 > 0) {
            this.d = 1;
         }

         var37 = this.d;
      }

      int var52 = var12;
      int var51 = var37;
      int var39 = var51;
      int var38 = var51;
      if (var52 == 0) {
         int var53 = var38;
         if (var53 > 0) {
            return;
         }

         MinecraftClient var20 = b;
         ClientPlayerEntity var21 = var20.player;
         double var76;
         var39 = (var76 = var21.fallDistance - 1.5) == 0.0 ? 0 : (var76 < 0.0 ? -1 : 1);
      }

      int var55 = var12;
      int var54 = var39;
      int var41 = var54;
      int var40 = var54;
      if (var55 == 0) {
         int var56 = var40;
         if (var56 > 0) {
            return;
         }

         var41 = this.c;
      }

      int var58 = var12;
      int var57 = var41;
      int var43 = var57;
      int var42 = var57;
      if (var58 == 0) {
         // int var59 = var42;
         if (var59 != var60) {
            return;
         }

         MinecraftClient var24 = b;
         ClientPlayerEntity var25 = var24.player;
         Object[] var26 = new Object[]{var25.getMainHandStack(), 19476550655932L};
         byte var61 = ((byte)((InventoryUtil.aReturningBoolean(var26)) ? 1 : 0));
         var43 = var61;
      }

      int var63 = var12;
      int var62 = var43;
      int var45 = var62;
      int var44 = var62;
      if (var63 == 0) {
         int var64 = var44;
         if (var64 == 0) {
            return;
         }

         Object[] var29 = new Object[]{49487520630543L};
         this.c = InventoryUtil.aReturningInt(var29);
         Object[] var31 = new Object[]{122970056805471L};
         BreachSwap var30 = this;
         int var65 = var30.aReturningInt(var31);
         var45 = var65;
      }

      int var13 = var45;
      int var67 = var12;
      int var66 = var13;
      int var47 = var66;
      int var46 = var66;
      if (var67 == 0) {
         // int var68 = var46;
         if (var68 == var69) {
            return;
         }

         int var70 = var13;
         var47 = var70;
      }

      Object[] var10003 = new Object[]{null, 72518082610550L};
      var10003[0] = var47;
      Object[] var35 = var10003;
      InventoryUtil.aReturningVoid(var35);
      this.d = 1;
   }

   public int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127337207808121L ^ var2;
      long var4 = var2 ^ 24832239650148L;
      long var6 = var2 ^ 87266989837632L;
      int var10000 = Event.cReturningInt();
      ArrayList var9 = new ArrayList();
      int var8 = var10000;

      byte var36;
      while (true) {
         int var43 = (int)l;
         int var42 = var10;
         if (var42 <= var43) {
            MinecraftClient var15 = b;
            ClientPlayerEntity var16 = var15.player;
            PlayerInventory var62 = var16.getInventory();
            int var18 = var10;
            PlayerInventory var17 = var62;
            Object[] var19 = new Object[]{var17.getStack(var18), var6};
            byte var63 = ((byte)((InventoryUtil.o(var19)) ? 1 : 0));
            int var45 = var8;
            byte var44 = var63;
            var36 = var44;
            byte var32 = var44;
            if (var45 == 0) {
               break;
            }

            int var47 = var8;
            byte var46 = var32;
            byte var33 = var46;
            if (var47 != 0) {
               byte var48 = var33;
               byte var34 = var48;
               byte var49 = var34;
               if (var49 != 0) {
                  int var22 = var10;
                  Integer var24 = var22;
                  ArrayList var23 = var9;
                  boolean var50 = var23.add(var24);
               }
            }

            var10++;
            int var51 = var8;
            if (var51 != 0) {
               continue;
            }
         }

         var10 = -1;
         var36 = -1;
         break;
      }

      int var11 = var36;
      ArrayList var26 = var9;
      Iterator var12 = var26.iterator();

      int var41;
      while (true) {
         Iterator var27 = var12;
         boolean var52 = var27.hasNext();
         if (var52) {
            Iterator var28 = var12;
            Integer var29 = (Integer)var28.next();
            int var13 = var29;
            Object[] var10004 = new Object[]{null, var4};
            var10004[0] = var13;
            Object[] var31 = var10004;
            BreachSwap var30 = this;
            int var14 = var30.cReturningInt(var31);
            int var54 = var8;
            int var53 = var14;
            var41 = var53;
            int var37 = var53;
            if (var54 == 0) {
               break;
            }

            label34: {
               int var56 = var8;
               int var55 = var37;
               int var40 = var55;
               int var38 = var55;
               if (var56 != 0) {
                  int var57 = var38;
                  int var39 = var57;
                  int var59 = var10;
                  int var58 = var39;
                  if (var58 <= var59) {
                     break label34;
                  }

                  var10 = var14;
                  var40 = var13;
               }

               var11 = var40;
            }

            int var60 = var8;
            if (var60 != 0) {
               continue;
            }
         }

         var41 = var11;
         break;
      }

      return var41;
   }

   public int cReturningInt(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 127337207808121L ^ var2;
      int var32 = Event.cReturningInt();
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      PlayerInventory var10001 = var9.getInventory();
      int var11 = var4;
      PlayerInventory var10 = var10001;
      ItemStack var6 = var10.getStack(var11);
      int var5 = var32;
      int var29 = var5;
      ItemStack var28 = var6;
      Object var27 = var28;
      ItemStack var26 = var28;
      if (var29 != 0) {
         ItemStack var30 = var26;
         if (var30 == null) {
            return 0;
         }

         MinecraftClient var13 = b;
         ClientWorld var14 = var13.world;
         DynamicRegistryManager var33 = var14.getRegistryManager();
         RegistryKey var15 = Enchantments.BREACH;
         RegistryKey var17 = var15.getRegistryRef();
         DynamicRegistryManager var16 = var33;
         Optional var18 = var16.getOptional(var17);
         Registry var34 = (Registry)var18.get();
         RegistryKey var19 = Enchantments.BREACH;
         Identifier var21 = var19.getValue();
         Registry var20 = var34;
         Optional var22 = var20.getEntry(var21);
         Object var31 = var22.get();
         var27 = var31;
      }

      RegistryEntry var35 = (RegistryEntry)var27;
      ItemStack var25 = var6;
      RegistryEntry var24 = var35;
      float var7 = EnchantmentHelper.getLevel(var24, var25);
      return (int)var7;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(118570957022933L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 1206962591843628409L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)16L,
            (byte)4287L,
            (byte)1097726L,
            (byte)281017877L,
            (byte)71940576544L,
            (byte)18416787595270L,
            (byte)4714697624389173L,
            (byte)1206962591843628409L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 40;
            yield var15;
         }
         case 1 -> {
            byte var16 = 23;
            yield var16;
         }
         case 2 -> {
            byte var17 = 25;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 19;
            yield var19;
         }
         case 5 -> {
            byte var20 = 4;
            yield var20;
         }
         case 6 -> {
            byte var21 = 38;
            yield var21;
         }
         case 7 -> {
            byte var22 = 48;
            yield var22;
         }
         case 8 -> {
            byte var23 = 52;
            yield var23;
         }
         case 9 -> {
            byte var24 = 22;
            yield var24;
         }
         case 10 -> {
            byte var25 = 58;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 45;
            yield var27;
         }
         case 13 -> {
            byte var28 = 16;
            yield var28;
         }
         case 14 -> {
            byte var29 = 46;
            yield var29;
         }
         case 15 -> {
            byte var30 = 54;
            yield var30;
         }
         case 16 -> {
            byte var31 = 29;
            yield var31;
         }
         case 17 -> {
            byte var32 = 49;
            yield var32;
         }
         case 18 -> {
            byte var33 = 30;
            yield var33;
         }
         case 19 -> {
            byte var34 = 15;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 24;
            yield var36;
         }
         case 22 -> {
            byte var37 = 53;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 18;
            yield var39;
         }
         case 25 -> {
            byte var40 = 20;
            yield var40;
         }
         case 26 -> {
            byte var41 = 34;
            yield var41;
         }
         case 27 -> {
            byte var42 = 8;
            yield var42;
         }
         case 28 -> {
            byte var43 = 27;
            yield var43;
         }
         case 29 -> {
            byte var44 = 63;
            yield var44;
         }
         case 30 -> {
            byte var45 = 21;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 13;
            yield var47;
         }
         case 33 -> {
            byte var48 = 10;
            yield var48;
         }
         case 34 -> {
            byte var49 = 17;
            yield var49;
         }
         case 35 -> {
            byte var50 = 56;
            yield var50;
         }
         case 36 -> {
            byte var51 = 33;
            yield var51;
         }
         case 37 -> {
            byte var52 = 12;
            yield var52;
         }
         case 38 -> {
            byte var53 = 32;
            yield var53;
         }
         case 39 -> {
            byte var54 = 62;
            yield var54;
         }
         case 40 -> {
            byte var55 = 50;
            yield var55;
         }
         case 41 -> {
            byte var56 = 36;
            yield var56;
         }
         case 42 -> {
            byte var57 = 39;
            yield var57;
         }
         case 43 -> {
            byte var58 = 6;
            yield var58;
         }
         case 44 -> {
            byte var59 = 0;
            yield var59;
         }
         case 45 -> {
            byte var60 = 35;
            yield var60;
         }
         case 46 -> {
            byte var61 = 51;
            yield var61;
         }
         case 47 -> {
            byte var62 = 1;
            yield var62;
         }
         case 48 -> {
            byte var63 = 37;
            yield var63;
         }
         case 49 -> {
            byte var64 = 57;
            yield var64;
         }
         case 50 -> {
            byte var65 = 41;
            yield var65;
         }
         case 51 -> {
            byte var66 = 31;
            yield var66;
         }
         case 52 -> {
            byte var67 = 11;
            yield var67;
         }
         case 53 -> {
            byte var68 = 28;
            yield var68;
         }
         case 54 -> {
            byte var69 = 60;
            yield var69;
         }
         case 55 -> {
            byte var70 = 26;
            yield var70;
         }
         case 56 -> {
            byte var71 = 59;
            yield var71;
         }
         case 57 -> {
            byte var72 = 14;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 3;
            yield var74;
         }
         case 60 -> {
            byte var75 = 43;
            yield var75;
         }
         case 61 -> {
            byte var76 = 9;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 55;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "PR}nFB[]l!!@NVlj\u001a";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "9{@/D?/{EuW(80Fs[<)wQd\u0010,2";
      m[3] = "\u0013%\b k~f\u0005\u0003/z1\u0007\u000b\b$~ks";
      m[4] = boolean.class;
      n[4] = "java/lang/Boolean";
      m[5] = "-^\fo\u0003L-^\u001b3\u000fC7\u0015\u001b-\u000fV0dOuX";
      m[6] = "\u0014J,@ir\u0014J;\u001ce}\u000e\u0001;\u0002eh\tpiX2*";
      m[7] = "/mQ\u000bng1eKD\f{6x";
      m[8] = "\n\")Y:*\u0014*3\u0016]+\u00051>L{-";
      m[9] = "\u0017wU+lU\u0001wPq\u007fB\u0016<SwsV\u0007{D`8D6";
      m[10] = "\u0018Z\u0012>(\u0013\u0018Z\u0005b$\u001c\u0002\u0011\u0005|$\t\u0005`W'|C";
      m[11] = "9\u0004IV1i2\u000bX\u0019Pg9\u0000\\C";
      m[12] = "A\u0006@\u0017vEA\u0006WKzJ[MWUz_\\<\u0007\b+";
      m[13] = "\u000ew\u001c,Xb\u0018w\u0019vKu\u000f<\u001apGa\u001e{\rg\fw\u0005";
      m[14] = "\r=zRUZ\u00062k\u001d6W\u0013?dv\u0003U\u0002,xZ\u0014X";
      m[15] = "\fU't\u0012cyu,{\u0003,\u0018{'p\u0007vl";
      m[16] = double.class;
      n[16] = "java/lang/Double";
      m[17] = "ct\u000e7}2\u0016T\u00058l}wZ\u000e3h'\u0003";
      m[18] = void.class;
      n[18] = "java/lang/Void";
      m[19] = ".wS\u001dX\r[WX\u0012IB:YS\u0019M\u0018N";
      m[20] = "/~Vf?\u00169~S<,\u0001.5P: \u0015?rG-k\u0002\r";
      m[21] = "yYMm3WrV\\\"[W|YO";
      m[22] = float.class;
      n[22] = "java/lang/Float";
      m[23] = "] '3cP(\u0000,<r\u001fI\u000e'7vE=";
      m[24] = "\u0006\u001a\u0017s\u0007\u0005\u0018\u0012\r<{\u0011\u0002\u001f\u000e\u007f";
      m[25] = ";do}JDNDdr[\u000b/Joy_Q[";
      m[26] = "<\u0015\u0017)MG<\u0015\u0000uAH&^\u0000kA]!/V3\u0015\u001b";
      m[27] = "HkS\u001e\u000b HkDB\u0007/R D\\\u0007:UQ\u0012\u0003Tx";
      m[28] = "\u000ev\u000fG'E\u0010~\u0015\bF@\u0010~\u0016Hh\\";
      m[29] = "m0K\u007fl\fm0\\#`\u0003w{\\=`\u0016p\n\u000ei8V";
      m[30] = "\u0012W\u0006X&X\u0012W\u0011\u0004*W\b\u001c\u0011\u001a*B\u000fmDEs";
      m[31] = "Kz\u001cmS)Kz\u000b1_&Q1\u000b/_3V@Zz\bp";
      m[32] = "\u001f,\bJ0 \u001f,\u001f\u0016</\u0005g\u001f\b<:\u0002\u0016NWjq";
      m[33] = "\u000e}V&j6\u000e}Azf9\u00146Adf,\u0013G\u00130>o";
      m[34] = "\u0006\u0002z\u00153Q\u0006\u0002mI?^\u001cImW?K\u001b88\u0003f\b";
      m[35] = "\u001d}d52'\u0003u~zO7\u0003";
      m[36] = "b\u000bpp*\"#\u00075c\u00112\\\\umo3;\u001f2maX";
      m[37] = "'W*4[A$Boc<\u001cqZ19P.'\u001flb\fy \u001b+eD\u0007uO.n<";
      m[38] = ",05\\C=/%p\u000b$kv,*Zs;/xq6Nh)..\u0007\u001f{p ";
      m[39] = "\u0001\u0015e\u001a{PJD2\u0016\nR8\u0014p\u0002uD\u0002\fo\u0016u;TOvHaIQ\u001a~\t\n";
      m[40] = "\u0011<W'^\u0016\u00197\u0002.1\t\u0018Z[xNV\u0018#S;J\u0015v=\ru_\u0001\u000e5\u0006 Vn";
      m[41] = "G\u001f,(Wn\u0010\u000f<x*w\u0006\u00107qVq\u0000}p\u007fIk\u0003F)\"\u0013qz";
      m[42] = "M\n\bnb}\f\u0006M}Yls]\rs'l\u0014\u001eJs)\u0007";
      m[43] = "\u001d)\u001a\u0016V=\u0003hR\u0016(*\u0011l\u0002\u001bD\u0018@.]A\u0019O\u001do\b\u0015\u0013.L`\t\u001f(,F,\u001aC\u00122\u001a|\u0013|";
      m[44] = "\u0018Od-e_\u0015Fp0\u0018\f\u001aO}$O_C\u001b$x\u0018\u0003\u0004HpsyR\u000bIz";
      m[45] = "jWI\b\"-\u007f\rI\t\u001a,c\u001aI\fv\u001e5^\u0012W+Io_Q\u0001d;q\u001e\u0019\u0001\u001a";
      m[46] = "_{v\u0010aK\u0002\"v.8\u0016\u001a\u001avJ$\u001df}'_'\u001b\u0001>`_)p";
      m[47] = "-%\u0002Sa\u0014)lWQ]A@.VWeF9&\u0015S&(";
      m[48] = "Us<S\u0005L\f.fI|\u0011\u0005d#.LF\u0017,1WD\u0005\u0013o_";
      m[49] = "q/^t\u0001\fqxSb?[ )Veh\f~~\u000e\t\u0004D:.U1\u0007Q\u007fy";
      m[50] = "g!\t\u0010\u0013+,p^\u001cb)^ \u001c\b\u001d?d8\u0003\u001c\u001d@gx\u0013\r\t'$?\u0013\u0003b";
      m[51] = "UQ\u0010fy!_\u0007\u00025@.dW\u0011r?:^O\u000ef?E]\u000f\u001ew+\"\u001eH\u001ey@";
      m[52] = "A$\u001a2`\u0005^o\u000e1\f\u0001Ii\u0015l`3\u001d-O17dA.\u0011g2\u0001_sOg\f\u0007\u001e)\r46\u0019By\u0004\u000b";
      m[53] = "\u0017mNoG6N0\u0014u>mCqk\u007fNq*1\u0011k_iEn\u0016\"\u000e\r";
      m[54] = "5\u0019H\u0013\\<i\u001e\u0017H,`>\fLI@RcJ\u0016\u0013,c/\u0012E\u001f\u001cj7\u0002W.\u0012u3\u0019@P\u0014w\"\u001e,\u0017\u0014t-\u001bKTSt#p";
      m[55] = "\u001d-_#$\u0001@t_\u001dbS@o[Zr:\u001d*Gcw]^mGm\u001c\u0003\u001b{\b%'^B{6";
      m[56] = "=Gzvaov\u0016-z\u0010c\u0004Fono{>^pzo\u0004?\u001ahttk`\u001d!%\u0010";
      m[57] = "L:\b_\u0017\bO/M\bpU\u001a7\u0013R\u001cgIsO\np\u000e\u0007+\u001aY\u000e\b\u0005:\u001d5";
      m[58] = "E\b\u0001n@s\u0010\\\u0004e8h\u0014I\u001b2TZD\t@e84AD\u0005>_w\u0006D\u000bU\u0006}\u0019\\\u0017+\u0000\u007f\b[{";
      m[59] = "4Y+\u001e0@cI;NMQeWJ\u001e|G1U3\u0016?Cr;q\u00124YmT.\u0015}\b\t";
      m[60] = "dYDAbqd\u000eIW\\&5_LP\u000bqj\u0002\u0017<8y4Q\u0010X-#4P";
      m[61] = "2;uxR58mg+k8\u0003=tl\u0014.9%kx\u0014Q:e{i\u00006y\"{gk";
      m[62] = "kL\f-@LvJ\u00117)\u0019bH\b(w\u001ebR\fTG\u0014>\u001f_>\u0019NjNa";
      m[63] = "\rBN\u0013P\u001b\u0007\u0014\\@i\u0016<M\u0000\u0019Q\u001c_Y_\u0006\u0015\u007fU\u0015TD\n\u001cAJK\u0000i";
      m[64] = "?8\u001fVj\u0018n7\u001e\\Q\u001c3;\u0015X=.dvL\u0000ny;|\u0011So\u001c%!OSQ";
      m[65] = "TF\"nU\u000eJ\u001argj[Z\u0000\u001e&[K\u000f\u0012g.\u0018OL|";
      m[66] = ")P K\u007f.)Bq\u0016Bt+]2g&u/QNG!*v\u0013$\u0019{~'-";
      m[67] = "u\u00197\u0011{!>H`\u001d\n#L\u0018\"\tu5v\u0000=\u001duJwD%\u0013n%(ClB\n";
      m[68] = ":\u0016dV\fWk\u0019e\\7S6\u0015nX[afY4\u0000\f6:\u0016dV\fWk\u0019e\\7";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(840378246474556L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(840378246474556L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(840378246474556L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 80;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 109;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 116;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 77;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 236;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 203;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 80;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 109;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 116;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eo_C0246",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eo" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
