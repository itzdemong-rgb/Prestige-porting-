package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.modules.state.CartAuraPlacementTime;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;

public class CartAura extends Module implements RotationSource {
   private MinMaxSetting a;
   private FloatSetting c;
   private BooleanSetting d;
   private FloatSetting e;
   private MinMaxSetting f;
   private FloatSetting g;
   private BooleanSetting h;
   private ElapsedTimer i;
   private ElapsedTimer j;
   private ElapsedTimer k;
   private ElapsedTimer l;
   private List m;
   private TntMinecartEntity n;
   private int o;
   private int p;
   private static final long q = 109655161439597L;
   private static final long[] r;
   private static final Integer[] s;
   private static final Map t = new HashMap(13);
   private static final long[] u;
   private static final Long[] v;
   private static final Map w;
   private static final Object[] x = new Object[161];
   private static final String[] y = new String[161];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public CartAura() {
      super();
      long var10001 = 77816924086395L ^ 43760175159122L;
      var10001 = 77816924086395L ^ 98616621175468L;

      this.i = new ElapsedTimer(106698256430889L);
      this.j = new ElapsedTimer(106698256430889L);
      this.k = new ElapsedTimer(106698256430889L);
      this.l = new ElapsedTimer(106698256430889L);
      this.m = new ArrayList();
      this.o = -1;
      this.p = 0;
      FloatSetting var10000 = this.e;
      Object[] var8 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var7 = var10000;
      var7.aReturningFloatSetting(var8);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 122895271667877L ^ 62713483831687L;
      int var10000 = Event.bReturningInt();
      Object[] var13 = new Object[0];
      PacketSendEvent var12 = var1;
      Packet var8 = var12.aReturningVoid(var13);
      int var6 = var10000;
      int var36 = var6;
      Packet var35 = var8;
      Packet var33 = var35;
      Packet var32 = var35;
      if (var36 == 0) {
         boolean var37 = var32 instanceof PlayerInteractBlockC2SPacket;
         if (!var37) {
            return;
         }

         Packet var38 = var8;
         var33 = var38;
      }

      PlayerInteractBlockC2SPacket var7 = (PlayerInteractBlockC2SPacket)var33;
      PlayerInteractBlockC2SPacket var16 = var7;
      Hand var44 = var16.getHand();
      Hand var18 = Hand.MAIN_HAND;
      Hand var17 = var44;
      boolean var39 = var17.equals(var18);
      ItemStack var34;
      if (var39) {
         MinecraftClient var19 = b;
         ClientPlayerEntity var20 = var19.player;
         ItemStack var40 = var20.getMainHandStack();
         var34 = var40;
      } else {
         MinecraftClient var22 = b;
         ClientPlayerEntity var23 = var22.player;
         var34 = var23.getOffHandStack();
      }

      ItemStack var43 = var34;
      ItemStack var24 = var43;
      Item var45 = var24.getItem();
      Item var42 = Items.TNT_MINECART;
      Item var41 = var45;
      if (var41 == var42) {
         PlayerInteractBlockC2SPacket var25 = var7;
         BlockHitResult var9 = var25.getBlockHitResult();
         long var10 = System.currentTimeMillis();
         List var46 = this.m;
         BlockHitResult var26 = var9;
         CartAuraPlacementTime var28 = new CartAuraPlacementTime(var26.getBlockPos(), var10);
         List var27 = var46;
         var27.add(var28);
         List var47 = this.m;
         Object[] var29 = new Object[]{var9, 95435648532770L};
         CartAuraPlacementTime var31 = new CartAuraPlacementTime(BlockUtil.aReturningBlockPos(var29), var10);
         List var30 = var47;
         var30.add(var31);
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      List var4 = this.m;
      var4.clear();
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 73608466808436L;
      long var6 = var2 ^ 10830563835490L;
      long var8 = var2 ^ 138007752420630L;
      long var10 = var2 ^ 33314122327210L;
      long var12 = var2 ^ 86497911947606L;
      long var14 = var2 ^ 82878281429531L;
      long var16 = var2 ^ 155943898136L;
      long var18 = var2 ^ 132457417592780L;
      long var20 = var2 ^ 26344595102870L;
      long var22 = var2 ^ 79826977404973L;
      long var24 = var2 ^ 87666872358447L;
      long var26 = var2 ^ 29159961624672L;
      long var28 = var2 ^ 77379818547405L;
      long var30 = var2 ^ 19182256418671L;
      long var32 = var2 ^ 101783648619701L;
      long var34 = var2 ^ 100729554575240L;
      long var36 = var2 ^ 50331604023260L;
      int var38 = Event.bReturningInt();
      int var235 = var38;
      if (var235 == 0) {
         MinecraftClient var42 = b;
         ClientPlayerEntity var236 = var42.player;
         if (var236 != null) {
            MinecraftClient var44 = b;
            ClientWorld var237 = var44.world;
            if (var237 != null) {
               int var239 = var38;
               int var238 = this.p;
               int var186 = var238;
               int var182 = var238;
               if (var239 == 0) {
                  byte var241 = 2;
                  int var240 = var182;
                  if (var240 == var241) {
                     int var243 = var38;
                     CartAura var242 = this;
                     CartAura var185 = var242;
                     CartAura var183 = var242;
                     if (var243 == 0) {
                        CartAura var244 = var183;
                        CartAura var184 = var244;
                        ElapsedTimer var348 = var184.k;
                        FloatSetting var51 = this.e;
                        Float var52 = (Float)var51.aReturningObject();
                        float var350 = var52;
                        Object[] var352 = new Object[]{null, var4};
                        var352[0] = var350;
                        Object[] var54 = var352;
                        ElapsedTimer var53 = var348;
                        boolean var245 = var53.aReturningBoolean(var54);
                        if (!var245) {
                           return null;
                        }

                        CartAura var246 = this;
                        var185 = var246;
                     }

                     Object[] var58 = new Object[]{var10};
                     CartAura var57 = var185;
                     var57.jReturningVoid(var58);
                     return null;
                  }

                  MinecraftClient var59 = b;
                  ClientPlayerEntity var60 = var59.player;
                  var186 = (((var60.isUsingItem()) ? 1 : 0));
               }

               int var248 = var38;
               int var247 = var186;
               int var188 = var247;
               int var187 = var247;
               if (var248 == 0) {
                  int var249 = var187;
                  if (var249 != 0) {
                     return null;
                  }

                  var188 = (((AutoObbyCrystal.R) ? 1 : 0));
               }

               int var251 = var38;
               int var250 = var188;
               int var190 = var250;
               int var189 = var250;
               if (var251 == 0) {
                  int var252 = var189;
                  if (var252 != 0) {
                     return null;
                  }

                  RotationManager var10000 = Prestige.o;
                  Object[] var66 = new Object[0];
                  RotationManager var65 = var10000;
                  var190 = (((var65.fReturningBoolean(var66)) ? 1 : 0));
               }

               int var253 = var190;
               if (var253 != 0) {
                  return null;
               }

               int var255 = var38;
               TntMinecartEntity var254 = this.n;
               TntMinecartEntity var196 = var254;
               TntMinecartEntity var191 = var254;
               if (var255 == 0) {
                  TntMinecartEntity var256 = var191;
                  label238:
                  if (var256 != null) {
                     CartAura var195;
                     Object[] var70 = new Object[]{this.n, var16};
                     CartAura var69 = this;
                     Vec3d var39 = var69.aReturningVec3d(var70);
                     int var258 = var38;
                     CartAura var257 = this;
                     var195 = var257;
                     CartAura var192 = var257;
                     label244:
                     if (var258 == 0) {
                        TntMinecartEntity var71 = var192.n;
                        boolean var259 = var71.isAlive();
                        if (var259) {
                           int var261 = var38;
                           CartAura var260 = this;
                           var195 = var260;
                           CartAura var193 = var260;
                           if (var261 != 0) {
                              break label244;
                           }

                           CartAura var262 = var193;
                           CartAura var194 = var262;
                           Object[] var75 = new Object[]{this.n, var20};
                           CartAura var74 = var194;
                           boolean var263 = var74.aReturningBoolean(var75);
                           if (!var263) {
                              MinecraftClient var77 = b;
                              Vec3d var78 = var39;
                              Vec3d var79 = var39;
                              Vec3d var80 = var39;
                              double var86 = var80.z;
                              double var84 = var79.y;
                              double var82 = var78.x;
                              ClientPlayerEntity var81 = var77.player;
                              double var88 = var81.squaredDistanceTo(var82, var84, var86);
                              double var353;
                              int var264 = (var353 = Math.sqrt(var88) - 5.0) == 0.0 ? 0 : (var353 < 0.0 ? -1 : 1);
                              if (var264 <= 0) {
                                 break label238;
                              }
                           }
                        }

                        CartAura var265 = this;
                        var195 = var265;
                     }

                     var195.n = null;
                  }

                  var196 = this.n;
               }

               CartAura var205;
               label263: {
                  TntMinecartEntity var201;
                  int var267 = var38;
                  TntMinecartEntity var266 = var196;
                  var201 = var266;
                  TntMinecartEntity var197 = var266;
                  label232:
                  if (var267 == 0) {
                     TntMinecartEntity var268 = var197;
                     if (var268 == null) {
                        FloatSetting var93 = this.g;
                        Float var94 = (Float)var93.aReturningObject();
                        float var10002 = var94;
                        Object[] var10005 = new Object[]{null, var22};
                        var10005[0] = var10002;
                        Object[] var96 = var10005;
                        CartAura var95 = this;
                        this.n = var95.aReturningTntMinecartEntity(var96);
                        int var270 = var38;
                        TntMinecartEntity var269 = this.n;
                        var201 = var269;
                        TntMinecartEntity var198 = var269;
                        if (var270 != 0) {
                           break label232;
                        }

                        TntMinecartEntity var271 = var198;
                        TntMinecartEntity var199 = var271;
                        TntMinecartEntity var272 = var199;
                        if (var272 != null) {
                           MinMaxSetting var335 = this.a;
                           Object[] var100 = new Object[]{var24};
                           MinMaxSetting var99 = var335;
                           var99.bReturningVoid(var100);
                           ElapsedTimer var336 = this.i;
                           Object[] var102 = new Object[]{var26};
                           ElapsedTimer var101 = var336;
                           var101.aReturningVoid(var102);
                        }
                     }

                     int var274 = var38;
                     CartAura var273 = this;
                     var205 = var273;
                     CartAura var200 = var273;
                     if (var274 != 0) {
                        break label263;
                     }

                     TntMinecartEntity var275 = var200.n;
                     var201 = var275;
                  }

                  TntMinecartEntity var276 = var201;
                  if (var276 == null) {
                     int var278 = var38;
                     CartAura var277 = this;
                     CartAura var204 = var277;
                     CartAura var202 = var277;
                     if (var278 == 0) {
                        CartAura var279 = var202;
                        CartAura var203 = var279;
                        byte var281 = 1;
                        int var280 = var203.p;
                        if (var280 != var281) {
                           return null;
                        }

                        CartAura var282 = this;
                        var204 = var282;
                     }

                     Object[] var109 = new Object[]{var10};
                     CartAura var108 = var204;
                     var108.jReturningVoid(var109);
                     return null;
                  }

                  var205 = this;
               }

               Rotation var40;
               byte var209;
               Object[] var111 = new Object[]{this.n, var16};
               CartAura var110 = var205;
               Vec3d var334 = var110.aReturningVec3d(var111);
               RotationManager var337 = Prestige.o;
               Object[] var113 = new Object[]{var334, var28};
               RotationManager var112 = var337;
               var40 = var112.aReturningdx_C0210(var113);
               BooleanSetting var114 = this.h;
               Boolean var115 = (Boolean)var114.aReturningObject();
               byte var338 = ((byte)(((java.lang.Boolean)(var115)).booleanValue() ? 1 : 0));
               int var284 = var38;
               byte var283 = var338;
               var209 = var283;
               byte var206 = var283;
               label222:
               if (var284 == 0) {
                  byte var285 = var206;
                  if (var285 != 0) {
                     Object[] var118 = new Object[0];
                     Rotation var117 = var40;
                     byte var339 = ((byte)((var117.aReturningBoolean(var118)) ? 1 : 0));
                     int var287 = var38;
                     byte var286 = var339;
                     var209 = var286;
                     byte var207 = var286;
                     if (var287 != 0) {
                        break label222;
                     }

                     byte var288 = var207;
                     byte var208 = var288;
                     byte var289 = var208;
                     if (var289 == 0) {
                        Object[] var121 = new Object[]{var40, var334, var32};
                        var40 = RotationUtil.dReturningdx_C0210(var121);
                     }
                  }

                  MinecraftClient var122 = b;
                  TntMinecartEntity var124 = this.n;
                  ClientPlayerEntity var123 = var122.player;
                  var209 = ((byte)((var123.canSee((Entity)var124)) ? 1 : 0));
               }

               int var291 = var38;
               byte var290 = var209;
               int var211 = var290;
               byte var210 = var290;
               if (var291 == 0) {
                  byte var292 = var210;
                  if (var292 == 0) {
                     return null;
                  }

                  Object[] var128 = new Object[]{this.n, var18};
                  CartAura var127 = this;
                  double var354;
                  var211 = (var354 = var127.aReturningDouble(var128) - 3.0) == 0.0 ? 0 : (var354 < 0.0 ? -1 : 1);
               }

               int var294 = var38;
               int var293 = var211;
               int var213 = var293;
               int var212 = var293;
               if (var294 == 0) {
                  int var295 = var212;
                  if (var295 > 0) {
                     return null;
                  }

                  ElapsedTimer var340 = this.i;
                  Object[] var132 = new Object[]{this.a, var14};
                  ElapsedTimer var131 = var340;
                  var213 = (((var131.bReturningBoolean(var132)) ? 1 : 0));
               }

               int var297 = var38;
               int var296 = var213;
               int var215 = var296;
               int var214 = var296;
               if (var297 == 0) {
                  int var298 = var214;
                  if (var298 == 0) {
                     return var40;
                  }

                  var215 = this.p;
               }

               int var225;
               label211: {
                  label265: {
                     int var300 = var38;
                     int var299 = var215;
                     int var221 = var299;
                     int var216 = var299;
                     if (var300 == 0) {
                        byte var302 = 1;
                        int var301 = var216;
                        if (var301 == var302) {
                           ElapsedTimer var342 = this.j;
                           FloatSetting var136 = this.c;
                           Float var137 = (Float)var136.aReturningObject();
                           float var10001 = var137;
                           Object[] var10004 = new Object[]{null, var4};
                           var10004[0] = var10001;
                           Object[] var139 = var10004;
                           ElapsedTimer var138 = var342;
                           byte var343 = ((byte)((var138.aReturningBoolean(var139)) ? 1 : 0));
                           int var304 = var38;
                           byte var303 = var343;
                           byte var219 = var303;
                           byte var217 = var303;
                           if (var304 == 0) {
                              byte var305 = var217;
                              byte var218 = var305;
                              byte var306 = var218;
                              if (var306 == 0) {
                                 return var40;
                              }

                              MinecraftClient var143 = b;
                              ClientPlayerEntity var144 = var143.player;
                              Object[] var145 = new Object[]{var144.getMainHandStack(), var36};
                              var219 = ((byte)((InventoryUtil.aReturningBoolean(var145)) ? 1 : 0));
                           }

                           int var308 = var38;
                           byte var307 = var219;
                           var225 = var307;
                           byte var220 = var307;
                           if (var308 != 0) {
                              break label211;
                           }

                           byte var309 = var220;
                           if (var309 == 0) {
                              Object[] var148 = new Object[]{var10};
                              CartAura var147 = this;
                              var147.jReturningVoid(var148);
                              return var40;
                           }
                           break label265;
                        }

                        MinecraftClient var150 = b;
                        ClientPlayerEntity var151 = var150.player;
                        Object[] var152 = new Object[]{var151.getMainHandStack(), var36};
                        var221 = (((InventoryUtil.aReturningBoolean(var152)) ? 1 : 0));
                     }

                     int var311 = var38;
                     int var310 = var221;
                     var225 = var310;
                     int var222 = var310;
                     if (var311 != 0) {
                        break label211;
                     }

                     int var312 = var222;
                     if (var312 == 0) {
                        Object[] var155 = new Object[]{var6};
                        CartAura var154 = this;
                        int var41 = var154.dReturningInt(var155);
                        int var314 = var38;
                        int var313 = var41;
                        int var224 = var313;
                        int var223 = var313;
                        if (var314 == 0) {
                           // int var315 = var223;
                           if (var315 == var316) {
                              return null;
                           }

                           Object[] var158 = new Object[]{var30};
                           this.o = InventoryUtil.aReturningInt(var158);
                           var224 = var41;
                        }

                        Object[] var10003 = new Object[]{null, var8};
                        var10003[0] = var224;
                        Object[] var159 = var10003;
                        InventoryUtil.aReturningVoid(var159);
                        this.p = 1;
                        ElapsedTimer var341 = this.j;
                        Object[] var161 = new Object[]{var26};
                        ElapsedTimer var160 = var341;
                        var160.aReturningVoid(var161);
                        return var40;
                     }
                  }

                  ElapsedTimer var344 = this.l;
                  Object[] var163 = new Object[]{this.f, var14};
                  ElapsedTimer var162 = var344;
                  var225 = (((var162.bReturningBoolean(var163)) ? 1 : 0));
               }

               int var318 = var38;
               int var317 = var225;
               int var227 = var317;
               int var226 = var317;
               if (var318 == 0) {
                  int var319 = var226;
                  if (var319 == 0) {
                     return var40;
                  }

                  Object[] var167 = new Object[0];
                  Rotation var166 = var40;
                  var227 = (((var166.aReturningBoolean(var167)) ? 1 : 0));
               }

               int var321 = var38;
               int var320 = var227;
               int var229 = var320;
               int var228 = var320;
               if (var321 == 0) {
                  int var322 = var228;
                  if (var322 != 0) {
                     return var40;
                  }

                  Object[] var170 = new Object[]{this.n, var34};
                  ItemUseUtil.aReturningVoid(var170);
                  ElapsedTimer var345 = this.l;
                  Object[] var172 = new Object[]{var26};
                  ElapsedTimer var171 = var345;
                  var171.aReturningVoid(var172);
                  MinMaxSetting var346 = this.f;
                  Object[] var174 = new Object[]{var24};
                  MinMaxSetting var173 = var346;
                  var173.bReturningVoid(var174);
                  var229 = this.p;
               }

               CartAura var234;
               label267: {
                  int var324 = var38;
                  int var323 = var229;
                  int var233 = var323;
                  int var230 = var323;
                  if (var324 == 0) {
                     byte var326 = 1;
                     int var325 = var230;
                     if (var325 != var326) {
                        return var40;
                     }

                     int var328 = var38;
                     CartAura var327 = this;
                     var234 = var327;
                     CartAura var231 = var327;
                     if (var328 != 0) {
                        break label267;
                     }

                     CartAura var329 = var231;
                     CartAura var232 = var329;
                     BooleanSetting var177 = var232.d;
                     Boolean var178 = (Boolean)var177.aReturningObject();
                     byte var330 = ((byte)(((java.lang.Boolean)(var178)).booleanValue() ? 1 : 0));
                     var233 = var330;
                  }

                  int var331 = var233;
                  if (var331 != 0) {
                     short var349 = 10096;
                     long var351 = 7534327203291348333L ^ var2;
                     this.p = 2;
                     ElapsedTimer var347 = this.k;
                     Object[] var181 = new Object[]{var26};
                     ElapsedTimer var180 = var347;
                     var180.aReturningVoid(var181);
                     int var332 = var38;
                     if (var332 == 0) {
                        return var40;
                     }
                  }

                  this.o = -1;
                  CartAura var333 = this;
                  var234 = var333;
               }

               var234.p = 0;
               return var40;
            }
         }

         Object[] var47 = new Object[]{var12};
         CartAura var46 = this;
         var46.kReturningVoid(var47);
      }

      return null;
   }

   private TntMinecartEntity aReturningTntMinecartEntity(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 109655161439597L ^ var2;
      long var5 = var2 ^ 47302364934488L;
      long var7 = var2 ^ 66885163426262L;
      long var9 = var2 ^ 52928803489489L;
      long var11 = var2 ^ 126764358513613L;
      int var13 = Event.cReturningInt();
      MinecraftClient var27 = b;
      ClientWorld var85 = var27.world;
      if (var85 == null) {
         return null;
      }

      long var14 = System.currentTimeMillis();
      List var10000 = this.m;
      Predicate var30 = invokeBinding2(var14);
      List var29 = var10000;
      var29.removeIf(var30);
      TntMinecartEntity var16 = null;
      double var17 = Double.MAX_VALUE;
      MinecraftClient var31 = b;
      ClientPlayerEntity var32 = var31.player;
      float var10002 = var32.getYaw();
      MinecraftClient var33 = b;
      ClientPlayerEntity var34 = var33.player;
      Rotation var19 = new Rotation(var10002, var34.getPitch());
      MinecraftClient var35 = b;
      ClientWorld var36 = var35.world;
      Iterable var37 = var36.getEntities();
      Iterator var20 = var37.iterator();

      while (true) {
         Iterator var38 = var20;
         boolean var86 = var38.hasNext();
         if (!var86) {
            break;
         }

         Iterator var39 = var20;
         Entity var21 = (Entity)var39.next();
         int var88 = var13;
         Entity var87 = var21;
         Entity var69 = var87;
         Entity var68 = var87;
         if (var88 != 0) {
            boolean var89 = var68 instanceof TntMinecartEntity;
            if (!var89) {
               continue;
            }

            var69 = var21;
         }

         TntMinecartEntity var22;
         CartAura var74;
         TntMinecartEntity var75;
         label85: {
            var22 = (TntMinecartEntity)var69;
            TntMinecartEntity var41 = var22;
            boolean var114 = var41.isAlive();
            int var91 = var13;
            boolean var90 = var114;
            boolean var73 = var90;
            boolean var70 = var90;
            if (var91 != 0) {
               boolean var92 = var70;
               if (!var92) {
                  continue;
               }

               int var95 = var13;
               TntMinecartEntity var94 = var22;
               CartAura var93 = this;
               var74 = var93;
               var75 = var94;
               CartAura var71 = var93;
               TntMinecartEntity var72 = var94;
               if (var95 == 0) {
                  break label85;
               }

               Object[] var44 = new Object[]{var72, var7};
               CartAura var43 = var71;
               boolean var96 = var43.aReturningBoolean(var44);
               var73 = var96;
            }

            boolean var97 = var73;
            if (var97) {
               continue;
            }

            var75 = var22;
            var74 = this;
         }

         Object[] var47 = new Object[]{var75, var5};
         CartAura var46 = var74;
         Vec3d var23 = var46.aReturningVec3d(var47);
         MinecraftClient var48 = b;
         Vec3d var49 = var23;
         Vec3d var50 = var23;
         Vec3d var51 = var23;
         double var57 = var51.z;
         double var55 = var50.y;
         double var53 = var49.x;
         ClientPlayerEntity var52 = var48.player;
         double var24 = var52.squaredDistanceTo(var53, var55, var57);
         double var59 = var24;
         double var120;
         int var115 = (var120 = Math.sqrt(var59) - 5.0) == 0.0 ? 0 : (var120 < 0.0 ? -1 : 1);
         int var99 = var13;
         int var98 = var115;
         int var77 = var98;
         int var76 = var98;
         if (var99 != 0) {
            int var100 = var76;
            if (var100 > 0) {
               continue;
            }

            float var121;
            var77 = (var121 = var4 - 360.0F) == 0.0F ? 0 : (var121 < 0.0F ? -1 : 1);
         }

         label69: {
            double var83;
            label87: {
               int var82;
               int var102 = var13;
               int var101 = var77;
               var82 = var101;
               int var78 = var101;
               label67:
               if (var102 != 0) {
                  int var103 = var78;
                  if (var103 < 0) {
                     Vec3d var63 = var23;
                     float var116 = (float)var63.x;
                     Vec3d var64 = var23;
                     float var10001 = (float)var64.y;
                     Vec3d var65 = var23;
                     var10002 = (float)var65.z;
                     Object[] var10005 = new Object[]{null, null, null, var9};
                     var10005[2] = var10002;
                     var10005[1] = var10001;
                     var10005[0] = var116;
                     Object[] var66 = var10005;
                     Rotation var26 = RotationUtil.bReturningdx_C0210(var66);
                     var10005 = new Object[]{null, null, null, var11};
                     var10005[2] = var4;
                     var10005[1] = var26;
                     var10005[0] = var19;
                     Object[] var67 = var10005;
                     byte var117 = ((byte)((RotationUtil.fReturningBoolean(var67)) ? 1 : 0));
                     int var105 = var13;
                     byte var104 = var117;
                     var82 = var104;
                     byte var79 = var104;
                     if (var105 == 0) {
                        break label67;
                     }

                     byte var106 = var79;
                     if (var106 == 0) {
                        continue;
                     }
                  }

                  int var109 = var13;
                  double var107 = var24;
                  var83 = var107;
                  double var80 = var107;
                  if (var109 == 0) {
                     break label87;
                  }

                  double var122;
                  int var110 = (var122 = var80 - var17) == 0.0 ? 0 : (var122 < 0.0 ? -1 : 1);
                  var82 = var110;
               }

               int var111 = var82;
               if (var111 >= 0) {
                  break label69;
               }

               var16 = var22;
               var83 = var24;
            }

            var17 = var83;
         }

         int var112 = var13;
         if (var112 == 0) {
            break;
         }
      }

      return var16;
   }

   private boolean aReturningBoolean(Object[] var1) {
      TntMinecartEntity var4 = (TntMinecartEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 109655161439597L ^ var2;
      long var5 = var2 ^ 69832085038070L;
      int var10000 = Event.cReturningInt();
      Object[] var13 = new Object[]{var4, var5};
      Vec3d var8 = RaycastUtil.aReturningVec3d(var13);
      int var7 = var10000;
      long var9 = System.currentTimeMillis();
      List var14 = this.m;
      Iterator var11 = var14.iterator();

      int var32;
      while (true) {
         Iterator var15 = var11;
         boolean var33 = var15.hasNext();
         if (var33) {
            Iterator var16 = var11;
            CartAuraPlacementTime var12 = (CartAuraPlacementTime)var16.next();
            CartAuraPlacementTime var17 = var12;
            long var45 = var9 - var17.al();
            short var10001 = 29735;
            long var10002 = 6227067089054729751L ^ var2;
            long var48;
            var10000 = (var48 = var45 - 5000L) == 0L ? 0 : (var48 < 0L ? -1 : 1);
            int var35 = var7;
            int var34 = var10000;
            var32 = var34;
            int var26 = var34;
            if (var35 == 0) {
               break;
            }

            int var37 = var7;
            int var36 = var26;
            int var29 = var36;
            int var27 = var36;
            if (var37 != 0) {
               int var38 = var27;
               int var28 = var38;
               int var39 = var28;
               if (var39 > 0) {
                  continue;
               }

               CartAuraPlacementTime var20 = var12;
               BlockPos var21 = var20.ak();
               Vec3d var47 = var21.toCenterPos();
               double var24 = 1.5;
               Vec3d var23 = var47;
               Vec3d var22 = var8;
               var29 = (((var22.isInRange((Position)var23, var24)) ? 1 : 0));
            }

            int var41 = var7;
            int var40 = var29;
            int var31 = var40;
            int var30 = var40;
            if (var41 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var31);
            }

            int var42 = var30;
            if (var42 != 0) {
               byte var49 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var49);
            }

            int var43 = var7;
            if (var43 != 0) {
               continue;
            }
         }

         var32 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var32);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 109655161439597L ^ var2;
      long var4 = var2 ^ 78769808870611L;
      int var10000 = Event.cReturningInt();
      int var6 = var10000;

      byte var17;
      while (true) {
         short var10001 = 30983;
         long var10002 = 368500433657337876L ^ var2;
         byte var19 = 8;
         int var18 = var7;
         if (var18 <= var19) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var28 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var28;
            Object[] var12 = new Object[]{var10.getStack(var11), var4};
            byte var29 = ((byte)((InventoryUtil.aReturningBoolean(var12)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var29;
            var17 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               break;
            }

            int var23 = var6;
            byte var22 = var13;
            int var16 = var22;
            byte var14 = var22;
            if (var23 == 0) {
               return var16;
            }

            byte var24 = var14;
            int var15 = var24;
            int var25 = var15;
            if (var25 != 0) {
               var16 = var7;
               return var16;
            }

            var7++;
            int var26 = var6;
            if (var26 != 0) {
               continue;
            }
         }

         var17 = -1;
         break;
      }

      return var17;
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 109655161439597L ^ var3;
      Entity var5 = var2;
      Box var6 = var5.getBoundingBox();
      return var6.getCenter();
   }

   private double aReturningDouble(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 109655161439597L ^ var3;
      MinecraftClient var19 = b;
      ClientPlayerEntity var20 = var19.player;
      Vec3d var5 = var20.getEyePos();
      Entity var21 = var2;
      Box var6 = var21.getBoundingBox();
      Vec3d var22 = var5;
      Box var23 = var6;
      Box var24 = var6;
      double var29 = var24.maxX;
      double var27 = var23.minX;
      double var25 = var22.x;
      double var7 = MathHelper.clamp(var25, var27, var29);
      Vec3d var31 = var5;
      Box var32 = var6;
      Box var33 = var6;
      double var38 = var33.maxY;
      double var36 = var32.minY;
      double var34 = var31.y;
      double var9 = MathHelper.clamp(var34, var36, var38);
      Vec3d var40 = var5;
      Box var41 = var6;
      Box var42 = var6;
      double var47 = var42.maxZ;
      double var45 = var41.minZ;
      double var43 = var40.z;
      double var11 = MathHelper.clamp(var43, var45, var47);
      Vec3d var49 = var5;
      double var13 = var49.x - var7;
      Vec3d var50 = var5;
      double var15 = var50.y - var9;
      Vec3d var51 = var5;
      double var17 = var51.z - var11;
      double var52 = var13 * var13 + var15 * var15 + var17 * var17;
      return Math.sqrt(var52);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 109655161439597L ^ var2;
      long var4 = var2 ^ 137680172497986L;
      int var6 = Event.cReturningInt();
      int var13 = var6;
      CartAura var12 = this;
      CartAura var11 = var12;
      CartAura var10 = var12;
      if (var13 != 0) {
         int var15 = -1;
         int var14 = var10.o;
         if (var14 != var15) {
            RotationManager var10000 = Prestige.o;
            int var10001 = this.o;
            Object[] var10004 = new Object[]{null, var4};
            var10004[0] = var10001;
            Object[] var9 = var10004;
            RotationManager var8 = var10000;
            var8.hReturningVoid(var9);
            this.o = -1;
         }

         var11 = this;
      }

      var11.p = 0;
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 109655161439597L ^ var2;
      this.n = null;
      List var4 = this.m;
      var4.clear();
      this.o = -1;
      this.p = 0;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      long var6 = var2 ^ 97421634845769L;
      Object[] var9 = new Object[]{var6};
      CartAura var8 = this;
      var8.kReturningVoid(var9);
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var4};
      RotationManager var10 = var10000;
      var10.dReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 63171712898472L;
      RotationManager var10000 = Prestige.o;
      Object[] var9 = new Object[]{this, var4};
      RotationManager var8 = var10000;
      var8.eReturningVoid(var9);
      Object[] var11 = new Object[]{var6};
      CartAura var10 = this;
      var10.jReturningVoid(var11);
      this.n = null;
      List var12 = this.m;
      var12.clear();
   }

   private static boolean lambda$findClosestCart$1(long var0, CartAuraPlacementTime var2) {
      int var5 = Event.cReturningInt();
      CartAuraPlacementTime var6 = var2;
      long var14;
      int var10000 = (var14 = var0 - var6.al() - 5000L) == 0L ? 0 : (var14 < 0L ? -1 : 1);
      int var11 = var5;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      if (var11 != 0) {
         int var12 = var7;
         if (var12 <= 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(32913123934887L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var19 = new long[2];
      String var17 = "¶4Ð§1=\u0016Ù2ém\u0012\u008b\u0088\u0088ß";
      int var18 = "¶4Ð§1=\u0016Ù2ém\u0012\u008b\u0088\u0088ß".length();
      do {
         int var10001 = var15;
         var15 += 8;
         byte[] var20 = var17.substring(var10001, var15).getBytes("ISO-8859-1");
         var10001 = var16++;
         long var21 = (var20[0] & 255L) << 56
            | (var20[1] & 255L) << 48
            | (var20[2] & 255L) << 40
            | (var20[3] & 255L) << 32
            | (var20[4] & 255L) << 24
            | (var20[5] & 255L) << 16
            | (var20[6] & 255L) << 8
            | var20[7] & 255L;
         byte[] var23 = var13.doFinal(
            new byte[]{
               (byte)(var21 >>> 56),
               (byte)(var21 >>> 48),
               (byte)(var21 >>> 40),
               (byte)(var21 >>> 32),
               (byte)(var21 >>> 24),
               (byte)(var21 >>> 16),
               (byte)(var21 >>> 8),
               (byte)var21
            }
         );
         long var10004 = (var23[0] & 255L) << 56
            | (var23[1] & 255L) << 48
            | (var23[2] & 255L) << 40
            | (var23[3] & 255L) << 32
            | (var23[4] & 255L) << 24
            | (var23[5] & 255L) << 16
            | (var23[6] & 255L) << 8
            | var23[7] & 255L;
         // var19[var10001] = var10004;
      } while (var15 < var18);

      r = var19;
      s = new Integer[2];
      w = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(32913123934887L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      String var4 = ".À\u0001\u008b\u0098·ÅÈör\u009bW\u0012e\u009eã";
      int var5 = ".À\u0001\u008b\u0098·ÅÈör\u009bW\u0012e\u009eã".length();
      do {
         int var26 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var26, var2).getBytes("ISO-8859-1");
         var26 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var32 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         // var6[var26] = var32;
      } while (var2 < var5);

      u = var6;
      v = new Long[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29309;
      if (s[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = r[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])t.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ep", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         s[var3] = var15;
      }

      return s[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ep_C0248",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ep" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 939;
      if (v[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = u[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])w.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               w.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ep", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         v[var3] = var15;
      }

      return v[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ep_C0248",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ep" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = y[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = x[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 11;
            yield var15;
         }
         case 1 -> {
            byte var16 = 50;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 26;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 37;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 10;
            yield var23;
         }
         case 9 -> {
            byte var24 = 36;
            yield var24;
         }
         case 10 -> {
            byte var25 = 30;
            yield var25;
         }
         case 11 -> {
            byte var26 = 8;
            yield var26;
         }
         case 12 -> {
            byte var27 = 46;
            yield var27;
         }
         case 13 -> {
            byte var28 = 12;
            yield var28;
         }
         case 14 -> {
            byte var29 = 40;
            yield var29;
         }
         case 15 -> {
            byte var30 = 6;
            yield var30;
         }
         case 16 -> {
            byte var31 = 25;
            yield var31;
         }
         case 17 -> {
            byte var32 = 38;
            yield var32;
         }
         case 18 -> {
            byte var33 = 41;
            yield var33;
         }
         case 19 -> {
            byte var34 = 24;
            yield var34;
         }
         case 20 -> {
            byte var35 = 16;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 34;
            yield var37;
         }
         case 23 -> {
            byte var38 = 55;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 47;
            yield var40;
         }
         case 26 -> {
            byte var41 = 62;
            yield var41;
         }
         case 27 -> {
            byte var42 = 7;
            yield var42;
         }
         case 28 -> {
            byte var43 = 18;
            yield var43;
         }
         case 29 -> {
            byte var44 = 42;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 44;
            yield var46;
         }
         case 32 -> {
            byte var47 = 9;
            yield var47;
         }
         case 33 -> {
            byte var48 = 28;
            yield var48;
         }
         case 34 -> {
            byte var49 = 14;
            yield var49;
         }
         case 35 -> {
            byte var50 = 17;
            yield var50;
         }
         case 36 -> {
            byte var51 = 0;
            yield var51;
         }
         case 37 -> {
            byte var52 = 59;
            yield var52;
         }
         case 38 -> {
            byte var53 = 39;
            yield var53;
         }
         case 39 -> {
            byte var54 = 13;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 61;
            yield var56;
         }
         case 42 -> {
            byte var57 = 49;
            yield var57;
         }
         case 43 -> {
            byte var58 = 58;
            yield var58;
         }
         case 44 -> {
            byte var59 = 63;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 52;
            yield var61;
         }
         case 47 -> {
            byte var62 = 4;
            yield var62;
         }
         case 48 -> {
            byte var63 = 19;
            yield var63;
         }
         case 49 -> {
            byte var64 = 1;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 5;
            yield var66;
         }
         case 52 -> {
            byte var67 = 20;
            yield var67;
         }
         case 53 -> {
            byte var68 = 54;
            yield var68;
         }
         case 54 -> {
            byte var69 = 51;
            yield var69;
         }
         case 55 -> {
            byte var70 = 56;
            yield var70;
         }
         case 56 -> {
            byte var71 = 32;
            yield var71;
         }
         case 57 -> {
            byte var72 = 3;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 35;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 31;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 45;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            y[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      x[0] = "K\fy\b\u0001w]\f|R\u0012`JG\u007fT\u001et[\u0000hCU`E";
      x[1] = long.class;
      y[1] = "java/lang/Long";
      x[2] = "\u0019(\npO \u000f(\u000f*\\7\u0018c\f,P#\t$\u001b;\u001b18";
      x[3] = int.class;
      y[3] = "java/lang/Integer";
      x[4] = ">\u001f1\n\fx(\u001f4P\u001fo?T7V\u0013{.\u0013 AXm*";
      x[5] = "<\u0012\u0010k\bV7\u001d\u0001$k[\"\u0010\u000eO^Y3\u0003\u0012cIT";
      x[6] = ",,W\fv3:,RVe$-gQPi0< FG\"\"$";
      x[7] = "Nz\"!/\u001d;Z).>RZT\"%:\b.";
      x[8] = ",k#hy*,k44u%6 4*u01Qeu'{";
      x[9] = "p4\u0019\u0010h4p4\u000eLd;j\u007f\u000eRd.m\u000e\\\t<d";
      x[10] = "\fGs7%f\fGdk)i\u0016\fdu)|\u0011}6.q=";
      x[11] = "~#\u0018]\u0012wu,\t\u0012obg6\u000bQ";
      x[12] = "~]*i\u00011~]=5\r>d\u0016=+\r+cgisZ";
      x[13] = "\"].ES\u000f\"]9\u0019_\u00008\u00169\u0007_\u0015?gkS\u000eT";
      x[14] = ".U>\u0010~\u000b0]$_\u001c\u00177@";
      x[15] = "!\b\u0012t7~*\u0007\u0003;Vp!\f\u0007a";
      x[16] = boolean.class;
      y[16] = "java/lang/Boolean";
      x[17] = "YQq3!\u0016YQfo-\u0019C\u001afq-\fDk7%tJ";
      x[18] = "~3+sWt~3</[{dx<1[nc\tno\f%";
      x[19] = "\u0018le|\u001a}\u0018lr \u0016r\u0002'r>\u0016g\u0005V\"cG";
      x[20] = "T\\T\u0004_\u0016T\\CXS\u0019N\u0017CFS\fIf\u0013\u0013\u0004J";
      x[21] = "!\u007fO]O\b7\u007fJ\u0007\\\u001f 4I\u0001P\u000b1s^\u0016\u001b\u001a ";
      x[22] = "z\u0004q \u0014O\u000f$z/\u0005\u0000n*q$\u0001Z\u001a";
      x[23] = "\t\b<9\u00057\t\b+e\t8\u0013C+{\t-\u00142z\"Qh";
      x[24] = "T{\u000feT5Js\u0015*\u001c5Py\rm\u0015.\u0010J\u000ba\u001e)]{\ra";
      x[25] = "9%\u001a\fo\f9%\rPc\u0003#n\rNc\u0016$\u001f\\\u00161";
      x[26] = double.class;
      y[26] = "java/lang/Double";
      x[27] = "@\\U\u001aiOKSDU\u000eWOOB\u0019+F";
      x[28] = "$ hSbh:(r\u001c\u0005i+3\u007fF#o";
      x[29] = float.class;
      y[29] = "java/lang/Float";
      x[30] = "X\u001bAY>4N\u001bD\u0003-#YPG\u0005!7H\u0017P\u0012j ~";
      x[31] = "PV,AaK%v'Np\u0004Dx,Et^0";
      x[32] = "\u00152\u0014RVM`\u0012\u001f]G\u0002\u0001\u001c\u0014VCXu";
      x[33] = "\b#.%x%}\u0003%*ij\u001c\r.!m0h";
      x[34] = "'\u001d\u000f\rQ-'\u001d\u0018Q]\"=V\u0018O]7:'M\u0010\u0004";
      x[35] = "U(&S-< \b-\\<sA\u0006&W8)5";
      x[36] = "\u0002\u0002\u001dKU-\u0014\u0002\u0018\u0011F:\u0003I\u001b\u0017J.\u0012\u000e\f\u0000\u00019\u001e";
      x[37] = "\u007f\tqIZ\u001f\u007f\tf\u0015V\u0010eBf\u000bV\u0005b34P\u0007G";
      x[38] = "\u001c6k'\u0002\u0012\u00179zha\u001f\u0002?";
      x[39] = "~Kk2b\buDz}\u000e\u000b{Fx2\"";
      x[40] = "G[$3\u0000tQ[!i\u0013cF\u0010\"o\u001fwWW5xT`e";
      x[41] = "V,e`qnV,r<}aLgr\"}tK\u0016#}$";
      x[42] = "p^5%\u000b*p^\"y\u0007%j\u0015\"g\u00070mdp9_t";
      x[43] = "7\u001dq>T\f7\u001dfbX\u0003-Vf|X\u0016*'6%\nW";
      x[44] = void.class;
      y[44] = "java/lang/Void";
      x[45] = "ckw7\\?ukrmO(b qkC<sgf|\b+~";
      x[46] = "(\u0010R\u0006FQ]0Y\tW\u001e<>R\u0002SDH";
      x[47] = "-7}^OSX\u0017vQ^\u001c9\u0019}ZZFM";
      x[48] = "Z\u000f\u0015\u000fN\u000fL\u000f\u0010U]\u0018[D\u0013SQ\fJ\u0003\u0004D\u001a\u001cR\u0003\u0006O@Qn\u0018\u0006R@\u0016Y\u000f";
      x[49] = "&\u0000\u0011&6\u000e&\u0000\u0006z:\u0001<K\u0006d:\u0014;:T>mV";
      x[50] = "25<'Q}$59}Bj3~:{N~\"9-l\u0005n9";
      x[51] = "cK296&\u0016k96'iwe2=#3\u0003";
      x[52] = "56<,]*@\u00167#Le!\u0018<(H?U";
      x[53] = "u\u0016{tGJ\u00006p{V\u0005a8{pR_\u0015";
      x[54] = "\u000frp*L:\u0011zje1*\u0011";
      x[55] = "P\u000e \fBG%.+\u0003S\bD  \bWR0";
      x[56] = "0a\u000b\u0011s~&a\u000eK`i1*\rMl} m\u001aZ'j\u0018";
      x[57] = "p\u001c\u001e\u0014\u0003K\u0005<\u0015\u001b\u0012\u0004d2\u001e\u0010\u0016^\u0010";
      x[58] = "\u0010\u0000J`Die AoU&\u0004.JdQ|p";
      x[59] = "^\u001dZ\u0019[,H\u001d_CH;_V\\ED/N\u0011KR\u000f:c";
      x[60] = "O\u007f:\t\u0017\u0014:_1\u0006\u0006[[Q:\r\u0002\u0001/";
      x[61] = "$/R\u001e\u0010{2/WD\u0003l%dTB\u000fx4#CUDh,";
      x[62] = "*\u0012]uNX_2Vz_\u0017><]q[MJ";
      x[63] = "\u0003G\u0018im\bvg\u0013f|G\u0017i\u0018mx\u001dc";
      x[64] = "\n_w^\u0017\u0015\u007f\u007f|Q\u0006Z\u001eqwZ\u0002\u0000j";
      x[65] = "+ c\u0011\u0004f^\u0000h\u001e\u0015)?\u000ec\u0015\u0011sK";
      x[66] = ":Nmq\u0016^Onf~\u0007\u0011.`mu\u0003KZ";
      x[67] = "\u0003Vd|Jrvvos[=\u0017xdx_gc";
      x[68] = "q~st0<\u0004^x{!sePsp%)\u0011";
      x[69] = ")\u0007MiTH\\'FfE\u0007=)MmA]I";
      x[70] = "`g\b9E.\u0015G\u00036TatI\b=P;\u0000";
      x[71] = "cfyLiP\u0016FrCx\u001fwHyH|E\u0003";
      x[72] = "\u001f\u001ar\\-\u000e\u0014\u0015c\u0013E\u000e\u001a\u001ap";
      x[73] = "D\u001c\f\u007f\u001b@1<\u0007p\n\u000fP2\f{\u000eU$";
      x[74] = "ix[<Q\r\u007fx^fB\u001ah3]`N\u000eytJw\u0005\u001e>";
      x[75] = "/\"\u0011\u0015P1Z\u0002\u001a\u001aA~;\f\u0011\u0011E$O";
      x[76] = "B\u000e\u0003Xk4B\u000e\u0014\u0004g;XE\u0014\u001ag._4EE1i";
      x[77] = "1OUxO;'OP\"\\,0\u0004S$P8!CD3\u001b/\u001f";
      x[78] = "o~3dH9\u001a^8kYv{P3`],\u000f";
      x[79] = "5e\u0001Cs(?s\u0002\u0016\r(iq\u0005\f`\u0013j\u0014\u0002Lj>\u007fz\u0001M\u007f3\u0004~R\u000br8a/\u001b\u000etR";
      x[80] = "}\u0012#QW})@6@U\u0013.)wY\u0002i)\u0016\"\u0004V#6)3J\u0017iuM6\u0000P.D";
      x[81] = "\u001c'v\u001e2u\u0001$!\u000eW+\u00062/\u001e\u0000|\\eqr6*\u00169;\u001f0t\u000b>";
      x[82] = "U0\\Q\u0017v\u000f;MGe\u007f\b=N]\tM^x\u0013\u0006U\u001a\u0014|M\u0000Y!T+JXe";
      x[83] = "X69G':_~o\u0011\u0016<\u001a=sCp+;&lCS6\u0003#hU\u0016n\r*nO,,\u0006,d.";
      x[84] = "^c0\u001a\u0006L\u0004h!\ftE\u0003n\"\u0016\u0018wU,~LH \r-xAH\u001a\u001fs\u007f\u001bt";
      x[85] = "HZK-\u0013'WI\u001bmz:6\tK?\u0000;\t\\\u0016kJ$6MX*\u0000gRH\u0012mGV";
      x[86] = "eFx0?\u0015oP{eA\u000e(Zah=\b.7y{3W6N}x*\tT";
      x[87] = "\\m*^m0\u00146-S3W\f\rh_c-\b2=\u00027g\u0017\rh^q7\u0002j \u0005v:\\\r";
      x[88] = "$@l\u0007\u0018x&@nHLIt~2\u0017\u001f3pAgJKyo~v\u0004\n3,\u001asNMt\u001d";
      x[89] = "\u0000tH0zBId\u001ag\u0010G;!@ijI\u0004t\u001d= V;eS|j\u0015_`\u0019;-$";
      x[90] = "q\u007f\u00016l\u0010+t\u0010 \u001e\u0019,r\u0013:r+z0O`#|\"1Im\"F0oN7\u001e";
      x[91] = "h\b{L\u0000Bl\u000bb\u0012b]g\u0002ut\u000bC1\u000fu\u0018XFm\u001b\t";
      x[92] = "~A\u001c\u007f&Fk\u001aN)LQ\u001aA\u001e*6V%\u0014C~|I\u001a\u0000\u001d&<AcA\u001a,};";
      x[93] = "'Tza\u001c\u0010b@<=wD2Qca\u001bvb\u001d;;wKoT|l\u0012\u001a&Qz\u0006";
      x[94] = "IN\u0017\u0004\f_U\\M\u0004vEIM\nj\u0017QAQ\u0006\u0007\u0011\u000f\\Vv\u000b\u0019OVG\u001b\rGRQ7";
      x[95] = "\u0010\u001a \u000f\u0006{\r\u0019w\u001fc%\n\u000fy\u000f4rPX$c\u0002$\u001a\u0004m\u000e\u0004z\u0007\u0003";
      x[96] = "\b|\\yV\u000f\u000bs^kgS\u00181]f\u000baLp\u0006<_6\u0014\"Lg\u0017[\u0012|Q`gW\u001a<[q\nQD!\\\u0001\u0006Y\u0004+Ml\u0000\u0007\u0019,=`\bG\u0013=PfVZ\u0014M";
      x[97] = ".gd\u0007u]3d3\u0017\u0010\b8c9\f|:l'aV\u0010\r2$8Wo\u000e/!ik";
      x[98] = "K\u001c\u0013`\u001b%\u0011\u0017\u0002vi,\u0016\u0011\u0001l\u0005\u001e@V\\4PI\u001b\nZjU6\u0018\u0017_;i";
      x[99] = "\u000e\u0000%\u0010z8\u0004\u0016&E\u0004)[\u001c/[\u0004?M\r<\u0010`:\u0007J{!";
      x[100] = "\u001e@VOrC\u001d]S\u001eNR\u001fJ\tB\u0019\u0005E\u001aW./S\u000fA\u001dC)\r\u0012F";
      x[101] = "r\u0019}d\u0006^q\u0004x5:Os\u0013\"im\u0018)C\u007f\u0005[Nc\u00186h]\u0010~\u001f";
      x[102] = "\u0015\u001eH\u0012\t/\u0016\u0003MC55\u0018\u0005\u0013\u0014Y\u0007OECK\u000fPL\u0016\u0001\u0010Z2M\u0014\u0002\r\u000fP\u0014\u0016\u0002\u0015E=\u0012H\u001f\u00125:E\u0000\f\u0019Pk\f\u0005\ns";
      x[103] = ")E1R&X6Va\u0012OIW\u00161@5DhCl\u0014\u007f[WR\"U5\u00183Wh\u0012r)";
      x[104] = "\u00048]*G\u0011\u0011c\u000f|-\u0002`8_\u007fW\u0001_m\u0002+\u001d\u001e`k\u000eoR\u0006\u0005:GjTl";
      x[105] = "!\u001e\b\u0004_\u000f{\u0015\u0019\u0012-\u0006|\u0013\u001a\bA4,QF^-\u0002~\u001e\u001c\u001f@\u0004 \u0003\u001boL\f`\t\n\u0002JR}\u000ez\u000eB\u0012w\u001f\u0017\b\u001c\u000fpo\u001b\u0000\\\u0005a\u0002\u001d^A\u0002\u0011";
      x[106] = "\u001em\rfjB\u0003nZv\u000f\u001c\u0004xTfXK^/\b\nn\u001d\u0014s@ghC\tt";
      x[107] = "68\\<[\u0006\u007f(\u000ek1\t\rmTeK\r28\t1\u0001\u0012\r,LuV\u000b<iX3\n`";
      x[108] = "IV\u0000\u0007^o\u0000FRP4`r\u0003\b^NdMVU\n\u0004{rZ\u000e\fU5\rY\u0013\t\u0004\t";
      x[109] = "\u0004\u007fi,\\[D(nt`\u0005\u0018>jq\f7H~1&`ZK}1+\u0001\\\u0010~;\u0016^\u001a\u000e&qf\u0002\u0019N0\n";
      x[110] = "-[ft\u0011;qEg<}n Vo`*9\u007f\u000b4\f\u001b}:Jw6\u001a\u007f;E";
      x[111] = "\u001f3n\u000e64^4dOL$ghj\u00176 X=7C|?g;;\u00073'\u0002jr\u00025M";
      x[112] = "7Ri[D\u001b*Q>K!E-G0[v\u0012w\u0010o7@D=L$ZF\u001a K";
      x[113] = "u<#x\u001cu<,q/vqNi+!\f~q<vuFaN-84\f\"*(rsK\u0013";
      x[114] = "(>\u00064oCr5\u0017\"\u001dJu3\u00148qx&wKn\u001d\u0011b4\u0010$mMat\u0006_";
      x[115] = "qw\u0019i.ic&L-K6{z\u0014\u007f\u001ce*/@\u0013 8sm\u0015\"2i&)";
      x[116] = "i\u0018\tSQK%U\u0016\u0012:@\u001b\u0011\u0015\u0000@D$DHT\n[\u001bBD\u0010EC~\u0013\r\u0015C)";
      x[117] = "\u0017:5DirM1$R\u001b{J7'HwI\u0019r~\u0012\u001bt\u001728E~%^7>/";
      x[118] = "P'_%\tgXqP)vkiz\u0011zM<\b|JyG\u0001";
      x[119] = "Ux\u0004%\n%Q-\u0014\"h i$\u0018v\u0012$VqE\"X;i \u001c~\u0019;\u0012'Cn\u0004I";
      x[120] = "2\u0011&R-Ta\u0012&59O\\\u0011.X7JfS%^=+";
      x[121] = "z.P:dT&-\u0010,\u001fA)(K9ss{e\u0013o\u001f\u001b&dA#%\u0019\"/B^";
      x[122] = "P\\\u0004_\f}\u0017\u0014\\\u000bV\u0002\u000e\u000b`\f\u00129\u0014\u0019\f_\u0017e\u0000eY\\\u000e8\u000f\u001a\u001e\u0014VlUe";
      x[123] = "IO\u0011>XK\u0005\u0002\u000e\u007f3@;F\rmID\u0004\u0013P9\u0003[;\u0002\u001exI\u0018_\u0007T?\u000e)";
      x[124] = "\u0006G0O\n=\u000e\u0011?Cu0?\u001a~\u0010Nf^\u001c%\u0013D[";
      x[125] = "ybL\u001a?tfg^HM\u007fd8S\u001c$s]6S\f \u0015ioN\u000e'p8&K\bM";
      x[126] = "5RF^%\r;UF\u0016G\u0004eQ^\n\u0010Z<\u0002\u000bfx\b4VG\\z\f\u007fU";
      x[127] = "^so?=\u001a\u001d5x;*c\rN898\u0019\nqmdlS\u0015Nkh(\u001c\r+:!-\u001ag";
      x[128] = "\u0004>\"^\u0019}A('Hr\"\u0015$\"V\u001e\u0010Ehx\u0000r<\u0000e.TB!\u00032>1";
      x[129] = "\u0002\u001f50!\t\u0001\u00020a\u001d\u0018\u0003\u0015j=JOYE6Q|\u0019\u0013\u001e~<zG\u000e\u0019";
      x[130] = "YDcnH\u0006S\buj-_#_i5PJO\fliD6";
      x[131] = "APvMV\u0011^C&\r?\u000e?\u0003v_E\r\u0000V+\u000b\u000f\u0012?P'O@\nZ\u0001nJF`";
      x[132] = "\u001f;\u001ehx_V+L?\u0012P$kO*q\u0001@.\u00121i9\u0018o\u0005;*]]2\u001e#\u0012";
      x[133] = " M[\r\u0010[?^\u000bMyG^\u001e[\u001f\u0003GaK\u0006KIX^ZH\n\u0003\u001b:_\u0002MD*";
      x[134] = "\u00060lz\u007fA\\;}l\rH[=~vaz\by#.\rQP!qz7\u0014F$g\u0011g\u001dO>tt6TJ8\u001e";
      x[135] = "2|3n\u0005:/\u007fd~`d(ijn73r>3\u0002\u0001e8b~o\u0007;%e";
      x[136] = "ag5X\\H=y4\u00100\u001dlj<LgJ2=d \u0000\u0002\u007fl*LZ\tnz";
      x[137] = "\fd/MT-\u0002}z\u000f$5\u000bg$\u0017H\u0007_!yL\u001fP\u000by}\u0012Bh\u0003w4\u0010$";
      x[138] = "GYDu%\\\u0004\u001fSq2%\u0017d\u0013s _\u0013[F.t\u0015\fdW`5_O\u0000R*r\u0018~";
      x[139] = "Ob_L@wB$L\u0016~p?cY\u0011\u0005~N|JAE";
      x[140] = "B\u0000{5\u001bP\u000eMdtp[0\tgf\n_\u000f\\:2@@0\n80K\u000fQ\fc3A2";
      x[141] = "F\u0004uX~\u0004[\u0007\"H\u001bZ\\\u0011,XL\r\u0006Ft4z[L\u001a8Y|\u0005Q\u001d";
      x[142] = "D cFF\u0018@#z\u0018$\u0001O!W\u0013T\u001d&0!\u0007[\u000bCah\u0002]a";
      x[143] = "\u0003\n\u0018\u001b<&\u000b\u0004Q\u0019Z{\u0003\u0014A\u001e6IWW\u001eFe\u001eS\r@\b(eTRP\u0015Z";
      x[144] = "X<8\u000f&i\u0011,jXLcci0V6b\\<m\u0002|}cjo\u0000w2\u0002l4\u0003}\u000f";
      x[145] = "*<\n$a\u007f?gXr\u000bnN<\bqqoqiU%;pN}\u000b}{x7<\fw:\u0002";
      x[146] = " E:Mh@v\u001c(\u0016\f\u0017M\u001b2\u001fv\u0013rNoK<\fMMk\u0014b\u001b1\u001f-\u000f3~";
      x[147] = "\u0005_+X^\u001cW\\nG\u001fmU1nVF\u0017Q\u000e;\u000b\u0012]N17P\u0014\f\u0000N4M\u0011]<";
      x[148] = "~~5w!#=8\"s6Z.Cbq$ *|7,pj5C1 4%-&`i1#G";
      x[149] = "\u00061\u0002/hO\u001fn\u0007#TP\u0018m\u0011$(V\u001e\u0000\t7&\t\u0006y\r4?Wd";
      x[150] = "a:y6+\u000729yQ?\u001b\u000f>~0'\nt9! :x";
      x[151] = "sJZ?w3)AK)\u0005:.GH3i\b}\u0003\u0014k\u0005a9@L/u=:\u0000ZT";
      x[152] = "<@ZZ'\u001buP\b\rM\u0014\u0007\u0015R\u00037\u00108@\u000fW}\u000f\u0007F\u0003\u00132\u0017b\u0017J\u00164}";
      x[153] = "F=\u001fv0aL+\u001c#Nr\u001b |.6 \n0\u0010}3|\u001eL\u0016w7d\u001d)G>2bw";
      x[154] = "*R(W\u000b\u001ccBz\u0000a\u0013\u0011\u0007 \u000e\u001b\u0017.R}ZQ\b\u0011_.\u0016\u0007\n|Yp\u000b\u0000z";
      x[155] = ",FpT\u0010`\"_%\u0016`x+E{\u000e\fJ\u007f\u0003&U^\u001d-Yr\u0013\u0005,?\b'W`";
      x[156] = "\u001e=( \u000f\u0001\u0019b8=}\u001fN$)6\u0011-\u001fftlMzC?r0A\u0005@\"wa}";
      x[157] = "\u000eW\u0018Wd\u007f\u000fUITf\u000eY^\u001e\u0002wP^^\u0004\u0006\u000bm\b\u0000IW1\u007fV\u0007\u0013k";
      x[158] = ":Z\u001d?\u0018\u001c%IM\u007fq\u0004D\t\u001d-\u000b\u0000{\\@yA\u001fDH\u001e!\u0001\u0017=\t\u0019+@m";
      x[159] = "t\u0007\u007fs\u0014TfV*7q\bf\u001a\u007fm\nev\u001f-t\r\t%\u001aq`q\u000f/\u001eic\u0014^f\u001bo\t";
      x[160] = "AGkT\u0017G@Ej[k\u0018JFpB\u0007*\u001e\n)\u001cQ}E\u000byGW\u0003\\T|Kk";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = x[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(y[var4]);
            x[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = y[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            x[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  x[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1086429485820106L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = y[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  x[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1086429485820106L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        x[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1086429485820106L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 186;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 101;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 230;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 117;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 203;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 236;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 186;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 101;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 230;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ep_C0248",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ep" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(CartAura var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ep_C0248;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ep_C0248", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((CartAura)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(long var0) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(J)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/ep_C0248", "lambda$findClosestCart$1", "(JLdev/zprestige/prestige/gj_C0344;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gj_C0344;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var3.invokeExact((long)var0);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
