package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.BlockPos;

public record CartAuraPlacementTime(BlockPos ak, long al) {
}
