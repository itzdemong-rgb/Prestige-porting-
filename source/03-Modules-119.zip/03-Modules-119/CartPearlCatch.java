package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.util.ExplosionDamageUtil;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.events.EntityOverlayRenderEvent;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.client.modules.state.CartPearlCatchState;
import dev.zprestige.prestige.client.modules.state.CartPearlIntercept;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;

public class CartPearlCatch extends Module implements RotationSource {
   private FloatSetting a;
   private FloatSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private IntSetting f;
   private BooleanSetting g;
   private FloatSetting h;
   private BooleanSetting i;
   private static final Item[] j;
   private CartPearlCatchState k;
   private UUID l;
   private Set m;
   private int n;
   private int o;
   private int p;
   private BlockPos q;
   private boolean r;
   private int s;
   private int t;
   private int u;
   private int v;
   private int w;
   private boolean x;
   private Rotation y;
   private int z;
   private static final Identifier A;
   private static ManagedGlTexture B;
   private static final long C = 33010110281137L;
   private static final String[] D;
   private static final String[] E;
   private static final Map F = new HashMap(13);
   private static final long[] G;
   private static final Integer[] H;
   private static final Map I;
   private static final Object[] J = new Object[310];
   private static final String[] K = new String[310];
   private static volatile MethodHandle bindingCache1;

   public CartPearlCatch() {
      super();
      long var10001 = 112411008616075L ^ 133360488707164L;

      this.k = CartPearlCatchState.IDLE;
      this.m = new HashSet();
      this.s = -1;
      this.t = 0;
      this.u = 0;
      this.v = 0;
      this.w = -1;
      this.x = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.z = -1;
      FloatSetting var10000 = this.h;
      Object[] var6 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var5 = var10000;
      var5.aReturningFloatSetting(var6);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      Object[] var7 = new Object[0];
      CartPearlCatch var6 = this;
      var6.jReturningVoid(var7);
      Set var8 = this.m;
      var8.clear();
      RotationManager var10000 = Prestige.o;
      Object[] var10 = new Object[]{this, var4};
      RotationManager var9 = var10000;
      var9.dReturningVoid(var10);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 132732501489668L;
      long var6 = var2 ^ 64097829662901L;
      Object[] var9 = new Object[]{var4};
      CartPearlCatch var8 = this;
      var8.mReturningVoid(var9);
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var6};
      RotationManager var10 = var10000;
      var10.eReturningVoid(var11);
      Object[] var13 = new Object[0];
      CartPearlCatch var12 = this;
      var12.jReturningVoid(var13);
   }

   private void jReturningVoid(Object[] var1) {
      this.k = CartPearlCatchState.IDLE;
      this.l = null;
      this.q = null;
      this.s = -1;
      this.t = 0;
      this.u = 0;
      this.v = 0;
      this.w = -1;
      this.y = null;
      this.z = -1;
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      Set var4 = this.m;
      var4.clear();
   }

   private void kReturningVoid(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 33010110281137L ^ var2;
      int var5 = Event.bReturningInt();
      MinecraftClient var6 = b;
      int var16 = var5;
      ClientPlayerEntity var15 = var6.player;
      ClientPlayerEntity var14 = var15;
      ClientPlayerEntity var13 = var15;
      if (var16 == 0) {
         ClientPlayerEntity var17 = var13;
         if (var17 == null) {
            return;
         }

         MinecraftClient var8 = b;
         ClientPlayerEntity var18 = var8.player;
         var14 = var18;
      }

      short var10002 = 30048;
      long var10003 = 5228166100432576995L ^ var2;
      String var10 = "§7[CartPearlCatch] §f" + var4;
      MutableText var12 = Text.literal(var10);
      ClientPlayerEntity var11 = var14;
      var11.sendMessage((Text)var12, false);
   }

   private void lReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      long var3 = (Long)var1[1];
      var3 = 33010110281137L ^ var3;
      long var5 = var3 ^ 66788852307382L;
      long var7 = var3 ^ 8261472493554L;
      int var10000 = Event.bReturningInt();
      short var10003 = 11218;
      long var10004 = 4872983728508605722L ^ var3;
      Object[] var11 = new Object[]{"aborted: " + var2, var7};
      CartPearlCatch var10 = this;
      var10.kReturningVoid(var11);
      int var9 = var10000;
      int var23 = var9;
      CartPearlCatch var22 = this;
      CartPearlCatch var21 = var22;
      CartPearlCatch var20 = var22;
      if (var23 == 0) {
         UUID var24 = var20.l;
         if (var24 != null) {
            UUID var14 = this.l;
            Set var13 = this.m;
            var13.add(var14);
         }

         Object[] var17 = new Object[]{var5};
         CartPearlCatch var16 = this;
         var16.mReturningVoid(var17);
         var21 = this;
      }

      Object[] var19 = new Object[0];
      CartPearlCatch var18 = var21;
      var18.jReturningVoid(var19);
   }

   private void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 33010110281137L ^ var2;
      int var4 = Event.bReturningInt();
      int var30 = var4;
      CartPearlCatch var29 = this;
      CartPearlCatch var23 = var29;
      CartPearlCatch var22 = var29;
      if (var30 == 0) {
         boolean var31 = var22.x;
         if (!var31) {
            return;
         }

         var23 = this;
      }

      MinecraftClient var28;
      label36: {
         var23.x = dev.prestige.recovery.SourceSupport.asBoolean(0);
         MinecraftClient var7 = b;
         GameOptions var8 = var7.options;
         KeyBinding var9 = var8.useKey;
         var9.setPressed(false);
         MinecraftClient var11 = b;
         int var33 = var4;
         ClientPlayerEntity var32 = var11.player;
         ClientPlayerEntity var27 = var32;
         ClientPlayerEntity var24 = var32;
         if (var33 == 0) {
            ClientPlayerEntity var34 = var24;
            if (var34 == null) {
               return;
            }

            int var36 = var4;
            MinecraftClient var35 = b;
            var28 = var35;
            MinecraftClient var25 = var35;
            if (var36 != 0) {
               break label36;
            }

            MinecraftClient var37 = var25;
            MinecraftClient var26 = var37;
            MinecraftClient var14 = var26;
            ClientPlayerEntity var38 = var14.player;
            var27 = var38;
         }

         ClientPlayerEntity var16 = var27;
         boolean var39 = var16.isUsingItem();
         if (!var39) {
            return;
         }

         MinecraftClient var40 = b;
         var28 = var40;
      }

      MinecraftClient var18 = var28;
      MinecraftClient var19 = b;
      ClientPlayerEntity var21 = var19.player;
      ClientPlayerInteractionManager var20 = var18.interactionManager;
      var20.stopUsingItem((PlayerEntity)var21);
   }

   private CartPearlIntercept aReturninggk_C0346(Object[] var1) {
      EnderPearlEntity var2 = (EnderPearlEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 33010110281137L ^ var3;
      EnderPearlEntity var22 = var2;
      double var6 = var22.getX();
      EnderPearlEntity var23 = var2;
      double var8 = var23.getY();
      EnderPearlEntity var24 = var2;
      double var10 = var24.getZ();
      int var10000 = Event.bReturningInt();
      EnderPearlEntity var25 = var2;
      Vec3d var12 = var25.getVelocity();
      int var5 = var10000;
      Vec3d var26 = var12;
      double var13 = var26.x;
      Vec3d var27 = var12;
      double var15 = var27.y;
      Vec3d var28 = var12;
      double var17 = var28.z;
      int var19 = 1;

      int var45;
      do {
         short var10001 = 2790;
         long var10002 = 1131898863840097768L ^ var3;
         short var38 = 200;
         int var37 = var19;
         if (var37 > var38) {
            break;
         }

         label26: {
            Vec3d var20 = new Vec3d(var6, var8, var10);
            var6 += var13;
            var8 += var15;
            var10 += var17;
            var13 *= 0.99;
            var17 *= 0.99;
            var15 = var15 * 0.99 - 0.03;
            MinecraftClient var29 = b;
            ClientWorld var47 = var29.world;
            RaycastContext var31 = new RaycastContext(var20, new Vec3d(var6, var8, var10), ShapeType.OUTLINE, FluidHandling.NONE, var2);
            ClientWorld var30 = var47;
            BlockHitResult var21 = var30.raycast(var31);
            int var40 = var5;
            BlockHitResult var39 = var21;
            BlockHitResult var36 = var39;
            BlockHitResult var35 = var39;
            if (var40 == 0) {
               BlockHitResult var41 = var35;
               if (var41 == null) {
                  break label26;
               }

               var36 = var21;
            }

            BlockHitResult var33 = var36;
            Type var48 = var33.getType();
            Type var43 = Type.BLOCK;
            Type var42 = var48;
            if (var42 == var43) {
               BlockHitResult var34 = var21;
               return new CartPearlIntercept(var34.getPos(), var19);
            }
         }

         double var49;
         int var44 = (var49 = var8 - -65.0) == 0.0 ? 0 : (var49 < 0.0 ? -1 : 1);
         if (var44 < 0) {
            break;
         }

         var19++;
         var45 = var5;
      } while (var45 == 0);

      return null;
   }

   private EnderPearlEntity aReturningEnderPearlEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 33010110281137L ^ var2;
      int var4 = Event.cReturningInt();
      UUID var27 = this.l;
      if (var27 != null) {
         MinecraftClient var8 = b;
         int var29 = var4;
         ClientWorld var28 = var8.world;
         ClientWorld var24 = var28;
         ClientWorld var22 = var28;
         if (var29 != 0) {
            ClientWorld var30 = var22;
            ClientWorld var23 = var30;
            ClientWorld var31 = var23;
            if (var31 == null) {
               return null;
            }

            MinecraftClient var12 = b;
            var24 = var12.world;
         }

         ClientWorld var13 = var24;
         Iterable var14 = var13.getEntities();
         Iterator var5 = var14.iterator();

         int var38;
         do {
            Iterator var15 = var5;
            boolean var32 = var15.hasNext();
            if (!var32) {
               break;
            }

            label29: {
               Iterator var16 = var5;
               Entity var6 = (Entity)var16.next();
               int var34 = var4;
               Entity var33 = var6;
               Entity var26 = var33;
               Entity var25 = var33;
               if (var34 != 0) {
                  boolean var35 = var25 instanceof EnderPearlEntity;
                  if (!var35) {
                     break label29;
                  }

                  Entity var36 = var6;
                  var26 = var36;
               }

               EnderPearlEntity var7 = (EnderPearlEntity)var26;
               Entity var19 = var6;
               UUID var39 = var19.getUuid();
               UUID var21 = this.l;
               UUID var20 = var39;
               boolean var37 = var20.equals(var21);
               if (var37) {
                  return var7;
               }
            }

            var38 = var4;
         } while (var38 != 0);

         return null;
      } else {
         return null;
      }
   }

   private double aReturningDouble(Object[] var1) {
      Vec3d var7 = (Vec3d)var1[0];
      Vec3d var2 = (Vec3d)var1[1];
      double var3 = (Double)var1[2];
      long var5 = (Long)var1[3];
      long var10000 = 33010110281137L ^ var5;
      int var65 = Event.cReturningInt();
      double var9 = var3 * 2.0;
      Vec3d var24 = var2;
      Vec3d var23 = var7;
      double var25 = var23.squaredDistanceTo(var24);
      double var11 = Math.sqrt(var25);
      int var8 = var65;
      double var13 = var11 / var9;
      double var70;
      int var66 = (var70 = var13 - 1.0) == 0.0 ? 0 : (var70 < 0.0 ? -1 : 1);
      int var51 = var8;
      int var50 = var66;
      int var43 = var50;
      int var42 = var50;
      if (var51 != 0) {
         int var52 = var42;
         if (var52 > 0) {
            return 0.0;
         }

         var43 = 0;
      }

      int var15 = var43;
      double[] var16 = new double[]{0.2, 1.0, 1.7};
      int var17 = var16.length;
      double var48;
      while (true) {
         int var54 = var17;
         int var53 = var18;
         if (var53 < var54) {
            double var67 = var16[var18];
            int var57 = var8;
            double var55 = var67;
            var48 = var55;
            double var44 = var55;
            if (var57 == 0) {
               break;
            }

            label35: {
               label34: {
                  double var19 = var44;
                  double var32 = var19;
                  Vec3d var29 = var7;
                  Vec3d var21 = var29.add(var30, var32, var34);
                  MinecraftClient var36 = b;
                  ClientWorld var68 = var36.world;
                  MinecraftClient var37 = b;
                  RaycastContext var39 = new RaycastContext(var2, var21, ShapeType.COLLIDER, FluidHandling.NONE, var37.player);
                  ClientWorld var38 = var68;
                  BlockHitResult var22 = var38.raycast(var39);
                  int var59 = var8;
                  BlockHitResult var58 = var22;
                  BlockHitResult var47 = var58;
                  BlockHitResult var46 = var58;
                  if (var59 != 0) {
                     BlockHitResult var60 = var46;
                     if (var60 == null) {
                        break label34;
                     }

                     var47 = var22;
                  }

                  BlockHitResult var41 = var47;
                  Type var69 = var41.getType();
                  Type var62 = Type.MISS;
                  Type var61 = var69;
                  if (var61 != var62) {
                     break label35;
                  }
               }

               var15++;
            }

            var18++;
            int var63 = var8;
            if (var63 != 0) {
               continue;
            }
         }

         var48 = (1.0 - var13) * (var15 / 3.0);
         break;
      }

      double var64 = var48;
      return (var64 * var64 + var64) / 2.0 * 7.0 * var9 + 1.0;
   }

   private BlockPos aReturningBlockPos(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      var3 = 33010110281137L ^ var3;
      long var5 = var3 ^ 15942899257947L;
      long var7 = var3 ^ 78816654781111L;
      long var9 = var3 ^ 51503067024489L;
      int var11 = Event.bReturningInt();
      boolean var81 = this.r;
      double var65;
      if (var81) {
         double var82 = 6.4;
         var65 = var82;
      } else {
         var65 = 6.25;
      }

      double var12 = var65;
      boolean var84 = this.r;
      double var67;
      if (var84) {
         double var85 = 3.15;
         var67 = var85;
      } else {
         var67 = 3.0;
      }

      double var14 = var67;
      short var10000 = 5984;
      Vec3d var30 = var2;
      BlockPos var16 = BlockPos.ofFloored((Position)var30);
      long var10001 = 626791854956559124L ^ var3;
      BlockPos var17 = null;
      FloatSetting var31 = this.c;
      Float var32 = (Float)var31.aReturningObject();
      double var18 = var32.floatValue();
      int var20 = -4;

      while (true) {
         int var69 = var20;

         label98:
         while (true) {
            byte var88 = 4;
            int var87 = var69;
            if (var87 > var88) {
               return var17;
            }

            int var21 = -1;

            label95:
            while (true) {
               int var70 = var21;

               label93:
               while (true) {
                  byte var90 = 2;
                  int var89 = var70;
                  if (var89 > var90) {
                     break label95;
                  }

                  var10000 = 2509;
                  var10001 = 3600230390624626082L ^ var3;
                  int var92 = var11;
                  byte var91 = -4;
                  var69 = var91;
                  byte var71 = var91;
                  if (var92 != 0) {
                     continue label98;
                  }

                  int var22 = var71;

                  int var110;
                  do {
                     byte var94 = 4;
                     int var93 = var22;
                     if (var93 > var94) {
                        break;
                     }

                     int var36 = var22;
                     int var35 = var21;
                     int var34 = var20;
                     BlockPos var33 = var16;
                     BlockPos var23 = var33.add(var34, var35, var36);
                     BlockPos var37 = var23;
                     BlockPos var24 = var37.up();
                     MinecraftClient var38 = b;
                     BlockPos var40 = var23;
                     ClientWorld var39 = var38.world;
                     BlockState var41 = var39.getBlockState(var40);
                     byte var115 = ((byte)((var41.isReplaceable()) ? 1 : 0));
                     int var96 = var11;
                     byte var95 = var115;
                     var70 = var95;
                     byte var72 = var95;
                     if (var96 != 0) {
                        continue label93;
                     }

                     label87: {
                        label107: {
                           int var98 = var11;
                           byte var97 = var72;
                           byte var74 = var97;
                           byte var73 = var97;
                           if (var98 == 0) {
                              byte var99 = var73;
                              if (var99 != 0) {
                                 break label107;
                              }

                              MinecraftClient var43 = b;
                              BlockPos var45 = var24;
                              ClientWorld var44 = var43.world;
                              BlockState var46 = var44.getBlockState(var45);
                              var74 = ((byte)((var46.isReplaceable()) ? 1 : 0));
                           }

                           int var101 = var11;
                           byte var100 = var74;
                           byte var76 = var100;
                           byte var75 = var100;
                           if (var101 == 0) {
                              byte var102 = var75;
                              if (var102 == 0) {
                                 break label107;
                              }

                              BlockPos var48 = var24;
                              double var119 = var48.getX() + 0.5;
                              BlockPos var49 = var24;
                              double var10002 = var49.getY() + 0.5;
                              BlockPos var50 = var24;
                              double var10003 = var50.getZ() + 0.5;
                              Object[] var10006 = new Object[]{null, null, null, var5};
                              var10006[2] = var10003;
                              var10006[1] = var10002;
                              var10006[0] = var119;
                              Object[] var52 = var10006;
                              CartPearlCatch var51 = this;
                              var76 = ((byte)((var51.fReturningBoolean(var52)) ? 1 : 0));
                           }

                           byte var103 = var76;
                           label76:
                           if (var103 != 0) {
                              BlockPos var53 = var24;
                              double var121 = var53.getX() + 0.5;
                              BlockPos var54 = var24;
                              double var122 = var54.getY() + 0.0625;
                              BlockPos var55 = var24;
                              Vec3d var25 = new Vec3d(var121, var122, var55.getZ() + 0.5);
                              ExplosionDamageUtil var116 = Prestige.f;
                              MinecraftClient var56 = b;
                              ClientPlayerEntity var120 = var56.player;
                              Object[] var123 = new Object[]{null, null, null, var7};
                              var123[2] = var14;
                              var123[1] = var25;
                              var123[0] = var120;
                              Object[] var58 = var123;
                              ExplosionDamageUtil var57 = var116;
                              double var117 = var57.gReturningVoid(var58);
                              int var106 = var11;
                              double var104 = var117;
                              double var79 = var104;
                              double var77 = var104;
                              if (var106 == 0) {
                                 FloatSetting var59 = this.d;
                                 Float var60 = (Float)var59.aReturningObject();
                                 double var125;
                                 int var107 = (var125 = var77 - var60.floatValue()) == 0.0 ? 0 : (var125 < 0.0 ? -1 : 1);
                                 if (var107 > 0) {
                                    break label76;
                                 }

                                 var123 = new Object[]{null, null, null, var9};
                                 var123[2] = var12;
                                 var123[1] = var25;
                                 var123[0] = var2;
                                 Object[] var64 = var123;
                                 CartPearlCatch var63 = this;
                                 var79 = var63.aReturningDouble(var64);
                              }

                              double var26 = var79;
                              int var108 = var11;
                              if (var108 != 0) {
                                 break label87;
                              }

                              double var126;
                              int var109 = (var126 = var26 - var18) == 0.0 ? 0 : (var126 < 0.0 ? -1 : 1);
                              if (var109 >= 0) {
                                 var18 = var26;
                                 var17 = var24;
                              }
                           }
                        }

                        var22++;
                     }

                     var110 = var11;
                  } while (var110 == 0);

                  var21++;
                  int var111 = var11;
                  if (var111 != 0) {
                     break label95;
                  }
                  break;
               }
            }

            var20++;
            int var112 = var11;
            if (var112 != 0) {
               return var17;
            }
            break;
         }
      }
   }

   private int aReturningInt(Object[] var1) {
      int var7;
      double var9;
      double var11;
      double var13;
      long var159;
      double var161;
      double var162;
      double var163;
      label93: {
         float var3 = (Float)var1[0];
         float var4 = (Float)var1[1];
         float var2 = (Float)var1[2];
         var159 = (Long)var1[3];
         var159 = 33010110281137L ^ var159;
         MinecraftClient var38 = b;
         ClientPlayerEntity var39 = var38.player;
         Vec3d var8 = var39.getEyePos();
         int var10000 = Event.cReturningInt();
         Vec3d var40 = var8;
         var9 = var40.x;
         Vec3d var41 = var8;
         var11 = var41.y - 0.1;
         Vec3d var42 = var8;
         var13 = var42.z;
         var7 = var10000;
         double var43 = var3;
         double var15 = Math.toRadians(var43);
         double var45 = var4;
         double var17 = Math.toRadians(var45);
         double var47 = var15;
         double var165 = -Math.sin(var47);
         double var49 = var17;
         var161 = var165 * Math.cos(var49);
         double var51 = var17;
         var162 = -Math.sin(var51);
         double var53 = var15;
         double var166 = Math.cos(var53);
         double var55 = var17;
         double var23 = var166 * Math.cos(var55);
         double var57 = var161 * var161 + var162 * var162 + var23 * var23;
         double var25 = Math.sqrt(var57);
         float var60 = 1.05F;
         float var59 = var2;
         double var27 = Math.min(var59, var60) * 3.0;
         var161 = var161 / var25 * var27;
         var162 = var162 / var25 * var27;
         var163 = var23 / var25 * var27;
         MinecraftClient var61 = b;
         ClientPlayerEntity var62 = var61.player;
         Vec3d var63 = var62.getVelocity();
         var161 += var63.x;
         MinecraftClient var64 = b;
         ClientPlayerEntity var65 = var64.player;
         Vec3d var66 = var65.getVelocity();
         double var167 = var163 + var66.z;
         int var124 = var7;
         double var122 = var167;
         double var101 = var122;
         double var99 = var122;
         if (var124 != 0) {
            var163 = var99;
            MinecraftClient var67 = b;
            ClientPlayerEntity var68 = var67.player;
            boolean var125 = var68.isOnGround();
            if (var125) {
               break label93;
            }

            MinecraftClient var69 = b;
            ClientPlayerEntity var70 = var69.player;
            Vec3d var71 = var70.getVelocity();
            double var126 = var162 + var71.y;
            var101 = var126;
         }

         var162 = var101;
      }

      Box var29 = new Box(this.n + 0.01, this.o + 0.0625, this.p + 0.01, this.n + 0.99, this.o + 0.7625, this.p + 0.99);
      BlockPos var30 = new BlockPos(this.n, this.o, this.p);
      int var31 = 1;

      label86:
      while (true) {
         int var103 = var31;

         label83:
         while (true) {
            short var10001 = 23179;
            long var10002 = 243996474444523619L ^ var159;
            byte var129 = 60;
            int var128 = var103;
            if (var128 > var129) {
               break;
            }

            Vec3d var32 = new Vec3d(var9, var11, var13);
            double var73 = var161 * var161 + var162 * var162 + var163 * var163;
            double var33 = Math.sqrt(var73);
            byte var168 = 1;
            double var75 = var33 / 0.25;
            int var78 = (int)Math.ceil(var75);
            int var35 = Math.max(1, var78);
            int var131 = var7;
            byte var130 = 0;
            byte var121 = var130;
            byte var104 = var130;
            if (var131 == 0) {
               return var121;
            }

            int var36 = var104;

            int var139;
            do {
               int var133 = var35;
               int var132 = var36;
               if (var132 >= var133) {
                  break;
               }

               var9 += var161 / var35;
               var11 += var162 / var35;
               var13 += var163 / var35;
               int var134 = var7;
               if (var134 != 0) {
                  double var84 = var13;
                  double var82 = var11;
                  double var80 = var9;
                  Box var79 = var29;
                  var168 = ((byte)((var79.contains(var80, var82, var84)) ? 1 : 0));
                  int var136 = var7;
                  byte var135 = var168;
                  var103 = var135;
                  byte var105 = var135;
                  if (var136 == 0) {
                     continue label83;
                  }

                  byte var137 = var105;
                  byte var106 = var137;
                  byte var138 = var106;
                  if (var138 != 0) {
                     return var31;
                  }

                  var36++;
               }

               var139 = var7;
            } while (var139 != 0);

            double var117;
            double var119;
            label100: {
               int var116;
               label101: {
                  label102: {
                     Vec3d var164 = new Vec3d(var9, var11, var13);
                     MinecraftClient var88 = b;
                     ClientWorld var170 = var88.world;
                     MinecraftClient var89 = b;
                     RaycastContext var91 = new RaycastContext(var32, var164, ShapeType.OUTLINE, FluidHandling.NONE, var89.player);
                     ClientWorld var90 = var170;
                     BlockHitResult var37 = var90.raycast(var91);
                     int var141 = var7;
                     BlockHitResult var140 = var37;
                     BlockHitResult var108 = var140;
                     BlockHitResult var107 = var140;
                     if (var141 != 0) {
                        BlockHitResult var142 = var107;
                        if (var142 == null) {
                           break label102;
                        }

                        var108 = var37;
                     }

                     int var144 = var7;
                     BlockHitResult var143 = var108;
                     BlockHitResult var110 = var143;
                     BlockHitResult var109 = var143;
                     if (var144 != 0) {
                        BlockHitResult var93 = var109;
                        Type var171 = var93.getType();
                        Type var146 = Type.BLOCK;
                        Type var145 = var171;
                        if (var145 != var146) {
                           break label102;
                        }

                        BlockHitResult var147 = var37;
                        var110 = var147;
                     }

                     BlockHitResult var96 = var110;
                     BlockPos var172 = var96.getBlockPos();
                     BlockPos var98 = var30;
                     BlockPos var97 = var172;
                     var168 = ((byte)((var97.equals(var98)) ? 1 : 0));
                     int var149 = var7;
                     byte var148 = var168;
                     var116 = var148;
                     byte var111 = var148;
                     if (var149 == 0) {
                        break label101;
                     }

                     byte var150 = var111;
                     if (var150 == 0) {
                        return -1;
                     }
                  }

                  double var175 = this.o - 3;
                  int var155 = var7;
                  double var153 = var175;
                  double var151 = var11;
                  var117 = var151;
                  var119 = var153;
                  double var112 = var151;
                  double var114 = var153;
                  if (var155 == 0) {
                     break label100;
                  }

                  double var176;
                  int var156 = (var176 = var112 - var114) == 0.0 ? 0 : (var176 < 0.0 ? -1 : 1);
                  var116 = var156;
               }

               int var157 = var116;
               if (var157 < 0) {
                  return -1;
               }

               var161 *= 0.99;
               var163 *= 0.99;
               double var174 = var162 * 0.99;
               var119 = 0.05;
               var117 = var174;
            }

            var162 = var117 - var119;
            var31++;
            int var158 = var7;
            if (var158 != 0) {
               continue label86;
            }
            break;
         }

         
      }
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 33010110281137L ^ var3;
      MinecraftClient var17 = b;
      ClientPlayerEntity var18 = var17.player;
      Vec3d var6 = var18.getEyePos();
      Vec3d var19 = var2;
      Vec3d var20 = var6;
      double var7 = var19.x - var20.x;
      int var53 = Event.bReturningInt();
      Vec3d var21 = var2;
      Vec3d var22 = var6;
      double var9 = var21.y - (var22.y - 0.1);
      int var5 = var53;
      Vec3d var23 = var2;
      Vec3d var24 = var6;
      double var11 = var23.z - var24.z;
      double var25 = var7 * var7 + var9 * var9 + var11 * var11;
      double var13 = Math.sqrt(var25);
      int var51 = var5;
      double var49 = 1.0E-6;
      double var47 = var13;
      double var43 = var47;
      double var45 = var49;
      double var39 = var47;
      double var41 = var49;
      if (var51 == 0) {
         double var55;
         int var52 = (var55 = var39 - var41) == 0.0 ? 0 : (var55 < 0.0 ? -1 : 1);
         if (var52 < 0) {
            return null;
         }

         double var31 = var7;
         double var29 = var11;
         double var33 = Math.atan2(var29, var31);
         double var54 = Math.toDegrees(var33);
         var45 = 90.0;
         var43 = var54;
      }

      float var15 = (float)(var43 - var45);
      double var35 = var9 / var13;
      double var37 = Math.asin(var35);
      float var16 = (float)(-Math.toDegrees(var37));
      return new Rotation(var15, var16);
   }

   private boolean aReturningBoolean(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      var3 = 33010110281137L ^ var3;
      long var5 = var3 ^ 123201317721435L;
      long var7 = var3 ^ 86337747108497L;
      int var10000 = Event.cReturningInt();
      Vec3d var10 = new Vec3d(this.n + 0.5, this.o + 0.45, this.p + 0.5);
      int var9 = var10000;
      short var42 = 22083;
      long var10001 = 1986570132027364239L ^ var3;
      double[] var43 = new double[]{0.0, 0.15, 0.3, 0.5, 0.8, 1.2, 0.0, 0.0};
      short var10002 = 2411;
      long var10003 = 467821302324137147L ^ var3;
      var43[6] = 1.8;
      var10002 = 2687;
      var10003 = 8577602824915062706L ^ var3;
      var43[7] = 2.6;
      double[] var11 = var43;
      int var12 = var11.length;
      int var40;
      do {
         int var35 = var12;
         int var34 = var13;
         if (var34 >= var35) {
            break;
         }

         label23: {
            double var14 = var11[var13];
            double var21 = var14;
            Vec3d var18 = var10;
            Object[] var26 = new Object[]{var18.add(var19, var21, var23), var5};
            CartPearlCatch var25 = this;
            Rotation var16 = var25.bReturningdx_C0210(var26);
            Rotation var36 = var16;
            if (var36 != null) {
               Object[] var29 = new Object[0];
               Rotation var28 = var16;
               float var44 = var28.aReturningFloat(var29);
               Object[] var31 = new Object[0];
               Rotation var30 = var16;
               float var46 = var30.bReturningFloat(var31);
               Object[] var10006 = new Object[]{null, null, null, var7};
               var10006[2] = var2;
               var10006[1] = var46;
               var10006[0] = var44;
               Object[] var33 = var10006;
               CartPearlCatch var32 = this;
               int var17 = var32.aReturningInt(var33);
               int var37 = var9;
               if (var37 == 0) {
                  break label23;
               }

               
               if (var38 != var39) {
                  this.y = var16;
                  this.z = var17;
                  return true;
               }
            }

            var13++;
         }

         var40 = var9;
      } while (var40 != 0);

      return false;
   }

   private BlockPos bReturningBlockPos(Object[] var1) {
      Vec3d var4 = (Vec3d)var1[0];
      long var2 = (Long)var1[1];
      var2 = 33010110281137L ^ var2;
      long var5 = var2 ^ 1603663936195L;
      long var7 = var2 ^ 36603735348323L;
      int var10000 = Event.cReturningInt();
      Object[] var39 = new Object[]{var4, var5};
      CartPearlCatch var38 = this;
      Rotation var10 = var38.bReturningdx_C0210(var39);
      int var9 = var10000;
      Rotation var144 = var10;
      if (var144 == null) {
         return null;
      }

      double var12;
      double var14;
      double var16;
      double var178;
      double var179;
      double var180;
      label94: {
         MinecraftClient var41 = b;
         ClientPlayerEntity var42 = var41.player;
         Vec3d var11 = var42.getEyePos();
         Vec3d var43 = var11;
         var12 = var43.x;
         Vec3d var44 = var11;
         var14 = var44.y - 0.1;
         Vec3d var45 = var11;
         var16 = var45.z;
         Object[] var47 = new Object[0];
         Rotation var46 = var10;
         double var48 = var46.aReturningFloat(var47);
         double var18 = Math.toRadians(var48);
         Object[] var51 = new Object[0];
         Rotation var50 = var10;
         double var52 = var50.bReturningFloat(var51);
         double var20 = Math.toRadians(var52);
         double var54 = var18;
         double var181 = -Math.sin(var54);
         double var56 = var20;
         var178 = var181 * Math.cos(var56);
         double var58 = var20;
         var179 = -Math.sin(var58);
         double var60 = var18;
         double var182 = Math.cos(var60);
         double var62 = var20;
         double var26 = var182 * Math.cos(var62);
         double var64 = var178 * var178 + var179 * var179 + var26 * var26;
         double var28 = Math.sqrt(var64);
         var178 = var178 / var28 * 3.15;
         var179 = var179 / var28 * 3.15;
         var180 = var26 / var28 * 3.15;
         MinecraftClient var66 = b;
         ClientPlayerEntity var67 = var66.player;
         Vec3d var68 = var67.getVelocity();
         var178 += var68.x;
         MinecraftClient var69 = b;
         ClientPlayerEntity var70 = var69.player;
         Vec3d var71 = var70.getVelocity();
         double var183 = var180 + var71.z;
         int var147 = var9;
         double var145 = var183;
         double var130 = var145;
         double var128 = var145;
         if (var147 != 0) {
            var180 = var128;
            MinecraftClient var72 = b;
            ClientPlayerEntity var73 = var72.player;
            boolean var148 = var73.isOnGround();
            if (var148) {
               break label94;
            }

            MinecraftClient var74 = b;
            ClientPlayerEntity var75 = var74.player;
            Vec3d var76 = var75.getVelocity();
            double var149 = var179 + var76.y;
            var130 = var149;
         }

         var179 = var130;
      }

      BlockPos var30 = new BlockPos(this.n, this.o, this.p);
      MinecraftClient var78 = b;
      ClientPlayerEntity var79 = var78.player;
      Box var184 = var79.getBoundingBox();
      double var81 = 0.3;
      Box var80 = var184;
      Box var31 = var80.expand(var81);
      while (true) {
         int var132 = var32;

         label85:
         while (true) {
            short var10001 = 1767;
            long var10002 = 3311828600112639145L ^ var2;
            byte var152 = 60;
            int var151 = var132;
            if (var151 < var152) {
               double var83 = var178 * var178 + var179 * var179 + var180 * var180;
               double var33 = Math.sqrt(var83);
               byte var185 = 1;
               double var85 = var33 / 0.25;
               int var88 = (int)Math.ceil(var85);
               int var35 = Math.max(1, var88);
               int var174;
               do {
                  int var154 = var35;
                  int var153 = var36;
                  if (var153 >= var154) {
                     break;
                  }

                  var12 += var178 / var35;
                  var14 += var179 / var35;
                  var16 += var180 / var35;
                  double var93 = var16;
                  double var91 = var14;
                  double var89 = var12;
                  BlockPos var37 = BlockPos.ofFloored(var89, var91, var93);
                  BlockPos var96 = var30;
                  BlockPos var95 = var37;
                  var185 = ((byte)((var95.equals(var96)) ? 1 : 0));
                  int var156 = var9;
                  byte var155 = var185;
                  var132 = var155;
                  byte var133 = var155;
                  if (var156 == 0) {
                     continue label85;
                  }

                  int var158 = var9;
                  byte var157 = var133;
                  byte var135 = var157;
                  byte var134 = var157;
                  if (var158 != 0) {
                     byte var159 = var134;
                     if (var159 != 0) {
                        return null;
                     }

                     BlockPos var98 = var30;
                     BlockPos var100 = var98.up();
                     BlockPos var99 = var37;
                     byte var160 = ((byte)((var99.equals(var100)) ? 1 : 0));
                     var135 = var160;
                  }

                  int var162 = var9;
                  byte var161 = var135;
                  byte var137 = var161;
                  byte var136 = var161;
                  if (var162 != 0) {
                     byte var163 = var136;
                     if (var163 != 0) {
                        return null;
                     }

                     Box var105 = new Box(var37);
                     Box var104 = var31;
                     var137 = ((byte)((var104.intersects(var105)) ? 1 : 0));
                  }

                  label101: {
                     int var165 = var9;
                     byte var164 = var137;
                     byte var139 = var164;
                     byte var138 = var164;
                     if (var165 != 0) {
                        byte var166 = var138;
                        if (var166 != 0) {
                           break label101;
                        }

                        BlockPos var107 = var37;
                        double var189 = var107.getX() + 0.5;
                        BlockPos var108 = var37;
                        double var191 = var108.getY();
                        BlockPos var109 = var37;
                        double var10003 = var109.getZ() + 0.5;
                        Object[] var10006 = new Object[]{null, null, null, var7};
                        var10006[2] = var10003;
                        var10006[1] = var191;
                        var10006[0] = var189;
                        Object[] var111 = var10006;
                        CartPearlCatch var110 = this;
                        var139 = ((byte)((var110.fReturningBoolean(var111)) ? 1 : 0));
                     }

                     int var168 = var9;
                     byte var167 = var139;
                     byte var141 = var167;
                     byte var140 = var167;
                     if (var168 != 0) {
                        byte var169 = var140;
                        if (var169 == 0) {
                           break label101;
                        }

                        MinecraftClient var113 = b;
                        BlockPos var115 = var37;
                        ClientWorld var114 = var113.world;
                        BlockState var116 = var114.getBlockState(var115);
                        var141 = ((byte)((var116.isReplaceable()) ? 1 : 0));
                     }

                     int var171 = var9;
                     byte var170 = var141;
                     byte var143 = var170;
                     byte var142 = var170;
                     if (var171 != 0) {
                        byte var172 = var142;
                        if (var172 == 0) {
                           break label101;
                        }

                        MinecraftClient var118 = b;
                        ClientWorld var187 = var118.world;
                        BlockPos var119 = var37;
                        BlockPos var121 = var119.down();
                        ClientWorld var120 = var187;
                        BlockState var188 = var120.getBlockState(var121);
                        MinecraftClient var122 = b;
                        ClientWorld var190 = var122.world;
                        BlockPos var123 = var37;
                        BlockPos var192 = var123.down();
                        Direction var127 = Direction.UP;
                        BlockPos var126 = var192;
                        ClientWorld var125 = var190;
                        BlockState var124 = var188;
                        var143 = ((byte)((var124.isSideSolidFullSquare((BlockView)var125, var126, var127)) ? 1 : 0));
                     }

                     byte var173 = var143;
                     if (var173 != 0) {
                        return var37;
                     }
                  }

                  var36++;
                  var174 = var9;
               } while (var174 != 0);

               var178 *= 0.99;
               var180 *= 0.99;
               var179 = var179 * 0.99 - 0.05;
               var32++;
               int var175 = var9;
               if (var175 != 0) {
                  break;
               }
            }

            return null;
         }
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      int var6;
      double var8;
      double var10;
      double var12;
      long var190;
      double var192;
      double var193;
      double var194;
      label127: {
         float var5 = (Float)var1[0];
         float var2 = (Float)var1[1];
         var190 = (Long)var1[2];
         var190 = 33010110281137L ^ var190;
         MinecraftClient var37 = b;
         ClientPlayerEntity var38 = var37.player;
         Vec3d var7 = var38.getEyePos();
         Vec3d var39 = var7;
         var8 = var39.x;
         Vec3d var40 = var7;
         var10 = var40.y - 0.1;
         int var10000 = Event.cReturningInt();
         Vec3d var41 = var7;
         var12 = var41.z;
         double var42 = var5;
         double var14 = Math.toRadians(var42);
         var6 = var10000;
         double var44 = var2;
         double var16 = Math.toRadians(var44);
         double var46 = var14;
         double var196 = -Math.sin(var46);
         double var48 = var16;
         var192 = var196 * Math.cos(var48);
         double var50 = var16;
         var193 = -Math.sin(var50);
         double var52 = var14;
         double var197 = Math.cos(var52);
         double var54 = var16;
         double var22 = var197 * Math.cos(var54);
         double var56 = var192 * var192 + var193 * var193 + var22 * var22;
         double var24 = Math.sqrt(var56);
         var192 = var192 / var24 * 3.15;
         var193 = var193 / var24 * 3.15;
         var194 = var22 / var24 * 3.15;
         MinecraftClient var58 = b;
         ClientPlayerEntity var59 = var58.player;
         Vec3d var60 = var59.getVelocity();
         var192 += var60.x;
         MinecraftClient var61 = b;
         ClientPlayerEntity var62 = var61.player;
         Vec3d var63 = var62.getVelocity();
         double var198 = var194 + var63.z;
         int var142 = var6;
         double var140 = var198;
         double var110 = var140;
         double var108 = var140;
         if (var142 != 0) {
            var194 = var108;
            MinecraftClient var64 = b;
            ClientPlayerEntity var65 = var64.player;
            boolean var143 = var65.isOnGround();
            if (var143) {
               break label127;
            }

            MinecraftClient var66 = b;
            ClientPlayerEntity var67 = var66.player;
            Vec3d var68 = var67.getVelocity();
            double var144 = var193 + var68.y;
            var110 = var144;
         }

         var193 = var110;
      }

      Box var26 = new Box(this.n + 0.01, this.o + 0.0625, this.p + 0.01, this.n + 0.99, this.o + 0.7625, this.p + 0.99);
      BlockPos var27 = new BlockPos(this.n, this.o, this.p);
      BlockPos var146 = this.q;
      Box var112;
      if (var146 != null) {
         Box var147 = new Box(this.q);
         var112 = var147;
      } else {
         var112 = null;
      }

      Box var28 = var112;
      byte var29 = 0;
      label121:
      while (true) {
         int var113 = var30;

         byte var139;
         label117:
         while (true) {
            short var10001 = 1767;
            long var10002 = 3311750128167931068L ^ var190;
            byte var149 = 60;
            int var148 = var113;
            if (var148 < var149) {
               Vec3d var31 = new Vec3d(var8, var10, var12);
               double var71 = var192 * var192 + var193 * var193 + var194 * var194;
               double var32 = Math.sqrt(var71);
               byte var199 = 1;
               double var73 = var32 / 0.25;
               int var76 = (int)Math.ceil(var73);
               int var34 = Math.max(1, var76);
               int var151 = var6;
               byte var150 = 0;
               var139 = var150;
               byte var114 = var150;
               if (var151 == 0) {
                  break;
               }

               int var35 = var114;

               int var170;
               do {
                  int var153 = var34;
                  int var152 = var35;
                  if (var152 >= var153) {
                     break;
                  }

                  var8 += var192 / var34;
                  var10 += var193 / var34;
                  var12 += var194 / var34;
                  int var155 = var6;
                  byte var154 = var29;
                  var113 = var154;
                  byte var115 = var154;
                  if (var155 == 0) {
                     continue label117;
                  }

                  byte var122;
                  int var157 = var6;
                  byte var156 = var115;
                  var122 = var156;
                  byte var116 = var156;
                  label109:
                  if (var157 != 0) {
                     Box var121;
                     label80: {
                        byte var158 = var116;
                        if (var158 == 0) {
                           int var160 = var6;
                           Box var159 = var28;
                           var121 = var159;
                           Box var117 = var159;
                           if (var160 == 0) {
                              break label80;
                           }

                           Box var161 = var117;
                           Box var118 = var161;
                           Box var162 = var118;
                           if (var162 != null) {
                              double var85 = var12;
                              double var83 = var10;
                              double var81 = var8;
                              Box var80 = var28;
                              var199 = ((byte)((var80.contains(var81, var83, var85)) ? 1 : 0));
                              int var164 = var6;
                              byte var163 = var199;
                              var122 = var163;
                              byte var119 = var163;
                              if (var164 == 0) {
                                 break label109;
                              }

                              byte var165 = var119;
                              byte var120 = var165;
                              byte var166 = var120;
                              if (var166 != 0) {
                                 var29 = 1;
                              }
                           }
                        }

                        var121 = var26;
                     }

                     double var94 = var12;
                     double var92 = var10;
                     double var90 = var8;
                     Box var89 = var121;
                     var122 = ((byte)((var89.contains(var90, var92, var94)) ? 1 : 0));
                  }

                  int var168 = var6;
                  byte var167 = var122;
                  byte var124 = var167;
                  byte var123 = var167;
                  if (var168 == 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var124);
                  }

                  byte var169 = var123;
                  if (var169 != 0) {
                     var124 = var29;
                     return dev.prestige.recovery.SourceSupport.asBoolean(var124);
                  }

                  var35++;
                  var170 = var6;
               } while (var170 != 0);

               double var135;
               double var137;
               label133: {
                  int var134;
                  label134: {
                     label135: {
                        Vec3d var195 = new Vec3d(var8, var10, var12);
                        MinecraftClient var97 = b;
                        ClientWorld var201 = var97.world;
                        MinecraftClient var98 = b;
                        RaycastContext var100 = new RaycastContext(var31, var195, ShapeType.OUTLINE, FluidHandling.NONE, var98.player);
                        ClientWorld var99 = var201;
                        BlockHitResult var36 = var99.raycast(var100);
                        int var172 = var6;
                        BlockHitResult var171 = var36;
                        BlockHitResult var126 = var171;
                        BlockHitResult var125 = var171;
                        if (var172 != 0) {
                           BlockHitResult var173 = var125;
                           if (var173 == null) {
                              break label135;
                           }

                           var126 = var36;
                        }

                        int var175 = var6;
                        BlockHitResult var174 = var126;
                        BlockHitResult var128 = var174;
                        BlockHitResult var127 = var174;
                        if (var175 != 0) {
                           BlockHitResult var102 = var127;
                           Type var202 = var102.getType();
                           Type var177 = Type.BLOCK;
                           Type var176 = var202;
                           if (var176 != var177) {
                              break label135;
                           }

                           BlockHitResult var178 = var36;
                           var128 = var178;
                        }

                        BlockHitResult var105 = var128;
                        BlockPos var203 = var105.getBlockPos();
                        BlockPos var107 = var27;
                        BlockPos var106 = var203;
                        var199 = ((byte)((var106.equals(var107)) ? 1 : 0));
                        int var180 = var6;
                        byte var179 = var199;
                        var134 = var179;
                        byte var129 = var179;
                        if (var180 == 0) {
                           break label134;
                        }

                        byte var181 = var129;
                        if (var181 == 0) {
                           return false;
                        }
                     }

                     double var206 = this.o - 3;
                     int var186 = var6;
                     double var184 = var206;
                     double var182 = var10;
                     var135 = var182;
                     var137 = var184;
                     double var130 = var182;
                     double var132 = var184;
                     if (var186 == 0) {
                        break label133;
                     }

                     double var207;
                     int var187 = (var207 = var130 - var132) == 0.0 ? 0 : (var207 < 0.0 ? -1 : 1);
                     var134 = var187;
                  }

                  int var188 = var134;
                  if (var188 < 0) {
                     return false;
                  }

                  var192 *= 0.99;
                  var194 *= 0.99;
                  double var205 = var193 * 0.99;
                  var137 = 0.05;
                  var135 = var205;
               }

               var193 = var135 - var137;
               var30++;
               int var189 = var6;
               if (var189 != 0) {
                  continue label121;
               }
            }

            var139 = 0;
            break;
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(var139);
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 76497144514516L ^ 66924141010030L;
      var10001 = 76497144514516L ^ 124016021873978L;
      var10001 = 76497144514516L ^ 114397745316413L;
      var10001 = 76497144514516L ^ 78406238768996L;
      var10001 = 76497144514516L ^ 72763067254311L;
      var10001 = 76497144514516L ^ 72219744417341L;
      var10001 = 76497144514516L ^ 67061075627967L;
      var10001 = 76497144514516L ^ 21042029677650L;
      var10001 = 76497144514516L ^ 86293719149291L;
      var10001 = 76497144514516L ^ 4838543704738L;
      var10001 = 76497144514516L ^ 101945609483296L;
      var10001 = 76497144514516L ^ 128309832934277L;
      var10001 = 76497144514516L ^ 33820515288528L;
      var10001 = 76497144514516L ^ 77420679562869L;
      var10001 = 76497144514516L ^ 87612710995953L;
      var10001 = 76497144514516L ^ 122845071551048L;
      var10001 = 76497144514516L ^ 89015942056858L;
      var10001 = 76497144514516L ^ 20116460012187L;
      var10001 = 76497144514516L ^ 41898683566685L;
      var10001 = 76497144514516L ^ 64598984291861L;
      var10001 = 76497144514516L ^ 5332954973877L;
      var10001 = 76497144514516L ^ 86043807593200L;
      int var48 = Event.cReturningInt();
      int var406 = var48;
      MinecraftClient var405 = b;
      MinecraftClient var323 = var405;
      MinecraftClient var322 = var405;
      if (var406 != 0) {
         MinecraftClient var51 = var322;
         ClientWorld var407 = var51.world;
         if (var407 == null) {
            return;
         }

         MinecraftClient var408 = b;
         var323 = var408;
      }

      MinecraftClient var54 = var323;
      ClientPlayerEntity var409 = var54.player;
      if (var409 != null) {
         int var411 = var48;
         CartPearlCatch var410 = this;
         CartPearlCatch var325 = var410;
         CartPearlCatch var324 = var410;
         if (var411 != 0) {
            CartPearlCatchState var413 = CartPearlCatchState.IDLE;
            CartPearlCatchState var412 = var324.k;
            if (var412 == var413) {
               Object[] var58 = new Object[]{3150377552048L};
               CartPearlCatch var57 = this;
               var57.o(var58);
               return;
            }

            var325 = this;
         }

         CartPearlCatch var335;
         label564: {
            CartPearlCatch var363;
            label565: {
               label531: {
                  label482: {
                     label504: {
                        label529: {
                           label506: {
                              label530: {
                                 label508: {
                                    label509: {
                                       label510: {
                                          CartPearlCatch var329;
                                          label474: {
                                             int var10000 = ++var325.u;
                                             int var415 = var48;
                                             int var414 = var10000;
                                             int var328 = var414;
                                             int var326 = var414;
                                             if (var415 != 0) {
                                                byte var417 = 100;
                                                int var416 = var326;
                                                if (var416 > var417) {
                                                   Object[] var62 = new Object[]{"timed out", 71791682978145L};
                                                   CartPearlCatch var61 = this;
                                                   var61.lReturningVoid(var62);
                                                   return;
                                                }

                                                int var419 = var48;
                                                CartPearlCatch var418 = this;
                                                var329 = var418;
                                                CartPearlCatch var327 = var418;
                                                if (var419 == 0) {
                                                   break label474;
                                                }

                                                CartPearlCatchState var64 = var327.k;
                                                int var420 = var64.ordinal();
                                                var328 = var420;
                                             }

                                             int var421 = var328;
                                             switch (var421) {
                                                case 1:
                                                   var329 = this;
                                                   break;
                                                case 2:
                                                   break label510;
                                                case 3:
                                                   break label509;
                                                case 4:
                                                   break label508;
                                                case 5:
                                                   break label530;
                                                case 6:
                                                   break label506;
                                                case 7:
                                                   break label529;
                                                case 8:
                                                   break label504;
                                                case 9:
                                                   break label482;
                                                case 10:
                                                   break label531;
                                                default:
                                                   return;
                                             }
                                          }

                                          Object[] var67 = new Object[]{133380687977402L};
                                          CartPearlCatch var66 = var329;
                                          EnderPearlEntity var49 = var66.aReturningEnderPearlEntity(var67);
                                          int var422 = var48;
                                          if (var422 == 0) {
                                             return;
                                          }

                                          EnderPearlEntity var423 = var49;
                                          if (var423 == null) {
                                             Object[] var70 = new Object[]{"too late — the pearl already landed", 71791682978145L};
                                             CartPearlCatch var69 = this;
                                             var69.lReturningVoid(var70);
                                             return;
                                          }

                                          label454: {
                                             Object[] var73 = new Object[]{var49, 4656165433833L};
                                             CartPearlCatch var72 = this;
                                             int var50 = var72.cReturningInt(var73);
                                             int var425 = var48;
                                             byte var424 = ((byte)((this.r) ? 1 : 0));
                                             int var331 = var424;
                                             byte var330 = var424;
                                             if (var425 != 0) {
                                                byte var426 = var330;
                                                if (var426 != 0) {
                                                   Object[] var10004 = new Object[]{null, 100401620500996L};
                                                   var10004[0] = 1.05F;
                                                   Object[] var76 = var10004;
                                                   CartPearlCatch var75 = this;
                                                   var75.aReturningBoolean(var76);
                                                   int var427 = var48;
                                                   if (var427 != 0) {
                                                      Object[] var79 = new Object[]{27672188482548L};
                                                      CartPearlCatch var78 = this;
                                                      int var638 = var78.dReturningInt(var79);
                                                      int var80 = this.z;
                                                      int var429 = var638 + Math.max(var80, 0);
                                                      int var428 = var50;
                                                      if (var428 > var429) {
                                                         break label454;
                                                      }

                                                      this.k = CartPearlCatchState.SWITCH_RAIL;
                                                   }

                                                   int var430 = var48;
                                                   if (var430 != 0) {
                                                      break label454;
                                                   }
                                                }

                                                int var431 = var50;
                                                var331 = var431;
                                             }

                                             Object[] var86 = new Object[]{27672188482548L};
                                             CartPearlCatch var85 = this;
                                             int var433 = var85.dReturningInt(var86) + 20;
                                             int var432 = var331;
                                             if (var432 <= var433) {
                                                this.k = CartPearlCatchState.SWITCH_RAIL;
                                             }
                                          }

                                          int var434 = var48;
                                          if (var434 != 0) {
                                             return;
                                          }
                                       }

                                       Object[] var89 = new Object[]{13096216816959L};
                                       CartPearlCatch var88 = this;
                                       int var590 = var88.eReturningInt(var89);
                                       int var436 = var48;
                                       int var435 = var590;
                                       int var334 = var435;
                                       int var332 = var435;
                                       if (var436 != 0) {
                                          
                                          if (var437 == var438) {
                                             Object[] var92 = new Object[]{"no rail in hotbar", 71791682978145L};
                                             CartPearlCatch var91 = this;
                                             var91.lReturningVoid(var92);
                                             return;
                                          }

                                          int var440 = var48;
                                          CartPearlCatch var439 = this;
                                          var335 = var439;
                                          CartPearlCatch var333 = var439;
                                          if (var440 == 0) {
                                             break label564;
                                          }

                                          double var639 = this.n + 0.5;
                                          double var10002 = this.o + 0.5;
                                          double var10003 = this.p + 0.5;
                                          Object[] var10006 = new Object[]{null, null, null, 23533245369422L};
                                          var10006[2] = var10003;
                                          var10006[1] = var10002;
                                          var10006[0] = var639;
                                          Object[] var95 = var10006;
                                          CartPearlCatch var94 = var333;
                                          byte var441 = ((byte)((var94.fReturningBoolean(var95)) ? 1 : 0));
                                          var334 = var441;
                                       }

                                       int var442 = var334;
                                       if (var442 == 0) {
                                          var335 = this;
                                          break label564;
                                       }

                                       BlockPos var598 = new BlockPos(this.n, this.o - 1, this.p);
                                       Object[] var647 = new Object[]{null, 72518082610550L};
                                       var647[0] = var590;
                                       Object[] var99 = var647;
                                       InventoryUtil.aReturningVoid(var99);
                                       Object[] var101 = new Object[]{
                                          new BlockHitResult(new Vec3d(this.n + 0.5, this.o, this.p + 0.5), Direction.UP, var598, false), 96591051752783L
                                       };
                                       CartPearlCatch var100 = this;
                                       var100.p(var101);
                                       IntSetting var102 = this.f;
                                       Integer var103 = (Integer)var102.aReturningObject();
                                       this.t = var103;
                                       this.k = CartPearlCatchState.SWITCH_CART;
                                       int var443 = var48;
                                       if (var443 != 0) {
                                          return;
                                       }
                                    }

                                    int var445 = var48;
                                    CartPearlCatch var444 = this;
                                    CartPearlCatch var338 = var444;
                                    CartPearlCatch var336 = var444;
                                    if (var445 != 0) {
                                       CartPearlCatch var446 = var336;
                                       CartPearlCatch var337 = var446;
                                       int var447 = var337.t;
                                       if (var447 > 0) {
                                          this.t--;
                                          return;
                                       }

                                       var338 = this;
                                    }

                                    Object[] var108 = new Object[]{50138069927401L};
                                    CartPearlCatch var107 = var338;
                                    Integer var591 = var107.aReturningBoxedInteger(var108);
                                    int var448 = var48;
                                    if (var448 == 0) {
                                       return;
                                    }

                                    Integer var449 = var591;
                                    if (var449 == null) {
                                       Object[] var111 = new Object[]{"no TNT carts", 71791682978145L};
                                       CartPearlCatch var110 = this;
                                       var110.lReturningVoid(var111);
                                       return;
                                    }

                                    MinecraftClient var113 = b;
                                    ClientPlayerEntity var114 = var113.player;
                                    PlayerInventory var603 = var114.getInventory();
                                    Integer var115 = var591;
                                    int var117 = var115;
                                    PlayerInventory var116 = var603;
                                    ItemStack var118 = var116.getStack(var117);
                                    Item var604 = var118.getItem();
                                    Item var451 = Items.TNT_MINECART;
                                    Item var450 = var604;
                                    if (var450 != var451) {
                                       return;
                                    }

                                    label440: {
                                       CartPearlCatch var342;
                                       label513: {
                                          double var640 = this.n + 0.5;
                                          double var644 = this.o + 0.5;
                                          double var648 = this.p + 0.5;
                                          Object[] var656 = new Object[]{null, null, null, 23533245369422L};
                                          var656[2] = var648;
                                          var656[1] = var644;
                                          var656[0] = var640;
                                          Object[] var121 = var656;
                                          CartPearlCatch var120 = this;
                                          boolean var605 = var120.fReturningBoolean(var121);
                                          int var453 = var48;
                                          boolean var452 = var605;
                                          boolean var341 = var452;
                                          boolean var339 = var452;
                                          if (var453 != 0) {
                                             boolean var454 = var339;
                                             if (!var454) {
                                                Object[] var124 = new Object[]{"cart out of reach", 71791682978145L};
                                                CartPearlCatch var123 = this;
                                                var123.lReturningVoid(var124);
                                                return;
                                             }

                                             Integer var126 = var591;
                                             int var606 = var126;
                                             Object[] var649 = new Object[]{null, 72518082610550L};
                                             var649[0] = var606;
                                             Object[] var127 = var649;
                                             InventoryUtil.aReturningVoid(var127);
                                             Object[] var128 = new Object[]{
                                                new BlockHitResult(
                                                   new Vec3d(this.n + 0.5, this.o + 0.125, this.p + 0.5),
                                                   Direction.UP,
                                                   new BlockPos(this.n, this.o, this.p),
                                                   false
                                                ),
                                                11253043183653L
                                             };
                                             ItemUseUtil.aReturningBoolean(var128);
                                             int var456 = var48;
                                             CartPearlCatch var455 = this;
                                             var342 = var455;
                                             CartPearlCatch var340 = var455;
                                             if (var456 == 0) {
                                                break label513;
                                             }

                                             boolean var457 = var340.r;
                                             var341 = var457;
                                          }

                                          boolean var458 = var341;
                                          if (var458) {
                                             IntSetting var130 = this.f;
                                             Integer var131 = (Integer)var130.aReturningObject();
                                             this.t = var131;
                                             this.k = CartPearlCatchState.SWITCH_FIRE;
                                             int var459 = var48;
                                             if (var459 != 0) {
                                                break label440;
                                             }
                                          }

                                          CartPearlCatch var460 = this;
                                          var342 = var460;
                                       }

                                       var342.k = CartPearlCatchState.SWITCH_BOW;
                                    }

                                    int var461 = var48;
                                    if (var461 != 0) {
                                       return;
                                    }
                                 }

                                 int var463 = var48;
                                 CartPearlCatch var462 = this;
                                 CartPearlCatch var345 = var462;
                                 CartPearlCatch var343 = var462;
                                 if (var463 != 0) {
                                    CartPearlCatch var464 = var343;
                                    CartPearlCatch var344 = var464;
                                    int var465 = var344.t;
                                    if (var465 > 0) {
                                       this.t--;
                                       return;
                                    }

                                    var345 = this;
                                 }

                                 CartPearlCatch var349;
                                 int var467 = var48;
                                 CartPearlCatch var466 = var345;
                                 var349 = var466;
                                 CartPearlCatch var346 = var466;
                                 label425:
                                 if (var467 != 0) {
                                    BlockPos var468 = var346.q;
                                    if (var468 == null) {
                                       Object[] var139 = new Object[]{new Vec3d(this.n + 0.5, this.o + 0.45, this.p + 0.5), 46355480980892L};
                                       CartPearlCatch var138 = this;
                                       this.q = var138.bReturningBlockPos(var139);
                                       int var470 = var48;
                                       CartPearlCatch var469 = this;
                                       var349 = var469;
                                       CartPearlCatch var347 = var469;
                                       if (var470 == 0) {
                                          break label425;
                                       }

                                       CartPearlCatch var471 = var347;
                                       CartPearlCatch var348 = var471;
                                       BlockPos var472 = var348.q;
                                       if (var472 == null) {
                                          Object[] var143 = new Object[]{"no fire spot on the shot path", 71791682978145L};
                                          CartPearlCatch var142 = this;
                                          var142.lReturningVoid(var143);
                                          return;
                                       }
                                    }

                                    var349 = this;
                                 }

                                 Object[] var146 = new Object[]{4376726503841L};
                                 CartPearlCatch var145 = var349;
                                 int var592 = var145.fReturningInt(var146);
                                 int var473 = var48;
                                 if (var473 == 0) {
                                    return;
                                 }

                                 
                                 if (var474 == var475) {
                                    Object[] var149 = new Object[]{"lost the flint & steel", 71791682978145L};
                                    CartPearlCatch var148 = this;
                                    var148.lReturningVoid(var149);
                                    return;
                                 }

                                 BlockPos var151 = this.q;
                                 BlockPos var599 = var151.down();
                                 Object[] var650 = new Object[]{null, 72518082610550L};
                                 var650[0] = var592;
                                 Object[] var152 = var650;
                                 InventoryUtil.aReturningVoid(var152);
                                 BlockPos var153 = var599;
                                 double var10005 = var153.getX() + 0.5;
                                 BlockPos var154 = var599;
                                 double var657 = var154.getY() + 1.0;
                                 BlockPos var155 = var599;
                                 Object[] var157 = new Object[]{
                                    new BlockHitResult(new Vec3d(var10005, var657, var155.getZ() + 0.5), Direction.UP, var599, false), 96591051752783L
                                 };
                                 CartPearlCatch var156 = this;
                                 var156.p(var157);
                                 IntSetting var158 = this.f;
                                 Integer var159 = (Integer)var158.aReturningObject();
                                 this.t = var159;
                                 this.k = CartPearlCatchState.SWITCH_XBOW;
                                 int var476 = var48;
                                 if (var476 != 0) {
                                    return;
                                 }
                              }

                              int var478 = var48;
                              int var477 = this.t;
                              int var352 = var477;
                              int var350 = var477;
                              if (var478 != 0) {
                                 int var479 = var350;
                                 int var351 = var479;
                                 int var480 = var351;
                                 if (var480 > 0) {
                                    this.t--;
                                    return;
                                 }

                                 Object[] var164 = new Object[]{133518700529771L};
                                 CartPearlCatch var163 = this;
                                 var352 = var163.gReturningInt(var164);
                              }

                              int var593 = var352;
                              int var482 = var48;
                              int var481 = var593;
                              int var354 = var481;
                              int var353 = var481;
                              if (var482 != 0) {
                                 
                                 if (var483 == var484) {
                                    Object[] var167 = new Object[]{"no charged crossbow", 71791682978145L};
                                    CartPearlCatch var166 = this;
                                    var166.lReturningVoid(var167);
                                    return;
                                 }

                                 var354 = var593;
                              }

                              Object[] var651 = new Object[]{null, 72518082610550L};
                              var651[0] = var354;
                              Object[] var169 = var651;
                              InventoryUtil.aReturningVoid(var169);
                              this.v = 0;
                              this.k = CartPearlCatchState.FIRE;
                              int var485 = var48;
                              if (var485 != 0) {
                                 return;
                              }
                           }

                           Object[] var171 = new Object[]{new Vec3d(this.n + 0.5, this.o + 0.45, this.p + 0.5), 58653613630190L};
                           CartPearlCatch var170 = this;
                           Rotation var594 = var170.bReturningdx_C0210(var171);
                           int var487 = var48;
                           Rotation var486 = var594;
                           Rotation var362 = var486;
                           Rotation var355 = var486;
                           if (var487 != 0) {
                              CartPearlCatch var360;
                              label414: {
                                 Rotation var488 = var355;
                                 if (var488 != null) {
                                    int var490 = var48;
                                    CartPearlCatch var489 = this;
                                    var360 = var489;
                                    CartPearlCatch var356 = var489;
                                    if (var490 == 0) {
                                       break label414;
                                    }

                                    CartPearlCatch var491 = var356;
                                    CartPearlCatch var357 = var491;
                                    Object[] var175 = new Object[0];
                                    Rotation var174 = var594;
                                    float var641 = var174.aReturningFloat(var175);
                                    Object[] var177 = new Object[0];
                                    Rotation var176 = var594;
                                    float var645 = var176.bReturningFloat(var177);
                                    Object[] var655 = new Object[]{null, null, 109442964557193L};
                                    var655[1] = var645;
                                    var655[0] = var641;
                                    Object[] var179 = var655;
                                    CartPearlCatch var178 = var357;
                                    boolean var492 = var178.dReturningBoolean(var179);
                                    if (var492) {
                                       this.y = var594;
                                       int var494 = var48;
                                       CartPearlCatch var493 = this;
                                       var360 = var493;
                                       CartPearlCatch var358 = var493;
                                       if (var494 == 0) {
                                          break label414;
                                       }

                                       CartPearlCatch var495 = var358;
                                       CartPearlCatch var359 = var495;
                                       Object[] var183 = new Object[0];
                                       Rotation var182 = var594;
                                       float var642 = var182.aReturningFloat(var183);
                                       Object[] var185 = new Object[0];
                                       Rotation var184 = var594;
                                       var645 = var184.bReturningFloat(var185);
                                       Object[] var658 = new Object[]{null, null, null, 13002002019620L};
                                       var658[2] = 1.05F;
                                       var658[1] = var645;
                                       var658[0] = var642;
                                       Object[] var187 = var658;
                                       CartPearlCatch var186 = var359;
                                       int var600 = var186.aReturningInt(var187);
                                       
                                       if (var496 != var497) {
                                          this.z = var600;
                                       }
                                    }
                                 }

                                 var360 = this;
                              }

                              int var499 = var48;
                              CartPearlCatch var498 = var360;
                              var363 = var498;
                              CartPearlCatch var361 = var498;
                              if (var499 == 0) {
                                 break label565;
                              }

                              Rotation var500 = var361.y;
                              var362 = var500;
                           }

                           Rotation var501 = var362;
                           if (var501 == null) {
                              var363 = this;
                              break label565;
                           }

                           Object[] var192 = new Object[]{Items.CROSSBOW, 8519502184947L};
                           byte var607 = ((byte)((InventoryUtil.lReturningBoolean(var192)) ? 1 : 0));
                           int var503 = var48;
                           boolean var502 = dev.prestige.recovery.SourceSupport.asBoolean(var607);
                           boolean var367 = var502;
                           boolean var364 = var502;
                           if (var503 != 0) {
                              boolean var504 = var364;
                              if (!var504) {
                                 Object[] var195 = new Object[]{133518700529771L};
                                 CartPearlCatch var194 = this;
                                 int var602 = var194.gReturningInt(var195);
                                 int var506 = var48;
                                 int var505 = var602;
                                 int var366 = var505;
                                 int var365 = var505;
                                 if (var506 != 0) {
                                    
                                    if (var507 == var508) {
                                       Object[] var198 = new Object[]{"crossbow lost its charge", 71791682978145L};
                                       CartPearlCatch var197 = this;
                                       var197.lReturningVoid(var198);
                                       return;
                                    }

                                    var366 = var602;
                                 }

                                 Object[] var653 = new Object[]{null, 72518082610550L};
                                 var653[0] = var366;
                                 Object[] var200 = var653;
                                 InventoryUtil.aReturningVoid(var200);
                                 return;
                              }

                              Object[] var202 = new Object[]{139992288653761L};
                              CartPearlCatch var201 = this;
                              var367 = var201.eReturningBoolean(var202);
                           }

                           boolean var509 = var367;
                           if (!var509) {
                              return;
                           }

                           RotationManager var608 = Prestige.o;
                           Object[] var204 = new Object[0];
                           RotationManager var203 = var608;
                           Rotation var601 = var203.cReturningdx_C0210(var204);
                           int var510 = var48;
                           if (var510 != 0) {
                              CartPearlCatch var373;
                              label397: {
                                 Rotation var511 = var601;
                                 label396:
                                 if (var511 != null) {
                                    Object[] var207 = new Object[0];
                                    Rotation var206 = var601;
                                    var607 = ((byte)((var206.aReturningBoolean(var207)) ? 1 : 0));
                                    int var513 = var48;
                                    byte var512 = var607;
                                    int var372 = var512;
                                    byte var368 = var512;
                                    if (var513 != 0) {
                                       byte var514 = var368;
                                       byte var369 = var514;
                                       byte var515 = var369;
                                       if (var515 == 0) {
                                          break label396;
                                       }

                                       int var517 = var48;
                                       CartPearlCatch var516 = this;
                                       var373 = var516;
                                       CartPearlCatch var370 = var516;
                                       if (var517 == 0) {
                                          break label397;
                                       }

                                       CartPearlCatch var518 = var370;
                                       CartPearlCatch var371 = var518;
                                       int var519 = var371.v++;
                                       var372 = var519;
                                    }

                                    byte var521 = 5;
                                    int var520 = var372;
                                    if (var520 < var521) {
                                       return;
                                    }
                                 }

                                 MinecraftClient var213 = b;
                                 MinecraftClient var214 = b;
                                 Hand var217 = Hand.MAIN_HAND;
                                 ClientPlayerEntity var216 = var214.player;
                                 ClientPlayerInteractionManager var215 = var213.interactionManager;
                                 var215.interactItem((PlayerEntity)var216, var217);
                                 RotationManager var610 = Prestige.o;
                                 Object[] var219 = new Object[]{true};
                                 RotationManager var218 = var610;
                                 var218.fReturningVoid(var219);
                                 var373 = this;
                              }

                              Object[] var221 = new Object[]{54016044393553L};
                              CartPearlCatch var220 = var373;
                              var220.nReturningVoid(var221);
                           }

                           int var522 = var48;
                           if (var522 != 0) {
                              return;
                           }
                        }

                        Object[] var222 = new Object[]{Items.BOW, 95321893129094L};
                        Integer var595 = InventoryUtil.aReturningBoxedInteger(var222);
                        int var524 = var48;
                        Integer var523 = var595;
                        Integer var375 = var523;
                        Integer var374 = var523;
                        if (var524 != 0) {
                           Integer var525 = var374;
                           if (var525 == null) {
                              Object[] var225 = new Object[]{"no bow in hotbar", 71791682978145L};
                              CartPearlCatch var224 = this;
                              var224.lReturningVoid(var225);
                              return;
                           }

                           var375 = var595;
                        }

                        Integer var227 = var375;
                        int var611 = var227;
                        Object[] var652 = new Object[]{null, 72518082610550L};
                        var652[0] = var611;
                        Object[] var228 = var652;
                        InventoryUtil.aReturningVoid(var228);
                        this.k = CartPearlCatchState.USE_BOW;
                        int var526 = var48;
                        if (var526 != 0) {
                           return;
                        }
                     }

                     MinecraftClient var229 = b;
                     GameOptions var230 = var229.options;
                     KeyBinding var231 = var230.useKey;
                     var231.setPressed(true);
                     MinecraftClient var233 = b;
                     MinecraftClient var234 = b;
                     Hand var237 = Hand.MAIN_HAND;
                     ClientPlayerEntity var236 = var234.player;
                     ClientPlayerInteractionManager var235 = var233.interactionManager;
                     var235.interactItem((PlayerEntity)var236, var237);
                     this.x = true;
                     this.k = CartPearlCatchState.CHARGE_WAIT;
                     int var527 = var48;
                     if (var527 != 0) {
                        return;
                     }
                  }

                  MinecraftClient var239 = b;
                  GameOptions var240 = var239.options;
                  KeyBinding var241 = var240.useKey;
                  byte var612 = ((byte)((var241.isPressed()) ? 1 : 0));
                  int var529 = var48;
                  byte var528 = var612;
                  int var378 = var528;
                  byte var376 = var528;
                  if (var529 != 0) {
                     byte var530 = var376;
                     byte var377 = var530;
                     byte var531 = var377;
                     if (var531 == 0) {
                        MinecraftClient var244 = b;
                        GameOptions var245 = var244.options;
                        KeyBinding var246 = var245.useKey;
                        var246.setPressed(true);
                     }

                     MinecraftClient var249 = b;
                     ClientPlayerEntity var250 = var249.player;
                     var378 = var250.getItemUseTime();
                  }

                  int var596 = var378;
                  int var533 = var48;
                  int var532 = var596;
                  int var379 = var532;
                  if (var533 != 0) {
                     byte var535 = 3;
                     int var534 = var379;
                     if (var534 >= var535) {
                        int var252 = var596;
                        float var643 = BowItem.getPullProgress(var252);
                        Object[] var654 = new Object[]{null, 100401620500996L};
                        var654[0] = var643;
                        Object[] var254 = var654;
                        CartPearlCatch var253 = this;
                        boolean var536 = var253.aReturningBoolean(var254);
                     }
                  }

                  label519: {
                     CartPearlCatch var384;
                     label520: {
                        int var538 = var48;
                        Rotation var537 = this.y;
                        Rotation var383 = var537;
                        Rotation var381 = var537;
                        if (var538 != 0) {
                           Rotation var539 = var381;
                           if (var539 == null) {
                              byte var541 = 30;
                              int var540 = var596;
                              if (var540 >= var541) {
                                 Object[] var259 = new Object[]{"no firing line at the cart", 71791682978145L};
                                 CartPearlCatch var258 = this;
                                 var258.lReturningVoid(var259);
                                 return;
                              }
                           }

                           int var543 = var48;
                           CartPearlCatch var542 = this;
                           var384 = var542;
                           CartPearlCatch var382 = var542;
                           if (var543 == 0) {
                              break label520;
                           }

                           Rotation var544 = var382.y;
                           var383 = var544;
                        }

                        Rotation var545 = var383;
                        if (var545 == null) {
                           break label519;
                        }

                        var384 = this;
                     }

                     int var547 = var48;
                     CartPearlCatch var546 = var384;
                     CartPearlCatch var386 = var546;
                     CartPearlCatch var385 = var546;
                     if (var547 != 0) {
                        Object[] var263 = new Object[]{139992288653761L};
                        CartPearlCatch var262 = var385;
                        boolean var548 = var262.eReturningBoolean(var263);
                        if (!var548) {
                           byte var550 = 30;
                           int var549 = var596;
                           if (var549 < var550) {
                              break label519;
                           }
                        }

                        this.v = 0;
                        CartPearlCatch var551 = this;
                        var386 = var551;
                     }

                     var386.k = CartPearlCatchState.RELEASE;
                  }

                  int var552 = var48;
                  if (var552 != 0) {
                     return;
                  }
               }

               int var554 = var48;
               CartPearlCatch var553 = this;
               CartPearlCatch var389 = var553;
               CartPearlCatch var387 = var553;
               if (var554 != 0) {
                  CartPearlCatch var555 = var387;
                  CartPearlCatch var388 = var555;
                  Rotation var556 = var388.y;
                  if (var556 == null) {
                     Object[] var270 = new Object[]{"no firing line at the cart", 71791682978145L};
                     CartPearlCatch var269 = this;
                     var269.lReturningVoid(var270);
                     return;
                  }

                  var389 = this;
               }

               KeyBinding var396;
               label566: {
                  label523: {
                     Object[] var273 = new Object[]{139992288653761L};
                     CartPearlCatch var272 = var389;
                     byte var613 = ((byte)((var272.eReturningBoolean(var273)) ? 1 : 0));
                     int var558 = var48;
                     byte var557 = var613;
                     int var391 = var557;
                     byte var390 = var557;
                     if (var558 != 0) {
                        byte var559 = var390;
                        if (var559 != 0) {
                           break label523;
                        }

                        MinecraftClient var275 = b;
                        ClientPlayerEntity var276 = var275.player;
                        int var560 = var276.getItemUseTime();
                        var391 = var560;
                     }

                     int var562 = var48;
                     int var561 = var391;
                     int var395 = var561;
                     int var392 = var561;
                     if (var562 != 0) {
                        byte var564 = 30;
                        int var563 = var392;
                        if (var563 >= var564) {
                           break label523;
                        }

                        MinecraftClient var279 = b;
                        GameOptions var280 = var279.options;
                        int var566 = var48;
                        KeyBinding var565 = var280.useKey;
                        var396 = var565;
                        KeyBinding var393 = var565;
                        if (var566 == 0) {
                           break label566;
                        }

                        KeyBinding var567 = var393;
                        KeyBinding var394 = var567;
                        KeyBinding var282 = var394;
                        byte var568 = ((byte)((var282.isPressed()) ? 1 : 0));
                        var395 = var568;
                     }

                     int var569 = var395;
                     if (var569 != 0) {
                        return;
                     }

                     MinecraftClient var284 = b;
                     GameOptions var285 = var284.options;
                     KeyBinding var570 = var285.useKey;
                     var396 = var570;
                     break label566;
                  }

                  int var404;
                  label525: {
                     RotationManager var614 = Prestige.o;
                     Object[] var290 = new Object[0];
                     RotationManager var289 = var614;
                     Rotation var597 = var289.cReturningdx_C0210(var290);
                     int var571 = var48;
                     if (var571 != 0) {
                        Rotation var572 = var597;
                        if (var572 != null) {
                           Object[] var293 = new Object[0];
                           Rotation var292 = var597;
                           byte var615 = ((byte)((var292.aReturningBoolean(var293)) ? 1 : 0));
                           int var574 = var48;
                           byte var573 = var615;
                           var404 = var573;
                           byte var397 = var573;
                           if (var574 == 0) {
                              break label525;
                           }

                           byte var575 = var397;
                           byte var398 = var575;
                           byte var576 = var398;
                           if (var576 != 0) {
                              int var616 = this.v++;
                              int var578 = var48;
                              int var577 = var616;
                              var404 = var577;
                              int var399 = var577;
                              if (var578 == 0) {
                                 break label525;
                              }

                              int var579 = var399;
                              int var400 = var579;
                              byte var581 = 5;
                              int var580 = var400;
                              if (var580 < var581) {
                                 MinecraftClient var298 = b;
                                 GameOptions var299 = var298.options;
                                 int var583 = var48;
                                 KeyBinding var582 = var299.useKey;
                                 KeyBinding var403 = var582;
                                 KeyBinding var401 = var582;
                                 if (var583 != 0) {
                                    KeyBinding var584 = var401;
                                    KeyBinding var402 = var584;
                                    KeyBinding var301 = var402;
                                    boolean var585 = var301.isPressed();
                                    if (var585) {
                                       return;
                                    }

                                    MinecraftClient var303 = b;
                                    GameOptions var304 = var303.options;
                                    KeyBinding var586 = var304.useKey;
                                    var403 = var586;
                                 }

                                 KeyBinding var306 = var403;
                                 var306.setPressed(true);
                                 return;
                              }
                           }
                        }

                        this.x = false;
                        MinecraftClient var308 = b;
                        GameOptions var309 = var308.options;
                        KeyBinding var310 = var309.useKey;
                        var310.setPressed(false);
                     }

                     int var587 = var48;
                     if (var587 == 0) {
                        return;
                     }

                     MinecraftClient var312 = b;
                     ClientPlayerEntity var313 = var312.player;
                     byte var588 = ((byte)((var313.isUsingItem()) ? 1 : 0));
                     var404 = var588;
                  }

                  int var589 = var404;
                  if (var589 != 0) {
                     MinecraftClient var315 = b;
                     MinecraftClient var316 = b;
                     ClientPlayerEntity var318 = var316.player;
                     ClientPlayerInteractionManager var317 = var315.interactionManager;
                     var317.stopUsingItem((PlayerEntity)var318);
                  }

                  Object[] var321 = new Object[]{54016044393553L};
                  CartPearlCatch var320 = this;
                  var320.nReturningVoid(var321);
                  return;
               }

               KeyBinding var287 = var396;
               var287.setPressed(true);
               return;
            }

            Object[] var191 = new Object[]{"no firing line through the fire", 71791682978145L};
            CartPearlCatch var190 = var363;
            var190.lReturningVoid(var191);
            return;
         }

         Object[] var98 = new Object[]{"placement out of reach", 71791682978145L};
         CartPearlCatch var97 = var335;
         var97.lReturningVoid(var98);
      }
   }

   private int cReturningInt(Object[] var1) {
      EnderPearlEntity var4 = (EnderPearlEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 33010110281137L ^ var2;
      long var5 = var2 ^ 20396717456517L;
      int var10000 = Event.bReturningInt();
      Object[] var10 = new Object[]{var4, var5};
      CartPearlCatch var9 = this;
      CartPearlIntercept var8 = var9.aReturninggk_C0346(var10);
      int var7 = var10000;
      int var17 = var7;
      CartPearlIntercept var16 = var8;
      CartPearlIntercept var14 = var16;
      CartPearlIntercept var13 = var16;
      if (var17 == 0) {
         CartPearlIntercept var18 = var13;
         if (var18 == null) {
            return 0;
         }

         var14 = var8;
      }

      CartPearlIntercept var12 = var14;
      return var12.an();
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 33010110281137L ^ var2;
      int var15 = Event.bReturningInt();
      IntSetting var6 = this.f;
      Integer var7 = (Integer)var6.aReturningObject();
      int var5 = var7;
      int var4 = var15;
      int var12 = var4;
      byte var11 = ((byte)((this.r) ? 1 : 0));
      int var9 = var11;
      byte var8 = var11;
      if (var12 == 0) {
         byte var13 = var8;
         if (var13 != 0) {
            return 3 * var5 + 4;
         }

         var9 = var5;
      }

      return var9 + 2;
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      long var4 = var2 ^ 26494072102858L;
      long var6 = var2 ^ 116422012173485L;
      int var8 = Event.bReturningInt();
      int var28 = var8;
      CartPearlCatch var27 = this;
      CartPearlCatch var21 = var27;
      CartPearlCatch var20 = var27;
      if (var28 == 0) {
         int var29 = var20.z;
         if (var29 < 0) {
            return false;
         }

         var21 = this;
      }

      Object[] var14 = new Object[]{var4};
      CartPearlCatch var13 = var21;
      EnderPearlEntity var9 = var13.aReturningEnderPearlEntity(var14);
      EnderPearlEntity var30 = var9;
      if (var30 == null) {
         return true;
      }

      Object[] var17 = new Object[]{var9, var6};
      CartPearlCatch var16 = this;
      CartPearlIntercept var10 = var16.aReturninggk_C0346(var17);
      int var32 = var8;
      CartPearlIntercept var31 = var10;
      CartPearlIntercept var23 = var31;
      CartPearlIntercept var22 = var31;
      if (var32 == 0) {
         CartPearlIntercept var33 = var22;
         if (var33 == null) {
            return true;
         }

         var23 = var10;
      }

      CartPearlIntercept var19 = var23;
      int var10000 = var19.an();
      int var35 = var8;
      int var34 = var10000;
      int var25 = var34;
      int var24 = var34;
      if (var35 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var25);
      }

      int var37 = this.z + 1;
      int var36 = var24;
      return var36 <= var37;
   }

   private void nReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      long var4 = var2 ^ 121844905219222L;
      int var6 = Event.bReturningInt();
      int var21 = var6;
      CartPearlCatch var20 = this;
      CartPearlCatch var17 = var20;
      CartPearlCatch var16 = var20;
      if (var21 == 0) {
         UUID var22 = var16.l;
         if (var22 != null) {
            UUID var9 = this.l;
            Set var8 = this.m;
            var8.add(var9);
         }

         var17 = this;
      }

      int var24 = var6;
      CartPearlCatch var23 = var17;
      CartPearlCatch var19 = var23;
      CartPearlCatch var18 = var23;
      if (var24 == 0) {
         
         if (var25 != var26) {
            int var10000 = this.s;
            Object[] var10003 = new Object[]{null, var4};
            var10003[0] = var10000;
            Object[] var12 = var10003;
            InventoryUtil.aReturningVoid(var12);
         }

         var19 = this;
      }

      Object[] var15 = new Object[0];
      CartPearlCatch var14 = var19;
      var14.jReturningVoid(var15);
   }

   private void o(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      long var4 = var2 ^ 78652933668613L;
      long var6 = var2 ^ 34236459236512L;
      long var8 = var2 ^ 54159254370536L;
      long var10 = var2 ^ 77060350164933L;
      long var12 = var2 ^ 22460047918556L;
      long var14 = var2 ^ 111838741165418L;
      long var16 = var2 ^ 81817404405383L;
      long var18 = var2 ^ 62060051202256L;
      long var20 = var2 ^ 25501127069758L;
      long var22 = var2 ^ 54814332533262L;
      long var24 = var2 ^ 28334926943909L;
      int var26 = Event.cReturningInt();
      Object[] var44 = new Object[]{var20};
      CartPearlCatch var43 = this;
      int var10000 = var43.eReturningInt(var44);
      
      if (var151 != var152) {
         MinecraftClient var46 = b;
         ClientWorld var47 = var46.world;
         Iterable var48 = var47.getEntities();
         Iterator var27 = var48.iterator();

         int var211;
         do {
            int var41;
            while (true) {
               EnderPearlEntity var29;
               CartPearlCatch var146;
               CartPearlIntercept var213;
               while (true) {
                  int var131;
                  while (true) {
                     CartPearlIntercept var129;
                     while (true) {
                        boolean var127;
                        while (true) {
                           PlayerEntity var39;
                           boolean var125;
                           while (true) {
                              Entity var123;
                              while (true) {
                                 Object var121;
                                 while (true) {
                                    Entity var119;
                                    while (true) {
                                       Iterator var49 = var27;
                                       boolean var153 = var49.hasNext();
                                       if (!var153) {
                                          return;
                                       }

                                       Iterator var50 = var27;
                                       Entity var28 = (Entity)var50.next();
                                       int var155 = var26;
                                       Entity var154 = var28;
                                       var119 = var154;
                                       Entity var118 = var154;
                                       if (var155 == 0) {
                                          break;
                                       }

                                       boolean var156 = var118 instanceof EnderPearlEntity;
                                       if (var156) {
                                          var119 = var28;
                                          break;
                                       }
                                    }

                                    var29 = (EnderPearlEntity)var119;
                                    int var158 = var26;
                                    Set var157 = this.m;
                                    var121 = var157;
                                    Set var120 = var157;
                                    if (var158 == 0) {
                                       break;
                                    }

                                    EnderPearlEntity var52 = var29;
                                    UUID var54 = var52.getUuid();
                                    Set var53 = var120;
                                    boolean var159 = var53.contains(var54);
                                    if (!var159) {
                                       FloatSetting var57 = this.a;
                                       var121 = var57.aReturningObject();
                                       break;
                                    }
                                 }

                                 Float var58 = (Float)var121;
                                 double var30 = var58.floatValue();
                                 MinecraftClient var59 = b;
                                 ClientPlayerEntity var60 = var59.player;
                                 Vec3d var32 = var60.getEyePos();
                                 EnderPearlEntity var61 = var29;
                                 double var214 = var61.getX();
                                 Vec3d var62 = var32;
                                 double var33 = var214 - var62.x;
                                 EnderPearlEntity var63 = var29;
                                 double var215 = var63.getY();
                                 Vec3d var64 = var32;
                                 double var35 = var215 - var64.y;
                                 EnderPearlEntity var65 = var29;
                                 double var216 = var65.getZ();
                                 Vec3d var66 = var32;
                                 double var37 = var216 - var66.z;
                                 double var223;
                                 int var160 = (var223 = var33 * var33 + var35 * var35 + var37 * var37 - var30 * var30) == 0.0 ? 0 : (var223 < 0.0 ? -1 : 1);
                                 if (var160 <= 0) {
                                    EnderPearlEntity var68 = var29;
                                    Entity var40 = var68.getOwner();
                                    int var162 = var26;
                                    Entity var161 = var40;
                                    var123 = var161;
                                    Entity var122 = var161;
                                    if (var162 == 0) {
                                       break;
                                    }

                                    boolean var163 = var122 instanceof PlayerEntity;
                                    if (var163) {
                                       var123 = var40;
                                       break;
                                    }
                                 }
                              }

                              var39 = (PlayerEntity)var123;
                              MinecraftClient var70 = b;
                              ClientPlayerEntity var72 = var70.player;
                              PlayerEntity var71 = var39;
                              boolean var217 = var71.equals(var72);
                              int var165 = var26;
                              boolean var164 = var217;
                              var125 = var164;
                              boolean var124 = var164;
                              if (var165 == 0) {
                                 break;
                              }

                              boolean var166 = var124;
                              if (!var166) {
                                 PlayerValidationTracker var218 = Prestige.i;
                                 Object[] var75 = new Object[]{var39, var10};
                                 PlayerValidationTracker var74 = var218;
                                 var125 = var74.aReturningBoolean(var75);
                                 break;
                              }
                           }

                           int var168 = var26;
                           boolean var167 = var125;
                           var127 = var167;
                           boolean var126 = var167;
                           if (var168 == 0) {
                              break;
                           }

                           boolean var169 = var126;
                           if (var169) {
                              SocialsManager var219 = Prestige.g;
                              PlayerEntity var77 = var39;
                              Text var78 = var77.getName();
                              Object[] var80 = new Object[]{var78.getString(), var18};
                              SocialsManager var79 = var219;
                              var127 = var79.aReturningBoolean(var80);
                              break;
                           }
                        }

                        boolean var170 = var127;
                        if (!var170) {
                           Object[] var82 = new Object[]{var29, var12};
                           CartPearlCatch var81 = this;
                           var213 = var81.aReturninggk_C0346(var82);
                           int var172 = var26;
                           CartPearlIntercept var171 = var213;
                           var129 = var171;
                           CartPearlIntercept var128 = var171;
                           if (var172 == 0) {
                              break;
                           }

                           CartPearlIntercept var173 = var128;
                           if (var173 != null) {
                              var129 = var213;
                              break;
                           }
                        }
                     }

                     CartPearlIntercept var84 = var129;
                     var10000 = var84.an();
                     int var175 = var26;
                     int var174 = var10000;
                     var131 = var174;
                     int var130 = var174;
                     if (var175 == 0) {
                        break;
                     }

                     short var10001 = 11324;
                     long var10002 = 3694910483692413777L ^ var2;
                     byte var177 = 100;
                     int var176 = var130;
                     if (var176 <= var177) {
                        BooleanSetting var87 = this.e;
                        Boolean var88 = (Boolean)var87.aReturningObject();
                        var131 = ((((java.lang.Boolean)(var88)).booleanValue() ? 1 : 0));
                        break;
                     }
                  }

                  int var141;
                  label159: {
                     int var140;
                     label158: {
                        label202: {
                           int var179 = var26;
                           int var178 = var131;
                           int var133 = var178;
                           int var132 = var178;
                           if (var179 != 0) {
                              int var180 = var132;
                              if (var180 == 0) {
                                 break label202;
                              }

                              Object[] var91 = new Object[]{var14};
                              CartPearlCatch var90 = this;
                              int var181 = var90.gReturningInt(var91);
                              var133 = var181;
                           }

                           int var184 = var26;
                           
                           int var138 = var182;
                           byte var139 = var183;
                           int var134 = var182;
                           byte var135 = var183;
                           if (var184 != 0) {
                              byte var186 = var135;
                              int var185 = var134;
                              if (var185 == var186) {
                                 break label202;
                              }

                              Object[] var95 = new Object[]{var6};
                              CartPearlCatch var94 = this;
                              var10000 = var94.fReturningInt(var95);
                              int var188 = var26;
                              int var187 = var10000;
                              var140 = var187;
                              int var136 = var187;
                              if (var188 == 0) {
                                 break label158;
                              }

                              int var189 = var136;
                              int var137 = var189;
                              
                              var138 = var190;
                              var139 = var191;
                           }

                           byte var193 = var139;
                           int var192 = var138;
                           if (var192 != var193) {
                              var140 = 1;
                              break label158;
                           }
                        }

                        var141 = 0;
                        break label159;
                     }

                     int var194 = var140;
                     var141 = var194;
                  }

                  Integer var145;
                  label204: {
                     var41 = var141;
                     int var195 = var41;
                     if (var195 == 0) {
                        Object[] var98 = new Object[]{Items.BOW, var16};
                        Integer var222 = InventoryUtil.aReturningBoxedInteger(var98);
                        int var197 = var26;
                        Integer var196 = var222;
                        var145 = var196;
                        Integer var142 = var196;
                        if (var197 == 0) {
                           break label204;
                        }

                        Integer var198 = var142;
                        Integer var143 = var198;
                        Integer var199 = var143;
                        if (var199 == null) {
                           continue;
                        }
                     }

                     int var201 = var26;
                     CartPearlCatch var200 = this;
                     var146 = var200;
                     CartPearlCatch var144 = var200;
                     if (var201 == 0) {
                        break;
                     }

                     Object[] var102 = new Object[]{var8};
                     CartPearlCatch var101 = var144;
                     Integer var202 = var101.aReturningBoxedInteger(var102);
                     var145 = var202;
                  }

                  Integer var203 = var145;
                  if (var203 != null) {
                     this.r = dev.prestige.recovery.SourceSupport.asBoolean(var41);
                     var146 = this;
                     break;
                  }
               }

               CartPearlIntercept var104 = var213;
               Object[] var106 = new Object[]{var104.am(), var24};
               CartPearlCatch var105 = var146;
               BlockPos var42 = var105.aReturningBlockPos(var106);
               int var204 = var26;
               if (var204 == 0) {
                  break;
               }

               BlockPos var205 = var42;
               if (var205 != null) {
                  EnderPearlEntity var109 = var29;
                  this.l = var109.getUuid();
                  BlockPos var110 = var42;
                  this.n = var110.getX();
                  BlockPos var111 = var42;
                  this.o = var111.getY();
                  BlockPos var112 = var42;
                  this.p = var112.getZ();
                  break;
               }
            }

            int var207 = var41;
            CartPearlCatch var206 = this;
            CartPearlCatch var148 = var206;
            CartPearlCatch var147 = var206;
            CartPearlCatch var149;
            float var150;
            if (var207 != 0) {
               float var209 = 1.05F;
               CartPearlCatch var208 = var147;
               var149 = var208;
               var150 = var209;
            } else {
               var150 = 1.0F;
               var149 = var148;
            }

            Object[] var10004 = new Object[]{null, var4};
            var10004[0] = var150;
            Object[] var115 = var10004;
            CartPearlCatch var114 = var149;
            boolean var210 = var114.aReturningBoolean(var115);
            if (var210) {
               break;
            }

            this.l = null;
            var211 = var26;
         } while (var211 != 0);

         Object[] var117 = new Object[]{var22};
         this.s = InventoryUtil.aReturningInt(var117);
         this.u = 0;
         this.t = 0;
         this.k = CartPearlCatchState.ARMED;
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 138426539507609L;
      long var6 = var2 ^ 77379818547405L;
      int var8 = Event.bReturningInt();
      int var99 = var8;
      MinecraftClient var98 = b;
      MinecraftClient var64 = var98;
      MinecraftClient var63 = var98;
      if (var99 == 0) {
         MinecraftClient var12 = var63;
         ClientPlayerEntity var100 = var12.player;
         if (var100 == null) {
            return null;
         }

         MinecraftClient var101 = b;
         var64 = var101;
      }

      CartPearlCatch var69;
      label152: {
         MinecraftClient var15 = var64;
         int var103 = var8;
         ClientWorld var102 = var15.world;
         Object var68 = var102;
         ClientWorld var65 = var102;
         if (var103 == 0) {
            ClientWorld var104 = var65;
            if (var104 == null) {
               return null;
            }

            int var106 = var8;
            CartPearlCatch var105 = this;
            var69 = var105;
            CartPearlCatch var66 = var105;
            if (var106 != 0) {
               break label152;
            }

            CartPearlCatch var107 = var66;
            CartPearlCatch var67 = var107;
            BooleanSetting var18 = var67.g;
            Object var108 = var18.aReturningObject();
            var68 = var108;
         }

         Boolean var20 = (Boolean)var68;
         boolean var109 = var20;
         if (!var109) {
            return null;
         }

         var69 = this;
      }

      CartPearlCatch var83;
      label154: {
         label155: {
            int var111 = var8;
            CartPearlCatch var110 = var69;
            CartPearlCatch var71 = var110;
            CartPearlCatch var70 = var110;
            if (var111 == 0) {
               Rotation var112 = var70.y;
               if (var112 == null) {
                  break label155;
               }

               CartPearlCatch var113 = this;
               var71 = var113;
            }

            int var115 = var8;
            CartPearlCatch var114 = var71;
            var83 = var114;
            CartPearlCatch var72 = var114;
            if (var115 != 0) {
               break label154;
            }

            CartPearlCatchState var117 = CartPearlCatchState.FIRE;
            CartPearlCatchState var116 = var72.k;
            if (var116 != var117) {
               int var119 = var8;
               CartPearlCatch var118 = this;
               var83 = var118;
               CartPearlCatch var73 = var118;
               if (var119 != 0) {
                  break label154;
               }

               CartPearlCatch var120 = var73;
               CartPearlCatch var74 = var120;
               CartPearlCatchState var122 = CartPearlCatchState.RELEASE;
               CartPearlCatchState var121 = var74.k;
               if (var121 != var122) {
                  int var124 = var8;
                  CartPearlCatch var123 = this;
                  var83 = var123;
                  CartPearlCatch var75 = var123;
                  if (var124 != 0) {
                     break label154;
                  }

                  CartPearlCatch var125 = var75;
                  CartPearlCatch var76 = var125;
                  CartPearlCatchState var127 = CartPearlCatchState.SWITCH_XBOW;
                  CartPearlCatchState var126 = var76.k;
                  if (var126 != var127) {
                     int var129 = var8;
                     CartPearlCatch var128 = this;
                     var83 = var128;
                     CartPearlCatch var77 = var128;
                     if (var129 != 0) {
                        break label154;
                     }

                     CartPearlCatch var130 = var77;
                     CartPearlCatch var78 = var130;
                     CartPearlCatchState var132 = CartPearlCatchState.SWITCH_BOW;
                     CartPearlCatchState var131 = var78.k;
                     if (var131 != var132) {
                        int var134 = var8;
                        CartPearlCatch var133 = this;
                        var83 = var133;
                        CartPearlCatch var79 = var133;
                        if (var134 != 0) {
                           break label154;
                        }

                        CartPearlCatch var135 = var79;
                        CartPearlCatch var80 = var135;
                        CartPearlCatchState var137 = CartPearlCatchState.USE_BOW;
                        CartPearlCatchState var136 = var80.k;
                        if (var136 != var137) {
                           int var139 = var8;
                           CartPearlCatch var138 = this;
                           var83 = var138;
                           CartPearlCatch var81 = var138;
                           if (var139 != 0) {
                              break label154;
                           }

                           CartPearlCatch var140 = var81;
                           CartPearlCatch var82 = var140;
                           CartPearlCatchState var142 = CartPearlCatchState.CHARGE_WAIT;
                           CartPearlCatchState var141 = var82.k;
                           if (var141 != var142) {
                              break label155;
                           }
                        }
                     }
                  }
               }
            }

            CartPearlCatch var143 = this;
            var83 = var143;
            break label154;
         }

         Vec3d var172;
         label104: {
            label156: {
               var172 = null;
               int var147 = var8;
               CartPearlCatchState var146 = CartPearlCatchState.SWITCH_RAIL;
               CartPearlCatchState var145 = this.k;
               CartPearlCatchState var86 = var145;
               CartPearlCatchState var87 = var146;
               CartPearlCatchState var84 = var145;
               CartPearlCatchState var85 = var146;
               if (var147 == 0) {
                  CartPearlCatchState var149 = var85;
                  CartPearlCatchState var148 = var84;
                  if (var148 == var149) {
                     break label156;
                  }

                  CartPearlCatchState var151 = CartPearlCatchState.SWITCH_CART;
                  CartPearlCatchState var150 = this.k;
                  var86 = var150;
                  var87 = var151;
               }

               CartPearlCatch var93;
               label157: {
                  int var154 = var8;
                  CartPearlCatchState var153 = var87;
                  CartPearlCatchState var152 = var86;
                  CartPearlCatchState var91 = var152;
                  CartPearlCatchState var92 = var153;
                  CartPearlCatchState var88 = var152;
                  CartPearlCatchState var89 = var153;
                  if (var154 == 0) {
                     CartPearlCatchState var156 = var89;
                     CartPearlCatchState var155 = var88;
                     if (var155 == var156) {
                        break label156;
                     }

                     int var158 = var8;
                     CartPearlCatch var157 = this;
                     var93 = var157;
                     CartPearlCatch var90 = var157;
                     if (var158 != 0) {
                        break label157;
                     }

                     CartPearlCatchState var160 = CartPearlCatchState.SWITCH_FIRE;
                     CartPearlCatchState var159 = var90.k;
                     var91 = var159;
                     var92 = var160;
                  }

                  CartPearlCatchState var162 = var92;
                  CartPearlCatchState var161 = var91;
                  if (var161 != var162) {
                     break label104;
                  }

                  var93 = this;
               }

               int var164 = var8;
               BlockPos var163 = var93.q;
               BlockPos var95 = var163;
               BlockPos var94 = var163;
               if (var164 == 0) {
                  BlockPos var165 = var94;
                  if (var165 == null) {
                     break label104;
                  }

                  BlockPos var166 = this.q;
                  var95 = var166;
               }

               BlockPos var51 = var95;
               var172 = var51.toCenterPos();
               break label104;
            }

            var172 = new Vec3d(this.n + 0.5, this.o + 0.5, this.p + 0.5);
         }

         Vec3d var167 = var172;
         if (var167 != null) {
            RotationManager var175 = Prestige.o;
            Object[] var53 = new Object[]{var172, var6};
            RotationManager var52 = var175;
            Rotation var10 = var52.aReturningdx_C0210(var53);
            int var169 = var8;
            Rotation var168 = var10;
            Rotation var97 = var168;
            Rotation var96 = var168;
            if (var169 == 0) {
               Rotation var170 = var96;
               if (var170 == null) {
                  return null;
               }

               var97 = var10;
            }

            Object[] var56 = new Object[0];
            Rotation var55 = var97;
            float var176 = var55.aReturningFloat(var56);
            MinecraftClient var57 = b;
            ClientPlayerEntity var58 = var57.player;
            float var177 = var176 - var58.getYaw();
            Object[] var178 = new Object[]{null, var4};
            var178[0] = var177;
            Object[] var59 = var178;
            float var60 = RotationUtil.bReturningFloat(var59);
            float var11 = Math.abs(var60);
            FloatSetting var61 = this.h;
            Float var62 = (Float)var61.aReturningObject();
            float var179;
            int var171 = (var179 = var11 - var62) == 0.0F ? 0 : (var179 < 0.0F ? -1 : 1);
            if (var171 <= 0) {
               return var10;
            }
         }

         return null;
      }

      Rotation var10000 = var83.y;
      Object[] var37 = new Object[0];
      Rotation var36 = var10000;
      float var173 = var36.aReturningFloat(var37);
      MinecraftClient var38 = b;
      ClientPlayerEntity var39 = var38.player;
      float var174 = var173 - var39.getYaw();
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var174;
      Object[] var40 = var10003;
      float var41 = RotationUtil.bReturningFloat(var40);
      float var9 = Math.abs(var41);
      FloatSetting var42 = this.h;
      Float var43 = (Float)var42.aReturningObject();
      float var180;
      int var144 = (var180 = var9 - var43) == 0.0F ? 0 : (var180 < 0.0F ? -1 : 1);
      return var144 <= 0 ? this.y : null;
   }

   @EventListener
   public void a(EntityOverlayRenderEvent var1) {
      long var10001 = 21781542301712L ^ 117099960839082L;
      var10001 = 21781542301712L ^ 32895763249461L;
      var10001 = 21781542301712L ^ 31841702395629L;
      var10001 = 21781542301712L ^ 72479535685386L;
      var10001 = 21781542301712L ^ 133264658563629L;
      var10001 = 21781542301712L ^ 109313961773189L;
      var10001 = 21781542301712L ^ 26334323622393L;
      var10001 = 21781542301712L ^ 66948606486895L;
      var10001 = 21781542301712L ^ 46335830175585L;
      var10001 = 21781542301712L ^ 102385034447056L;
      var10001 = 21781542301712L ^ 126444240174518L;
      var10001 = 21781542301712L ^ 29645172016787L;
      int var28 = Event.cReturningInt();
      BooleanSetting var60 = this.i;
      Boolean var61 = (Boolean)var60.aReturningObject();
      boolean var118 = var61;
      if (var118) {
         MinecraftClient var110;
         int var120 = var28;
         MinecraftClient var119 = b;
         var110 = var119;
         MinecraftClient var107 = var119;
         label69:
         if (var120 != 0) {
            MinecraftClient var63 = var107;
            Screen var121 = var63.currentScreen;
            if (var121 != null) {
               int var123 = var28;
               MinecraftClient var122 = b;
               var110 = var122;
               MinecraftClient var108 = var122;
               if (var123 == 0) {
                  break label69;
               }

               MinecraftClient var124 = var108;
               MinecraftClient var109 = var124;
               MinecraftClient var66 = var109;
               boolean var125 = var66.currentScreen instanceof ChatScreen;
               if (!var125) {
                  return;
               }
            }

            var110 = b;
         }

         int var127 = var28;
         MinecraftClient var126 = var110;
         MinecraftClient var112 = var126;
         MinecraftClient var111 = var126;
         if (var127 != 0) {
            MinecraftClient var69 = var111;
            ClientWorld var128 = var69.world;
            if (var128 == null) {
               return;
            }

            MinecraftClient var129 = b;
            var112 = var129;
         }

         MinecraftClient var72 = var112;
         ClientPlayerEntity var130 = var72.player;
         if (var130 != null) {
            CartPearlCatchState var132 = CartPearlCatchState.IDLE;
            CartPearlCatchState var131 = this.k;
            if (var131 != var132) {
               label54: {
                  int var134 = var28;
                  ManagedGlTexture var133 = B;
                  ManagedGlTexture var114 = var133;
                  ManagedGlTexture var113 = var133;
                  if (var134 != 0) {
                     ManagedGlTexture var135 = var113;
                     if (var135 != null) {
                        break label54;
                     }

                     Object[] var76 = new Object[]{A, 86660470323392L};
                     ManagedGlTexture var136 = ManagedGlTexture.dReturningbT_C0095(var76);
                     var114 = var136;
                  }

                  B = var114;
               }

               Object[] var79 = new Object[]{133380687977402L};
               CartPearlCatch var78 = this;
               EnderPearlEntity var30 = var78.aReturningEnderPearlEntity(var79);
               EnderPearlEntity var137 = var30;
               String var115;
               if (var137 == null) {
                  String var138 = "!";
                  var115 = var138;
               } else {
                  Object[] var158 = new Object[1];
                  Object[] var82 = new Object[]{var30, 4656165433833L};
                  CartPearlCatch var81 = this;
                  float var83 = var81.cReturningInt(var82) / 20.0F;
                  var158[0] = var83;
                  Object[] var85 = var158;
                  String var84 = "%.1fs";
                  var115 = String.format(var84, var85);
               }

               String var29 = var115;
               Object[] var86 = new Object[]{new Vec3d(this.n + 0.5, this.o + 0.8, this.p + 0.5), 123853079263381L};
               Vec3d var31 = GameRenderUtil.aReturningVec3d(var86);
               Vec3d var87 = var31;
               double var163;
               int var10000 = (var163 = var87.z - 0.0) == 0.0 ? 0 : (var163 < 0.0 ? -1 : 1);
               int var140 = var28;
               int var139 = var10000;
               int var117 = var139;
               int var116 = var139;
               if (var140 != 0) {
                  int var141 = var116;
                  if (var141 < 0) {
                     return;
                  }

                  Vec3d var89 = var31;
                  double var164;
                  int var142 = (var164 = var89.z - 1.0) == 0.0 ? 0 : (var164 < 0.0 ? -1 : 1);
                  var117 = var142;
               }

               int var143 = var117;
               if (var143 < 0) {
                  MsdfFontManager var144 = Prestige.c;
                  Object[] var92 = new Object[]{51869363673471L};
                  MsdfFontManager var91 = var144;
                  MsdfFont var32 = var91.aReturningcx_C0158(var92);
                  Object[] var94 = new Object[]{15549079685413L};
                  MsdfFont var93 = var32;
                  float var33 = var93.cReturningFloat(var94);
                  float var34 = 16.0F;
                  float var35 = 3.0F;
                  float var36 = 0.5F;
                  float var37 = 4.0F;
                  float var38 = 3.0F;
                  float var39 = 5.0F;
                  Object[] var96 = new Object[]{var29, 117628177084989L};
                  MsdfFont var95 = var32;
                  float var40 = var95.aReturningFloat(var96);
                  float var98 = var40;
                  float var97 = var34;
                  float var41 = Math.max(var97, var98);
                  float var42 = var34 + var35 + var36 + var35 + var33;
                  float var43 = var41 + 2.0F * var37;
                  float var44 = var42 + 2.0F * var38;
                  Vec3d var99 = var31;
                  float var45 = (float)var99.x;
                  Vec3d var100 = var31;
                  float var46 = (float)var100.y;
                  float var47 = var45 - var43 / 2.0F;
                  float var48 = var46 - var44 / 2.0F;
                  Matrix4f var49 = new Matrix4f();
                  Color var50 = new Color(14, 14, 14, 200);
                  Color var51 = new Color(255, 255, 255, 50);
                  Color var52 = new Color(255, 255, 255, 255);
                  MeshBufferManager var145 = var1.a;
                  RenderContext var159 = var1.b;
                  Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 16745277116157L};
                  var10011[8] = var39;
                  var10011[7] = 5;
                  var10011[6] = var44;
                  var10011[5] = var43;
                  var10011[4] = var48;
                  var10011[3] = var47;
                  var10011[2] = var49;
                  var10011[1] = var159;
                  var10011[0] = var145;
                  Object[] var101 = var10011;
                  BlurredRectangleRenderer.eReturningVoid(var101);
                  MeshBufferManager var146 = var1.a;
                  RenderContext var160 = var1.b;
                  var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
                  var10011[8] = var39;
                  var10011[7] = var50;
                  var10011[6] = var44;
                  var10011[5] = var43;
                  var10011[4] = var48;
                  var10011[3] = var47;
                  var10011[2] = var49;
                  var10011[1] = var160;
                  var10011[0] = var146;
                  Object[] var102 = var10011;
                  FilledRectangleRenderer.cReturningVoid(var102);
                  float var53 = var45 - var34 / 2.0F;
                  float var54 = var48 + var38;
                  Object[] var10009 = new Object[]{null, null, null, null, var49, B, var52, 106444071603622L};
                  var10009[3] = var34;
                  var10009[2] = var34;
                  var10009[1] = var54;
                  var10009[0] = var53;
                  Object[] var103 = var10009;
                  GameRenderUtil.v(var103);
                  float var55 = var47 + var37;
                  float var56 = var47 + var43 - var37;
                  float var57 = var54 + var34 + var35;
                  float var10004 = var57 + var36;
                  Object[] var10008 = new Object[]{null, null, null, null, null, var51, 90315074383642L};
                  var10008[4] = var10004;
                  var10008[3] = var56;
                  var10008[2] = var57;
                  var10008[1] = var55;
                  var10008[0] = var49;
                  Object[] var104 = var10008;
                  ShapeRenderer.lReturningVoid(var104);
                  float var58 = var45 - var40 / 2.0F;
                  float var59 = var57 + var36 + var35;
                  var10008 = new Object[]{null, null, null, null, var52, 10141036836483L};
                  var10008[3] = var59;
                  var10008[2] = var58;
                  var10008[1] = var29;
                  var10008[0] = var49;
                  Object[] var106 = var10008;
                  MsdfFont var105 = var32;
                  var105.v(var106);
               }
            }
         }
      }
   }

   private void p(Object[] var1) {
      BlockHitResult var4 = (BlockHitResult)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 33010110281137L ^ var2;
      int var5 = Event.bReturningInt();
      int var23 = var5;
      MinecraftClient var22 = b;
      MinecraftClient var21 = var22;
      MinecraftClient var20 = var22;
      if (var23 == 0) {
         MinecraftClient var6 = var20;
         MinecraftClient var7 = b;
         BlockHitResult var11 = var4;
         Hand var10 = Hand.MAIN_HAND;
         ClientPlayerEntity var9 = var7.player;
         ClientPlayerInteractionManager var8 = var6.interactionManager;
         ActionResult var12 = var8.interactBlock(var9, var10, var11);
         boolean var24 = var12.isAccepted();
         if (!var24) {
            return;
         }

         MinecraftClient var25 = b;
         var21 = var25;
      }

      MinecraftClient var15 = var21;
      Hand var17 = Hand.MAIN_HAND;
      ClientPlayerEntity var16 = var15.player;
      var16.swingHand(var17);
      RotationManager var26 = Prestige.o;
      Object[] var19 = new Object[]{true};
      RotationManager var18 = var26;
      var18.fReturningVoid(var19);
   }

   private boolean fReturningBoolean(Object[] var1) {
      double var2 = (Double)var1[0];
      double var4 = (Double)var1[1];
      double var6 = (Double)var1[2];
      long var8 = (Long)var1[3];
      var8 = 33010110281137L ^ var8;
      long var10 = var8 ^ 106254595536323L;
      MinecraftClient var22 = b;
      ClientPlayerEntity var23 = var22.player;
      Vec3d var13 = var23.getEyePos();
      int var10000 = Event.cReturningInt();
      Object[] var24 = new Object[]{var10};
      double var14 = ItemUseUtil.bReturningFloat(var24);
      Vec3d var25 = var13;
      double var16 = var2 - var25.x;
      int var12 = var10000;
      Vec3d var26 = var13;
      double var18 = var4 - var26.y;
      Vec3d var27 = var13;
      double var20 = var6 - var27.z;
      double var37;
      var10000 = (var37 = var16 * var16 + var18 * var18 + var20 * var20 - var14 * var14) == 0.0 ? 0 : (var37 < 0.0 ? -1 : 1);
      int var32 = var12;
      int var31 = var10000;
      int var29 = var31;
      int var28 = var31;
      if (var32 != 0) {
         int var33 = var28;
         if (var33 > 0) {
            return false;
         }

         var29 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var29);
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      while (true) {
         short var10001 = 17426;
         long var10002 = 1533883128740736763L ^ var2;
         byte var22 = 9;
         int var21 = var5;
         if (var21 < var22) {
            MinecraftClient var11 = b;
            ClientPlayerEntity var12 = var11.player;
            PlayerInventory var36 = var12.getInventory();
            int var14 = var5;
            PlayerInventory var13 = var36;
            ItemStack var15 = var13.getStack(var14);
            Item var16 = var15.getItem();

            label37:
            while (true) {
               Item var6 = var16;
               Item[] var7 = j;
               int var8 = var7.length;
               int var24 = var4;
               byte var23 = 0;
               byte var20 = var23;
               byte var17 = var23;
               if (var24 != 0) {
                  return var20;
               }

               int var9 = var17;

               while (true) {
                  int var26 = var8;
                  int var25 = var9;
                  if (var25 >= var26) {
                     break label37;
                  }

                  Item var10 = var7[var9];
                  int var27 = var4;
                  if (var27 == 0) {
                     int var29 = var4;
                     Item var28 = var6;
                     var16 = var28;
                     Item var18 = var28;
                     if (var29 != 0) {
                        break;
                     }

                     Item var30 = var18;
                     Item var19 = var30;
                     Item var32 = var10;
                     Item var31 = var19;
                     if (var31 == var32) {
                        return var5;
                     }

                     var9++;
                  }

                  int var33 = var4;
                  if (var33 != 0) {
                     break label37;
                  }
               }
            }

            var5++;
            int var34 = var4;
            if (var34 == 0) {
               continue;
            }
         }

         
      }
   }

   private int fReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      int var15;
      do {
         short var10001 = 28164;
         long var10002 = 6291957247436564601L ^ var2;
         byte var12 = 9;
         int var11 = var5;
         if (var11 >= var12) {
            break;
         }

         MinecraftClient var6 = b;
         ClientPlayerEntity var7 = var6.player;
         PlayerInventory var17 = var7.getInventory();
         int var9 = var5;
         PlayerInventory var8 = var17;
         ItemStack var10 = var8.getStack(var9);
         Item var18 = var10.getItem();
         Item var14 = Items.FLINT_AND_STEEL;
         Item var13 = var18;
         if (var13 == var14) {
            return var5;
         }

         var5++;
         var15 = var4;
      } while (var15 == 0);

      return -1;
   }

   
   private int gReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      int var63;
      do {
         short var10001 = 17426;
         long var10002 = 1533757226116762543L ^ var2;
         byte var39 = 9;
         int var38 = var5;
         if (var38 >= var39) {
            break;
         }

         label63: {
            MinecraftClient var10 = b;
            ClientPlayerEntity var11 = var10.player;
            PlayerInventory var71 = var11.getInventory();
            int var13 = var5;
            PlayerInventory var12 = var71;
            ItemStack var6 = var12.getStack(var13);
            ItemStack var14 = var6;
            Item var72 = var14.getItem();
            int var41 = var4;
            Item var40 = var72;
            Object var29 = var40;
            Item var26 = var40;
            if (var41 == 0) {
               Item var43 = Items.CROSSBOW;
               Item var42 = var26;
               Item var27 = var42;
               Item var28 = var43;
               Item var45 = var28;
               Item var44 = var27;
               if (var44 != var45) {
                  break label63;
               }

               ComponentType var17 = DataComponentTypes.CHARGED_PROJECTILES;
               ItemStack var16 = var6;
               var29 = var16.get(var17);
            }

            label60:
            while (true) {
               ChargedProjectilesComponent var7 = (ChargedProjectilesComponent)var29;
               int var47 = var4;
               ChargedProjectilesComponent var46 = var7;
               ChargedProjectilesComponent var31 = var46;
               ChargedProjectilesComponent var30 = var46;
               if (var47 == 0) {
                  ChargedProjectilesComponent var48 = var30;
                  if (var48 == null) {
                     break;
                  }

                  var31 = var7;
               }

               ChargedProjectilesComponent var19 = var31;
               List var20 = var19.getProjectiles();
               Iterator var8 = var20.iterator();

               while (true) {
                  Iterator var21 = var8;
                  boolean var49 = var21.hasNext();
                  if (!var49) {
                     break label60;
                  }

                  Iterator var22 = var8;
                  ItemStack var9 = (ItemStack)var22.next();
                  ItemStack var23 = var9;
                  Item var73 = var23.getItem();
                  int var52 = var4;
                  Item var51 = Items.ARROW;
                  Item var50 = var73;
                  Item var67 = var50;
                  Item var68 = var51;
                  Item var32 = var50;
                  Item var33 = var51;
                  if (var52 != 0) {
                     Item var70 = var68;
                     Item var69 = var67;
                     if (var69 != var70) {
                        break label60;
                     }

                     ComponentType var66 = DataComponentTypes.CHARGED_PROJECTILES;
                     ItemStack var65 = var6;
                     var29 = var65.get(var66);
                     break;
                  }

                  int var55 = var4;
                  Item var54 = var33;
                  Item var53 = var32;
                  Item var36 = var53;
                  Item var37 = var54;
                  Item var34 = var53;
                  Item var35 = var54;
                  if (var55 == 0) {
                     Item var57 = var35;
                     Item var56 = var34;
                     if (var56 == var57) {
                        return var5;
                     }

                     ItemStack var25 = var9;
                     Item var74 = var25.getItem();
                     Item var59 = Items.SPECTRAL_ARROW;
                     Item var58 = var74;
                     var36 = var58;
                     var37 = var59;
                  }

                  Item var61 = var37;
                  Item var60 = var36;
                  if (var60 == var61) {
                     return var5;
                  }

                  int var62 = var4;
                  if (var62 != 0) {
                     break label60;
                  }
               }
            }
         }

         var5++;
         var63 = var4;
      } while (var63 == 0);

      return -1;
   }

   private Integer aReturningBoxedInteger(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 33010110281137L ^ var2;
      long var4 = var2 ^ 23278793789518L;
      long var6 = var2 ^ 111246995684318L;
      long var8 = var2 ^ 33665432827735L;
      long var10 = var2 ^ 58593170411589L;
      int var10000 = Event.bReturningInt();
      Object[] var18 = new Object[]{Items.TNT_MINECART, var6};
      Integer var13 = InventoryUtil.aReturningBoxedInteger(var18);
      int var12 = var10000;
      int var81 = var12;
      Integer var80 = var13;
      Integer var54 = var80;
      Integer var53 = var80;
      if (var81 == 0) {
         Integer var82 = var53;
         if (var82 == null) {
            int var14 = -1;
            short var131 = 17426;
            long var10001 = 1533850489430378029L ^ var2;
            int var15 = 9;

            int var56;
            label129: {
               while (true) {
                  short var136 = 23206;
                  long var10002 = 6237701350129277061L ^ var2;
                  byte var85 = 36;
                  int var84 = var15;
                  label126:
                  if (var84 < var85) {
                     int var86 = var12;
                     if (var86 != 0) {
                        break;
                     }

                     MinecraftClient var21 = b;
                     ClientPlayerEntity var22 = var21.player;
                     PlayerInventory var132 = var22.getInventory();
                     int var24 = var15;
                     PlayerInventory var23 = var132;
                     ItemStack var25 = var23.getStack(var24);
                     Item var133 = var25.getItem();
                     Item var88 = Items.TNT_MINECART;
                     Item var87 = var133;
                     if (var87 == var88) {
                        var14 = var15;
                        int var89 = var12;
                        if (var89 == 0) {
                           break label126;
                        }
                     }

                     var15++;
                     int var90 = var12;
                     if (var90 == 0) {
                        continue;
                     }
                  }

                  int var92 = var12;
                  int var91 = var14;
                  var56 = var91;
                  int var55 = var91;
                  if (var92 != 0) {
                     break label129;
                  }

                  
                  if (var93 == var94) {
                     return null;
                  }

                  Object[] var30 = new Object[]{var8};
                  var15 = InventoryUtil.aReturningInt(var30);
                  break;
               }

               var56 = -1;
            }

            int var16 = var56;
            int var65;
            int var66;
            while (true) {
               short var137 = 17426;
               long var138 = 1533850489430378029L ^ var2;
               byte var96 = 9;
               int var95 = var17;
               label110:
               if (var95 < var96) {
                  label139: {
                     int var98 = var12;
                     int var97 = var17;
                     int var62 = var97;
                     int var57 = var97;
                     if (var98 == 0) {
                        int var101 = var12;
                        int var100 = var15;
                        int var99 = var57;
                        var65 = var99;
                        var66 = var100;
                        int var58 = var99;
                        int var59 = var100;
                        if (var101 != 0) {
                           break;
                        }

                        int var103 = var59;
                        int var102 = var58;
                        int var60 = var102;
                        int var61 = var103;
                        int var105 = var61;
                        int var104 = var60;
                        if (var104 == var105) {
                           break label139;
                        }

                        MinecraftClient var33 = b;
                        ClientPlayerEntity var34 = var33.player;
                        PlayerInventory var134 = var34.getInventory();
                        int var36 = var17;
                        PlayerInventory var35 = var134;
                        ItemStack var37 = var35.getStack(var36);
                        var62 = (((var37.isEmpty()) ? 1 : 0));
                     }

                     int var107 = var12;
                     int var106 = var62;
                     int var64 = var106;
                     int var63 = var106;
                     if (var107 == 0) {
                        int var108 = var63;
                        if (var108 == 0) {
                           break label139;
                        }

                        var64 = var17;
                     }

                     var16 = var64;
                     int var109 = var12;
                     if (var109 == 0) {
                        break label110;
                     }
                  }

                  var17++;
                  int var110 = var12;
                  if (var110 == 0) {
                     continue;
                  }
               }

               var66 = -1;
               var65 = var16;
               break;
            }

            int var113 = var12;
            int var112 = var66;
            int var111 = var65;
            int var69 = var111;
            int var70 = var112;
            int var67 = var111;
            int var68 = var112;
            if (var113 == 0) {
               int var115 = var68;
               int var114 = var67;
               if (var114 == var115) {
                  return null;
               }

               var70 = -1;
               var69 = this.w;
            }

            int var77;
            label146: {
               int var78;
               int var79;
               int var118 = var12;
               int var117 = var70;
               int var116 = var69;
               var78 = var116;
               var79 = var117;
               int var71 = var116;
               int var72 = var117;
               label71:
               if (var118 == 0) {
                  label147: {
                     int var120 = var72;
                     int var119 = var71;
                     if (var119 != var120) {
                        label143: {
                           int var122 = var12;
                           PacketQueueManager var121 = Prestige.u;
                           PacketQueueManager var75 = var121;
                           PacketQueueManager var73 = var121;
                           if (var122 == 0) {
                              PacketQueueManager var123 = var73;
                              PacketQueueManager var74 = var123;
                              PacketQueueManager var124 = var74;
                              if (var124 == null) {
                                 break label143;
                              }

                              var75 = Prestige.u;
                           }

                           Object[] var46 = new Object[]{var4};
                           PacketQueueManager var45 = var75;
                           byte var135 = ((byte)((var45.aReturningBoolean(var46)) ? 1 : 0));
                           int var126 = var12;
                           byte var125 = var135;
                           var77 = var125;
                           byte var76 = var125;
                           if (var126 != 0) {
                              break label146;
                           }

                           byte var127 = var76;
                           if (var127 != 0) {
                              break label147;
                           }
                        }

                        this.w = -1;
                        int var128 = var12;
                        if (var128 != 0) {
                           break label147;
                        }
                     }

                     var79 = var16;
                     var78 = var14;
                     break label71;
                  }

                  int var129 = this.w;
                  var77 = var129;
                  break label146;
               }

               Object[] var10004 = new Object[]{null, null, var10};
               var10004[1] = var79;
               var10004[0] = var78;
               Object[] var51 = var10004;
               InventoryUtil.fReturningBoolean(var51);
               this.w = var16;
               int var52 = var16;
               return var52;
            }

            int var50 = var77;
            return var50;
         }

         this.w = -1;
         Integer var83 = var13;
         var54 = var83;
      }

      return var54;
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.g;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(94841520464963L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[19];
      String var15 = "\u008a§\u0011§¤\u0083~\u0007¯\\0\u000e+ñ\u001e\u0000\u0004¹\u008d\u001f¬e\nÄ·(Tµ[*=&r:)ÊQI\u0099î@\u0016p]\u0007\u0088ob\u009c\u0001ßEQ÷Ì\u0090õætûc4\u0098ßÄp7\u008fc\u0012\u008b¬\u009a\u008fªÈ\u0012\u0091ÚS\u0005z1\u0082\u0007\u0081\u000fÓ[[\u0003½\u007f\u0082w1QýÙâ\u009bb¬\nè(\u0088äg%¸]ã×ûÖ\u0002\u001c¤¶\u0019/@Ý¼\b\u0080Ð\u000eM\u0006cy\u0005¹ÅûbÄ&½öf\u001d¾õ8¤\u0000§~©«t\u0089\u000b¡K=\u0017 ¦tWò\u009a*ç¼qe¬Æç¯\u009c-¡\u0003\u0099I\u0006Å\u0089p3c\u001cÄò è\u0013g\u009bx\u008cÕçªÓûL\u0018\u009b»a`+Ø«_F!\u0001¯\u0017D\u000f }+aî²[M\u00830\u001eó:ß£ß\u0098ÿ\u009aÛ£ps (ëâEfÞË1ì¸Ul\u0091×\u0088µrJêNC\u0012_þûnã\u0096Ä&\u0003}Ñù(l\u0092xGê\u008bËCÚ\u0099rÉ\u001f\u0091P\u00916B´dT}ÿ[\u007fH»µ\u0015²Ë\"\u0096 ä,Q\u009f\u0002×\u0018\u0013ãÆbvsfæ#à¬¦cz\u007f\u0005á·óyÊ\u001e1X8\u00ad\u009bÂöÜµªþt\u0085Ç\u0019\u0017IÓÓÛ½kÿ'\u0085\bÐ¶\u007fe\u0082´C½¦@\u0011ØËN±À\u0003Nµc}¢±\nÍ~\u0003ý\u0017k\u0098¨À(ek7Ñå\u000b¢Å¦.\"s{\u008b\u0003ÿj1]\u000fy\u0014®Ò%ì»Ï'Wû >gdÑ\b1nË \u0081+é_\fÉIºB\u0092Ô÷ñr\u000e·M{B§'í7wU\u0002*\u008b\u0082¼-c(\u0095N\u001d\u001fÊ\u001e\u0015\u0015ýþKÕß2¯¸\u001erÿïÑÎ b\u0084ê.R<\u009a|ò©¿\u0085]î\u0013m\u00ad8\u0001,8\u0011\f_\u0091ºØ\u0012w\u0097NÌ@\u0085\u0099òüf\u0015(\u0082?\u009b\u0088lf,H\u0004¼)\u009e\u0085mºû/îk\u0093ì\u0018\u001cnâ]\nù\u001d¿/\u008e\u0001Ä\u0018ï(qëaJ°+Kçk\u0006þìD¼\u0019\u001d*0\u0083\u0016Ûh\u0010i¸\u0007Ë)æcÖè\u001e\u0014þ\f5'R(\u0096¢þH\u0014\u0011Q:Ä\u009d÷=\u0083Ê§\u0099\fª\u0018\u0090PCHcU\u001f\u008d\u008eA\u001b\u000b\u0001cG@<ú\u0005añ0\u0016Øú'ýðH\u0001ß\u0002þt>]ßÑü=\u0012:£\u00930jj\u0098Y\u0086\u0000ýÌþ\u0015g$y\u008cdw§6\u0004\u0000ÑÙµ\u0086Z";
      int var17 = "\u008a§\u0011§¤\u0083~\u0007¯\\0\u000e+ñ\u001e\u0000\u0004¹\u008d\u001f¬e\nÄ·(Tµ[*=&r:)ÊQI\u0099î@\u0016p]\u0007\u0088ob\u009c\u0001ßEQ÷Ì\u0090õætûc4\u0098ßÄp7\u008fc\u0012\u008b¬\u009a\u008fªÈ\u0012\u0091ÚS\u0005z1\u0082\u0007\u0081\u000fÓ[[\u0003½\u007f\u0082w1QýÙâ\u009bb¬\nè(\u0088äg%¸]ã×ûÖ\u0002\u001c¤¶\u0019/@Ý¼\b\u0080Ð\u000eM\u0006cy\u0005¹ÅûbÄ&½öf\u001d¾õ8¤\u0000§~©«t\u0089\u000b¡K=\u0017 ¦tWò\u009a*ç¼qe¬Æç¯\u009c-¡\u0003\u0099I\u0006Å\u0089p3c\u001cÄò è\u0013g\u009bx\u008cÕçªÓûL\u0018\u009b»a`+Ø«_F!\u0001¯\u0017D\u000f }+aî²[M\u00830\u001eó:ß£ß\u0098ÿ\u009aÛ£ps (ëâEfÞË1ì¸Ul\u0091×\u0088µrJêNC\u0012_þûnã\u0096Ä&\u0003}Ñù(l\u0092xGê\u008bËCÚ\u0099rÉ\u001f\u0091P\u00916B´dT}ÿ[\u007fH»µ\u0015²Ë\"\u0096 ä,Q\u009f\u0002×\u0018\u0013ãÆbvsfæ#à¬¦cz\u007f\u0005á·óyÊ\u001e1X8\u00ad\u009bÂöÜµªþt\u0085Ç\u0019\u0017IÓÓÛ½kÿ'\u0085\bÐ¶\u007fe\u0082´C½¦@\u0011ØËN±À\u0003Nµc}¢±\nÍ~\u0003ý\u0017k\u0098¨À(ek7Ñå\u000b¢Å¦.\"s{\u008b\u0003ÿj1]\u000fy\u0014®Ò%ì»Ï'Wû >gdÑ\b1nË \u0081+é_\fÉIºB\u0092Ô÷ñr\u000e·M{B§'í7wU\u0002*\u008b\u0082¼-c(\u0095N\u001d\u001fÊ\u001e\u0015\u0015ýþKÕß2¯¸\u001erÿïÑÎ b\u0084ê.R<\u009a|ò©¿\u0085]î\u0013m\u00ad8\u0001,8\u0011\f_\u0091ºØ\u0012w\u0097NÌ@\u0085\u0099òüf\u0015(\u0082?\u009b\u0088lf,H\u0004¼)\u009e\u0085mºû/îk\u0093ì\u0018\u001cnâ]\nù\u001d¿/\u008e\u0001Ä\u0018ï(qëaJ°+Kçk\u0006þìD¼\u0019\u001d*0\u0083\u0016Ûh\u0010i¸\u0007Ë)æcÖè\u001e\u0014þ\f5'R(\u0096¢þH\u0014\u0011Q:Ä\u009d÷=\u0083Ê§\u0099\fª\u0018\u0090PCHcU\u001f\u008d\u008eA\u001b\u000b\u0001cG@<ú\u0005añ0\u0016Øú'ýðH\u0001ß\u0002þt>]ßÑü=\u0012:£\u00930jj\u0098Y\u0086\u0000ýÌþ\u0015g$y\u008cdw§6\u0004\u0000ÑÙµ\u0086Z"
         .length();
      char var14 = '(';
      int var26 = -1;

      label54:
      while (true) {
         String var27 = var15.substring(++var26, var26 + var14);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var11.doFinal(var27.getBytes("ISO-8859-1"));
            String var38 = b(var19).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var38;
                  if ((var26 += var14) >= var17) {
                     D = var18;
                     E = new String[19];
                     I = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(94841520464963L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[22];
                     String var4 = "5ð\u0083ºrDzóò¿G,ãêÐ\u009f\u0090L\u0094²qX³+¡VMÂ\u0015ö\u001d-\u0095ÿYBÚ«ð'\u0002lô{¨H\u0082]ÔéoC\u0099^´¬\u009cTZaG#èJ\u0093\u0006f\u0082\n/6F\u008bK\u008f®\u0006\u000e\u0080\u0081ùíèIu\u0015gQ%&\u0096Ô¾vÂâWÈ4Êªâ\f¢\f/ïæ¢S5\n\u0081=Ë\u008b®SÄ\u0015FÃh\tá\u001c&¤m\u0090DÜÖY{#&u(ð\u009cà\bÏs\u00944½@m\u000e\u00916\u0093=Ó{\u008cÝL";
                     int var5 = "5ð\u0083ºrDzóò¿G,ãêÐ\u009f\u0090L\u0094²qX³+¡VMÂ\u0015ö\u001d-\u0095ÿYBÚ«ð'\u0002lô{¨H\u0082]ÔéoC\u0099^´¬\u009cTZaG#èJ\u0093\u0006f\u0082\n/6F\u008bK\u008f®\u0006\u000e\u0080\u0081ùíèIu\u0015gQ%&\u0096Ô¾vÂâWÈ4Êªâ\f¢\f/ïæ¢S5\n\u0081=Ë\u008b®SÄ\u0015FÃh\tá\u001c&¤m\u0090DÜÖY{#&u(ð\u009cà\bÏs\u00944½@m\u000e\u00916\u0093=Ó{\u008cÝL"
                        .length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var30 = var6;
                        var10001 = var3++;
                        long var42 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var42;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var47 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var45) {
                              case 0:
                                 var30[var10001] = var47;
                                 if (var2 >= var5) {
                                    G = var6;
                                    H = new Integer[22];
                                    j = new Item[]{Items.RAIL, Items.POWERED_RAIL, Items.DETECTOR_RAIL, Items.ACTIVATOR_RAIL};
                                    String var23 = "textures/item/tnt_minecart.png";
                                    String var22 = "minecraft";
                                    A = Identifier.of(var22, var23);
                                    break;
                                 }
                                 break;
                              default:
                                 var30[var10001] = var47;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "IÞ\u0087³\u001e7\u00076g\u007f\u0000\u009dÛ\u008a®÷";
                                 var5 = "IÞ\u0087³\u001e7\u00076g\u007f\u0000\u009dÛ\u008a®÷".length();
                                 var2 = 0;
                           }

                           int var36 = var2;
                           var2 += 8;
                           var7 = var4.substring(var36, var2).getBytes("ISO-8859-1");
                           var30 = var6;
                           var10001 = var3++;
                           var42 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var45 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var26);
                  break;
               default:
                  var18[var16++] = var38;
                  if ((var26 += var14) < var17) {
                     var14 = var15.charAt(var26);
                     continue label54;
                  }

                  var15 = "ÑSµUà\u0090\u000e\u0005E^LäxÂÙR\u0011?<¿\u007fåù\u001dO¦FÝö8\u0099äßßB&;Ó\u008c\u00900n\\|¸öE,ó\u0086\u0013n\u0088\u0007\u0005º\u000e§YªjW\u0099¸Èª3\u0016Q¼¥ÀyùÇÃ£\u0091vØ\u0085cÚ\u001b½\u0087Ö\u001a\u0019";
                  var17 = "ÑSµUà\u0090\u000e\u0005E^LäxÂÙR\u0011?<¿\u007fåù\u001dO¦FÝö8\u0099äßßB&;Ó\u008c\u00900n\\|¸öE,ó\u0086\u0013n\u0088\u0007\u0005º\u000e§YªjW\u0099¸Èª3\u0016Q¼¥ÀyùÇÃ£\u0091vØ\u0085cÚ\u001b½\u0087Ö\u001a\u0019"
                     .length();
                  var14 = '(';
                  var26 = -1;
            }

            var27 = var15.substring(++var26, var26 + var14);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2578;
      if (E[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])F.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               F.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eq", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = D[var5].getBytes("ISO-8859-1");
         E[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return E[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eq_C0250",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eq" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29288;
      if (H[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = G[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])I.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               I.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eq", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         H[var3] = var15;
      }

      return H[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eq_C0250",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eq" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = K[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = J[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 53;
            yield var15;
         }
         case 1 -> {
            byte var16 = 34;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 21;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 44;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 42;
            yield var22;
         }
         case 8 -> {
            byte var23 = 14;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 5;
            yield var26;
         }
         case 12 -> {
            byte var27 = 4;
            yield var27;
         }
         case 13 -> {
            byte var28 = 22;
            yield var28;
         }
         case 14 -> {
            byte var29 = 7;
            yield var29;
         }
         case 15 -> {
            byte var30 = 16;
            yield var30;
         }
         case 16 -> {
            byte var31 = 43;
            yield var31;
         }
         case 17 -> {
            byte var32 = 15;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 8;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 20;
            yield var36;
         }
         case 22 -> {
            byte var37 = 40;
            yield var37;
         }
         case 23 -> {
            byte var38 = 0;
            yield var38;
         }
         case 24 -> {
            byte var39 = 9;
            yield var39;
         }
         case 25 -> {
            byte var40 = 32;
            yield var40;
         }
         case 26 -> {
            byte var41 = 12;
            yield var41;
         }
         case 27 -> {
            byte var42 = 61;
            yield var42;
         }
         case 28 -> {
            byte var43 = 46;
            yield var43;
         }
         case 29 -> {
            byte var44 = 35;
            yield var44;
         }
         case 30 -> {
            byte var45 = 25;
            yield var45;
         }
         case 31 -> {
            byte var46 = 58;
            yield var46;
         }
         case 32 -> {
            byte var47 = 59;
            yield var47;
         }
         case 33 -> {
            byte var48 = 17;
            yield var48;
         }
         case 34 -> {
            byte var49 = 57;
            yield var49;
         }
         case 35 -> {
            byte var50 = 62;
            yield var50;
         }
         case 36 -> {
            byte var51 = 39;
            yield var51;
         }
         case 37 -> {
            byte var52 = 55;
            yield var52;
         }
         case 38 -> {
            byte var53 = 31;
            yield var53;
         }
         case 39 -> {
            byte var54 = 24;
            yield var54;
         }
         case 40 -> {
            byte var55 = 63;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 37;
            yield var58;
         }
         case 44 -> {
            byte var59 = 19;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 11;
            yield var62;
         }
         case 48 -> {
            byte var63 = 28;
            yield var63;
         }
         case 49 -> {
            byte var64 = 26;
            yield var64;
         }
         case 50 -> {
            byte var65 = 6;
            yield var65;
         }
         case 51 -> {
            byte var66 = 47;
            yield var66;
         }
         case 52 -> {
            byte var67 = 30;
            yield var67;
         }
         case 53 -> {
            byte var68 = 3;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 54;
            yield var72;
         }
         case 58 -> {
            byte var73 = 36;
            yield var73;
         }
         case 59 -> {
            byte var74 = 60;
            yield var74;
         }
         case 60 -> {
            byte var75 = 23;
            yield var75;
         }
         case 61 -> {
            byte var76 = 52;
            yield var76;
         }
         case 62 -> {
            byte var77 = 38;
            yield var77;
         }
         default -> 29;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            K[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      J[0] = ":@\u00156#J,@\u0010l0];\u000b\u0013j<I*L\u0004}w[\u001b";
      J[1] = int.class;
      K[1] = "java/lang/Integer";
      J[2] = "!\u0006u\b\\7!\u0006bTP8;MbJP-<<6\u0012\u0007";
      J[3] = float.class;
      K[3] = "java/lang/Float";
      J[4] = "\u000f\u0013Dw\b!\u0004\u001cU8d\"\n\u001eWwH";
      J[5] = boolean.class;
      K[5] = "java/lang/Boolean";
      J[6] = "*iUNfu*iB\u0012jz0\"B\fjo7S\u0012Q;";
      J[7] = "}\u001aop\u0017Y}\u001ax,\u001bVgQx2\u001bC` -mB";
      J[8] = "\fa\u0013KJ\u001b\u001aa\u0016\u0011Y\f\r*\u0015\u0017U\u0018\u001cm\u0002\u0000\u001e\u000f.";
      J[9] = "]ur&\u0012JVzcisD]qg3";
      J[10] = "OY\u001bT\u0011SOY\f\b\u001d\\U\u0012\f\u0016\u001dIRc]IO\u0002";
      J[11] = "Q!yrd|Q!n.hsKjn0hfL\u001b?h:";
      J[12] = "&;t{\u0004\u0019-4e4l\u0019#;v";
      J[13] = "\"-_\u001c\u0003\n4-ZF\u0010\u001d#fY@\u001c\t2!NWW\u001e>";
      J[14] = "u=+*\u0013/\u0000\u001d %\u0002`a\u0013+.\u0006:\u0015";
      J[15] = "/?\u0015;&=9?\u0010a5*.t\u0013g9>?3\u0004pr.'3\u0006{(c\u001b(\u0006f($,?";
      J[16] = "nd^H\t=xd[\u0012\u001a*o/X\u0014\u0016>~hO\u0003])s";
      J[17] = "^3^xbEH3[\"qR_xX$}FN?O36Qx";
      J[18] = "\b8\f\u0006\u001cU}\u0018\u0007\t\r\u001a\u001c\u0016\f\u0002\t@h";
      J[19] = "zQIme7\u000fqBbtxn\u007fIip\"\u001a";
      J[20] = "nU\u00073aheZ\u0016|\u0002ep\\";
      J[21] = "8k.0{;.k+jh,9 (ld8(g?{/.-";
      J[22] = "n/_J&Xe N\u0005EUp-AnpWa>]BgZ";
      J[23] = "~,bpf\u000eh,g*u\u0019\u007fgd,y\rn s;2\u001cN";
      J[24] = "HS\u0000:_\u001d=s\u000b5NR\\}\u0000>J\b(";
      J[25] = "D\u000f\u0017`\u0002\u001fR\u000f\u0012:\u0011\bED\u0011<\u001d\u001cT\u0003\u0006+V\u000bW";
      J[26] = "6\u001dY\u0003tZC=R\fe\u0015\"3Y\u0007aOV";
      J[27] = void.class;
      K[27] = "java/lang/Void";
      J[28] = "m2%!=5{2 {.\"ly#}\"6}>4ji&s";
      J[29] = "3w.kt\u001e3w97x\u0011)<9)x\u0004.Mnv.";
      J[30] = "msc3$\u001d{sfi7\nl8eo;\u001e}\u007frxp\t\u007f";
      J[31] = "heP5>5\u001dE[:/z|KP1+ \b";
      J[32] = double.class;
      K[32] = "java/lang/Double";
      J[33] = "*\u000e\u000ej\u0000\u0002!\u0001\u001f%}\u001a2\u0006\u0016l";
      J[34] = ".%1\u0001.=[\u0005:\u000e?r:\u000b1\u0005;(N";
      J[35] = "zi(WL:li-\r_-{\".\u000bS9je9\u001c\u0018)f";
      J[36] = "u\u000eSLI\n\u0000.XCXEa SH\\\u001f\u0015";
      J[37] = ",\u0007\\\u00132kY'W\u001c#$8)\\\u0017'~L";
      J[38] = "`;[o(E\u0015\u001bP`9\nt\u0015[k=P\u0000";
      J[39] = "7G\r\na_Bg\u0006\u0005p\u0010#i\r\u000etJW";
      J[40] = "\ts\u0019We\u0005\u001fs\u001c\rv\u0012\b8\u001f\u000bz\u0006\u0019\u007f\b\u001c1\u0011\u000b";
      J[41] = "ZF]\r\u001an/fV\u0002\u000b!Nh]\t\u000f{:";
      J[42] = "pI\u0014pRVfI\u0011*AAq\u0002\u0012,MU`E\u0005;\u0006E-";
      J[43] = "4s@i7\u0018ASKf&W ]@m\"\rT";
      J[44] = "\u001b\u0010 [\rxn0+T\u001c7\u000f> _\u0018m{";
      J[45] = "<-J5Z,I\rA:Kc(\u0003J1O9\\";
      J[46] = "`<#W0.\u0015\u001c(X!at\u0012#S%;\u0000";
      J[47] = "\u0013*Pq\u001ar\u0013*G-\u0016}\taG3\u0016h\u000e\u0010\u0015iO/";
      J[48] = "UQ^:Y$UQIfU+O\u001aIxU>Hk\u001c'\u0002";
      J[49] = "\"\u0011m[lG\"\u0011z\u0007`H8Zz\u0019`]?+*D4";
      J[50] = "7ppnXR7pg2T]-;g,TH*J5v\u0000\f";
      J[51] = "R\u0011~h\u0019/R\u0011i4\u0015 HZi*\u00155O+9v@";
      J[52] = "\u00179\t:u\u0011\u00019\f`f\u0006\u0016r\u000ffj\u0012\u00075\u0018q!\u0002\u001f";
      J[53] = "bJ\u001fejp\u0017j\u0014j{?vd\u001fa\u007fe\u0002";
      J[54] = "Q\u0012(\u0003V^Q\u0012?_ZQKY?AZDL(m\u001b\r\u0006";
      J[55] = "Fw_\"\tqFwH~\u0005~\\<H`\u0005k[M\u001a4T*";
      J[56] = "2\\]t\ro2\\J(\u0001`(\u0017J6\u0001u/f\u0018mY4";
      J[57] = "\\\b\u0012/]\"\\\b\u0005sQ-FC\u0005mQ8A2W6\tr";
      J[58] = "\u0004\u0019n:%#q9e54l\u00107n>06d";
      J[59] = "\u007fyn'\t~\nYe(\u00181kWn#\u001ck\u001f";
      J[60] = "\u001eh\u0012\u001b-\u0007\u0000`\bTP\u0017\u0000";
      J[61] = "EG\u0015\u0015G\u00020g\u001e\u001aVMQi\u0015\u0011R\u0017%";
      J[62] = "XK\u0016JTO-k\u001dEE\u0000Le\u0016NAZ8";
      J[63] = "\u0004pG29LqPL=(\u0003\u0010^G6,Yd";
      J[64] = "L>zPMS9\u001eq_\\\u001cX\u0010zTXF,";
      J[65] = "xzZ\u0000LwxzM\\@xb1MB@me@\u001f\u001c\u0017'";
      J[66] = "a(%C\tE\u0014\b.L\u0018\nu\u0006%G\u001cP\u0001";
      J[67] = "?lr\u0011y\u001b?leMu\u0014%'eSu\u0001\"V7\r\"J";
      J[68] = "\u0015\u0002]S\u001es\u0015\u0002J\u000f\u0012|\u000fIJ\u0011\u0012i\b8\u001aDE/";
      J[69] = "H4\u001c\u0017\u007f\\C;\rX\u0018^V0\r\u0013#";
      J[70] = "r6)\\ktd6,\u0006xcs}/\u0000twb:8\u0017?gy";
      J[71] = "n}r6N5\u001b]y9_zzSr2[ \u000e";
      J[72] = "\u0006DY|)\u001f\u0018LC3R?%a";
      J[73] = "e\u0001\u0012\u0010A\u0003n\u000e\u0003_&\u001bj\u0012\u0005\u0013\u0003\n";
      J[74] = "Lq\u0017~\u000fdRy\r1heCb\u0000kNc";
      J[75] = "3ko\u0003xl3kx_tc) xAtv.Q*\u001f,2";
      J[76] = "\u0017\u0014Td4\u001b\u0017\u0014C88\u0014\r_C&8\u0001\n.\u0012\u007foC";
      J[77] = "GbQ\belGbFTic])FJivZX\u0010\u0014=5";
      J[78] = "\u001fQ+5UMjq :D\u0002\u000b\u007f+1@X\u007f";
      J[79] = ";2}Mb\u000f-2x\u0017q\u0018:y{\u0011}\f+>l\u00066\u00184";
      J[80] = "xyM'a\"\rYF(pmlWM#t7\u0018";
      J[81] = "6\t9F\nsC)2I\u001b<\"'9B\u001ffV";
      J[82] = "uqngj*\u0000Qeh{ea_nc\u007f?\u0015";
      J[83] = "\u0014^,jiC\u0002^)0zT\u0015\u0015*6v@\u0004R=!=R\b";
      J[84] = "?\u0001\u0012\u0007M\bJ!\u0019\b\\G+/\u0012\u0003X\u001d_";
      J[85] = "\u0007K)5\u0000\u001a\u0007K>i\f\u0015\u001d\u0000>w\f\u0000\u001aqo(ZG";
      J[86] = ",b p8\u007f,b7,4p6)724e1Xfhm&";
      J[87] = "z\u0001z\u0005\u000euz\u0001mY\u0002z`JmG\u0002og;<\u0012U,";
      J[88] = "\u001fUf\t\u0017l\tUcS\u0004{\u001e\u001e`U\bo\u000fYwBC}\u001d";
      J[89] = "p%!_Tc\u0005\u0005*PE,d\u000b![Av\u0010";
      J[90] = "4m!\u0001II\"m$[Z^5&']VJ$a0J\u001d_\u001f";
      J[91] = "\u00194\\3#\fl\u0014W<2C\r\u001a\\76\u0019y";
      J[92] = ",n)U-\u0012YN\"Z<]8@)Q8\u0007L";
      J[93] = "n\u000bH\u001a&\u0019\u001b+C\u00157Vz%H\u001e3\f\u000e";
      J[94] = "\u0017\u0010GeP\u0012b0LjA]\u0003>GaE\u0007w";
      J[95] = "u#\nYpK\u0000\u0003\u0001Va\u0004a\r\n]e^\u0015";
      J[96] = "G>8q\u0011\n2\u001e3~\u0000ES\u00108u\u0004\u001f'";
      J[97] = "<^SwJQI~Xx[\u001e(pSs_D\\";
      J[98] = "Za\u001b9j=/A\u00106{rNO\u001b=\u007f(:";
      J[99] = ".W!S\u0003\u0014[w*\\\u0012[:y!W\u0016\u0001N";
      J[100] = " F}Xf+6Fx\u0002u<!\r{\u0004y(0Jl\u00132?\u000e";
      J[101] = "x]A\\\u001c\u001b\r}JS\rTlsAX\t\u000e\u0018";
      J[102] = ")6\\\u0001>\b)6K]2\u00073}KC2\u00124\f\u001a\u001cjE$?I\\ >ug\u0018";
      J[103] = "c9\u007f<T\u0007c9h`X\byrh~X\u001d~\u00038+\fW";
      J[104] = "J6\u0016o/KJ6\u00013#DP}\u0001-#QW\fPrz";
      J[105] = "\u0010~Y??j\u0010~Nc3e\n5N}3p\rD\u001e(g:ZxAp!p!(\u0014'b";
      J[106] = ";W\u0010j\u0016\u0014;W\u00076\u001a\u001b!\u001c\u0007(\u001a\u000e&mW}NDqQ\b%\b\u000e\n\u0000Pv";
      J[107] = "Q\u0005k\u00143RQ\u0005|H?]KN|V?HL?&\tm\n";
      J[108] = "\r\u0019\u001cQjk\u0013\u0011\u0006\u001e\bw\u0014\f";
      J[109] = "l>\u000b_s\u0004l>\u001c\u0003\u007f\u000bvu\u001c\u001d\u007f\u001eq\u0004FC)U";
      J[110] = "2r\u001f7cF2r\bkoI(9\buo\\/HR*=\u001b";
      J[111] = "Lyx.D#9Ys!UlXWx*Q6,";
      J[112] = "qUms\u0017FgUh)\u0004Qp\u001ek/\bEaY|8CP";
      J[113] = "\u001a,\u00117x&o\f\u001a8ii\u000e\u0002\u00113m3z";
      J[114] = "R@^yn\u0015'`Uv\u007fZFn^}{\u00002";
      J[115] = "\u001e1YQ\"1k\u0011R^3~\n\u001fYU7$~";
      J[116] = "\u000b6t\u0017:\u001b~\u0016\u007f\u0018+T\u001f\u0018t\u0013/\u000ek";
      J[117] = "&Az\u001e\u0013Z&AmB\u001fU<\nm\\\u001f@;{<\u0003K\u0003";
      J[118] = "\u0000G'H\u0003\u0002ug,G\u0012M\u0014i'L\u0016\u0017`";
      J[119] = "(j)\u0003EW]J\"\fT\u0018<D)\u0007PBH";
      J[120] = "\u001eZn11zkze> 5\ntn5$o~";
      J[121] = "F]TxXOF]C$T@\\\u0016C:TU[g\u0011a\u0000\u0015";
      J[122] = "AQ'goZ4q,h~\u0015U\u007f'czO!";
      J[123] = "\u0002W8$r\u0006ww3+cI\u0016y8 g\u0013b";
      J[124] = "$Jr+\u001a#Qjy$\u000bl0dr/\u000f6D";
      J[125] = "#7\u0007r\u0018~V\u0017\f}\t17\u0019\u0007v\rkC";
      J[126] = "U^p-,+C^uw?<T\u0015vq3(ERafx9g";
      J[127] = "8\u001e^\u0016\rIM>U\u0019\u001c\u0006,0^\u0012\u0018\\X";
      J[128] = "4cly\n?ACgv\u001bp Ml}\u001f*T";
      J[129] = "\u0001$8\u001f\u0016u\u0001$/C\u001az\u001bo/]\u001ao\u001c\u001e}\bI.";
      J[130] = "%X\u0016JZOPx\u001dEK\u00001v\u0016NOZE";
      J[131] = "r\u001b\u001a?S>r\u001d\u0015b( vP++N,}\u0011NjX \u001fYM;Jtz\u0018[7(<yIIcM}oE+";
      J[132] = "S\u0016\u0005R<n\r\u0015]]]`=\u0016\u0002Q wCC\u0011@%x=U\u0005T?8X\u0014\u0013X]";
      J[133] = "C\u0012b:[/CI:oW@\u001fN~1Q,-\u00199o\b}z\u0018fk[.\u001e\u001aooR@";
      J[134] = ")\u0013\u0012L8d:\u0014\rQI~@M\u001bRv!9\u0015_Bsy";
      J[135] = "\u001et:J%=\\l.^dWB~)Z=;p-m\u0004gj'uh@53\u001bh9UdWA./U>k\\\u007f:\u0004Zn@|%E0,Xh1\u0004Z";
      J[136] = "\u0002c\u0003CQ\u0004\u0011d\u001c^ \u0014kf\u0000\tZNQ\u007f\u001fW\u001f";
      J[137] = "\u001c^\u000b\u0005}GDO\f\u0012A\u0014ANW\u0004\u0016C\u001f\u001e\u000eh\"K\u0011\\Q\u000b \u0002LY";
      J[138] = "Z+Zs8N\u0018pQ+;+\rpW&7|S(\u0000s[\u0012YoKxaB\u0006.T9";
      J[139] = "R\r\u00027m#_\r\t,\u0004!8\u0006\u00129y3FS\u0001(|<8]\u000e'y+TN\u0016'fM";
      J[140] = "\u0001UwX6H\u0003\u001eoO:#Q%'D5^F[rW$[I%$U3^WN&\u001e+I[%";
      J[141] = "+9P=x\u0000*>U=\u001c\u0015yzS&p'->\u000b~ p+9P=x\u0000*>U=\u001c";
      J[142] = "nT\n\u0000\u0001n1\u0003\u0014\u0019dk9\u0012\u0006\u0002\bYnRV_T\u000eo\n\\\b\njm\u0003X\u0001d";
      J[143] = "\u0018A\u000f0\u0000G\u0005\u0010\u001aad\u0015\u0019\u0006\u00106\u0018{\u0018A\u000f0\u0000G\u0005\u0010\u001aadA\u001f\u0010\b!\u001a\u0014\f\u0001\r.d\u001dC\u0006\u001a;X\u0000\u0012\u0013K_";
      J[144] = "9*\u001c\u0019=fg:D\r \fo'_3!va,Lh;1z%GT&`ot#";
      J[145] = "EN\u001e\u0017`|O\u0010Z\u0012~\u0015\u001a\u001b\\\u001evy(O\u0018F!\u0015\u001a\u001b\u0018Dq*\u001fH@\u0000\u0011p\u0012N\u001a\u001e.uA\u0016^~txGL@Aq+\u001f\b Eu/\u0012\u0018DG|+\u001bv";
      J[146] = "p.cKA\u0017s`3\u0015E'$s>\u0014\u0013pv#mLN'p(*\u0015\rC$t/\n\u001d";
      J[147] = "gL#Z\u0002$gJ,\u0007y$s\rn7\u001c22Mr\b\u0019aj\t\u0012R\u0014g0\u0017-WG?tw";
      J[148] = "=q\r\u0013F\\shJ\\*\u0007/hRKF5\u007f*\f\u0013*[/(\u000bFV\u0019z~^M*";
      J[149] = "`\n\u0011zD\u0017\"YS$Fv3dVuW\u000b$\u001a\u0003fF\u000e+dWp\u0001\u001b4\u0000Uy\u0005\u0012Z";
      J[150] = "hsUn\u000ex=7\u000e-A\u001e<(\u00002RIkrQf>$hqUfXq,*\u0016)";
      J[151] = "P}h2uP\u001ed/}\u0019\u000bBd7ju9\u0015#l7 nJuo7yQO&7s\u0019";
      J[152] = "a0-\u0006'K>g3\u001fBN6v!\u0004.|`1|\\{+k:{_rZjly\u001bB";
      J[153] = "C\u000b*\u0016+\u000b\u0001^|C w\u0017\u001fkF%\fzXt\u0017*I\u001c\u0005iR$wA\u0002,B/\u0013C\u000b(KA";
      J[154] = "\u001faaO|9GpfX@jBq=N\u0017=\u001d-a\"1jB%#\u001fqm[#";
      J[155] = "{iNa]^%j\u0016n<[\u0015iIbAGk<ZsDH\u00152U|A_y!M|^9";
      J[156] = "}\fGc{]&^\u0018e{g!\u000b_if\u000b\u0013_\u001c61\\D_Qcc\n{\u0003Ex}\u001aD";
      J[157] = "\u001f!TM.KA\"\fBO@q!SN2R\u000ft@_7]q V\u0018\"B\u0015\"_\u001c+,";
      J[158] = "RS9!V!\r\u0004'83$\u0005\u00155#_\u0016WRh\u007f3x\bV$$Y&\u0018\u000e093z\fS8*Wx\u0005W1DR<\u001a\u00143(A$\u001a\u000bU";
      J[159] = "\u0004P\\r<Z\u0005WYrXOV\u0013_i4}\u0002W\u00050`*B\tVliO\u0003\u001fZ\u000e";
      J[160] = "|\u0013\u00033Vq\"\u0010[<7x\u0012\u0013\u00040JhlF\u0017!Og\u0012P\u00035U'w\u0011\u001597";
      J[161] = "^;lDs>W}gC7\u0007\u0002ouJnk0?5\u00119\u0007\u001ed`H8b_rl*0<\u0006r6Fez\u0019}7*";
      J[162] = "\u0007%S;x}Y&\u000b4\u0019\u007fi%T8dd\u0017pG)aki~H&d|\u0005mP&{\u001a";
      J[163] = "\u001a\u0005?S\u0013\u000f\u001b\u0002:Sw\u001aHF<H\u001b(\u001c\u0002d\u001fK\u007f\u001a\u0005?S\u0013\u000f\u001b\u0002:Sw";
      J[164] = "J~[gf\u001b\u001cbX=\u0019\r{(Bjd\u001a\u0005}Q{a\u0015{)G<t\n\u001f+N8}d";
      J[165] = "?;_YXMb4\u0018CU<mb\u0006U@]`~`\u0017K\u0004m;\u0006JVAc\u0005[M\u0013QhaYD\u0017X\u0006";
      J[166] = "\u0007t,\u0002Q:S;y]U\nS$q\\\u0002]\u0004|$\u0003P\n\u0007t,\u0002Q:S;y]U";
      J[167] = "\b;JhB4](YmM\u000f_3Hn\\X\fb\u001d:06X=Gx\u000bcK.Bw";
      J[168] = "u\u0006q\"K\u000bsVopQt)\u0004a{L\u0018\u001bT#%\u0014tu\u0004!\"A\b7QwwJt";
      J[169] = "3C\u00075\u0015>2\u0015\u0005q%*n\u000f]nI\u0018:K\u00074%\u007f3I\u00019T~eKE\t@\";I]6Eqc\r=";
      J[170] = "AR5\f^\u001a\u0006@7Z\nc\u0011V\u000eL\u0003\n\u001a\u0001k\r\u0015\u0006x";
      J[171] = "m\u0010l'9Z{\u0015i\"RK\u0011Af./Xo\u0014u?*W\u0011\u001az0/@}\tb00&";
      J[172] = ";v\u0013\u0002ko6v\u0018\u0019\u0002jQ}\u0003\f\u007f\u007f/(\u0010\u001dzpQv\u000e\u0018c~. \u0012\u001b9\u0001";
      J[173] = "\u0018\u0012;]WW\u0012L\u007fXI>GGyTARu\u001b4\b&\u0004\u001a\u0014lEO\u000eDPi[&\u0005F\u0010hZB\u0007O\u0014a4";
      J[174] = "*\u0004\u001a$[\u007f/P\u001ag?yMTJ3Bl3\u0001Y\"GcMTDeXi \u0017@1@\u0012";
      J[175] = "ps'o(=/6|jh\u0003 K s>~75u`/{8K!vhn'/#\u007flgI";
      J[176] = "\u001a~\\\u00016cD}\u0004\u000eWmt~[\u0002*z\n+H\u0013/ut;_QhhJuF\u0016'\u0004";
      J[177] = "\u0004\u001d\u0011 'j[J\u000f9BoS[\u001d\".]\u0000\u001eDxB1Z\u001d\u0010+&3S\u0019\u0019E";
      J[178] = "q'G\r\n'/(_\u0000W_&L\u000f\u001c\u0002\"62Z\u000f\u0013'9L\u000e\u0019T2&(\f\u0010P;H";
      J[179] = "6Jkk+|xS,$G'$S43+\u0015p\u001fkewBy\u001fnhw3xIl,G";
      J[180] = "H+J4Yq\u001dmU;X\u001d\u0014}W$\u0001q&/\u001a|W\u001dH*U5\\'\u0018u\u0014*\u001d\u001d";
      J[181] = "I2qL\"U\u0017=iA\u007f-\u0019Y9]*P\u000e'lN;U\u0001YbA4P\u00165qY4Op";
      J[182] = "H<\u000b\u0011|o\u00153L\u000bq\u001e\u0016l4_o&\u001a<R\u0002rc\u0014\u0002\r_2n\u0000sPPut\r\u0002";
      J[183] = "K-q\":WIa%?KY\u0016;++\"U/5+;&3J8u+%WH1q\"K";
      J[184] = "Q\u00124E&\"^\u0015,9tM\u0016N/[.(WX#9";
      J[185] = "p%m\u0004sfqso@Cy!x3T\u0014.{(o8&zx/7\u0007#) k";
      J[186] = "\u001fx8\u0007vjA{`\b\u0017dqx?\u0004js\u000f-,\u0015o|q}a\u000bki\u0001|f\u000ek\r";
      J[187] = "^\u001bf\u0018C\u000e\u0006\na\u000f\u007f]\u0003\u000b:\u0019(\n]\\buE\t\u000e\u0003;\u0015\u001a^\u0010\u001a";
      J[188] = "\u0017`mW+WH7sNNR@&aU\"`\u0014j>\u0003~7\u001dj;\u000e~F\u001c<9JN";
      J[189] = "\u0003 `:\u001dlU<c`bz2vy7\u001fmL#j&\u001ab2vwa\u0005h_5s5\u001d\u0013";
      J[190] = "tG%7[}tA*j z~0y5Zkt\u0007\u0014?M>#\u001c+:\u001efg|q7\u0018<yCtd@x\u0019";
      J[191] = "c\u000e\n\u001d}Fe\\\u0016J&y:\t\u0012b(\t&`R@\u007f\u00144\u0004PI{\u001dZ";
      J[192] = "\b>3 2^K}*6?'\\g#/cp\u000b9sv?'\b>3 2^K}*6?";
      J[193] = "WJOO\u0004(\f\u0018\u0010I\u0004\u0012\u000bMWE\u0019~9\u0019\u0014\u001aA-n\u001f\u0014F\u0002v\u001e\u001e\u0013C\u0002\u0012";
      J[194] = "U:qN5Z\t9q\u001d6e\u00129k\u0002)\"\u0002Pv\u0019-\u0007]57\u000f!eU:qN5Z\t9q\u001d6e";
      J[195] = "\u000f\u0014\\%N\fQ\u0017\u0004*/\u0002a\u0014[&R\u0015\u001fAH7W\u001aaKWr\u0015\u000b^N\u0004*Qk";
      J[196] = " g\u0013\u0016<[b<\u0018N?>w<\u001eC3i)fB\u0016_\u0007##\u0002\u001deW|b\u001d\\";
      J[197] = "#\u0005T|y\u0003#\u0003[!\u0002\u001d'Ne+mB)E\bhi\u00161>_~8\u001f5S\u001czl\u0007N\u0004\n+e\u0003#G\u000e\u007f}x";
      J[198] = "u\u0004$\u007f?u+\u0007|p^|\u001b\u0004#|#leQ0m&c\u001b\u0005&*3|\u007f\u0007/.:\u0012";
      J[199] = "\u0006D\u0005L\u0000=Q\u001a[\u001d\u000f\u0003P!\u0006\u0011\u0002~A_S\u0002\u0013{N!Y\u001dV9_\u001e\\N\u000e}?";
      J[200] = "'o\u0013\u0010]\u0007>pMUlTE'H\u0006\u0011C;r[\u0017\u0014LEzC[\u0017Y(\u007f\u0017[T=";
      J[201] = "7aR:NG7g]g5W7;\u0007WPQb`\u0003hU\u0002:$c2X\u0004`:\\7\u000b\\$Z";
      J[202] = "TmH\u0005#M\nbP\b~5\t\u0006\u0000\u0014+H\u0013xU\u0007:M\u001c\u0006\u0001\u0011}X\u0003b\u0003\u0018yQm";
      J[203] = "_n\u0001\rr\u000f\u000eg\\O\u0012\u0018?7Y]o\u000fAbJLj\u0000?=\b\u000b.AN<^\tjq";
      J[204] = "~\nQa{K(\u0016R;\u0004^O\\HlyJ1\t[}|EO\\F:cO\"\u001fBn{4";
      J[205] = "\u0015\u001c<Wx\"K\u001fdX\u0019/{\u001c;Td;\u0005I(Ea4{\u0019e[e!\u000b\u0018b^eE";
      J[206] = "jt%\u001d\u0012\u00064w}\u0012s\b\u0004t\"\u001e\u000e\u001fz!1\u000f\u000b\u0010\u0004w!IJZ}03K\u001c\u000e\u0004";
      J[207] = ">)iDSC|rb\u001cP&ird\u0011\\q7-4H0\u001f=mxO\nOb,g\u000e";
      J[208] = "\bHy1@IV\u001ej*!\u0016X\rw(M$\fN(s\u001bs\f\u0003k#XMP\u0014q.Xs\f\u001bs%[IWI,#[s";
      J[209] = "yDlSgmxCiS\u0003x+\u0007oHoJzE2\u00123\u001dvK5\u00133lw\u001d7W\u0003";
      J[210] = "mf\u0012$\u001aa21\f=\u007fd: \u001e&\u0013VidBq\u007fx15\u001cp\u001a9'9~";
      J[211] = "\b\u0012gMh\n^@v\rUT\\\u001fe\f\u000bS\\\u0005apoU\u0002\u001fw\u001d,QV\u0007\f";
      J[212] = "[\u0015\u00001YzV\u0015\u000b*0}1\u001e\u0010?MjOK\u0003.He1\u0015\u001d+QkNC\u0001(\u000b\u0014";
      J[213] = "\u001a[\u001dy[8]G\\(f1`\u0018B-\u001b$\u001eMQ<\u001e+`C^3\u001b<\fPF3\u0004Z";
      J[214] = "\u0011+d=z\u001cO(<2\u001b\u0014\u007f+c>f\u0005\u0001~p/c\n\u007fhd;yJ\u001a)r7\u001b";
      J[215] = "n\u0013EYg;0\u0010\u001dV\u00067\u0000\u0013BZ{\"~FQK~-\u0000PE_dme\u0011SS\u0006";
      J[216] = "pJF\u001c\u0002\u001eq\u001cDX2\n-\u0006\u001cG^8yBG\u00192\n-BF@\r\u000f~\u001a\u0002 W\u0002x@\u001c\u001fRQ \u0004|E_Wz\u001aC@\f\u000f>zL\u0010\bSp\u000bMF\n\u0017@";
      J[217] = "p\u0016\u0012.\u0000\u0018q\u0011\u0017.d\r\"U\u00115\b?v\u0011IlUh6O\u00180U\rwY\u0014R\u001d\u000e&K@7\\\u0018*)\b4\r\n~LI\"\u0001hp\u0016\u0012.\u0000\u0018q\u0011\u0017.d";
      J[218] = "n\u0006GHgi0\u0005\u001fG\u0006g\u0000\u0006@K{p~SSZ~\u007f\u0000\u0005KY7\u007f?YHYd|\u0000";
      J[219] = ">Ps\u0014\u0007?bDh\n\u0017\u0000iCt\u0012\u0006W>\u0019\"Lj9uH{\u001bUeaSe\u000b";
      J[220] = "_*\u0015H5z\nl\nG4\u0016\u0003|\bXmz1,D\u0006;*f+NAod\u0002\u007f\u0012Dptf/\u0016\u0000a(\u0000r\u000bEo\u0016";
      J[221] = "\u0016Y3=_\\HZk2>_xY4>CE\u0006\f'/FJx\u0002( C]\u0014\u00110 \\;";
      J[222] = "/]\u0014/R{w\u0019\u0004*\n\u0002\u007f%@q\u0000\u007fh[\u0015b\u0011zg%AtVoxAC}Rf\u0016";
      J[223] = "07^x~S$jU!\u0017G_lOwjU!9\\foZ_9OktB'-\u0012`-+";
      J[224] = "\u0002tJZ{r]#TC\u001ewU2FXrE\u0003w\u001b\u0003.\u0012\u0001wCQd+\b1HV \u0012";
      J[225] = "Z5p3RL\u0018n{kQ)\rn}f]~S6(=1\u0010Yqa8\u000b@\u00060~y";
      J[226] = "`'\u000b\u0011_ds \u0014\f.p\ty\u0003\r\u0014qt+\u0001\u001dDx";
      J[227] = "Bd|9*{\u001d3b O~\u0015\"p;#LC`,as\u001bB1*;4v\u00015~#O";
      J[228] = "#\u0017O\u000f!\u0019vQP\u0000 u\u007fAR\u001fy\u0019M\u0013\u001fA&u!H\u0014\u0012p\u0011#A\u0010\u001b\u001e";
      J[229] = "\n\u0011\u0010SOAUF\u000eJ*D]W\u001cQFv\r\u001bF\u0007*\u001b\b\u0015\u0015GC\u0011VQ\u0010Y*";
      J[230] = "(\u000b4\u0000~o(\r;]\u0005q$V\u0005Wj.\"Kh\u0014nz:0?\u0002?s>]|\u0006kkE\njWbo(In\u0003z\u0014";
      J[231] = "PvI{.\u0004\u0018-\ruux\u000b0Ze\u007f\u0004\r67&x\u001bSt\b *\u0007\u0004/7";
      J[232] = ";@z%\u001c\u0012=\u0004z'Z~f\u0007m#\u0003\u0017e}x$\f\u001c0\u001892\u0000~";
      J[233] = "}\u0019\u001a\u0017\u0013\u001a!\u001a\u001aD\u0010%%\u0015\u0018x\u000bA9\u001ed_\u0004L&B\u0001\u001e\u0012@D";
      J[234] = "Q\u0002 ?\u001b/\u001f\u001bgpwtC\u001b\u007fg\u001bF\u0014[.:N\u0011\u0017\bs9\u0017n\u0011Xmk\r\u0011";
      J[235] = "^v$\u0005@C^p+X;DT\u0017|\u0004ZQU6\u0015\rV\u0000\t-*\b\u0005XMMp\u0005\u0003\u0002SruV[F3";
      J[236] = "*,\u000eO~&t/V@\u001f'D,\tLb?:y\u001a]g0Dw\u0015Rb'(d\rR}A";
      J[237] = "\u0005L<%U,\u0003\u001e r\u000e\u0013ZO/`m-^\u001a4\"\u000bpC_:\u001c";
      J[238] = "d*m]\u0003<d,b\u0000x,nj\\U\u0015\u007f3qcPF'w\u00119]@}i.<\u000e\u00189\t";
      J[239] = ";c \u001a36>7 YW2\\3p\r*%\"fc\u001c/*\\3~[0 1pz\u000f([";
      J[240] = "Y'\\'\u000e\u001fY!Szu\r^gmp\u001a^Sg\u00003\u001e\nK\u001cW%O\u0003Oq\u0014!\u001b\u001b4";
      J[241] = "!uWLx c.\\\u0014{Ev.Z\u0019w\u0012(\u007f\u000bM\u001b|\"1FG!,}pY\u0006";
      J[242] = "tgb-\rg7${;\u0000\u001e >r\"\\Iw`\"{\u0001\u001etgb-\rg7${;\u0000";
      J[243] = "VYY5R T\u000fSf#;KHH;O\t\u001c\u0004\u0019b#d\u001cXM9C;KFT\\\u001a7IVZgO$ZSU\\\u001a4B^RfAf\u001dXR\\\u001aoF_E3\u001a4\u001e\nI\\";
      J[244] = ".\u0005u\u001eM^l^~FN;y^xKBl'\u0005.\u0011.\u0002-Ad\u0015\u0014Rr\u0000{T";
      J[245] = "\u001ao,bji\u001b9.&ZvK2r2\r!\u0011b,^?u\u0012eva:&J!";
      J[246] = "g7?mYYfa=)iF6ja=>\u0011l:<Q\fEo=en\t\u00167y";
      J[247] = "+2Y:|\u001885F'\r\u001eBoF7c\u001c#-\u0015u=\u001e";
      J[248] = "\r\u0019 @3HS\u00168Mn0]rhQ;MJ\f=B*HErkZ)\u0001EM7Y)RFr";
      J[249] = "v&T]hltp^\u000e\u0019wk7ESuE<{\u0014\u000b\u0019`9tDRxs9$X4xot6CXkwt)%";
      J[250] = "X\u00120\u001bR`\u0006\u0011h\u00143j6\u00127\u0018NyHG$\tKv6\u00132N^iR\u0011;JW\u0007";
      J[251] = "i\u0015@}\u000f:;\u0017P-\u0006G9l\u0016&\r:.\u0012C5\u001c?!l\u0017#[*>\b\u0015*_#P";
      J[252] = "\u000b=r\u001eK?E$5Q'd\u0019$-FKVNcv\u0018\u0018\u0001\u00115u\u001bG>\u0014f-_'";
      J[253] = "\u000f\u001a2>UgQ\u0019j14ia\u001a5=I~\u001fO&,Lqa\u001b0kYn\u0005\u00199oP\u0000";
      J[254] = "g8c\u0013F\u0011f?f\u0013\"\u00045{`\bN6d6>T\u001da=j8UB^89`\u0011\"\u00045?:\u000f\u001d\u0001fg~oG\f`=`PB_8y\u0000P\u001d\u0002$cpQ\u001a\u0007$\u0007";
      J[255] = "!\u0013l%s\ny\u0002k2OY|\u00030$\u0018\u000e#^kHr\u000es\u00105r,X`\u000b";
      J[256] = "&\u0016Urt~,TC~wBy@Xwp.K\u0010\u001b+,}\u001c\u0017\u001eisz`_E-}!\u001c";
      J[257] = "C!-\t;RB&(\t_G\u0011b.\u00123uE&tKd\"\u0005x'\u0017nGDn+u";
      J[258] = "k\u0012i_;8%\u000b.\u0010Wcy\u000b6\u0007;Q.LmYg\u0006q\u001anZ79tI6\u001eW";
      J[259] = "!>y\\<Fwlh\u001c\u0001\bx0o\fF\u0018\u0011n}[f\r|-y\u000f~v!>y\\<Fwlh\u001c\u0001";
      J[260] = "eWj\u0014=6%Ps\u0012GeuToA\u00102%\u00017-5y)P{C$j{R";
      J[261] = "Z\u000eci\u0019\u001f[\tfi}\n\bM`r\u00118Y\u0000>.Mo\\W;oF\u0011Y\\1v\u0019oZ\u000eci\u0019\u001f[\tfi}";
      J[262] = "H&(w)\u001aQ(msE\u000b##w{8\u001f]vdj=\u0010##y-\"\u001aN`}y:a";
      J[263] = "4\u000b&\u001b\nX%\u0018t\u0019zS+\u0005{\u0015\u0016a\u007fE Nz\r\"Cv\u001c\u001e\u000f+G\u007fr";
      J[264] = "f\u001b)E\u00077!\t+\u0013SN6\u001c\u0012L\ftcIcMZv'y";
      J[265] = "O1/p\u0006*\u00112w\u007fg$!e$/\u001f*J7sb\u001eMOfyg\u0000&\u001d14fg";
      J[266] = "[Kp \u0004{HLo=un2\u0015diIn\fB:7\u0018a";
      J[267] = "\b\u00195+8bN\u0004x jZT\u00129-a6fE{w>d1E%2}&@Eysa31@z.z>AA}+zZ\u000bNuw9j_\u0001 (=Z\n\u001b\u007f h>\b\u0012{)\u0006";
      J[268] = "X]\u00150&\"\u0006^M?G\"6]\u00123:;H\b\u0001\"?46\u0006\u000e-:#Z\u0015\u0016-%E";
      J[269] = "\u007f*\u001b\u0011\tIp-\u0003mZ&8v\u0000\u000f\u0001Cy`\fm";
      J[270] = "\u0006g\u00116\u0010\u001c^v\u0016!,O[wM7{\u0018\u0005$\u0010[\\LKsX%^\u001aA ";
      J[271] = "+5>f\u0001\u0016+31;z\u0016'h\u000fn\u0017U|n0kD\r8\u000ejfBW&1o5\u001a\u0013F";
      J[272] = "l9k$/I=06fOI\f`3t2Ir5 e7F\f;/j2Q`(7j-7";
      J[273] = "r%Q=\u0001\u00030~Ze\u0002f%~\\h\u000e1{/\u00010b_qa@6X\u000f. _w";
      J[274] = "6\u0011{H^+j\u0005`VN\u0014a\u0002|N_C6X*\u00113-}\tsG\fqi\u0012mW";
      J[275] = "^\u0005|\u0007\u0015}_\u0002y\u0007qh\fF\u007f\u001c\u001dZX\u0002%EM\r\u0018\\v\u0019@hYJz{";
      J[276] = "\u001aUB{BEX\u000eI#A M\u000eO.Mw\u0013W\u001c{!\u0019\u0019\u0011Sp\u001bIFPL1";
      J[277] = "zE<\u001f\u0006+eR(\\v&\u001e\u00151K\u000b<`@\"Z\u000e3\u001eN-U\u000b$r]5U\u0014B";
      J[278] = "\u001b~2K>}FquQ3\fK,a;qn\u001a+3],s_%\r\u0000+6O.i\u0002\"2F@";
      J[279] = "9fMq\r\u0012vgYt=A\u0004 UpV\u0016b}H5X(";
      J[280] = "FIG\"4\u0002KIL9]\u0002,BW, \u0012R\u0017D=%\u001d,\u0019K2 \n@\nS2?l";
      J[281] = "O\u007f\u007fYIAB\u007ftB B%toW]Q[!|FX^%/sI]II<kIB/";
      J[282] = "\u0015a\u000613\u0002\u00177\fbB\u0019\bp\u0017?.+_=NiB\u000eZ3\u0016>#\u001dZc\nX{\u0015\nn\u0005c.\u0006\u0019k\nX{M\u0005g\u001a7{\u0016]2\u0016X";
      J[283] = "IC9k\t7HD<km*\u000f\u00013s\u0016GH\u001eb|S!\u0015\u0003'rm|\u0012F7y\t~\u001bB>\u0017";
      J[284] = "9\u0000>\u0015J\t*\u0007!\b;\u0015P\r~\u0014Y\u001b>\u0000~\u001fB";
      J[285] = "]oN\u0016_!\u00028P\u000f:$\n)B\u0014V\u0016Yl\u001aO:x\u000e:@\u0001\u0001-\u001d)E\u000e: \u001a'_\u0015V3\u0002'@s";
      J[286] = "\u0007\u001apui(Y\u0015hx4PWq8da-@\u000fmwp(Oq{cd2\u000f\u0014:uhP";
      J[287] = "VW.;.F\u0010Jc0|~\n\\\"=w\u00128\rca/Bo\n:g}\u0010\u000b\b3ct~";
      J[288] = ">)\u0013W\u0004i`\u007f\u0000Le6nl\u001dN\t\u00043+G\u0011el<s\u0001M\u0015m;v\u0001)\\5svC\u0011\u001a(>}\u0011)";
      J[289] = "7![LgE$!\u000bP\u0001A(b\u0004Jmsx\"[\u0012\u0001\u001d%!\u0015MkC5y\u0001P\u0001";
      J[290] = "u\\W^cl)WX\u0000a\u0011*Z\u001a\u0005k}\u0018\bY_6\u00116Q\u000f\u0007=twG\u0003e6~uP\u001d\buz!Hf";
      J[291] = "A?+\u0010A\u001a\u0003d HB\u007f\u0016d&EN(H?r\u0018\"FB{:\u001b\u0018\u0016\u001d:%Z";
      J[292] = "?\u0006H\u001af4c\u0011[[r[g\u0017X\u001fu'a\u00115\\r8?S\nZ $h\b5";
      J[293] = " \u0017\u0019yyZ \u0011\u0016$\u0002H6MN\u0014gLu\u0016H+b\u001f-R(qo\u0019wL\u0017t<A3,";
      J[294] = "rraPWIar1L1Ey07UJ(>/fZ\u000fNc2#T1\u0013dw3_U\u0011ms:1";
      J[295] = "EYDf\u0002T\u001bZ\u001cicK+YCe\u001eMU\fPt\u001bB+\u0002_{\u001eUG\u0011G{\u00013";
      J[296] = "\u0001\t\u0004\u001coI_\u0019\\\br#]\u0004G\rhOoU\u0000Q0\u001b8\u000f\u0006\u0017`G\u0004\u0012W\u00021#\u0001\tV\u0012nE_\u0003C\u0010d#";
      J[297] = "L\u0011\u0016\u000eQ0L\u0017\u0019S*\"]CAY*.L\u0012\u001d\u0003\u0015+\u001fJYcO&\u0019\u0010G\\JuAT'\u0006Gs\u001bJ\u0018\u0003\u0014+_*";
      J[298] = "5g\u007f]i*$t-_\u0019!*i\"Su\u0013}.~\u0004 D|qxYw ~x|P\u0019%:g?Ru6\"g 4";
      J[299] = " M{\u0002P.b\u0016pZSKw\u0016vW_\u001c)N#\t3r#\tj\t\t\"|HuH";
      J[300] = "\u0007w\u0014DE\u001fYtLK$\u0014iw\u0013GY\u0006\u0017\"\u0000V\\\ti4\u0014BFI\fu\u0002N$";
      J[301] = "Us\u0016MC\u0002\u000e!IKC8\tt\u000eG^T; M\u0018\t\u0004l)B\u001d\u0005\b\u001d(\u0014\u001fA8";
      J[302] = "\u000e'6Gt{\u000bs6\u0004\u0010hiwfPmh\u0017\"uAhgi,zNmp\u0005?bNr\u0016";
      J[303] = "z#\u001a\u0012cc%fA\u0017#])\u001b\u001d\u000eu =eH\u001dd%2\u001b\u001d\u0000#:8v^\u0004w\"C";
      J[304] = "%ZQ<\u0004k{Y\t3eaKZV?\u0018r5\u000fE.\u001d}K\u0019Q:\u0007=.XG6e";
      J[305] = "\b(\t\u0013\u00154V+Q\u001ct0f(\u000e\u0010\t-\u0018}\u001d\u0001\f\"fs\u0012\u000e\t5\n`\n\u000e\u0016S";
      J[306] = "00SmR%m?\u0014w_Tbj\u0001tYThs\u001e`E8{k\u001e\u007f#";
      J[307] = ";f=wY\u001118yrGxd3\u007f~O\u0014Vg;'\u0014xd3;$HGa`c`(B9`joAHg$oq(";
      J[308] = "F\u0018^yK?\u0018\u001b\u0006v*2(\u0018YzW&VMJkR)(\u0013TnK'WEHm\u0011X";
      J[309] = "4Rq`\u001caj\u0004b{}>d\u0017\u007fy\u0011\f0[&'G[0\u0006ba\u00074l\u0011q \u0013[";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = J[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(K[var4]);
            J[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = J[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = K[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            J[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  J[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(662987352044110L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = J[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = K[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  J[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(662987352044110L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        J[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(662987352044110L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 226;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 78;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 85;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 72;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 181;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 230;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 226;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 78;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 85;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eq_C0250",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eq" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(CartPearlCatch var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eq_C0250;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eq_C0250", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((CartPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
