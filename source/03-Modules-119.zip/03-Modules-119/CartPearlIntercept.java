package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.Vec3d;

public record CartPearlIntercept(Vec3d am, int an) {
}
