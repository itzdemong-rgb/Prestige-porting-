package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public class CartRefill extends Module {
   private ModeSetting a;
   private BindSetting f;
   private IntSetting c;
   private IntSetting d;
   private ElapsedTimer e;
   private static final long k = 120659128618241L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[52];
   private static final String[] s = new String[52];

   public CartRefill() {
      super();
      long var10001 = 53868861477260L ^ 90111869347493L;

      this.e = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 90035973447006L ^ 52095490198346L;
      var10001 = 90035973447006L ^ 130938362377566L;
      var10001 = 90035973447006L ^ 116375187135263L;
      var10001 = 90035973447006L ^ 95885229931843L;
      var10001 = 90035973447006L ^ 137887233901444L;
      int var14 = Event.bReturningInt();
      int var58 = var14;
      MinecraftClient var57 = b;
      MinecraftClient var46 = var57;
      MinecraftClient var45 = var57;
      if (var58 == 0) {
         MinecraftClient var18 = var45;
         ClientPlayerEntity var59 = var18.player;
         if (var59 == null) {
            return;
         }

         MinecraftClient var60 = b;
         var46 = var60;
      }

      MinecraftClient var21 = var46;
      ClientWorld var61 = var21.world;
      if (var61 != null) {
         ElapsedTimer var10000 = this.e;
         IntSetting var23 = this.d;
         Integer var24 = (Integer)var23.aReturningObject();
         float var84 = var24.intValue();
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var84;
         Object[] var26 = var10004;
         ElapsedTimer var25 = var10000;
         byte var76 = ((byte)((var25.aReturningBoolean(var26)) ? 1 : 0));
         int var63 = var14;
         byte var62 = var76;
         byte var48 = var62;
         byte var47 = var62;
         if (var63 == 0) {
            byte var64 = var47;
            if (var64 == 0) {
               return;
            }

            Object[] var29 = new Object[]{48977620655834L};
            CartRefill var28 = this;
            var48 = ((byte)((var28.dReturningBoolean(var29)) ? 1 : 0));
         }

         int var66 = var14;
         byte var65 = var48;
         int var50 = var65;
         byte var49 = var65;
         if (var66 == 0) {
            byte var67 = var49;
            if (var67 == 0) {
               return;
            }

            IntSetting var31 = this.c;
            Integer var32 = (Integer)var31.aReturningObject();
            var50 = var32 - 1;
         }

         int var15 = var50;
         MinecraftClient var33 = b;
         ClientPlayerEntity var34 = var33.player;
         PlayerInventory var77 = var34.getInventory();
         int var36 = var15;
         PlayerInventory var35 = var77;
         ItemStack var16 = var35.getStack(var36);
         ItemStack var37 = var16;
         byte var78 = ((byte)((var37.isEmpty()) ? 1 : 0));
         int var69 = var14;
         byte var68 = var78;
         int var52 = var68;
         byte var51 = var68;
         if (var69 == 0) {
            byte var70 = var51;
            if (var70 == 0) {
               return;
            }

            Object[] var40 = new Object[]{61798531614273L};
            CartRefill var39 = this;
            var52 = var39.aReturningInt(var40);
         }

         int var17 = var52;
         int var73 = var14;
         // int var71 = var17;
         int var55 = var71;
         int var56 = var72;
         int var53 = var71;
         byte var54 = var72;
         if (var73 == 0) {
            byte var75 = var54;
            int var74 = var53;
            if (var74 == var75) {
               return;
            }

            var56 = var15;
            var55 = var17;
         }

         var10004 = new Object[]{null, null, 7516849659933L};
         var10004[1] = var56;
         var10004[0] = var55;
         Object[] var42 = var10004;
         InventoryUtil.fReturningBoolean(var42);
         var10000 = this.e;
         Object[] var44 = new Object[]{42835128969216L};
         ElapsedTimer var43 = var10000;
         var43.aReturningVoid(var44);
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 120659128618241L ^ var2;
      int var4 = Event.cReturningInt();
      ModeSetting var6 = this.a;
      String var10000 = (String)var6.aReturningObject();
      short var10001 = 26068;
      long var10002 = 7735714351502108156L ^ var2;
      String var8 = "Always";
      String var7 = var10000;
      byte var47 = ((byte)((var7.equals(var8)) ? 1 : 0));
      int var31 = var4;
      byte var30 = var47;
      int var21 = var30;
      byte var20 = var30;
      if (var31 != 0) {
         byte var32 = var20;
         if (var32 != 0) {
            MinecraftClient var10 = b;
            return var10.currentScreen instanceof InventoryScreen;
         }

         BindSetting var12 = this.f;
         Integer var13 = (Integer)var12.aReturningObject();
         var21 = var13;
      }

      int var5 = var21;
      int var35 = var4;
      // int var33 = var5;
      int var26 = var33;
      byte var27 = var34;
      int var22 = var33;
      byte var23 = var34;
      if (var35 != 0) {
         byte var37 = var23;
         int var36 = var22;
         if (var36 == var37) {
            return false;
         }

         MinecraftClient var15 = b;
         Window var16 = var15.getWindow();
         long var48 = var16.getHandle();
         int var19 = var5;
         long var17 = var48;
         int var49 = GLFW.glfwGetKey(var17, var19);
         int var39 = var4;
         int var38 = var49;
         int var28 = var38;
         int var24 = var38;
         if (var39 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var28);
         }

         int var40 = var24;
         int var25 = var40;
         byte var42 = 1;
         int var41 = var25;
         var26 = var41;
         var27 = var42;
      }

      byte var44 = var27;
      int var43 = var26;
      if (var43 == var44) {
         byte var50 = 1;
         return dev.prestige.recovery.SourceSupport.asBoolean(var50);
      } else {
         return false;
      }
   }

   private int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 120659128618241L ^ var2;
      int var10000 = Event.bReturningInt();
      short var10001 = 10678;
      long var10002 = 7107499700452315952L ^ var2;
      int var5 = 9;
      int var4 = var10000;

      byte var19;
      while (true) {
         var10001 = 9652;
         var10002 = 6893084561110196019L ^ var2;
         byte var21 = 36;
         int var20 = var5;
         if (var20 < var21) {
            label27: {
               MinecraftClient var7 = b;
               ClientPlayerEntity var8 = var7.player;
               PlayerInventory var32 = var8.getInventory();
               int var10 = var5;
               PlayerInventory var9 = var32;
               ItemStack var6 = var9.getStack(var10);
               int var23 = var4;
               ItemStack var22 = var6;
               ItemStack var18 = var22;
               ItemStack var15 = var22;
               if (var23 == 0) {
                  ItemStack var11 = var15;
                  byte var33 = ((byte)((var11.isEmpty()) ? 1 : 0));
                  int var25 = var4;
                  byte var24 = var33;
                  var19 = var24;
                  byte var16 = var24;
                  if (var25 != 0) {
                     break;
                  }

                  byte var26 = var16;
                  byte var17 = var26;
                  byte var27 = var17;
                  if (var27 != 0) {
                     break label27;
                  }

                  var18 = var6;
               }

               ItemStack var14 = var18;
               Item var34 = var14.getItem();
               Item var29 = Items.TNT_MINECART;
               Item var28 = var34;
               if (var28 == var29) {
                  return var5;
               }
            }

            var5++;
            int var30 = var4;
            if (var30 == 0) {
               continue;
            }
         }

         var19 = -1;
         break;
      }

      return var19;
   }

   private boolean lambda$new$0(Integer var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Keybind";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(39665295900008L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[2];
      String var17 = "$Å«81Ô\u0099u\u0002s\u0003\u0089ÐU\u0015\u00ad\u0010\u001ed½¤\u001a(§ºZ\u0014\u0094Ì\u0096\u0093\"ÿ";
      int var19 = "$Å«81Ô\u0099u\u0002s\u0003\u0089ÐU\u0015\u00ad\u0010\u001ed½¤\u001a(§ºZ\u0014\u0094Ì\u0096\u0093\"ÿ".length();
      char var16 = 16;
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var27 = b(var21).intern();
         int var10001 = -1;
         var20[var18++] = var27;
         if ((var15 += var16) >= var19) {
            l = var20;
            m = new String[2];
            q = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(39665295900008L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[2];
            String var4 = "5)}Lù*.ï<N³\u009dBp\u008cí";
            int var5 = "5)}Lù*.ï<N³\u009dBp\u008cí".length();
            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               // var6[var10001] = var10004;
            } while (var2 < var5);

            o = var6;
            p = new Integer[2];
            break;
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5106;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/er", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/er_C0252",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/er" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12742;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/er", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/er_C0252",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/er" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 42;
            yield var15;
         }
         case 1 -> {
            byte var16 = 14;
            yield var16;
         }
         case 2 -> {
            byte var17 = 16;
            yield var17;
         }
         case 3 -> {
            byte var18 = 38;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 34;
            yield var21;
         }
         case 7 -> {
            byte var22 = 36;
            yield var22;
         }
         case 8 -> {
            byte var23 = 3;
            yield var23;
         }
         case 9 -> {
            byte var24 = 6;
            yield var24;
         }
         case 10 -> {
            byte var25 = 0;
            yield var25;
         }
         case 11 -> {
            byte var26 = 5;
            yield var26;
         }
         case 12 -> {
            byte var27 = 35;
            yield var27;
         }
         case 13 -> {
            byte var28 = 27;
            yield var28;
         }
         case 14 -> {
            byte var29 = 60;
            yield var29;
         }
         case 15 -> {
            byte var30 = 33;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 18;
            yield var32;
         }
         case 18 -> {
            byte var33 = 29;
            yield var33;
         }
         case 19 -> {
            byte var34 = 51;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 41;
            yield var36;
         }
         case 22 -> {
            byte var37 = 45;
            yield var37;
         }
         case 23 -> {
            byte var38 = 39;
            yield var38;
         }
         case 24 -> {
            byte var39 = 26;
            yield var39;
         }
         case 25 -> {
            byte var40 = 54;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 11;
            yield var42;
         }
         case 28 -> {
            byte var43 = 49;
            yield var43;
         }
         case 29 -> {
            byte var44 = 56;
            yield var44;
         }
         case 30 -> {
            byte var45 = 2;
            yield var45;
         }
         case 31 -> {
            byte var46 = 43;
            yield var46;
         }
         case 32 -> {
            byte var47 = 1;
            yield var47;
         }
         case 33 -> {
            byte var48 = 63;
            yield var48;
         }
         case 34 -> {
            byte var49 = 13;
            yield var49;
         }
         case 35 -> {
            byte var50 = 28;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 55;
            yield var53;
         }
         case 39 -> {
            byte var54 = 48;
            yield var54;
         }
         case 40 -> {
            byte var55 = 53;
            yield var55;
         }
         case 41 -> {
            byte var56 = 4;
            yield var56;
         }
         case 42 -> {
            byte var57 = 15;
            yield var57;
         }
         case 43 -> {
            byte var58 = 10;
            yield var58;
         }
         case 44 -> {
            byte var59 = 9;
            yield var59;
         }
         case 45 -> {
            byte var60 = 31;
            yield var60;
         }
         case 46 -> {
            byte var61 = 24;
            yield var61;
         }
         case 47 -> {
            byte var62 = 61;
            yield var62;
         }
         case 48 -> {
            byte var63 = 19;
            yield var63;
         }
         case 49 -> {
            byte var64 = 59;
            yield var64;
         }
         case 50 -> {
            byte var65 = 23;
            yield var65;
         }
         case 51 -> {
            byte var66 = 57;
            yield var66;
         }
         case 52 -> {
            byte var67 = 22;
            yield var67;
         }
         case 53 -> {
            byte var68 = 46;
            yield var68;
         }
         case 54 -> {
            byte var69 = 17;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 25;
            yield var71;
         }
         case 57 -> {
            byte var72 = 20;
            yield var72;
         }
         case 58 -> {
            byte var73 = 8;
            yield var73;
         }
         case 59 -> {
            byte var74 = 32;
            yield var74;
         }
         case 60 -> {
            byte var75 = 58;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 50;
            yield var77;
         }
         default -> 62;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "Jd\u0011\u001av \\d\u0014@e7K/\u0017Fi#Zh\u0000Q\"1k";
      r[1] = int.class;
      s[1] = "java/lang/Integer";
      r[2] = "C\u0019K}<\u0002C\u0019\\!0\rYR\\?0\u0018^#\bgg";
      r[3] = "\r\u0006\b\u0013\"\u000b\r\u0006\u001fO.\u0004\u0017M\u001fQ.\u0011\u0010<M\u000byS";
      r[4] = "Q\fjm^;Q\f}1R4KG}/R!L6/t\nk";
      r[5] = "QV1\u0006Z2QV&ZV=K\u001d&DV(Llt\u001f\u000ei";
      r[6] = "z<\"9Uvl<'cFa{w$eJuj03r\u0001cl";
      r[7] = "c0\u0006\u0019V\u0007h?\u0017V5\n}2\u0018=\u0000\bl!\u0004\u0011\u0017\u0005";
      r[8] = boolean.class;
      s[8] = "java/lang/Boolean";
      r[9] = "_4CNT\u001e_4T\u0012X\u0011E\u007fT\fX\u0004B\u000e\u0006X\tE";
      r[10] = "t\u0000)?*6t\u0000>c&9nK>}&,i:n w";
      r[11] = "`U7evF`U 9zIz\u001e 'z\\}or{/\u001e";
      r[12] = long.class;
      s[12] = "java/lang/Long";
      r[13] = "121,\u0019^:= cdF):)*";
      r[14] = "\u0010}\r\r o\u001br\u001cBAa\u0010y\u0018\u0018";
      r[15] = "l\u0019\u007f\"!Kl\u0019h~-DvRh`-Qq#??{";
      r[16] = "~<9i-o{)2i&tw9p\u0000\r^F";
      r[17] = "TFhb4|BFm8'kU\rn>+\u007fDJy)`hv";
      r[18] = "\u0013?\u0012:-\u0003\u00180\u0003uJ\u0001\r;\u0003>q";
      r[19] = "Q\nJ\u001c@ZO\u0002PS=JO";
      r[20] = "KAAx/4>aJw>{_oA|:!+";
      r[21] = "\u001cp{%L\u000f\np~\u007f_\u0018\u001d;}yS\f\f|jn\u0018\u0019!";
      r[22] = " O-Q^tUo&^O;4a-UKa@";
      r[23] = "~O\fk\t\u0012~O\u001b7\u0005\u001dd\u0004\u001b)\u0005\bcuNv\\";
      r[24] = "t\\pz8k\u0001|{u)$`rp~-~\u0014";
      r[25] = void.class;
      s[25] = "java/lang/Void";
      r[26] = "b\u0003/'\\W\u0017#$(M\u0018v-/#IB\u0002";
      r[27] = "5ngX\nG#nb\u0002\u0019P4%a\u0004\u0015D%bv\u0013^T>";
      r[28] = "~qq\u0003X\u001e\u000bQz\fIQj_q\u0007M\u000b\u001e";
      r[29] = "|\u00167SZ=&\u001e+\u001e3#@\u00109\u000e\u000e.q\u00121RJO~Kq\u0014W.<Jr\u00103";
      r[30] = "gD\t\u0004op>\\\bb8Hx\u0000\u0011\u000670m\u0000Nb";
      r[31] = "tJ-U\u001eD'\nqZ\u007fH&Gu[\u0013zw\u0007$\u0004\u007f\u001d+P*\\A\u0013q^w<";
      r[32] = "_Z@\u0001B+\tU[\u0003++\u0017AP\u0007PF_FY[P7\u001f\u0002U\u000e+xW\u0006C\u0007J:V\u0005Gc";
      r[33] = ")\u001e@\u0004K\u000f\u007f\u0010A\t+\u0003}\u000fO\u0001G1+J\u0012Z\u001bf*\u001aR_J\u0007w\u000b\u0017^+";
      r[34] = "9mO[<z)uRENuT}ZUs}e\u007fR\t7\u001cj&\u0012O*}('\u0011KN";
      r[35] = "\u0018^A]J\u0003D\u0013\u0014\f'^O_H\u0004Kl\u001d\u0012\u0010R'\u0000XNAYBR\u001e\u0012\u0014c";
      r[36] = "rnqi;N(fm$RUN7ch\"Q#`m>(<sd1$?Q$jg.R";
      r[37] = "R+\u0003):\u001b\u000f|\\1EL\f)\u0004:\u0012\u001bRy]V,S\t.\u0011-?\\\r=";
      r[38] = "1IMu\"gb\u0010J}R|3(Gm2#&Y\u0007)>v]D\u0017,0k!\u0017N+8\u001b";
      r[39] = "d&LO\u000f`8k\u0019\u001eb=3'E\u0016\u000e\u000faj\u001bIbfga_\u0015\u0003$fb[q";
      r[40] = "<(\f{X&i2Z\"<u2,\u001f\tQf\u0015/\u0011F\fz=}\u0000x\u0002 3 `9\u0002{2'\u0018,\u0002$V=^'X\u007f.(^x<";
      r[41] = "(?{A\u001d}q'z'KE7{cCE=\"{<'";
      r[42] = ":xi\u0018`\rukx\u001c\n\\e~n\u0017]\u0002<-;{1Hiz0\u001ec\u000e5/";
      r[43] = "[VWY\u001bG\u0006G\u0012XzC\fCJ\u0007\u0016q\\\u0003\u0011PzY_^N\u0005\u0002L_\u0001*Z\u0007O_R\u0012\u0006J\u001a\u000e?";
      r[44] = "D$A\u007f5,\u0019s\u001egJ{\u001a&Fl\u001d,E{\u001d\u0000%)\u00163L>8k\u001cr";
      r[45] = "{8\u001b_:\r+!]O^\u001c\u0011r\u0019Ef\u000e`2]I3u";
      r[46] = "-*\t= \u001a*k\n#\u001dK -:8yW+Q\u001bo|N#)\u000eo#*";
      r[47] = "\u000e~\u0014r\u001cAS)Kjc\u0016P|\u0013a4A\u000e+K\rZ\u0015^s\u0017d\f\u001b_~";
      r[48] = "\u000e2 (Tr\u001e*=6&}c\"5&\u001buR =z_\u0014\u0003 -/Ly\u0003#-'&";
      r[49] = "\u0019O 3!OCG<~HT%I.nu\\\u0014K&21=Z\u0015=j-EO\u0015b\u000e";
      r[50] = "#\u000ebQ14~Y=INhq\u001daI\"Z&[?\u001eu\r#\u00109G/dpPeHN";
      r[51] = "lb\u001dSLE79\u0015W6L\u000e8V\u000b\u000bC?:^WO\"0c\u001e\u0011RCrb\u001d\u00156";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(991543520061122L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(991543520061122L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(991543520061122L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 111;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 237;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 82;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 212;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 211;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 119;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 111;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 237;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 82;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/er_C0252",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/er" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
