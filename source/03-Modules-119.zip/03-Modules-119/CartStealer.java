package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.util.Window;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class CartStealer extends Module {
   private MinMaxSetting a;
   private BooleanSetting d;
   private BindSetting f;
   private ElapsedTimer c;
   private static final long k = 93994298276320L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[57];
   private static final String[] p = new String[57];

   public CartStealer() {
      super();
      long var10001 = 113883537903433L ^ 7254409394272L;

      this.c = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      int var12;
      int var75;
      long var10001 = 102176754813735L ^ 51842006857064L;
      var10001 = 102176754813735L ^ 134246543500071L;
      var10001 = 102176754813735L ^ 82095605420288L;
      var10001 = 102176754813735L ^ 48367676166492L;
      var12 = Event.bReturningInt();
      BindSetting var16 = this.f;
      Integer var17 = (Integer)var16.aReturningObject();
      int var10000 = var17;
      int var84 = var12;
      int var83 = var10000;
      var75 = var83;
      int var72 = var83;
      label82:
      if (var84 == 0) {
         // int var85 = var72;
         if (var85 != var86) {
            MinecraftClient var19 = b;
            Window var20 = var19.getWindow();
            long var114 = var20.getHandle();
            BindSetting var21 = this.f;
            Integer var22 = (Integer)var21.aReturningObject();
            int var25 = var22;
            long var23 = var114;
            var10000 = GLFW.glfwGetKey(var23, var25);
            int var88 = var12;
            int var87 = var10000;
            var75 = var87;
            int var73 = var87;
            if (var88 != 0) {
               break label82;
            }

            int var89 = var73;
            int var74 = var89;
            byte var91 = 1;
            int var90 = var74;
            if (var90 != var91) {
               return;
            }
         }

         ElapsedTimer var116 = this.c;
         Object[] var30 = new Object[]{this.a, 130913203968635L};
         ElapsedTimer var29 = var116;
         var75 = (((var29.bReturningBoolean(var30)) ? 1 : 0));
      }

      int var92 = var75;
      if (var92 != 0) {
         MinecraftClient var31 = b;
         ClientPlayerEntity var32 = var31.player;
         ScreenHandler var14 = var32.currentScreenHandler;
         int var94 = var12;
         ScreenHandler var93 = var14;
         ScreenHandler var77 = var93;
         ScreenHandler var76 = var93;
         if (var94 == 0) {
            boolean var95 = var76 instanceof ShulkerBoxScreenHandler;
            if (!var95) {
               return;
            }

            ScreenHandler var96 = var14;
            var77 = var96;
         }

         ShulkerBoxScreenHandler var13 = (ShulkerBoxScreenHandler)var77;
         int var97 = var12;
         if (var97 == 0) {
            Object[] var37 = new Object[]{var13, 24497391065639L};
            CartStealer var36 = this;
            var10000 = var36.aReturningInt(var37);
            int var99 = var12;
            int var98 = var10000;
            int var79 = var98;
            int var78 = var98;
            if (var99 == 0) {
               byte var101 = 1;
               int var100 = var78;
               if (var100 <= var101) {
                  BooleanSetting var39 = this.d;
                  Boolean var40 = (Boolean)var39.aReturningObject();
                  boolean var102 = var40;
                  if (var102) {
                     MinecraftClient var42 = b;
                     ClientPlayerEntity var43 = var42.player;
                     var43.closeHandledScreen();
                  }

                  return;
               }

               var79 = 0;
            }

            int var113 = var79;

            boolean var82;
            while (true) {
               byte var104 = 27;
               int var103 = var113;
               if (var103 < var104) {
                  int var46 = var113;
                  ShulkerBoxScreenHandler var45 = var13;
                  Slot var15 = var45.getSlot(var46);
                  int var105 = var12;
                  if (var105 == 0) {
                     Slot var47 = var15;
                     boolean var118 = var47.hasStack();
                     int var107 = var12;
                     boolean var106 = var118;
                     var82 = var106;
                     boolean var80 = var106;
                     if (var107 != 0) {
                        break;
                     }

                     boolean var108 = var80;
                     boolean var81 = var108;
                     boolean var109 = var81;
                     if (var109) {
                        Slot var50 = var15;
                        ItemStack var119 = var50.getStack();
                        Item var52 = Items.TNT_MINECART;
                        ItemStack var51 = var119;
                        boolean var110 = var51.isOf(var52);
                        if (var110) {
                           MinecraftClient var54 = b;
                           ShulkerBoxScreenHandler var55 = var13;
                           byte var10003 = 0;
                           MinecraftClient var56 = b;
                           ClientPlayerEntity var62 = var56.player;
                           SlotActionType var61 = SlotActionType.QUICK_MOVE;
                           int var59 = var113;
                           int var58 = var55.syncId;
                           ClientPlayerInteractionManager var57 = var54.interactionManager;
                           var57.clickSlot(var58, var59, 0, var61, (PlayerEntity)var62);
                           ElapsedTimer var120 = this.c;
                           Object[] var64 = new Object[]{42835128969216L};
                           ElapsedTimer var63 = var120;
                           var63.aReturningVoid(var64);
                           MinMaxSetting var121 = this.a;
                           Object[] var66 = new Object[]{127318019014223L};
                           MinMaxSetting var65 = var121;
                           var65.bReturningVoid(var66);
                           return;
                        }
                     }

                     var113++;
                  }

                  int var111 = var12;
                  if (var111 == 0) {
                     continue;
                  }
               }

               BooleanSetting var68 = this.d;
               Boolean var69 = (Boolean)var68.aReturningObject();
               var82 = var69;
               break;
            }

            boolean var112 = var82;
            if (var112) {
               MinecraftClient var70 = b;
               ClientPlayerEntity var71 = var70.player;
               var71.closeHandledScreen();
            }
         }
      }
   }

   private int aReturningInt(Object[] var1) {
      ShulkerBoxScreenHandler var2 = (ShulkerBoxScreenHandler)var1[0];
      long var3 = (Long)var1[1];
      var3 = 93994298276320L ^ var3;
      int var10000 = Event.cReturningInt();
      short var10001 = 9137;
      long var10002 = 3768551907011470778L ^ var3;
      int var7 = 27;
      int var5 = var10000;

      int var12;
      while (true) {
         var10001 = 14028;
         var10002 = 8123157795140776134L ^ var3;
         byte var14 = 63;
         int var13 = var7;
         if (var13 < var14) {
            int var9 = var7;
            ShulkerBoxScreenHandler var8 = var2;
            Slot var10 = var8.getSlot(var9);
            byte var20 = ((byte)((var10.hasStack()) ? 1 : 0));
            int var16 = var5;
            byte var15 = var20;
            var12 = var15;
            byte var11 = var15;
            if (var16 == 0) {
               break;
            }

            byte var17 = var11;
            if (var17 == 0) {
               var6++;
            }

            var7++;
            int var18 = var5;
            if (var18 != 0) {
               continue;
            }
         }

         var12 = var6;
         break;
      }

      return var12;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(44479139077867L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[3];
      String var6 = "B»\u0091\u0082n\u009b\f\u0004\u008emþÑú\u0091\u008a:i1kL3Ý\u008b\u0093";
      int var7 = "B»\u0091\u0082n\u009b\f\u0004\u008emþÑú\u0091\u008a:i1kL3Ý\u008b\u0093".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Integer[3];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9676;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/es", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/es_C0254",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/es" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 48;
            yield var15;
         }
         case 1 -> {
            byte var16 = 29;
            yield var16;
         }
         case 2 -> {
            byte var17 = 4;
            yield var17;
         }
         case 3 -> {
            byte var18 = 7;
            yield var18;
         }
         case 4 -> {
            byte var19 = 14;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 16;
            yield var21;
         }
         case 7 -> {
            byte var22 = 21;
            yield var22;
         }
         case 8 -> {
            byte var23 = 63;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 13;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 30;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 5;
            yield var29;
         }
         case 15 -> {
            byte var30 = 20;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 38;
            yield var32;
         }
         case 18 -> {
            byte var33 = 11;
            yield var33;
         }
         case 19 -> {
            byte var34 = 1;
            yield var34;
         }
         case 20 -> {
            byte var35 = 36;
            yield var35;
         }
         case 21 -> {
            byte var36 = 27;
            yield var36;
         }
         case 22 -> {
            byte var37 = 46;
            yield var37;
         }
         case 23 -> {
            byte var38 = 10;
            yield var38;
         }
         case 24 -> {
            byte var39 = 35;
            yield var39;
         }
         case 25 -> {
            byte var40 = 58;
            yield var40;
         }
         case 26 -> {
            byte var41 = 15;
            yield var41;
         }
         case 27 -> {
            byte var42 = 25;
            yield var42;
         }
         case 28 -> {
            byte var43 = 50;
            yield var43;
         }
         case 29 -> {
            byte var44 = 32;
            yield var44;
         }
         case 30 -> {
            byte var45 = 57;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 37;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 2;
            yield var49;
         }
         case 35 -> {
            byte var50 = 62;
            yield var50;
         }
         case 36 -> {
            byte var51 = 44;
            yield var51;
         }
         case 37 -> {
            byte var52 = 28;
            yield var52;
         }
         case 38 -> {
            byte var53 = 19;
            yield var53;
         }
         case 39 -> {
            byte var54 = 3;
            yield var54;
         }
         case 40 -> {
            byte var55 = 8;
            yield var55;
         }
         case 41 -> {
            byte var56 = 18;
            yield var56;
         }
         case 42 -> {
            byte var57 = 52;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 6;
            yield var59;
         }
         case 45 -> {
            byte var60 = 24;
            yield var60;
         }
         case 46 -> {
            byte var61 = 31;
            yield var61;
         }
         case 47 -> {
            byte var62 = 55;
            yield var62;
         }
         case 48 -> {
            byte var63 = 47;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 33;
            yield var65;
         }
         case 51 -> {
            byte var66 = 0;
            yield var66;
         }
         case 52 -> {
            byte var67 = 22;
            yield var67;
         }
         case 53 -> {
            byte var68 = 23;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 12;
            yield var70;
         }
         case 56 -> {
            byte var71 = 54;
            yield var71;
         }
         case 57 -> {
            byte var72 = 9;
            yield var72;
         }
         case 58 -> {
            byte var73 = 61;
            yield var73;
         }
         case 59 -> {
            byte var74 = 26;
            yield var74;
         }
         case 60 -> {
            byte var75 = 43;
            yield var75;
         }
         case 61 -> {
            byte var76 = 41;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 17;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "s@%j%\u001fs@26)\u0010i\u000b2()\u0005nz`s{C";
      o[1] = boolean.class;
      p[1] = "java/lang/Boolean";
      o[2] = "s\n`\u0019dne\neCwyrAfE{mc\u0006qR0{d";
      o[3] = "I~u.\u00025Bqdaa8W|k\nT:Fow&C7";
      o[4] = "q\u0003SNp\u001dg\u0003V\u0014c\npHU\u0012o\u001ea\u000fB\u0005$\fP";
      o[5] = int.class;
      p[5] = "java/lang/Integer";
      o[6] = ";R@rO`;RW.Co!\u0019W0Cz&h\u0005k\u0011:";
      o[7] = "jlr^\u000fG|lw\u0004\u001cPk't\u0002\u0010Dz`c\u0015[SB";
      o[8] = "\u0004(\t/Zbq\b\u0002 K-\u0010\u0006\t+Owd";
      o[9] = void.class;
      p[9] = "java/lang/Void";
      o[10] = "\u00052)H6V\u00052>\u0014:Y\u001fy>\n:L\u0018\blVo\u000e";
      o[11] = long.class;
      p[11] = "java/lang/Long";
      o[12] = "|1a35\u0019|1vo9\u0016fzvq9\u0003a\u000b&,h";
      o[13] = "x\u0000\b\u0000`$x\u0000\u001f\\l+bK\u001fBl>e:J\u001d;";
      o[14] = "r\u0011z]\u001cZr\u0011m\u0001\u0010UhZm\u001f\u0010@o+9GG";
      o[15] = "T]\u0016ST\bT]\u0001\u000fX\u0007N\u0016\u0001\u0011X\u0012IgSJ\bR";
      o[16] = "2xp\u0004nr2xgXb}(3gFbh/B5\u001c6,";
      o[17] = "PlbY[e%LiVJ*DBb]Np0";
      o[18] = "guVj>#b`]j58np\u001f\u0003\u001e\u0012_";
      o[19] = " b\u001es\u0001\\+m\u000f<m_%o\rsA";
      o[20] = "\u0006V\\m\u007fu\u0010VY7lb\u0007\u001dZ1`v\u0016ZM&+c;";
      o[21] = "\u0006W'I/Ksw,F>\u0004\u0012y'M:^f";
      o[22] = "w Ns\u0004bw Y/\bmmkY1\bxj\u001a\u000beY9";
      o[23] = "e\u0014#`6-e\u00144<:\"\u007f_4\":7x.fybv";
      o[24] = "{sT\u0011Z`{sCMVoa8CSVzfI\u0011\b\u0007:";
      o[25] = "Dy\u0007)@\u0004Ry\u0002sS\u0013E2\u0001u_\u0007Tu\u0016b\u0014\u0010f";
      o[26] = "\u0019fd{X&\u0012iu49(\u0019bqn";
      o[27] = "h?\"K\u0018)c03\u0004\u007f+v;3OD";
      o[28] = "X\faiE*-,jfTeL\"amP?8";
      o[29] = "'\u0002\u0001\f'!'\u0002\u0016P+.=I\u0016N+;:8D\u0015sq";
      o[30] = "&b|NR88jf\u0001/(8";
      o[31] = "}ew%qt/cjw\u000b#@f{*r)>;ewuI~gp,59!9zq\u000b";
      o[32] = "\u000bK>w\u0004\u000f^\u001a*p>\u00020HyaBRB\u0016x}\u0002h";
      o[33] = "\u0015\\hcv\u0015LWm \fFD]cu[\u0011\u001a\u000e>\u0019=I\u001d\bbajW\u0019U";
      o[34] = "X.-+J!\r;m4v+RB7q\n'\u0001<?!\u001c7<&:7\u0011pQs/w\u000eL";
      o[35] = "dxIJmGwnV\u0007VTkpKt;GLsE;iK2~\u0004\n6\u0001qn4\u0007jCs$FYk_3\u001e\b\u0007.G5lV\u00062\u0007\u000f";
      o[36] = "{\\]2>\u000f.\rI5\u0004\u0003@_\u001a$xR2\u0001\u001b88h";
      o[37] = "\u001715/83\u000058sW'\u001c,5'>+%\"57:M\u0001- %m1A9#J";
      o[38] = "=E9<O\u000e`\u000e;0sYQW+8\nS/\n5e\r3+S:2IOkG9]";
      o[39] = "Uty*kx\u0007wuhQ+Zt}9\u0006u\u0003'(U>%\u0001}!n!~_s";
      o[40] = "c\u0003SOY\u0016z@\u0012ReF\u0003\u0010\u0010O\u000e\u0012}\u0018@Y\u001e/";
      o[41] = "\t2\u0019v;c\trW9Ue\rp5.1y\u0006\fW{-xQ~\tz18k";
      o[42] = "5o^$OYld[g5\ndnU2b]:9\r^\\Tnn['RZ4g";
      o[43] = "n+'(s_3`%$O\u000b\u000295,6\u0002|d+q1b<8>*q\u0012cf4wO";
      o[44] = "t.\u0019'\rxy~\u000f>0.)s\u0004-g\u007fw [A\f|0bZ3R},\"";
      o[45] = "\u0017:!a|/N1$\"\u0006wJ*.|jE\u001dlp+=\u0012\u0018f%!9#B,vj\u0006";
      o[46] = "E\u0013\u00106f/\u001cVG\f2~\u0004O\u001d`\u0000,F\u001fC\f-u\t@@pma\n/";
      o[47] = "g\u001a4.P&=Pgeor5V?s\u0003@d\u0016n,o((\u0017?$^wbT/\u0014";
      o[48] = ",)EU\u0018H\"'\u001f\\rT(eN_\u001efz\"\u0012\u0006r\u000f&rM\u0006\u0002Pxx\u00108";
      o[49] = "5OsY~[bQw\u0004\u001bFiR+\u0006wt>\u001fs_\u001b\u001f8V7[iA9Jwa'\u001f|Rq\u0013y\u001e`\u0012K]'[x\u00149\u0003&G8.\"\u0004kR{T:]k@\u0004D\"\u0010&\u001e>\u001e5\\e#:M \u0002%Se\u0013*_\u001b";
      o[50] = "hh\r\u0018Qokv\u0011\u0005<wQs\u0014\rE~/.\nPB\u001em-\f\u0014\u0006l3,\u0010T<";
      o[51] = "4_{\u001c_\f7Ag\u00012\u0014\r\u001cnSH\u0014tI\u007fPK}7J=\u0016[\u0004b[>\u00152";
      o[52] = "k/kl\"\u0005f\u007f}u\u001fX:crmsjh!+3\u001f\u0001kgn0m_j{.\n\"\u0001=%#6{Dj\u001f";
      o[53] = "39{,+\\=7!%AK;dt-\u0016\u001ag0*A!\u001dgdn\">G?1";
      o[54] = "\u000bT%J\r5\u000bWh\u001afj\u0005A5M\nXS\u0004h\u0015Z\u000f\u0007]oN^4\u0018\u00061@fu\u000eL:\u0010\u001a5\u001aOU";
      o[55] = "a\u000fRW8}8J\u0005ml, S_\u0001^~b\f\u0007mj(,SSWj+a\u00038";
      o[56] = "s@ hn6k\u0019 z\u0011\"{H4uFs%\u0014l\u0019x)jT/c`pjF";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1844483806599688L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1844483806599688L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1844483806599688L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 244;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 196;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 223;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 203;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 197;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 229;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 244;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 196;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 223;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/es_C0254",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/es" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
