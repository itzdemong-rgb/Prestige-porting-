package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class ChestStealer extends Module {
   private MinMaxSetting a;
   private BooleanSetting d;
   private BindSetting f;
   private ElapsedTimer c;
   private static final long k = 41558988227080L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[53];
   private static final String[] p = new String[53];

   public ChestStealer() {
      super();
      long var10001 = 114291137617098L ^ 7666063944675L;

      this.c = new ElapsedTimer(106698256430889L);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      int var14;
      int var68;
      label85: {
         long var10001 = 109870236344006L ^ 17758098251913L;
         var10001 = 109870236344006L ^ 82123688100159L;
         var10001 = 109870236344006L ^ 32364313856210L;
         var10001 = 109870236344006L ^ 75971475404486L;
         var10001 = 109870236344006L ^ 2764668084017L;
         var14 = Event.cReturningInt();
         BindSetting var18 = this.f;
         Integer var19 = (Integer)var18.aReturningObject();
         int var10000 = var19;
         int var80 = var14;
         // int var78 = var10000;
         int var66 = var78;
         byte var67 = var79;
         int var62 = var78;
         byte var63 = var79;
         if (var80 != 0) {
            byte var82 = var63;
            int var81 = var62;
            if (var81 == var82) {
               return;
            }

            MinecraftClient var21 = b;
            Window var22 = var21.getWindow();
            long var111 = var22.getHandle();
            BindSetting var23 = this.f;
            Integer var24 = (Integer)var23.aReturningObject();
            int var27 = var24;
            long var25 = var111;
            var10000 = GLFW.glfwGetKey(var25, var27);
            int var84 = var14;
            int var83 = var10000;
            var68 = var83;
            int var64 = var83;
            if (var84 == 0) {
               break label85;
            }

            int var85 = var64;
            int var65 = var85;
            byte var87 = 1;
            int var86 = var65;
            var66 = var86;
            var67 = var87;
         }

         byte var89 = var67;
         int var88 = var66;
         if (var88 != var89) {
            return;
         }

         ElapsedTimer var113 = this.c;
         MinMaxSetting var30 = this.a;
         Float var31 = (Float)var30.aReturningObject();
         float var121 = var31;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var121;
         Object[] var33 = var10004;
         ElapsedTimer var32 = var113;
         var68 = (((var32.aReturningBoolean(var33)) ? 1 : 0));
      }

      ScreenHandler var72;
      label88: {
         int var91 = var14;
         int var90 = var68;
         int var71 = var90;
         int var69 = var90;
         if (var91 != 0) {
            int var92 = var69;
            if (var92 == 0) {
               return;
            }

            MinecraftClient var35 = b;
            ClientPlayerEntity var36 = var35.player;
            int var94 = var14;
            ScreenHandler var93 = var36.currentScreenHandler;
            var72 = var93;
            ScreenHandler var70 = var93;
            if (var94 == 0) {
               break label88;
            }

            byte var95 = ((byte)((var70 instanceof GenericContainerScreenHandler) ? 1 : 0));
            var71 = var95;
         }

         int var96 = var71;
         if (var96 == 0) {
            return;
         }

         MinecraftClient var38 = b;
         ClientPlayerEntity var39 = var38.player;
         ScreenHandler var97 = var39.currentScreenHandler;
         var72 = var97;
      }

      GenericContainerScreenHandler var15 = (GenericContainerScreenHandler)var72;
      boolean var75;
      label58: {
         int var105;
         do {
            GenericContainerScreenHandler var41 = var15;
            Inventory var42 = var41.getInventory();
            int var99 = var42.size();
            int var98 = var16;
            if (var98 >= var99) {
               break;
            }

            int var44 = var16;
            GenericContainerScreenHandler var43 = var15;
            Slot var17 = var43.getSlot(var44);
            int var100 = var14;
            if (var100 != 0) {
               Slot var45 = var17;
               boolean var114 = var45.hasStack();
               int var102 = var14;
               boolean var101 = var114;
               var75 = var101;
               boolean var73 = var101;
               if (var102 == 0) {
                  break label58;
               }

               boolean var103 = var73;
               boolean var74 = var103;
               boolean var104 = var74;
               if (var104) {
                  Object[] var10005 = new Object[]{null, null, SlotActionType.QUICK_MOVE, 107127681548791L};
                  var10005[1] = 0;
                  var10005[0] = var16;
                  Object[] var48 = var10005;
                  InventoryUtil.gReturningBoolean(var48);
                  ElapsedTimer var115 = this.c;
                  Object[] var50 = new Object[]{42835128969216L};
                  ElapsedTimer var49 = var115;
                  var49.aReturningVoid(var50);
                  MinMaxSetting var116 = this.a;
                  Object[] var52 = new Object[]{127318019014223L};
                  MinMaxSetting var51 = var116;
                  var51.bReturningVoid(var52);
                  return;
               }

               var16++;
            }

            var105 = var14;
         } while (var105 != 0);

         Object[] var55 = new Object[]{var15, 45482649411577L};
         ChestStealer var54 = this;
         var75 = var54.aReturningBoolean(var55);
      }

      int var107 = var14;
      boolean var106 = var75;
      boolean var77 = var106;
      boolean var76 = var106;
      if (var107 != 0) {
         boolean var108 = var76;
         if (!var108) {
            return;
         }

         BooleanSetting var57 = this.d;
         Boolean var58 = (Boolean)var57.aReturningObject();
         boolean var109 = var58;
         var77 = var109;
      }

      boolean var110 = var77;
      if (var110) {
         MinecraftClient var60 = b;
         ClientPlayerEntity var61 = var60.player;
         var61.closeHandledScreen();
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      GenericContainerScreenHandler var2 = (GenericContainerScreenHandler)var1[0];
      long var3 = (Long)var1[1];
      var3 = 41558988227080L ^ var3;
      int var5 = Event.bReturningInt();
      GenericContainerScreenHandler var8 = var2;
      Inventory var9 = var8.getInventory();
      int var10000 = var9.size();
      int var24 = var5;
      int var23 = var10000;
      int var16 = var23;
      int var15 = var23;
      int var17;
      if (var24 == 0) {
         short var10001 = 2360;
         long var10002 = 8614676231368497495L ^ var3;
         byte var26 = 90;
         int var25 = var15;
         if (var25 == var26) {
            short var39 = 11448;
            long var42 = 4182356577608531156L ^ var3;
            byte var27 = 54;
            var17 = var27;
         } else {
            short var40 = 4412;
            long var43 = 8635552251270054225L ^ var3;
            var17 = 27;
         }
      } else {
         int var28 = var16;
         var17 = var28;
      }

      int var6 = var17;
      byte var22;
      while (true) {
         int var30 = var6;
         int var29 = var7;
         if (var29 < var30) {
            int var13 = var7;
            GenericContainerScreenHandler var12 = var2;
            Slot var14 = var12.getSlot(var13);
            byte var41 = ((byte)((var14.hasStack()) ? 1 : 0));
            int var32 = var5;
            byte var31 = var41;
            var22 = var31;
            byte var18 = var31;
            if (var32 != 0) {
               break;
            }

            int var34 = var5;
            byte var33 = var18;
            byte var21 = var33;
            byte var19 = var33;
            if (var34 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var21);
            }

            byte var35 = var19;
            byte var20 = var35;
            byte var36 = var20;
            if (var36 != 0) {
               var21 = 0;
               return dev.prestige.recovery.SourceSupport.asBoolean(var21);
            }

            var7++;
            int var37 = var5;
            if (var37 == 0) {
               continue;
            }
         }

         var22 = 1;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var22);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(6835724010181L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[3];
      String var6 = "\u009d.;é\u0081dªf@y¿#kü\u009dx\n\\ã\u0083\u0085¿\u0086&";
      int var7 = "\u009d.;é\u0081dªf@y¿#kü\u009dx\n\\ã\u0083\u0085¿\u0086&".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Integer[3];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3484;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/et", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/et_C0256",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/et" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 11;
            yield var15;
         }
         case 1 -> {
            byte var16 = 56;
            yield var16;
         }
         case 2 -> {
            byte var17 = 1;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 7;
            yield var21;
         }
         case 7 -> {
            byte var22 = 52;
            yield var22;
         }
         case 8 -> {
            byte var23 = 22;
            yield var23;
         }
         case 9 -> {
            byte var24 = 41;
            yield var24;
         }
         case 10 -> {
            byte var25 = 51;
            yield var25;
         }
         case 11 -> {
            byte var26 = 36;
            yield var26;
         }
         case 12 -> {
            byte var27 = 45;
            yield var27;
         }
         case 13 -> {
            byte var28 = 28;
            yield var28;
         }
         case 14 -> {
            byte var29 = 40;
            yield var29;
         }
         case 15 -> {
            byte var30 = 48;
            yield var30;
         }
         case 16 -> {
            byte var31 = 24;
            yield var31;
         }
         case 17 -> {
            byte var32 = 43;
            yield var32;
         }
         case 18 -> {
            byte var33 = 31;
            yield var33;
         }
         case 19 -> {
            byte var34 = 44;
            yield var34;
         }
         case 20 -> {
            byte var35 = 23;
            yield var35;
         }
         case 21 -> {
            byte var36 = 2;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 32;
            yield var38;
         }
         case 24 -> {
            byte var39 = 47;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 60;
            yield var41;
         }
         case 27 -> {
            byte var42 = 25;
            yield var42;
         }
         case 28 -> {
            byte var43 = 3;
            yield var43;
         }
         case 29 -> {
            byte var44 = 26;
            yield var44;
         }
         case 30 -> {
            byte var45 = 0;
            yield var45;
         }
         case 31 -> {
            byte var46 = 18;
            yield var46;
         }
         case 32 -> {
            byte var47 = 42;
            yield var47;
         }
         case 33 -> {
            byte var48 = 57;
            yield var48;
         }
         case 34 -> {
            byte var49 = 15;
            yield var49;
         }
         case 35 -> {
            byte var50 = 6;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 29;
            yield var52;
         }
         case 38 -> {
            byte var53 = 9;
            yield var53;
         }
         case 39 -> {
            byte var54 = 62;
            yield var54;
         }
         case 40 -> {
            byte var55 = 10;
            yield var55;
         }
         case 41 -> {
            byte var56 = 46;
            yield var56;
         }
         case 42 -> {
            byte var57 = 17;
            yield var57;
         }
         case 43 -> {
            byte var58 = 33;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 39;
            yield var60;
         }
         case 46 -> {
            byte var61 = 4;
            yield var61;
         }
         case 47 -> {
            byte var62 = 54;
            yield var62;
         }
         case 48 -> {
            byte var63 = 50;
            yield var63;
         }
         case 49 -> {
            byte var64 = 63;
            yield var64;
         }
         case 50 -> {
            byte var65 = 35;
            yield var65;
         }
         case 51 -> {
            byte var66 = 53;
            yield var66;
         }
         case 52 -> {
            byte var67 = 19;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 58;
            yield var69;
         }
         case 55 -> {
            byte var70 = 49;
            yield var70;
         }
         case 56 -> {
            byte var71 = 13;
            yield var71;
         }
         case 57 -> {
            byte var72 = 12;
            yield var72;
         }
         case 58 -> {
            byte var73 = 5;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 55;
            yield var75;
         }
         case 61 -> {
            byte var76 = 16;
            yield var76;
         }
         case 62 -> {
            byte var77 = 34;
            yield var77;
         }
         default -> 38;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "U\u000f-wy\u001dU\u000f:+u\u0012OD:5u\u0007H5hn'A";
      o[1] = boolean.class;
      p[1] = "java/lang/Boolean";
      o[2] = "}68'\buk6=}\u001bb|}>{\u0017vm:)l\\aU";
      o[3] = "Rl\u0014N\u0000\u0000'L\u001fA\u0011OFB\u0014J\u0015\u00152";
      o[4] = void.class;
      p[4] = "java/lang/Void";
      o[5] = "C`Jz\u001f4C`]&\u0013;Y+]8\u0013.^Z\u000fdFl";
      o[6] = long.class;
      p[6] = "java/lang/Long";
      o[7] = "%;Ju(\u001d3;O/;\n$pL)7\u001e57[>|\u000b\u0018";
      o[8] = "94}@*.L\u0014vO;a-\u001a}D?;Y";
      o[9] = "\u0016\u0004}J\u001f(\u0016\u0004j\u0016\u0013'\fOj\b\u00132\u000b>>PD";
      o[10] = "$\u000fA x\u00132\u000fDzk\u0004%DG|g\u00104\u0003Pk,\u00064";
      o[11] = ".n[\r\n0[NP\u0002\u001b\u007f:@[\t\u001f%N";
      o[12] = "9A:?MB9A-cAM#\n-}AX${\u007f&\u0010\u001c";
      o[13] = int.class;
      p[13] = "java/lang/Integer";
      o[14] = "+_\u0006eRv.J\reYm\"ZO\frG\u0013";
      o[15] = "{&S}M\u0015{&D!A\u001aamD?A\u000ff\u001c\u0016a\u0016O";
      o[16] = "Pw\u000f0\u0013f[x\u001e\u007f\u007feUz\u001c0S";
      o[17] = "Zul\u0007q{Lui]bl[>j[nxJy}L%j{";
      o[18] = "_.+\b\u001b*_.<T\u0017%Ee<J\u00170B\u0014n\u0011Fp";
      o[19] = "-`kbRI&oz-1D3buF\u0004F\"qij\u0013K";
      o[20] = "\u0011\u0013A_oZ\u0007\u0013D\u0005|M\u0010XG\u0003pY\u0001\u001fP\u0014;N3";
      o[21] = "oxpULtdwa\u001a-zo|e@";
      o[22] = "\u001a\u0015??pe\u0011\u001a.p\u0017g\u0004\u0011.;,";
      o[23] = "\u0007-mM?C\u0007-z\u00113L\u001dfz\u000f3Y\u001a\u0017*Rb";
      o[24] = "Bg+\u000f\u0018\u000fIh:@p\u000fGg)";
      o[25] = float.class;
      p[25] = "java/lang/Float";
      o[26] = "h\u000e+\u0005OT\u001d. \n^\u001b| +\u0001ZA\b";
      o[27] = "/1I\u0016\u0011$91LL\u00023.zOJ\u000e'?=X]E7$";
      o[28] = "#\u0005\u001a\r\u007f\u0016V%\u0011\u0002nY7+\u001a\tj\u0003C";
      o[29] = "7|<\u000b\u000eF7|+W\u0002I-7+I\u0002\\*Fy\u0012R\u001c";
      o[30] = "tx\u000bJ\u000f\u00162u\u000e#\u000b\u00006%PO9Rtu\u000e#WP&;\u0007]\u000e\u0004'\u007f7";
      o[31] = "uv\rJnuttTG\f#O.MAe*\u007fsM\u001fgIt\"TLr;~&YB\f";
      o[32] = "h\u0006y=)Q(Ud7\u0010V9Cd\"|dh\u00035}\u0010\u000f;\u00078&i\\8T`E";
      o[33] = "N\u001bx\u0000PF\u001c\n!\u001dnF$[qR\u000b\u001cN\u001bq\u001e\u0014,";
      o[34] = "xoYoM\u000673\u000763\rE0FiZ\u0007umF7Xd|oZs\u0003\u001a%;[73";
      o[35] = "~O146*<D4rNr-W?-\"@\u007f\u0010ctN,.B64<&*O8J";
      o[36] = "R[Qcjl\u0015@\u0016o\u0003>lHX6j4\\\u0015XhhWU\u0017D,3)\fCEh\u0003";
      o[37] = "\u0003\u0014CR&?\u0003\u0002@\bVf^\u0015\u0018\b:T\fWAVV2\u0002X\u001d_<r\u0002\u0014\u0002oh>\u000f\u0000\u0019\u0014.3\ni";
      o[38] = ",ya1\bL=t6buN!z%O\u0018]\u0006y+\u0000IN}(9y\u001aM.pZ1D\u0010 $0qD\\?\u0014k1DDu~+1\b[E";
      o[39] = "O\u001c\"<.+O\n!f^r\u0012\u001dyf2@@_#0^~\u0002[ws9iE\u0000a\u0001";
      o[40] = "J\f5G\u0018+@@`E(&GZaFA*~TaVEL\u0019\u0000iU\u00182@Th\u0011(";
      o[41] = "i\u0016\u007fd\";;\u0007&y\u001c:\u0003Vv6yai\u0016vzfQ";
      o[42] = ";Wt\u0010\u00182y\\qV`ad^~\u0002708\n n\u000bu<C`\u0001\u00111;P";
      o[43] = "I4V2@\u001c\u000e/\u0011>)Nw)\u0010nNHJ:\u001fo\u0012'\u001bzBdF\u001a\buC8)";
      o[44] = "(\u0012\b_oi\u007fKCQ\u001dbE\u0016\u0005U-v!\u0010\u0001Jf\u000b";
      o[45] = "c+!%z5d){gGnk+\u0015q#r`Wz)vj==:):u\r";
      o[46] = "_KnP,\n\nWhTR\u0006QBc\u0000\u0005Q\u000f\u0015;ll\f^Q\u007fQ.\u0007[\u0017";
      o[47] = "(Zy\u0007\u0001\u0019q\u001eeE`\u001b,\u0001iG>\u001c,\u001bm;\u0000\u0017%_n\n\u000b\u000e\"\u000f\u0000";
      o[48] = "d\u0015m++O+I3rUDYJr-<Ni\u0017rs>-bFk +_hBf.U";
      o[49] = "\u001aYh\u0013&\\\b@*\u0015\u0016TxRfM\u007fXH\u000ff\u0013};A\rzW&E\u0018Y{\u0013\u0016";
      o[50] = "-p#\u0011gDvmbN\u0002\u001b/{xGUJq' +a\u0013q,y\u001a:\u000e0s";
      o[51] = ".\u0002\u001ccyN{\u001e\u001ag\u0007I,\u001a\u00158k{{\\Ko<,}_\b'>N=\f\u0015-\u0007";
      o[52] = "9Z\u0018\u001aP\u001b.\u001dC\f\"\u0019=[B\u0013N+m\u001b\u0019E\"Ma\u0016GDH\raZXt";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1505003035573036L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1505003035573036L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1505003035573036L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 199;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 231;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 203;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 255;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 68;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 99;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 199;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 231;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 203;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/et_C0256",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/et" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
