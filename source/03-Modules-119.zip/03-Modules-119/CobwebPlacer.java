package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.client.modules.state.CobwebPlacementTask;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.SlotReservation;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.client.modules.state.CobwebPlacementResult;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.management.PacketQueueResult;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

public class CobwebPlacer extends Module implements RotationSource {
   private static final double a = 0.08;
   private static final double c = 0.91;
   private static final double d = 0.98;
   private static final double e = 0.999;
   private ModeSetting f;
   private FloatSetting g;
   private MinMaxSetting h;
   private IntSetting i;
   private BooleanSetting j;
   private IntSetting k;
   private BooleanSetting l;
   private ModeSetting m;
   private IntSetting n;
   private ModeSetting o;
   private BooleanSetting p;
   private BooleanSetting q;
   private ModeSetting r;
   private IntSetting s;
   private BooleanSetting t;
   private ColorSetting u;
   private ElapsedTimer v;
   private int w;
   private Integer x;
   private Vec3d y;
   private UUID z;
   private int A;
   private int B;
   private int C;
   private int D;
   private boolean E;
   private boolean F;
   private Object G;
   private static final long H = 12023629169224L;
   private static final String[] I;
   private static final String[] J;
   private static final Map K = new HashMap(13);
   private static final long[] L;
   private static final Integer[] M;
   private static final Map N;
   private static final Object[] O = new Object[252];
   private static final String[] P = new String[252];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;

   public CobwebPlacer() {
      super();
      long var10001 = 37584296110536L ^ 73823394356961L;
      var10001 = 37584296110536L ^ 6220771824170L;
      var10001 = 37584296110536L ^ 84349840734732L;
      var10001 = 37584296110536L ^ 126373205582436L;

      this.v = new ElapsedTimer(106698256430889L);
      this.w = 0;
      this.x = null;
      this.y = null;
      this.z = null;
      this.A = 0;
      this.B = -1;
      this.C = -1;
      this.D = -1;
      this.E = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.F = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.G = null;
      BooleanSetting var10000 = this.l;
      Object[] var12 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var11 = var10000;
      var11.aReturningBooleanSetting(var12);
      IntSetting var17 = this.n;
      Object[] var14 = new Object[]{invokeBinding2(this), 43459238656994L};
      IntSetting var13 = var17;
      var13.aReturningIntSetting(var14);
      ModeSetting var18 = this.m;
      Object[] var16 = new Object[]{invokeBinding3(this), 121607650890692L};
      ModeSetting var15 = var18;
      var15.aReturningModeSetting(var16);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      short var10000 = 10840;
      long var2 = (Long)var1[0];
      long var10001 = 1849557078583457945L ^ var2;
      ModeSetting var4 = this.f;
      Object var6 = var4.aReturningObject();
      String var5 = "Auto";
      return var5.equals(var6);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var6;
      label27: {
         long var4;
         CobwebPlacer var25;
         label29: {
            long var2 = (Long)var1[0];
            var4 = var2 ^ 130407746063613L;
            var6 = var2 ^ 38266410274184L;
            this.w = 0;
            this.x = null;
            this.y = null;
            this.z = null;
            int var10000 = Event.bReturningInt();
            this.A = 0;
            int var8 = var10000;
            int var27 = var8;
            CobwebPlacer var26 = this;
            Object var24 = var26;
            CobwebPlacer var21 = var26;
            if (var27 == 0) {
               boolean var28 = var21.E;
               if (!var28) {
                  Object[] var11 = new Object[]{var4};
                  CobwebPlacer var10 = this;
                  var10.p(var11);
                  int var29 = var8;
                  if (var29 == 0) {
                     break label27;
                  }
               }

               int var31 = var8;
               CobwebPlacer var30 = this;
               var25 = var30;
               CobwebPlacer var22 = var30;
               if (var31 != 0) {
                  break label29;
               }

               CobwebPlacer var32 = var22;
               CobwebPlacer var23 = var32;
               Object var33 = var23.G;
               var24 = var33;
            }

            MinecraftClient var15 = b;
            ClientWorld var35 = var15.world;
            Object var34 = var24;
            if (var34 == var35) {
               break label27;
            }

            CobwebPlacer var36 = this;
            var25 = var36;
         }

         Object[] var18 = new Object[]{var4};
         CobwebPlacer var17 = var25;
         var17.p(var18);
      }

      RotationManager var37 = Prestige.o;
      Object[] var20 = new Object[]{this, var6};
      RotationManager var19 = var37;
      var19.dReturningVoid(var20);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 99940649060138L;
      Object[] var9 = new Object[]{var6};
      CobwebPlacer var8 = this;
      var8.nReturningVoid(var9);
      this.w = 0;
      this.x = null;
      this.y = null;
      this.z = null;
      this.A = 0;
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var4};
      RotationManager var10 = var10000;
      var10.eReturningVoid(var11);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 74226941936115L ^ 54280070166955L;
      var10001 = 74226941936115L ^ 81081519145430L;
      var10001 = 74226941936115L ^ 24687003790508L;
      var10001 = 74226941936115L ^ 121498058049276L;
      var10001 = 74226941936115L ^ 2706367054981L;
      var10001 = 74226941936115L ^ 57805252139912L;
      var10001 = 74226941936115L ^ 132620044907434L;
      var10001 = 74226941936115L ^ 16134182111508L;
      int var20 = Event.bReturningInt();
      ModeSetting var23 = this.f;
      String var10000 = (String)var23.aReturningObject();
      String var25 = "Auto";
      String var24 = var10000;
      boolean var120 = var24.equals(var25);
      if (!var120) {
         int var122 = var20;
         MinecraftClient var121 = b;
         MinecraftClient var101 = var121;
         MinecraftClient var100 = var121;
         if (var122 == 0) {
            MinecraftClient var27 = var100;
            Screen var123 = var27.currentScreen;
            if (var123 != null) {
               return;
            }

            MinecraftClient var124 = b;
            var101 = var124;
         }

         MinecraftClient var30 = var101;
         boolean var166 = var30.isWindowFocused();
         int var126 = var20;
         boolean var125 = var166;
         boolean var103 = var125;
         boolean var102 = var125;
         if (var126 == 0) {
            boolean var127 = var102;
            if (!var127) {
               return;
            }

            MinecraftClient var32 = b;
            ClientPlayerEntity var33 = var32.player;
            boolean var128 = var33.isUsingItem();
            var103 = var128;
         }

         int var130 = var20;
         boolean var129 = var103;
         boolean var105 = var129;
         boolean var104 = var129;
         if (var130 == 0) {
            boolean var131 = var104;
            if (var131) {
               return;
            }

            RotationManager var167 = Prestige.o;
            Object[] var37 = new Object[0];
            RotationManager var36 = var167;
            var105 = var36.fReturningBoolean(var37);
         }

         int var133 = var20;
         boolean var132 = var105;
         boolean var107 = var132;
         boolean var106 = var132;
         if (var133 == 0) {
            boolean var134 = var106;
            if (var134) {
               return;
            }

            ElapsedTimer var168 = this.v;
            Object[] var40 = new Object[]{this.h, 130913203968635L};
            ElapsedTimer var39 = var168;
            var107 = var39.bReturningBoolean(var40);
         }

         boolean var135 = var107;
         if (var135) {
            MinecraftClient var41 = b;
            HitResult var22 = var41.crosshairTarget;
            int var136 = var20;
            if (var136 == 0) {
               boolean var137 = var22 instanceof BlockHitResult;
               if (var137) {
                  BlockHitResult var21 = (BlockHitResult)var22;
                  int var138 = var20;
                  if (var138 == 0) {
                     MinecraftClient var46 = b;
                     ClientWorld var169 = var46.world;
                     BlockHitResult var47 = var21;
                     BlockPos var49 = var47.getBlockPos();
                     ClientWorld var48 = var169;
                     BlockState var50 = var48.getBlockState(var49);
                     byte var170 = ((byte)((var50.isReplaceable()) ? 1 : 0));
                     int var140 = var20;
                     byte var139 = var170;
                     byte var109 = var139;
                     byte var108 = var139;
                     if (var140 == 0) {
                        byte var141 = var108;
                        if (var141 != 0) {
                           Object[] var53 = new Object[]{126290808879192L};
                           CobwebPlacer var52 = this;
                           var52.aReturningVoid(var53);
                           return;
                        }

                        BooleanSetting var55 = this.l;
                        Boolean var56 = (Boolean)var55.aReturningObject();
                        var109 = ((byte)(((java.lang.Boolean)(var56)).booleanValue() ? 1 : 0));
                     }

                     int var143 = var20;
                     byte var142 = var109;
                     int var111 = var142;
                     byte var110 = var142;
                     if (var143 == 0) {
                        byte var144 = var110;
                        if (var144 != 0) {
                           Block var171 = Blocks.COBWEB;
                           Runnable var184 = invokeBinding4(var21);
                           BooleanSetting var58 = this.l;
                           Boolean var59 = (Boolean)var58.aReturningObject();
                           boolean var10002 = var59;
                           Object[] var10005 = new Object[]{null, null, null, 94496437480799L};
                           var10005[2] = var10002;
                           var10005[1] = var184;
                           var10005[0] = var171;
                           Object[] var60 = var10005;
                           boolean var145 = InventoryUtil.kReturningBoolean(var60);
                           if (!var145) {
                              return;
                           }

                           Object[] var63 = new Object[]{126290808879192L};
                           CobwebPlacer var62 = this;
                           var62.aReturningVoid(var63);
                           int var146 = var20;
                           if (var146 == 0) {
                              return;
                           }
                        }

                        int var147 = this.w;
                        var111 = var147;
                     }

                     label108: {
                        label107: {
                           label148: {
                              int var149 = var20;
                              int var148 = var111;
                              int var113 = var148;
                              int var112 = var148;
                              if (var149 == 0) {
                                 int var150 = var112;
                                 switch (var150) {
                                    case 0:
                                       Object[] var67 = new Object[]{49487520630543L};
                                       int var68 = InventoryUtil.aReturningInt(var67);
                                       this.x = var68;
                                       int var151 = var20;
                                       if (var151 != 0) {
                                          break label148;
                                       }

                                       Object[] var70 = new Object[]{Blocks.COBWEB, 64992723038809L};
                                       byte var152 = ((byte)((InventoryUtil.iReturningVoid(var70)) ? 1 : 0));
                                       var113 = var152;
                                       break;
                                    case 1:
                                       break label107;
                                    case 2:
                                       break label108;
                                    default:
                                       return;
                                 }
                              }

                              int var153 = var113;
                              if (var153 == 0) {
                                 Object[] var73 = new Object[]{126290808879192L};
                                 CobwebPlacer var72 = this;
                                 var72.aReturningVoid(var73);
                                 return;
                              }

                              Object[] var76 = new Object[]{84863297276135L};
                              CobwebPlacer var75 = this;
                              var75.s(var76);
                           }

                           int var154 = var20;
                           if (var154 == 0) {
                              return;
                           }
                        }

                        Object[] var77 = new Object[]{var21, 11253043183653L};
                        ItemUseUtil.aReturningBoolean(var77);
                        Object[] var79 = new Object[]{84863297276135L};
                        CobwebPlacer var78 = this;
                        var78.s(var79);
                        int var155 = var20;
                        if (var155 == 0) {
                           return;
                        }
                     }

                     CobwebPlacer var119;
                     label89: {
                        label88: {
                           ModeSetting var81 = this.m;
                           var10000 = (String)var81.aReturningObject();
                           String var83 = "Slot";
                           String var82 = var10000;
                           boolean var173 = var82.equals(var83);
                           int var157 = var20;
                           boolean var156 = var173;
                           boolean var118 = var156;
                           boolean var114 = var156;
                           if (var157 == 0) {
                              boolean var158 = var114;
                              boolean var115 = var158;
                              boolean var159 = var115;
                              if (var159) {
                                 IntSetting var86 = this.n;
                                 Integer var87 = (Integer)var86.aReturningObject();
                                 int var174 = var87 - 1;
                                 Object[] var10003 = new Object[]{null, 72518082610550L};
                                 var10003[0] = var174;
                                 Object[] var88 = var10003;
                                 InventoryUtil.aReturningVoid(var88);
                                 int var160 = var20;
                                 if (var160 == 0) {
                                    break label88;
                                 }
                              }

                              int var162 = var20;
                              CobwebPlacer var161 = this;
                              var119 = var161;
                              CobwebPlacer var116 = var161;
                              if (var162 != 0) {
                                 break label89;
                              }

                              CobwebPlacer var163 = var116;
                              CobwebPlacer var117 = var163;
                              ModeSetting var91 = var117.m;
                              var10000 = (String)var91.aReturningObject();
                              String var93 = "Original";
                              String var92 = var10000;
                              boolean var164 = var92.equals(var93);
                              var118 = var164;
                           }

                           boolean var165 = var118;
                           if (var165) {
                              Integer var95 = this.x;
                              int var176 = var95;
                              Object[] var185 = new Object[]{null, 72518082610550L};
                              var185[0] = var176;
                              Object[] var96 = var185;
                              InventoryUtil.aReturningVoid(var96);
                           }
                        }

                        var119 = this;
                     }

                     Object[] var99 = new Object[]{126290808879192L};
                     CobwebPlacer var98 = var119;
                     var98.aReturningVoid(var99);
                     return;
                  }
               }

               Object[] var44 = new Object[]{126290808879192L};
               CobwebPlacer var43 = this;
               var43.aReturningVoid(var44);
            }
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 88564170757952L;
      long var6 = var2 ^ 2975697362989L;
      long var8 = var2 ^ 105250408331843L;
      long var10 = var2 ^ 65762800970131L;
      long var12 = var2 ^ 40935945515753L;
      long var14 = var2 ^ 80225105446133L;
      long var16 = var2 ^ 20582613785184L;
      long var18 = var2 ^ 59641449638428L;
      long var20 = var2 ^ 136327255761257L;
      long var22 = var2 ^ 82878281429531L;
      long var24 = var2 ^ 138426539507609L;
      long var26 = var2 ^ 106287752917474L;
      long var28 = var2 ^ 95577660162816L;
      long var30 = var2 ^ 87666872358447L;
      long var32 = var2 ^ 29159961624672L;
      long var34 = var2 ^ 55073399657995L;
      long var36 = var2 ^ 77379818547405L;
      long var38 = var2 ^ 96421272380508L;
      long var40 = var2 ^ 19182256418671L;
      long var42 = var2 ^ 83347268631053L;
      long var44 = var2 ^ 40758141153873L;
      long var46 = var2 ^ 134366226930033L;
      long var48 = var2 ^ 125483130411561L;
      long var50 = var2 ^ 27958948442010L;
      int var52 = Event.bReturningInt();
      ModeSetting var92 = this.f;
      String var10000 = (String)var92.aReturningObject();
      short var10001 = 10840;
      long var10002 = 1849470361296403139L ^ var2;
      String var94 = "Auto";
      String var93 = var10000;
      boolean var642 = var93.equals(var94);
      int var441 = var52;
      boolean var440 = var642;
      boolean var345 = var440;
      if (var441 == 0) {
         boolean var442 = var345;
         if (var442) {
            label528: {
               int var445 = var52;
               MinecraftClient var444 = b;
               MinecraftClient var348 = var444;
               MinecraftClient var347 = var444;
               if (var445 == 0) {
                  MinecraftClient var101 = var347;
                  ClientPlayerEntity var446 = var101.player;
                  if (var446 == null) {
                     break label528;
                  }

                  MinecraftClient var447 = b;
                  var348 = var447;
               }

               MinecraftClient var104 = var348;
               ClientWorld var448 = var104.world;
               if (var448 != null) {
                  CobwebPlacer var358;
                  label563: {
                     int var359;
                     int var450 = var52;
                     int var449 = this.B;
                     var359 = var449;
                     int var349 = var449;
                     label504:
                     if (var450 == 0) {
                        label518: {
                           // int var451 = var349;
                           if (var451 != var452) {
                              int var454 = var52;
                              CobwebPlacer var453 = this;
                              var358 = var453;
                              CobwebPlacer var350 = var453;
                              if (var454 != 0) {
                                 break label563;
                              }

                              CobwebPlacer var455 = var350;
                              CobwebPlacer var351 = var455;
                              MinecraftClient var110 = b;
                              ClientWorld var457 = var110.world;
                              Object var456 = var351.G;
                              if (var456 != var457) {
                                 break label518;
                              }

                              int var459 = var52;
                              CobwebPlacer var458 = this;
                              var358 = var458;
                              CobwebPlacer var352 = var458;
                              if (var459 != 0) {
                                 break label563;
                              }

                              CobwebPlacer var460 = var352;
                              CobwebPlacer var353 = var460;
                              Object[] var113 = new Object[]{var353};
                              boolean var461 = SlotReservation.aReturningBoolean(var113);
                              if (!var461) {
                                 break label518;
                              }

                              int var463 = var52;
                              int var462 = this.C;
                              var359 = var462;
                              int var354 = var462;
                              if (var463 != 0) {
                                 break label504;
                              }

                              int var464 = var354;
                              int var355 = var464;
                              // int var465 = var355;
                              if (var465 != var466) {
                                 Object[] var117 = new Object[]{var40};
                                 int var643 = InventoryUtil.aReturningInt(var117);
                                 int var468 = var52;
                                 int var467 = var643;
                                 var359 = var467;
                                 int var356 = var467;
                                 if (var468 != 0) {
                                    break label504;
                                 }

                                 int var469 = var356;
                                 int var357 = var469;
                                 int var471 = this.C;
                                 int var470 = var357;
                                 if (var470 != var471) {
                                    break label518;
                                 }
                              }
                           }

                           Object[] var124 = new Object[]{var8};
                           CobwebPlacer var123 = this;
                           var359 = (((var123.dReturningBoolean(var124)) ? 1 : 0));
                           break label504;
                        }

                        CobwebPlacer var472 = this;
                        var358 = var472;
                        break label563;
                     }

                     int var473 = var359;
                     if (var473 != 0) {
                        return null;
                     }

                     label564: {
                        int var475 = var52;
                        MinecraftClient var474 = b;
                        MinecraftClient var361 = var474;
                        MinecraftClient var360 = var474;
                        if (var475 == 0) {
                           MinecraftClient var126 = var360;
                           Screen var476 = var126.currentScreen;
                           if (var476 != null) {
                              break label564;
                           }

                           MinecraftClient var477 = b;
                           var361 = var477;
                        }

                        MinecraftClient var129 = var361;
                        boolean var644 = var129.isWindowFocused();
                        int var479 = var52;
                        boolean var478 = var644;
                        boolean var363 = var478;
                        boolean var362 = var478;
                        if (var479 == 0) {
                           boolean var480 = var362;
                           if (!var480) {
                              break label564;
                           }

                           MinecraftClient var131 = b;
                           ClientPlayerEntity var132 = var131.player;
                           boolean var481 = var132.isUsingItem();
                           var363 = var481;
                        }

                        int var483 = var52;
                        boolean var482 = var363;
                        boolean var365 = var482;
                        boolean var364 = var482;
                        if (var483 == 0) {
                           boolean var484 = var364;
                           if (var484) {
                              break label564;
                           }

                           RotationManager var645 = Prestige.o;
                           Object[] var139 = new Object[0];
                           RotationManager var138 = var645;
                           var365 = var138.fReturningBoolean(var139);
                        }

                        int var486 = var52;
                        boolean var485 = var365;
                        boolean var367 = var485;
                        boolean var366 = var485;
                        if (var486 == 0) {
                           boolean var487 = var366;
                           if (var487) {
                              return null;
                           }

                           ElapsedTimer var646 = this.v;
                           Object[] var143 = new Object[]{this.h, var22};
                           ElapsedTimer var142 = var646;
                           var367 = var142.bReturningBoolean(var143);
                        }

                        boolean var488 = var367;
                        if (!var488) {
                           return null;
                        }

                        Object[] var145 = new Object[]{var46};
                        PlayerEntity var53 = EntityUtil.aReturningPlayerEntity(var145);
                        int var489 = var52;
                        if (var489 == 0) {
                           PlayerEntity var490 = var53;
                           label473:
                           if (var490 != null) {
                              MinecraftClient var147 = b;
                              PlayerEntity var149 = var53;
                              ClientPlayerEntity var148 = var147.player;
                              float var647 = var148.distanceTo((Entity)var149);
                              FloatSetting var150 = this.g;
                              Float var151 = (Float)var150.aReturningObject();
                              float var675;
                              int var648 = (var675 = var647 - var151) == 0.0F ? 0 : (var675 < 0.0F ? -1 : 1);
                              int var492 = var52;
                              int var491 = var648;
                              int var370 = var491;
                              int var368 = var491;
                              if (var492 == 0) {
                                 int var493 = var368;
                                 int var369 = var493;
                                 int var494 = var369;
                                 if (var494 > 0) {
                                    break label473;
                                 }

                                 Object[] var157 = new Object[]{var53, var20};
                                 var370 = (((BlockUtil.aReturningBoolean(var157)) ? 1 : 0));
                              }

                              int var495 = var370;
                              if (var495 != 0) {
                                 this.y = null;
                                 Object[] var159 = new Object[]{var28};
                                 CobwebPlacer var158 = this;
                                 return var158.bReturningdx_C0210(var159);
                              }

                              Object[] var161 = new Object[]{Blocks.COBWEB, var4};
                              Integer var54 = InventoryUtil.dReturningBoxedInteger(var161);
                              int var55 = -1;
                              int var497 = var52;
                              Integer var496 = var54;
                              Integer var374 = var496;
                              Integer var371 = var496;
                              if (var497 == 0) {
                                 Integer var498 = var371;
                                 if (var498 == null) {
                                    BooleanSetting var163 = this.p;
                                    Boolean var164 = (Boolean)var163.aReturningObject();
                                    boolean var499 = var164;
                                    label456:
                                    if (var499) {
                                       Item var649 = Items.COBWEB;
                                       Object[] var10004 = new Object[]{null, null, var6};
                                       var10004[1] = false;
                                       var10004[0] = var649;
                                       Object[] var166 = var10004;
                                       List var56 = InventoryUtil.bReturningList(var166);
                                       List var167 = var56;
                                       byte var650 = ((byte)((var167.isEmpty()) ? 1 : 0));
                                       int var501 = var52;
                                       byte var500 = var650;
                                       int var373 = var500;
                                       byte var372 = var500;
                                       if (var501 == 0) {
                                          byte var502 = var372;
                                          if (var502 != 0) {
                                             break label456;
                                          }

                                          List var169 = var56;
                                          Integer var171 = (Integer)var169.get(0);
                                          int var503 = var171;
                                          var373 = var503;
                                       }

                                       var55 = var373;
                                    }
                                 }

                                 var374 = var54;
                              }

                              int var379;
                              label449: {
                                 int var505 = var52;
                                 Integer var504 = var374;
                                 Object var378 = var504;
                                 Integer var375 = var504;
                                 if (var505 == 0) {
                                    Integer var506 = var375;
                                    if (var506 == null) {
                                       int var508 = var52;
                                       int var507 = var55;
                                       var379 = var507;
                                       int var376 = var507;
                                       if (var508 != 0) {
                                          break label449;
                                       }

                                       int var509 = var376;
                                       int var377 = var509;
                                       // int var510 = var377;
                                       if (var510 == var511) {
                                          this.y = null;
                                          Object[] var177 = new Object[]{var28};
                                          CobwebPlacer var176 = this;
                                          return var176.bReturningdx_C0210(var177);
                                       }
                                    }

                                    ModeSetting var179 = this.o;
                                    var378 = var179.aReturningObject();
                                 }

                                 var10000 = (String)var378;
                                 var10001 = 6400;
                                 var10002 = 3613043546833996185L ^ var2;
                                 String var181 = "None";
                                 String var180 = var10000;
                                 var379 = (((var180.equals(var181)) ? 1 : 0));
                              }

                              label541: {
                                 Vec3d var57;
                                 Vec3d var400;
                                 int var638;
                                 label440: {
                                    label439: {
                                       label438: {
                                          CobwebPlacer var399;
                                          label542: {
                                             int var386;
                                             var638 = var379;
                                             int var513 = var52;
                                             int var512 = var638;
                                             var386 = var512;
                                             int var380 = var512;
                                             label436:
                                             if (var513 == 0) {
                                                int var514 = var380;
                                                if (var514 != 0) {
                                                   Object[] var183 = new Object[]{Items.COBWEB, var10};
                                                   byte var652 = ((byte)((InventoryUtil.lReturningBoolean(var183)) ? 1 : 0));
                                                   int var516 = var52;
                                                   byte var515 = var652;
                                                   var386 = var515;
                                                   byte var381 = var515;
                                                   if (var516 != 0) {
                                                      break label436;
                                                   }

                                                   byte var517 = var381;
                                                   byte var382 = var517;
                                                   byte var518 = var382;
                                                   if (var518 == 0) {
                                                      int var520 = var52;
                                                      int var519 = var55;
                                                      var386 = var519;
                                                      int var383 = var519;
                                                      if (var520 != 0) {
                                                         break label436;
                                                      }

                                                      int var521 = var383;
                                                      int var384 = var521;
                                                      // int var522 = var384;
                                                      if (var522 == var523) {
                                                         this.y = null;
                                                         Object[] var189 = new Object[]{var28};
                                                         CobwebPlacer var188 = this;
                                                         return var188.bReturningdx_C0210(var189);
                                                      }
                                                   }
                                                }

                                                int var525 = var52;
                                                CobwebPlacer var524 = this;
                                                var399 = var524;
                                                CobwebPlacer var385 = var524;
                                                if (var525 != 0) {
                                                   break label542;
                                                }

                                                BooleanSetting var191 = var385.j;
                                                Boolean var192 = (Boolean)var191.aReturningObject();
                                                byte var526 = ((byte)(((java.lang.Boolean)(var192)).booleanValue() ? 1 : 0));
                                                var386 = var526;
                                             }

                                             int var527 = var386;
                                             if (var527 != 0) {
                                                CobwebPlacer var396;
                                                label545: {
                                                   int var395;
                                                   label546: {
                                                      label419: {
                                                         CobwebPlacer var393;
                                                         int var529 = var52;
                                                         CobwebPlacer var528 = this;
                                                         var393 = var528;
                                                         CobwebPlacer var387 = var528;
                                                         label418:
                                                         if (var529 == 0) {
                                                            CobwebPlacer var530 = var387;
                                                            CobwebPlacer var388 = var530;
                                                            UUID var531 = var388.z;
                                                            if (var531 != null) {
                                                               int var533 = var52;
                                                               CobwebPlacer var532 = this;
                                                               var393 = var532;
                                                               CobwebPlacer var389 = var532;
                                                               if (var533 != 0) {
                                                                  break label418;
                                                               }

                                                               CobwebPlacer var534 = var389;
                                                               CobwebPlacer var390 = var534;
                                                               UUID var653 = var390.z;
                                                               PlayerEntity var197 = var53;
                                                               UUID var199 = var197.getUuid();
                                                               UUID var198 = var653;
                                                               boolean var535 = var198.equals(var199);
                                                               if (var535) {
                                                                  Object[] var201 = new Object[]{var53, var48};
                                                                  double var676;
                                                                  int var654 = (var676 = RaycastUtil.aReturningDouble(var201) - 0.3F) == 0.0
                                                                     ? 0
                                                                     : (var676 < 0.0 ? -1 : 1);
                                                                  int var537 = var52;
                                                                  int var536 = var654;
                                                                  var395 = var536;
                                                                  int var391 = var536;
                                                                  if (var537 != 0) {
                                                                     break label546;
                                                                  }

                                                                  int var538 = var391;
                                                                  int var392 = var538;
                                                                  int var539 = var392;
                                                                  if (var539 >= 0) {
                                                                     break label419;
                                                                  }
                                                               }
                                                            }

                                                            PlayerEntity var204 = var53;
                                                            this.z = var204.getUuid();
                                                            CobwebPlacer var540 = this;
                                                            var393 = var540;
                                                         }

                                                         var393.A = 0;
                                                      }

                                                      int var542 = var52;
                                                      CobwebPlacer var541 = this;
                                                      var396 = var541;
                                                      CobwebPlacer var394 = var541;
                                                      if (var542 != 0) {
                                                         break label545;
                                                      }

                                                      int var543 = var394.A;
                                                      var395 = var543;
                                                   }

                                                   IntSetting var207 = this.k;
                                                   Integer var208 = (Integer)var207.aReturningObject();
                                                   int var545 = var208;
                                                   int var544 = var395;
                                                   if (var544 >= var545) {
                                                      this.y = null;
                                                      Object[] var210 = new Object[]{var28};
                                                      CobwebPlacer var209 = this;
                                                      return var209.bReturningdx_C0210(var210);
                                                   }

                                                   var396 = this;
                                                }

                                                Object[] var213 = new Object[]{var53, var44};
                                                CobwebPlacer var212 = var396;
                                                var57 = var212.bReturningVec3d(var213);
                                                int var546 = var52;
                                                if (var546 != 0) {
                                                   break label541;
                                                }

                                                Vec3d var547 = var57;
                                                if (var547 == null) {
                                                   break label439;
                                                }

                                                int var549 = var52;
                                                Vec3d var548 = var57;
                                                var400 = var548;
                                                Vec3d var397 = var548;
                                                if (var549 != 0) {
                                                   break label440;
                                                }

                                                Vec3d var550 = var397;
                                                Vec3d var398 = var550;
                                                Vec3d var216 = var398;
                                                double var655 = var216.y;
                                                Object[] var217 = new Object[]{var53, var42};
                                                Vec3d var218 = RaycastUtil.aReturningVec3d(var217);
                                                double var677;
                                                int var551 = (var677 = var655 - (var218.y - 0.5)) == 0.0 ? 0 : (var677 < 0.0 ? -1 : 1);
                                                if (var551 >= 0) {
                                                   break label439;
                                                }
                                                break label438;
                                             }

                                             var399 = this;
                                          }

                                          Object[] var224 = new Object[]{var53, var14};
                                          CobwebPlacer var223 = var399;
                                          var57 = var223.aReturningVec3d(var224);
                                       }

                                       var400 = var57;
                                       break label440;
                                    }

                                    this.y = null;
                                    break label541;
                                 }

                                 int var553 = var52;
                                 Vec3d var552 = var400;
                                 Vec3d var402 = var552;
                                 Vec3d var401 = var552;
                                 if (var553 == 0) {
                                    Vec3d var554 = var401;
                                    if (var554 == null) {
                                       Object[] var227 = new Object[]{var28};
                                       CobwebPlacer var226 = this;
                                       return var226.bReturningdx_C0210(var227);
                                    }

                                    this.y = var57;
                                    var402 = var57;
                                 }

                                 BlockPos[] var405;
                                 label388: {
                                    Vec3d var229 = var402;
                                    Vec3d var230 = var57;
                                    Vec3d var231 = var57;
                                    double var236 = var231.z;
                                    double var234 = var230.y;
                                    double var232 = var229.x;
                                    BlockPos var58 = BlockPos.ofFloored(var232, var234, var236);
                                    BooleanSetting var238 = this.q;
                                    Boolean var239 = (Boolean)var238.aReturningObject();
                                    byte var656 = ((byte)(((java.lang.Boolean)(var239)).booleanValue() ? 1 : 0));
                                    int var556 = var52;
                                    byte var555 = var656;
                                    byte var404 = var555;
                                    byte var403 = var555;
                                    if (var556 == 0) {
                                       byte var557 = var403;
                                       if (var557 != 0) {
                                          BlockPos[] var658 = new BlockPos[]{var58, null};
                                          BlockPos var241 = var58;
                                          var658[1] = var241.up();
                                          BlockPos[] var558 = var658;
                                          var405 = var558;
                                          break label388;
                                       }

                                       var404 = 1;
                                    }

                                    BlockPos[] var657 = new BlockPos[var404];
                                    var657[0] = var58;
                                    var405 = var657;
                                 }

                                 BlockPos[] var59 = var405;
                                 Rotation var60 = null;
                                 BlockHitResult var61 = null;
                                 double var62 = Double.MAX_VALUE;
                                 Rotation var64 = null;
                                 MinecraftClient var243 = b;
                                 ClientPlayerEntity var244 = var243.player;
                                 Vec3d var65 = var244.getEyePos();
                                 Object[] var245 = new Object[]{var38};
                                 double var66 = ItemUseUtil.bReturningFloat(var245);
                                 MinecraftClient var246 = b;
                                 ClientPlayerEntity var247 = var246.player;
                                 float var68 = var247.getYaw();
                                 MinecraftClient var248 = b;
                                 ClientPlayerEntity var249 = var248.player;
                                 float var69 = var249.getPitch();
                                 MinecraftClient var250 = b;
                                 ClientPlayerEntity var251 = var250.player;
                                 BlockPos var70 = var251.getBlockPos();
                                 BlockPos var252 = var70;
                                 BlockPos var71 = var252.up();
                                 BlockPos[] var72 = var59;
                                 int var73 = var72.length;
                                 label382:
                                 while (true) {
                                    int var406 = var74;

                                    byte var428;
                                    label379:
                                    while (true) {
                                       int var560 = var73;
                                       int var559 = var406;
                                       if (var559 < var560) {
                                          BlockPos var75 = var72[var74];
                                          int var561 = var52;
                                          if (var561 == 0) {
                                             BlockPos var254 = var70;
                                             BlockPos var253 = var75;
                                             byte var659 = ((byte)((var253.equals(var254)) ? 1 : 0));
                                             int var563 = var52;
                                             byte var562 = var659;
                                             var428 = var562;
                                             byte var407 = var562;
                                             if (var563 != 0) {
                                                break;
                                             }

                                             byte var564 = var407;
                                             byte var408 = var564;
                                             byte var565 = var408;
                                             if (var565 == 0) {
                                                BlockPos var258 = var71;
                                                BlockPos var257 = var75;
                                                boolean var566 = var257.equals(var258);
                                                label328:
                                                if (!var566) {
                                                   MinecraftClient var261 = b;
                                                   BlockPos var263 = var75;
                                                   ClientWorld var262 = var261.world;
                                                   BlockState var76 = var262.getBlockState(var263);
                                                   BlockState var264 = var76;
                                                   boolean var660 = var264.isReplaceable();
                                                   int var568 = var52;
                                                   boolean var567 = var660;
                                                   boolean var410 = var567;
                                                   boolean var409 = var567;
                                                   if (var568 == 0) {
                                                      boolean var569 = var409;
                                                      if (!var569) {
                                                         break label328;
                                                      }

                                                      BlockState var266 = var76;
                                                      FluidState var267 = var266.getFluidState();
                                                      var410 = var267.isEmpty();
                                                   }

                                                   boolean var570 = var410;
                                                   if (var570) {
                                                      Direction[] var77 = Direction.values();
                                                      int var78 = var77.length;
                                                      int var602;
                                                      do {
                                                         int var572 = var78;
                                                         int var571 = var79;
                                                         if (var571 >= var572) {
                                                            break;
                                                         }

                                                         Direction var80 = var77[var79];
                                                         Direction var269 = var80;
                                                         BlockPos var268 = var75;
                                                         BlockPos var81 = var268.offset(var269);
                                                         MinecraftClient var270 = b;
                                                         BlockPos var272 = var81;
                                                         ClientWorld var271 = var270.world;
                                                         BlockState var82 = var271.getBlockState(var272);
                                                         BlockState var273 = var82;
                                                         byte var661 = ((byte)((var273.isAir()) ? 1 : 0));
                                                         int var574 = var52;
                                                         byte var573 = var661;
                                                         var406 = var573;
                                                         byte var411 = var573;
                                                         if (var574 != 0) {
                                                            continue label379;
                                                         }

                                                         label368: {
                                                            label552: {
                                                               int var576 = var52;
                                                               byte var575 = var411;
                                                               byte var413 = var575;
                                                               byte var412 = var575;
                                                               if (var576 == 0) {
                                                                  byte var577 = var412;
                                                                  if (var577 != 0) {
                                                                     break label552;
                                                                  }

                                                                  BlockState var275 = var82;
                                                                  var413 = ((byte)((var275.isReplaceable()) ? 1 : 0));
                                                               }

                                                               int var579 = var52;
                                                               byte var578 = var413;
                                                               byte var415 = var578;
                                                               byte var414 = var578;
                                                               if (var579 == 0) {
                                                                  byte var580 = var414;
                                                                  if (var580 != 0) {
                                                                     break label552;
                                                                  }

                                                                  BlockState var277 = var82;
                                                                  FluidState var278 = var277.getFluidState();
                                                                  var415 = ((byte)((var278.isEmpty()) ? 1 : 0));
                                                               }

                                                               byte var581 = var415;
                                                               if (var581 != 0) {
                                                                  Direction var279 = var80;
                                                                  Direction var83 = var279.getOpposite();
                                                                  BlockPos var280 = var81;
                                                                  double var670 = var280.getX() + 0.5;
                                                                  Direction var281 = var83;
                                                                  double var671 = var670 + var281.getOffsetX() * 0.5;
                                                                  BlockPos var282 = var81;
                                                                  double var10003 = var282.getY() + 0.5;
                                                                  Direction var283 = var83;
                                                                  var10003 += var283.getOffsetY() * 0.5;
                                                                  BlockPos var284 = var81;
                                                                  double var674 = var284.getZ() + 0.5;
                                                                  Direction var285 = var83;
                                                                  Vec3d var84 = new Vec3d(var671, var10003, var674 + var285.getOffsetZ() * 0.5);
                                                                  Vec3d var287 = var84;
                                                                  Vec3d var286 = var65;
                                                                  double var678;
                                                                  int var582 = (var678 = var286.distanceTo(var287) - var66) == 0.0
                                                                     ? 0
                                                                     : (var678 < 0.0 ? -1 : 1);
                                                                  label356:
                                                                  if (var582 <= 0) {
                                                                     RotationManager var662 = Prestige.o;
                                                                     Object[] var290 = new Object[]{var84, var36};
                                                                     RotationManager var289 = var662;
                                                                     Rotation var85 = var289.aReturningdx_C0210(var290);
                                                                     Object[] var292 = new Object[0];
                                                                     Rotation var291 = var85;
                                                                     float var663 = var291.aReturningFloat(var292) - var68;
                                                                     Object[] var673 = new Object[]{null, var24};
                                                                     var673[0] = var663;
                                                                     Object[] var293 = var673;
                                                                     float var86 = RotationUtil.bReturningFloat(var293);
                                                                     int var584 = var52;
                                                                     Rotation var583 = var85;
                                                                     Rotation var420 = var583;
                                                                     Rotation var416 = var583;
                                                                     if (var584 == 0) {
                                                                        Object[] var295 = new Object[0];
                                                                        Rotation var294 = var416;
                                                                        boolean var585 = var294.aReturningBoolean(var295);
                                                                        if (var585) {
                                                                           int var587 = var52;
                                                                           Rotation var586 = var64;
                                                                           Rotation var419 = var586;
                                                                           Rotation var417 = var586;
                                                                           if (var587 == 0) {
                                                                              Rotation var588 = var417;
                                                                              Rotation var418 = var588;
                                                                              Rotation var589 = var418;
                                                                              if (var589 != null) {
                                                                                 break label356;
                                                                              }

                                                                              var419 = var85;
                                                                           }

                                                                           var64 = var419;
                                                                           int var590 = var52;
                                                                           if (var590 == 0) {
                                                                              break label356;
                                                                           }
                                                                        }

                                                                        Rotation var591 = var85;
                                                                        var420 = var591;
                                                                     }

                                                                     Object[] var300 = new Object[]{var420, var18};
                                                                     HitResult var87 = RotationUtil.aReturningHitResult(var300);
                                                                     int var592 = var52;
                                                                     if (var592 != 0) {
                                                                        break label368;
                                                                     }

                                                                     boolean var593 = var87 instanceof BlockHitResult;
                                                                     label344:
                                                                     if (var593) {
                                                                        BlockHitResult var88 = (BlockHitResult)var87;
                                                                        int var595 = var52;
                                                                        BlockHitResult var594 = var88;
                                                                        BlockHitResult var422 = var594;
                                                                        BlockHitResult var421 = var594;
                                                                        if (var595 == 0) {
                                                                           BlockHitResult var302 = var421;
                                                                           BlockPos var664 = var302.getBlockPos();
                                                                           BlockPos var304 = var81;
                                                                           BlockPos var303 = var664;
                                                                           boolean var596 = var303.equals(var304);
                                                                           if (!var596) {
                                                                              break label344;
                                                                           }

                                                                           var422 = var88;
                                                                        }

                                                                        BlockHitResult var307 = var422;
                                                                        Direction var665 = var307.getSide();
                                                                        Direction var598 = var83;
                                                                        Direction var597 = var665;
                                                                        if (var597 == var598) {
                                                                           BlockHitResult var309 = var88;
                                                                           Vec3d var311 = var309.getPos();
                                                                           Vec3d var310 = var65;
                                                                           double var679;
                                                                           int var599 = (var679 = var310.distanceTo(var311) - var66) == 0.0
                                                                              ? 0
                                                                              : (var679 < 0.0 ? -1 : 1);
                                                                           if (var599 <= 0) {
                                                                              Object[] var314 = new Object[0];
                                                                              Rotation var313 = var85;
                                                                              float var89 = var313.bReturningFloat(var314) - var69;
                                                                              double var315 = var86 * var86 + var89 * var89;
                                                                              double var90 = Math.sqrt(var315);
                                                                              int var600 = var52;
                                                                              if (var600 != 0) {
                                                                                 break label368;
                                                                              }

                                                                              double var680;
                                                                              int var601 = (var680 = var90 - var62) == 0.0 ? 0 : (var680 < 0.0 ? -1 : 1);
                                                                              if (var601 < 0) {
                                                                                 var62 = var90;
                                                                                 var60 = var85;
                                                                                 var61 = var88;
                                                                              }
                                                                           }
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            }

                                                            var79++;
                                                         }

                                                         var602 = var52;
                                                      } while (var602 == 0);
                                                   }
                                                }
                                             }

                                             var74++;
                                          }

                                          int var603 = var52;
                                          if (var603 == 0) {
                                             continue label382;
                                          }
                                       }

                                       int var605 = var52;
                                       Rotation var604 = var60;
                                       Rotation var424 = var604;
                                       Rotation var423 = var604;
                                       if (var605 == 0) {
                                          Rotation var606 = var423;
                                          if (var606 != null) {
                                             BlockHitResult var611 = var61;
                                             if (var611 == null) {
                                                return var60;
                                             }

                                             Object[] var323 = new Object[]{Items.COBWEB, var10};
                                             var428 = ((byte)((InventoryUtil.lReturningBoolean(var323)) ? 1 : 0));
                                             break;
                                          }

                                          var424 = var64;
                                       }

                                       int var608 = var52;
                                       Rotation var607 = var424;
                                       Rotation var426 = var607;
                                       Rotation var425 = var607;
                                       if (var608 == 0) {
                                          Rotation var609 = var425;
                                          if (var609 == null) {
                                             Object[] var321 = new Object[]{var28};
                                             CobwebPlacer var320 = this;
                                             return var320.bReturningdx_C0210(var321);
                                          }

                                          var426 = var64;
                                       }

                                       return var426;
                                    }

                                    boolean var433;
                                    label299: {
                                       label554: {
                                          int var613 = var52;
                                          byte var612 = var428;
                                          int var430 = var612;
                                          byte var429 = var612;
                                          if (var613 == 0) {
                                             byte var614 = var429;
                                             if (var614 != 0) {
                                                break label554;
                                             }

                                             int var615 = this.B;
                                             var430 = var615;
                                          }

                                          int var617 = var52;
                                          int var616 = var430;
                                          int var432 = var616;
                                          int var431 = var616;
                                          if (var617 == 0) {
                                             // int var618 = var431;
                                             if (var618 != var619) {
                                                break label554;
                                             }

                                             int var620 = var638;
                                             var432 = var620;
                                          }

                                          int var621 = var432;
                                          if (var621 == 0) {
                                             Integer var622 = var54;
                                             if (var622 != null) {
                                                boolean var623 = true;
                                                var433 = var623;
                                                break label299;
                                             }
                                          }
                                       }

                                       var433 = false;
                                    }

                                    boolean var639 = var433;
                                    boolean var624 = var639;
                                    if (!var624) {
                                       Object[] var331 = new Object[]{var61, var12};
                                       CobwebPlacer var330 = this;
                                       BlockHitResult var640 = var330.aReturningBlockHitResult(var331);
                                       int var626 = var52;
                                       BlockHitResult var625 = var640;
                                       BlockHitResult var435 = var625;
                                       BlockHitResult var434 = var625;
                                       if (var626 == 0) {
                                          BlockHitResult var627 = var434;
                                          if (var627 == null) {
                                             return var60;
                                          }

                                          var435 = var640;
                                       }

                                       var61 = var435;
                                    }

                                    Object[] var10007 = new Object[]{null, null, null, null, var50};
                                    var10007[3] = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var638));
                                    var10007[2] = var55;
                                    var10007[1] = var54;
                                    var10007[0] = var61;
                                    Object[] var335 = var10007;
                                    CobwebPlacer var334 = this;
                                    CobwebPlacementResult var641 = var334.aReturningh_C0378(var335);
                                    int var630 = var52;
                                    CobwebPlacementResult var629 = CobwebPlacementResult.PLACE_SENT;
                                    CobwebPlacementResult var628 = var641;
                                    CobwebPlacementResult var438 = var628;
                                    CobwebPlacementResult var439 = var629;
                                    CobwebPlacementResult var436 = var628;
                                    CobwebPlacementResult var437 = var629;
                                    if (var630 == 0) {
                                       CobwebPlacementResult var632 = var437;
                                       CobwebPlacementResult var631 = var436;
                                       if (var631 == var632) {
                                          Object[] var338 = new Object[]{var34};
                                          CobwebPlacer var337 = this;
                                          var337.jReturningVoid(var338);
                                          int var633 = var52;
                                          if (var633 == 0) {
                                             return var60;
                                          }
                                       }

                                       CobwebPlacementResult var635 = CobwebPlacementResult.INVENTORY_QUEUED;
                                       CobwebPlacementResult var634 = var641;
                                       var438 = var634;
                                       var439 = var635;
                                    }

                                    CobwebPlacementResult var637 = var439;
                                    CobwebPlacementResult var636 = var438;
                                    if (var636 == var637) {
                                       ElapsedTimer var666 = this.v;
                                       Object[] var342 = new Object[]{var32};
                                       ElapsedTimer var341 = var666;
                                       var341.aReturningVoid(var342);
                                       MinMaxSetting var667 = this.h;
                                       Object[] var344 = new Object[]{var30};
                                       MinMaxSetting var343 = var667;
                                       var343.bReturningVoid(var344);
                                    }

                                    return var60;
                                 }
                              }

                              Object[] var222 = new Object[]{var28};
                              CobwebPlacer var221 = this;
                              return var221.bReturningdx_C0210(var222);
                           }

                           this.y = null;
                        }

                        Object[] var156 = new Object[]{var28};
                        CobwebPlacer var155 = this;
                        return var155.bReturningdx_C0210(var156);
                     }

                     Object[] var136 = new Object[]{var28};
                     CobwebPlacer var135 = this;
                     return var135.bReturningdx_C0210(var136);
                  }

                  Object[] var122 = new Object[]{var26};
                  CobwebPlacer var121 = var358;
                  var121.p(var122);
                  return null;
               }
            }

            Object[] var106 = new Object[]{var26};
            CobwebPlacer var105 = this;
            var105.p(var106);
            return null;
         }

         this.y = null;
         Object[] var97 = new Object[]{var16};
         CobwebPlacer var96 = this;
         var96.mReturningVoid(var97);
         Object[] var99 = new Object[]{var8};
         CobwebPlacer var98 = this;
         boolean var443 = var98.dReturningBoolean(var99);
      }

      return null;
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      BlockHitResult var2 = (BlockHitResult)var1[0];
      long var3 = (Long)var1[1];
      var3 = 12023629169224L ^ var3;
      long var5 = var3 ^ 132377601414397L;
      long var7 = var3 ^ 28492933864125L;
      int var10000 = Event.cReturningInt();
      RotationManager var10001 = Prestige.o;
      Object[] var14 = new Object[0];
      RotationManager var13 = var10001;
      Rotation var10 = var13.bReturningdx_C0210(var14);
      int var9 = var10000;
      int var43 = var9;
      Rotation var42 = var10;
      Rotation var37 = var42;
      Rotation var36 = var42;
      if (var43 != 0) {
         Rotation var44 = var36;
         if (var44 == null) {
            return null;
         }

         var37 = var10;
      }

      Object[] var17 = new Object[]{var37, var7};
      HitResult var11 = RotationUtil.aReturningHitResult(var17);
      int var46 = var9;
      HitResult var45 = var11;
      HitResult var39 = var45;
      HitResult var38 = var45;
      if (var46 != 0) {
         boolean var47 = var38 instanceof BlockHitResult;
         if (!var47) {
            return null;
         }

         HitResult var48 = var11;
         var39 = var48;
      }

      BlockHitResult var12 = (BlockHitResult)var39;
      int var49 = var9;
      if (var49 != 0) {
         int var51 = var9;
         BlockHitResult var50 = var12;
         BlockHitResult var41 = var50;
         BlockHitResult var40 = var50;
         if (var51 != 0) {
            BlockHitResult var21 = var40;
            BlockPos var57 = var21.getBlockPos();
            BlockHitResult var22 = var2;
            BlockPos var24 = var22.getBlockPos();
            BlockPos var23 = var57;
            boolean var52 = var23.equals(var24);
            if (!var52) {
               return null;
            }

            var41 = var12;
         }

         BlockHitResult var27 = var41;
         Direction var58 = var27.getSide();
         BlockHitResult var28 = var2;
         Direction var54 = var28.getSide();
         Direction var53 = var58;
         if (var53 != var54) {
            return null;
         }

         MinecraftClient var30 = b;
         ClientPlayerEntity var31 = var30.player;
         Vec3d var59 = var31.getEyePos();
         BlockHitResult var32 = var12;
         Vec3d var34 = var32.getPos();
         Vec3d var33 = var59;
         double var60 = var33.distanceTo(var34);
         Object[] var35 = new Object[]{var5};
         double var61;
         int var55 = (var61 = var60 - ItemUseUtil.bReturningFloat(var35)) == 0.0 ? 0 : (var61 < 0.0 ? -1 : 1);
         return var55 > 0 ? null : var12;
      } else {
         return null;
      }
   }

   private CobwebPlacementResult aReturningh_C0378(Object[] var1) {
      BlockHitResult var7 = (BlockHitResult)var1[0];
      Integer var4 = (Integer)var1[1];
      int var6 = (Integer)var1[2];
      byte var5 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var1[3]))))))))) ? 1 : 0);
      long var2 = (Long)var1[4];
      var2 = 12023629169224L ^ var2;
      long var8 = var2 ^ 41232412886556L;
      long var10 = var2 ^ 41570035516823L;
      long var12 = var2 ^ 21215772133647L;
      long var14 = var2 ^ 44312577557569L;
      long var16 = var2 ^ 27566744848025L;
      long var18 = var2 ^ 100322806809268L;
      long var20 = var2 ^ 3234051752637L;
      long var22 = var2 ^ 81584372742567L;
      long var24 = var2 ^ 120974802075844L;
      long var26 = var2 ^ 16947648778025L;
      long var28 = var2 ^ 1350909294514L;
      int var10000 = Event.bReturningInt();
      Object[] var35 = new Object[]{var20};
      int var31 = InventoryUtil.aReturningInt(var35);
      int var30 = var10000;
      Object[] var36 = new Object[]{Items.COBWEB, var14};
      int var198 = (((InventoryUtil.lReturningBoolean(var36)) ? 1 : 0));
      int var132 = var30;
      byte var131 = (byte)var198;
      int var120 = var131;
      byte var94 = var131;
      if (var132 == 0) {
         byte var133 = var94;
         if (var133 == 0) {
            int var135 = var30;
            int var134 = this.B;
            int var105 = var134;
            int var95 = var134;
            if (var135 == 0) {
               int var136 = var95;
               int var96 = var136;
               // int var137 = var96;
               if (var137 != var138) {
                  CobwebPlacer var104;
                  label159: {
                     int var103;
                     Object[] var40 = new Object[]{this};
                     var198 = (((SlotReservation.aReturningBoolean(var40)) ? 1 : 0));
                     int var140 = var30;
                     byte var139 = ((byte)(var198));
                     var103 = var139;
                     byte var97 = var139;
                     label102:
                     if (var140 == 0) {
                        byte var141 = var97;
                        byte var98 = var141;
                        byte var142 = var98;
                        if (var142 != 0) {
                           int var144 = var30;
                           int var143 = var31;
                           var103 = var143;
                           int var99 = var143;
                           if (var144 != 0) {
                              break label102;
                           }

                           int var145 = var99;
                           int var100 = var145;
                           int var147 = this.C;
                           int var146 = var100;
                           if (var146 == var147) {
                              Object[] var53 = new Object[]{var28};
                              CobwebPlacer var52 = this;
                              var52.mReturningVoid(var53);
                              return CobwebPlacementResult.NONE;
                           }
                        }

                        int var149 = var30;
                        CobwebPlacer var148 = this;
                        var104 = var148;
                        CobwebPlacer var101 = var148;
                        if (var149 != 0) {
                           break label159;
                        }

                        CobwebPlacer var150 = var101;
                        CobwebPlacer var102 = var150;
                        Object[] var46 = new Object[]{var102};
                        byte var151 = ((byte)((SlotReservation.aReturningBoolean(var46)) ? 1 : 0));
                        var103 = var151;
                     }

                     int var152 = var103;
                     if (var152 != 0) {
                        Object[] var48 = new Object[]{this, var8};
                        SlotReservation.aReturningVoid(var48);
                     }

                     var104 = this;
                  }

                  Object[] var51 = new Object[0];
                  CobwebPlacer var50 = var104;
                  var50.q(var51);
                  return CobwebPlacementResult.NONE;
               }

               var105 = var5;
            }

            Integer var109;
            label161: {
               int var154 = var30;
               int var153 = var105;
               int var110 = var153;
               int var106 = var153;
               if (var154 == 0) {
                  int var155 = var106;
                  if (var155 == 0) {
                     int var157 = var30;
                     Integer var156 = var4;
                     var109 = var156;
                     Integer var107 = var156;
                     if (var157 != 0) {
                        break label161;
                     }

                     Integer var158 = var107;
                     Integer var108 = var158;
                     Integer var159 = var108;
                     if (var159 != null) {
                        Object[] var57 = new Object[]{this, var16};
                        this.B = SlotReservation.aReturningInt(var57);
                        Integer var58 = var4;
                        this.C = var58;
                        MinecraftClient var59 = b;
                        this.G = var59.world;
                        Integer var160 = var4;
                        var109 = var160;
                        break label161;
                     }
                  }

                  var110 = var6;
               }

               int var162 = var30;
               int var161 = var110;
               int var112 = var161;
               int var111 = var161;
               if (var162 == 0) {
                  // int var163 = var111;
                  if (var163 == var164) {
                     return CobwebPlacementResult.NONE;
                  }

                  int var165 = var6;
                  var112 = var165;
               }

               int var32;
               int var33;
               label118: {
                  label162: {
                     var32 = var112;
                     var33 = var31;
                     int var167 = var30;
                     PacketQueueManager var166 = Prestige.u;
                     PacketQueueManager var114 = var166;
                     PacketQueueManager var113 = var166;
                     if (var167 == 0) {
                        PacketQueueManager var168 = var113;
                        if (var168 == null) {
                           break label162;
                        }

                        var114 = Prestige.u;
                     }

                     Object[] var10006 = new Object[]{null, null, invokeBinding5(this, var7, var32, var33), var26};
                     var10006[1] = var33;
                     var10006[0] = var32;
                     Object[] var69 = var10006;
                     PacketQueueManager var68 = var114;
                     PacketQueueResult var34 = var68.bReturningp_C0432(var69);
                     int var171 = var30;
                     PacketQueueResult var170 = PacketQueueResult.QUEUED;
                     PacketQueueResult var169 = var34;
                     PacketQueueResult var117 = var169;
                     PacketQueueResult var118 = var170;
                     PacketQueueResult var115 = var169;
                     PacketQueueResult var116 = var170;
                     if (var171 == 0) {
                        PacketQueueResult var173 = var116;
                        PacketQueueResult var172 = var115;
                        if (var172 == var173) {
                           return CobwebPlacementResult.INVENTORY_QUEUED;
                        }

                        var118 = PacketQueueResult.REJECTED;
                        var117 = var34;
                     }

                     PacketQueueResult var175 = var118;
                     PacketQueueResult var174 = var117;
                     if (var174 == var175) {
                        return CobwebPlacementResult.NONE;
                     }

                     int var176 = var30;
                     if (var176 == 0) {
                        break label118;
                     }
                  }

                  Object[] var10005 = new Object[]{null, null, SlotActionType.SWAP, var22};
                  var10005[1] = var33;
                  var10005[0] = var32;
                  Object[] var73 = var10005;
                  InventoryUtil.eReturningBoolean(var73);
               }

               Object[] var203 = new Object[]{null, null, null, var18};
               var203[2] = var33;
               var203[1] = var32;
               var203[0] = var7;
               Object[] var76 = var203;
               CobwebPlacer var75 = this;
               boolean var177 = var75.aReturningBoolean(var76);
               CobwebPlacementResult var119;
               if (var177) {
                  CobwebPlacementResult var178 = CobwebPlacementResult.PLACE_SENT;
                  var119 = var178;
               } else {
                  var119 = CobwebPlacementResult.NONE;
               }

               return var119;
            }

            Integer var61 = var109;
            var198 = var61;
            Object[] var10003 = new Object[]{null, var24};
            var10003[0] = var198;
            Object[] var62 = var10003;
            InventoryUtil.aReturningVoid(var62);
            RotationManager var201 = Prestige.o;
            Object[] var64 = new Object[]{true};
            RotationManager var63 = var201;
            var63.fReturningVoid(var64);
            return CobwebPlacementResult.HOTBAR_SWAPPED;
         }

         var120 = this.B;
      }

      CobwebPlacer var129;
      label168: {
         int var180 = var30;
         int var179 = var120;
         int var121 = var179;
         label141:
         if (var180 == 0) {
            // int var181 = var121;
            label150:
            if (var181 != var182) {
               Object[] var79 = new Object[]{this};
               boolean var199 = SlotReservation.aReturningBoolean(var79);
               int var184 = var30;
               boolean var183 = var199;
               boolean var128 = var183;
               boolean var122 = var183;
               if (var184 == 0) {
                  boolean var185 = var122;
                  boolean var123 = var185;
                  boolean var186 = var123;
                  if (var186) {
                     int var188 = var30;
                     int var187 = var31;
                     int var124 = var187;
                     if (var188 != 0) {
                        break label141;
                     }

                     int var189 = var124;
                     int var125 = var189;
                     int var191 = this.C;
                     int var190 = var125;
                     if (var190 == var191) {
                        break label150;
                     }
                  }

                  int var193 = var30;
                  CobwebPlacer var192 = this;
                  var129 = var192;
                  CobwebPlacer var126 = var192;
                  if (var193 != 0) {
                     break label168;
                  }

                  CobwebPlacer var194 = var126;
                  CobwebPlacer var127 = var194;
                  Object[] var85 = new Object[]{var127};
                  boolean var195 = SlotReservation.aReturningBoolean(var85);
                  var128 = var195;
               }

               boolean var196 = var128;
               if (var196) {
                  Object[] var87 = new Object[]{this, var8};
                  SlotReservation.aReturningVoid(var87);
               }

               var129 = this;
               break label168;
            }

            Object[] var91 = new Object[]{var7, var10};
            boolean var130 = ItemUseUtil.aReturningBoolean(var91);
         }

         Object[] var93 = new Object[]{var12};
         CobwebPlacer var92 = this;
         var92.kReturningVoid(var93);
         return CobwebPlacementResult.PLACE_SENT;
      }

      Object[] var90 = new Object[0];
      CobwebPlacer var89 = var129;
      var89.q(var90);
      return CobwebPlacementResult.NONE;
   }

   private boolean aReturningBoolean(Object[] var1) {
      BlockHitResult var6 = (BlockHitResult)var1[0];
      int var2 = (Integer)var1[1];
      int var5 = (Integer)var1[2];
      long var3 = (Long)var1[3];
      var3 = 12023629169224L ^ var3;
      long var7 = var3 ^ 127678746543467L;
      long var9 = var3 ^ 8743361738689L;
      long var11 = var3 ^ 31943084344752L;
      int var13 = Event.bReturningInt();
      int var39 = var13;
      MinecraftClient var38 = b;
      MinecraftClient var33 = var38;
      MinecraftClient var32 = var38;
      if (var39 == 0) {
         MinecraftClient var14 = var32;
         ClientPlayerEntity var40 = var14.player;
         if (var40 == null) {
            return false;
         }

         MinecraftClient var41 = b;
         var33 = var41;
      }

      MinecraftClient var17 = var33;
      int var43 = var13;
      ClientWorld var42 = var17.world;
      Object var35 = var42;
      ClientWorld var34 = var42;
      if (var43 == 0) {
         ClientWorld var44 = var34;
         if (var44 == null) {
            return false;
         }

         Object[] var20 = new Object[]{var6, var7};
         ItemUseUtil.aReturningBoolean(var20);
         ModeSetting var21 = this.r;
         var35 = var21.aReturningObject();
      }

      String var10000 = (String)var35;
      int var10001 = 28048;
      long var10002 = 3396484557943099430L ^ var3;
      String var23 = "Slot";
      String var22 = var10000;
      byte var49 = ((byte)((var22.equals(var23)) ? 1 : 0));
      int var46 = var13;
      byte var45 = var49;
      byte var37 = var45;
      byte var36 = var45;
      if (var46 == 0) {
         byte var47 = var36;
         if (var47 != 0) {
            IntSetting var25 = this.s;
            Integer var26 = (Integer)var25.aReturningObject();
            var10001 = var26 - 1;
            Object[] var10004 = new Object[]{null, var11};
            var10004[0] = var10001;
            Object[] var28 = var10004;
            CobwebPlacer var27 = this;
            var27.lReturningVoid(var28);
         }

         RotationManager var50 = Prestige.o;
         Object[] var31 = new Object[]{invokeBinding6(var2, var5), var9};
         RotationManager var30 = var50;
         var30.gReturningVoid(var31);
         var37 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var37);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 131126265905772L;
      long var6 = var2 ^ 37919921181731L;
      int var8 = Event.bReturningInt();
      int var20 = var8;
      CobwebPlacer var19 = this;
      CobwebPlacer var18 = var19;
      CobwebPlacer var17 = var19;
      if (var20 == 0) {
         BooleanSetting var9 = var17.j;
         Boolean var10 = (Boolean)var9.aReturningObject();
         boolean var21 = var10;
         if (var21) {
            this.A++;
         }

         ElapsedTimer var10000 = this.v;
         Object[] var14 = new Object[]{var6};
         ElapsedTimer var13 = var10000;
         var13.aReturningVoid(var14);
         var18 = this;
      }

      MinMaxSetting var23 = var18.h;
      Object[] var16 = new Object[]{var4};
      MinMaxSetting var15 = var23;
      var15.bReturningVoid(var16);
   }

   private void kReturningVoid(Object[] var1) {
      long var4;
      long var6;
      int var8;
      int var42;
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      var4 = var2 ^ 117154200344439L;
      var6 = var2 ^ 93977172676107L;
      ModeSetting var11 = this.r;
      String var9 = (String)var11.aReturningObject();
      int var10000 = Event.bReturningInt();
      // var8 = var10000;
      String var12 = var9;
      var10000 = var12.hashCode();
      int var47 = var8;
      int var46 = var10000;
      var42 = var46;
      int var37 = var46;
      label53:
      if (var47 == 0) {
         int var48 = var37;
         switch (var48) {
            case 2579998:
               short var10001 = 13729;
               long var10002 = 4266934777816712110L ^ var2;
               String var15 = "Slot";
               String var14 = var9;
               byte var70 = ((byte)((var14.equals(var15)) ? 1 : 0));
               int var50 = var8;
               byte var49 = var70;
               var42 = var49;
               byte var38 = var49;
               if (var50 != 0) {
                  break label53;
               }

               byte var51 = var38;
               byte var39 = var51;
               byte var52 = var39;
               if (var52 == 0) {
                  break;
               }

               var10 = 0;
               int var53 = var8;
               if (var53 == 0) {
                  break;
               }
            case 1443687921:
               short var72 = 15260;
               long var75 = 8975870338298776991L ^ var2;
               String var19 = "Original";
               String var18 = var9;
               byte var71 = ((byte)((var18.equals(var19)) ? 1 : 0));
               int var55 = var8;
               byte var54 = var71;
               var42 = var54;
               byte var40 = var54;
               if (var55 != 0) {
                  break label53;
               }

               byte var56 = var40;
               byte var41 = var56;
               byte var57 = var41;
               if (var57 != 0) {
                  var10 = 1;
               }
         }

         var42 = var10;
      }

      int var58 = var42;
      switch (var58) {
         case 0:
            IntSetting var22 = this.s;
            Integer var23 = (Integer)var22.aReturningObject();
            int var73 = var23 - 1;
            Object[] var10004 = new Object[]{null, var6};
            var10004[0] = var73;
            Object[] var25 = var10004;
            CobwebPlacer var24 = this;
            var24.lReturningVoid(var25);
            int var59 = var8;
            if (var59 == 0) {
               break;
            }
         case 1:
            int var61 = var8;
            CobwebPlacer var60 = this;
            CobwebPlacer var45 = var60;
            CobwebPlacer var43 = var60;
            if (var61 == 0) {
               CobwebPlacer var62 = var43;
               CobwebPlacer var44 = var62;
               // int var63 = var44.B;
               if (var63 != var64) {
                  int var74 = this.B;
                  Object[] var76 = new Object[]{null, var6};
                  var76[0] = var74;
                  Object[] var30 = var76;
                  CobwebPlacer var29 = this;
                  var29.lReturningVoid(var30);
                  int var65 = var8;
                  if (var65 == 0) {
                     break;
                  }
               }

               CobwebPlacer var66 = this;
               var45 = var66;
            }

            Object[] var34 = new Object[]{var4};
            CobwebPlacer var33 = var45;
            var33.p(var34);
            int var67 = var8;
            if (var67 == 0) {
               break;
            }
         default:
            Object[] var36 = new Object[]{var4};
            CobwebPlacer var35 = this;
            var35.p(var36);
      }
   }

   private void lReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 12023629169224L ^ var2;
      long var5 = var2 ^ 58388698700596L;
      long var7 = var2 ^ 84299984684474L;
      long var9 = var2 ^ 104595598180765L;
      long var11 = var2 ^ 75606757787065L;
      int var13 = Event.bReturningInt();
      int var49 = var13;
      if (var49 == 0) {
         int var50 = var4;
         label38:
         if (var50 >= 0) {
            short var10001 = 24777;
            long var10002 = 7267214165363296630L ^ var2;
            int var53 = var13;
            byte var52 = 8;
            int var51 = var4;
            int var39 = var51;
            int var40 = var52;
            int var35 = var51;
            byte var36 = var52;
            if (var53 == 0) {
               byte var55 = var36;
               int var54 = var35;
               int var37 = var54;
               byte var38 = var55;
               byte var57 = var38;
               int var56 = var37;
               if (var56 > var57) {
                  break label38;
               }

               Object[] var17 = new Object[]{var11};
               int var59 = InventoryUtil.aReturningInt(var17);
               int var58 = var4;
               var39 = var58;
               var40 = var59;
            }

            CobwebPlacer var48;
            label58: {
               int var47;
               label59: {
                  int var62 = var13;
                  int var61 = var40;
                  int var60 = var39;
                  int var44 = var60;
                  int var45 = var61;
                  int var41 = var60;
                  int var42 = var61;
                  if (var62 == 0) {
                     int var64 = var42;
                     int var63 = var41;
                     if (var63 == var64) {
                        break label38;
                     }

                     int var66 = var13;
                     int var65 = this.B;
                     var47 = var65;
                     int var43 = var65;
                     if (var66 != 0) {
                        break label59;
                     }

                     // int var67 = var43;
                     var44 = var67;
                     var45 = var68;
                  }

                  int var70 = var45;
                  int var69 = var44;
                  if (var69 == var70) {
                     Object[] var24 = new Object[]{this, var9};
                     this.B = SlotReservation.aReturningInt(var24);
                     Object[] var25 = new Object[]{var11};
                     this.C = InventoryUtil.aReturningInt(var25);
                     MinecraftClient var26 = b;
                     this.G = var26.world;
                  }

                  int var72 = var13;
                  CobwebPlacer var71 = this;
                  var48 = var71;
                  CobwebPlacer var46 = var71;
                  if (var72 != 0) {
                     break label58;
                  }

                  Object[] var28 = new Object[]{var46};
                  byte var73 = ((byte)((SlotReservation.aReturningBoolean(var28)) ? 1 : 0));
                  var47 = var73;
               }

               int var74 = var47;
               if (var74 == 0) {
                  Object[] var31 = new Object[0];
                  CobwebPlacer var30 = this;
                  var30.q(var31);
                  return;
               }

               this.D = var4;
               this.E = dev.prestige.recovery.SourceSupport.asBoolean(1);
               var48 = this;
            }

            Object[] var34 = new Object[]{var7};
            CobwebPlacer var33 = var48;
            var33.o(var34);
            return;
         }

         Object[] var21 = new Object[]{var5};
         CobwebPlacer var20 = this;
         var20.p(var21);
      }
   }

   private void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 133024541239754L;
      long var6 = var2 ^ 78107822698678L;
      long var8 = var2 ^ 10054733608775L;
      int var10 = Event.bReturningInt();
      int var52 = var10;
      byte var51 = ((byte)((this.E) ? 1 : 0));
      int var39 = var51;
      byte var38 = var51;
      if (var52 == 0) {
         byte var53 = var38;
         if (var53 != 0) {
            return;
         }

         int var54 = this.B;
         var39 = var54;
      }

      // int var55 = var39;
      if (var55 != var56) {
         label70: {
            int var58 = var10;
            MinecraftClient var57 = b;
            MinecraftClient var41 = var57;
            MinecraftClient var40 = var57;
            if (var58 == 0) {
               MinecraftClient var14 = var40;
               ClientPlayerEntity var59 = var14.player;
               if (var59 == null) {
                  break label70;
               }

               MinecraftClient var60 = b;
               var41 = var60;
            }

            CobwebPlacer var46;
            label71: {
               MinecraftClient var17 = var41;
               int var62 = var10;
               ClientWorld var61 = var17.world;
               Object var45 = var61;
               ClientWorld var42 = var61;
               if (var62 == 0) {
                  ClientWorld var63 = var42;
                  if (var63 == null) {
                     break label70;
                  }

                  int var65 = var10;
                  CobwebPlacer var64 = this;
                  var46 = var64;
                  CobwebPlacer var43 = var64;
                  if (var65 != 0) {
                     break label71;
                  }

                  CobwebPlacer var66 = var43;
                  CobwebPlacer var44 = var66;
                  Object var67 = var44.G;
                  var45 = var67;
               }

               MinecraftClient var21 = b;
               ClientWorld var69 = var21.world;
               Object var68 = var45;
               if (var68 != var69) {
                  break label70;
               }

               var46 = this;
            }

            CobwebPlacer var50;
            label73: {
               Object[] var25 = new Object[]{var46};
               int var10000 = (((SlotReservation.aReturningBoolean(var25)) ? 1 : 0));
               int var71 = var10;
               byte var70 = (byte)var10000;
               int var49 = var70;
               byte var47 = var70;
               if (var71 == 0) {
                  byte var72 = var47;
                  if (var72 == 0) {
                     Object[] var28 = new Object[0];
                     CobwebPlacer var27 = this;
                     var27.q(var28);
                     return;
                  }

                  int var74 = var10;
                  CobwebPlacer var73 = this;
                  var50 = var73;
                  CobwebPlacer var48 = var73;
                  if (var74 != 0) {
                     break label73;
                  }

                  int var75 = var48.C;
                  var49 = var75;
               }

               // int var76 = var49;
               if (var76 != var77) {
                  Object[] var31 = new Object[]{var8};
                  var10000 = InventoryUtil.aReturningInt(var31);
                  int var79 = this.C;
                  int var78 = var10000;
                  if (var78 != var79) {
                     Object[] var34 = new Object[]{var4};
                     CobwebPlacer var33 = this;
                     var33.p(var34);
                     return;
                  }
               }

               var50 = this;
            }

            int var10001 = this.B;
            Object[] var10004 = new Object[]{null, var6};
            var10004[0] = var10001;
            Object[] var37 = var10004;
            CobwebPlacer var36 = var50;
            var36.lReturningVoid(var37);
            return;
         }

         Object[] var23 = new Object[]{var4};
         CobwebPlacer var22 = this;
         var22.p(var23);
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 109212920255429L;
      long var6 = var2 ^ 59364884318697L;
      long var8 = var2 ^ 74924807051108L;
      long var10 = var2 ^ 44884859360541L;
      int var12 = Event.cReturningInt();
      int var70 = var12;
      byte var69 = ((byte)((this.E) ? 1 : 0));
      byte var51 = var69;
      byte var50 = var69;
      if (var70 != 0) {
         byte var71 = var50;
         if (var71 != 0) {
            label88: {
               int var73 = var12;
               MinecraftClient var72 = b;
               MinecraftClient var53 = var72;
               MinecraftClient var52 = var72;
               if (var73 != 0) {
                  MinecraftClient var14 = var52;
                  ClientPlayerEntity var74 = var14.player;
                  if (var74 == null) {
                     break label88;
                  }

                  MinecraftClient var75 = b;
                  var53 = var75;
               }

               CobwebPlacer var58;
               label89: {
                  MinecraftClient var17 = var53;
                  int var77 = var12;
                  ClientWorld var76 = var17.world;
                  Object var57 = var76;
                  ClientWorld var54 = var76;
                  if (var77 != 0) {
                     ClientWorld var78 = var54;
                     if (var78 == null) {
                        break label88;
                     }

                     int var80 = var12;
                     CobwebPlacer var79 = this;
                     var58 = var79;
                     CobwebPlacer var55 = var79;
                     if (var80 == 0) {
                        break label89;
                     }

                     CobwebPlacer var81 = var55;
                     CobwebPlacer var56 = var81;
                     Object var82 = var56.G;
                     var57 = var82;
                  }

                  MinecraftClient var21 = b;
                  ClientWorld var84 = var21.world;
                  Object var83 = var57;
                  if (var83 != var84) {
                     break label88;
                  }

                  var58 = this;
               }

               Object[] var25 = new Object[]{var58};
               int var10000 = (((SlotReservation.aReturningBoolean(var25)) ? 1 : 0));
               int var86 = var12;
               byte var85 = (byte)var10000;
               int var60 = var85;
               byte var59 = var85;
               if (var86 != 0) {
                  byte var87 = var59;
                  if (var87 == 0) {
                     Object[] var28 = new Object[0];
                     CobwebPlacer var27 = this;
                     var27.q(var28);
                     return true;
                  }

                  var60 = this.C;
               }

               int var64;
               int var89 = var12;
               int var88 = var60;
               var64 = var88;
               int var61 = var88;
               label64:
               if (var89 != 0) {
                  // int var90 = var61;
                  if (var90 != var91) {
                     Object[] var31 = new Object[]{var8};
                     var10000 = InventoryUtil.aReturningInt(var31);
                     int var93 = var12;
                     int var92 = var10000;
                     var64 = var92;
                     int var62 = var92;
                     if (var93 == 0) {
                        break label64;
                     }

                     int var94 = var62;
                     int var63 = var94;
                     int var96 = this.C;
                     int var95 = var63;
                     if (var95 != var96) {
                        Object[] var35 = new Object[]{var6};
                        CobwebPlacer var34 = this;
                        var34.p(var35);
                        return true;
                     }
                  }

                  RotationManager var106 = Prestige.o;
                  Object[] var38 = new Object[0];
                  RotationManager var37 = var106;
                  var64 = (((var37.fReturningBoolean(var38)) ? 1 : 0));
               }

               int var98 = var12;
               int var97 = var64;
               int var66 = var97;
               int var65 = var97;
               if (var98 != 0) {
                  int var99 = var65;
                  if (var99 != 0) {
                     return true;
                  }

                  Object[] var41 = new Object[]{var8};
                  var66 = InventoryUtil.aReturningInt(var41);
               }

               int var101 = var12;
               int var100 = var66;
               int var68 = var100;
               int var67 = var100;
               if (var101 != 0) {
                  int var103 = this.D;
                  int var102 = var67;
                  if (var102 != var103) {
                     var10000 = this.D;
                     Object[] var10003 = new Object[]{null, var10};
                     var10003[0] = var10000;
                     Object[] var43 = var10003;
                     InventoryUtil.aReturningVoid(var43);
                     RotationManager var108 = Prestige.o;
                     Object[] var45 = new Object[]{true};
                     RotationManager var44 = var108;
                     var44.fReturningVoid(var45);
                  }

                  Object[] var47 = new Object[]{this, var4};
                  SlotReservation.aReturningVoid(var47);
                  Object[] var49 = new Object[0];
                  CobwebPlacer var48 = this;
                  var48.q(var49);
                  var68 = 1;
               }

               return dev.prestige.recovery.SourceSupport.asBoolean(var68);
            }

            Object[] var23 = new Object[]{var6};
            CobwebPlacer var22 = this;
            var22.p(var23);
            return true;
         }

         var51 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var51);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 4104200764171L;
      long var6 = var2 ^ 86562167380776L;
      Object[] var9 = new Object[]{var6};
      CobwebPlacer var8 = this;
      var8.mReturningVoid(var9);
      Object[] var11 = new Object[]{var4};
      CobwebPlacer var10 = this;
      var10.dReturningBoolean(var11);
      return null;
   }

   private void nReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 25948295169410L;
      long var6 = var2 ^ 121121264098060L;
      long var8 = var2 ^ 44577467158051L;
      long var10 = var2 ^ 112428062825231L;
      long var12 = var2 ^ 111646706576896L;
      int var14 = Event.cReturningInt();
      int var76 = var14;
      if (var76 != 0) {
         MinecraftClient var15 = b;
         ClientPlayerEntity var77 = var15.player;
         label84:
         if (var77 != null) {
            CobwebPlacer var62;
            label98: {
               MinecraftClient var17 = b;
               int var79 = var14;
               ClientWorld var78 = var17.world;
               Object var61 = var78;
               ClientWorld var57 = var78;
               if (var79 != 0) {
                  ClientWorld var80 = var57;
                  ClientWorld var58 = var80;
                  ClientWorld var81 = var58;
                  if (var81 == null) {
                     break label84;
                  }

                  int var83 = var14;
                  CobwebPlacer var82 = this;
                  var62 = var82;
                  CobwebPlacer var59 = var82;
                  if (var83 == 0) {
                     break label98;
                  }

                  CobwebPlacer var84 = var59;
                  CobwebPlacer var60 = var84;
                  Object var85 = var60.G;
                  var61 = var85;
               }

               MinecraftClient var22 = b;
               ClientWorld var87 = var22.world;
               Object var86 = var61;
               if (var86 != var87) {
                  break label84;
               }

               Object[] var27 = new Object[]{var12};
               CobwebPlacer var26 = this;
               var26.mReturningVoid(var27);
               var62 = this;
            }

            CobwebPlacer var69;
            label109: {
               int var89 = var14;
               boolean var88 = var62.E;
               boolean var65 = var88;
               boolean var63 = var88;
               if (var89 != 0) {
                  boolean var90 = var63;
                  if (!var90) {
                     Object[] var30 = new Object[]{var4};
                     CobwebPlacer var29 = this;
                     var29.p(var30);
                     return;
                  }

                  int var92 = var14;
                  CobwebPlacer var91 = this;
                  var69 = var91;
                  CobwebPlacer var64 = var91;
                  if (var92 == 0) {
                     break label109;
                  }

                  Object[] var32 = new Object[]{var64};
                  boolean var93 = SlotReservation.aReturningBoolean(var32);
                  var65 = var93;
               }

               boolean var94 = var65;
               label67:
               if (var94) {
                  int var96 = var14;
                  MinecraftClient var95 = b;
                  MinecraftClient var68 = var95;
                  MinecraftClient var66 = var95;
                  if (var96 != 0) {
                     MinecraftClient var97 = var66;
                     MinecraftClient var67 = var97;
                     MinecraftClient var35 = var67;
                     ClientPlayerEntity var98 = var35.player;
                     if (var98 == null) {
                        break label67;
                     }

                     MinecraftClient var99 = b;
                     var68 = var99;
                  }

                  MinecraftClient var38 = var68;
                  ClientWorld var100 = var38.world;
                  if (var100 != null) {
                     int var73;
                     int var103 = var14;
                     int var102 = this.C;
                     var73 = var102;
                     int var70 = var102;
                     label59:
                     if (var103 != 0) {
                        // int var104 = var70;
                        if (var104 != var105) {
                           Object[] var43 = new Object[]{var10};
                           int var10000 = InventoryUtil.aReturningInt(var43);
                           int var107 = var14;
                           int var106 = var10000;
                           var73 = var106;
                           int var71 = var106;
                           if (var107 == 0) {
                              break label59;
                           }

                           int var108 = var71;
                           int var72 = var108;
                           int var110 = this.C;
                           int var109 = var72;
                           if (var109 != var110) {
                              Object[] var47 = new Object[]{var4};
                              CobwebPlacer var46 = this;
                              var46.p(var47);
                              return;
                           }
                        }

                        RotationManager var115 = Prestige.o;
                        Object[] var50 = new Object[0];
                        RotationManager var49 = var115;
                        var73 = (((var49.fReturningBoolean(var50)) ? 1 : 0));
                     }

                     int var112 = var14;
                     int var111 = var73;
                     int var74 = var111;
                     if (var112 != 0) {
                        int var113 = var74;
                        if (var113 != 0) {
                           Object[] var53 = new Object[]{var6};
                           CobwebPlacer var52 = this;
                           var52.o(var53);
                           return;
                        }

                        Object[] var56 = new Object[]{var8};
                        CobwebPlacer var55 = this;
                        boolean var75 = var55.dReturningBoolean(var56);
                     }

                     return;
                  }
               }

               CobwebPlacer var101 = this;
               var69 = var101;
            }

            Object[] var41 = new Object[]{var4};
            CobwebPlacer var40 = var69;
            var40.p(var41);
            return;
         }

         Object[] var24 = new Object[]{var4};
         CobwebPlacer var23 = this;
         var23.p(var24);
      }
   }

   private void o(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 94924992034763L;
      int var6 = Event.cReturningInt();
      int var14 = var6;
      CobwebPlacer var13 = this;
      CobwebPlacer var12 = var13;
      CobwebPlacer var11 = var13;
      if (var14 != 0) {
         boolean var15 = var11.F;
         if (var15) {
            return;
         }

         var12 = this;
      }

      var12.F = dev.prestige.recovery.SourceSupport.asBoolean(1);
      RotationManager var10000 = Prestige.o;
      Object[] var10 = new Object[]{new CobwebPlacementTask(this), var4};
      RotationManager var9 = var10000;
      var9.gReturningVoid(var10);
   }

   private void p(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 101458194454628L;
      int var6 = Event.bReturningInt();
      int var16 = var6;
      CobwebPlacer var15 = this;
      CobwebPlacer var14 = var15;
      CobwebPlacer var13 = var15;
      if (var16 == 0) {
         Object[] var7 = new Object[]{var13};
         boolean var17 = SlotReservation.aReturningBoolean(var7);
         if (var17) {
            Object[] var9 = new Object[]{this, var4};
            SlotReservation.aReturningVoid(var9);
         }

         var14 = this;
      }

      Object[] var12 = new Object[0];
      CobwebPlacer var11 = var14;
      var11.q(var12);
   }

   private void q(Object[] var1) {
      this.B = -1;
      this.C = -1;
      this.D = -1;
      this.E = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.G = null;
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      PlayerEntity var4;
      long var5;
      long var9;
      int var22;
      label20: {
         var4 = (PlayerEntity)var1[0];
         long var2 = (Long)var1[1];
         var2 = 12023629169224L ^ var2;
         var5 = var2 ^ 63021688282116L;
         long var7 = var2 ^ 53025492507796L;
         var9 = var2 ^ 101995872205021L;
         int var11 = Event.cReturningInt();
         Object[] var13 = new Object[]{var4, var7};
         double var31;
         int var10000 = (var31 = RaycastUtil.aReturningDouble(var13) - 0.3F) == 0.0 ? 0 : (var31 < 0.0 ? -1 : 1);
         int var25 = var11;
         int var24 = var10000;
         int var21 = var24;
         int var20 = var24;
         if (var25 != 0) {
            int var26 = var20;
            if (var26 >= 0) {
               var22 = 0;
               break label20;
            }

            var21 = 1;
         }

         int var27 = var21;
         var22 = var27;
      }

      int var12 = var22;
      int var28 = var12;
      Vec3d var23;
      if (var28 != 0) {
         Object[] var16 = new Object[]{var4, var5};
         CobwebPlacer var15 = this;
         Vec3d var29 = var15.dReturningVec3d(var16);
         var23 = var29;
      } else {
         Object[] var19 = new Object[]{var4, var9};
         CobwebPlacer var18 = this;
         var23 = var18.cReturningVec3d(var19);
      }

      return var23;
   }

   private Vec3d bReturningVec3d(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 12023629169224L ^ var2;
      long var5 = var2 ^ 103840636769672L;
      long var7 = var2 ^ 110170389989908L;
      long var9 = var2 ^ 99898266484744L;
      Object[] var45 = new Object[]{var4, var7};
      Vec3d var12 = RaycastUtil.aReturningVec3d(var45);
      int var10000 = Event.cReturningInt();
      Object[] var46 = new Object[]{var4, var5};
      Vec3d var13 = RaycastUtil.cReturningVec3d(var46);
      PlayerEntity var47 = var4;
      Vec3d var14 = var47.getVelocity();
      int var11 = var10000;
      Vec3d var48 = var12;
      Vec3d var49 = var13;
      double var129 = var48.y - var49.y;
      Vec3d var50 = var14;
      double var53 = var50.y;
      double var51 = var129;
      double var15 = Math.min(var51, var53);
      Vec3d var55 = var12;
      Vec3d var56 = var13;
      double var10002 = var55.x - var56.x;
      Vec3d var57 = var12;
      Vec3d var58 = var13;
      Vec3d var17 = new Vec3d(var10002, var15, var57.z - var58.z);
      PlayerEntity var59 = var4;
      Box var18 = var59.getBoundingBox();
      Box var60 = var18;
      Box var61 = var18;
      double var130 = (var60.maxX - var61.minX) / 2.0;
      double var64 = 0.15;
      double var62 = var130;
      double var19 = Math.max(var62, var64);
      int var131 = 6366;
      long var10001 = 8659604806107392943L ^ var2;
      MinecraftClient var66 = b;
      ClientWorld var67 = var66.world;
      int var23 = var67.getBottomY();
      Vec3d var68 = var12;
      double var24 = var68.x;
      Vec3d var69 = var12;
      double var26 = var69.y;
      Vec3d var70 = var12;
      double var28 = var70.z;
      double var38;
      double var42;
      int var105;
      label52: {
         int var127;
         do {
            byte var110 = 80;
            int var109 = var30;
            if (var109 >= var110) {
               break;
            }

            Vec3d var71 = var17;
            double var31 = var71.x / 4;
            Vec3d var72 = var17;
            double var33 = var72.y / 4;
            Vec3d var73 = var17;
            double var35 = var73.z / 4;
            int var108;
            while (true) {
               byte var112 = 4;
               int var111 = var37;
               if (var111 < var112) {
                  var38 = var24 + var31;
                  double var40 = var26 + var33;
                  var42 = var28 + var35;
                  Vec3d var74 = var17;
                  int var115 = var11;
                  double var113 = var74.y;
                  double var106 = var113;
                  double var99 = var113;
                  if (var115 != 0) {
                     double var135;
                     var131 = (var135 = var99 - 0.0) == 0.0 ? 0 : (var135 < 0.0 ? -1 : 1);
                     int var117 = var11;
                     int var116 = var131;
                     var108 = var116;
                     int var101 = var116;
                     if (var117 == 0) {
                        break;
                     }

                     int var118 = var101;
                     int var102 = var118;
                     int var119 = var102;
                     if (var119 <= 0) {
                        Object[] var10007 = new Object[]{null, null, null, null, var9};
                        var10007[3] = var19;
                        var10007[2] = var42;
                        var10007[1] = var40;
                        var10007[0] = var38;
                        Object[] var78 = var10007;
                        CobwebPlacer var77 = this;
                        byte var133 = ((byte)((var77.eReturningBoolean(var78)) ? 1 : 0));
                        int var121 = var11;
                        byte var120 = var133;
                        var105 = var120;
                        byte var103 = var120;
                        if (var121 == 0) {
                           break label52;
                        }

                        byte var122 = var103;
                        byte var104 = var122;
                        byte var123 = var104;
                        if (var123 != 0) {
                           double var81 = var40 - 1.0E-4;
                           int var124 = MathHelper.floor(var81);
                           var105 = var124;
                           break label52;
                        }
                     }

                     var24 = var38;
                     var26 = var40;
                     var106 = var42;
                  }

                  var28 = var106;
                  var37++;
                  int var125 = var11;
                  if (var125 != 0) {
                     continue;
                  }
               }

               double var136;
               var108 = (var136 = var26 - var23) == 0.0 ? 0 : (var136 < 0.0 ? -1 : 1);
               break;
            }

            int var126 = var108;
            if (var126 <= 0) {
               return null;
            }

            double var88 = 0.08;
            Vec3d var85 = var17;
            Vec3d var134 = var85.subtract(var86, var88, var90);
            double var97 = 0.91;
            double var95 = 0.98;
            double var93 = 0.91;
            Vec3d var92 = var134;
            var17 = var92.multiply(var93, var95, var97);
            var30++;
            var127 = var11;
         } while (var127 != 0);

         return null;
      }

      int var44 = var105;
      return new Vec3d(var38, var44 + 1.0, var42);
   }

   private boolean eReturningBoolean(Object[] var1) {
      double var2 = (Double)var1[0];
      double var4 = (Double)var1[1];
      double var6 = (Double)var1[2];
      double var8 = (Double)var1[3];
      long var10 = (Long)var1[4];
      long var10000 = 12023629169224L ^ var10;
      int var66 = Event.bReturningInt();
      double var22 = var2 - var8 + 0.001;
      int var13 = MathHelper.floor(var22);
      double var24 = var2 + var8 - 0.001;
      int var14 = MathHelper.floor(var24);
      int var12 = var66;
      double var26 = var6 - var8 + 0.001;
      int var15 = MathHelper.floor(var26);
      double var28 = var6 + var8 - 0.001;
      int var16 = MathHelper.floor(var28);
      double var30 = var4 - 0.001;
      int var17 = MathHelper.floor(var30);
      int var18 = var13;

      label57:
      while (true) {
         int var42 = var18;

         int var49;
         label53:
         while (true) {
            int var51 = var14;
            int var50 = var42;
            if (var50 <= var51) {
               int var53 = var12;
               int var52 = var15;
               var49 = var52;
               int var43 = var52;
               if (var53 != 0) {
                  break;
               }

               int var19 = var43;

               int var64;
               do {
                  int var55 = var16;
                  int var54 = var19;
                  if (var54 > var55) {
                     break;
                  }

                  BlockPos var20 = new BlockPos(var18, var17, var19);
                  MinecraftClient var32 = b;
                  BlockPos var34 = var20;
                  ClientWorld var33 = var32.world;
                  BlockState var21 = var33.getBlockState(var34);
                  BlockState var35 = var21;
                  byte var67 = ((byte)((var35.isAir()) ? 1 : 0));
                  int var57 = var12;
                  byte var56 = var67;
                  var42 = var56;
                  byte var44 = var56;
                  if (var57 != 0) {
                     continue label53;
                  }

                  label62: {
                     int var59 = var12;
                     byte var58 = var44;
                     byte var46 = var58;
                     byte var45 = var58;
                     if (var59 == 0) {
                        byte var60 = var45;
                        if (var60 != 0) {
                           break label62;
                        }

                        MinecraftClient var37 = b;
                        BlockPos var40 = var20;
                        ClientWorld var39 = var37.world;
                        BlockState var38 = var21;
                        VoxelShape var41 = var38.getCollisionShape((BlockView)var39, var40);
                        var46 = ((byte)((var41.isEmpty()) ? 1 : 0));
                     }

                     int var62 = var12;
                     byte var61 = var46;
                     byte var48 = var61;
                     byte var47 = var61;
                     if (var62 != 0) {
                        return dev.prestige.recovery.SourceSupport.asBoolean(var48);
                     }

                     byte var63 = var47;
                     if (var63 == 0) {
                        var48 = 1;
                        return dev.prestige.recovery.SourceSupport.asBoolean(var48);
                     }
                  }

                  var19++;
                  var64 = var12;
               } while (var64 == 0);

               var18++;
               int var65 = var12;
               if (var65 == 0) {
                  continue label57;
               }
            }

            var49 = 0;
            break;
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(var49);
      }
   }

   private Vec3d cReturningVec3d(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 12023629169224L ^ var3;
      long var5 = var3 ^ 111851982887353L;
      long var7 = var3 ^ 105522296800805L;
      Object[] var21 = new Object[]{var2, var7};
      Vec3d var10 = RaycastUtil.aReturningVec3d(var21);
      Object[] var22 = new Object[]{var2, var5};
      Vec3d var11 = RaycastUtil.cReturningVec3d(var22);
      int var10000 = Event.bReturningInt();
      PlayerEntity var23 = var2;
      Vec3d var12 = var23.getVelocity();
      int var9 = var10000;
      Vec3d var24 = var10;
      Vec3d var25 = var11;
      double var95 = var24.y - var25.y;
      Vec3d var26 = var12;
      double var29 = var26.y;
      double var27 = var95;
      double var13 = Math.min(var27, var29);
      Vec3d var31 = var10;
      Vec3d var32 = var11;
      double var10002 = var31.x - var32.x;
      Vec3d var33 = var10;
      Vec3d var34 = var11;
      Vec3d var15 = new Vec3d(var10002, var13, var33.z - var34.z);
      Vec3d var16 = var10;
      IntSetting var35 = this.i;
      Integer var36 = (Integer)var35.aReturningObject();
      int var17 = var36;
      MinecraftClient var37 = b;
      ClientWorld var38 = var37.world;
      int var18 = var38.getBottomY();
      Vec3d var81;
      while (true) {
         int var83 = var17;
         int var82 = var19;
         if (var82 < var83) {
            var16 = var10;
            Vec3d var40 = var15;
            Vec3d var39 = var10;
            var10 = var39.add(var40);
            int var85 = var9;
            Vec3d var84 = var10;
            var81 = var84;
            Vec3d var76 = var84;
            if (var85 != 0) {
               break;
            }

            Vec3d var80;
            label40: {
               Vec3d var41 = var76;
               Vec3d var42 = var10;
               double var10001 = var42.y - 0.1;
               Vec3d var43 = var10;
               double var48 = var43.z;
               double var46 = var10001;
               double var44 = var41.x;
               BlockPos var20 = BlockPos.ofFloored(var44, var46, var48);
               MinecraftClient var50 = b;
               BlockPos var52 = var20;
               ClientWorld var51 = var50.world;
               BlockState var53 = var51.getBlockState(var52);
               byte var96 = ((byte)((var53.isAir()) ? 1 : 0));
               int var87 = var9;
               byte var86 = var96;
               int var79 = var86;
               byte var77 = var86;
               if (var87 == 0) {
                  byte var88 = var77;
                  if (var88 == 0) {
                     Vec3d var55 = var10;
                     var10002 = var55.x;
                     BlockPos var56 = var20;
                     double var10003 = var56.getY() + 1.0;
                     Vec3d var57 = var10;
                     return new Vec3d(var10002, var10003, var57.z);
                  }

                  int var90 = var9;
                  Vec3d var89 = var10;
                  var80 = var89;
                  Vec3d var78 = var89;
                  if (var90 != 0) {
                     break label40;
                  }

                  Vec3d var59 = var78;
                  double var99;
                  int var91 = (var99 = var59.y - var18) == 0.0 ? 0 : (var99 < 0.0 ? -1 : 1);
                  var79 = var91;
               }

               int var92 = var79;
               if (var92 <= 0) {
                  return null;
               }

               double var65 = 0.08;
               Vec3d var62 = var15;
               Vec3d var97 = var62.subtract(var63, var65, var67);
               double var74 = 0.91;
               double var72 = 0.98;
               double var70 = 0.91;
               Vec3d var69 = var97;
               var80 = var69.multiply(var70, var72, var74);
            }

            var15 = var80;
            var19++;
            int var93 = var9;
            if (var93 == 0) {
               continue;
            }
         }

         var81 = var16;
         break;
      }

      return var81;
   }

   private Vec3d dReturningVec3d(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 12023629169224L ^ var3;
      long var5 = var3 ^ 172660227424L;
      long var7 = var3 ^ 64228852015868L;
      Object[] var16 = new Object[]{var2, var7};
      Vec3d var10 = RaycastUtil.aReturningVec3d(var16);
      Object[] var17 = new Object[]{var2, var5};
      Vec3d var11 = RaycastUtil.cReturningVec3d(var17);
      Vec3d var18 = var10;
      Vec3d var19 = var11;
      double var10002 = var18.x - var19.x;
      Vec3d var20 = var10;
      Vec3d var21 = var11;
      Vec3d var12 = new Vec3d(var10002, 0.0, var20.z - var21.z);
      int var10000 = Event.bReturningInt();
      IntSetting var22 = this.i;
      Integer var23 = (Integer)var22.aReturningObject();
      int var13 = var23;
      int var9 = var10000;
      Vec3d var64;
      while (true) {
         int var66 = var13;
         int var65 = var14;
         label37:
         if (var65 < var66) {
            Vec3d var24 = var12;
            Vec3d var25 = var12;
            double var31 = var25.z;
            double var27 = var24.x;
            Vec3d var26 = var10;
            var10 = var26.add(var27, var29, var31);
            int var68 = var9;
            Vec3d var67 = var10;
            var64 = var67;
            Vec3d var61 = var67;
            if (var68 != 0) {
               break;
            }

            label44: {
               Vec3d var33 = var61;
               Vec3d var34 = var10;
               double var10001 = var34.y - 0.1;
               Vec3d var35 = var10;
               double var40 = var35.z;
               double var38 = var10001;
               double var36 = var33.x;
               BlockPos var15 = BlockPos.ofFloored(var36, var38, var40);
               MinecraftClient var42 = b;
               BlockPos var44 = var15;
               ClientWorld var43 = var42.world;
               BlockState var45 = var43.getBlockState(var44);
               byte var78 = ((byte)((var45.isAir()) ? 1 : 0));
               int var70 = var9;
               byte var69 = var78;
               int var63 = var69;
               byte var62 = var69;
               if (var70 == 0) {
                  byte var71 = var62;
                  if (var71 != 0) {
                     break label37;
                  }

                  double var52 = 0.999;
                  double var50 = 1.0;
                  double var48 = 0.999;
                  Vec3d var47 = var12;
                  var12 = var47.multiply(var48, var50, var52);
                  int var72 = var9;
                  if (var72 != 0) {
                     break label44;
                  }

                  Vec3d var54 = var12;
                  double var55 = var54.x;
                  double var79;
                  int var73 = (var79 = Math.abs(var55) - 0.005) == 0.0 ? 0 : (var79 < 0.0 ? -1 : 1);
                  var63 = var73;
               }

               int var74 = var63;
               if (var74 < 0) {
                  Vec3d var58 = var12;
                  double var59 = var58.z;
                  double var80;
                  int var75 = (var80 = Math.abs(var59) - 0.005) == 0.0 ? 0 : (var80 < 0.0 ? -1 : 1);
                  if (var75 < 0) {
                     break label37;
                  }
               }

               var14++;
            }

            int var76 = var9;
            if (var76 == 0) {
               continue;
            }
         }

         var64 = var10;
         break;
      }

      return var64;
   }

   @EventListener
   public void a(Render3DEvent var1) {
      int var6;
      CobwebPlacer var42;
      label47: {
         long var10001 = 36911794702297L ^ 19714349582792L;
         var6 = Event.bReturningInt();
         ModeSetting var9 = this.f;
         String var10000 = (String)var9.aReturningObject();
         String var11 = "Auto";
         String var10 = var10000;
         boolean var62 = var10.equals(var11);
         int var48 = var6;
         boolean var47 = var62;
         boolean var41 = var47;
         boolean var38 = var47;
         if (var48 == 0) {
            boolean var49 = var38;
            if (!var49) {
               return;
            }

            int var51 = var6;
            CobwebPlacer var50 = this;
            var42 = var50;
            CobwebPlacer var39 = var50;
            if (var51 != 0) {
               break label47;
            }

            CobwebPlacer var52 = var39;
            CobwebPlacer var40 = var52;
            BooleanSetting var14 = var40.t;
            Boolean var15 = (Boolean)var14.aReturningObject();
            boolean var53 = var15;
            var41 = var53;
         }

         boolean var54 = var41;
         if (!var54) {
            return;
         }

         var42 = this;
      }

      Vec3d var7 = var42.y;
      int var56 = var6;
      Vec3d var55 = var7;
      Vec3d var44 = var55;
      Vec3d var43 = var55;
      if (var56 == 0) {
         Vec3d var57 = var43;
         if (var57 == null) {
            return;
         }

         var44 = var7;
      }

      Vec3d var18 = var44;
      Vec3d var19 = var7;
      Vec3d var20 = var7;
      double var25 = var20.z;
      double var23 = var19.y;
      double var21 = var18.x;
      BlockPos var8 = BlockPos.ofFloored(var21, var23, var25);
      ColorSetting var27 = this.u;
      Object[] var29 = new Object[]{var1, var8, (Color)var27.aReturningObject(), 53309815950865L};
      CobwebPlacer var28 = this;
      var28.r(var29);
      int var59 = var6;
      CobwebPlacer var58 = this;
      CobwebPlacer var46 = var58;
      CobwebPlacer var45 = var58;
      if (var59 == 0) {
         BooleanSetting var30 = var45.q;
         Boolean var31 = (Boolean)var30.aReturningObject();
         boolean var60 = var31;
         if (!var60) {
            return;
         }

         CobwebPlacer var61 = this;
         var46 = var61;
      }

      BlockPos var34 = var8;
      BlockPos var10002 = var34.up();
      ColorSetting var35 = this.u;
      Object[] var37 = new Object[]{var1, var10002, (Color)var35.aReturningObject(), 53309815950865L};
      CobwebPlacer var36 = var46;
      var36.r(var37);
   }

   private void r(Object[] var1) {
      Render3DEvent var6 = (Render3DEvent)var1[0];
      BlockPos var2 = (BlockPos)var1[1];
      Color var5 = (Color)var1[2];
      long var3 = (Long)var1[3];
      var3 = 12023629169224L ^ var3;
      long var7 = var3 ^ 99979686599773L;
      RenderContext var10000 = var6.b;
      MeshBufferManager var10001 = var6.a;
      BlockPos var9 = var2;
      float var10002 = var9.getX();
      BlockPos var10 = var2;
      float var10003 = var10.getY();
      BlockPos var11 = var2;
      float var10004 = var11.getZ();
      BlockPos var12 = var2;
      float var10005 = var12.getX() + 1.0F;
      BlockPos var13 = var2;
      float var10006 = var13.getY() + 1.0F;
      BlockPos var14 = var2;
      float var10007 = var14.getZ() + 1.0F;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var5, var7};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var10003;
      var10011[2] = var10002;
      var10011[1] = var10001;
      var10011[0] = var10000;
      Object[] var15 = var10011;
      ShapeRenderer.gReturningVoid(var15);
   }

   private void s(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 12023629169224L ^ var2;
      long var4 = var2 ^ 57218491675872L;
      long var6 = var2 ^ 106879895233199L;
      ElapsedTimer var10000 = this.v;
      Object[] var9 = new Object[]{var6};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      MinMaxSetting var13 = this.h;
      Object[] var11 = new Object[]{var4};
      MinMaxSetting var10 = var13;
      var10.bReturningVoid(var11);
      this.w++;
   }

   private static void lambda$finishInvSwapPlace$16(int var0, int var1) {
      long var10001 = 63453601962376L ^ 69698028894613L;
      int var6 = Event.cReturningInt();
      int var11 = var6;
      if (var11 != 0) {
         MinecraftClient var7 = b;
         ClientPlayerEntity var12 = var7.player;
         if (var12 == null) {
            return;
         }

         Object[] var10004 = new Object[]{null, null, 7516849659933L};
         var10004[1] = var1;
         var10004[0] = var0;
         Object[] var10 = var10004;
         InventoryUtil.fReturningBoolean(var10);
      }
   }

   private void lambda$performAutoPlace$15(BlockHitResult var1, int var2, int var3) {
      long var10001 = 42763073020910L ^ 44540055018885L;
      var10001 = 42763073020910L ^ 90333867320552L;
      int var10 = Event.cReturningInt();
      int var20 = var10;
      CobwebPlacer var19 = this;
      CobwebPlacer var18 = var19;
      CobwebPlacer var17 = var19;
      if (var20 != 0) {
         Object[] var10006 = new Object[]{null, null, null, 128423612925702L};
         var10006[2] = var3;
         var10006[1] = var2;
         var10006[0] = var1;
         Object[] var12 = var10006;
         CobwebPlacer var11 = var17;
         boolean var21 = var11.aReturningBoolean(var12);
         if (!var21) {
            return;
         }

         CobwebPlacer var22 = this;
         var18 = var22;
      }

      Object[] var16 = new Object[]{15834603765355L};
      CobwebPlacer var15 = var18;
      var15.jReturningVoid(var16);
   }

   private static void lambda$onMotionUpdate$14(BlockHitResult var0) {
      long var10001 = 68143353211546L ^ 61322770836159L;
      Object[] var5 = new Object[]{var0, 11253043183653L};
      ItemUseUtil.aReturningBoolean(var5);
   }

   private boolean lambda$new$13(Color var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.f;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Auto";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.t;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$12(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$11(Integer var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.f;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Auto";
      String var6 = var10000;
      byte var25 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var18 = var4;
      byte var17 = var25;
      byte var13 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            return false;
         }

         ModeSetting var9 = this.r;
         var10000 = (String)var9.aReturningObject();
         String var11 = "Slot";
         String var10 = var10000;
         byte var20 = ((byte)((var10.equals(var11)) ? 1 : 0));
         var13 = var20;
      }

      int var22 = var4;
      byte var21 = var13;
      byte var15 = var21;
      byte var14 = var21;
      if (var22 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var15);
      } else {
         byte var23 = var14;
         if (var23 != 0) {
            var15 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var15);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$10(String var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$9(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$8(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$7(String var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$6(Integer var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.f;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Manual";
      String var6 = var10000;
      byte var35 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var24 = var4;
      byte var23 = var35;
      byte var17 = var23;
      byte var16 = var23;
      if (var24 == 0) {
         byte var25 = var16;
         if (var25 == 0) {
            return false;
         }

         BooleanSetting var9 = this.l;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var26 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var17 = var26;
      }

      int var28 = var4;
      byte var27 = var17;
      byte var19 = var27;
      byte var18 = var27;
      if (var28 == 0) {
         byte var29 = var18;
         if (var29 != 0) {
            return false;
         }

         ModeSetting var13 = this.m;
         var10000 = (String)var13.aReturningObject();
         String var15 = "Slot";
         String var14 = var10000;
         byte var30 = ((byte)((var14.equals(var15)) ? 1 : 0));
         var19 = var30;
      }

      int var32 = var4;
      byte var31 = var19;
      byte var21 = var31;
      byte var20 = var31;
      if (var32 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var21);
      } else {
         byte var33 = var20;
         if (var33 != 0) {
            var21 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var21);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$5(String var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.f;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Manual";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.l;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 == 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$4(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Manual";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$3(Integer var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.f;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Auto";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 == 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.j;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$2(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Integer var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Auto";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(107669148576225L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[9];
      String var17 = "L\u00995\u0091H4\u0092õöýHl)\"®\u008ad ¾GF±\u0001_À¢\u0092ÿÇ\u009e9¶\u0010\u0012]ZÕ\u0019ô+Ï`\u000bxá\u0005få\u0080\u0010ëæ·ãsÿ!h>¡ª\u0007ø\u0006\u0080\u008d\u0010\u0010¯\u00adhYj¥\u0095j\u0095ï\f\u009e\u0005~¿\u0010V\u008e\u0005Èx\u0096Ñ6\u0014\u0095Ôî¯_åy\u0010Ï\u0011é.\u0012\u00188Ëé}ù¿$\u0011\u008et\u0010ý&ÿëRñ:wÃk«K\bwÂÎ";
      int var19 = "L\u00995\u0091H4\u0092õöýHl)\"®\u008ad ¾GF±\u0001_À¢\u0092ÿÇ\u009e9¶\u0010\u0012]ZÕ\u0019ô+Ï`\u000bxá\u0005få\u0080\u0010ëæ·ãsÿ!h>¡ª\u0007ø\u0006\u0080\u008d\u0010\u0010¯\u00adhYj¥\u0095j\u0095ï\f\u009e\u0005~¿\u0010V\u008e\u0005Èx\u0096Ñ6\u0014\u0095Ôî¯_åy\u0010Ï\u0011é.\u0012\u00188Ëé}ù¿$\u0011\u008et\u0010ý&ÿëRñ:wÃk«K\bwÂÎ"
         .length();
      char var16 = ' ';
      int var23 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var24.getBytes("ISO-8859-1"));
            String var33 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var23 += var16) >= var19) {
                     I = var20;
                     J = new String[9];
                     N = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(107669148576225L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     String var4 = "\u0007\u0082Á}Kü+iG¨»²\u001c\u0005\u008d\u0080";
                     int var5 = "\u0007\u0082Á}Kü+iG¨»²\u001c\u0005\u008d\u0080".length();
                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var10001] = var10004;
                     } while (var2 < var5);

                     L = var6;
                     M = new Integer[2];
                     break;
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label45;
                  }

                  var17 = "f\u0087\\Ýö\u001bÌq\u0000ãtG\u009a^Âì\u0018\u0003kêìi/.\u0006\u0005\u0014ö\u0082R¡Vº~ó%\u009fEvw«";
                  var19 = "f\u0087\\Ýö\u001bÌq\u0000ãtG\u009a^Âì\u0018\u0003kêìi/.\u0006\u0005\u0014ö\u0082R¡Vº~ó%\u009fEvw«".length();
                  var16 = 16;
                  var23 = -1;
            }

            var24 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14590;
      if (J[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])K.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               K.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eu", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = I[var5].getBytes("ISO-8859-1");
         J[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return J[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eu_C0258",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11016;
      if (M[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = L[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])N.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               N.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eu", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         M[var3] = var15;
      }

      return M[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eu_C0258",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = P[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = O[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 28;
            yield var15;
         }
         case 1 -> {
            byte var16 = 32;
            yield var16;
         }
         case 2 -> {
            byte var17 = 48;
            yield var17;
         }
         case 3 -> {
            byte var18 = 43;
            yield var18;
         }
         case 4 -> {
            byte var19 = 29;
            yield var19;
         }
         case 5 -> {
            byte var20 = 15;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 60;
            yield var23;
         }
         case 9 -> {
            byte var24 = 7;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 41;
            yield var26;
         }
         case 12 -> {
            byte var27 = 42;
            yield var27;
         }
         case 13 -> {
            byte var28 = 25;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 17;
            yield var30;
         }
         case 16 -> {
            byte var31 = 24;
            yield var31;
         }
         case 17 -> {
            byte var32 = 12;
            yield var32;
         }
         case 18 -> {
            byte var33 = 14;
            yield var33;
         }
         case 19 -> {
            byte var34 = 33;
            yield var34;
         }
         case 20 -> {
            byte var35 = 19;
            yield var35;
         }
         case 21 -> {
            byte var36 = 40;
            yield var36;
         }
         case 22 -> {
            byte var37 = 21;
            yield var37;
         }
         case 23 -> {
            byte var38 = 46;
            yield var38;
         }
         case 24 -> {
            byte var39 = 27;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 26;
            yield var42;
         }
         case 28 -> {
            byte var43 = 50;
            yield var43;
         }
         case 29 -> {
            byte var44 = 38;
            yield var44;
         }
         case 30 -> {
            byte var45 = 10;
            yield var45;
         }
         case 31 -> {
            byte var46 = 22;
            yield var46;
         }
         case 32 -> {
            byte var47 = 18;
            yield var47;
         }
         case 33 -> {
            byte var48 = 20;
            yield var48;
         }
         case 34 -> {
            byte var49 = 44;
            yield var49;
         }
         case 35 -> {
            byte var50 = 3;
            yield var50;
         }
         case 36 -> {
            byte var51 = 39;
            yield var51;
         }
         case 37 -> {
            byte var52 = 37;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 61;
            yield var54;
         }
         case 40 -> {
            byte var55 = 35;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 11;
            yield var58;
         }
         case 44 -> {
            byte var59 = 31;
            yield var59;
         }
         case 45 -> {
            byte var60 = 4;
            yield var60;
         }
         case 46 -> {
            byte var61 = 56;
            yield var61;
         }
         case 47 -> {
            byte var62 = 49;
            yield var62;
         }
         case 48 -> {
            byte var63 = 9;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 5;
            yield var65;
         }
         case 51 -> {
            byte var66 = 51;
            yield var66;
         }
         case 52 -> {
            byte var67 = 53;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 8;
            yield var69;
         }
         case 55 -> {
            byte var70 = 55;
            yield var70;
         }
         case 56 -> {
            byte var71 = 34;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 59;
            yield var73;
         }
         case 59 -> {
            byte var74 = 45;
            yield var74;
         }
         case 60 -> {
            byte var75 = 54;
            yield var75;
         }
         case 61 -> {
            byte var76 = 52;
            yield var76;
         }
         case 62 -> {
            byte var77 = 0;
            yield var77;
         }
         default -> 16;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            P[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      O[0] = "{(/\u007f\u001f\u000fm(*%\f\u0018zc)#\u0000\fk$>4K\u001cs";
      O[1] = "d\u001bz\u0015Iq\u0011;q\u001aX>p5z\u0011\\d\u0004";
      O[2] = boolean.class;
      P[2] = "java/lang/Boolean";
      O[3] = "b@*\thTt@/S{Cc\u000b,UwWrL;B<EC";
      O[4] = int.class;
      P[4] = "java/lang/Integer";
      O[5] = "\u0003\u0015\u0006n\u0018\u0006\u0015\u0015\u00034\u000b\u0011\u0002^\u00002\u0007\u0005\u0013\u0019\u0017%L\u0013\u0012";
      O[6] = "am\u0002\tR\u000b\u0014M\t\u0006CDuC\u0002\rG\u001e\u0001";
      O[7] = void.class;
      P[7] = "java/lang/Void";
      O[8] = "S>)^\u0000\u001c&\u001e\"Q\u0011SG\u0010)Z\u0015\t3";
      O[9] = "D)>g\u0005`O&/(fmZ+ CSoK8<oDb";
      O[10] = "Ki9|8NKi. 4AQ\".>4TVS~ce";
      O[11] = "-!wM\u0015r-!`\u0011\u0019}7j`\u000f\u0019h0\u001b5P@";
      O[12] = "\u0017LO7\u0010\u001d\u0001LJm\u0003\n\u0016\u0007Ik\u000f\u001e\u0007@^|D\u000b=";
      O[13] = "k\u0014#:,]\u001e4(5=\u0012\u007f:#>9H\u000b";
      O[14] = "]p\u0001L\u001bJKp\u0004\u0016\b]\\;\u0007\u0010\u0004IM|\u0010\u0007OYV";
      O[15] = "s\n\u0019?u \u0006*\u00120dog$\u0019;`5\u0013";
      O[16] = "7eu_^XBE~PO\u0017#Ku[KMW";
      O[17] = "%mFm9uPMMb(:1CFi,`E";
      O[18] = "\u00109\u001a@@\f\u00109\r\u001cL\u0003\nr\r\u0002L\u0016\r\u0003\\X\u0015U";
      O[19] = "yh7\u000f~Zyh SrUc# Mr@dRp\u0017\"\u0003";
      O[20] = "}n?(cDkn:rpS|%9t|Gmb.c7PU";
      O[21] = "\u00166X\u001a\u0013\nc\u0016S\u0015\u0002E\u0002\u0018X\u001e\u0006\u001fv";
      O[22] = "41>5\u001bDA\u00115:\n\u000b \u001f>1\u000eQT";
      O[23] = "C8~\u0019m0U8{C~'BsxEr3S4oR9$_";
      O[24] = "\u001dR\u000f\\\u0014I\u001dR\u0018\u0000\u0018F\u0007\u0019\u0018\u001e\u0018S\u0000hIAJ\u0018";
      O[25] = "t\u0001\u0014Wl\u0004t\u0001\u0003\u000b`\u000bnJ\u0003\u0015`\u001ei;RJ4]";
      O[26] = "`\u001aRG\u0003g`\u001aE\u001b\u000fhzQE\u0005\u000f}} \u0012ZY";
      O[27] = "*{({OC*{?'CL00?9CY7Aka\u0014";
      O[28] = float.class;
      P[28] = "java/lang/Float";
      O[29] = "\u007f:FKzst5W\u0004\u001dqa>WO&";
      O[30] = "0zf@\r:EZmO\u001cu$TfD\u0018/P";
      O[31] = "[\u001f%!C(P\u00104n %E\u0016";
      O[32] = double.class;
      P[32] = "java/lang/Double";
      O[33] = "9X\u0000zr\r\u000f}\u0000zeQ\u0003r\u001a1eO\u0003g\u001d@4\u0010W$U";
      O[34] = ";;93Ah;;.oMg!p.qMr&\u0001\u007f)\u001f";
      O[35] = "29\u000e+o[96\u001fd\u0012C*1\u0016-";
      O[36] = "q'\tME?z(\u0018\u0002$1q#\u001cX";
      O[37] = "p\u0017)-+{n\u001f3bP[S2";
      O[38] = "[`Qm)FM`T7:QZ+W16EKl@&}U\f";
      O[39] = "R'7L/''\u0007<C>hF\t7H:22";
      O[40] = "3q\u0017/ol%q\u0012u|{2:\u0011spo#}\u0006d;x\u0015";
      O[41] = "\n\u000f\u0011,iK\u007f/\u001a#x\u0004\u001e!\u0011(|^j";
      O[42] = "^+P Cy^+G|OvD`GbOcC\u0011\u0016=\u0017";
      O[43] = "?2z\f\u001dZ!:`C\u007fF&'";
      O[44] = ",\u0017`^abY7kQp-89`ZtwL";
      O[45] = "s-t\u001d\u001ec\u0006\r\u007f\u0012\u000f,g\u0003t\u0019\u000bv\u0013";
      O[46] = "\u0016\u0016\n^7\u001b\u0016\u0016\u001d\u0002;\u0014\f]\u001d\u001c;\u0001\u000b,OFoE";
      O[47] = "v+s=\"-\u0003\u000bx23bb\u0005s978\u0016";
      O[48] = "X/O\u0018\u001b\fX/XD\u0017\u0003BdXZ\u0017\u0016E\u0015\n\u000eFW";
      O[49] = "X\u00126k8\u0012X\u0012!74\u001dBY!)4\bE(srlI";
      O[50] = "Fv<N(b3V7A9-RX<J=w&";
      O[51] = "sV1BYc\u0006v:MH,gx1FLv\u0013";
      O[52] = "|0}>$*j0xd7=}{{b;)l<lup2";
      O[53] = "\u0002YJU\u0002\u000bwyAZ\u0013D\u0016wJQ\u0017\u001eb";
      O[54] = "6yqZ{T=v`\u0015\u0017W3tbZ;";
      O[55] = "z<\u0002Qh\"l<\u0007\u000b{5{w\u0004\rw!j0\u0013\u001a<3r";
      O[56] = "F7\u0013\u0006\u0001%3\u0017\u0018\t\u0010jR\u0019\u0013\u0002\u00140&";
      O[57] = "zJ\u001a\u001fo]lJ\u001fE|J{\u0001\u001cCp^jF\u000bT;KG";
      O[58] = "t?v\u000f/8\u0001\u001f}\u0000>w`\u0011v\u000b:-\u0014";
      O[59] = "u9f#j\u000bc9cyy\u001ctr`\u007fu\be5wh>\u001fh";
      O[60] = "(yaw\u0014X]Yjx\u0005\u0017<Was\u0001MH";
      O[61] = "Tu_s@vBuZ)SaU>Y/_uDyN8\u0014bv";
      O[62] = "4P\u001fLs84P\b\u0010\u007f7.\u001b\b\u000e\u007f\")jZP'f";
      O[63] = "v\u0004_\u0012;E\u0003$T\u001d*\nb*_\u0016.P\u0016";
      O[64] = "dT\t8Lp\u0011t\u00027]?pz\t<Ye\u0004";
      O[65] = "E&\rP\u001d{S&\b\n\u000elDm\u000b\f\u0002xU*\u001c\u001bIhM*\u001e\u0010\u0013%q1\u001e\r\u0013bF&";
      O[66] = "L6#\u0000\u000e@9\u0016(\u000f\u001f\u000fX\u0018#\u0004\u001bU,";
      O[67] = "9\u0012@|\"~9\u0012W .q#YW>.d$(\u0006`{!";
      O[68] = "tO[}d\u007ftOL!hpn\u0004L?heiu\u001da=.";
      O[69] = "\u0012u\u001f\u0010\\\n\u0012u\bLP\u0005\b>\bRP\u0010\u000fOX\u0007\u0007V";
      O[70] = "\u000bXl\u0019\u00144~xg\u0016\u0005{\u001fvl\u001d\u0001!k";
      O[71] = "L!\"\u0017\u0006%9\u0001)\u0018\u0017jX\u000f\"\u0013\u00130,";
      O[72] = "GyrwX62YyxIySWrsM#'";
      O[73] = "\u000f\u001b>4#C\u0019\u001b;n0T\u000eP8h<@\u001f\u0017/\u007fwU>";
      O[74] = "\u0006D\u0001H tsd\nG1;\u0012j\u0001L5af";
      O[75] = "+i)\u001fqz^I\"\u0010`5?G)\u001bdoK";
      O[76] = "k\u0000\u001f7#b`\u000f\u000exKbn\u0000\u001d";
      O[77] = "\u0001]BI\u001f3t}IF\u000e|\u0015sBM\n&a";
      O[78] = "\u001bxA)eonXJ&t \u000fVA-pz{";
      O[79] = "^h1\rn8+H:\u0002\u007fwJF1\t{->";
      O[80] = "pgWeJi\u0005G\\j[&dIWa_|\u0010";
      O[81] = "{u\u001b^&Nmu\u001e\u00045Yz>\u001d\u00029Mky\n\u0015rZi";
      O[82] = "7*\u001d\u0007\"xB\n\u0016\b37#\u0004\u001d\u00037mW";
      O[83] = "xE5L`F\re>Cq\tlk5HuS\u0018";
      O[84] = "X@?$\u001a\u0004-`4+\u000bKLn? \u000f\u00118";
      O[85] = "s,z\u000026e,\u007fZ!!rg|\\-5c kKf$A";
      O[86] = "l&~KRe\u0019\u0006uDC*x\b~OGp\f";
      O[87] = "0n\t~ \"&n\f$351%\u000f\"?! b\u00185t\"";
      O[88] = "8z\u007f\u0004V6MZt\u000bGy,T\u007f\u0000C#X";
      O[89] = "F^%t\u001f\u001d3~.{\u000eRRp%p\n\b&";
      O[90] = "J\"G\u0011i0?\u0002L\u001ex\u007f^\fG\u0015|%*";
      O[91] = "\u0011\u001fA\u007f=V\u0011\u001fV#1Y\u000bTV=1L\f%\u0004fa\f";
      O[92] = "g\u0019\u0000sd\u001f\u00129\u000b|uPs7\u0000wq\n\u0007";
      O[93] = "_J4_Uo*j?PD Kd4[@z?";
      O[94] = "Hz\u0001pIM=Z\n\u007fX\u0002\\T\u0001t\\X(";
      O[95] = "X%n *\n-\u0005e/;EL\u000bn$?\u001f8";
      O[96] = "\u0013'}\u0015/Lf\u0007v\u001a>\u0003\u0007\t}\u0011:Ys";
      O[97] = ",5\u001eu\u0015xY\u0015\u0015z\u000478\u001b\u001eq\u0000mL";
      O[98] = "j%\u001e%qH|%\u001b\u007fb_kn\u0018ynKz)\u000fn%\\_";
      O[99] = "a\u001bA\u0011gk\u0014;J\u001ev$u5A\u0015r~\u0001";
      O[100] = "Y}BC\u0013z,]IL\u00025MSBG\u0006o9";
      O[101] = "p}\u0004,t{\u0005]\u000f#e4dS\u0004(an\u0010";
      O[102] = "\u0003'k\u0004P0v\u0007`\u000bA\u007f\u0017\tk\u0000E%c";
      O[103] = "J\rRe\u0003\u0010?-Yj\u0012_^#Ra\u0016\u0005*";
      O[104] = "GpH%(82PC*9wS^H!=-'";
      O[105] = "F2'o[l3\u0012,`J#R\u001c'kNy&";
      O[106] = "es\"\u000b)`ss'Q:wd8$W6cu\u007f3@}tI";
      O[107] = "\u0015mGH5\r`MLG$B\u0001CGL \u0018u";
      O[108] = "e2#\u001c*)s2&F9>dy%@5*u>2W~=J";
      O[109] = "\n\u0007>9aX\u007f'56p\u0017\u001e)>=tMj";
      O[110] = "$XX\u0001\u0002C2X][\u0011T%\u0013^]\u001d@4TIJVW\r";
      O[111] = "CY%7\t96y.8\u0018vWw%3\u001c,#";
      O[112] = "%\b\u0019:BJP(\u00125S\u00051&\u0019>W_E";
      O[113] = "q$\u0001qX\u0018q$\u0016-T\u0017ko\u00163T\u0002l\u001eGl\r";
      O[114] = "; q\u0004\u0000\u0015; fX\f\u001a!kfF\f\u000f&\u001a6\u001f^N";
      O[115] = "B*\u0010pCX\\\"\n?>H\\";
      O[116] = "fA\u000bli)\u0013a\u0000cxfro\u000bh|<\u0006";
      O[117] = "q\u001fYkg\u0003\u0004?RdvLe1Yor\u0016\u0011";
      O[118] = "\u0006G'VJtsg,Y[;\u0012i'R_af";
      O[119] = "\u0016\u0001\u001ckIN\u0016\u0001\u000b7EA\fJ\u000b)ET\u000b;Y|\u0016\u0015";
      O[120] = "5O\u001aJdu5O\r\u0016hz/\u0004\r\bho(u\\R<";
      O[121] = "?l\u0013l\b\u0005>6\u001am\u0004xl\nBj\b\u0003|a\u0003s\u0000D7\nAd\u001bFm0\u0011l\u0005\u0002a\n";
      O[122] = ")I2\u001b.i#G=\u001bJ;\u0012\u0003%\u00171+yB<\u001fv`\u0012V/D*m}\u0006r\u0016)Q";
      O[123] = ",e#]\u0017#&k,]sc\u0017/4Q\ba|n-YO*\u0017(d^\u001d*~m#P\u000f\u001b";
      O[124] = ">aw\u0006Pud |\u0000\nKmX?S^0~3~JVw5X?\u0003GwafeBLq;X";
      O[125] = "M\tR>\u0006cG\u0007]>b6vCE2\u0019!\u001d\u0002\\:^jv@L:\u00100G\u0005G4\u0012[";
      O[126] = "'e+\tlmemjH\u001d2ycpUJe'3)9|fye\u007f\u0004%l`s";
      O[127] = "2\u0015\u000b\u00132\rdDG\u001c2wg(\u0000\u000b`\fqCA\u0012hK:(\u0007[o\u0019:AB\u001ca\u000b\u000b";
      O[128] = "6\r\u0000U?W0\u001c[QPP:\u000f\u0005\u000b<blMYQm55\u0002\f\u0000nPk\n[\u001eP";
      O[129] = "RC*\u0014fiTRq\u0010\tn^A/Je\\\t\u0001r\u00144\u000bS\u0001r\u001ckeN\u0007sU\t";
      O[130] = "Hz\f)\u0004\b\u001d:O)e\\Mdt1\u0006WQg\u00114\u001a\u0002F\u0002\u00117\u000bDIg\u0014+^S,g\u0017:\u0018\\Ib\u000bo\u000f9";
      O[131] = "\u000e\u0000guD\bB\u001e{!z_>Jvq\u0001LU\u000boyF\u0007>I\u007fy\b]\u000f\ftw\n6";
      O[132] = " 7*\t5'vff\u00065]s\n!\u0011g&ca`\boa(\nt\u001b4=%e$Ff>\u0019";
      O[133] = "x\\Ck\b\u0013-\u001c\u0000kiYe^G\u0016\fArY^s\t]'N;s\nLaA^v\u0016\u0019v$";
      O[134] = "\u000b\u001f+$C1G\u00017p}f;U: \u0006uP\u0014#(A>;Rj/\u0013>R\u0017-!\u0001\u000f";
      O[135] = "J\\{S1:[L\u007fBX)CV9Q#WL^?Li3DO.\\X";
      O[136] = "kE\u00027RoaK\r76>P\u000f\u0015;M-;N\f3\nfP\f\u001c3D<aI\u0017=FW";
      O[137] = "\u001d\u007fr[AO\u001bn)_.H\u0011}w\u0005BzG:*]\u0017-\u001b<y\u0010\u0015_\u001dq~\u000e.";
      O[138] = "`*)R\u0017Y<4 \u0013-\u0004~72\u000bVi\u007frj\u0006U\nes5P-Pg))\u0004\u001c\u0015l'+o";
      O[139] = "!R82\u0011\t:_{\"xZ P,<\u00037!\u0015t1\u0000T;\u0014+gx\u000e9N73IK2@5X";
      O[140] = "rp$F%Yz}sCW\\\u000b'#M,O`f:Ek\u0004\u000bx)H*Pn}5\u001d=5";
      O[141] = "b\u00166Zh\u0016h\u00189Z\fMY\\!VwT2\u001d8^0\u001fY[qYb\u001f0\u001e6Wp.";
      O[142] = "\r@\u0013\t\u001c%\u0010F\u0012@~.\u0000\u0000N_\u0012\u001cTD\u0014\u0006FKVEQ\u0006\u001d6\u0016\u001c\u0014\u0004~";
      O[143] = "`ITi\nD!Y[)\u0014;07\u0011~\u000e@#\\Pg\u0006\u0007h7\u0016.\u0001Uh^Si\u000fGY";
      O[144] = "nn+E*\u0003aex\u001fP\u001ehb!@<,? {\u001dh{?w.M;\nk{(_;{e\"|\u00162\u0015x$}_PAos+[j\u001f?q+YP";
      O[145] = "kxT'\u0014\u000b;%\u0006$(\r\u0004!\u0005,S\u001eo`\u001c$\u0014U\u0004\"\f$Z\u000f5g\u0007*Xd";
      O[146] = "\beQ ?0\u0015cPi];\u0005%\fv1\tQaT!a^\beQ ?0\u0015cPi]";
      O[147] = "Zh&Yag\t&/A ^\u000e7!W0\tYmv\b\\;\u000381V9>\u001fm&";
      O[148] = "NR\u0017#E'H\u001f\u0010=~0D\u0013\u00196\u0012\u0002\u0010WCj~0J\u0001\u00044\u001b5VT\u0013Q\u001b6G\u0012\u001c4\u001e*\u0012\u0005y4\u001d;T\n\u001c1\u0001nCo\u001el\u0010'\u0012\u001d\u0018!\u00179)";
      O[149] = "*^|JWli\u001axLY\\u\f?@@0GX~\u001b\u001ac\u0010\u0004 NZ9u\u0001<\u001bM\\+X<\u001eD!k\u0001y\u001c'";
      O[150] = "}]\u0001]q4i\u0012WTIio\u001c\u000f\u000b%[?PU]I6<\n\u0005Qper\u0003\u001d\u0010I";
      O[151] = "I\u0012.$[\u0014FLa\u001c^z\u001f\u00185gM\u0011^\u0001= \u0006z\u001c\u0011=n\\KY\u001a3l7";
      O[152] = "\bOU/8YUV\u00064\\\u0007\tP\u0004+05]\u0011[rmb]L\u0007>7S\u0018G\t<\\";
      O[153] = "\u0006\u0004\u001e}\u001aB\u0000\u0015EyuE\n\u0006\u001b#\u0019wYCByu\u0019\u0007\u0019\t/D\\\f\u0017\u000bD";
      O[154] = "\u000f\u0006/\u0018$G\u0001Gp\u0004DNf\u0000y\u0003?Z\rA`\u000bx\u0011f\u0003p\u000b6KWF{\u00054 ";
      O[155] = ";\u000e<\u001a\u0000C1\u00003\u001ad\u0019\u0000D+\u0016\u001f\u0001k\u00052\u001eXJ\u0000C{\u0019\nJi\u0006<\u0017\u0018{";
      O[156] = "\b/VL03HyT\\P6\u0019-P]\u0007hGp\n1!gF!R\u000b51\u0007{";
      O[157] = "]a1\u0017\u0002\u0002S n\u000bb\t4gg\f\u0019\u001f_&~\u0004^T4>bW\u001aYL<c\u001a\u0019e";
      O[158] = "eL*h\\PoB%h8\u0001^\u0006=dC\u00125G$l\u0004Y^\u0005laX\tnL->S\u0018^";
      O[159] = "gYH7\bki\u0018\u0017+he\u000e_\u001e,\u0013ve\u001e\u0007$T=\u000eXN#\u0006=g\u001d\t-\u0014\f";
      O[160] = "\u001dMr/^PMF<&O @\u0013B;\r\u0011N\u0005!!\fN\u0018}xs\u0005LL\r(xKE]}";
      O[161] = "5uH\u0010\u000e\b0'X^\u000e0f+T\u0006\tYj\u0012Z\u0006\u0019]\fuS\u0001\u0016[=0X\u000f\u00140";
      O[162] = "\u001ev8-_HB%95gL$|z6YDY<#s['";
      O[163] = "P\u000e+Ve!\u0017QoKc\u001b\u00004kBu`\u0013_*[}'X4hK}i\u0002\u0005-@ski";
      O[164] = "9w`)\u001cMa=u5\u0003pjL(%\u0016\u000bz'i<\u001eL1L+,\u001e\u0002k}n'\u0010\u0000\u0000";
      O[165] = "?1Y?jX9|^!QD9aS!\u0006\u0013c1\u000fM4I6qR(1Ucf";
      O[166] = "\u0017QJ\u0011dYUY\u000bP\u0015\u0006IW\u0011MBQ\u0017\u0000I!t\u0016M\u0003\u001aCr\u0007\u0016\u0007";
      O[167] = "^\r\u0004}\u0018{\u000ePV~$}1TUv_nZ\u0015L~\u0018%1\fMtH*TRE#V\u0014";
      O[168] = "V\u0004\u0014F\u0001M\u0012\u000e\u001d\u001eoWQ9\u001aX\u0013G*M\u001fC\u001d]\u001b\b\u0014M\u001f6";
      O[169] = ")0NFW\u000fodP\\Pqu6^]W\u001dGb\u001d\u0002\u000fN\u0010;\u001e\u0000\u0001\u0013~&\u0018\u0001Hq";
      O[170] = "XlT\u0019<o\u0006<V\u0019>U\u0007kE\u0013'95?\u0000JxU[fZ\u0001+d\u001emT\u0003@";
      O[171] = "9\u0003qC|%;\u0002<@@#3\u000b<V\u00073ZTxD~>'\u0014!\u0001|]9\u0003qC|%;\u0002<@@";
      O[172] = "18\\\u0010?(?y\u0003\f_+X>\n\u000b$53\u007f\u0013\u0003c~X=\u0003\u0003-$ix\b\r/O";
      O[173] = "w4i}\r|'i;~1y\u0018m8vJis,!~\r\"\u00185 t]-}k(#C\u0013";
      O[174] = "\u001f\u001f\u0014Ad\u0002\u001c\u0017\u0007Si:H\u0014\tF|dO\u0014\u0013B\u0000XW\u0019\u0002\u0011e\u0006_N\u001c/";
      O[175] = "X`\u0015 \\\u0012Ip\u001115\u001aUrJ(Y(\u00016\u0013r\u000e\u007fX`\u0015 \\\u0012Ip\u001115";
      O[176] = "D1'\u001dG7U!#\f.?I#x\u0015B\r\u001dg!L\u0012Z\u001ffgLM'_?\"N.";
      O[177] = "\u001d\rOBL\u0017K\\\u0003MLmM0DZ\u001e\u0016^[\u0005C\u0016Q\u00150\u0011PM\r\u0018_A\r\u001f\u000e$";
      O[178] = "M\u000e9n1QKC>p\nFGO7{ft\u0013\u000bl%\nFI]*yoCU\b=\u001co@DN2yj\\\u0011YWyiMWV2|u\u0018@30!dQ\u0011A6lcO*";
      O[179] = "y\u0015w\u001cV:s\u001bx\u001c2kB_`\u0010Ix)\u001ey\u0018\u000e3B\u00024\u0015@90\u0004y\u0012^\u0002";
      O[180] = "e\u001b\u007f9(fo\u0015p9L7^Qh57$5\u0010q=po^Rj279 \u0014>,->^";
      O[181] = "v\b>\u0001{gpE9\u001f@p|I0\u0014,B(\u0005`K}\u0015tV>\u000e%pqJk\u0019@pr[-\u0016%un\u000e:s%v\u007fH5\u0016 j*_P\u0014}{c\u000e\"\u00120|}5";
      O[182] = "d!e?5\u0015k*6eO\bb-o:#:5o5gpmc2>>+V>+m%O";
      O[183] = "\u001eP\u001bDw\"\b\t]\u0000\u000b(s\n\nUp8\u0018K\u0013]7ss\rZZes\u001aH\u001dTwB";
      O[184] = " i\u0005N\u0019xu)FNx,-a}V\u001b'9t\u0018S\u0007r.\u0011\u0018P\u00164!t\u001dLC#Dt\u001e]\u0005,!q\u0002\b\u0012I";
      O[185] = "K\r4\r_\n\u0017\u0013=LeZE\u0016&{\u0002VAm}\t\u001a\u0004O\u0010=P_\u0006,";
      O[186] = "\u000bj4\u001c?A\u0016l5U]J\u0006*iJ1xRn1\u001cf/\u000b86B4B\u001a(2S]OWk8O3RQjq-";
      O[187] = "\u0003/e'GL\u0005>>#(K\u000f-`yDyYo<#\u0014.\u0000 ir\u0016K^(>l(";
      O[188] = "Es\n~KH\u0007{K?:\u001c\u0017dU)V.C%\u000b\u007f:@\u001a{G%\u000b\u0005\u0011uEN";
      O[189] = "8B\"OI7:CoLu.=RL^\u001126.)\u000e\nq8SiWOs[";
      O[190] = ")0JN\u0000C#>ENd\u0017\u0012z]B\u001f\u0001y;DJXJ\u0012yTJ\u0016\u0010#<_D\u0014{";
      O[191] = "\\_h>\u0014)\u0000\u001ch(EL\u000fc7(\u00147\u001c\bv1\u001cpWc7}\u001a3\r\u0006k>\u001a%\\c";
      O[192] = "x7Cs\u000eB~zDm5^~gImb\t$7\u0017\u0001PSqwHdUO$`";
      O[193] = "4Z_fq~%J[w\u0018v9H\u0000ntDm\fY7%\u0013o\r\u001f7{n/TZ5\u0018";
      O[194] = "Q\u00005TT:WM2Jo&WP?J8q\r\u0000b&\n+X@>C\u000f7\rW";
      O[195] = "\rdU\u0017\u0014\u0000\u0007jZ\u0017p_6.B\u001b\u000bB]o[\u0013L\t6)\u0012\u0014\u001e\t_lU\u001a\f8";
      O[196] = "3\u0001\u001f\u0001-\\{@T^|dw0\u001c^(\u000baM\u001d\u0004!\nm";
      O[197] = "\u0013>w\u0019Sd\u0003vs\u0015o6its\u001e\u0014%\u00025j\u0016Sni2}\u0017\u0000'\u0005tp\u000f\b_";
      O[198] = ":Xpk\u0014'i\u0016ysU\u001en\u0007weEI9] 9){c\bgdL~\u007f]p";
      O[199] = "g\"Xy7:%*\u00198Fe9$\u0003%\u00112gwZI:l:&\u001f%|a\".";
      O[200] = "Ep\u001ar<qXv\u001b;^zH0G$2H\u0019}\u0019xa\u001f@/I>;zE3\u001c)^zF\"Z&;\u007fZwMC;|K1B&>`\u001e&'#b\"\u0014.I>d#]L";
      O[201] = "\u0011\u0018&1BlS\u0010gp33O\u001e}mdd\u0010C&\u0001\f$B\ngbAeT\u0010";
      O[202] = "\u001ct\u001b%n=X~\u0012}\u0000)\rxpx99^g\r8`|\\\u0004\b{1/\u0018g\u0012zny`";
      O[203] = "\u001e|\u0005?\u001dwK<F?|/\u0010\u007f}'\u001f(\u0007a\u0018\"\u0003}\u0010\u0004\u0018!\u0012;\u001fa\u001d=G,z";
      O[204] = "\u0001\u0015qf`E\u001c\u0013p/\u0002N\fU,0n|X\u0011vi9+Z\u00103iaV\u001aIvk\u0002";
      O[205] = "\u0011\u0017zE\fw\u0019\u0014}G\b\u001dGt-B\rfR\u001fl[\u0005!\u0019t*\u0012\u0002s\u0019\u001doU\fa(";
      O[206] = ",L\u0012;\u0004/<\u0004\u001678~V\u0006\u0016<Cn=G\u000f4\u0004%V^\u000e>T*3\u0000\u0006iJ\u0014";
      O[207] = "G\u0013\u0017+-\u0010H\u0018DqW\rA\u001f\u001d.;?\u0016]Gpjh\u0015\u0003\u001e;<YP\b\u00109W";
      O[208] = "\u0015.KMp,\u001bo\u0014Q\u0010&|(\u001dVk1\u0017i\u0004^,z|+\u0014^b Mn\u001fP`K";
      O[209] = "pI\u00046Zd~\b[*:b\u0019OR-Ayr\u000eK%\u00062\u0019L[%Hh(\tP+J\u0003";
      O[210] = "\u0016\t<=pOZ\u0017 iN\u0018&C-95\u000bM\u000241r@&B}-p\u0012[\u0002$hrq";
      O[211] = "\nc\u0001,I\\\u001e,W%q\u0001\u0018\"\u000fz\u001d3H`Q\"q\u001c\n#\u0005tO\u0007\u0007`\u0015\u001d";
      O[212] = "\\a)>h<\u00002(&P9fkk%n0\u001b+2`lS";
      O[213] = "42ff$q:s9zDu]40}?l6u)ux']79u6}lr2{4\u0016";
      O[214] = "\r\bL\u001e>L\u0010\u000eMW\\G\u0000H\u0011H0uT\fK\u0011`\"V\r\u000e\u0011?_\u0016TK\u0013\\";
      O[215] = "!4Kc+$+:DcOg\u001a~\\o4fq?Egs-\u001ay\f`!-s<Kn3\u001c";
      O[216] = "}\u0016B>$fw\u0018M>@8F\\U2;$-\u001dL:|oF[\u0005=.o/\u001eB3<^";
      O[217] = "\u0019\fel77\u0011\u00012iE0`[bg>!\u000b\u001a{oyj`\u00066b7`\u0012\u0000{e)[";
      O[218] = "(:\t\u001a\u001c\u0010\"4\u0006\u001axB\u0013p\u001e\u0016\u0003Rx1\u0007\u001eD\u0019\u0013-J\u0013\n\u0013a+\u0007\u0014\u0014(";
      O[219] = "St\"tu{\u0005%n{u\u0001\u0004I)l'z\u0010\"hu/=[I*e/s\u0001xon!qj";
      O[220] = "?\\\u0010a\u0010%:\rMg\u001d@ob\n#J)~\u0001\u0010\"\u0015\u007f\u0006";
      O[221] = "s\u0002\u0018!\u0006\u0013u\u0013C%i\u0014\u007f\u0000\u001d\u007f\u0005&/CF)iH-@\u0017z\t\u0011o\u0019Cci\u0013c\u0015\u0011&\fMkB\u000f\u0018";
      O[222] = "w{^cM\u000f!*\u0012lMu FU{\u001f\u000e4-\u0014b\u0017I\u007fFR+\u0010\u001b\u007f/\u0017l\u001e\tN";
      O[223] = "h7~hj6>f2gjL>\nup87+a4i0p`\nr 7\"`c7g90Q";
      O[224] = "=B\u0001\u001ac\nk\u0013M\u0015cpi\u007f\n\u00021\u000b~\u0014K\u001b9L5\u007f\rR>\u001e5\u0016H\u00150\f\u0004";
      O[225] = "jG|i\fq2\riu\u0013L:|4e\u00067)\u0017u|\u000epb|35\t\"b\u0015vr\u00070S";
      O[226] = "\r\n=4wp\u0010\f<}\u0015s\u0014Kian\u001e\u0015\u000e1lm}\u000f\u000fn:\u0015'\rUrn$b\u0006[p\u0005";
      O[227] = "v;2~v\u0011g+6o\u001f\u0019{)mvs+/m4-/|-lr/|\u0001m57-\u001f";
      O[228] = "mu*\u0007\u001e\u001a%4aXO\"3D)\u0003ASm>\u007fR\r\\m";
      O[229] = "o\u0004\u0010,\fPaEO0l^\u0006\u0002F7\u0017MmC_?P\u0006\u0006\u0003\u0016#RT{COfP7";
      O[230] = "\u001dzogh%\u0017t`g\fx&0xkwgMqac0,&7(db,Orojp\u001d";
      O[231] = "?*?\u0000\u000f;ly0\u0017\rUh\"-\n\n\u0002?{{R]U?).\rX8}:<\u0005\u0014";
      O[232] = "Rl7{\t\rT!0e2\u001aX-9n^(\fic32\u0018\b?+2@\u001eE85\tW\u001c[,<lR\u0000\u000e;Y";
      O[233] = "Q\u0015\u0019\u0017d0^\u001eJM\u001e-W\u0019\u0013\u0012r\u001f\u0006XOJ\"H\u0003\u0005\u0010\u0007uyF\u000e\u001e\u0005\u001e";
      O[234] = "\u0004Q\u0017{\u000fJI\u0010\u0001aqLVT\u001be\u001d~\u0000\u0011E:N)\u0000\u0011\u0004<\u0012T@HA>q";
      O[235] = "Ek\u0012Vl\u001b\b*\u0004L\u0012\u001d\u0017n\u001eH~/J)D\u0017\u0012\u0018F/OM|\u0005@.\u0006/y\b\u0010p\u0004Wv\u0003C*~";
      O[236] = "VRj{G`\\\\e{#!m\u0018}wX\"\u0006Yd\u007f\u001fim\u001f-xMi\u0004Zjv_X";
      O[237] = "\u001ey5\u000e3c\u0016tb\u000bAfg.2\u0005:u\fo+\r}>gsf\u000034\u0015u+\u0007-\u000f";
      O[238] = "\u001dY!?&v\u0017W.?B*&\u00136394MR/;~\u007f&\u0014f<,\u007fOQ!2>N";
      O[239] = "V##44.Xb|(T#?%u//3Tdl'hx?cl/2'D'f&jI";
      O[240] = "HT6+7_\\\u001b`\"\u000f\u0002Z\u00158}c0\u000eYg+?gPT6h4\u0015V\u00191v\u000f";
      O[241] = "=%\u0014k)S}4\u0014n60mHU}3K~#\u0014d;\f5H\u0010)6\u0001<p\u0004f`\b\u0004";
      O[242] = "n\u0018?M~1d\u00160M\u001abUR(Aas>\u00131I&8U\u000f|Dh2'\t1Cv\t";
      O[243] = "d\u000b\u001f5\\]n\u0005\u001058\f_E\u001e*AX0\u0000[5Iea\u0004\u0019+\u0005\n$A\u0006#8";
      O[244] = "gkm~\u0001fa&j`:qm*ckVC9n:=:s=8q7Hup?o\f])n$8~[di:\u0003";
      O[245] = "x\u000bR}'!r\u0005]}CuCAEq8c(\u0000\\y\u007f(C\u001c\u0011t1\"1\u001a\\s/\u0019";
      O[246] = "\u0010:7{\u0012IVn)a\u00157L<'`\u0012[~hd?E\u000b)6fn\u0007\f[0+i\u00197";
      O[247] = "\u0013\u000b\u001b\u0012\u0013\u0005\u0016QS\r\u0005y@0\u0019\u001a\u0007\u0002S[X\u0003\u000fE\u00180\u0019HT\u0018VL\u001c\u0012\u001c\u0007@0";
      O[248] = "JA,;8_@O#;\\\u001dq\u000b;7'\u001d\u001aJ\"?`Vq\fk82V\u0018I,6 g";
      O[249] = "t\u000eZEmX{P\u0015}k6\"\u0004A\u0006{]c\u001dIA06z\u001cC\u0011?S$\u0014\u0014\u000f\u0001";
      O[250] = "PqhIBz\u00077#\u0005\u0007\u0019\u0007j>_UNV4b\u00029 \u00130!@ZwU{m\u0005";
      O[251] = "\u0015Fp\u0018v\"S\u0012n\u0002q\\I@`\u0003v0{\u0014#\\!d,Mr\\~5A\\bXo\\";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = O[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(P[var4]);
            O[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = O[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = P[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            O[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  O[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2539727508145651L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = O[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = P[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  O[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2539727508145651L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        O[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2539727508145651L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 162;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 75;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 205;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 66;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 243;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 252;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 162;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 75;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 205;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eu_C0258",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(CobwebPlacer var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eu_C0258;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eu_C0258", "lambda$new$4", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((CobwebPlacer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(CobwebPlacer var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eu_C0258;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eu_C0258", "lambda$new$6", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((CobwebPlacer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(CobwebPlacer var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eu_C0258;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eu_C0258", "lambda$new$5", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((CobwebPlacer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding4(BlockHitResult var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Lnet/minecraft/util/hit/BlockHitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eu_C0258", "lambda$onMotionUpdate$14", "(Lnet/minecraft/util/hit/BlockHitResult;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((BlockHitResult)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding5(CobwebPlacer var0, BlockHitResult var1, int var2, int var3) {
         MethodHandle var8 = bindingCache5;
         MethodHandle var7 = bindingCache5;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/eu_C0258;Lnet/minecraft/util/hit/BlockHitResult;II)Ljava/lang/Runnable;", MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/eu_C0258", "lambda$performAutoPlace$15", "(Lnet/minecraft/util/hit/BlockHitResult;II)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var5.invokeExact((CobwebPlacer)var0, (BlockHitResult)var1, (int)var2, (int)var3);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Runnable invokeBinding6(int var0, int var1) {
         MethodHandle var6 = bindingCache6;
         MethodHandle var5 = bindingCache6;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(II)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/eu_C0258", "lambda$finishInvSwapPlace$16", "(II)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var3.invokeExact((int)var0, (int)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

    public final boolean recoveryAccess_write_F(boolean value) { return this.F = value; }

    public final boolean recoveryAccess_read_E() { return this.E; }

    public final boolean recoveryAccess_call_dReturningBoolean(java.lang.Object[] p0) { return this.dReturningBoolean(p0); }

   public final void recoveryAccess_call_o(Object[] args) { o(args); }

}
