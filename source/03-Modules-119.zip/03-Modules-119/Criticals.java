package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.PacketUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.KeyBindingUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.PositionAndOnGround;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;

public class Criticals extends Module {
   private ModeSetting a;
   private Entity c = null;
   private int d = 0;
   private boolean i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private static final long k = 92972563950088L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long o;
   private static final Object[] p = new Object[66];
   private static final String[] q = new String[66];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 27161503675705L ^ 111021237305573L;
      var10001 = 27161503675705L ^ 67760244561368L;
      var10001 = 27161503675705L ^ 96560381705210L;
      int var10 = Event.bReturningInt();
      Object[] var13 = new Object[]{40770757828833L};
      Criticals var12 = this;
      boolean var10000 = var12.dReturningBoolean(var13);
      int var71 = var10;
      boolean var70 = var10000;
      boolean var56 = var70;
      boolean var55 = var70;
      if (var71 == 0) {
         boolean var72 = var55;
         if (!var72) {
            return;
         }

         boolean var73 = this.i;
         var56 = var73;
      }

      boolean var74 = var56;
      if (!var74) {
         Object[] var17 = new Object[0];
         AttackEntityEvent var16 = var1;
         Entity var11 = var16.aReturningEntity(var17);
         int var76 = var10;
         Entity var75 = var11;
         Object var58 = var75;
         Entity var57 = var75;
         if (var76 == 0) {
            Entity var77 = var57;
            if (var77 == null) {
               return;
            }

            ModeSetting var19 = this.a;
            Object var78 = var19.aReturningObject();
            var58 = var78;
         }

         label55: {
            label54: {
               label71: {
                  String var95 = (String)var58;
                  String var22 = "Silent";
                  String var21 = var95;
                  var10000 = var21.equals(var22);
                  int var80 = var10;
                  boolean var79 = var10000;
                  boolean var60 = var79;
                  boolean var59 = var79;
                  if (var80 == 0) {
                     boolean var81 = var59;
                     if (var81) {
                        Object[] var10004 = new Object[]{null, 87300319416003L};
                        var10004[0] = 0.0625F;
                        Object[] var25 = var10004;
                        Criticals var24 = this;
                        var24.jReturningVoid(var25);
                        var10004 = new Object[]{null, 87300319416003L};
                        var10004[0] = 0.0F;
                        Object[] var27 = var10004;
                        Criticals var26 = this;
                        var26.jReturningVoid(var27);
                        int var82 = var10;
                        if (var82 == 0) {
                           return;
                        }
                     }

                     this.c = var11;
                     int var83 = var10;
                     if (var83 != 0) {
                        break label71;
                     }

                     ModeSetting var30 = this.a;
                     String var97 = (String)var30.aReturningObject();
                     String var32 = "Legit";
                     String var31 = var97;
                     boolean var84 = var31.equals(var32);
                     var60 = var84;
                  }

                  boolean var85 = var60;
                  if (!var85) {
                     break label54;
                  }

                  Object[] var34 = new Object[]{136670736201180L};
                  KeyBindingUtil.aReturningVoid(var34);
               }

               int var86 = var10;
               if (var86 == 0) {
                  break label55;
               }
            }

            MinecraftClient var36 = b;
            ClientPlayerEntity var98 = var36.player;
            MinecraftClient var37 = b;
            ClientPlayerEntity var38 = var37.player;
            Vec3d var39 = var38.getVelocity();
            double var10003 = var39.x;
            MinecraftClient var40 = b;
            ClientPlayerEntity var41 = var40.player;
            Vec3d var42 = var41.getVelocity();
            double var104 = var42.y + 0.15;
            MinecraftClient var43 = b;
            ClientPlayerEntity var44 = var43.player;
            Vec3d var45 = var44.getVelocity();
            Vec3d var47 = new Vec3d(var10003, var104, var45.z);
            ClientPlayerEntity var46 = var98;
            var46.setVelocity(var47);
         }

         Criticals var68;
         int var69;
         label38: {
            ModeSetting var49 = this.a;
            String var101 = (String)var49.aReturningObject();
            String var51 = "Legit";
            String var50 = var101;
            byte var102 = ((byte)((var50.equals(var51)) ? 1 : 0));
            int var89 = var10;
            byte var88 = var102;
            Criticals var87 = this;
            Criticals var65 = var87;
            int var66 = var88;
            Criticals var61 = var87;
            byte var62 = var88;
            if (var89 == 0) {
               byte var91 = var62;
               Criticals var90 = var61;
               Criticals var67 = var90;
               Criticals var63 = var90;
               if (var91 == 0) {
                  var69 = 1;
                  var68 = var67;
                  break label38;
               }

               Criticals var92 = var63;
               Criticals var64 = var92;
               var66 = (int)o;
               var65 = var64;
            }

            int var94 = var66;
            Criticals var93 = var65;
            var68 = var93;
            var69 = var94;
         }

         var68.d = var69;
         Object[] var54 = new Object[0];
         AttackEntityEvent var53 = var1;
         var53.aReturningVoid(var54);
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 39671804941637L ^ 1101145240996L;
      int var6 = Event.bReturningInt();
      Object[] var8 = new Object[]{40770757828833L};
      Criticals var7 = this;
      boolean var10000 = var7.dReturningBoolean(var8);
      int var32 = var6;
      boolean var31 = var10000;
      boolean var23 = var31;
      boolean var22 = var31;
      if (var32 == 0) {
         boolean var33 = var22;
         if (!var33) {
            return;
         }

         boolean var34 = this.i;
         var23 = var34;
      }

      int var36 = var6;
      boolean var35 = var23;
      boolean var25 = var35;
      boolean var24 = var35;
      if (var36 == 0) {
         boolean var37 = var24;
         if (var37) {
            return;
         }

         Object[] var13 = new Object[0];
         PacketSendEvent var12 = var1;
         var25 = var12.aReturningVoid(var13) instanceof HandSwingC2SPacket;
      }

      Criticals var30;
      label48: {
         int var39 = var6;
         boolean var38 = var25;
         boolean var29 = var38;
         boolean var26 = var38;
         if (var39 == 0) {
            boolean var40 = var26;
            if (!var40) {
               return;
            }

            int var42 = var6;
            Criticals var41 = this;
            var30 = var41;
            Criticals var27 = var41;
            if (var42 != 0) {
               break label48;
            }

            Criticals var43 = var27;
            Criticals var28 = var43;
            ModeSetting var16 = var28.a;
            String var47 = (String)var16.aReturningObject();
            String var18 = "Silent";
            String var17 = var47;
            boolean var44 = var17.equals(var18);
            var29 = var44;
         }

         boolean var45 = var29;
         if (var45) {
            return;
         }

         var30 = this;
      }

      Entity var46 = var30.c;
      if (var46 != null) {
         Object[] var21 = new Object[0];
         PacketSendEvent var20 = var1;
         var20.aReturningVoid(var21);
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 51706577931884L ^ 80170075994500L;
      int var6 = Event.cReturningInt();
      int var20 = var6;
      Criticals var19 = this;
      Criticals var16 = var19;
      Criticals var15 = var19;
      if (var20 != 0) {
         Entity var21 = var15.c;
         if (var21 == null) {
            return;
         }

         Criticals var22 = this;
         var16 = var22;
      }

      int var24 = var6;
      Criticals var23 = var16;
      Criticals var18 = var23;
      Criticals var17 = var23;
      if (var24 != 0) {
         int var25 = var17.d;
         if (var25 <= 0) {
            this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
            int var26 = var6;
            if (var26 != 0) {
               MinecraftClient var11 = b;
               HitResult var12 = var11.crosshairTarget;
               Type var10000 = var12.getType();
               Type var28 = Type.ENTITY;
               Type var27 = var10000;
               if (var27 == var28) {
                  Object[] var14 = new Object[]{this.c, 114267283224552L};
                  ItemUseUtil.aReturningVoid(var14);
               }

               this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
               this.c = null;
            }

            int var29 = var6;
            if (var29 != 0) {
               return;
            }
         }

         Criticals var30 = this;
         var18 = var30;
      }

      var18.d--;
   }

   @EventListener
   public void a(AttackAttemptEvent var1) {
      int var4 = Event.bReturningInt();
      Object[] var6 = new Object[0];
      AttackAttemptEvent var5 = var1;
      EventPhase var10000 = var5.aReturningEventPhase(var6);
      EventPhase var15 = EventPhase.PRE;
      EventPhase var14 = var10000;
      if (var14 == var15) {
         int var17 = var4;
         Criticals var16 = this;
         Criticals var13 = var16;
         Criticals var12 = var16;
         if (var17 == 0) {
            Entity var18 = var12.c;
            if (var18 == null) {
               return;
            }

            Criticals var19 = this;
            var13 = var19;
         }

         int var20 = var13.d;
         if (var20 > 0) {
            Object[] var11 = new Object[0];
            AttackAttemptEvent var10 = var1;
            var10.aReturningVoid(var11);
         }
      }
   }

   private void jReturningVoid(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 92972563950088L ^ var2;
      long var5 = var2 ^ 130858128936719L;
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      double var10002 = var9.getX();
      MinecraftClient var10 = b;
      ClientPlayerEntity var11 = var10.player;
      double var10003 = var11.getY() + var4;
      MinecraftClient var12 = b;
      ClientPlayerEntity var13 = var12.player;
      double var10004 = var13.getZ();
      MinecraftClient var14 = b;
      ClientPlayerEntity var15 = var14.player;
      PositionAndOnGround var7 = new PositionAndOnGround(var10002, var10003, var10004, false, var15.horizontalCollision);
      Object[] var16 = new Object[]{var7, var5};
      PacketUtil.aReturningVoid(var16);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 92972563950088L ^ var2;
      int var4 = Event.bReturningInt();
      MinecraftClient var5 = b;
      int var33 = var4;
      ClientPlayerEntity var32 = var5.player;
      ClientPlayerEntity var22 = var32;
      ClientPlayerEntity var21 = var32;
      if (var33 == 0) {
         ClientPlayerEntity var34 = var21;
         if (var34 == null) {
            return false;
         }

         MinecraftClient var7 = b;
         ClientPlayerEntity var35 = var7.player;
         var22 = var35;
      }

      ClientPlayerEntity var9 = var22;
      byte var52 = ((byte)((var9.isOnGround()) ? 1 : 0));
      int var37 = var4;
      byte var36 = var52;
      byte var24 = var36;
      byte var23 = var36;
      if (var37 == 0) {
         byte var38 = var23;
         if (var38 == 0) {
            return false;
         }

         MinecraftClient var11 = b;
         ClientPlayerEntity var12 = var11.player;
         byte var39 = ((byte)((var12.isSubmergedInWater()) ? 1 : 0));
         var24 = var39;
      }

      int var41 = var4;
      byte var40 = var24;
      byte var26 = var40;
      byte var25 = var40;
      if (var41 == 0) {
         byte var42 = var25;
         if (var42 != 0) {
            return false;
         }

         MinecraftClient var15 = b;
         ClientPlayerEntity var16 = var15.player;
         byte var43 = ((byte)((var16.isInLava()) ? 1 : 0));
         var26 = var43;
      }

      int var45 = var4;
      byte var44 = var26;
      byte var28 = var44;
      byte var27 = var44;
      if (var45 == 0) {
         byte var46 = var27;
         if (var46 != 0) {
            return false;
         }

         MinecraftClient var19 = b;
         ClientPlayerEntity var20 = var19.player;
         byte var47 = ((byte)((var20.isClimbing()) ? 1 : 0));
         var28 = var47;
      }

      int var49 = var4;
      byte var48 = var28;
      byte var30 = var48;
      byte var29 = var48;
      if (var49 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var30);
      } else {
         byte var50 = var29;
         if (var50 == 0) {
            var30 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var30);
         } else {
            return false;
         }
      }
   }

   @Override
   public String aReturningString(Object[] var1) {
      long var2 = (Long)var1[0];
      return invokeBinding2((String)invokeBinding1(this.a, -4961620581170847197L, var2), -4962131749114786393L, var2);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(1210033361201L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[4];
      String var11 = "ý#\u001f¸\"ÆÊþÒv\u0003\u0013\u0086\u0082\u0097Ì\u0010\u0002Õl=EãÉ\u001e7\u000f,ÄË¥èk";
      int var13 = "ý#\u001f¸\"ÆÊþÒv\u0003\u0013\u0086\u0082\u0097Ì\u0010\u0002Õl=EãÉ\u001e7\u000f,ÄË¥èk".length();
      char var10 = 16;
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         // while (true) {
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     l = var14;
                     m = new String[4];
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(1210033361201L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = 665812972624965049L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)9L,
                           (byte)2365L,
                           (byte)605553L,
                           (byte)155021662L,
                           (byte)39685545720L,
                           (byte)10159499704360L,
                           (byte)2600831924316269L,
                           (byte)665812972624965049L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     o = var31;
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "Þ3|±§î¿\",¦¥\u009fbHN\u0094\u0010ýu\u0004×\u008fpyÞþ\u00879z\u0013´Ñ(";
                  var13 = "Þ3|±§î¿\",¦¥\u009fbHN\u0094\u0010ýu\u0004×\u008fpyÞþ\u00879z\u0013´Ñ(".length();
                  var10 = 16;
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10738;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ev", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ev_C0260",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ev" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 2;
            yield var15;
         }
         case 1 -> {
            byte var16 = 12;
            yield var16;
         }
         case 2 -> {
            byte var17 = 23;
            yield var17;
         }
         case 3 -> {
            byte var18 = 53;
            yield var18;
         }
         case 4 -> {
            byte var19 = 55;
            yield var19;
         }
         case 5 -> {
            byte var20 = 9;
            yield var20;
         }
         case 6 -> {
            byte var21 = 19;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 48;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 7;
            yield var25;
         }
         case 11 -> {
            byte var26 = 58;
            yield var26;
         }
         case 12 -> {
            byte var27 = 3;
            yield var27;
         }
         case 13 -> {
            byte var28 = 52;
            yield var28;
         }
         case 14 -> {
            byte var29 = 40;
            yield var29;
         }
         case 15 -> {
            byte var30 = 39;
            yield var30;
         }
         case 16 -> {
            byte var31 = 6;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 24;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 61;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 33;
            yield var39;
         }
         case 25 -> {
            byte var40 = 5;
            yield var40;
         }
         case 26 -> {
            byte var41 = 35;
            yield var41;
         }
         case 27 -> {
            byte var42 = 20;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 30;
            yield var44;
         }
         case 30 -> {
            byte var45 = 27;
            yield var45;
         }
         case 31 -> {
            byte var46 = 49;
            yield var46;
         }
         case 32 -> {
            byte var47 = 60;
            yield var47;
         }
         case 33 -> {
            byte var48 = 41;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 32;
            yield var50;
         }
         case 36 -> {
            byte var51 = 51;
            yield var51;
         }
         case 37 -> {
            byte var52 = 43;
            yield var52;
         }
         case 38 -> {
            byte var53 = 14;
            yield var53;
         }
         case 39 -> {
            byte var54 = 62;
            yield var54;
         }
         case 40 -> {
            byte var55 = 29;
            yield var55;
         }
         case 41 -> {
            byte var56 = 50;
            yield var56;
         }
         case 42 -> {
            byte var57 = 37;
            yield var57;
         }
         case 43 -> {
            byte var58 = 17;
            yield var58;
         }
         case 44 -> {
            byte var59 = 42;
            yield var59;
         }
         case 45 -> {
            byte var60 = 34;
            yield var60;
         }
         case 46 -> {
            byte var61 = 21;
            yield var61;
         }
         case 47 -> {
            byte var62 = 54;
            yield var62;
         }
         case 48 -> {
            byte var63 = 18;
            yield var63;
         }
         case 49 -> {
            byte var64 = 11;
            yield var64;
         }
         case 50 -> {
            byte var65 = 36;
            yield var65;
         }
         case 51 -> {
            byte var66 = 26;
            yield var66;
         }
         case 52 -> {
            byte var67 = 15;
            yield var67;
         }
         case 53 -> {
            byte var68 = 8;
            yield var68;
         }
         case 54 -> {
            byte var69 = 1;
            yield var69;
         }
         case 55 -> {
            byte var70 = 16;
            yield var70;
         }
         case 56 -> {
            byte var71 = 13;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 0;
            yield var74;
         }
         case 60 -> {
            byte var75 = 47;
            yield var75;
         }
         case 61 -> {
            byte var76 = 56;
            yield var76;
         }
         case 62 -> {
            byte var77 = 28;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = "\u001b\u0011'\nFB\u0010\u001e6E;Z\u0003\u0019?\f";
      p[1] = "\u0018d\u0018$\n\n\u0013k\tkk\u0004\u0018`\r1";
      p[2] = boolean.class;
      q[2] = "java/lang/Boolean";
      p[3] = "5,\u0014\u0014`\u0011#,\u0011Ns\u00064g\u0012H\u007f\u0012% \u0005_4\u0000\u0014";
      p[4] = int.class;
      q[4] = "java/lang/Integer";
      p[5] = "\u0011\u0019(\u001e\u0006$\u0007\u0019-D\u00153\u0010R.B\u0019'\u0001\u00159UR03";
      p[6] = "A4I\"\u001bnW4Lx\by@\u007fO~\u0004mQ8XiO{S";
      p[7] = "\u0014toV!{\u001f{~\u0019Bv\nvqrwt\u001bem^`y";
      p[8] = "\u001e%@*\u001f,k\u0005K%\u000ec\n\u000b@.\n9~";
      p[9] = void.class;
      q[9] = "java/lang/Void";
      p[10] = ";X],eINxV#t\u0006/v](p\\[";
      p[11] = "}\n\u001clhzk\n\u00196{m|A\u001a0wym\u0006\r'<h|";
      p[12] = "uob$;n\u0000Oi+*!aAb .{\u0015";
      p[13] = "\u0007\u0004lJ\u0004\u0001\u0007\u0004{\u0016\b\u000e\u001dO{\b\b\u001b\u001a>*QP^";
      p[14] = "M\u001e{4R\u0013M\u001elh^\u001cWUlv^\tP$<+\u000f";
      p[15] = "<\u0011QlWH<\u0011F0[G&ZF.[R!+\u0017q\u0003";
      p[16] = "\u000f\fm\u00177\u000e\u0019\fhM$\u0019\u000eGkK(\r\u001f\u0000|\\c\u001d\u0007";
      p[17] = "\\5u\u00125N)\u0015~\u001d$\u0001H\u001bu\u0016 [<";
      p[18] = "\u0005n\u0016hM'\u0005n\u00014A(\u001f%\u0001*A=\u0018TPu\u0019j\bg\u00035S\u0011Y?R";
      p[19] = "\b\u0018R'\u0011)\u0016\u0010Hhl9\u0016";
      p[20] = "6n\u00033|s6n\u0014op|,%\u0014qpi+TE)\"";
      p[21] = double.class;
      q[21] = "java/lang/Double";
      p[22] = "v<\u00196`\u0019\u0003\u001c\u00129qVb\u0012\u00192u\f\u0016";
      p[23] = "T><p'~T>+,+qNu+2+dI\u0004\u007fj|";
      p[24] = "s\u001eT?[\u0002e\u001eQeH\u0015rURcD\u0001c\u0012Et\u000f\u0013_";
      p[25] = "i\u001b)k0q\u001c;\"d!>}5)o%d\t";
      p[26] = "\u0010=\u0017qe^\u0010=\u0000-iQ\nv\u00003iD\r\u0007Rm1\u0000";
      p[27] = "woSwq]aoV-bJv$U+n^gcB<%Na";
      p[28] = "oi\u0002%0i\u001aI\t*!&{G\u0002!%|\u000f";
      p[29] = "@[\u0002\u001c76V[\u0007F$!A\u0010\u0004@(5PW\u0013Wc%\u0014";
      p[30] = "k/FVx_\u001e\u000fMYi\u0010\u007f\u0001FRmJ\u000b";
      p[31] = "O6Ad}=:\u0016Jklr[\u0018A`h(/";
      p[32] = "N_*\u0001 QX_/[3FO\u0014,]?R^S;JtV";
      p[33] = "m\u0010\to&\u001fxB\u001b5\u0019\u0014oR\u00038u&8\u0015Xf&ql\u0010Sa)\u0003?S[4\u0019";
      p[34] = "qvE'M\u0003s!\u0010ctXK \u0004(\t\u000f-v\u0014\"I2";
      p[35] = ">\t\b=82jL\u0006;R-<p\u0017\";0h\u0000\u000598J,\n\u0000\"h:>\u0011\u0003X>33\u0015\u0003 jv=\u0013i";
      p[36] = "8X\u0013Eny:\u000fF\u0001W!\u0002PO\u0005*prIV\u000bhHgSN\\k*zSGUW";
      p[37] = "\u0007-M4P\u000f\u0005z\u0018piU={\f;\u0014\u0003[-\u001c1T>";
      p[38] = "rl-N4\u0019g>?\u0014\u000b\u0012p.'\u0019g $bxO:wpk.\u0006p\u001b\u007f7w\u001e\u000bI|b-Ep\u001e|>w~";
      p[39] = "\u000eX4\njW\u000eA$\u001d\u0001^nU-[|\u000f\u001eL4U>7\u000f\u00013\u0018cI\u000eC(\u0004\u0001";
      p[40] = ")6j\u0005\u0006&%lhYvvC13\u0007\u000b'3(*\tI\u001f}4aSMd*4=\tv";
      p[41] = "a3\u001b\u0004y;ta\t^F0cq\u0011S*\u000241A\u000evU7b\bJ&?~o\u001bXF";
      p[42] = "\u0019)/myOZ~;l\u0015\u0019%m,coJU\u007f7`\u0015";
      p[43] = "i\u0015x\u0000<+fI!\u0018G)eAu\u0014\u0010~?\u0011)x)y4\u0012!\nz:<G";
      p[44] = "\u000b\u0019VE\u001b\u0015[\u0011M\u0014\"\u001f7BW\u001d\u001bL\r\u000eY\u000b\u0012v\n\u001eQC\u0018LF\u0010GJ\"";
      p[45] = "iLLJ*\u0011|\u001e^\u0010\u0015\u001ak\u000eF\u001dy(?B\u0019K%\u007fkKO\u0002n\u0013d\u0017\u0016\u001a\u0015";
      p[46] = "\u000ezmrU\u001eFnwp%\u001e^mq#rI\u0000:)OJNU0*!_\u001cGj";
      p[47] = "F\u001d\u000f#!\u0017H\u001a\u0000/O\u001aL\u000b\u0006,\u0018M\u0016][@$\u000f@\u0005\f#*\bO\t";
      p[48] = "\u0015\\t\nf`\u0017\u000b!N_8/T(J\"i_M1D`Q\u0011Qz\u001ed*FQ&D_";
      p[49] = "=\u0018oac5(J};\\>?Ze60\fh\u001d>hl[<\u00185ol)o[=:\\";
      p[50] = "\u0013::=tWFzzF0\u000f-z:'*\u0007vc|<7PI6<|L";
      p[51] = "\u00059,V\u001fDNfl\u0004xS5f3\u0004\u0005\u0002E\u007f*\nG:\u0004mi\u0006\u0001\u0001PmjDx";
      p[52] = "wX0I\u0019lw\rv\u001d{w\u0014WlL\u0006&dNuBD\u001e*R>\u0018@e}RbB{";
      p[53] = "\u0011S@u0~\u0004\u0001R/\u000fu\u0013\u0011J\"cGC]\u0014t\u000f)\u0011\u0014T%e`\u001c\u0007FE";
      p[54] = " )x/$!ui8Tqg8|f/\u001c`?|xnlr$\u007f\u0002msg;uh$~t)\u0015";
      p[55] = "$'p'UH+{)?.J(s}3y\u001dr##_@\u001ay )-\u0013Yqu";
      p[56] = "_Wh0rRP\u000b1(\tPS\u0003e$^\u0007\tS8Hg\u0000\u0002P1:4C\n\u0005";
      p[57] = "?4p\r%{*fbW\u001ap=vzZvBn3\"\u0004\u001a,?sd]pe2`v=";
      p[58] = "\u0001:Zt\b\u0019Q2A%1\u0018=8XuLBM!A{\u000ez\u0003=\n!\n\u0001T=V{1";
      p[59] = "\u0017\u0010\u0006\u0014*u_\u0004\u001c\u0016ZuG\u0007\u001aE\r\"\u0019TC)0\"A\u0007B\u0012=`CP";
      p[60] = "`^t3aAm\u001cvd]\u001fg\u001bs91-3X,nfza\u001c~=3\u0019o\u001bq1]";
      p[61] = "a{0@\\\u0000t)\"\u001ac\u000bc9:\u0017\u000f94~aJZn`{jNS\u001c38b\u001bc";
      p[62] = "jer>\u0011&\u007f7`d.-h'xiB\u001f8d'7.qj\"fnD8g1t\u000e";
      p[63] = "U\u0007\u0014B!t\u000f\u0010\u0003J^#4\u001e\u000e\u0012#rD\u0007\u0017\u001caJ\n\u001b\\Fe1]\u001b\u0000\u001c^";
      p[64] = "\u0010o \u0000(v@g;Q\u0011y,m\"\u0001l-\\t;\u000f.\u0015\u0015f9Aq\u007f\\k*S\u0011";
      p[65] = "\u0019\u0005]v3D\fWO,\fD\u0017VS*[\u0017G\u0004\tF5E\u000fEW,|H\u001cW";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(89593644888227L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(89593644888227L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(89593644888227L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 88;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 109;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 205;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 87;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 200;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 81;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 88;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 109;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 205;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ev_C0260",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ev" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Object invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = c(MethodHandles.lookup(), "È", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = c(MethodHandles.lookup(), "È", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
