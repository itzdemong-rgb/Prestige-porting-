package dev.zprestige.prestige.client.modules;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import net.minecraft.util.Hand;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.util.PositionSegment;
import dev.zprestige.prestige.client.modules.state.DiagonalPearlSolution;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.modules.state.DiagonalPearlCatchState;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class DiagonalPearlCatch extends Module implements RotationSource {
   private ModeSetting a;
   private FloatSetting c;
   private BooleanSetting d;
   private FloatSetting e;
   private static final double f = 0.4;
   private static final int g;
   private static final int h;
   private static final float i = 1.5F;
   private static final double j = 0.03;
   private static final double k = 0.99;
   private static final float l = 1.5F;
   private static final double m = 0.99;
   private static final double n = 0.0;
   private static final double o = 0.08;
   private static final double p = 0.98;
   private static final double q = 0.91;
   private DiagonalPearlCatchState r;
   private int s;
   private List t;
   private DiagonalPearlSolution u;
   private ElapsedTimer v;
   private boolean w;
   private Rotation x;
   private boolean y;
   private boolean z;
   private boolean A;
   private boolean B;
   private Object C;
   private Object D;
   private static final long E = 57799471956990L;
   private static final String[] F;
   private static final String[] G;
   private static final Map H = new HashMap(13);
   private static final long[] I;
   private static final Integer[] J;
   private static final Map K;
   private static final Object[] L = new Object[169];
   private static final String[] M = new String[169];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public DiagonalPearlCatch() {
      super();
      long var10001 = 70930963646683L ^ 36870034063346L;

      this.r = DiagonalPearlCatchState.IDLE;
      this.v = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 113634414339373L;
      long var6 = var2 ^ 38266410274184L;
      Object[] var9 = new Object[]{var4};
      DiagonalPearlCatch var8 = this;
      var8.jReturningVoid(var9);
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var6};
      RotationManager var10 = var10000;
      var10.dReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 94904578140464L;
      Object[] var9 = new Object[]{var6};
      DiagonalPearlCatch var8 = this;
      var8.jReturningVoid(var9);
      this.D = null;
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var4};
      RotationManager var10 = var10000;
      var10.eReturningVoid(var11);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 57799471956990L ^ var2;
      long var4 = var2 ^ 104987717753772L;
      long var6 = var2 ^ 52627938338958L;
      this.r = DiagonalPearlCatchState.IDLE;
      this.s = 0;
      this.t = null;
      this.u = null;
      this.w = dev.prestige.recovery.SourceSupport.asBoolean(0);
      ElapsedTimer var10000 = this.v;
      Object[] var9 = new Object[]{var4};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      Object[] var11 = new Object[]{var6};
      DiagonalPearlCatch var10 = this;
      var10.nReturningVoid(var11);
      MinecraftClient var12 = b;
      this.D = var12.world;
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      long var10001 = 120514886000187L ^ 35751261433449L;
      Object[] var7 = new Object[]{84767416823890L};
      DiagonalPearlCatch var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(TickEvent var1) {
      int var18;
      label141: {
         long var10001 = 135805662199431L ^ 28412925323252L;
         var10001 = 135805662199431L ^ 10307494594271L;
         var10001 = 135805662199431L ^ 60042762276565L;
         var10001 = 135805662199431L ^ 39716130263331L;
         var10001 = 135805662199431L ^ 88224442094982L;
         var10001 = 135805662199431L ^ 58094374500612L;
         var10001 = 135805662199431L ^ 50404979844517L;
         var18 = Event.cReturningInt();
         int var108 = var18;
         DiagonalPearlCatch var107 = this;
         DiagonalPearlCatch var80 = var107;
         DiagonalPearlCatch var79 = var107;
         if (var108 != 0) {
            MinecraftClient var22 = b;
            ClientWorld var110 = var22.world;
            Object var109 = var79.D;
            if (var109 == var110) {
               break label141;
            }

            DiagonalPearlCatch var111 = this;
            var80 = var111;
         }

         Object[] var26 = new Object[]{84767416823890L};
         DiagonalPearlCatch var25 = var80;
         var25.jReturningVoid(var26);
      }

      RotationManager var10000 = Prestige.o;
      Object[] var28 = new Object[]{108116642552179L};
      RotationManager var27 = var10000;
      boolean var112 = var27.eReturningBoolean(var28);
      if (!var112) {
         Object[] var30 = new Object[]{84767416823890L};
         DiagonalPearlCatch var29 = this;
         var29.jReturningVoid(var30);
      } else {
         DiagonalPearlCatch var89;
         label144: {
            boolean var88;
            label145: {
               label146: {
                  int var114 = var18;
                  MinecraftClient var113 = b;
                  MinecraftClient var82 = var113;
                  MinecraftClient var81 = var113;
                  if (var114 != 0) {
                     MinecraftClient var32 = var81;
                     ClientPlayerEntity var115 = var32.player;
                     if (var115 == null) {
                        break label146;
                     }

                     MinecraftClient var116 = b;
                     var82 = var116;
                  }

                  int var118 = var18;
                  MinecraftClient var117 = var82;
                  MinecraftClient var84 = var117;
                  MinecraftClient var83 = var117;
                  if (var118 != 0) {
                     MinecraftClient var35 = var83;
                     ClientWorld var119 = var35.world;
                     if (var119 == null) {
                        break label146;
                     }

                     MinecraftClient var120 = b;
                     var84 = var120;
                  }

                  MinecraftClient var38 = var84;
                  boolean var167 = var38.isWindowFocused();
                  int var122 = var18;
                  boolean var121 = var167;
                  var88 = var121;
                  boolean var85 = var121;
                  if (var122 == 0) {
                     break label145;
                  }

                  boolean var123 = var85;
                  if (var123) {
                     MinecraftClient var40 = b;
                     Screen var124 = var40.currentScreen;
                     if (var124 == null) {
                        int var19;
                        byte var101;
                        label148: {
                           DiagonalPearlCatch var96;
                           label149: {
                              Object[] var47 = new Object[]{invokeBinding1(), 87229155166083L};
                              DiagonalPearlCatch var46 = this;
                              var19 = var46.aReturningInt(var47);
                              int var131 = var18;
                              int var130 = var19;
                              int var92 = var130;
                              int var90 = var130;
                              if (var131 != 0) {
                                 // int var132 = var90;
                                 if (var132 == var133) {
                                    Object[] var50 = new Object[]{126290808879192L};
                                    DiagonalPearlCatch var49 = this;
                                    var49.aReturningVoid(var50);
                                    return;
                                 }

                                 int var135 = var18;
                                 DiagonalPearlCatch var134 = this;
                                 var96 = var134;
                                 DiagonalPearlCatch var91 = var134;
                                 if (var135 == 0) {
                                    break label149;
                                 }

                                 ModeSetting var52 = var91.a;
                                 String var168 = (String)var52.aReturningObject();
                                 String var54 = "Macro";
                                 String var53 = var168;
                                 byte var136 = ((byte)((var53.equals(var54)) ? 1 : 0));
                                 var92 = var136;
                              }

                              int var137 = var92;
                              if (var137 != 0) {
                                 int var139 = var18;
                                 byte var138 = ((byte)((this.w) ? 1 : 0));
                                 byte var95 = var138;
                                 byte var93 = var138;
                                 if (var139 != 0) {
                                    byte var140 = var93;
                                    byte var94 = var140;
                                    byte var141 = var94;
                                    if (var141 == 0) {
                                       byte var142 = 1;
                                       var101 = var142;
                                       break label148;
                                    }

                                    var95 = 0;
                                 }

                                 byte var143 = var95;
                                 var101 = var143;
                                 break label148;
                              }

                              var96 = this;
                           }

                           label93: {
                              int var146 = var18;
                              DiagonalPearlCatchState var145 = DiagonalPearlCatchState.IDLE;
                              DiagonalPearlCatchState var144 = var96.r;
                              DiagonalPearlCatchState var99 = var144;
                              DiagonalPearlCatchState var100 = var145;
                              DiagonalPearlCatchState var97 = var144;
                              DiagonalPearlCatchState var98 = var145;
                              if (var146 != 0) {
                                 DiagonalPearlCatchState var148 = var98;
                                 DiagonalPearlCatchState var147 = var97;
                                 if (var147 == var148) {
                                    break label93;
                                 }

                                 DiagonalPearlCatchState var150 = DiagonalPearlCatchState.THROW_PEARL;
                                 DiagonalPearlCatchState var149 = this.r;
                                 var99 = var149;
                                 var100 = var150;
                              }

                              DiagonalPearlCatchState var152 = var100;
                              DiagonalPearlCatchState var151 = var99;
                              if (var151 != var152) {
                                 var101 = 0;
                                 break label148;
                              }
                           }

                           byte var153 = 1;
                           var101 = var153;
                        }

                        int var21;
                        DiagonalPearlCatch var106;
                        label151: {
                           int var105;
                           byte var20 = var101;
                           var21 = -1;
                           int var155 = var18;
                           byte var154 = var20;
                           var105 = var154;
                           byte var102 = var154;
                           label83:
                           if (var155 != 0) {
                              byte var156 = var102;
                              if (var156 != 0) {
                                 Object[] var64 = new Object[]{invokeBinding2(), 87229155166083L};
                                 DiagonalPearlCatch var63 = this;
                                 var21 = var63.aReturningInt(var64);
                                 int var158 = var18;
                                 int var157 = var21;
                                 var105 = var157;
                                 int var103 = var157;
                                 if (var158 == 0) {
                                    break label83;
                                 }

                                 // int var159 = var103;
                                 if (var159 == var160) {
                                    Object[] var67 = new Object[]{126290808879192L};
                                    DiagonalPearlCatch var66 = this;
                                    var66.aReturningVoid(var67);
                                    return;
                                 }
                              }

                              int var162 = var18;
                              DiagonalPearlCatch var161 = this;
                              var106 = var161;
                              DiagonalPearlCatch var104 = var161;
                              if (var162 == 0) {
                                 break label151;
                              }

                              ModeSetting var69 = var104.a;
                              String var169 = (String)var69.aReturningObject();
                              String var71 = "Macro";
                              String var70 = var169;
                              byte var163 = ((byte)((var70.equals(var71)) ? 1 : 0));
                              var105 = var163;
                           }

                           int var164 = var105;
                           if (var164 != 0) {
                              Object[] var10005 = new Object[]{null, null, 105126196342692L};
                              var10005[1] = var19;
                              var10005[0] = var21;
                              Object[] var74 = var10005;
                              DiagonalPearlCatch var73 = this;
                              var73.kReturningVoid(var74);
                              int var165 = var18;
                              if (var165 != 0) {
                                 return;
                              }
                           }

                           DiagonalPearlCatch var166 = this;
                           var106 = var166;
                        }

                        Object[] var176 = new Object[]{null, null, 48098848598785L};
                        var176[1] = var19;
                        var176[0] = var21;
                        Object[] var78 = var176;
                        DiagonalPearlCatch var77 = var106;
                        var77.lReturningVoid(var78);
                        return;
                     }
                  }
               }

               int var126 = var18;
               DiagonalPearlCatch var125 = this;
               var89 = var125;
               DiagonalPearlCatch var86 = var125;
               if (var126 == 0) {
                  break label144;
               }

               DiagonalPearlCatch var127 = var86;
               DiagonalPearlCatch var87 = var127;
               boolean var128 = var87.A;
               var88 = var128;
            }

            boolean var129 = var88;
            if (var129) {
               return;
            }

            var89 = this;
         }

         Object[] var45 = new Object[]{94920566889250L};
         DiagonalPearlCatch var44 = var89;
         var44.nReturningVoid(var45);
      }
   }

   private void kReturningVoid(Object[] var1) {
      int var5 = (Integer)var1[0];
      int var2 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      var3 = 57799471956990L ^ var3;
      long var6 = var3 ^ 31305040763620L;
      long var8 = var3 ^ 85730530231386L;
      long var10 = var3 ^ 23706783889998L;
      long var12 = var3 ^ 60215221519869L;
      int var14 = Event.cReturningInt();
      int var49 = var14;
      boolean var48 = this.w;
      boolean var41 = var48;
      boolean var34 = var48;
      if (var49 != 0) {
         boolean var50 = var34;
         if (!var50) {
            int var53 = var14;
            int var52 = var5;
            DiagonalPearlCatch var51 = this;
            DiagonalPearlCatch var39 = var51;
            int var40 = var52;
            DiagonalPearlCatch var35 = var51;
            int var36 = var52;
            if (var53 != 0) {
               int var55 = var36;
               DiagonalPearlCatch var54 = var35;
               DiagonalPearlCatch var37 = var54;
               int var38 = var55;
               Object[] var18 = new Object[]{var12};
               DiagonalPearlCatch var17 = this;
               Object[] var71 = new Object[]{null, var17.dReturningdx_C0210(var18), var6};
               var71[0] = var38;
               Object[] var20 = var71;
               DiagonalPearlCatch var19 = var37;
               boolean var56 = var19.dReturningBoolean(var20);
               if (!var56) {
                  return;
               }

               byte var58 = 1;
               DiagonalPearlCatch var57 = this;
               var39 = var57;
               var40 = var58;
            }

            var39.w = dev.prestige.recovery.SourceSupport.asBoolean(var40);
            ElapsedTimer var70 = this.v;
            Object[] var24 = new Object[]{var8};
            ElapsedTimer var23 = var70;
            var23.aReturningVoid(var24);
            return;
         }

         ElapsedTimer var10000 = this.v;
         FloatSetting var25 = this.c;
         Float var26 = (Float)var25.aReturningObject();
         float var10001 = var26;
         Object[] var10004 = new Object[]{null, var10};
         var10004[0] = var10001;
         Object[] var28 = var10004;
         ElapsedTimer var27 = var10000;
         var41 = var27.aReturningBoolean(var28);
      }

      DiagonalPearlCatch var46;
      int var47;
      label48: {
         int var60 = var14;
         boolean var59 = var41;
         boolean var45 = var59;
         boolean var42 = var59;
         if (var60 != 0) {
            boolean var61 = var42;
            if (!var61) {
               return;
            }

            int var64 = var14;
            int var63 = var2;
            DiagonalPearlCatch var62 = this;
            var46 = var62;
            var47 = var63;
            DiagonalPearlCatch var43 = var62;
            int var44 = var63;
            if (var64 == 0) {
               break label48;
            }

            Object[] var31 = new Object[]{var12};
            DiagonalPearlCatch var30 = this;
            Object[] var10005 = new Object[]{null, var30.dReturningdx_C0210(var31), var6};
            var10005[0] = var44;
            Object[] var33 = var10005;
            DiagonalPearlCatch var32 = var43;
            boolean var65 = var32.dReturningBoolean(var33);
            var45 = var65;
         }

         boolean var66 = var45;
         if (!var66) {
            return;
         }

         byte var68 = 1;
         DiagonalPearlCatch var67 = this;
         var46 = var67;
         var47 = var68;
      }

      var46.B = dev.prestige.recovery.SourceSupport.asBoolean(var47);
   }

   private void lReturningVoid(Object[] var1) {
      int var2;
      long var14;
      label98: {
         int var16;
         label99: {
            int var5;
            long var6;
            long var8;
            long var10;
            long var12;
            label93: {
               DiagonalPearlCatch var61;
               label100: {
                  var5 = (Integer)var1[0];
                  var2 = (Integer)var1[1];
                  long var3 = (Long)var1[2];
                  var3 = 57799471956990L ^ var3;
                  var6 = var3 ^ 120893682176167L;
                  var8 = var3 ^ 114738953166401L;
                  var10 = var3 ^ 73536445972824L;
                  var12 = var3 ^ 36373236040134L;
                  var14 = var3 ^ 65720887326830L;
                  var16 = Event.bReturningInt();
                  DiagonalPearlCatchState var17 = this.r;
                  int var10000 = var17.ordinal();
                  int var86 = var16;
                  int var85 = var10000;
                  int var60 = var85;
                  int var57 = var85;
                  if (var86 == 0) {
                     int var87 = var57;
                     switch (var87) {
                        case 0:
                           int var89 = var16;
                           DiagonalPearlCatch var88 = this;
                           var61 = var88;
                           DiagonalPearlCatch var58 = var88;
                           if (var89 != 0) {
                              break label100;
                           }

                           DiagonalPearlCatch var90 = var58;
                           DiagonalPearlCatch var59 = var90;
                           Object[] var21 = new Object[]{var10};
                           DiagonalPearlCatch var20 = this;
                           Object[] var23 = new Object[]{var20.dReturningdx_C0210(var21), var12};
                           DiagonalPearlCatch var22 = var59;
                           byte var91 = ((byte)((var22.aReturningBoolean(var23)) ? 1 : 0));
                           var60 = var91;
                           break;
                        case 1:
                           break label93;
                        case 2:
                           break label99;
                        case 3:
                           break label98;
                        default:
                           return;
                     }
                  }

                  int var92 = var60;
                  if (var92 == 0) {
                     Object[] var26 = new Object[]{var6};
                     DiagonalPearlCatch var25 = this;
                     var25.aReturningVoid(var26);
                     return;
                  }

                  var61 = this;
               }

               var61.r = DiagonalPearlCatchState.THROW_PEARL;
               int var93 = var16;
               if (var93 == 0) {
                  return;
               }
            }

            DiagonalPearlCatch var73;
            int var74;
            label102: {
               boolean var72;
               int var95 = var16;
               boolean var94 = this.y;
               var72 = var94;
               boolean var62 = var94;
               label76:
               if (var95 == 0) {
                  boolean var96 = var62;
                  boolean var63 = var96;
                  boolean var97 = var63;
                  if (var97) {
                     int var99 = var16;
                     boolean var98 = this.A;
                     var72 = var98;
                     boolean var64 = var98;
                     if (var99 != 0) {
                        break label76;
                     }

                     boolean var100 = var64;
                     boolean var65 = var100;
                     boolean var101 = var65;
                     if (!var101) {
                        RotationManager var132 = Prestige.o;
                        Object[] var33 = new Object[0];
                        RotationManager var32 = var132;
                        boolean var133 = var32.fReturningBoolean(var33);
                        int var103 = var16;
                        boolean var102 = var133;
                        var72 = var102;
                        boolean var66 = var102;
                        if (var103 != 0) {
                           break label76;
                        }

                        boolean var104 = var66;
                        boolean var67 = var104;
                        boolean var105 = var67;
                        if (!var105) {
                           Object[] var37 = new Object[]{this.x, var12};
                           DiagonalPearlCatch var36 = this;
                           boolean var134 = var36.aReturningBoolean(var37);
                           int var107 = var16;
                           boolean var106 = var134;
                           var72 = var106;
                           boolean var68 = var106;
                           if (var107 != 0) {
                              break label76;
                           }

                           boolean var108 = var68;
                           boolean var69 = var108;
                           boolean var109 = var69;
                           if (!var109) {
                              Object[] var41 = new Object[]{var6};
                              DiagonalPearlCatch var40 = this;
                              var40.aReturningVoid(var41);
                              return;
                           }
                        }
                     }
                  }

                  int var112 = var16;
                  int var111 = var5;
                  DiagonalPearlCatch var110 = this;
                  var73 = var110;
                  var74 = var111;
                  DiagonalPearlCatch var70 = var110;
                  int var71 = var111;
                  if (var112 != 0) {
                     break label102;
                  }

                  Object[] var44 = new Object[]{var10};
                  DiagonalPearlCatch var43 = this;
                  Object[] var10005 = new Object[]{null, var43.dReturningdx_C0210(var44), var8};
                  var10005[0] = var71;
                  Object[] var46 = var10005;
                  DiagonalPearlCatch var45 = var70;
                  boolean var113 = var45.dReturningBoolean(var46);
                  var72 = var113;
               }

               boolean var114 = var72;
               if (!var114) {
                  return;
               }

               this.s = this.u.a;
               int var116 = this.s;
               DiagonalPearlCatch var115 = this;
               var73 = var115;
               var74 = var116;
            }

            int var118 = var74;
            DiagonalPearlCatch var117 = var73;
            DiagonalPearlCatch var76 = var117;
            DiagonalPearlCatch var75 = var117;
            DiagonalPearlCatch var77;
            DiagonalPearlCatchState var78;
            if (var118 > 0) {
               DiagonalPearlCatchState var120 = DiagonalPearlCatchState.WAIT_FOR_LAUNCH;
               DiagonalPearlCatch var119 = var75;
               var77 = var119;
               var78 = var120;
            } else {
               var78 = DiagonalPearlCatchState.THROW_WIND_CHARGE;
               var77 = var76;
            }

            var77.r = var78;
            int var121 = var16;
            if (var121 == 0) {
               return;
            }
         }

         int var10001 = this.s - 1;
         int var124 = var16;
         int var123 = var10001;
         DiagonalPearlCatch var122 = this;
         DiagonalPearlCatch var83 = var122;
         int var84 = var123;
         DiagonalPearlCatch var79 = var122;
         int var80 = var123;
         if (var124 == 0) {
            int var126 = var80;
            DiagonalPearlCatch var125 = var79;
            DiagonalPearlCatch var81 = var125;
            int var82 = var126;
            int var127 = var81.s = var82;
            if (var127 > 0) {
               return;
            }

            this.r = DiagonalPearlCatchState.THROW_WIND_CHARGE;
            int var129 = var2;
            DiagonalPearlCatch var128 = this;
            var83 = var128;
            var84 = var129;
         }

         Object[] var10004 = new Object[]{null, var14};
         var10004[0] = var84;
         Object[] var54 = var10004;
         DiagonalPearlCatch var53 = var83;
         var53.mReturningVoid(var54);
         int var130 = var16;
         if (var130 == 0) {
            return;
         }
      }

      Object[] var135 = new Object[]{null, var14};
      var135[0] = var2;
      Object[] var56 = var135;
      DiagonalPearlCatch var55 = this;
      var55.mReturningVoid(var56);
   }

   private void mReturningVoid(Object[] var1) {
      long var5;
      DiagonalPearlCatch var26;
      label27: {
         label26: {
            int var4 = (Integer)var1[0];
            long var2 = (Long)var1[1];
            var2 = 57799471956990L ^ var2;
            var5 = var2 ^ 108471179635511L;
            long var7 = var2 ^ 113310168098257L;
            long var9 = var2 ^ 3829273031215L;
            int var10000 = Event.cReturningInt();
            Object[] var14 = new Object[]{var9};
            DiagonalPearlCatch var13 = this;
            Object[] var10006 = new Object[]{null, var13.cReturningdx_C0210(var14), var7};
            var10006[0] = var4;
            Object[] var16 = var10006;
            DiagonalPearlCatch var15 = this;
            boolean var12 = var15.dReturningBoolean(var16);
            int var11 = var10000;
            int var27 = var11;
            if (var27 != 0) {
               boolean var28 = var12;
               if (!var28) {
                  int var30 = var11;
                  DiagonalPearlCatch var29 = this;
                  var26 = var29;
                  DiagonalPearlCatch var24 = var29;
                  if (var30 == 0) {
                     break label27;
                  }

                  DiagonalPearlCatch var31 = var24;
                  DiagonalPearlCatch var25 = var31;
                  boolean var32 = var25.A;
                  if (!var32) {
                     break label26;
                  }
               }

               this.B = dev.prestige.recovery.SourceSupport.asBoolean(1);
            }

            int var33 = var11;
            if (var33 != 0) {
               return;
            }
         }

         DiagonalPearlCatch var34 = this;
         var26 = var34;
      }

      Object[] var23 = new Object[]{var5};
      DiagonalPearlCatch var22 = var26;
      var22.aReturningVoid(var23);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2;
      long var4;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      int var18;
      label117: {
         var2 = (Long)var1[0];
         var4 = var2 ^ 103512462602515L;
         var6 = var2 ^ 31777281238881L;
         var8 = var2 ^ 52160886458656L;
         var10 = var2 ^ 124693407750194L;
         var12 = var2 ^ 107469041369543L;
         var14 = var2 ^ 75772413402283L;
         var16 = var2 ^ 7703413019222L;
         var18 = Event.bReturningInt();
         int var107 = var18;
         DiagonalPearlCatch var106 = this;
         DiagonalPearlCatch var72 = var106;
         DiagonalPearlCatch var71 = var106;
         if (var107 == 0) {
            MinecraftClient var20 = b;
            ClientWorld var109 = var20.world;
            Object var108 = var71.D;
            if (var108 == var109) {
               break label117;
            }

            DiagonalPearlCatch var110 = this;
            var72 = var110;
         }

         Object[] var24 = new Object[]{var10};
         DiagonalPearlCatch var23 = var72;
         var23.jReturningVoid(var24);
      }

      RotationManager var10000 = Prestige.o;
      Object[] var26 = new Object[]{var4};
      RotationManager var25 = var10000;
      boolean var111 = var25.eReturningBoolean(var26);
      if (!var111) {
         Object[] var28 = new Object[]{var10};
         DiagonalPearlCatch var27 = this;
         var27.jReturningVoid(var28);
         return null;
      }

      DiagonalPearlCatch var83;
      label120: {
         int var113 = var18;
         Rotation var112 = this.x;
         Object var75 = var112;
         Rotation var73 = var112;
         if (var113 == 0) {
            Rotation var114 = var73;
            if (var114 != null) {
               return this.x;
            }

            int var116 = var18;
            DiagonalPearlCatch var115 = this;
            var83 = var115;
            DiagonalPearlCatch var74 = var115;
            if (var116 != 0) {
               break label120;
            }

            ModeSetting var32 = var74.a;
            Object var117 = var32.aReturningObject();
            var75 = var117;
         }

         String var162 = (String)var75;
         short var10001 = 9893;
         long var10002 = 7957096180469983408L ^ var2;
         String var35 = "Macro";
         String var34 = var162;
         boolean var118 = var34.equals(var35);
         if (var118) {
            int var81;
            label80: {
               int var80;
               int var120 = var18;
               byte var119 = ((byte)((this.w) ? 1 : 0));
               var80 = var119;
               byte var76 = var119;
               label79:
               if (var120 == 0) {
                  byte var121 = var76;
                  byte var77 = var121;
                  byte var122 = var77;
                  if (var122 != 0) {
                     ElapsedTimer var163 = this.v;
                     Object[] var39 = new Object[]{var6};
                     ElapsedTimer var38 = var163;
                     float var164 = var38.aReturningFloat(var39) + 55.0F;
                     FloatSetting var40 = this.c;
                     Float var41 = (Float)var40.aReturningObject();
                     float var166;
                     int var165 = (var166 = var164 - var41) == 0.0F ? 0 : (var166 < 0.0F ? -1 : 1);
                     int var124 = var18;
                     int var123 = var165;
                     var80 = var123;
                     int var78 = var123;
                     if (var124 != 0) {
                        break label79;
                     }

                     int var125 = var78;
                     int var79 = var125;
                     int var126 = var79;
                     if (var126 < 0) {
                        var81 = 0;
                        break label80;
                     }
                  }

                  var80 = 1;
               }

               int var127 = var80;
               var81 = var127;
            }

            int var19 = var81;
            int var128 = var19;
            Rotation var82;
            if (var128 != 0) {
               Object[] var45 = new Object[]{var12};
               DiagonalPearlCatch var44 = this;
               Object[] var47 = new Object[]{var44.dReturningdx_C0210(var45), var16};
               DiagonalPearlCatch var46 = this;
               Rotation var129 = var46.eReturningdx_C0210(var47);
               var82 = var129;
            } else {
               var82 = null;
            }

            return var82;
         }

         var83 = this;
      }

      int var132 = var18;
      DiagonalPearlCatchState var131 = DiagonalPearlCatchState.THROW_PEARL;
      DiagonalPearlCatchState var130 = var83.r;
      DiagonalPearlCatchState var86 = var130;
      DiagonalPearlCatchState var87 = var131;
      DiagonalPearlCatchState var84 = var130;
      DiagonalPearlCatchState var85 = var131;
      if (var132 == 0) {
         DiagonalPearlCatchState var134 = var85;
         DiagonalPearlCatchState var133 = var84;
         if (var133 == var134) {
            Object[] var51 = new Object[]{var12};
            DiagonalPearlCatch var50 = this;
            Object[] var53 = new Object[]{var50.dReturningdx_C0210(var51), var16};
            DiagonalPearlCatch var52 = this;
            return var52.eReturningdx_C0210(var53);
         }

         var87 = DiagonalPearlCatchState.WAIT_FOR_LAUNCH;
         var86 = this.r;
      }

      DiagonalPearlCatch var105;
      label123: {
         int var137 = var18;
         DiagonalPearlCatchState var136 = var87;
         DiagonalPearlCatchState var135 = var86;
         DiagonalPearlCatchState var103 = var135;
         DiagonalPearlCatchState var104 = var136;
         DiagonalPearlCatchState var88 = var135;
         DiagonalPearlCatchState var89 = var136;
         if (var137 == 0) {
            DiagonalPearlCatchState var139 = var89;
            DiagonalPearlCatchState var138 = var88;
            if (var138 == var139) {
               DiagonalPearlCatch var92;
               Rotation var161;
               label94: {
                  Object[] var57 = new Object[]{var14};
                  DiagonalPearlCatch var56 = this;
                  var161 = var56.bReturningdx_C0210(var57);
                  Rotation var140 = var161;
                  if (var140 == null) {
                     int var142 = var18;
                     DiagonalPearlCatch var141 = this;
                     var92 = var141;
                     DiagonalPearlCatch var90 = var141;
                     if (var142 != 0) {
                        break label94;
                     }

                     DiagonalPearlCatch var143 = var90;
                     DiagonalPearlCatch var91 = var143;
                     byte var145 = 2;
                     int var144 = var91.s;
                     if (var144 > var145) {
                        return null;
                     }
                  }

                  DiagonalPearlCatch var146 = this;
                  var92 = var146;
               }

               DiagonalPearlCatch var100;
               Rotation var101;
               label88: {
                  int var149 = var18;
                  Rotation var148 = var161;
                  DiagonalPearlCatch var147 = var92;
                  DiagonalPearlCatch var97 = var147;
                  Rotation var98 = var148;
                  DiagonalPearlCatch var93 = var147;
                  Rotation var94 = var148;
                  if (var149 == 0) {
                     Rotation var151 = var94;
                     DiagonalPearlCatch var150 = var93;
                     DiagonalPearlCatch var99 = var150;
                     DiagonalPearlCatch var95 = var150;
                     if (var151 == null) {
                        Object[] var63 = new Object[]{var12};
                        DiagonalPearlCatch var62 = this;
                        var101 = var62.dReturningdx_C0210(var63);
                        var100 = var99;
                        break label88;
                     }

                     DiagonalPearlCatch var152 = var95;
                     DiagonalPearlCatch var96 = var152;
                     var98 = var161;
                     var97 = var96;
                  }

                  Rotation var154 = var98;
                  DiagonalPearlCatch var153 = var97;
                  var100 = var153;
                  var101 = var154;
               }

               Object[] var65 = new Object[]{var101, var16};
               DiagonalPearlCatch var64 = var100;
               return var64.eReturningdx_C0210(var65);
            }

            int var156 = var18;
            DiagonalPearlCatch var155 = this;
            var105 = var155;
            DiagonalPearlCatch var102 = var155;
            if (var156 != 0) {
               break label123;
            }

            DiagonalPearlCatchState var158 = DiagonalPearlCatchState.THROW_WIND_CHARGE;
            DiagonalPearlCatchState var157 = var102.r;
            var103 = var157;
            var104 = var158;
         }

         DiagonalPearlCatchState var160 = var104;
         DiagonalPearlCatchState var159 = var103;
         if (var159 != var160) {
            return null;
         }

         var105 = this;
      }

      Object[] var68 = new Object[]{var8};
      DiagonalPearlCatch var67 = this;
      Object[] var70 = new Object[]{var67.cReturningdx_C0210(var68), var16};
      DiagonalPearlCatch var69 = var105;
      return var69.eReturningdx_C0210(var70);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 57799471956990L ^ var2;
      long var4 = var2 ^ 14975200436428L;
      int var6 = Event.cReturningInt();
      ModeSetting var8 = this.a;
      String var10000 = (String)var8.aReturningObject();
      short var10001 = 16639;
      long var10002 = 8522916125941453245L ^ var2;
      String var10 = "Trajectory";
      String var9 = var10000;
      boolean var57 = var9.equals(var10);
      int var39 = var6;
      boolean var38 = var57;
      boolean var31 = var38;
      boolean var30 = var38;
      if (var39 != 0) {
         boolean var40 = var30;
         if (!var40) {
            return null;
         }

         BooleanSetting var13 = this.d;
         Boolean var14 = (Boolean)var13.aReturningObject();
         var31 = var14;
      }

      boolean var41 = var31;
      if (!var41) {
         return null;
      }

      MinecraftClient var16 = b;
      ClientPlayerEntity var42 = var16.player;
      if (var42 == null) {
         return null;
      }

      int var44 = var6;
      DiagonalPearlCatch var43 = this;
      DiagonalPearlCatch var33 = var43;
      DiagonalPearlCatch var32 = var43;
      if (var44 != 0) {
         DiagonalPearlSolution var45 = var32.u;
         if (var45 == null) {
            return null;
         }

         var33 = this;
      }

      DiagonalPearlCatch var37;
      int var47 = var6;
      DiagonalPearlCatch var46 = var33;
      var37 = var46;
      DiagonalPearlCatch var34 = var46;
      label44:
      if (var47 != 0) {
         DiagonalPearlCatchState var49 = DiagonalPearlCatchState.WAIT_FOR_LAUNCH;
         DiagonalPearlCatchState var48 = var34.r;
         if (var48 != var49) {
            int var51 = var6;
            DiagonalPearlCatch var50 = this;
            var37 = var50;
            DiagonalPearlCatch var35 = var50;
            if (var51 == 0) {
               break label44;
            }

            DiagonalPearlCatch var52 = var35;
            DiagonalPearlCatch var36 = var52;
            DiagonalPearlCatchState var54 = DiagonalPearlCatchState.THROW_WIND_CHARGE;
            DiagonalPearlCatchState var53 = var36.r;
            if (var53 != var54) {
               return null;
            }
         }

         var37 = this;
      }

      MinecraftClient var24 = b;
      ClientPlayerEntity var25 = var24.player;
      float var58 = var37.u.b - var25.getYaw();
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var58;
      Object[] var26 = var10003;
      float var27 = RotationUtil.bReturningFloat(var26);
      float var7 = Math.abs(var27);
      FloatSetting var28 = this.e;
      Float var29 = (Float)var28.aReturningObject();
      float var59;
      int var55 = (var59 = var7 - var29) == 0.0F ? 0 : (var59 < 0.0F ? -1 : 1);
      return var55 > 0 ? null : new Rotation(this.u.b, this.u.c);
   }

   private Rotation cReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 57799471956990L ^ var2;
      long var4 = var2 ^ 134551895296793L;
      long var6 = var2 ^ 104505013016181L;
      int var10000 = Event.bReturningInt();
      Object[] var11 = new Object[]{var6};
      DiagonalPearlCatch var10 = this;
      Rotation var9 = var10.bReturningdx_C0210(var11);
      int var8 = var10000;
      int var19 = var8;
      Rotation var18 = var9;
      Rotation var16 = var18;
      Rotation var15 = var18;
      if (var19 == 0) {
         Rotation var20 = var15;
         if (var20 == null) {
            Object[] var14 = new Object[]{var4};
            DiagonalPearlCatch var13 = this;
            return var13.dReturningdx_C0210(var14);
         }

         var16 = var9;
      }

      return var16;
   }

   private Rotation dReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 57799471956990L ^ var2;
      MinecraftClient var4 = b;
      ClientPlayerEntity var5 = var4.player;
      float var10002 = var5.getYaw();
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      return new Rotation(var10002, var7.getPitch());
   }

   private boolean aReturningBoolean(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 57799471956990L ^ var2;
      long var5 = var2 ^ 15252608396408L;
      long var7 = var2 ^ 65581145351907L;
      long var9 = var2 ^ 23725403414800L;
      MinecraftClient var16 = b;
      ClientPlayerEntity var17 = var16.player;
      Vec3d var11 = var17.getEyePos();
      MinecraftClient var18 = b;
      ClientPlayerEntity var19 = var18.player;
      Vec3d var12 = var19.getVelocity();
      MinecraftClient var20 = b;
      ClientPlayerEntity var21 = var20.player;
      boolean var13 = var21.isOnGround();
      short var10004 = 22830;
      long var10005 = 2156428970106733154L ^ var2;
      Object[] var10007 = new Object[]{null, null, null, null, var9};
      var10007[3] = 17;
      var10007[2] = var13;
      var10007[1] = var12;
      var10007[0] = var11;
      Object[] var23 = var10007;
      DiagonalPearlCatch var22 = this;
      List var14 = var22.bReturningList(var23);
      List var24 = var14;
      PositionSegment var15 = (PositionSegment)var24.get(0);
      Object[] var27 = new Object[0];
      Rotation var26 = var4;
      float var10003 = var26.aReturningFloat(var27);
      Object[] var29 = new Object[0];
      Rotation var28 = var4;
      float var38 = var28.bReturningFloat(var29);
      var10007 = new Object[]{null, null, null, var5};
      var10007[2] = var38;
      var10007[1] = var10003;
      var10007[0] = var15;
      Object[] var31 = var10007;
      DiagonalPearlCatch var30 = this;
      this.t = var30.cReturningList(var31);
      Object[] var33 = new Object[]{var14, this.t, var7};
      DiagonalPearlCatch var32 = this;
      this.u = var32.aReturningaz_C0054(var33);
      DiagonalPearlSolution var35 = this.u;
      byte var34;
      if (var35 != null) {
         byte var36 = 1;
         var34 = var36;
      } else {
         var34 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var34);
   }

   private boolean dReturningBoolean(Object[] var1) {
      int var2 = (Integer)var1[0];
      Rotation var3 = (Rotation)var1[1];
      long var4 = (Long)var1[2];
      var4 = 57799471956990L ^ var4;
      long var6 = var4 ^ 2268595138614L;
      long var8 = var4 ^ 132584750436214L;
      long var10 = var4 ^ 124032227561421L;
      int var12 = Event.bReturningInt();
      RotationManager var10000 = Prestige.o;
      Object[] var20 = new Object[0];
      RotationManager var19 = var10000;
      byte var58 = ((byte)((var19.fReturningBoolean(var20)) ? 1 : 0));
      if (var12 == 0) {
         if (var58 == 0) {
            Object[] var23 = new Object[]{var3, var8};
            Rotation var13 = this.eReturningdx_C0210(var23);
            byte var59 = ((byte)((this.y) ? 1 : 0));
            if (var12 == 0) {
               label64:
               if (this.y) {
                  int var60 = (((this.A) ? 1 : 0));
                  if (var12 == 0) {
                     if (this.A) {
                        break label64;
                     }

                     var60 = var2;
                  }

                  Object[] var10003 = new Object[]{null, var6};
                  var10003[0] = var60;
                  Object[] var27 = var10003;
                  InventoryUtil.aReturningVoid(var27);
                  MinecraftClient var28 = b;
                  ClientPlayerEntity var29 = var28.player;
                  float var14 = var29.getYaw();
                  MinecraftClient var30 = b;
                  ClientPlayerEntity var31 = var30.player;
                  float var15 = var31.getPitch();

                  boolean var17;
                  try {
                     MinecraftClient var32 = b;
                     ClientPlayerEntity var61 = var32.player;
                     Object[] var34 = new Object[0];
                     float var36 = var13.aReturningFloat(var34);
                     ClientPlayerEntity var35 = var61;
                     var35.setYaw(var36);
                     MinecraftClient var37 = b;
                     ClientPlayerEntity var62 = var37.player;
                     Object[] var39 = new Object[0];
                     float var41 = var13.bReturningFloat(var39);
                     ClientPlayerEntity var40 = var62;
                     var40.setPitch(var41);
                     Object[] var42 = new Object[]{Hand.MAIN_HAND, var10};
                     boolean var16 = ItemUseUtil.cReturningBoolean(var42);
                     this.A = dev.prestige.recovery.SourceSupport.asBoolean(1);
                     var17 = var16;
                  } finally {
                     MinecraftClient var49 = b;
                     ClientPlayerEntity var50 = var49.player;
                     var50.setYaw(var14);
                     MinecraftClient var52 = b;
                     ClientPlayerEntity var53 = var52.player;
                     var53.setPitch(var15);
                  }

                  return var17;
               }

               var59 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var59);
         }

         var58 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var58);
   }

   private Rotation eReturningdx_C0210(Object[] var1) {
      Rotation var4 = (Rotation)var1[0];
      long var2 = (Long)var1[1];
      var2 = 57799471956990L ^ var2;
      long var5 = var2 ^ 78988607055765L;
      int var7 = Event.bReturningInt();
      int var20 = var7;
      Rotation var19 = this.x;
      Rotation var18 = var19;
      Rotation var17 = var19;
      if (var20 == 0) {
         Rotation var21 = var17;
         if (var21 == null) {
            Object[] var10 = new Object[0];
            Rotation var9 = var4;
            float var10003 = var9.aReturningFloat(var10);
            Object[] var12 = new Object[0];
            Rotation var11 = var4;
            this.x = new Rotation(var10003, var11.bReturningFloat(var12));
            this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.z = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.A = dev.prestige.recovery.SourceSupport.asBoolean(0);
            MinecraftClient var13 = b;
            this.C = var13.world;
         }

         RotationManager var10000 = Prestige.o;
         Object[] var16 = new Object[]{this, this.x, var5};
         RotationManager var15 = var10000;
         var15.cReturningBoolean(var16);
         var18 = this.x;
      }

      return var18;
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 64747727674918L ^ 79435948877438L;
      var10001 = 64747727674918L ^ 126260711620731L;
      var10001 = 64747727674918L ^ 94985310179551L;
      var10001 = 64747727674918L ^ 119533971244292L;
      int var12 = Event.bReturningInt();
      Rotation var62 = this.x;
      if (var62 != null) {
         Object[] var16 = new Object[0];
         PlayerUpdateEvent var15 = var1;
         EventPhase var10000 = var15.aReturningEventPhase(var16);
         int var65 = var12;
         EventPhase var64 = EventPhase.PRE;
         EventPhase var63 = var10000;
         EventPhase var48 = var63;
         EventPhase var49 = var64;
         EventPhase var46 = var63;
         EventPhase var47 = var64;
         if (var65 == 0) {
            EventPhase var67 = var47;
            EventPhase var66 = var46;
            if (var66 == var67) {
               RotationManager var94 = Prestige.o;
               Object[] var19 = new Object[]{this, this.x, 79397261631069L};
               RotationManager var18 = var94;
               boolean var68 = var18.cReturningBoolean(var19);
               if (!var68) {
                  this.z = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  return;
               }

               Rotation var98 = this.x;
               Object[] var23 = new Object[0];
               Rotation var22 = var98;
               Object[] var25 = new Object[]{var22.aReturningFloat(var23)};
               PlayerUpdateEvent var24 = var1;
               var24.bReturningVoid(var25);
               Rotation var99 = this.x;
               Object[] var27 = new Object[0];
               Rotation var26 = var99;
               Object[] var29 = new Object[]{var26.bReturningFloat(var27)};
               PlayerUpdateEvent var28 = var1;
               var28.cReturningVoid(var29);
               this.z = dev.prestige.recovery.SourceSupport.asBoolean(1);
               return;
            }

            Object[] var31 = new Object[0];
            PlayerUpdateEvent var30 = var1;
            var10000 = var30.aReturningEventPhase(var31);
            var49 = EventPhase.POST;
            var48 = var10000;
         }

         EventPhase var70 = var49;
         EventPhase var69 = var48;
         if (var69 == var70) {
            int var72 = var12;
            boolean var71 = this.z;
            boolean var52 = var71;
            boolean var50 = var71;
            if (var72 == 0) {
               boolean var73 = var50;
               boolean var51 = var73;
               boolean var74 = var51;
               if (!var74) {
                  return;
               }

               this.z = dev.prestige.recovery.SourceSupport.asBoolean(0);
               RotationManager var93 = Prestige.o;
               Object[] var35 = new Object[]{this, 119298033110777L};
               RotationManager var34 = var93;
               var52 = var34.dReturningBoolean(var35);
            }

            DiagonalPearlCatch var61;
            label96: {
               int var76 = var12;
               boolean var75 = var52;
               boolean var55 = var75;
               boolean var53 = var75;
               if (var76 == 0) {
                  boolean var77 = var53;
                  if (!var77) {
                     return;
                  }

                  int var79 = var12;
                  DiagonalPearlCatch var78 = this;
                  var61 = var78;
                  DiagonalPearlCatch var54 = var78;
                  if (var79 != 0) {
                     break label96;
                  }

                  boolean var80 = var54.A;
                  var55 = var80;
               }

               boolean var81 = var55;
               if (var81) {
                  label61: {
                     DiagonalPearlCatch var60;
                     label90: {
                        boolean var13 = this.B;
                        Object[] var39 = new Object[]{94920566889250L};
                        DiagonalPearlCatch var38 = this;
                        var38.nReturningVoid(var39);
                        int var83 = var12;
                        boolean var82 = var13;
                        boolean var59 = var82;
                        boolean var56 = var82;
                        if (var83 == 0) {
                           boolean var84 = var56;
                           if (!var84) {
                              break label61;
                           }

                           int var86 = var12;
                           DiagonalPearlCatch var85 = this;
                           var60 = var85;
                           DiagonalPearlCatch var57 = var85;
                           if (var86 != 0) {
                              break label90;
                           }

                           DiagonalPearlCatch var87 = var57;
                           DiagonalPearlCatch var58 = var87;
                           DiagonalPearlCatch var42 = var58;
                           boolean var88 = var42.aReturningBoolean();
                           var59 = var88;
                        }

                        boolean var89 = var59;
                        if (!var89) {
                           break label61;
                        }

                        var60 = this;
                     }

                     Object[] var45 = new Object[]{126290808879192L};
                     DiagonalPearlCatch var44 = var60;
                     var44.aReturningVoid(var45);
                  }

                  int var90 = var12;
                  if (var90 == 0) {
                     return;
                  }
               }

               DiagonalPearlCatch var91 = this;
               var61 = var91;
            }

            var61.y = dev.prestige.recovery.SourceSupport.asBoolean(1);
         }
      }
   }

   private void nReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 57799471956990L ^ var2;
      long var4 = var2 ^ 118160400567733L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.bReturningVoid(var7);
      this.x = null;
      this.C = null;
      this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.z = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.A = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.B = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private int aReturningInt(Object[] var1) {
      Predicate var4 = (Predicate)var1[0];
      long var2 = (Long)var1[1];
      var2 = 57799471956990L ^ var2;
      int var10000 = Event.cReturningInt();
      int var5 = var10000;

      byte var16;
      while (true) {
         short var10001 = 31208;
         long var10002 = 6636035958244019226L ^ var2;
         byte var18 = 9;
         int var17 = var6;
         if (var17 < var18) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var26 = var9.getInventory();
            int var11 = var6;
            PlayerInventory var10 = var26;
            ItemStack var7 = var10.getStack(var11);
            int var19 = var5;
            if (var19 != 0) {
               ItemStack var13 = var7;
               Predicate var12 = var4;
               byte var27 = ((byte)((var12.test(var13)) ? 1 : 0));
               int var21 = var5;
               byte var20 = var27;
               var16 = var20;
               byte var14 = var20;
               if (var21 == 0) {
                  break;
               }

               byte var22 = var14;
               byte var15 = var22;
               byte var23 = var15;
               if (var23 != 0) {
                  return var6;
               }

               var6++;
            }

            int var24 = var5;
            if (var24 != 0) {
               continue;
            }
         }

         var16 = -1;
         break;
      }

      return var16;
   }

   private static Vec3d aReturningVec3d(Object[] var0) {
      Vec3d var1 = (Vec3d)var0[0];
      double var6 = (Double)var0[1];
      Vec3d var3 = (Vec3d)var0[2];
      boolean var2 = (Boolean)var0[3];
      long var4 = (Long)var0[4];
      long var10000 = 57799471956990L ^ var4;
      double var9 = var6;
      Vec3d var8 = var1;
      Vec3d var42 = var8.multiply(var9);
      Vec3d var11 = var3;
      boolean var36 = var2;
      double var34 = var11.x;
      Vec3d var33 = var42;
      Vec3d var25 = var33;
      double var26 = var34;
      Vec3d var22 = var33;
      double var23 = var34;
      Vec3d var28;
      double var29;
      double var31;
      if (var36) {
         double var38 = var23;
         Vec3d var37 = var22;
         var28 = var37;
         var29 = var38;
         var31 = var40;
      } else {
         Vec3d var13 = var3;
         var31 = var13.y;
         var29 = var26;
         var28 = var25;
      }

      Vec3d var14 = var3;
      double var20 = var14.z;
      double var18 = var31;
      double var16 = var29;
      Vec3d var15 = var28;
      return var15.add(var16, var18, var20);
   }

   private List bReturningList(Object[] var1) {
      Vec3d var5 = (Vec3d)var1[0];
      Vec3d var6 = (Vec3d)var1[1];
      boolean var2 = (Boolean)var1[2];
      int var7 = (Integer)var1[3];
      long var3 = (Long)var1[4];
      long var10000 = 57799471956990L ^ var3;
      ArrayList var9 = new ArrayList(var7 + 1);
      Vec3d var10 = var5;
      int var36 = Event.cReturningInt();
      Vec3d var11 = var6;
      boolean var12 = var2;
      PositionSegment var21 = new PositionSegment(var10, var11, var12);
      ArrayList var20 = var9;
      var20.add(var21);
      int var8 = var36;

      ArrayList var30;
      while (true) {
         int var32 = var7;
         int var31 = var13;
         if (var31 < var32) {
            Vec3d var23 = var11;
            Vec3d var22 = var10;
            var10 = var22.add(var23);
            Vec3d var24 = var11;
            double var14 = (var24.y - 0.08) * 0.98;
            Vec3d var25 = var11;
            double var16 = var25.x * 0.91;
            Vec3d var26 = var11;
            double var18 = var26.z * 0.91;
            var11 = new Vec3d(var16, var14, var18);
            int var34 = var8;
            ArrayList var33 = var9;
            var30 = var33;
            ArrayList var29 = var33;
            if (var34 == 0) {
               break;
            }

            PositionSegment var28 = new PositionSegment(var10, var11, false);
            ArrayList var27 = var29;
            var27.add(var28);
            var13++;
            int var35 = var8;
            if (var35 != 0) {
               continue;
            }
         }

         var30 = var9;
         break;
      }

      return var30;
   }

   private List cReturningList(Object[] var1) {
      PositionSegment var6 = (PositionSegment)var1[0];
      float var2 = (Float)var1[1];
      float var3 = (Float)var1[2];
      long var4 = (Long)var1[3];
      var4 = 57799471956990L ^ var4;
      long var7 = var4 ^ 109725028328795L;
      long var9 = var4 ^ 200127946284L;
      int var10000 = 15938;
      long var10001 = 4938314521124407947L ^ var4;
      var10000 = Event.cReturningInt();
      ArrayList var13 = new ArrayList(31);
      Object[] var10005 = new Object[]{null, null, var9};
      var10005[1] = var3;
      var10005[0] = var2;
      Object[] var18 = var10005;
      Vec3d var14 = bReturningVec3d(var18);
      Vec3d var10003 = var6.b;
      boolean var10004 = var6.c;
      Object[] var10007 = new Object[]{null, null, null, null, var7};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = 1.5;
      var10007[0] = var14;
      Object[] var19 = var10007;
      Vec3d var15 = aReturningVec3d(var19);
      Vec3d var16 = var6.a;
      Vec3d var21 = var16;
      ArrayList var20 = var13;
      var20.add(var21);
      int var11 = var10000;

      ArrayList var40;
      while (true) {
         byte var42 = 30;
         int var41 = var17;
         label25:
         if (var41 < var42) {
            Vec3d var23 = var15;
            Vec3d var22 = var16;
            var16 = var22.add(var23);
            double var25 = 0.99;
            Vec3d var24 = var15;
            Vec3d var50 = var24.multiply(var25);
            double var30 = 0.03;
            Vec3d var27 = var50;
            var15 = var27.subtract(var28, var30, var32);
            int var44 = var11;
            ArrayList var43 = var13;
            var40 = var43;
            ArrayList var39 = var43;
            if (var44 == 0) {
               break;
            }

            Vec3d var35 = var16;
            ArrayList var34 = var39;
            var34.add(var35);
            int var45 = var11;
            if (var45 != 0) {
               Vec3d var37 = var16;
               Vec3d var38 = var6.a;
               double var51;
               int var46 = (var51 = var37.y - (var38.y - 256.0)) == 0.0 ? 0 : (var51 < 0.0 ? -1 : 1);
               if (var46 < 0) {
                  break label25;
               }

               var17++;
            }

            int var47 = var11;
            if (var47 != 0) {
               continue;
            }
         }

         var40 = var13;
         break;
      }

      return var40;
   }

   private List dReturningList(Object[] var1) {
      PositionSegment var5 = (PositionSegment)var1[0];
      float var7 = (Float)var1[1];
      float var2 = (Float)var1[2];
      int var6 = (Integer)var1[3];
      long var3 = (Long)var1[4];
      var3 = 57799471956990L ^ var3;
      long var8 = var3 ^ 15082910421384L;
      long var10 = var3 ^ 121298506001151L;
      ArrayList var13 = new ArrayList(var6 + 1);
      Object[] var10004 = new Object[]{null, null, var10};
      var10004[1] = var2;
      var10004[0] = var7;
      Object[] var18 = var10004;
      Vec3d var14 = bReturningVec3d(var18);
      Vec3d var10002 = var5.b;
      boolean var10003 = var5.c;
      Object[] var10006 = new Object[]{null, null, null, null, var8};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = 1.5;
      var10006[0] = var14;
      Object[] var19 = var10006;
      Vec3d var15 = aReturningVec3d(var19);
      Vec3d var16 = var5.a;
      int var10000 = Event.cReturningInt();
      Vec3d var21 = var16;
      ArrayList var20 = var13;
      var20.add(var21);
      int var12 = var10000;

      ArrayList var30;
      while (true) {
         int var32 = var6;
         int var31 = var17;
         if (var31 < var32) {
            Vec3d var23 = var15;
            Vec3d var22 = var16;
            var16 = var22.add(var23);
            double var25 = 0.99;
            Vec3d var24 = var15;
            var15 = var24.multiply(var25);
            int var34 = var12;
            ArrayList var33 = var13;
            var30 = var33;
            ArrayList var29 = var33;
            if (var34 == 0) {
               break;
            }

            Vec3d var28 = var16;
            ArrayList var27 = var29;
            var27.add(var28);
            var17++;
            int var35 = var12;
            if (var35 != 0) {
               continue;
            }
         }

         var30 = var13;
         break;
      }

      return var30;
   }

   private DiagonalPearlSolution aReturningaz_C0054(Object[] var1) {
      List var5 = (List)var1[0];
      List var2 = (List)var1[1];
      long var3 = (Long)var1[2];
      var3 = 57799471956990L ^ var3;
      long var6 = var3 ^ 70399692788842L;
      long var8 = var3 ^ 94735575009418L;
      DiagonalPearlSolution var11 = null;
      int var10000 = Event.bReturningInt();
      double var12 = Double.MAX_VALUE;
      int var10 = var10000;
      int var191 = 9765;
      long var10001 = 3384961341998028917L ^ var3;
      List var32 = var2;
      int var15 = var32.size();
      List var33 = var5;
      int var16 = var33.size();
      int var17 = 2;

      DiagonalPearlSolution var108;
      label184:
      while (true) {
         int var87 = var17;

         label181:
         while (true) {
            byte var121 = 15;
            int var120 = var87;
            if (var120 > var121) {
               break;
            }

            int var196 = var15 - 1;
            int var124 = var10;
            int var123 = var196;
            int var122 = var17;
            int var90 = var122;
            int var91 = var123;
            int var88 = var122;
            int var89 = var123;
            if (var124 == 0) {
               int var126 = var89;
               int var125 = var88;
               if (var125 >= var126) {
                  break;
               }

               int var128 = var16;
               int var127 = var17;
               var90 = var127;
               var91 = var128;
            }

            int var130 = var91;
            int var129 = var90;
            if (var129 >= var130) {
               break;
            }

            int var37 = var17;
            List var36 = var5;
            PositionSegment var18 = (PositionSegment)var36.get(var37);
            int var19 = var17 + 1;

            int var162;
            do {
               int var132 = var15;
               int var131 = var19;
               if (var131 >= var132) {
                  break;
               }

               int var39 = var19;
               List var38 = var2;
               Vec3d var20 = (Vec3d)var38.get(var39);
               int var21 = var19 - var17;
               Vec3d var41 = var18.a;
               Vec3d var40 = var20;
               Vec3d var22 = var40.subtract(var41);
               Vec3d var42 = var22;
               double var197;
               var191 = (var197 = var42.lengthSquared() - 1.0E-6) == 0.0 ? 0 : (var197 < 0.0 ? -1 : 1);
               int var134 = var10;
               int var133 = var191;
               var87 = var133;
               int var92 = var133;
               if (var134 != 0) {
                  continue label181;
               }

               label191: {
                  Vec3d var97;
                  label174: {
                     PositionSegment var96;
                     label192: {
                        int var136 = var10;
                        int var135 = var92;
                        int var95 = var135;
                        int var93 = var135;
                        if (var136 == 0) {
                           int var137 = var93;
                           if (var137 < 0) {
                              break label191;
                           }

                           int var139 = var10;
                           PositionSegment var138 = var18;
                           var96 = var138;
                           PositionSegment var94 = var138;
                           if (var139 != 0) {
                              break label192;
                           }

                           byte var140 = ((byte)((var94.c) ? 1 : 0));
                           var95 = var140;
                        }

                        int var141 = var95;
                        if (var141 != 0) {
                           Vec3d var45 = var18.b;
                           Vec3d var46 = var18.b;
                           Vec3d var142 = new Vec3d(var45.x, 0.0, var46.z);
                           var97 = var142;
                           break label174;
                        }

                        var96 = var18;
                     }

                     var97 = var96.b;
                  }

                  Vec3d var23 = var97;
                  double var49 = var21;
                  Vec3d var48 = var23;
                  Vec3d var52 = var48.multiply(var49);
                  Vec3d var51 = var22;
                  Vec3d var24 = var51.subtract(var52);
                  Vec3d var53 = var24;
                  double var193 = -var53.x;
                  Vec3d var54 = var24;
                  double var57 = var54.z;
                  double var55 = var193;
                  double var59 = Math.atan2(var55, var57);
                  float var25 = (float)Math.toDegrees(var59);
                  Vec3d var61 = var24;
                  Vec3d var62 = var24;
                  double var194 = var61.x * var62.x;
                  Vec3d var63 = var24;
                  Vec3d var64 = var24;
                  double var65 = var194 + var63.z * var64.z;
                  double var26 = Math.sqrt(var65);
                  Vec3d var67 = var24;
                  double var70 = var26;
                  double var68 = var67.y;
                  double var72 = -Math.atan2(var68, var70);
                  float var28 = (float)Math.toDegrees(var72);
                  float var98 = var28 - 5.0F;

                  label161:
                  while (true) {
                     float var29 = var98;

                     while (true) {
                        float var198;
                        int var143 = (var198 = var29 - (var28 + 5.0F)) == 0.0F ? 0 : (var198 < 0.0F ? -1 : 1);
                        if (var143 > 0) {
                           break label161;
                        }

                        float var195 = var25 - 5.0F;
                        int var145 = var10;
                        float var144 = var195;
                        var98 = var144;
                        float var99 = var144;
                        if (var145 != 0) {
                           break;
                        }

                        float var30 = var99;

                        int var160;
                        do {
                           float var199;
                           int var146 = (var199 = var30 - (var25 + 5.0F)) == 0.0F ? 0 : (var199 < 0.0F ? -1 : 1);
                           if (var146 > 0) {
                              break;
                           }

                           Object[] var10009 = new Object[]{null, null, null, null, null, null, var8};
                           var10009[5] = var29;
                           var10009[4] = var30;
                           var10009[3] = var21;
                           var10009[2] = var17;
                           var10009[1] = var2;
                           var10009[0] = var18;
                           Object[] var75 = var10009;
                           DiagonalPearlCatch var74 = this;
                           DiagonalPearlSolution var31 = var74.bReturningaz_C0054(var75);
                           int var147 = var10;
                           if (var147 == 0) {
                              int var149 = var10;
                              DiagonalPearlSolution var148 = var31;
                              var108 = var148;
                              DiagonalPearlSolution var100 = var148;
                              if (var149 != 0) {
                                 break label184;
                              }

                              DiagonalPearlSolution var150 = var100;
                              DiagonalPearlSolution var101 = var150;
                              DiagonalPearlSolution var151 = var101;
                              label149:
                              if (var151 != null) {
                                 int var154 = var10;
                                 double var152 = var31.d;
                                 double var106 = var152;
                                 double var102 = var152;
                                 if (var154 == 0) {
                                    double var155 = var102;
                                    double var104 = var155;
                                    double var200;
                                    int var157 = (var200 = var104 - var12) == 0.0 ? 0 : (var200 < 0.0 ? -1 : 1);
                                    if (var157 >= 0) {
                                       break label149;
                                    }

                                    double var158 = var31.d;
                                    var106 = var158;
                                 }

                                 var12 = var106;
                                 var11 = var31;
                              }

                              var30 += 0.5F;
                           }

                           var160 = var10;
                        } while (var160 == 0);

                        var29 += 0.5F;
                        int var161 = var10;
                        if (var161 != 0) {
                           break label161;
                        }
                     }
                  }
               }

               var19++;
               var162 = var10;
            } while (var162 == 0);

            var17++;
            int var163 = var10;
            if (var163 == 0) {
               continue label184;
            }
            break;
         }

         var108 = var11;
         break;
      }

      int var165 = var10;
      DiagonalPearlSolution var164 = var108;
      Object var110 = var164;
      DiagonalPearlSolution var109 = var164;
      if (var165 == 0) {
         DiagonalPearlSolution var166 = var109;
         if (var166 == null) {
            return null;
         }

         int var84 = var11.a;
         List var83 = var5;
         var110 = var83.get(var84);
      }

      PositionSegment var187 = (PositionSegment)var110;
      float var188 = var11.c - 0.5F;

      DiagonalPearlSolution var117;
      label113:
      while (true) {
         float var201;
         int var167 = (var201 = var188 - (var11.c + 0.5F)) == 0.0F ? 0 : (var201 < 0.0F ? -1 : 1);
         if (var167 <= 0) {
            int var169 = var10;
            DiagonalPearlSolution var168 = var11;
            var117 = var168;
            DiagonalPearlSolution var111 = var168;
            if (var169 != 0) {
               break;
            }

            float var189 = var111.b - 1.0F;

            int var181;
            do {
               float var202;
               int var170 = (var202 = var189 - (var11.b + 1.0F)) == 0.0F ? 0 : (var202 < 0.0F ? -1 : 1);
               if (var170 > 0) {
                  break;
               }

               int var10003 = var11.a;
               Object[] var10008 = new Object[]{null, null, null, null, null, var6};
               var10008[4] = var188;
               var10008[3] = var189;
               var10008[2] = var10003;
               var10008[1] = var2;
               var10008[0] = var187;
               Object[] var86 = var10008;
               DiagonalPearlCatch var85 = this;
               DiagonalPearlSolution var190 = var85.cReturningaz_C0054(var86);
               int var171 = var10;
               if (var171 == 0) {
                  int var173 = var10;
                  DiagonalPearlSolution var172 = var190;
                  var117 = var172;
                  DiagonalPearlSolution var112 = var172;
                  if (var173 != 0) {
                     break label113;
                  }

                  DiagonalPearlSolution var174 = var112;
                  DiagonalPearlSolution var113 = var174;
                  DiagonalPearlSolution var175 = var113;
                  label101:
                  if (var175 != null) {
                     int var177 = var10;
                     DiagonalPearlSolution var176 = var190;
                     DiagonalPearlSolution var116 = var176;
                     DiagonalPearlSolution var114 = var176;
                     if (var177 == 0) {
                        DiagonalPearlSolution var178 = var114;
                        DiagonalPearlSolution var115 = var178;
                        double var203;
                        int var179 = (var203 = var115.d - var11.d) == 0.0 ? 0 : (var203 < 0.0 ? -1 : 1);
                        if (var179 >= 0) {
                           break label101;
                        }

                        DiagonalPearlSolution var180 = var190;
                        var116 = var180;
                     }

                     var11 = var116;
                  }

                  var189 += 0.1F;
               }

               var181 = var10;
            } while (var181 == 0);

            var188 += 0.05F;
            int var182 = var10;
            if (var182 == 0) {
               continue;
            }
         }

         var117 = var11;
         break;
      }

      int var184 = var10;
      DiagonalPearlSolution var183 = var117;
      DiagonalPearlSolution var119 = var183;
      DiagonalPearlSolution var118 = var183;
      if (var184 == 0) {
         double var204;
         int var185 = (var204 = var118.d - 0.4) == 0.0 ? 0 : (var204 < 0.0 ? -1 : 1);
         if (var185 > 0) {
            return null;
         }

         var119 = var11;
      }

      return var119;
   }

   private DiagonalPearlSolution bReturningaz_C0054(Object[] var1) {
      PositionSegment var7 = (PositionSegment)var1[0];
      List var9 = (List)var1[1];
      int var8 = (Integer)var1[2];
      int var4 = (Integer)var1[3];
      float var2 = (Float)var1[4];
      float var3 = (Float)var1[5];
      long var5 = (Long)var1[6];
      var5 = 57799471956990L ^ var5;
      long var10 = var5 ^ 15598382233282L;
      int var10000 = Event.bReturningInt();
      int var10005 = var4 + 4;
      Object[] var10008 = new Object[]{null, null, null, null, var10};
      var10008[3] = var10005;
      var10008[2] = var3;
      var10008[1] = var2;
      var10008[0] = var7;
      Object[] var22 = var10008;
      DiagonalPearlCatch var21 = this;
      List var13 = var21.dReturningList(var22);
      double var14 = Double.MAX_VALUE;
      int var12 = var10000;
      int var16 = var8;
      int var17 = 1;

      int var38;
      while (true) {
         List var23 = var13;
         int var40 = var23.size();
         int var39 = var17;
         if (var39 < var40) {
            int var18 = var8 + var17;
            int var42 = var12;
            int var41 = var18;
            var38 = var41;
            int var37 = var41;
            if (var42 != 0) {
               break;
            }

            List var24 = var9;
            int var44 = var24.size();
            int var43 = var37;
            if (var43 < var44) {
               int var28 = var17;
               List var27 = var13;
               Vec3d var50 = (Vec3d)var27.get(var28);
               int var30 = var18;
               List var29 = var9;
               Vec3d var32 = (Vec3d)var29.get(var30);
               Vec3d var31 = var50;
               double var19 = var31.squaredDistanceTo(var32);
               int var45 = var12;
               if (var45 == 0) {
                  double var51;
                  int var46 = (var51 = var19 - var14) == 0.0 ? 0 : (var51 < 0.0 ? -1 : 1);
                  if (var46 < 0) {
                     var14 = var19;
                     var16 = var18;
                  }

                  var17++;
               }

               int var47 = var12;
               if (var47 == 0) {
                  continue;
               }
            }
         }

         double var52;
         var38 = (var52 = var14 - (Double.MAX_VALUE)) == 0.0 ? 0 : (var52 < 0.0 ? -1 : 1);
         break;
      }

      int var48 = var38;
      if (var48 == 0) {
         return null;
      }

      double var35 = var14;
      return new DiagonalPearlSolution(var8, var2, var3, Math.sqrt(var35), var16);
   }

   private DiagonalPearlSolution cReturningaz_C0054(Object[] var1) {
      PositionSegment var8 = (PositionSegment)var1[0];
      List var2 = (List)var1[1];
      int var6 = (Integer)var1[2];
      float var3 = (Float)var1[3];
      float var7 = (Float)var1[4];
      long var4 = (Long)var1[5];
      var4 = 57799471956990L ^ var4;
      long var9 = var4 ^ 26395341072930L;
      int var10000 = Event.cReturningInt();
      List var21 = var2;
      int var12 = var21.size() - var6;
      int var11 = var10000;
      byte var42 = 1;
      int var41 = var12;
      if (var41 <= var42) {
         return null;
      }

      Object[] var10007 = new Object[]{null, null, null, null, var9};
      var10007[3] = var12;
      var10007[2] = var7;
      var10007[1] = var3;
      var10007[0] = var8;
      Object[] var24 = var10007;
      DiagonalPearlCatch var23 = this;
      List var13 = var23.dReturningList(var24);
      double var14 = Double.MAX_VALUE;
      int var16 = var6;
      int var17 = 1;

      int var40;
      while (true) {
         List var25 = var13;
         int var44 = var25.size();
         int var43 = var17;
         if (var43 < var44) {
            int var18 = var6 + var17;
            int var46 = var11;
            int var45 = var18;
            var40 = var45;
            int var39 = var45;
            if (var46 == 0) {
               break;
            }

            List var26 = var2;
            int var48 = var26.size();
            int var47 = var39;
            if (var47 < var48) {
               int var30 = var17;
               List var29 = var13;
               Vec3d var54 = (Vec3d)var29.get(var30);
               int var32 = var18;
               List var31 = var2;
               Vec3d var34 = (Vec3d)var31.get(var32);
               Vec3d var33 = var54;
               double var19 = var33.squaredDistanceTo(var34);
               int var49 = var11;
               if (var49 != 0) {
                  double var55;
                  int var50 = (var55 = var19 - var14) == 0.0 ? 0 : (var55 < 0.0 ? -1 : 1);
                  if (var50 < 0) {
                     var14 = var19;
                     var16 = var18;
                  }

                  var17++;
               }

               int var51 = var11;
               if (var51 != 0) {
                  continue;
               }
            }
         }

         double var56;
         var40 = (var56 = var14 - (Double.MAX_VALUE)) == 0.0 ? 0 : (var56 < 0.0 ? -1 : 1);
         break;
      }

      int var52 = var40;
      if (var52 == 0) {
         return null;
      }

      double var37 = var14;
      return new DiagonalPearlSolution(var6, var3, var7, Math.sqrt(var37), var16);
   }

   private static Vec3d bReturningVec3d(Object[] var0) {
      float var3 = (Float)var0[0];
      float var4 = (Float)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 57799471956990L ^ var1;
      double var15 = var3;
      float var5 = (float)Math.toRadians(var15);
      double var17 = var4;
      float var6 = (float)Math.toRadians(var17);
      double var19 = var5;
      float var32 = -MathHelper.sin(var19);
      double var21 = var6;
      double var7 = var32 * MathHelper.cos(var21);
      double var23 = var6;
      double var9 = -MathHelper.sin(var23);
      double var25 = var5;
      float var33 = MathHelper.cos(var25);
      double var27 = var6;
      double var11 = var33 * MathHelper.cos(var27);
      double var29 = var7 * var7 + var9 * var9 + var11 * var11;
      double var13 = Math.sqrt(var29);
      double var34;
      int var31 = (var34 = var13 - 1.0E-9) == 0.0 ? 0 : (var34 < 0.0 ? -1 : 1);
      return var31 < 0 ? new Vec3d(0.0, 0.0, 1.0) : new Vec3d(var7 / var13, var9 / var13, var11 / var13);
   }

   private static boolean lambda$onTick$4(ItemStack var0) {
      int var3 = Event.cReturningInt();
      int var12 = var3;
      ItemStack var11 = var0;
      ItemStack var9 = var11;
      ItemStack var8 = var11;
      if (var12 != 0) {
         ItemStack var4 = var8;
         boolean var13 = var4.isEmpty();
         if (var13) {
            return false;
         }

         ItemStack var14 = var0;
         var9 = var14;
      }

      ItemStack var7 = var9;
      Item var10000 = var7.getItem();
      Item var16 = Items.ENDER_PEARL;
      Item var15 = var10000;
      return var15 == var16;
   }

   private static boolean lambda$onTick$3(ItemStack var0) {
      long var10001 = 22508940268723L ^ 54145056713773L;
      int var5 = Event.bReturningInt();
      ItemStack var6 = var0;
      byte var10000 = ((byte)((var6.isEmpty()) ? 1 : 0));
      int var15 = var5;
      byte var14 = var10000;
      byte var10 = var14;
      byte var9 = var14;
      if (var15 == 0) {
         byte var16 = var9;
         if (var16 != 0) {
            return false;
         }

         Object[] var8 = new Object[]{var0, 40984284805278L};
         byte var17 = ((byte)((InventoryUtil.p(var8)) ? 1 : 0));
         var10 = var17;
      }

      int var19 = var5;
      byte var18 = var10;
      byte var12 = var18;
      byte var11 = var18;
      if (var19 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var12);
      } else {
         byte var20 = var11;
         if (var20 != 0) {
            var12 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var12);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$2(Float var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Trajectory";
      String var6 = var10000;
      byte var24 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var17 = var4;
      byte var16 = var24;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         BooleanSetting var9 = this.d;
         Boolean var10 = (Boolean)var9.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var10)).booleanValue() ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Trajectory";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Macro";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(78283202505995L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[4];
      String var17 = "à¤G\u0015\u0098Zí¤É>=ªc$;»ú¿fVS êH\u0018Eãô_¿\u001f\u0013R7s\u001b0J±]\u0085.K\"£Ý\u0087?\u0013";
      int var19 = "à¤G\u0015\u0098Zí¤É>=ªc$;»ú¿fVS êH\u0018Eãô_¿\u001f\u0013R7s\u001b0J±]\u0085.K\"£Ý\u0087?\u0013".length();
      char var16 = 24;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     F = var20;
                     G = new String[4];
                     K = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(78283202505995L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[6];
                     String var4 = "_·nÙª\u0082S\u008b\\; \u00869¥Á\u009frçp\u008b!\u0005\u0087\u001fl\u0003ïK\u0088s×\u0004";
                     int var5 = "_·nÙª\u0082S\u008b\\; \u00869¥Á\u009frçp\u008b!\u0005\u0087\u001fl\u0003ïK\u0088s×\u0004".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    I = var6;
                                    J = new Integer[6];
                                    g = 15;
                                    h = 30;
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\fÓ\u001aÈá;S{\"ÀN?½%¹»";
                                 var5 = "\fÓ\u001aÈá;S{\"ÀN?½%¹»".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "÷ëþ\u0015\u0012P-%©ØZ\u000bX\u008b\u0096\u0099\u0010\\Î¾\u0012ßañYÌ\u001a¥Q(HÌý";
                  var19 = "÷ëþ\u0015\u0012P-%©ØZ\u000bX\u008b\u0096\u0099\u0010\\Î¾\u0012ßañYÌ\u001a¥Q(HÌý".length();
                  var16 = 16;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9846;
      if (G[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])H.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               H.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ex", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = F[var5].getBytes("ISO-8859-1");
         G[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return G[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ex_C0264",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ex" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12682;
      if (J[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = I[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])K.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               K.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ex", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         J[var3] = var15;
      }

      return J[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ex_C0264",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ex" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = M[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = L[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 30;
            yield var15;
         }
         case 1 -> {
            byte var16 = 21;
            yield var16;
         }
         case 2 -> {
            byte var17 = 42;
            yield var17;
         }
         case 3 -> {
            byte var18 = 53;
            yield var18;
         }
         case 4 -> {
            byte var19 = 36;
            yield var19;
         }
         case 5 -> {
            byte var20 = 19;
            yield var20;
         }
         case 6 -> {
            byte var21 = 51;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 52;
            yield var23;
         }
         case 9 -> {
            byte var24 = 40;
            yield var24;
         }
         case 10 -> {
            byte var25 = 43;
            yield var25;
         }
         case 11 -> {
            byte var26 = 38;
            yield var26;
         }
         case 12 -> {
            byte var27 = 35;
            yield var27;
         }
         case 13 -> {
            byte var28 = 8;
            yield var28;
         }
         case 14 -> {
            byte var29 = 15;
            yield var29;
         }
         case 15 -> {
            byte var30 = 18;
            yield var30;
         }
         case 16 -> {
            byte var31 = 57;
            yield var31;
         }
         case 17 -> {
            byte var32 = 17;
            yield var32;
         }
         case 18 -> {
            byte var33 = 32;
            yield var33;
         }
         case 19 -> {
            byte var34 = 49;
            yield var34;
         }
         case 20 -> {
            byte var35 = 44;
            yield var35;
         }
         case 21 -> {
            byte var36 = 0;
            yield var36;
         }
         case 22 -> {
            byte var37 = 16;
            yield var37;
         }
         case 23 -> {
            byte var38 = 34;
            yield var38;
         }
         case 24 -> {
            byte var39 = 62;
            yield var39;
         }
         case 25 -> {
            byte var40 = 10;
            yield var40;
         }
         case 26 -> {
            byte var41 = 29;
            yield var41;
         }
         case 27 -> {
            byte var42 = 1;
            yield var42;
         }
         case 28 -> {
            byte var43 = 25;
            yield var43;
         }
         case 29 -> {
            byte var44 = 31;
            yield var44;
         }
         case 30 -> {
            byte var45 = 55;
            yield var45;
         }
         case 31 -> {
            byte var46 = 26;
            yield var46;
         }
         case 32 -> {
            byte var47 = 14;
            yield var47;
         }
         case 33 -> {
            byte var48 = 22;
            yield var48;
         }
         case 34 -> {
            byte var49 = 39;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 50;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 56;
            yield var53;
         }
         case 39 -> {
            byte var54 = 6;
            yield var54;
         }
         case 40 -> {
            byte var55 = 48;
            yield var55;
         }
         case 41 -> {
            byte var56 = 4;
            yield var56;
         }
         case 42 -> {
            byte var57 = 5;
            yield var57;
         }
         case 43 -> {
            byte var58 = 20;
            yield var58;
         }
         case 44 -> {
            byte var59 = 23;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 41;
            yield var61;
         }
         case 47 -> {
            byte var62 = 27;
            yield var62;
         }
         case 48 -> {
            byte var63 = 46;
            yield var63;
         }
         case 49 -> {
            byte var64 = 3;
            yield var64;
         }
         case 50 -> {
            byte var65 = 58;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 45;
            yield var67;
         }
         case 53 -> {
            byte var68 = 7;
            yield var68;
         }
         case 54 -> {
            byte var69 = 2;
            yield var69;
         }
         case 55 -> {
            byte var70 = 24;
            yield var70;
         }
         case 56 -> {
            byte var71 = 12;
            yield var71;
         }
         case 57 -> {
            byte var72 = 61;
            yield var72;
         }
         case 58 -> {
            byte var73 = 60;
            yield var73;
         }
         case 59 -> {
            byte var74 = 47;
            yield var74;
         }
         case 60 -> {
            byte var75 = 37;
            yield var75;
         }
         case 61 -> {
            byte var76 = 28;
            yield var76;
         }
         case 62 -> {
            byte var77 = 54;
            yield var77;
         }
         default -> 9;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            M[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      L[0] = "!\u0001~\u0015SC7\u0001{O@T JxIL@1\ro^\u0007R\u0000";
      L[1] = int.class;
      M[1] = "java/lang/Integer";
      L[2] = "\fk5uWn\u001ak0/Dy\r 3)Hm\u001cg$>\u0003}\u0007";
      L[3] = "K0\u000f\u0006\u00170>\u0010\u0004\t\u0006\u007f_\u001e\u000f\u0002\u0002%+";
      L[4] = boolean.class;
      M[4] = "java/lang/Boolean";
      L[5] = "\u0016_v!\u0013c\u0016_a}\u001fl\f\u0014ac\u001fy\u000be38G3";
      L[6] = "\u000e\u001cza\u0016_\u0018\u001c\u007f;\u0005H\u000fW|=\t\\\u001e\u0010k*BJ\u0012";
      L[7] = "\"[Q'O-)T@h, <YO\u0003\u0019\"-JS/\u000e/";
      L[8] = "a\f;O+?a\f,\u0013'0{G,\r'%|6}Uu";
      L[9] = double.class;
      M[9] = "java/lang/Double";
      L[10] = "Ui\u0015\u001b\u007fwKa\u000fT\u001dkL|";
      L[11] = "\u0000%M([+\u000b*\\g:%\u0000!X=";
      L[12] = "t |'\fB\u0001\u0000w(\u001d\r`\u000e|#\u0019W\u0014";
      L[13] = "\u0012Ai#G\u001dgab,VR\u0006oi'R\br";
      L[14] = "yO\f\u000e\f\u001dyO\u001bR\u0000\u0012c\u0004\u001bL\u0000\u0007duK\u0015RF";
      L[15] = float.class;
      M[15] = "java/lang/Float";
      L[16] = "Y\u001c\u0003S\tvR\u0013\u0012\u001cj{G\u0015";
      L[17] = ";*b'\u001cQ%\"xhaA%";
      L[18] = "R\u000e\u0001Vi\u0000Y\u0001\u0010\u0019\u0014\u0018J\u0006\u0019P";
      L[19] = "}IREzp}IE\u0019v\u007fg\u0002E\u0007vj`s\u0011_!";
      L[20] = "w\u0003\u0001bMg|\f\u0010-!dr\u000e\u0012b\r";
      L[21] = "\b-y\tZE\u001e-|SIR\tf\u007fUEF\u0018!hB\u000eQ*";
      L[22] = "\u0003P\n}\u0011\u0000\u0003P\u001d!\u001d\u000f\u0019\u001b\u001d?\u001d\u001a\u001ejMbL";
      L[23] = "{\u0005\u001cL3Bp\n\r\u0003[B~\u0005\u001e";
      L[24] = "*L\fu\u007f\u0006<L\t/l\u0011+\u0007\n)`\u0005:@\u001d>+\u0012\f";
      L[25] = "_u~:\u0002z*Uu5\u00135K[~>\u0017o?";
      L[26] = "lZ:4V\u0016\u0019z1;GYxt:0C\u0003\f";
      L[27] = "1\u007f/Q6TD_$^'\u001b%Q/U#AQ";
      L[28] = void.class;
      M[28] = "java/lang/Void";
      L[29] = "\u000b^.a\u001fF\u001d^+;\fQ\n\u0015(=\u0000E\u001bR?*KR>";
      L[30] = "\u0014H;sFJah0|W\u0005\u0000f;wS_t";
      L[31] = "D94F\u0012h1\u0019?I\u0003'P\u00174B\u0007}$";
      L[32] = "\u000e#\"-]+{\u0003)\"Ld\u001a\r\")H>n";
      L[33] = "\u001dIJ\u000e=R\u000bIOT.E\u001c\u0002LR\"Q\rE[EiF\u0001";
      L[34] = "Kc\u0013lR\u0006>C\u0018cCI_M\u0013hG\u0013+";
      L[35] = "\u0003\bD\u007fM!v(Op\\n\u0017&D{X4c";
      L[36] = "\"vl[\u0015r\"v{\u0007\u0019}8={\u0019\u0019h?L,FO";
      L[37] = "\u000b\\cl9m\u000b\\t05b\u0011\u0017t.5w\u0016f!ql";
      L[38] = "'\u001dLFtMR=GIe\u000233LBaXG";
      L[39] = "T4J\u001b\u001c\u0001B4OA\u000f\u0016U\u007fLG\u0003\u0002D8[PH\u0015I";
      L[40] = "'\u0006\u000f\u0003\u0003[R&\u0004\f\u0012\u00143(\u000f\u0007\u0016NG";
      L[41] = "\u0014G/\u007f\u0007.ag$p\u0016a\u0000i/{\u0012;t";
      L[42] = "R\u001cC#y\u001eD\u001cFyj\tSWE\u007ff\u001dB\u0010Rh-\rZ\u0010Pcw@f\u000bP~w\u0007Q\u001c";
      L[43] = "1p\u0007ZF-'p\u0002\u0000U:0;\u0001\u0006Y.!|\u0016\u0011\u0012;\f";
      L[44] = "\u0015mgArK`MlNc\u0004\u0001CgEg^u";
      L[45] = "4f\u0017\u001bp<AF\u001c\u0014as H\u0017\u001fe)T";
      L[46] = "O+\u007fO;P:\u000bt@*\u001f[\u0005\u007fK.E/";
      L[47] = "0trC<.ETyL-a$ZrG);P";
      L[48] = "&YMus;&YZ)\u007f4<\u0012Z7\u007f!;c\bl'`";
      L[49] = "X|\u0015A\u0006dX|\u0002\u001d\nkB7\u0002\u0003\n~EFPW[?";
      L[50] = "\u0000KfYLG\u0016Kc\u0003_P\u0001\u0000`\u0005SD\u0010Gw\u0012\u0018U\u0005";
      L[51] = "L\u0006K.U)9&@!DfX(K*@<,";
      L[52] = "\u0004xJ+;oqXA$* \u0010VJ/.zd";
      L[53] = "IXl\u001ea\u0018<xg\u0011pW]vl\u001at\r)";
      L[54] = "$M\n?YrQm\u00010H=0c\n;LgD";
      L[55] = "\u00072\u0010\u00172<\u00112\u0015M!+\u0006y\u0016K-?\u0017>\u0001\\f;";
      L[56] = ": \u00174a#O\u0000\u001c;pl.\u000e\u00170t6Z";
      L[57] = "O!FEN\u001d:\u0001MJ_R[\u000fFA[\b/";
      L[58] = "]\u0016I\u0019:-(6B\u0016+bI8I\u001d/8=";
      L[59] = "at,so4\u0014T'|~{uZ,wz!\u0001";
      L[60] = "X \u0000+\u0004\n-\u0000\u000b$\u0015EL\u000e\u0000/\u0011\u001f8";
      L[61] = "15,5e\u0019D\u0015':tV%\u001b,1p\fQ";
      L[62] = "\u0007a@Qf\u0011\u0011aE\u000bu\u0006\u0006*F\ry\u0012\u0017mQ\u001a2\b";
      L[63] = "8\u001b;\u0016E#M;0\u0019Tl,5;\u0012P6X";
      L[64] = "\u000b\u0005/)A\u007f\u000b\u00058uMp\u0011N8kMe\u0016?j1\u001a'";
      L[65] = "\u0007t}u)Q\u0019|g:aQ\u0003v\u007f}hJCEyqcM\u000et\u007fq";
      L[66] = "e\u00005`f8\u0010 >owwq.5ds-\u0005";
      L[67] = "e[ek9Y\u0010{nd(\u0016queo,L\u0005";
      L[68] = "A?T\u001a>7W?Q@- @tRF!4Q3EQj&_";
      L[69] = "EX%L\u0014i0x.C\u0005&Qv%H\u0001|%";
      L[70] = ",8\u0007(\u000e/Y\u0018\f'\u001f`8\u0016\u0007,\u001b:L";
      L[71] = "!]Fy\u0016hT}Mv\u0007'5sF}\u0003}A";
      L[72] = ";\u0019Kj6U-\u0019N0%B:RM6)V+\u0015Z!bF3";
      L[73] = "\u0019\u0013p\u001dT3l3{\u0012E|\r=p\u0019A&y";
      L[74] = "\u0004\b \u0015T[q(+\u001aE\u0014\u0010& \u0011ANd";
      L[75] = "!//|@N!/8 LA;d8>LT<\u0015j`\u001b\u001f";
      L[76] = "Z\u0001\u0013\tO1/!\u0018\u0006^~N/\u0013\rZ$:";
      L[77] = "\u001cPIU.{ipBZ?4\b~IQ;n|";
      L[78] = "E\u0017o*cz07d%r5Q9o.vo%";
      L[79] = "N\fy\"s\u001a;,r-bUZ\"y&f\u000f.";
      L[80] = "~q&Wls}d?C\u0014(B2,Q+.;z P\u007f(Bi.\u0014ms2v!\u0015lM";
      L[81] = "8o+\u001d2I)-lAU\u001d9,1\u00169/oilMexm`(\u0012'G6nhM(x";
      L[82] = "7?mb\u000f\u00074*tvwZ\u000b|gdHZr4ke\u001c\\\u000b'e!\u000e\u0007{8j \u000f9";
      L[83] = "Y4x)\u0014t\f'ded{V5yx3,\be \u0014\u001c+G3a\u007fZkQb";
      L[84] = "UtBO|l\u0000n\u0011\u001c\u0006s\twIEjA]6\u0012\u001c<\u0016ZuB\u001f6y\u0000fRM\u0006\u007f\u0004gX[x\u007f\u000buV\"";
      L[85] = ".BR\u0005zf?\u0000\u0015Y\u001d2/\u0001H\u000eq\u0000yC\u0014T!W+\u001dD\u0018d)+\u0012V\u0016\u001d";
      L[86] = "L\b g\bR\n\u00122pgT\u001a\u0014*y\u000bfHYt&g\n\u001e\u000e8l\nV\u001cU*\u001e";
      L[87] = "G]:XnhY^t]U{=^)AjtD\u0016%@>r=\u0005+\u0004,)M\u001a$\u0005-\u0017";
      L[88] = "mi(4X;8z4x(?ny-nD\r:8s8(ajc?{E=h8-\t";
      L[89] = "\u007f|\baMe|i\u0011u51C?\u0002g\n8:w\u000ef^>C8Yf\n<(a[|\b[";
      L[90] = "(oWT&U9-\u0010\bA\u0001),M_-3~l\u001d\u0002qd\u007f9KJ3\t#;\u0010XA";
      L[91] = "\u0019H-\nt\u001bCJ \u000e\u0004\u0017\u0014w9\u001ae\u0002\u0015VPHz\u0000N\u001d?\u0012i\u0010\u001c-n\boVCB4\u001b\u007f\u0004s";
      L[92] = "\u0013K 5\nq\u0002\tgim%\u0012\b:>\u0001\u0017DJfdP@\u0016\u00146(\u0014>\u0016\u001b$&m";
      L[93] = ":i%$@@lbq4^$\u007f5`4>\u001b{)&yG\u001ed?kH\u0005Me*i%YO>8\u001b";
      L[94] = "yU\tj\u001b?z@\u0010~chE\u0013\u0012i\t`<L\u001a)\u0011\u0001y_\u0018y\u0002x&WXac";
      L[95] = "{D%s|\u0003:L>zFW\u0006\u0010&oy]\u007fX*n-[\u0006@'|7Gx@(n9>";
      L[96] = "uo-!#T/m %S_fp,]mZt7`27IdePc-O\":?9>_p\n";
      L[97] = "?d\u001f80Cef\u0012<@Z?zb- _$x\u001c-/M*\u0001\u000b$,B,\u007f\u000b+>LU";
      L[98] = "9\\\u00109x\u001fi\u0011\u001bh#ug\u0019\u00124$\u001cdc\u0002<\u007f\u00171\\\u00109xu";
      L[99] = "gU&'\u0017\u0014v\u0017a{p@f\u0016<,\u001cr0QatI%5P\"t\u0017NlR8vp";
      L[100] = "\"mP4\u0018\n{oJ6\u007f\u0004q+Nl\u00136%o\u00144\u007f_b<\u0013;\u0010\u0005q,A\u000b";
      L[101] = "-#IA\u0016`t!SCqertS\u0012&2($\u000e~Oux$\u0007\u0011\u0015fhv";
      L[102] = "P\\\u0015\u0012\u0014i\u0003\n\u000e\u0002xkE\u001a\u000e\n\u0003\u0006\u0003\u001f\u0016SI\u007f\u0006\u0000\u0000\u001ex=U\u0001\u0015\u001c\u0015aWZ\u0007n";
      L[103] = "B\u000eD8t`\u001b\f^:\u0013e\u001dY^kD2G\t\u0000\u0007-u\u0017\t\nhwf\u0007[";
      L[104] = "\u000f \u001az\u0003s\f5\u0003n{'3c\u0010|D.J+\u001c}\u0010(3<\u0011`F.I0J9\u000bM";
      L[105] = "}?\u0011Z_h6bNW$2\u000f:IW\u001b:vrEVO<\u000faK\u0012]g\u007f~D\u0013\\Y";
      L[106] = "\u0005\u0012y\u001eo\u0006\u0006\u0007`\n\u0017T9Qs\u0018([@\u0019\u007f\u0019|]9W)\u000e}\bZ\ni[u8";
      L[107] = "x(\u001cY<5{=\u0005MDiDk\u0016_{h=#\u001a^/nD0\u0014\u001a=54/\u001b\u001b<\u000b";
      L[108] = "D]\u0017\u00177\u000f\u0011GDDM\u0010\u0018^\u001c\u001d!\"L\u001fGEquK\\\u0017G}\u001a\u0011O\u0007\u0015M\u001c\u0015N\r\u00033\u001c\u001a\\\u0003z";
      L[109] = "z(\fs&>u \u0003oL6\u0019 \u001dqs<`h\u0011p':\u0019{\u001f45aid\u001054_";
      L[110] = "\u001a\u0019\u0014!kX\u0019\f\r5\u0013\n&Z\u001e',\u0005_\u0012\u0012&x\u0003&X\u0016>a\u0014K\u0004\u0014esf";
      L[111] = "$<\u0003\u001bjP\u007f2CDeoxa\u0006\u0018\u007f\u0003J1FC(oaeG\u001a)Ps`@x#\u000fwu\u0015\u001be\u0015ebz";
      L[112] = "\u001c\u0010x\u0013M$AP-\u001b}(NW\u0011\u0005\u0014zA\u001a.\u0017\u0011}#\u0014i\b@vZ\u0011v\u001e\rG";
      L[113] = "_\u001bA\u0012\u000bG\n\b]^{HP\u001a@C,\u001f\u000fG\u001b/\u0003\\O\u001d\u001dFG\\U\u0017";
      L[114] = "zr@j{\u001f'tHgnt-|@nh#~-\u0015:\u0004M,pMuo\u0010*x@`";
      L[115] = " 1*n!\u001a#$3zYM\u001cr hfGe:,i2A\u001cu{ifCw,ysd$";
      L[116] = "R*B\u001b>=\u000b(X\u0019Y3\u0001l\\C5\u0001U(\u0006\u001fYh\u0012{\u0001\u001462\u0001kS$g(\u0007-\fK=;\u0017\u007f<\u001a'=Q S@4-\u0003\u0010\u0002\u001e'i\u000b{[\u001c=kl";
      L[117] = "\u0001~8BC\\\u0007|=[#\rn5d]\u001c\u0004\u0017}h\\H\u0002neeNR\u001e\u0010ej\\\\g";
      L[118] = "\u001bQI\u000bh|BSS\t\u000frH\u0017WSc@\u001cS\r\t\u000f)\u001f\u0015\bSdp\u001d\u000f\n41iNV\u0007[kz^\u00047";
      L[119] = "1v\u001a!A'2c\u000359u\r5\u0010'\u0006zt}\u001c&R|\rj\u0011;\u0004zwfJbI\u0019";
      L[120] = "f4 Y\u00117e!9MibZw*_Vj#?&^\u0002lZ(+CTj $p\u001a\u0019\t";
      L[121] = "X+x\u000f,\\\u0001)b\rKR\u000bmfW'`_)<\bK\t\\o9W P^u;0u\r\u0018.a[,\u000f\u0002,\u0006";
      L[122] = "A% -\u007fCB099\u0007\u0016}f*+8\u001e\u0004.&*l\u0018}`p=mM\u001e=0he}";
      L[123] = "\u001dwe 3<V*:-Hgor=-wn\u0016:1,#ho)?h13\u001f60i0\r";
      L[124] = "/8g~\u0005k!\"gAPW6,+#\u000bh$),A";
      L[125] = "t\u0010\u001f0g%w\u0005\u0006$\u001frHS\u00156 x1\u001b\u00197t~HQ\u001d/mi%\r\u001ft\u007f\u001b";
      L[126] = "G\b\u001f%\u0001KD\u001d\u00061y\u0011{K\u0015#F\u0016\u0002\u0003\u0019\"\u0012\u0010{\u0010\u0017f\u0000K\u000b\u000f\u0018g\u0001u";
      L[127] = "\u000b\t\u0007\u001e\u0019=M\u0013\u0015\tv;]\u0015\r\u0000\u001a\t\u000fXUVv.L\u0003\u0007\u001bM0\n\u0004\u0011g";
      L[128] = "*El\bS))Pu\u001c+}\u0016\u0006f\u000e\u0014toNj\u000f@r\u0016\u0006mOEfs\u00066\u0015\u001a'\u0016";
      L[129] = "\u007fAX>p\u000e+\u0000O1\u0000\u0018{<\u001c9qB$E\u0019&g\u000f\u0015V^:\u007f\u000fd\u0002\u001f-p\u007f";
      L[130] = "\u000e{\u0011BF\u001cU\"\u0016Vx\u00177'MMG\u001dNoAL\u0013\u001b7|O\b\u0001@Gc@\t\u0000~";
      L[131] = "!\u000fy\u000b\u001dCzV~\u001f#Y\u0018S%\u0004\u001cBa\u001b)\u0005HD\u0018Q-\u001dQSu\r/FC!";
      L[132] = "0\u0003)4\u000fN>\u0019)\u000bYrl\u001f'4S\u000b$\u0013&`UrlD5kI\u001dn\u0014bl]r";
      L[133] = "\u0017(i_,\r\u00192i`x1\u000e<%\u0002\"\u000e\u001c9\"`";
      L[134] = "hIBFi{lAN\u000f\u0017lb\u001eLY~`[\u0010LIz\u0006>\u0010NFekb\u0012\u0015T\u0017";
      L[135] = "bx\u00014l\u0016s:Fh\u000bBc;\u001b?gp5yGe4'g'\u0017)rYg(\u0005'\u000bEm}\u0002f{Zb|\u0003X";
      L[136] = "\u0002\u0015^\u0005Mu\u0001\u0000G\u00115!>VT\u0003\n(G\u001eX\u0002^.>P\u000e\u0015_{]\rN@WK";
      L[137] = "9#\u0007\u0006O\u001f:6\u001e\u00127G\u0005`\r\u0000\bB|(\u0001\u0001\\D\u0005;\u000fEN\u001fu$\u0000DO!";
      L[138] = "\u0013{T4Y[\u001ezV f\u000e~9S?[V\u0007<L)\u0016g";
      L[139] = "\u0000b~'izY`d%\u000e\u007f_5dtY(\u0005e8\u00180oUe0wj|E7";
      L[140] = "Zs\u001b]:iDpUX\u0001{ p\bD>uY8\u0004Ejs r\u0000]sdM.\u0002\u0006a\u0016";
      L[141] = "mT\u007f]S\fsW1Xh\u001d\u0017WlDW\u0010n\u001f`E\u0003\u0016\u0017Ud]\u001a\u0001z\tf\u0006\bs";
      L[142] = "l8\u0013\u007fei3;\u0010<a\u0000>U\u0017\"y?6,_.xk0U\u0015*`r'8I(;`U";
      L[143] = "en\u001aL\u007fy{mTIDk\u001fm\tU{ef%\u0005T/c\u001f6\u000b\u0010=8o)\u0004\u0011<\u0006";
      L[144] = "2lh\u0018F\u001eg\u007ftT6\u0011=miIaFc:1%Z@&lj\u0014K\u0002a0";
      L[145] = "\u0004+\u0019&\u0011zE#\u0002/+.y\u007f\u001a:\u0014$\u00007\u0016;@\"y$\u0018\u007fRy\t;\u0017~SG";
      L[146] = "o\u001e\u0012nAQ~\\U2&\u0005n]\beJ7:\u0011W3\u0016`=\u001b\u0016=A\u000bd\u0019\f?&";
      L[147] = "\tFr\u001dX&\u000bU{\u00193zu^9\u0005U&\n@:KP";
      L[148] = "\u0010x1uy:\u001c#h8\u001a)v!37%#\u000fi?6q%vq2$k9\bq=6e@";
      L[149] = "G\u0018\u007fXG~PC:Y~lWI%X)2\b\u001f}4\u000e~\\N=\u000f\u00108[X";
      L[150] = "\u0001qJ\u0006[\u0016[sG\u0002+\u001a\fXZ\u0015Q\u000b\u0006o7DU\rV$X\u001eF\u001d\u0004\u0014\t\u0004@[[{S\u0017P\tk";
      L[151] = "\u0016\u0018Wm-(\u0007Z\u00101J|\u0017[Mf&NA\u0019\u0011<t\u0019\u0013GAp3g\u0013HS~J{\u0019\u001dT?:d\u0016\u001cU\u0001";
      L[152] = "b6\u0010\ra^a#\t\u0019\u0019\u000b^u\u001a\u000b&\u0003'=\u0016\nr\u0005^u\u0011Jw\u0011;uJ\u0010(P^";
      L[153] = "#Fl\f\u0000c=E\"\t;vYE\u007f\u0015\u0004\u007f \rs\u0014PyY\u001e}PB\")\u0001rQC\u001c";
      L[154] = "~\u0013qV};?\u001bj_Go\u0003GrJxez\u000f~K,c\u0003EzS5tn\u0019x\b'\u0006";
      L[155] = "\u000eYD\u0005D4\u0002\u0002\u001dH'$h\u0000FG\u0018-\u0011HJFL+hPGTV7\u0016PHFXN";
      L[156] = "\u0013J<%+vIH1![o\u0005F'c[8\u0007D|i4b\u0014T.Yex\u0012\u0012q6?k\u0002@Ag%mD\u001f.=6}\u0016/";
      L[157] = "S)\u00182otM*V7T`)*\u000b+khPb\u0007*?n)(\u00032&yDt\u0001i4\u000b";
      L[158] = "HQy]o\u001f\u0015\u0011,U_\u0015\u001b\u0006\u0010\b'\rJ[i\r8\u001b\u0007j+^9\u000e\u0005\u0007w\\b\u001cw";
      L[159] = "\u001dhyM\"Q@(,E\u0012IC!}'n[\u001f1!\u0018|^\u0018S";
      L[160] = "v\u0016?W.(h\u0015qR\u0015;\f\u0015,N*4u] O~2\f\u0017$Wg%aK&\fuW";
      L[161] = "g\u0000A\">4h\bN>T<\u0004\nX9&'iVZb4U";
      L[162] = "5\u0000!)5\\6\u00158=M\u000b\tC+/r\u0001p\u000b'.&\u0007\tC n#\u0013lC{4|R\t";
      L[163] = "FID-ST\u001fK^/4Z\u0015\u000fZuXhAK\u0003#4\u0001B\r\u0005u_X@\u0017\u0007\u0012\n\u0005\u0006L]yS\u0007\u001cN:";
      L[164] = "\u001c\u0003`A)0\u001f\u0016yUQc @jGnmY\bfF:k \u001fk[lmZ\u00130\u0002!\u000e";
      L[165] = "y?f4\u00035z*\u007f {bE|l2Dh<4`3\u0010nE9dp\u0019:z+aw{";
      L[166] = "@j1K\u001fGIamOuSKc=K+TKy97\u001c]Cu-I\u001cRQ{T";
      L[167] = "<\bb)J\u0019e\nx+-\u0017oN|qA%;\n&/-L|Y!&B\u0016oIs\u0016\u0013H|\r{}JJf\u000f\u001c";
      L[168] = "L{sXMF\u0015yiZ*H\u001f=m\u0000FzKy6^*\u0013\f*0WEI\u001f:bg\u0014S\u0019|=\bN@\t.\rYTFOqb\u0003GV\u001dA3]T\u0012\u0015*j_N\u0010r";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = L[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(M[var4]);
            L[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = L[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = M[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            L[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  L[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(784123297847169L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = L[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = M[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  L[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(784123297847169L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        L[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(784123297847169L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 88;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 216;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 104;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 250;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 252;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 201;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 88;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 216;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 104;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ex_C0264",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ex" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/ex_C0264", "lambda$onTick$3", "(Lnet/minecraft/item/ItemStack;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/item/ItemStack;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/ex_C0264", "lambda$onTick$4", "(Lnet/minecraft/item/ItemStack;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/item/ItemStack;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
