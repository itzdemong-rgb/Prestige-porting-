package dev.zprestige.prestige.client.modules.state;

public final class DiagonalPearlSolution {
   public int a;
   public float b;
   public float c;
   public double d;
   public int e;

   public DiagonalPearlSolution(int var1, float var2, float var3, double var4, int var6) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var6;
   }
}
