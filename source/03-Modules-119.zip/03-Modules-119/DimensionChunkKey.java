package dev.zprestige.prestige.client.modules.state;

import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;

public record DimensionChunkKey(RegistryKey<World> a_, long ba) {
}
