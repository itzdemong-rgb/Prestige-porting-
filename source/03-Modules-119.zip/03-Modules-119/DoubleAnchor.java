package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.InteractionUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.modules.state.DoubleAnchorState;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class DoubleAnchor extends Module {
   private FloatSetting a;
   private BooleanSetting d;
   private MinMaxSetting c;
   private BindSetting f;
   private BooleanSetting e;
   private MinMaxSetting g;
   private ModeSetting h;
   private BooleanSetting i;
   private IntSetting j;
   private BooleanSetting k;
   private FloatSetting l;
   private IntSetting m;
   private ElapsedTimer n;
   private ElapsedTimer o;
   private BlockPos p;
   private int q;
   private boolean r;
   private ElapsedTimer s;
   private ElapsedTimer t;
   private DoubleAnchorState u;
   private BlockHitResult v;
   private BlockPos w;
   private int x;
   private boolean y;
   private boolean z;
   private boolean A;
   private static final long B = 96259854710565L;
   private static final String[] C;
   private static final String[] D;
   private static final Map E = new HashMap(13);
   private static final Object[] F = new Object[167];
   private static final String[] G = new String[167];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;

   public DoubleAnchor() {
      super();
      long var10001 = 128152548634617L ^ 23670782122192L;
      var10001 = 128152548634617L ^ 19136636106390L;
      var10001 = 128152548634617L ^ 118725874408750L;
      var10001 = 128152548634617L ^ 91308644897819L;
      var10001 = 128152548634617L ^ 28673939225661L;
      var10001 = 128152548634617L ^ 39911515890773L;

      this.n = new ElapsedTimer(106698256430889L);
      this.o = new ElapsedTimer(106698256430889L);
      this.p = null;
      this.q = 0;
      this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.s = new ElapsedTimer(106698256430889L);
      this.t = new ElapsedTimer(106698256430889L);
      this.u = DoubleAnchorState.IDLE;
      this.v = null;
      this.w = null;
      this.x = -1;
      this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.z = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.A = dev.prestige.recovery.SourceSupport.asBoolean(0);
      ModeSetting var10000 = this.h;
      Object[] var16 = new Object[]{invokeBinding1(this), 121607650890692L};
      ModeSetting var15 = var10000;
      var15.aReturningModeSetting(var16);
      MinMaxSetting var31 = this.g;
      Object[] var18 = new Object[]{invokeBinding2(this), 112057026795887L};
      MinMaxSetting var17 = var31;
      var17.aReturningMinMaxSetting(var18);
      FloatSetting var32 = this.l;
      Object[] var20 = new Object[]{invokeBinding3(this), 34595201528535L};
      FloatSetting var19 = var32;
      var19.aReturningFloatSetting(var20);
      IntSetting var33 = this.m;
      Object[] var22 = new Object[]{invokeBinding4(this), 43459238656994L};
      IntSetting var21 = var33;
      var21.aReturningIntSetting(var22);
      BooleanSetting var34 = this.i;
      Object[] var24 = new Object[]{invokeBinding5(this), 88791076916140L};
      BooleanSetting var23 = var34;
      var23.aReturningBooleanSetting(var24);
      BooleanSetting var35 = this.k;
      Object[] var26 = new Object[]{invokeBinding6(this), 88791076916140L};
      BooleanSetting var25 = var35;
      var25.aReturningBooleanSetting(var26);
      BooleanSetting var36 = this.e;
      Object[] var28 = new Object[]{invokeBinding7(this), 88791076916140L};
      BooleanSetting var27 = var36;
      var27.aReturningBooleanSetting(var28);
      IntSetting var37 = this.j;
      Object[] var30 = new Object[]{invokeBinding8(this), 43459238656994L};
      IntSetting var29 = var37;
      var29.aReturningIntSetting(var30);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Object[] var5 = new Object[0];
      DoubleAnchor var4 = this;
      var4.jReturningVoid(var5);
      this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Object[] var5 = new Object[0];
      DoubleAnchor var4 = this;
      var4.jReturningVoid(var5);
      this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void jReturningVoid(Object[] var1) {
      this.u = DoubleAnchorState.IDLE;
      this.v = null;
      this.w = null;
      this.x = -1;
      this.z = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.A = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private boolean aReturningBoolean(Object[] var1) {
      BlockPos var4 = (BlockPos)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 96259854710565L ^ var2;
      int var5 = Event.cReturningInt();
      MinecraftClient var6 = b;
      BlockPos var8 = var4;
      ClientWorld var7 = var6.world;
      BlockState var31 = var7.getBlockState(var8);
      Block var10 = Blocks.RESPAWN_ANCHOR;
      BlockState var9 = var31;
      byte var32 = ((byte)((var9.isOf(var10)) ? 1 : 0));
      int var24 = var5;
      byte var23 = var32;
      int var19 = var23;
      byte var18 = var23;
      if (var24 != 0) {
         byte var25 = var18;
         if (var25 == 0) {
            return false;
         }

         MinecraftClient var12 = b;
         BlockPos var14 = var4;
         ClientWorld var13 = var12.world;
         BlockState var33 = var13.getBlockState(var14);
         IntProperty var16 = Properties.CHARGES;
         BlockState var15 = var33;
         Integer var17 = (Integer)var15.get((Property)var16);
         int var26 = var17;
         var19 = var26;
      }

      int var28 = var5;
      int var27 = var19;
      int var21 = var27;
      int var20 = var27;
      if (var28 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var21);
      } else {
         int var29 = var20;
         if (var29 > 0) {
            byte var34 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var34);
         } else {
            return false;
         }
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 96259854710565L ^ var3;
      MinecraftClient var5 = b;
      BlockPos var7 = var2;
      ClientWorld var6 = var5.world;
      BlockState var10 = var6.getBlockState(var7);
      Block var9 = Blocks.RESPAWN_ANCHOR;
      BlockState var8 = var10;
      return var8.isOf(var9);
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 96259854710565L ^ var2;
      long var4 = var2 ^ 82548431235625L;
      long var6 = var2 ^ 127358939319596L;
      int var8 = Event.cReturningInt();
      BooleanSetting var10 = this.k;
      Boolean var11 = (Boolean)var10.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var11)).booleanValue() ? 1 : 0));
      int var38 = var8;
      byte var37 = (byte)var10000;
      byte var30 = var37;
      byte var29 = var37;
      if (var38 != 0) {
         byte var39 = var29;
         if (var39 != 0) {
            Object[] var13 = new Object[]{var6};
            PlayerEntity var9 = EntityUtil.aReturningPlayerEntity(var13);
            PlayerEntity var40 = var9;
            if (var40 == null) {
               return false;
            }

            MinecraftClient var15 = b;
            PlayerEntity var17 = var9;
            ClientPlayerEntity var16 = var15.player;
            float var51 = var16.distanceTo((Entity)var17);
            FloatSetting var18 = this.l;
            Float var19 = (Float)var18.aReturningObject();
            float var54;
            var10000 = (var54 = var51 - var19) == 0.0F ? 0 : (var54 < 0.0F ? -1 : 1);
            int var42 = var8;
            int var41 = var10000;
            int var32 = var41;
            int var31 = var41;
            if (var42 != 0) {
               int var43 = var31;
               if (var43 >= 0) {
                  return false;
               }

               PlayerEntity var22 = var9;
               var32 = var22.hurtTime;
            }

            int var45 = var8;
            int var44 = var32;
            int var34 = var44;
            int var33 = var44;
            if (var45 != 0) {
               int var46 = var33;
               if (var46 == 0) {
                  return false;
               }

               ElapsedTimer var53 = this.t;
               IntSetting var25 = this.m;
               Integer var26 = (Integer)var25.aReturningObject();
               float var10001 = var26.intValue();
               Object[] var10004 = new Object[]{null, var4};
               var10004[0] = var10001;
               Object[] var28 = var10004;
               ElapsedTimer var27 = var53;
               var34 = (((var27.aReturningBoolean(var28)) ? 1 : 0));
            }

            int var48 = var8;
            int var47 = var34;
            int var36 = var47;
            int var35 = var47;
            if (var48 != 0) {
               int var49 = var35;
               if (var49 != 0) {
                  return false;
               }

               var36 = 1;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var36);
         }

         var30 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var30);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 109046068184356L ^ 32637644067632L;
      var10001 = 109046068184356L ^ 39502317341823L;
      int var8 = Event.bReturningInt();
      BooleanSetting var10 = this.d;
      Boolean var11 = (Boolean)var10.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var11)).booleanValue() ? 1 : 0));
      int var54 = var8;
      boolean var53 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var43 = var53;
      boolean var42 = var53;
      if (var54 == 0) {
         boolean var55 = var42;
         if (!var55) {
            return;
         }

         boolean var56 = this.r;
         var43 = var56;
      }

      int var58 = var8;
      boolean var57 = var43;
      boolean var45 = var57;
      boolean var44 = var57;
      if (var58 == 0) {
         boolean var59 = var44;
         if (!var59) {
            return;
         }

         ElapsedTimer var75 = this.o;
         MinMaxSetting var15 = this.c;
         Float var16 = (Float)var15.aReturningObject();
         float var83 = var16;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var83;
         Object[] var18 = var10004;
         ElapsedTimer var17 = var75;
         boolean var60 = var17.aReturningBoolean(var18);
         var45 = var60;
      }

      HitResult var49;
      label67: {
         int var62 = var8;
         boolean var61 = var45;
         boolean var48 = var61;
         boolean var46 = var61;
         if (var62 == 0) {
            boolean var63 = var46;
            if (!var63) {
               return;
            }

            MinecraftClient var21 = b;
            int var65 = var8;
            HitResult var64 = var21.crosshairTarget;
            var49 = var64;
            HitResult var47 = var64;
            if (var65 != 0) {
               break label67;
            }

            boolean var66 = var47 instanceof BlockHitResult;
            var48 = var66;
         }

         boolean var67 = var48;
         if (!var67) {
            this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
            return;
         }

         MinecraftClient var24 = b;
         var49 = var24.crosshairTarget;
      }

      BlockHitResult var9 = (BlockHitResult)var49;
      int var68 = var8;
      if (var68 == 0) {
         MinecraftClient var25 = b;
         ClientWorld var76 = var25.world;
         BlockHitResult var26 = var9;
         BlockPos var28 = var26.getBlockPos();
         ClientWorld var27 = var76;
         BlockState var29 = var27.getBlockState(var28);
         Block var77 = var29.getBlock();
         Block var70 = Blocks.RESPAWN_ANCHOR;
         Block var69 = var77;
         label43:
         if (var69 == var70) {
            MinecraftClient var31 = b;
            ClientWorld var78 = var31.world;
            BlockHitResult var32 = var9;
            BlockPos var34 = var32.getBlockPos();
            ClientWorld var33 = var78;
            BlockState var79 = var33.getBlockState(var34);
            IntProperty var36 = Properties.CHARGES;
            BlockState var35 = var79;
            Integer var37 = (Integer)var35.get((Property)var36);
            var10000 = var37;
            int var72 = var8;
            int var71 = var10000;
            int var50 = var71;
            if (var72 == 0) {
               int var73 = var50;
               int var51 = var73;
               int var74 = var51;
               if (var74 != 0) {
                  break label43;
               }

               this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
               Item var81 = Items.GLOWSTONE;
               Runnable var84 = invokeBinding9(var9);
               Object[] var10005 = new Object[]{null, null, null, 71193876973915L};
               var10005[2] = false;
               var10005[1] = var84;
               var10005[0] = var81;
               Object[] var41 = var10005;
               boolean var52 = InventoryUtil.jReturningBoolean(var41);
            }

            return;
         }

         this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 126952514872499L ^ 133360381404310L;
      var10001 = 126952514872499L ^ 128410771498304L;
      var10001 = 126952514872499L ^ 815620594428L;
      var10001 = 126952514872499L ^ 15342169207463L;
      var10001 = 126952514872499L ^ 94022121557171L;
      var10001 = 126952514872499L ^ 7113929121870L;
      int var16 = Event.bReturningInt();
      int var84 = var16;
      boolean var83 = this.z;
      boolean var67 = var83;
      boolean var66 = var83;
      if (var84 == 0) {
         boolean var85 = var66;
         if (var85) {
            return;
         }

         Object[] var20 = new Object[0];
         PacketSendEvent var19 = var1;
         var67 = var19.aReturningVoid(var20) instanceof PlayerInteractBlockC2SPacket;
      }

      int var87 = var16;
      boolean var86 = var67;
      boolean var69 = var86;
      boolean var68 = var86;
      if (var87 == 0) {
         boolean var88 = var68;
         if (!var88) {
            return;
         }

         ElapsedTimer var10000 = this.n;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = 200.0F;
         Object[] var23 = var10004;
         ElapsedTimer var22 = var10000;
         boolean var89 = var22.aReturningBoolean(var23);
         var69 = var89;
      }

      int var91 = var16;
      boolean var90 = var69;
      boolean var71 = var90;
      boolean var70 = var90;
      if (var91 == 0) {
         boolean var92 = var70;
         if (!var92) {
            return;
         }

         Object[] var26 = new Object[]{Items.RESPAWN_ANCHOR, 8519502184947L};
         boolean var93 = InventoryUtil.lReturningBoolean(var26);
         var71 = var93;
      }

      boolean var94 = var71;
      if (var94) {
         MinecraftClient var28 = b;
         BlockHitResult var17 = (BlockHitResult)var28.crosshairTarget;
         BlockHitResult var95 = var17;
         if (var95 != null) {
            MinecraftClient var29 = b;
            ClientWorld var116 = var29.world;
            BlockHitResult var30 = var17;
            BlockPos var32 = var30.getBlockPos();
            ClientWorld var31 = var116;
            BlockState var117 = var31.getBlockState(var32);
            Block var34 = Blocks.RESPAWN_ANCHOR;
            BlockState var33 = var117;
            byte var118 = ((byte)((var33.isOf(var34)) ? 1 : 0));
            int var97 = var16;
            byte var96 = var118;
            int var74 = var96;
            byte var72 = var96;
            if (var97 == 0) {
               byte var98 = var72;
               byte var73 = var98;
               byte var99 = var73;
               if (var99 == 0) {
                  return;
               }

               MinecraftClient var37 = b;
               var116 = var37.world;
               BlockHitResult var38 = var17;
               BlockPos var40 = var38.getBlockPos();
               ClientWorld var39 = var116;
               BlockState var120 = var39.getBlockState(var40);
               IntProperty var42 = Properties.CHARGES;
               BlockState var41 = var120;
               Integer var43 = (Integer)var41.get((Property)var42);
               int var100 = var43;
               var74 = var100;
            }

            int var102 = var16;
            int var101 = var74;
            int var76 = var101;
            int var75 = var101;
            if (var102 == 0) {
               int var103 = var75;
               if (var103 == 0) {
                  return;
               }

               Object[] var131 = new Object[]{null, null, 128703941739773L};
               var131[1] = 100.0F;
               var131[0] = 0.0F;
               Object[] var46 = var131;
               float var121 = RandomUtil.aReturningFloat(var46);
               FloatSetting var47 = this.a;
               Float var48 = (Float)var47.aReturningObject();
               float var132;
               int var104 = (var132 = var121 - var48) == 0.0F ? 0 : (var132 < 0.0F ? -1 : 1);
               var76 = var104;
            }

            int var106 = var16;
            int var105 = var76;
            int var78 = var105;
            int var77 = var105;
            if (var106 == 0) {
               int var107 = var77;
               if (var107 > 0) {
                  return;
               }

               BlockHitResult var51 = var17;
               BlockPos var122 = var51.getBlockPos();
               BlockPos var53 = this.p;
               BlockPos var52 = var122;
               var78 = (((var52.equals(var53)) ? 1 : 0));
            }

            label62: {
               label92: {
                  int var109 = var16;
                  int var108 = var78;
                  int var80 = var108;
                  int var79 = var108;
                  if (var109 == 0) {
                     int var110 = var79;
                     if (var110 == 0) {
                        BlockHitResult var58 = var17;
                        this.p = var58.getBlockPos();
                        this.q = 0;
                        break label92;
                     }

                     int var111 = this.q;
                     var80 = var111;
                  }

                  int var113 = var16;
                  int var112 = var80;
                  int var81 = var112;
                  if (var113 != 0) {
                     break label62;
                  }

                  byte var115 = 1;
                  int var114 = var81;
                  if (var114 >= var115) {
                     return;
                  }
               }

               ElapsedTimer var123 = this.n;
               Object[] var60 = new Object[]{42835128969216L};
               ElapsedTimer var59 = var123;
               var59.aReturningVoid(var60);
               Object[] var61 = new Object[]{var17, 11253043183653L};
               boolean var82 = ItemUseUtil.aReturningBoolean(var61);
            }

            this.r = dev.prestige.recovery.SourceSupport.asBoolean(1);
            MinMaxSetting var124 = this.c;
            Object[] var63 = new Object[]{127318019014223L};
            MinMaxSetting var62 = var124;
            var62.bReturningVoid(var63);
            ElapsedTimer var125 = this.o;
            Object[] var65 = new Object[]{42835128969216L};
            ElapsedTimer var64 = var125;
            var64.aReturningVoid(var65);
            this.q++;
         }
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 118638861288720L ^ 26582800726879L;
      var10001 = 118638861288720L ^ 67253093598258L;
      var10001 = 118638861288720L ^ 84746542148880L;
      var10001 = 118638861288720L ^ 16817212629399L;
      var10001 = 118638861288720L ^ 97135775872384L;
      var10001 = 118638861288720L ^ 77949180674591L;
      var10001 = 118638861288720L ^ 12350515258171L;
      var10001 = 118638861288720L ^ 4904670542652L;
      var10001 = 118638861288720L ^ 31844366802795L;
      int var22 = Event.bReturningInt();
      BindSetting var26 = this.f;
      Integer var27 = (Integer)var26.aReturningObject();
      int var10000 = var27;
      
      if (var132 != var133) {
         int var135 = var22;
         MinecraftClient var134 = b;
         MinecraftClient var103 = var134;
         MinecraftClient var102 = var134;
         if (var135 == 0) {
            MinecraftClient var29 = var102;
            ClientPlayerEntity var136 = var29.player;
            if (var136 == null) {
               return;
            }

            MinecraftClient var137 = b;
            var103 = var137;
         }

         int var139 = var22;
         MinecraftClient var138 = var103;
         MinecraftClient var105 = var138;
         MinecraftClient var104 = var138;
         if (var139 == 0) {
            MinecraftClient var32 = var104;
            ClientWorld var140 = var32.world;
            if (var140 == null) {
               return;
            }

            var105 = b;
         }

         int var142 = var22;
         MinecraftClient var141 = var105;
         MinecraftClient var107 = var141;
         MinecraftClient var106 = var141;
         if (var142 == 0) {
            MinecraftClient var35 = var106;
            Screen var143 = var35.currentScreen;
            if (var143 != null) {
               return;
            }

            MinecraftClient var144 = b;
            var107 = var144;
         }

         MinecraftClient var38 = var107;
         boolean var192 = var38.isWindowFocused();
         int var146 = var22;
         boolean var145 = var192;
         boolean var109 = var145;
         boolean var108 = var145;
         if (var146 == 0) {
            boolean var147 = var108;
            if (!var147) {
               return;
            }

            MinecraftClient var40 = b;
            ClientPlayerEntity var41 = var40.player;
            boolean var148 = var41.isUsingItem();
            var109 = var148;
         }

         int var150 = var22;
         boolean var149 = var109;
         boolean var111 = var149;
         boolean var110 = var149;
         if (var150 == 0) {
            boolean var151 = var110;
            if (var151) {
               return;
            }

            MinecraftClient var44 = b;
            ClientPlayerEntity var45 = var44.player;
            boolean var152 = var45.isSneaking();
            var111 = var152;
         }

         boolean var153 = var111;
         if (!var153) {
            int var155 = var22;
            DoubleAnchor var154 = this;
            DoubleAnchor var116 = var154;
            DoubleAnchor var112 = var154;
            if (var155 == 0) {
               DoubleAnchorState var157 = DoubleAnchorState.IDLE;
               DoubleAnchorState var156 = var112.u;
               if (var156 != var157) {
                  int var159 = var22;
                  DoubleAnchor var158 = this;
                  DoubleAnchor var115 = var158;
                  DoubleAnchor var113 = var158;
                  if (var159 == 0) {
                     DoubleAnchor var160 = var113;
                     DoubleAnchor var114 = var160;
                     ElapsedTimer var204 = var114.s;
                     Object[] var50 = new Object[]{this.g, 130913203968635L};
                     ElapsedTimer var49 = var204;
                     boolean var161 = var49.bReturningBoolean(var50);
                     if (!var161) {
                        return;
                     }

                     var115 = this;
                  }

                  Object[] var54 = new Object[]{56895100776592L};
                  DoubleAnchor var53 = var115;
                  var53.kReturningVoid(var54);
                  return;
               }

               var116 = this;
            }

            BindSetting var193 = var116.f;
            Object[] var56 = new Object[]{122678057516588L};
            BindSetting var55 = var193;
            boolean var23 = var55.cReturningBoolean(var56);
            int var163 = var22;
            boolean var162 = var23;
            boolean var118 = var162;
            boolean var117 = var162;
            if (var163 == 0) {
               boolean var164 = var117;
               if (!var164) {
                  this.y = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  return;
               }

               var118 = this.y;
            }

            boolean var122;
            int var166 = var22;
            boolean var165 = var118;
            var122 = var165;
            boolean var119 = var165;
            label127:
            if (var166 == 0) {
               boolean var167 = var119;
               if (var167) {
                  BooleanSetting var60 = this.e;
                  Boolean var61 = (Boolean)var60.aReturningObject();
                  var192 = var61;
                  int var169 = var22;
                  boolean var168 = var192;
                  var122 = var168;
                  boolean var120 = var168;
                  if (var169 != 0) {
                     break label127;
                  }

                  boolean var170 = var120;
                  boolean var121 = var170;
                  boolean var171 = var121;
                  if (!var171) {
                     return;
                  }
               }

               ElapsedTimer var195 = this.s;
               Object[] var65 = new Object[]{this.g, 130913203968635L};
               ElapsedTimer var64 = var195;
               var122 = var64.bReturningBoolean(var65);
            }

            boolean var172 = var122;
            if (var172) {
               MinecraftClient var66 = b;
               HitResult var25 = var66.crosshairTarget;
               int var174 = var22;
               HitResult var173 = var25;
               HitResult var124 = var173;
               HitResult var123 = var173;
               if (var174 == 0) {
                  boolean var175 = var123 instanceof BlockHitResult;
                  if (!var175) {
                     return;
                  }

                  HitResult var176 = var25;
                  var124 = var176;
               }

               BlockHitResult var24 = (BlockHitResult)var124;
               int var178 = var22;
               BlockHitResult var177 = var24;
               BlockHitResult var126 = var177;
               BlockHitResult var125 = var177;
               if (var178 == 0) {
                  BlockHitResult var69 = var125;
                  Type var196 = var69.getType();
                  Type var180 = Type.BLOCK;
                  Type var179 = var196;
                  if (var179 != var180) {
                     return;
                  }

                  var126 = var24;
               }

               Object[] var72 = new Object[]{var126, 106503767598635L};
               var192 = BlockUtil.dReturningBoolean(var72);
               int var182 = var22;
               boolean var181 = var192;
               boolean var128 = var181;
               boolean var127 = var181;
               if (var182 == 0) {
                  boolean var183 = var127;
                  if (!var183) {
                     return;
                  }

                  MinecraftClient var74 = b;
                  ClientWorld var198 = var74.world;
                  BlockHitResult var75 = var24;
                  BlockPos var77 = var75.getBlockPos();
                  ClientWorld var76 = var198;
                  BlockState var199 = var76.getBlockState(var77);
                  Block var79 = Blocks.RESPAWN_ANCHOR;
                  BlockState var78 = var199;
                  var128 = var78.isOf(var79);
               }

               int var185 = var22;
               boolean var184 = var128;
               boolean var130 = var184;
               boolean var129 = var184;
               if (var185 == 0) {
                  boolean var186 = var129;
                  if (var186) {
                     return;
                  }

                  MinecraftClient var81 = b;
                  ClientWorld var200 = var81.world;
                  BlockHitResult var82 = var24;
                  BlockPos var84 = var82.getBlockPos();
                  ClientWorld var83 = var200;
                  BlockState var85 = var83.getBlockState(var84);
                  var130 = var85.isReplaceable();
               }

               boolean var187 = var130;
               BlockPos var131;
               if (var187) {
                  BlockHitResult var86 = var24;
                  BlockPos var188 = var86.getBlockPos();
                  var131 = var188;
               } else {
                  Object[] var88 = new Object[]{var24, 95435648532770L};
                  var131 = BlockUtil.aReturningBlockPos(var88);
               }

               BlockPos var191 = var131;
               int var189 = var22;
               if (var189 == 0) {
                  MinecraftClient var89 = b;
                  ClientPlayerEntity var90 = var89.player;
                  Box var201 = var90.getBoundingBox();
                  Box var92 = new Box(var191);
                  Box var91 = var201;
                  boolean var190 = var91.intersects(var92);
                  if (var190) {
                     return;
                  }

                  this.y = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  this.v = var24;
                  this.w = var191;
                  Object[] var95 = new Object[]{49487520630543L};
                  this.x = InventoryUtil.aReturningInt(var95);
                  this.u = DoubleAnchorState.PLACE_1;
                  ElapsedTimer var202 = this.s;
                  Object[] var97 = new Object[]{42835128969216L};
                  ElapsedTimer var96 = var202;
                  var96.aReturningVoid(var97);
                  MinMaxSetting var203 = this.g;
                  Object[] var99 = new Object[]{127318019014223L};
                  MinMaxSetting var98 = var203;
                  var98.bReturningVoid(var99);
                  Object[] var101 = new Object[]{"Macro: sequence started", 110695481025671L};
                  DoubleAnchor var100 = this;
                  var100.mReturningVoid(var101);
               }
            }
         }
      }
   }

   
   
   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 96259854710565L ^ var2;
      long var4 = var2 ^ 81217831538115L;
      long var6 = var2 ^ 685565567794L;
      long var8 = var2 ^ 97364273328720L;
      long var10 = var2 ^ 91419302685209L;
      long var12 = var2 ^ 1130703025694L;
      long var14 = var2 ^ 6800789736621L;
      long var16 = var2 ^ 81377854434716L;
      long var18 = var2 ^ 16416959464917L;
      long var20 = var2 ^ 26359749196282L;
      long var22 = var2 ^ 21782927205210L;
      long var24 = var2 ^ 73424723652533L;
      long var26 = var2 ^ 123070476529490L;
      long var28 = var2 ^ 52622106286165L;
      int var10000 = Event.cReturningInt();
      this.z = true;
      int var30 = var10000;

      label384: {
         label383: {
            label382: {
               label381: {
                  label380: {
                     label379: {
                        label378: {
                           label377: {
                              label376: {
                                 DoubleAnchor var168;
                                 label375: {
                                    label374: {
                                       DoubleAnchor var180;
                                       label373: {
                                          label372: {
                                             try {
                                                label406: {
                                                   int var183 = var30;
                                                   DoubleAnchor var182 = this;
                                                   var180 = var182;
                                                   DoubleAnchor var141 = var182;
                                                   if (var183 == 0) {
                                                      break label373;
                                                   }

                                                   label389: {
                                                      label390: {
                                                         label391: {
                                                            DoubleAnchorState var32 = var141.u;
                                                            int var184 = var32.ordinal();
                                                            switch (var184) {
                                                               case 1:
                                                                  DoubleAnchor var146;
                                                                  label394: {
                                                                     MinecraftClient var34 = b;
                                                                     ClientPlayerEntity var35 = var34.player;
                                                                     Box var254 = var35.getBoundingBox();
                                                                     Box var37 = new Box(this.w);
                                                                     Box var36 = var254;
                                                                     boolean var255 = var36.intersects(var37);
                                                                     int var186 = var30;
                                                                     boolean var185 = var255;
                                                                     boolean var145 = var185;
                                                                     boolean var142 = var185;
                                                                     if (var186 != 0) {
                                                                        boolean var187 = var142;
                                                                        boolean var143 = var187;
                                                                        boolean var188 = var143;
                                                                        if (var188) {
                                                                           short var283 = 9373;
                                                                           long var299 = 8649095464658373459L ^ var2;
                                                                           Object[] var41 = new Object[]{"player blocking placement", var12};
                                                                           DoubleAnchor var40 = this;
                                                                           var40.lReturningVoid(var41);
                                                                           break label384;
                                                                        }

                                                                        int var190 = var30;
                                                                        DoubleAnchor var189 = this;
                                                                        var146 = var189;
                                                                        DoubleAnchor var144 = var189;
                                                                        if (var190 == 0) {
                                                                           break label394;
                                                                        }

                                                                        Object[] var43 = new Object[]{this.v, var28};
                                                                        DoubleAnchor var42 = var144;
                                                                        boolean var191 = var42.fReturningBoolean(var43);
                                                                        var145 = var191;
                                                                     }

                                                                     boolean var192 = var145;
                                                                     if (!var192) {
                                                                        short var266 = 4498;
                                                                        long var284 = 1302817650011258437L ^ var2;
                                                                        Object[] var46 = new Object[]{"no respawn anchor", var12};
                                                                        DoubleAnchor var45 = this;
                                                                        var45.lReturningVoid(var46);
                                                                        break label383;
                                                                     }

                                                                     byte var10001 = 119;
                                                                     long var10002 = 2641614087519186864L ^ var2;
                                                                     Object[] var48 = new Object[]{"Macro: placed anchor", var6};
                                                                     DoubleAnchor var47 = this;
                                                                     var47.mReturningVoid(var48);
                                                                     var146 = this;
                                                                  }

                                                                  var146.u = DoubleAnchorState.GLOW_1;
                                                                  int var193 = var30;
                                                                  if (var193 != 0) {
                                                                     break label406;
                                                                  }
                                                               case 2:
                                                                  DoubleAnchor var151;
                                                                  label392: {
                                                                     Object[] var50 = new Object[]{this.w, var22};
                                                                     DoubleAnchor var49 = this;
                                                                     boolean var256 = var49.dReturningBoolean(var50);
                                                                     int var195 = var30;
                                                                     boolean var194 = var256;
                                                                     boolean var150 = var194;
                                                                     boolean var147 = var194;
                                                                     if (var195 != 0) {
                                                                        boolean var196 = var147;
                                                                        boolean var148 = var196;
                                                                        boolean var197 = var148;
                                                                        if (!var197) {
                                                                           short var282 = 8747;
                                                                           long var298 = 7542487811142913506L ^ var2;
                                                                           Object[] var54 = new Object[]{"anchor missing", var12};
                                                                           DoubleAnchor var53 = this;
                                                                           var53.lReturningVoid(var54);
                                                                           break label382;
                                                                        }

                                                                        int var199 = var30;
                                                                        DoubleAnchor var198 = this;
                                                                        var151 = var198;
                                                                        DoubleAnchor var149 = var198;
                                                                        if (var199 == 0) {
                                                                           break label392;
                                                                        }

                                                                        Object[] var56 = new Object[]{this.w, var10};
                                                                        DoubleAnchor var55 = this;
                                                                        Object[] var58 = new Object[]{var55.aReturningBlockHitResult(var56), var26};
                                                                        DoubleAnchor var57 = var149;
                                                                        boolean var200 = var57.gReturningBoolean(var58);
                                                                        var150 = var200;
                                                                     }

                                                                     boolean var201 = var150;
                                                                     if (!var201) {
                                                                        short var268 = 28301;
                                                                        long var286 = 4549258568016412993L ^ var2;
                                                                        Object[] var61 = new Object[]{"no glowstone", var12};
                                                                        DoubleAnchor var60 = this;
                                                                        var60.lReturningVoid(var61);
                                                                        break label381;
                                                                     }

                                                                     short var267 = 26055;
                                                                     long var285 = 1037412644801071623L ^ var2;
                                                                     Object[] var63 = new Object[]{"Macro: charged anchor", var6};
                                                                     DoubleAnchor var62 = this;
                                                                     var62.mReturningVoid(var63);
                                                                     var151 = this;
                                                                  }

                                                                  var151.u = DoubleAnchorState.EXPLODE_DOUBLE_1;
                                                                  int var202 = var30;
                                                                  if (var202 != 0) {
                                                                     break label406;
                                                                  }
                                                               case 3:
                                                                  break;
                                                               case 4:
                                                                  break label391;
                                                               case 5:
                                                                  break label390;
                                                               case 6:
                                                                  break label389;
                                                               default:
                                                                  break label406;
                                                            }

                                                            DoubleAnchor var156;
                                                            label396: {
                                                               Object[] var65 = new Object[]{this.w, var18};
                                                               DoubleAnchor var64 = this;
                                                               boolean var257 = var64.aReturningBoolean(var65);
                                                               int var204 = var30;
                                                               boolean var203 = var257;
                                                               boolean var155 = var203;
                                                               boolean var152 = var203;
                                                               if (var204 != 0) {
                                                                  boolean var205 = var152;
                                                                  boolean var153 = var205;
                                                                  boolean var206 = var153;
                                                                  if (!var206) {
                                                                     short var281 = 8114;
                                                                     long var297 = 100785214718750820L ^ var2;
                                                                     Object[] var69 = new Object[]{"anchor not charged", var12};
                                                                     DoubleAnchor var68 = this;
                                                                     var68.lReturningVoid(var69);
                                                                     break label380;
                                                                  }

                                                                  int var208 = var30;
                                                                  DoubleAnchor var207 = this;
                                                                  var156 = var207;
                                                                  DoubleAnchor var154 = var207;
                                                                  if (var208 == 0) {
                                                                     break label396;
                                                                  }

                                                                  Object[] var71 = new Object[]{this.w, var10};
                                                                  DoubleAnchor var70 = this;
                                                                  Object[] var73 = new Object[]{var70.aReturningBlockHitResult(var71), var4};
                                                                  DoubleAnchor var72 = var154;
                                                                  boolean var209 = var72.iReturningVoid(var73);
                                                                  var155 = var209;
                                                               }

                                                               boolean var210 = var155;
                                                               if (!var210) {
                                                                  short var270 = 27988;
                                                                  long var288 = 4808518269654385302L ^ var2;
                                                                  Object[] var76 = new Object[]{"explode failed", var12};
                                                                  DoubleAnchor var75 = this;
                                                                  var75.lReturningVoid(var76);
                                                                  break label379;
                                                               }

                                                               short var269 = 12772;
                                                               long var287 = 7340311483516984880L ^ var2;
                                                               Object[] var78 = new Object[]{"Macro: exploded + double-placed", var6};
                                                               DoubleAnchor var77 = this;
                                                               var77.mReturningVoid(var78);
                                                               var156 = this;
                                                            }

                                                            var156.u = DoubleAnchorState.GLOW_2;
                                                            int var211 = var30;
                                                            if (var211 != 0) {
                                                               break label406;
                                                            }
                                                         }

                                                         DoubleAnchor var161;
                                                         label398: {
                                                            Object[] var80 = new Object[]{this.w, var22};
                                                            DoubleAnchor var79 = this;
                                                            boolean var258 = var79.dReturningBoolean(var80);
                                                            int var213 = var30;
                                                            boolean var212 = var258;
                                                            boolean var160 = var212;
                                                            boolean var157 = var212;
                                                            if (var213 != 0) {
                                                               boolean var214 = var157;
                                                               boolean var158 = var214;
                                                               boolean var215 = var158;
                                                               if (!var215) {
                                                                  short var280 = 4803;
                                                                  long var296 = 881779128376081676L ^ var2;
                                                                  Object[] var84 = new Object[]{"double failed", var12};
                                                                  DoubleAnchor var83 = this;
                                                                  var83.lReturningVoid(var84);
                                                                  break label378;
                                                               }

                                                               int var217 = var30;
                                                               DoubleAnchor var216 = this;
                                                               var161 = var216;
                                                               DoubleAnchor var159 = var216;
                                                               if (var217 == 0) {
                                                                  break label398;
                                                               }

                                                               Object[] var86 = new Object[]{this.w, var10};
                                                               DoubleAnchor var85 = this;
                                                               Object[] var88 = new Object[]{var85.aReturningBlockHitResult(var86), var26};
                                                               DoubleAnchor var87 = var159;
                                                               boolean var218 = var87.gReturningBoolean(var88);
                                                               var160 = var218;
                                                            }

                                                            boolean var219 = var160;
                                                            if (!var219) {
                                                               short var272 = 16499;
                                                               long var290 = 1026273584143560610L ^ var2;
                                                               Object[] var91 = new Object[]{"no glowstone (2)", var12};
                                                               DoubleAnchor var90 = this;
                                                               var90.lReturningVoid(var91);
                                                               break label377;
                                                            }

                                                            short var271 = 30317;
                                                            long var289 = 6274059051381578153L ^ var2;
                                                            Object[] var93 = new Object[]{"Macro: charged again", var6};
                                                            DoubleAnchor var92 = this;
                                                            var92.mReturningVoid(var93);
                                                            this.u = DoubleAnchorState.EXPLODE_2;
                                                            ElapsedTimer var259 = this.t;
                                                            Object[] var95 = new Object[]{var24};
                                                            ElapsedTimer var94 = var259;
                                                            var94.aReturningVoid(var95);
                                                            var161 = this;
                                                         }

                                                         var161.A = false;
                                                         int var220 = var30;
                                                         if (var220 != 0) {
                                                            break label406;
                                                         }
                                                      }

                                                      Object[] var97 = new Object[]{this.w, var18};
                                                      DoubleAnchor var96 = this;
                                                      boolean var260 = var96.aReturningBoolean(var97);
                                                      int var222 = var30;
                                                      boolean var221 = var260;
                                                      boolean var164 = var221;
                                                      boolean var162 = var221;
                                                      if (var222 != 0) {
                                                         boolean var223 = var162;
                                                         boolean var163 = var223;
                                                         boolean var224 = var163;
                                                         if (!var224) {
                                                            short var279 = 21661;
                                                            long var295 = 91469675523341141L ^ var2;
                                                            Object[] var101 = new Object[]{"second anchor not charged", var12};
                                                            DoubleAnchor var100 = this;
                                                            var100.lReturningVoid(var101);
                                                            break label376;
                                                         }

                                                         Object[] var103 = new Object[]{var14};
                                                         DoubleAnchor var102 = this;
                                                         var164 = var102.eReturningBoolean(var103);
                                                      }

                                                      DoubleAnchor var171;
                                                      label400: {
                                                         int var226 = var30;
                                                         boolean var225 = var164;
                                                         boolean var170 = var225;
                                                         boolean var165 = var225;
                                                         if (var226 != 0) {
                                                            boolean var227 = var165;
                                                            if (var227) {
                                                               int var229 = var30;
                                                               DoubleAnchor var228 = this;
                                                               var168 = var228;
                                                               DoubleAnchor var166 = var228;
                                                               if (var229 == 0) {
                                                                  break label375;
                                                               }

                                                               DoubleAnchor var230 = var166;
                                                               DoubleAnchor var167 = var230;
                                                               boolean var231 = var167.A;
                                                               if (!var231) {
                                                                  short var278 = 17675;
                                                                  long var294 = 224213177064188638L ^ var2;
                                                                  Object[] var108 = new Object[]{"Macro: waiting for damage tick", var6};
                                                                  DoubleAnchor var107 = this;
                                                                  var107.mReturningVoid(var108);
                                                                  this.A = true;
                                                               }
                                                               break label372;
                                                            }

                                                            this.A = false;
                                                            int var233 = var30;
                                                            DoubleAnchor var232 = this;
                                                            var171 = var232;
                                                            DoubleAnchor var169 = var232;
                                                            if (var233 == 0) {
                                                               break label400;
                                                            }

                                                            Object[] var111 = new Object[]{this.w, var10};
                                                            DoubleAnchor var110 = this;
                                                            Object[] var113 = new Object[]{var110.aReturningBlockHitResult(var111), var16};
                                                            DoubleAnchor var112 = var169;
                                                            boolean var234 = var112.hReturningVoid(var113);
                                                            var170 = var234;
                                                         }

                                                         boolean var235 = var170;
                                                         if (!var235) {
                                                            short var274 = 29013;
                                                            long var292 = 1663243750791405203L ^ var2;
                                                            Object[] var116 = new Object[]{"explode failed (2)", var12};
                                                            DoubleAnchor var115 = this;
                                                            var115.lReturningVoid(var116);
                                                            break label374;
                                                         }

                                                         short var273 = 22049;
                                                         long var291 = 1227483576148752868L ^ var2;
                                                         Object[] var118 = new Object[]{"Macro: exploded again", var6};
                                                         DoubleAnchor var117 = this;
                                                         var117.mReturningVoid(var118);
                                                         var171 = this;
                                                      }

                                                      var171.u = DoubleAnchorState.RESTORE;
                                                      int var236 = var30;
                                                      if (var236 != 0) {
                                                         break label406;
                                                      }
                                                   }

                                                   DoubleAnchor var179;
                                                   int var238 = var30;
                                                   DoubleAnchor var237 = this;
                                                   var179 = var237;
                                                   DoubleAnchor var172 = var237;
                                                   label302:
                                                   if (var238 != 0) {
                                                      DoubleAnchor var239 = var172;
                                                      DoubleAnchor var173 = var239;
                                                      BooleanSetting var120 = var173.i;
                                                      Boolean var121 = (Boolean)var120.aReturningObject();
                                                      boolean var240 = var121;
                                                      label308:
                                                      if (var240) {
                                                         short var261 = 19292;
                                                         long var275 = 472684677374600349L ^ var2;
                                                         ModeSetting var123 = this.h;
                                                         Object var125 = var123.aReturningObject();
                                                         String var124 = "Swap";
                                                         byte var262 = ((byte)((var124.equals(var125)) ? 1 : 0));
                                                         int var242 = var30;
                                                         byte var241 = var262;
                                                         int var178 = var241;
                                                         byte var174 = var241;
                                                         if (var242 != 0) {
                                                            byte var243 = var174;
                                                            byte var175 = var243;
                                                            byte var244 = var175;
                                                            if (var244 == 0) {
                                                               break label308;
                                                            }

                                                            int var246 = var30;
                                                            DoubleAnchor var245 = this;
                                                            var179 = var245;
                                                            DoubleAnchor var176 = var245;
                                                            if (var246 == 0) {
                                                               break label302;
                                                            }

                                                            DoubleAnchor var247 = var176;
                                                            DoubleAnchor var177 = var247;
                                                            int var248 = var177.x;
                                                            var178 = var248;
                                                         }

                                                         
                                                         if (var249 != var250) {
                                                            RotationManager var263 = Prestige.o;
                                                            int var276 = this.x;
                                                            Object[] var10004 = new Object[]{null, var8};
                                                            var10004[0] = var276;
                                                            Object[] var131 = var10004;
                                                            RotationManager var130 = var263;
                                                            var130.hReturningVoid(var131);
                                                         }
                                                      }

                                                      short var277 = 9111;
                                                      long var293 = 922497806566296645L ^ var2;
                                                      Object[] var134 = new Object[]{"Macro: done", var6};
                                                      DoubleAnchor var133 = this;
                                                      var133.mReturningVoid(var134);
                                                      var179 = this;
                                                   }

                                                   Object[] var136 = new Object[0];
                                                   DoubleAnchor var135 = var179;
                                                   var135.jReturningVoid(var136);
                                             } catch (Throwable var252) {
                                                this.z = false;
                                                throw var252;
                                             }

                                             var180 = this;
                                             break label373;
                                          }

                                          var168 = this;
                                          break label375;
                                       }

                                       var180.z = false;
                                       ElapsedTimer var264 = this.s;
                                       Object[] var138 = new Object[]{var24};
                                       ElapsedTimer var137 = var264;
                                       var137.aReturningVoid(var138);
                                       MinMaxSetting var265 = this.g;
                                       Object[] var140 = new Object[]{var20};
                                       MinMaxSetting var139 = var265;
                                       var139.bReturningVoid(var140);
                                       return;
                                    }

                                    this.z = false;
                                    return;
                                 }

                                 var168.z = false;
                                 return;
                              }

                              this.z = false;
                              return;
                           }

                           this.z = false;
                           return;
                        }

                        this.z = false;
                        return;
                     }

                     this.z = false;
                     return;
                  }

                  this.z = false;
                  return;
               }

               this.z = false;
               return;
            }

            this.z = false;
            return;
         }

         this.z = false;
         return;
      }

      this.z = false;
   }

   private void lReturningVoid(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 96259854710565L ^ var2;
      long var5 = var2 ^ 71958522263745L;
      long var7 = var2 ^ 15419464758123L;
      long var9 = var2 ^ 94647719338505L;
      long var11 = var2 ^ 22320874188430L;
      int var13 = Event.cReturningInt();
      int var34 = var13;
      if (var34 != 0) {
         DoubleAnchor var33;
         label20: {
            short var10000 = 19292;
            long var10001 = 472603902516798886L ^ var2;
            ModeSetting var14 = this.h;
            Object var16 = var14.aReturningObject();
            String var15 = "Swap";
            boolean var35 = var15.equals(var16);
            if (var35) {
               int var37 = var13;
               DoubleAnchor var36 = this;
               var33 = var36;
               DoubleAnchor var31 = var36;
               if (var37 == 0) {
                  break label20;
               }

               DoubleAnchor var38 = var31;
               DoubleAnchor var32 = var38;
               
               if (var39 != var40) {
                  RotationManager var42 = Prestige.o;
                  int var45 = this.x;
                  Object[] var10004 = new Object[]{null, var7};
                  var10004[0] = var45;
                  Object[] var21 = var10004;
                  RotationManager var20 = var42;
                  var20.hReturningVoid(var21);
               }
            }

            short var10002 = 6696;
            long var10003 = 3631229257382130904L ^ var2;
            Object[] var24 = new Object[]{"Macro aborted: " + var4, var9};
            DoubleAnchor var23 = this;
            var23.mReturningVoid(var24);
            Object[] var26 = new Object[0];
            DoubleAnchor var25 = this;
            var25.jReturningVoid(var26);
            ElapsedTimer var43 = this.s;
            Object[] var28 = new Object[]{var11};
            ElapsedTimer var27 = var43;
            var27.aReturningVoid(var28);
            var33 = this;
         }

         MinMaxSetting var44 = var33.g;
         Object[] var30 = new Object[]{var5};
         MinMaxSetting var29 = var44;
         var29.bReturningVoid(var30);
      }
   }

   private void mReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      long var3 = (Long)var1[1];
      var3 = 96259854710565L ^ var3;
      long var5 = var3 ^ 101966946004225L;
      Object[] var7 = new Object[]{this, var2, NotificationType.INFO, var5};
      ModuleNotificationsWidget.s(var7);
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      BlockPos var2 = (BlockPos)var1[0];
      long var3 = (Long)var1[1];
      var3 = 96259854710565L ^ var3;
      long var5 = var3 ^ 27076543832908L;
      int var10000 = Event.bReturningInt();
      Object[] var9 = new Object[]{var2, var5};
      Vec3d var8 = InteractionUtil.bReturningVec3d(var9);
      int var7 = var10000;
      int var17 = var7;
      Vec3d var16 = var8;
      Vec3d var15 = var16;
      Vec3d var14 = var16;
      if (var17 == 0) {
         Vec3d var18 = var14;
         if (var18 != null) {
            return new BlockHitResult(var8, Direction.UP, var2, false);
         }

         BlockPos var11 = var2;
         double var10002 = var11.getX() + 0.5;
         BlockPos var12 = var2;
         double var10003 = var12.getY() + 1.0;
         BlockPos var13 = var2;
         Vec3d var19 = new Vec3d(var10002, var10003, var13.getZ() + 0.5);
         var15 = var19;
      }

      var8 = var15;
      return new BlockHitResult(var8, Direction.UP, var2, false);
   }

   private boolean fReturningBoolean(Object[] var1) {
      BlockHitResult var2;
      long var5;
      label33: {
         var2 = (BlockHitResult)var1[0];
         long var3 = (Long)var1[1];
         var3 = 96259854710565L ^ var3;
         var5 = var3 ^ 24596876290272L;
         long var7 = var3 ^ 30638087366966L;
         long var9 = var3 ^ 43424965057180L;
         int var11 = Event.cReturningInt();
         short var10000 = 14091;
         long var10001 = 8459455919010150321L ^ var3;
         ModeSetting var12 = this.h;
         Object var14 = var12.aReturningObject();
         String var13 = "None";
         boolean var41 = var13.equals(var14);
         int var31 = var11;
         boolean var30 = var41;
         boolean var27 = var30;
         boolean var24 = var30;
         if (var31 != 0) {
            boolean var32 = var24;
            if (var32) {
               Object[] var16 = new Object[]{Items.RESPAWN_ANCHOR, var7};
               var41 = InventoryUtil.lReturningBoolean(var16);
               int var34 = var11;
               boolean var33 = var41;
               boolean var43 = var33;
               boolean var25 = var33;
               if (var34 == 0) {
                  return var43;
               }

               boolean var35 = var25;
               boolean var26 = var35;
               boolean var36 = var26;
               if (!var36) {
                  return false;
               }
               break label33;
            }

            Object[] var20 = new Object[]{Blocks.RESPAWN_ANCHOR, var9};
            var27 = InventoryUtil.iReturningVoid(var20);
         }

         int var38 = var11;
         boolean var37 = var27;
         boolean var29 = var37;
         boolean var28 = var37;
         if (var38 == 0) {
            return var29;
         }

         boolean var39 = var28;
         if (!var39) {
            return false;
         }
      }

      Object[] var23 = new Object[]{var2, var5};
      ItemUseUtil.aReturningBoolean(var23);
      return true;
   }

   private boolean gReturningBoolean(Object[] var1) {
      BlockHitResult var2;
      long var5;
      label33: {
         var2 = (BlockHitResult)var1[0];
         long var3 = (Long)var1[1];
         var3 = 96259854710565L ^ var3;
         var5 = var3 ^ 95023834603495L;
         long var7 = var3 ^ 101085841366577L;
         long var9 = var3 ^ 113576994352539L;
         int var11 = Event.bReturningInt();
         short var10000 = 14091;
         long var10001 = 8459526345512583350L ^ var3;
         ModeSetting var12 = this.h;
         Object var14 = var12.aReturningObject();
         String var13 = "None";
         boolean var41 = var13.equals(var14);
         int var31 = var11;
         boolean var30 = var41;
         boolean var27 = var30;
         boolean var24 = var30;
         if (var31 == 0) {
            boolean var32 = var24;
            if (var32) {
               Object[] var16 = new Object[]{Items.GLOWSTONE, var7};
               var41 = InventoryUtil.lReturningBoolean(var16);
               int var34 = var11;
               boolean var33 = var41;
               boolean var43 = var33;
               boolean var25 = var33;
               if (var34 != 0) {
                  return var43;
               }

               boolean var35 = var25;
               boolean var26 = var35;
               boolean var36 = var26;
               if (!var36) {
                  return false;
               }
               break label33;
            }

            Object[] var20 = new Object[]{Blocks.GLOWSTONE, var9};
            var27 = InventoryUtil.iReturningVoid(var20);
         }

         int var38 = var11;
         boolean var37 = var27;
         boolean var29 = var37;
         boolean var28 = var37;
         if (var38 != 0) {
            return var29;
         }

         boolean var39 = var28;
         if (!var39) {
            return false;
         }
      }

      Object[] var23 = new Object[]{var2, var5};
      ItemUseUtil.aReturningBoolean(var23);
      return true;
   }

   private boolean h(Object[] var1) {
      BlockHitResult var4;
      long var5;
      label24: {
         var4 = (BlockHitResult)var1[0];
         long var2 = (Long)var1[1];
         var2 = 96259854710565L ^ var2;
         var5 = var2 ^ 127000639053097L;
         long var7 = var2 ^ 138547989880063L;
         long var9 = var2 ^ 61889418860666L;
         int var11 = Event.bReturningInt();
         short var10000 = 16367;
         long var10001 = 8494535910795086469L ^ var2;
         ModeSetting var12 = this.h;
         Object var14 = var12.aReturningObject();
         String var13 = "None";
         byte var37 = ((byte)((var13.equals(var14)) ? 1 : 0));
         int var30 = var11;
         byte var29 = var37;
         int var27 = var29;
         byte var24 = var29;
         if (var30 == 0) {
            byte var31 = var24;
            if (var31 != 0) {
               Object[] var16 = new Object[]{Items.GLOWSTONE, var7};
               boolean var38 = InventoryUtil.lReturningBoolean(var16);
               int var33 = var11;
               boolean var32 = var38;
               boolean var28 = var32;
               boolean var25 = var32;
               if (var33 != 0) {
                  return var28;
               }

               boolean var34 = var25;
               boolean var26 = var34;
               boolean var35 = var26;
               if (var35) {
                  return false;
               }
               break label24;
            }

            IntSetting var20 = this.j;
            Integer var21 = (Integer)var20.aReturningObject();
            var27 = var21 - 1;
         }

         Object[] var10003 = new Object[]{null, var9};
         var10003[0] = var27;
         Object[] var22 = var10003;
         InventoryUtil.aReturningVoid(var22);
      }

      Object[] var23 = new Object[]{var4, var5};
      ItemUseUtil.aReturningBoolean(var23);
      return true;
   }

   private boolean i(Object[] var1) {
      BlockHitResult var4 = (BlockHitResult)var1[0];
      long var2 = (Long)var1[1];
      var2 = 96259854710565L ^ var2;
      long var5 = var2 ^ 123553829535094L;
      long var7 = var2 ^ 138386167577760L;
      long var9 = var2 ^ 92713371735930L;
      long var11 = var2 ^ 72015320026890L;
      int var13 = Event.cReturningInt();
      Object[] var15 = new Object[]{var4, var9};
      DoubleAnchor var14 = this;
      short var10000 = ((short)((var14.hReturningVoid(var15)) ? 1 : 0));
      int var40 = var13;
      boolean var39 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var32 = var39;
      boolean var31 = var39;
      if (var40 != 0) {
         boolean var41 = var31;
         if (!var41) {
            return false;
         }

         var10000 = 14091;
         long var10001 = 8459554878511948327L ^ var2;
         ModeSetting var18 = this.h;
         Object var20 = var18.aReturningObject();
         String var19 = "None";
         var32 = var19.equals(var20);
      }

      int var43 = var13;
      boolean var42 = var32;
      boolean var36 = var42;
      boolean var33 = var42;
      if (var43 != 0) {
         boolean var44 = var33;
         if (var44) {
            Object[] var22 = new Object[]{Items.RESPAWN_ANCHOR, var7};
            byte var56 = ((byte)((InventoryUtil.lReturningBoolean(var22)) ? 1 : 0));
            int var46 = var13;
            byte var45 = var56;
            byte var38 = var45;
            byte var34 = var45;
            if (var46 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var38);
            }

            byte var47 = var34;
            byte var35 = var47;
            byte var48 = var35;
            if (var48 == 0) {
               return true;
            }

            Object[] var25 = new Object[]{var4, var5};
            ItemUseUtil.aReturningBoolean(var25);
            int var49 = var13;
            if (var49 != 0) {
               return true;
            }
         }

         Object[] var27 = new Object[]{Blocks.RESPAWN_ANCHOR, var11};
         boolean var50 = InventoryUtil.iReturningVoid(var27);
         var36 = var50;
      }

      int var52 = var13;
      boolean var51 = var36;
      boolean var57 = var51;
      boolean var37 = var51;
      if (var52 == 0) {
         return var57;
      }

      boolean var53 = var37;
      if (var53) {
         Object[] var30 = new Object[]{var4, var5};
         ItemUseUtil.aReturningBoolean(var30);
      }

      return true;
   }

   private static void lambda$onMotionUpdate$9(BlockHitResult var0) {
      long var10001 = 17467525593465L ^ 6455135320412L;
      Object[] var5 = new Object[]{var0, 11253043183653L};
      ItemUseUtil.aReturningBoolean(var5);
   }

   private boolean lambda$new$8(Integer var1) {
      int var4 = Event.cReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var16 = var4;
      int var15 = var10000;
      int var11 = var15;
      int var10 = var15;
      if (var16 != 0) {
         
         if (var17 == var18) {
            return false;
         }

         BooleanSetting var8 = this.k;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var19;
      }

      int var21 = var4;
      int var20 = var11;
      int var13 = var20;
      int var12 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         int var22 = var12;
         if (var22 != 0) {
            byte var24 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var24);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$7(Float var1) {
      int var4 = Event.cReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var16 = var4;
      int var15 = var10000;
      int var11 = var15;
      int var10 = var15;
      if (var16 != 0) {
         
         if (var17 == var18) {
            return false;
         }

         BooleanSetting var8 = this.k;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var19 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var19;
      }

      int var21 = var4;
      int var20 = var11;
      int var13 = var20;
      int var12 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         int var22 = var12;
         if (var22 != 0) {
            byte var24 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var24);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$6(Boolean var1) {
      int var4 = Event.bReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 == 0) {
         
         if (var12 != var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$5(Integer var1) {
      int var4 = Event.cReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var17 = var4;
      int var16 = var10000;
      int var12 = var16;
      int var11 = var16;
      if (var17 != 0) {
         
         if (var18 == var19) {
            return false;
         }

         ModeSetting var8 = this.h;
         String var25 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var25;
         byte var20 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var20;
      }

      int var22 = var4;
      int var21 = var12;
      int var14 = var21;
      int var13 = var21;
      if (var22 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var23 = var13;
         if (var23 != 0) {
            byte var26 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var26);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$4(Boolean var1) {
      int var4 = Event.bReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var17 = var4;
      int var16 = var10000;
      int var12 = var16;
      int var11 = var16;
      if (var17 == 0) {
         
         if (var18 == var19) {
            return false;
         }

         ModeSetting var8 = this.h;
         String var25 = (String)var8.aReturningObject();
         String var10 = "Swap";
         String var9 = var25;
         byte var20 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var20;
      }

      int var22 = var4;
      int var21 = var12;
      int var14 = var21;
      int var13 = var21;
      if (var22 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var23 = var13;
         if (var23 != 0) {
            byte var26 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var26);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$3(String var1) {
      int var4 = Event.bReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 == 0) {
         
         if (var12 != var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$2(Float var1) {
      int var4 = Event.bReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 == 0) {
         
         if (var12 != var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$1(Boolean var1) {
      int var4 = Event.cReturningInt();
      BindSetting var5 = this.f;
      Integer var6 = (Integer)var5.aReturningObject();
      int var10000 = var6;
      int var11 = var4;
      int var10 = var10000;
      int var8 = var10;
      int var7 = var10;
      int var9;
      if (var11 != 0) {
         
         if (var12 != var13) {
            byte var14 = 1;
            var9 = var14;
         } else {
            var9 = 0;
         }
      } else {
         int var15 = var8;
         var9 = var15;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(113833025753279L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[23];
      String var6 = "Ýñá+tÃ#QÅ\u0092§üÚ\u008aì\u001bsBõ\u000bfM\u0011T©-çB\u00138¾}\u0098^o\u000f¤Ý#Ã(\u0082\u0013sÞC9ê{¬\u001fñ[X\u0004\u008dP¤w(lïï¶¥\u001fôot\u0005Çü\u008cÈ\u009f\u0001ÈU%û£(\u0001ÿ\u0010a\n°Ýônë\u001eZ@M4þ\u000b\u0092\u008d`QMzÁãVú\u0093\u001fø{çÖ3\u0081ñ<_gþ(\u0007\u009d\u0013%éâ\u008fn6ûâeÙ«]k´\u0017\u0091\u0084ËM7ýâÞ\u0018Ç\u0099^\u0095M\u0002ÛÛw(0\u0086°\u0010çØ\u0080Ê\u0015\u0090±\u000bG&\u0095|~\u000e\u0018b\u0018¢\u0010g_»g©¦3½1\u000e\u0017\u001d±xÂ\ri85\u009dþ«\u0010µ$\u0080ê-éX=Õ(åÙ\u009fpFp(/9\u001c\u008eyþX´ÂzÈã¨x5|ßdr\u009ezü5Ó\u001aQGÚÄx÷9\u009e7w~ð®1à \u0012\u0001\u0018ò¼\r\u0088¸Ç³º=î|`iù&¨)%K¶Eá\u0098A@ëÇÄü0;ã«áëÜÕÐÀ%³\u0005\u00850w\"«ü\u0097(0tU\u0089\u008aFGD3;¬Î2p ó\u0006Èõ1ù\u0087Å¤ê\u001büæ(g\f8\u001d\u008d.\u0000\u008d\u001ekÅå`\u000f½$¿\u008fßâZL?öW\u000f#\u0001`ØQ\u0082¦û\u0090Hè\u0093Îz\u0018Z¯mhí\u0000¾P®\u0094\u00ad\u0016ÂÄ\u009e!»\u0004ð¯GìKx\u0018{%ë#\u0098õ\u0007ï¡¬\u008dîáâ¨A\u0018w°òá&ÑR\u0010 ºªË;\u0098\u0093³¨uaZ¡ÌU] \u000eR\u0007Ëb¶©\u0004tòM\u001cì3t\bYqõÀ[õ¯\u0090-\u001f\u001a\u001cX\u0088Ho0]@êÇ¦frZ\u0083Û,©\u0083ÿ$ÖbàUyÛ\u0018Ä¯ë¯Ê³Ìn\u008e\u008487\u0007\u0019@\u001a\u000b¬®\u0084àâu&32(¹Æû\u0010Ús\u0017'uÁµ$¸·\u0081\u0080 \u0085°§o¹O\u001aÆç\téþ¿eÎ_ó®ÉVJò]($\u0089%\u007f\u0087aÁ\u0007ÞÛ¯ý½²ëË×\u0092v·\tÏ¬?B\u0016EO°\u0000´\u009duÂ\u0096¯Z\u008bð(8\"\u0018ÊZ]çÇ\u0010{¡\u007fÂ%ZÇª£\u0096\u0083\u0098u5\u00860÷\u00ad9ÏP\u008c©¥}«\f\u009frló]Â&Ù%\u000b\u0097u¥òÊ\u008f\u0082\bÏØ38Ìg\u008b\u001d\u0084QLôùðUòõdsùºp<\u0005Kx3ÉtCe\u0082~2\b×\u0084`\u0016\u0095¸\u001f¦.\u0090\u009e¿a×dÏa\u00069c4&ÝîÝ\u0010\u0003¹\u0001ÊÄN¸Û<Ýß£p0w©";
      int var8 = "Ýñá+tÃ#QÅ\u0092§üÚ\u008aì\u001bsBõ\u000bfM\u0011T©-çB\u00138¾}\u0098^o\u000f¤Ý#Ã(\u0082\u0013sÞC9ê{¬\u001fñ[X\u0004\u008dP¤w(lïï¶¥\u001fôot\u0005Çü\u008cÈ\u009f\u0001ÈU%û£(\u0001ÿ\u0010a\n°Ýônë\u001eZ@M4þ\u000b\u0092\u008d`QMzÁãVú\u0093\u001fø{çÖ3\u0081ñ<_gþ(\u0007\u009d\u0013%éâ\u008fn6ûâeÙ«]k´\u0017\u0091\u0084ËM7ýâÞ\u0018Ç\u0099^\u0095M\u0002ÛÛw(0\u0086°\u0010çØ\u0080Ê\u0015\u0090±\u000bG&\u0095|~\u000e\u0018b\u0018¢\u0010g_»g©¦3½1\u000e\u0017\u001d±xÂ\ri85\u009dþ«\u0010µ$\u0080ê-éX=Õ(åÙ\u009fpFp(/9\u001c\u008eyþX´ÂzÈã¨x5|ßdr\u009ezü5Ó\u001aQGÚÄx÷9\u009e7w~ð®1à \u0012\u0001\u0018ò¼\r\u0088¸Ç³º=î|`iù&¨)%K¶Eá\u0098A@ëÇÄü0;ã«áëÜÕÐÀ%³\u0005\u00850w\"«ü\u0097(0tU\u0089\u008aFGD3;¬Î2p ó\u0006Èõ1ù\u0087Å¤ê\u001büæ(g\f8\u001d\u008d.\u0000\u008d\u001ekÅå`\u000f½$¿\u008fßâZL?öW\u000f#\u0001`ØQ\u0082¦û\u0090Hè\u0093Îz\u0018Z¯mhí\u0000¾P®\u0094\u00ad\u0016ÂÄ\u009e!»\u0004ð¯GìKx\u0018{%ë#\u0098õ\u0007ï¡¬\u008dîáâ¨A\u0018w°òá&ÑR\u0010 ºªË;\u0098\u0093³¨uaZ¡ÌU] \u000eR\u0007Ëb¶©\u0004tòM\u001cì3t\bYqõÀ[õ¯\u0090-\u001f\u001a\u001cX\u0088Ho0]@êÇ¦frZ\u0083Û,©\u0083ÿ$ÖbàUyÛ\u0018Ä¯ë¯Ê³Ìn\u008e\u008487\u0007\u0019@\u001a\u000b¬®\u0084àâu&32(¹Æû\u0010Ús\u0017'uÁµ$¸·\u0081\u0080 \u0085°§o¹O\u001aÆç\téþ¿eÎ_ó®ÉVJò]($\u0089%\u007f\u0087aÁ\u0007ÞÛ¯ý½²ëË×\u0092v·\tÏ¬?B\u0016EO°\u0000´\u009duÂ\u0096¯Z\u008bð(8\"\u0018ÊZ]çÇ\u0010{¡\u007fÂ%ZÇª£\u0096\u0083\u0098u5\u00860÷\u00ad9ÏP\u008c©¥}«\f\u009frló]Â&Ù%\u000b\u0097u¥òÊ\u008f\u0082\bÏØ38Ìg\u008b\u001d\u0084QLôùðUòõdsùºp<\u0005Kx3ÉtCe\u0082~2\b×\u0084`\u0016\u0095¸\u001f¦.\u0090\u009e¿a×dÏa\u00069c4&ÝîÝ\u0010\u0003¹\u0001ÊÄN¸Û<Ýß£p0w©"
         .length();
      char var5 = '(';
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     C = var9;
                     D = new String[23];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "wBJ¢ßäø§\u0096Ó©mjÍ¢úZÙü)ûZ\u0094z(=h\u009b\n\u009dHÚ<7ñWú}kÊ\u008c\u0004Ê´\u0096Õ\u0092\u0081\u0084 \tJRì\u0016\u0096§×ùÄ\u0013éÑ\u0081'";
                  var8 = "wBJ¢ßäø§\u0096Ó©mjÍ¢úZÙü)ûZ\u0094z(=h\u009b\n\u009dHÚ<7ñWú}kÊ\u008c\u0004Ê´\u0096Õ\u0092\u0081\u0084 \tJRì\u0016\u0096§×ùÄ\u0013éÑ\u0081'"
                     .length();
                  var5 = 24;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26738;
      if (D[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])E.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               E.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ey", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = C[var5].getBytes("ISO-8859-1");
         D[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return D[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ey_C0266",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ey" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = G[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = F[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 20;
            yield var15;
         }
         case 1 -> {
            byte var16 = 35;
            yield var16;
         }
         case 2 -> {
            byte var17 = 3;
            yield var17;
         }
         case 3 -> {
            byte var18 = 12;
            yield var18;
         }
         case 4 -> {
            byte var19 = 48;
            yield var19;
         }
         case 5 -> {
            byte var20 = 60;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 36;
            yield var23;
         }
         case 9 -> {
            byte var24 = 11;
            yield var24;
         }
         case 10 -> {
            byte var25 = 49;
            yield var25;
         }
         case 11 -> {
            byte var26 = 18;
            yield var26;
         }
         case 12 -> {
            byte var27 = 51;
            yield var27;
         }
         case 13 -> {
            byte var28 = 0;
            yield var28;
         }
         case 14 -> {
            byte var29 = 33;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 26;
            yield var31;
         }
         case 17 -> {
            byte var32 = 54;
            yield var32;
         }
         case 18 -> {
            byte var33 = 8;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 42;
            yield var36;
         }
         case 22 -> {
            byte var37 = 19;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 32;
            yield var40;
         }
         case 26 -> {
            byte var41 = 62;
            yield var41;
         }
         case 27 -> {
            byte var42 = 27;
            yield var42;
         }
         case 28 -> {
            byte var43 = 25;
            yield var43;
         }
         case 29 -> {
            byte var44 = 58;
            yield var44;
         }
         case 30 -> {
            byte var45 = 2;
            yield var45;
         }
         case 31 -> {
            byte var46 = 50;
            yield var46;
         }
         case 32 -> {
            byte var47 = 61;
            yield var47;
         }
         case 33 -> {
            byte var48 = 29;
            yield var48;
         }
         case 34 -> {
            byte var49 = 4;
            yield var49;
         }
         case 35 -> {
            byte var50 = 13;
            yield var50;
         }
         case 36 -> {
            byte var51 = 21;
            yield var51;
         }
         case 37 -> {
            byte var52 = 16;
            yield var52;
         }
         case 38 -> {
            byte var53 = 45;
            yield var53;
         }
         case 39 -> {
            byte var54 = 52;
            yield var54;
         }
         case 40 -> {
            byte var55 = 7;
            yield var55;
         }
         case 41 -> {
            byte var56 = 9;
            yield var56;
         }
         case 42 -> {
            byte var57 = 34;
            yield var57;
         }
         case 43 -> {
            byte var58 = 14;
            yield var58;
         }
         case 44 -> {
            byte var59 = 37;
            yield var59;
         }
         case 45 -> {
            byte var60 = 63;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 22;
            yield var63;
         }
         case 49 -> {
            byte var64 = 59;
            yield var64;
         }
         case 50 -> {
            byte var65 = 57;
            yield var65;
         }
         case 51 -> {
            byte var66 = 53;
            yield var66;
         }
         case 52 -> {
            byte var67 = 56;
            yield var67;
         }
         case 53 -> {
            byte var68 = 38;
            yield var68;
         }
         case 54 -> {
            byte var69 = 5;
            yield var69;
         }
         case 55 -> {
            byte var70 = 43;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 28;
            yield var72;
         }
         case 58 -> {
            byte var73 = 15;
            yield var73;
         }
         case 59 -> {
            byte var74 = 46;
            yield var74;
         }
         case 60 -> {
            byte var75 = 41;
            yield var75;
         }
         case 61 -> {
            byte var76 = 31;
            yield var76;
         }
         case 62 -> {
            byte var77 = 17;
            yield var77;
         }
         default -> 6;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            G[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      F[0] = ">[6K\"\u00075T'\u0004_\u001f&S.M";
      F[1] = "KZU)2u@UDfS{K^@<";
      F[2] = boolean.class;
      G[2] = "java/lang/Boolean";
      F[3] = "y\u0017o37ro\u0017ji$ex\\io(qi\u001b~xcar";
      F[4] = "ayk5'\\\u0014Y`:6\u0013uWk12I\u0001";
      F[5] = "\f!\u0014\u0011*O\f!\u0003M&@\u0016j\u0003S&U\u0011\u001bR\rs\u0010";
      F[6] = "WvaMAwWvv\u0011MxM=v\u000fMmJL'Q\u0018&";
      F[7] = "HG4zR:^G1 A-I\f2&M9XK%1\u0006+i";
      F[8] = int.class;
      G[8] = "java/lang/Integer";
      F[9] = "\b\u0013\u00071\u0018 \b\u0013\u0010m\u0014/\u0012X\u0010s\u0014:\u0015)B'E{";
      F[10] = "rf\u0006\u0016>hrf\u0011J2gh-\u0011T2ro\\C\u000fj3";
      F[11] = "J}9UKk\\}<\u000fX|K6?\tThZq(\u001e\u001f\u007fh";
      F[12] = "oiu+s\u0003yipq`\u0014n\"swl\u0000\u007fed`'\u0016r";
      F[13] = "u/K|\u0018\u0013~ Z3{\u001ek-UXN\u001cz>ItY\u0011";
      F[14] = "4v\t\t\u0000Y\"v\fS\u0013N5=\u000fU\u001fZ$z\u0018BTJ<";
      F[15] = "F\"+=<X3\u0002 2-\u0017R\f+9)M&";
      F[16] = "C\u000e^\u001b\f.6.U\u0014\u001daW ^\u001f\u0019;#";
      F[17] = ":[I|\n*O{Bs\u001be.uIx\u001f?Z";
      F[18] = void.class;
      G[18] = "java/lang/Void";
      F[19] = "\u001b]\u0018C\u0000o\u001b]\u000f\u001f\f`\u0001\u0016\u000f\u0001\fu\u0006g^[U6";
      F[20] = "+!|1dA+!kmhN1jksh[6\u001b:(?\u0011";
      F[21] = "\\h\"R~\u0003Wg3\u001d\u0013\u0000[y5A1\rZl";
      F[22] = "Ly>SS'Ly)\u000f_(V2)\u0011_=QCyL\u000e";
      F[23] = "h\u0018Ht\u001d7h\u0018_(\u00118rS_6\u0011-u\"\niH";
      F[24] = "\u0017(+.\u000e\u0006\u001c':ai\u0004\t,:*R";
      F[25] = "V\u001ar{UrV\u001ae'Y}LQe9YhK 4b\f*";
      F[26] = ".|3\u0011:0.|$M6?47$S6*3Fu\bba";
      F[27] = "u,\u0019\\\u0005\u0014u,\u000e\u0000\t\u001bog\u000e\u001e\t\u000eh\u0016_A[E";
      F[28] = "`\u0013NEE\u0005v\u0013K\u001fV\u0012aXH\u0019Z\u0006p\u001f_\u000e\u0011\u0013]";
      F[29] = "\u0016+05\u001d\bc\u000b;:\fG\u0002\u000501\b\u001dv";
      F[30] = "+_ejLL Pt% O.Rvj\f";
      F[31] = "N\u0012\u000bX>1N\u0012\u001c\u00042>TY\u001c\u001a2+S(MEj";
      F[32] = "\u0014Y8Qa\u0007\u001fV)\u001e\t\u0007\u0011Y:";
      F[33] = float.class;
      G[33] = "java/lang/Float";
      F[34] = "v\u000fY1\u0003\u0010\u0003/R>\u0012_b!Y5\u0016\u0005\u0016";
      F[35] = "\rVOGx\u0007\rVX\u001bt\b\u0017\u001dX\u0005t\u001d\u0010l\bP#[";
      F[36] = "y\u0003V%7~o\u0003S\u007f$ixHPy(}i\u000fGncjQ";
      F[37] = "wsk5\bK\u0002S`:\u0019\u0004c]k1\u001d^\u0017";
      F[38] = "'5Z#bq15_yqf&~\\\u007f}r79Kh6e:";
      F[39] = "e\r\u000f\u001a\u0007Y\u0010-\u0004\u0015\u0016\u0016q#\u000f\u001e\u0012L\u0005";
      F[40] = "|\u0012\u00104#y\t2\u001b;26h<\u001006l\u001c";
      F[41] = ")\r\u0006\"g\u001f?\r\u0003xt\b(F\u0000~x\u001c9\u0001\u0017i3\f!\u0001\u0015biA\u001d\u001a\u0015\u007fi\u0006*\r";
      F[42] = "L1'V3)9\u0011,Y\"fX\u001f'R&<,";
      F[43] = "\u0015\u007f\"\u001b}2`_)\u0014l}\u0001Q\"\u001fh'u";
      F[44] = "gq\u0013f^Eyy\t)#Uy";
      F[45] = "\u001d'Q,\u0019Qh\u0007Z#\b\u001e\t\tQ(\fD}";
      F[46] = "&-Xm\u0002\u00150-]7\u0011\u0002'f^1\u001d\u00166!I&V\u0001\n";
      F[47] = "ahDO\u0010\r\u0014HO@\u0001BuFDK\u0005\u0018\u0001";
      F[48] = "6k\u000e\u0006;c k\u000b\\(t7 \bZ$`&g\u001fMow\u0018";
      F[49] = "l\u0000q\u0018V'\u0019 z\u0017Ghx.q\u001cC2\f";
      F[50] = "\u0002w0%[\u0003wW;*JL\u0016Y0!N\u0016b";
      F[51] = "6\u001a\t\u001d!E \u001a\fG2R7Q\u000fA>F&\u0016\u0018VuQ\u0019";
      F[52] = "(\u00144W?Y]4?X.\u0016<:4S*LH";
      F[53] = "\nr0<\u0012.\u001cr5f\u00019\u000b96`\r-\u001a~!wF:#";
      F[54] = "@\u0011SDjm51XK{\"T?S@\u007fx ";
      F[55] = "\u007f\u0001m(txi\u0001hrgo~Jktk{o\r|c j\"";
      F[56] = "dree:s\u0011Rnj+<p\\ea/f\u0004";
      F[57] = "sl\u0013\u0007\u001aMsl\u0004[\u0016Bi'\u0004E\u0016WnVU\u001aN\u0000~e\u0006Z\u0004{/=W";
      F[58] = "72s\u001a\"D!2v@1S6yuF=G'>bQvU?";
      F[59] = ">)\u0001Ma\u0018K\t\nBpW*\u0007\u0001It\r^";
      F[60] = "LG\u0018\u0004\u00035LG\u000fX\u000f:V\f\u000fF\u000f/Q}X\u0019Y";
      F[61] = "$$U_\u0015g$$B\u0003\u0019h>oB\u001d\u0019}9\u001e\u0016EN";
      F[62] = "7\u000eE,5\"7\u000eRp9--ERn98*4\u00031`";
      F[63] = "/\u0017\u0013\u0002ZGZ7\u0018\rK\b;9\u0013\u0006ORO";
      F[64] = "c4D\u0012e'\u0016\u0014O\u001dthw\u001aD\u0016p2\u0003";
      F[65] = "QS\u0011/4\u0011$s\u001a %^E}\u0011+!\u00041";
      F[66] = "B\u0016\fKld76\u0007D}+V8\fOyq\"";
      F[67] = "uStW\u0001CcSq\r\u0012Tt\u0018r\u000b\u001e@e_e\u001cUWV";
      F[68] = "2Z$zPNGz/uA\u0001&t$~E[R";
      F[69] = "?B\"nb+)B'4q<>\t$2}(/N3%68i";
      F[70] = "H(s\u000bSz=\bx\u0004B5\\\u0006s\u000fFo(";
      F[71] = "\u0002=\u0000\n9e\u0002=\u0017V5j\u0018v\u0017H5\u007f\u001f\u0007F\u0010g";
      F[72] = "\u0000X\u001cIf2\u0000X\u000b\u0015j=\u001a\u0013\u000b\u000bj(\u001dbZT>k";
      F[73] = "]C3B\f\u001bKC6\u0018\u001f\f\\\b5\u001e\u0013\u0018MO\"\tX\u000fP";
      F[74] = "\u0016.fE#\u0010c\u000emJ2_\u0002\u0000fA6\u0005v";
      F[75] = "i\u001e]K$U\u007f\u001eX\u00117BhU[\u0017;Vy\u0012L\u0000pGh";
      F[76] = "\u0017\u007fv\u0011!=b_}\u001e0r\u0003Qv\u00154(w";
      F[77] = "\u0016\t*[M8\u0016\t=\u0007A7\fB=\u0019A\"\u000b3l@\u0019g";
      F[78] = "\\0n_K&J0k\u0005X1]{h\u0003T%L<\u007f\u0014\u001f0m";
      F[79] = "!bZ=U!TBQ2Dn5LZ9@4A";
      F[80] = "\u0004ZQ\n$\t\u0004ZFV(\u0006\u001e\u0011FH(\u0013\u0019`\u0014\u0012|W";
      F[81] = "\u0002s'(\u0004o\u0002s0t\b`\u001880j\bu\u001fIb4P1";
      F[82] = "U\u0005a\ntdC\u0005dPgsTNgVkgE\tpA ~";
      F[83] = "G\u0012!v\u0001A22*y\u0010\u000eS<!r\u0014T'";
      F[84] = "'}WGa\u0012R]\\Hp]3SWCt\u0007G";
      F[85] = "3\u0016\u0010(\u0013\u0014F6\u001b'\u0002['8\u0010,\u0006\u0001S";
      F[86] = "R/Lt~X'\u000fG{o\u0017F\u0001LpkM2";
      F[87] = "\"u\u0004GT\u0010WU\u000fHE_6[\u0004CA\u0005B";
      F[88] = "\u001ah\u0012\u007f-doH\u0019p<+\u000eF\u0012{8qz";
      F[89] = "\fcgMUXyClBD\u0017\u0018MgI@Ml";
      F[90] = "\u0006:S*R\u007fs\u001aX%C0\u0012\u0014S.Gjf";
      F[91] = "We\u0012\u0002e'Tn\u0002\u00035B\u0000?\u0006\t8\u0015WePWT{U'\u0004\\1x^7\u0005\f";
      F[92] = "i\u001ccXFn0\u0015$\u0001\\R7\u00022X];4xcABi(E'\u0002_nP";
      F[93] = "D,EB\n&\u0012;R\u00061<E?_Z]\u000e\u0011z\u0001\u0000\rYE}@MR%E$QO17\u0013#Z_O!\u00158\u000f=";
      F[94] = "{6{@D/n4tT.7\u00036bJ\\gbwcM\u0010f\u0003c&\\O:?4&XJ]";
      F[95] = "QB$G\u0002DGC2\u0007m\\.K'Y\u001f\u000fO\n&^S\u000e.\rnM\u001dZ_\u001bo[]5";
      F[96] = "\u0019;QS-&O,F\u0017\u0016<\u0018(KKz\u000eOj\u0011\u0014*YI;\u001aM|#\u001a6AB\u0016";
      F[97] = "\u0013-Bx]zE2N'd$\u001c.A)3sB~\u0018E]w\r2\u001b.Z4C J";
      F[98] = "!?k&hC,<a#V\u0018\u0011kws$@p*vthA\u0011>3e7\u001d-i3a2z";
      F[99] = "oGDa\u001dH&\u0016C9\u001513\u0014V0\u001d]\u0001D\u0015iG1o\u0001\u00144\u001b\nl\u0007Tnz";
      F[100] = "*\u001e\u0011\u0013d}cO\u0016Kl\u0004vM\u0003BdhD\u001dO\u00182\u0004*\u001e\u000eXqdbL\u0010M3\u0004";
      F[101] = "}:s+3-+%\u007ft\nx~(tqfJ*i*'\n$kjpw1'm**\u0016";
      F[102] = "} @uH.p#JpvxMt\\ \u0004-,5]'H,Mt]p\u0012vvw[0H\u0017";
      F[103] = "\u001b)&F$H\u0013&$U\u001f\u001ekv`ImM\n7aN!Lk?\u007f\u0018~LT7p\u001amw";
      F[104] = "{s<\rk\u0006\"<pP\u0012\t}?\u001f\u0006v\u0015vC|\u0017kSc~8TvT\u001b";
      F[105] = "\u0018b92UOBf+1\r>HZ}(YL\u001b;<)^\u0000\u001aZ}iJ]C+'mX^\u001bZ";
      F[106] = "F6@c\txK5Jf7(vj\u0015)Q;\u00199\u0018$\nAGkT>M.\u0014fYe7";
      F[107] = "E\u000fI4\u0012eH\fC1,=u[Ua^f\u0014\u001aTf\u0012gu[T1H=NXRq\u0012\\";
      F[108] = "Z\rV\u001eZ$[\rC|G9@\nX\u0007*=\u0000\r^\u0001R:A\u001d<ER~Y\u0002\u0007FT>\u0003c";
      F[109] = "wu\b\u0010\\\u0004qw\u0002Om\u001e\u000e)\u0015@\u001fDoh\u0014GSE\u000e|QV\f\u00192+QR\t~";
      F[110] = "2\t\u001bnG)3\u001cQk5'8\nJrY\u0015lI\u0015%\u000eBlMSz\u0004'oFC{TB";
      F[111] = "dP1%3N&E.$%t7;gf;\u0006gZ&g<Jf;gs9\u0013l@<v3N6;";
      F[112] = "&K`\u0012^$)OdT0**I=N\\\u0018~\rg\u0017\bOzM$\u0012Hr>\u000e9\u00150";
      F[113] = "`{?w\u001ax6d3(#&ox<&tq1+eJG0qt2vSrqh";
      F[114] = "6\tc?V<`\u0016o`ob9\n`n85fW;\u0002\u0000n$Y{<\u00176'\t";
      F[115] = ", \t!\u00129#$\rg|7 \"T}\u0010\u0005tf\u000e$GRp&M!\u0004o4eP&|";
      F[116] = "\u001eF\fT`!\u0013E\u0006Q^q.\u0012\u0010\u0001,\"OS\u0011\u0006`#.\u0012\u0011Q:y\u0015\u0011\u0017\u0011`\u0018";
      F[117] = "2=\u001aO\u001c|;*OE\u000b\u0018e1\u001dD\u001aO2iH\u001bH\u00182=\u001aO\u001c|;*OE\u000b";
      F[118] = "C7I,\"\u0001\u000beW9`a\u001fdD67\r-8\tjPXDxB$0\u0010\u0016fWfPX\u00027\\7k[\u0004w\u0006V";
      F[119] = "O#t%\u0002\u0000Yso/h\u0012&+f(\u001aAGjg/V@&+gx\f\u001a\u001d(a8V{";
      F[120] = "FE+\u000f-gAX+\u001dTz|\u001a.\u001f&!\u001d[/\u0018j |\u001a/O0zG\u0019)\u000fj\u001b";
      F[121] = "\u001f A\u000b9.VqFS1WCsSZ9;q \u0016\u0003cW\u001ff\u0011^?l\u001c`Q\u0004^";
      F[122] = "lOO\u001e\u0004^aLE\u001b:\t\\\u001bSKH]=ZRL\u0004\\\\\u001bR\u001b^\u0006g\u0018T[\u0004g";
      F[123] = "V\u001d'%\u001dMR\u0011r0%\u001ck@a3\u001e\u000eV\u0004\".\u0019v";
      F[124] = "y\u0011d1i(y\u001cm/-\u0013)-$7zazLe6}-{-|0)(.Fs4-n@";
      F[125] = "N5gxx\u0007\u0010zs+\u0019V\u0014'{(N\u0002Ns\"~\u0019\u0004\u001a{~.cW\u0017 q";
      F[126] = "^nV\u0003p^QjRE\u001ePRl\u000b_rb\u0006(Q\u0006\"5\u0002h\u0012\u0003f\bF+\u000f\u0004\u001e";
      F[127] = "{!Y\u00153--&\u0007Y!\\,\"V\u0001/\u000b|y\u0000XCa::\u0000\u001d~%y'\u0007";
      F[128] = "\u0000Jf\u0011z/\u0005Sz\u0000E1\u00130zC+4\u0000H}\u0002;V\u0000Jf\u0011z/\u0005Sz\u0000E";
      F[129] = "3J->)x4W-,Pm\t\u0015(.\">hT))n?\t@l81c5\u0017l<4\u0004";
      F[130] = "xO<j`6|Ci\u007fXfE\u0012z|cuxV9ad\r";
      F[131] = "YA\u0014p{|TEJk@o]XHf)cdVHv-\u0005\u0003G\u0012o!>\u0000AR5@";
      F[132] = "x0Z\u0015\u007f0u3P\u0010AeHdF@33)%GG\u007f2HdG\u0010%hsgAP\u007f\t";
      F[133] = "i.v\u0001-*6nq\u0017N<\u000bji\u0014<lj+h\u0013pm\u000bjhD*70in\u0004pV";
      F[134] = "\u0001;\u0014\tG7\u00149\u001b\u001d-,y;\r\u0003_\u007f\u0018z\f\u0004\u0013~yzM\rI/\u000boO\u0002]E";
      F[135] = "\u0018[([+0R[|XY\"(\u001f\u007fX;6P\u0018>HY";
      F[136] = "\u001cq\u001fMs\u0010U \u0018\u0015{i@\"\r\u001cs\u0005rrNG%i\u001c,M\u001d{SG1\u0018\u0013,iC%\u0000M*Y\u001e>\u000eD\u0014";
      F[137] = "$Skdsq)PaaM,\u0014\u0007w1?ruFv6ss\u0014R3',/(\u00053#)H";
      F[138] = "eN[<1\u001d:\u000e\\*R\b\u0007\nD) [fKE.lZ\u0007_\u0000?3\u0006;\b\u0000;6a";
      F[139] = "9,`XuEo3l\u0007L\u001b6/c\t\u001bLhx;euK9s`\u001c<\u001a>+h";
      F[140] = "'iTpBI tTb;W\u001d6Q`I\u000f|wPg\u0005\u000e\u001d6P0_T&5Vp\u00055";
      F[141] = "HFYpmq\u0016\tM#\f \u0012TE [wK\u0000\u001eu\fr\u001c\b@&v!\u0011SO";
      F[142] = "qn_\u0018Cp~j[^-vim\u000bGV\u001bm-\fAPcjl\u001c#\u0014c.t\u0003\u0018\u0017en.b";
      F[143] = "e\u001c\u0002&xGd\t\\s\u0019]\u001e\u0017^&'\u000bd\u0011\\,x";
      F[144] = "\u0017T^\u001djE\u0010I^\u000f\u0013P-\u000b[\ra\u0003LJZ\n-\u0002-\u000fZ\u001a(A\u0010K\u0019\u0007/9";
      F[145] = "/c@'9u.v\n\"K{%`\u0011;'Iq#Nct\u001e)bLg%u&fH!K";
      F[146] = "t\t|\u0003\u0018[\"\u001ekG#Au\u001af\u001bOs$[:C\u001f$!\u001e8\u0018B\u001f\"\u0018xB#";
      F[147] = "U\u0010\u0002VMxBH\u0001\u00062#W\u000e\u001e\u000f^\u0011\nIDP2'DOE\u0006Y(@K\u0003h^)@\rE\u0017\b>WI~";
      F[148] = "\u001e\bDN\u001e\u0006W\u001d\u0004@J<NfBY\u0015N\u001d\u0007\u0003X\u0012\u0002\u001cf\u001dJ\n\r\u0019V@Q\u0004\u0004'";
      F[149] = "\u0004(\u0000?\u0010\u001dZ,K<\u0017tTG\u0000y\u0006\u0006\u0007&Ax\u0001J\u0006G\u0000`\u000b\nQ|Px\u0007\u001aCG";
      F[150] = "xALH$\u0006uBFM\u001a\\H\u0015P\u001dh\u0005)TQ\u001a$\u0004H@\u0014\u000b{Xt\u0017\u0014\u000f~?";
      F[151] = "WLF\u0011r:\b\fA\u0007\u0011/5\bY\u0004c|TIX\u0003/}5\bXTu'\u000e\u000b^\u0014/F";
      F[152] = "\u0001aBR\u001bZ\u0003$UVYcC[\u0001SN\u0011\u0002:@RI]\u0003[T\u0017X\u0002_g\u0003\u0017\\\u00078";
      F[153] = "CJ\u0003>Z\u0001DW\u0003,#\u0019y\u0015\u0006.QG\u0018T\u0007)\u001dFy\u0015\u0007~G\u001cB\u0016\u0001>\u001d}";
      F[154] = "\rTTDS}X\u000e_H\u0014\u0013]5\u000fX\u0001a\u000eTNY\u0006-\u000f5\u000fC\rcDDYDS/V5";
      F[155] = "**kRW\t*'bL\u00132\u007f\u0016+TD@)wjUC\f(\u0016+U\u0014Vr-(ST\f\u0013";
      F[156] = "Z65A\u0016\t^-=Y|\u0004\u0005 (\\+P_tp\t|U^(p\fM\n\u0005'=";
      F[157] = "\"\u000b\u0007H1Kk\u0015\u0007\u001d@NP]\u0001\u001a2\u001d1\u001c\u0000\u001d~\u001cP\u0016\u0017\u000b|V<_\t\u000b)'";
      F[158] = "31A)\nB>2K,4\u0012\u0003e]|FAb$\\{\n@\u0003;[#O\th:NiJ{";
      F[159] = "D[rt\u007fUIXxqA\ft\u000fn!3V\u0015No&\u007fWt\u000foq%\rO\fi1\u007fl";
      F[160] = "9U*%t\u001f4V  JK\t\u00016p8\u001ch@7wt\u001d\t\u00017 .G2\u00021`t&";
      F[161] = "'U\u001cxQC<BT\u007f3P&_\remW&E\t\u0019UT3\tZ)\bO=\u0000d";
      F[162] = "fvV\u0003`Zbm^\u001b\nW9`K\u001e]\th5\u0016r5\u0003=1\u0013CjX2|";
      F[163] = ")\u001btt->#\u0001#hCo(\u0014.}\u0014;r@z.C`/\u00014c2s4\u0019v";
      F[164] = "\u0001\u0016\b>\u0007R\f\u0015\u0002;9\u000e1B\u0014kKQP\u0003\u0015l\u0007P1\u0017P}X\f\r@Py]k";
      F[165] = "\u001eT\u0013a \u000eHC\u0004%\u001b\u0014\u001fG\tyw&H\u0004Y#!qNTX\u007fq\u000b\u001dY\u0003p\u001bH\n\u0005\r\u007f K\fEW\u001e";
      F[166] = "MI6@^lLK/U_\u0007\u001f sE\u000euNA2D\t9O sD^c\u0015\u001bpB\u001e9t";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = F[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(G[var4]);
            F[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = F[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = G[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            F[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  F[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(85058970227491L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = F[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = G[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  F[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(85058970227491L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        F[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(85058970227491L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 67;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 226;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 212;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 71;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 198;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 109;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 67;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 226;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 212;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ey_C0266",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ey" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$3", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$8", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$4", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$6", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(DoubleAnchor var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ey_C0266;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/ey_C0266", "lambda$new$5", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((DoubleAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding9(BlockHitResult var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Lnet/minecraft/util/hit/BlockHitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/ey_C0266", "lambda$onMotionUpdate$9", "(Lnet/minecraft/util/hit/BlockHitResult;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((BlockHitResult)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
