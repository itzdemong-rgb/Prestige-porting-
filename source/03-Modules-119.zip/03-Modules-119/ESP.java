package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.EntityModelManager;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ConcurrentIdentitySet;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.RenderEvents;
import dev.zprestige.prestige.renderlib.RenderCallback;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.effects.EffectType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.ui.MenuSettings;
import dev.zprestige.prestige.renderlib.RLUniforms;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.entity.EntityType;

public class ESP extends Module {
   private static final String a;
   private static final String b;
   private static final String c;
   private ModeSetting d;
   private MultiModeSetting e;
   private BooleanSetting f;
   private ColorSetting g;
   private IntSetting h;
   private IntSetting i;
   private BooleanSetting j;
   private FloatSetting k;
   private FloatSetting l;
   private FloatSetting m;
   private FloatSetting n;
   private FloatSetting o;
   private BooleanSetting p;
   private boolean[] q;
   private String r;
   private boolean s = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private Consumer t;
   public static final ThreadLocal u;
   private static final long v = 36099288923116L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long z;
   private static final Object[] A = new Object[172];
   private static final String[] B = new String[172];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;

   @EventListener
   public void a(TickEvent var1) {
      int var10;
      Object var37;
      label33: {
         label32: {
            long var10001 = 88898565768019L ^ 85817672557158L;
            var10001 = 88898565768019L ^ 41195561494720L;
            var10001 = 88898565768019L ^ 6791606767590L;
            int var10000 = Event.cReturningInt();
            MultiModeSetting var13 = this.e;
            boolean[] var11 = var13.aReturningArrayOfBoolean();
            var10 = var10000;
            int var41 = var10;
            ESP var40 = this;
            ESP var36 = var40;
            ESP var33 = var40;
            if (var41 != 0) {
               boolean[] var42 = var33.q;
               if (var42 != null) {
                  int var44 = var10;
                  boolean[] var43 = var11;
                  var37 = var43;
                  boolean[] var34 = var43;
                  if (var44 == 0) {
                     break label33;
                  }

                  boolean[] var45 = var34;
                  boolean[] var35 = var45;
                  boolean[] var17 = this.q;
                  boolean[] var16 = var35;
                  boolean var46 = Arrays.equals(var16, var17);
                  if (var46) {
                     break label32;
                  }
               }

               Object[] var20 = new Object[]{33907500933429L};
               ESP var19 = this;
               var19.kReturningVoid(var20);
               ESP var47 = this;
               var36 = var47;
            }

            int var23 = var11.length;
            boolean[] var22 = var11;
            var36.q = Arrays.copyOf(var22, var23);
         }

         ModeSetting var24 = this.d;
         var37 = var24.aReturningObject();
      }

      String var12 = (String)var37;
      String var26 = this.r;
      String var25 = var12;
      boolean var51 = var25.equals(var26);
      int var49 = var10;
      boolean var48 = var51;
      boolean var39 = var48;
      boolean var38 = var48;
      if (var49 != 0) {
         boolean var50 = var38;
         if (!var50) {
            Object[] var28 = new Object[]{var12, 129389540944787L};
            Object[] var29 = new Object[]{a(var28), 95618926120117L};
            EntityModelManager.aReturningVoid(var29);
            this.r = var12;
         }

         BooleanSetting var31 = this.p;
         Boolean var32 = (Boolean)var31.aReturningObject();
         var39 = var32;
      }

      EntityModelManager.f = var39;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 105468164980460L;
      long var6 = var2 ^ 137124968012234L;
      ModeSetting var9 = this.d;
      Object[] var10 = new Object[]{(String)var9.aReturningObject(), var4};
      Object[] var11 = new Object[]{a(var10), var6};
      EntityModelManager.aReturningVoid(var11);
      int var10000 = Event.cReturningInt();
      ModeSetting var12 = this.d;
      this.r = (String)var12.aReturningObject();
      int var8 = var10000;
      int var22 = var8;
      boolean var21 = this.s;
      boolean var20 = var21;
      boolean var19 = var21;
      if (var22 != 0) {
         boolean var23 = var19;
         if (!var23) {
            net.fabricmc.fabric.api.event.Event var24 = RenderEvents.c;
            RenderCallback var15 = invokeBinding1(this);
            net.fabricmc.fabric.api.event.Event var14 = var24;
            var14.register(var15);
            this.s = dev.prestige.recovery.SourceSupport.asBoolean(1);
         }

         EntityModelManager.e = dev.prestige.recovery.SourceSupport.asBoolean(1);
         BooleanSetting var17 = this.p;
         Boolean var18 = (Boolean)var17.aReturningObject();
         var20 = var18;
      }

      EntityModelManager.f = var20;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      EntityModelManager.e = dev.prestige.recovery.SourceSupport.asBoolean(0);
      EntityModelManager.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
      int var10000 = Event.cReturningInt();
      Object[] var6 = new Object[0];
      FramebufferEffect var5 = EntityModelManager.aReturningc_(var6);
      int var4 = var10000;
      int var13 = var4;
      FramebufferEffect var12 = var5;
      FramebufferEffect var11 = var12;
      FramebufferEffect var10 = var12;
      if (var13 != 0) {
         FramebufferEffect var14 = var10;
         if (var14 == null) {
            return;
         }

         var11 = var5;
      }

      Object[] var9 = new Object[]{null};
      FramebufferEffect var8 = var11;
      var8.dReturningVoid(var9);
   }

   private void jReturningVoid(Object[] param1) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[11];
      recoveryLocals[0]=this;
      recoveryLocals[1]=param1;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((dev.zprestige.prestige.renderlib.RLUniforms)recoveryStack[1]); }
                  recoveryAt=5; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=6; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=7; { recoveryStack[2]=1; }
                  recoveryAt=8; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=9; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=10; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=11; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=13; { recoveryStack[0]=36099288923116L; }
                  recoveryAt=14; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=15; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=16; { recoveryLocals[3]=recoveryStack[0];  }
                  recoveryAt=17; { recoveryStack[0]=-223178370781879107L; }
                  recoveryAt=18; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=19; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding2(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=22; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=23; { recoveryStack[1]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[1]).d; }
                  recoveryAt=24; { recoveryStack[2]=-227696425181923329L; }
                  recoveryAt=25; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=26; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding3(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=27; { recoveryStack[1]=((java.lang.String)recoveryStack[1]); }
                  recoveryAt=28; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=29; { recoveryLocals[5]=recoveryStack[0];  }
                  recoveryAt=32; { recoveryStack[0]=1; }
                  recoveryAt=33; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=34; { recoveryStack[1]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[1]).h; }
                  recoveryAt=35; { recoveryStack[2]=-227696425181923329L; }
                  recoveryAt=36; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=37; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding4(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=38; { recoveryStack[1]=((java.lang.Integer)recoveryStack[1]); }
                  recoveryAt=39; { recoveryStack[2]=-220958509532481074L; }
                  recoveryAt=40; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=41; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding5(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=42; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.z; }
                  recoveryAt=43; { recoveryStack[2]=(int)dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=44; { recoveryStack[3]=-223706623910260200L; }
                  recoveryAt=45; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=46; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding6(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=47; { recoveryStack[2]=-218015132430223103L; }
                  recoveryAt=48; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=49; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding7(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=50; { recoveryLocals[7]=recoveryStack[0];  }
                  recoveryAt=53; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=54; { recoveryStack[0]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[0]).f; }
                  recoveryAt=55; { recoveryStack[1]=-227696425181923329L; }
                  recoveryAt=56; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=57; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding8(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=58; { recoveryStack[0]=((java.lang.Boolean)recoveryStack[0]); }
                  recoveryAt=59; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=60; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=111; continue recoveryFlow;} recoveryPc=62; continue recoveryFlow; }
               }
               case 62 -> {
                  recoveryAt=62; { recoveryStack[1]=-222989314933497950L; }
                  recoveryAt=63; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=64; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding9(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=65; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=104; continue recoveryFlow;} recoveryPc=67; continue recoveryFlow; }
               }
               case 67 -> {
                  recoveryAt=67; { recoveryPc=77; continue recoveryFlow; }
               }
               case 70 -> {
                  recoveryAt=70; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=71; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=72; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding10(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=73; { throw (Throwable)recoveryStack[0]; }
               }
               case 77 -> {
                  recoveryAt=77; { recoveryStack[0]=-228314289493299811L; }
                  recoveryAt=78; { recoveryStack[1]=recoveryLocals[3];  }
                  recoveryAt=79; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding11(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=80; { recoveryStack[1]=0; }
                  recoveryAt=81; { recoveryStack[1]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])]; }
                  recoveryAt=82; { recoveryStack[2]=-217254863508838351L; }
                  recoveryAt=83; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=84; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding12(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=85; { recoveryStack[1]=0; }
                  recoveryAt=86; { recoveryStack[1]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])]; }
                  recoveryAt=87; { recoveryStack[2]=-228273551447170370L; }
                  recoveryAt=88; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=89; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding13(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=90; { recoveryStack[1]=-227696425181923329L; }
                  recoveryAt=91; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=92; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding14(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=93; { recoveryStack[0]=((java.awt.Color)recoveryStack[0]); }
                  recoveryAt=94; { recoveryPc=114; continue recoveryFlow; }
               }
               case 97 -> {
                  recoveryAt=97; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=98; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=99; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding15(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=100; { throw (Throwable)recoveryStack[0]; }
               }
               case 104 -> {
                  recoveryAt=104; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=105; { recoveryStack[0]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[0]).g; }
                  recoveryAt=106; { recoveryStack[1]=-227696425181923329L; }
                  recoveryAt=107; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=108; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding16(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryPc=111; continue recoveryFlow;
               }
               case 111 -> {
                  recoveryAt=111; { recoveryStack[0]=((java.awt.Color)recoveryStack[0]); }
                  recoveryPc=114; continue recoveryFlow;
               }
               case 114 -> {
                  recoveryAt=114; { recoveryLocals[8]=recoveryStack[0];  }
                  recoveryAt=117; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=118; { recoveryStack[1]=6785; }
                  recoveryAt=119; { recoveryStack[2]=7866666967593456499L; }
                  recoveryAt=120; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=121; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=122; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding17(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=123; { recoveryStack[2]=recoveryLocals[8];  }
                  recoveryAt=124; { recoveryStack[3]=-221066909625135414L; }
                  recoveryAt=125; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=126; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding18(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=130; { recoveryStack[0]=recoveryLocals[6];  }
                  recoveryAt=131; { recoveryLocals[9]=recoveryStack[0];  }
                  recoveryAt=132; { recoveryStack[0]=-1; }
                  recoveryAt=133; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=135; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=136; { recoveryStack[1]=-221167529850679522L; }
                  recoveryAt=137; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=138; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding19(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=139; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=140; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=268; continue recoveryFlow;} recoveryPc=142; continue recoveryFlow; }
               }
               case 142 -> {
                  recoveryAt=142; { recoveryPc=switch(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])){ case -1955878649 -> 151;case 2052483 -> 229;case 65070882 -> 190;default -> 265;}; continue recoveryFlow; }
               }
               case 145 -> {
                  recoveryAt=145; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=146; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=147; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding20(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=148; { throw (Throwable)recoveryStack[0]; }
               }
               case 151 -> {
                  recoveryAt=151; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=152; { recoveryStack[1]=21899; }
                  recoveryAt=153; { recoveryStack[2]=1685133147731254368L; }
                  recoveryAt=154; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=155; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=156; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding21(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=157; { recoveryStack[2]=-224363965736601254L; }
                  recoveryAt=158; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=159; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding22(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=160; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=161; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=268; continue recoveryFlow;} recoveryPc=163; continue recoveryFlow; }
               }
               case 163 -> {
                  recoveryAt=163; { recoveryPc=172; continue recoveryFlow; }
               }
               case 166 -> {
                  recoveryAt=166; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=167; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=168; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding23(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=169; { throw (Throwable)recoveryStack[0]; }
               }
               case 172 -> {
                  recoveryAt=172; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=265; continue recoveryFlow;} recoveryPc=174; continue recoveryFlow; }
               }
               case 174 -> {
                  recoveryAt=174; { recoveryPc=183; continue recoveryFlow; }
               }
               case 177 -> {
                  recoveryAt=177; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=178; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=179; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding24(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=180; { throw (Throwable)recoveryStack[0]; }
               }
               case 183 -> {
                  recoveryAt=183; { recoveryStack[0]=0; }
                  recoveryAt=184; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=186; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=187; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=265; continue recoveryFlow;} recoveryPc=190; continue recoveryFlow; }
               }
               case 190 -> {
                  recoveryAt=190; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=191; { recoveryStack[1]=5844; }
                  recoveryAt=192; { recoveryStack[2]=8189344986833002296L; }
                  recoveryAt=193; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=194; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=195; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding25(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=196; { recoveryStack[2]=-224363965736601254L; }
                  recoveryAt=197; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=198; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding26(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=199; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=200; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=268; continue recoveryFlow;} recoveryPc=202; continue recoveryFlow; }
               }
               case 202 -> {
                  recoveryAt=202; { recoveryPc=211; continue recoveryFlow; }
               }
               case 205 -> {
                  recoveryAt=205; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=206; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=207; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding27(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=208; { throw (Throwable)recoveryStack[0]; }
               }
               case 211 -> {
                  recoveryAt=211; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=265; continue recoveryFlow;} recoveryPc=213; continue recoveryFlow; }
               }
               case 213 -> {
                  recoveryAt=213; { recoveryPc=222; continue recoveryFlow; }
               }
               case 216 -> {
                  recoveryAt=216; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=217; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=218; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding28(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=219; { throw (Throwable)recoveryStack[0]; }
               }
               case 222 -> {
                  recoveryAt=222; { recoveryStack[0]=1; }
                  recoveryAt=223; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=225; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=226; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=265; continue recoveryFlow;} recoveryPc=229; continue recoveryFlow; }
               }
               case 229 -> {
                  recoveryAt=229; { recoveryStack[0]=recoveryLocals[9];  }
                  recoveryAt=230; { recoveryStack[1]=27047; }
                  recoveryAt=231; { recoveryStack[2]=2630935243274903634L; }
                  recoveryAt=232; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=233; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=234; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding29(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=235; { recoveryStack[2]=-224363965736601254L; }
                  recoveryAt=236; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=237; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding30(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=238; { recoveryStack[1]=recoveryLocals[5];  }
                  recoveryAt=239; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1])==0){recoveryPc=268; continue recoveryFlow;} recoveryPc=241; continue recoveryFlow; }
               }
               case 241 -> {
                  recoveryAt=241; { recoveryPc=250; continue recoveryFlow; }
               }
               case 244 -> {
                  recoveryAt=244; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=245; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=246; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding31(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=247; { throw (Throwable)recoveryStack[0]; }
               }
               case 250 -> {
                  recoveryAt=250; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=265; continue recoveryFlow;} recoveryPc=252; continue recoveryFlow; }
               }
               case 252 -> {
                  recoveryAt=252; { recoveryPc=261; continue recoveryFlow; }
               }
               case 255 -> {
                  recoveryAt=255; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=256; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=257; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding32(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=258; { throw (Throwable)recoveryStack[0]; }
               }
               case 261 -> {
                  recoveryAt=261; { recoveryStack[0]=2; }
                  recoveryAt=262; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryPc=265; continue recoveryFlow;
               }
               case 265 -> {
                  recoveryAt=265; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryPc=268; continue recoveryFlow;
               }
               case 268 -> {
                  recoveryAt=268; { recoveryPc=switch(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])){ case 0 -> 272;case 1 -> 368;case 2 -> 421;default -> 570;}; continue recoveryFlow; }
               }
               case 272 -> {
                  recoveryAt=272; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=273; { recoveryStack[1]=31661; }
                  recoveryAt=274; { recoveryStack[2]=5337819144976101979L; }
                  recoveryAt=275; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=276; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=277; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding33(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=278; { recoveryStack[2]=recoveryLocals[7];  }
                  recoveryAt=279; { recoveryStack[3]=-224060158055092154L; }
                  recoveryAt=280; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=281; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding34(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=282; { recoveryStack[1]=5101; }
                  recoveryAt=283; { recoveryStack[2]=4051212796726680079L; }
                  recoveryAt=284; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=285; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=286; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding35(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=287; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=288; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).i; }
                  recoveryAt=291; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=292; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=293; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding36(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=294; { recoveryStack[2]=((java.lang.Integer)recoveryStack[2]); }
                  recoveryAt=295; { recoveryStack[3]=-228478179367885845L; }
                  recoveryAt=296; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=297; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding37(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=298; { recoveryStack[3]=recoveryLocals[5];  }
                  recoveryAt=299; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])==0){recoveryPc=351; continue recoveryFlow;} recoveryPc=301; continue recoveryFlow; }
               }
               case 301 -> {
                  recoveryAt=301; { recoveryPc=310; continue recoveryFlow; }
               }
               case 304 -> {
                  recoveryAt=304; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=305; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=306; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding38(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=307; { throw (Throwable)recoveryStack[0]; }
               }
               case 310 -> {
                  recoveryAt=310; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=311; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=312; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding39(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=313; { recoveryStack[1]=30942; }
                  recoveryAt=314; { recoveryStack[2]=1697516861745623332L; }
                  recoveryAt=315; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=316; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=317; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding40(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=320; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=321; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).j; }
                  recoveryAt=322; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=323; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=324; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding41(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=325; { recoveryStack[2]=((java.lang.Boolean)recoveryStack[2]); }
                  recoveryAt=326; { recoveryStack[3]=-222989314933497950L; }
                  recoveryAt=327; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=328; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding42(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=329; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])==0){recoveryPc=354; continue recoveryFlow;} recoveryPc=331; continue recoveryFlow; }
               }
               case 331 -> {
                  recoveryAt=331; { recoveryPc=340; continue recoveryFlow; }
               }
               case 334 -> {
                  recoveryAt=334; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=335; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=336; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding43(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=337; { throw (Throwable)recoveryStack[0]; }
               }
               case 340 -> {
                  recoveryAt=340; { recoveryStack[2]=Float.intBitsToFloat(1050253722); }
                  recoveryAt=342; { recoveryPc=357; continue recoveryFlow; }
               }
               case 345 -> {
                  recoveryAt=345; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=346; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=347; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding44(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=348; { throw (Throwable)recoveryStack[0]; }
               }
               case 351 -> {
                  recoveryAt=351; { recoveryPc=357; continue recoveryFlow; }
               }
               case 354 -> {
                  recoveryAt=354; { recoveryStack[2]=Float.intBitsToFloat(0); }
                  recoveryPc=357; continue recoveryFlow;
               }
               case 357 -> {
                  recoveryAt=357; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=358; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=359; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding45(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=363; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=364; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=570; continue recoveryFlow;} recoveryPc=368; continue recoveryFlow; }
               }
               case 368 -> {
                  recoveryAt=368; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=369; { recoveryStack[1]=13455; }
                  recoveryAt=370; { recoveryStack[2]=3297897369069895009L; }
                  recoveryAt=371; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=372; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=373; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding46(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=374; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=375; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).k; }
                  recoveryAt=376; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=377; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=378; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding47(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=379; { recoveryStack[2]=((java.lang.Float)recoveryStack[2]); }
                  recoveryAt=380; { recoveryStack[3]=-221933233745332663L; }
                  recoveryAt=381; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=382; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding48(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=383; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=384; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=385; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding49(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=386; { recoveryStack[1]=17151; }
                  recoveryAt=387; { recoveryStack[2]=3339309342568008470L; }
                  recoveryAt=388; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=389; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=390; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding50(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=391; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=392; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).l; }
                  recoveryAt=395; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=396; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=397; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding51(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=398; { recoveryStack[2]=((java.lang.Float)recoveryStack[2]); }
                  recoveryAt=399; { recoveryStack[3]=-221933233745332663L; }
                  recoveryAt=400; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=401; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding52(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=402; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=403; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=404; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding53(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=408; { recoveryStack[0]=recoveryLocals[5];  }
                  recoveryAt=409; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=570; continue recoveryFlow;} recoveryPc=411; continue recoveryFlow; }
               }
               case 411 -> {
                  recoveryAt=411; { recoveryPc=421; continue recoveryFlow; }
               }
               case 414 -> {
                  recoveryAt=414; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=415; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=416; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding54(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=417; { throw (Throwable)recoveryStack[0]; }
               }
               case 421 -> {
                  recoveryAt=421; { recoveryStack[0]=recoveryLocals[2];  }
                  recoveryAt=422; { recoveryStack[1]=22737; }
                  recoveryAt=423; { recoveryStack[2]=851083889633612077L; }
                  recoveryAt=424; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=425; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=426; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding55(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=427; { recoveryStack[2]=recoveryLocals[7];  }
                  recoveryAt=428; { recoveryStack[3]=-224060158055092154L; }
                  recoveryAt=429; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=430; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding56(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=431; { recoveryStack[1]=27581; }
                  recoveryAt=432; { recoveryStack[2]=7465947961893151323L; }
                  recoveryAt=433; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=434; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=435; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding57(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=436; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=437; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).i; }
                  recoveryAt=440; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=441; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=442; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding58(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=443; { recoveryStack[2]=((java.lang.Integer)recoveryStack[2]); }
                  recoveryAt=444; { recoveryStack[3]=-228478179367885845L; }
                  recoveryAt=445; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=446; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding59(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=447; { recoveryStack[3]=recoveryLocals[5];  }
                  recoveryAt=448; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])==0){recoveryPc=500; continue recoveryFlow;} recoveryPc=450; continue recoveryFlow; }
               }
               case 450 -> {
                  recoveryAt=450; { recoveryPc=459; continue recoveryFlow; }
               }
               case 453 -> {
                  recoveryAt=453; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=454; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=455; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding60(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=456; { throw (Throwable)recoveryStack[0]; }
               }
               case 459 -> {
                  recoveryAt=459; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=460; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=461; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding61(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=462; { recoveryStack[1]=541; }
                  recoveryAt=463; { recoveryStack[2]=9052154096053455842L; }
                  recoveryAt=464; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=465; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=466; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding62(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=469; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=470; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).j; }
                  recoveryAt=471; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=472; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=473; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding63(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=474; { recoveryStack[2]=((java.lang.Boolean)recoveryStack[2]); }
                  recoveryAt=475; { recoveryStack[3]=-222989314933497950L; }
                  recoveryAt=476; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=477; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding64(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=478; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])==0){recoveryPc=503; continue recoveryFlow;} recoveryPc=480; continue recoveryFlow; }
               }
               case 480 -> {
                  recoveryAt=480; { recoveryPc=489; continue recoveryFlow; }
               }
               case 483 -> {
                  recoveryAt=483; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=484; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=485; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding65(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=486; { throw (Throwable)recoveryStack[0]; }
               }
               case 489 -> {
                  recoveryAt=489; { recoveryStack[2]=Float.intBitsToFloat(1050253722); }
                  recoveryAt=491; { recoveryPc=506; continue recoveryFlow; }
               }
               case 494 -> {
                  recoveryAt=494; { recoveryStack[1]=-218076355976779257L; }
                  recoveryAt=495; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=496; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding66(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=497; { throw (Throwable)recoveryStack[0]; }
               }
               case 500 -> {
                  recoveryAt=500; { recoveryPc=506; continue recoveryFlow; }
               }
               case 503 -> {
                  recoveryAt=503; { recoveryStack[2]=Float.intBitsToFloat(0); }
                  recoveryPc=506; continue recoveryFlow;
               }
               case 506 -> {
                  recoveryAt=506; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=507; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=508; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding67(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=509; { recoveryStack[1]=3982; }
                  recoveryAt=510; { recoveryStack[2]=7790446051356444230L; }
                  recoveryAt=511; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=512; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=513; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding68(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=514; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=515; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).m; }
                  recoveryAt=518; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=519; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=520; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding69(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=521; { recoveryStack[2]=((java.lang.Float)recoveryStack[2]); }
                  recoveryAt=522; { recoveryStack[3]=-221933233745332663L; }
                  recoveryAt=523; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=524; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding70(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=525; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=526; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=527; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding71(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=528; { recoveryStack[1]=29543; }
                  recoveryAt=529; { recoveryStack[2]=8526420176595679879L; }
                  recoveryAt=530; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=531; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=532; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding72(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=533; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=534; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).n; }
                  recoveryAt=537; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=538; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=539; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding73(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=540; { recoveryStack[2]=((java.lang.Float)recoveryStack[2]); }
                  recoveryAt=541; { recoveryStack[3]=-221933233745332663L; }
                  recoveryAt=542; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=543; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding74(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=544; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=545; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=546; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding75(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=547; { recoveryStack[1]=27052; }
                  recoveryAt=548; { recoveryStack[2]=6824741444730085443L; }
                  recoveryAt=549; { recoveryStack[3]=recoveryLocals[3];  }
                  recoveryAt=550; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=551; { recoveryStack[1]=dev.zprestige.prestige.client.modules.ESP.invokeBinding76(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=552; { recoveryStack[2]=recoveryLocals[0];  }
                  recoveryAt=553; { recoveryStack[2]=((dev.zprestige.prestige.client.modules.ESP)recoveryStack[2]).o; }
                  recoveryAt=556; { recoveryStack[3]=-227696425181923329L; }
                  recoveryAt=557; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=558; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding77(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=559; { recoveryStack[2]=((java.lang.Float)recoveryStack[2]); }
                  recoveryAt=560; { recoveryStack[3]=-221933233745332663L; }
                  recoveryAt=561; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=562; { recoveryStack[2]=dev.zprestige.prestige.client.modules.ESP.invokeBinding78(((java.lang.Object)recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryAt=563; { recoveryStack[3]=-228078710499507627L; }
                  recoveryAt=564; { recoveryStack[4]=recoveryLocals[3];  }
                  recoveryAt=565; { recoveryStack[0]=dev.zprestige.prestige.client.modules.ESP.invokeBinding79(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asFloat(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[4])); }
                  recoveryPc=570; continue recoveryFlow;
               }
               case 570 -> {
                  recoveryAt=570; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=51 && recoveryAt<66 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=70; continue recoveryFlow;}
            if(recoveryAt>=61 && recoveryAt<95 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=97; continue recoveryFlow;}
            if(recoveryAt>=134 && recoveryAt<143 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=145; continue recoveryFlow;}
            if(recoveryAt>=141 && recoveryAt<162 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=166; continue recoveryFlow;}
            if(recoveryAt>=149 && recoveryAt<173 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=177; continue recoveryFlow;}
            if(recoveryAt>=185 && recoveryAt<201 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=205; continue recoveryFlow;}
            if(recoveryAt>=188 && recoveryAt<212 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=216; continue recoveryFlow;}
            if(recoveryAt>=224 && recoveryAt<240 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=244; continue recoveryFlow;}
            if(recoveryAt>=227 && recoveryAt<251 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=255; continue recoveryFlow;}
            if(recoveryAt>=266 && recoveryAt<300 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=304; continue recoveryFlow;}
            if(recoveryAt>=269 && recoveryAt<330 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=334; continue recoveryFlow;}
            if(recoveryAt>=308 && recoveryAt<341 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=345; continue recoveryFlow;}
            if(recoveryAt>=355 && recoveryAt<410 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=414; continue recoveryFlow;}
            if(recoveryAt>=365 && recoveryAt<449 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=453; continue recoveryFlow;}
            if(recoveryAt>=418 && recoveryAt<479 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=483; continue recoveryFlow;}
            if(recoveryAt>=457 && recoveryAt<490 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=494; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   private static EffectType a(Object[] var0) {
      int var20;
      String var3 = (String)var0[0];
      long var1 = (Long)var0[1];
      var1 = 36099288923116L ^ var1;
      int var10000 = Event.cReturningInt();
      String var5 = var3;
      int var4 = var10000;
      // String var7 = var5;
      var10000 = var7.hashCode();
      int var23 = var4;
      int var22 = var10000;
      var20 = var22;
      int var15 = var22;
      label37:
      if (var23 != 0) {
         int var24 = var15;
         switch (var24) {
            case 65070882:
               short var10001 = 5844;
               long var10002 = 8189355478990500789L ^ var1;
               String var10 = "Chams";
               String var9 = var5;
               byte var39 = ((byte)((var9.equals(var10)) ? 1 : 0));
               int var26 = var4;
               byte var25 = var39;
               var20 = var25;
               byte var16 = var25;
               if (var26 == 0) {
                  break label37;
               }

               byte var27 = var16;
               byte var17 = var27;
               byte var28 = var17;
               if (var28 == 0) {
                  break;
               }

               var6 = 0;
               int var29 = var4;
               if (var29 != 0) {
                  break;
               }
            case 2052483:
               short var41 = 1502;
               long var42 = 6331415852823847075L ^ var1;
               String var14 = "Aura";
               String var13 = var5;
               byte var40 = ((byte)((var13.equals(var14)) ? 1 : 0));
               int var31 = var4;
               byte var30 = var40;
               var20 = var30;
               byte var18 = var30;
               if (var31 == 0) {
                  break label37;
               }

               byte var32 = var18;
               byte var19 = var32;
               byte var33 = var19;
               if (var33 != 0) {
                  var6 = 1;
               }
         }

         var20 = var6;
      }

      int var34 = var20;

      return switch (var34) {
         case 0 -> {
            EffectType var35 = EffectType.CHAMS;
            yield var35;
         }
         case 1 -> {
            EffectType var36 = EffectType.AURA;
            yield var36;
         }
         default -> EffectType.NORMAL;
      };
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 36099288923116L ^ var2;
      long var4 = var2 ^ 130186147999437L;
      long var6 = var2 ^ 31079043739704L;
      long var8 = var2 ^ 139611252244663L;
      int var10000 = Event.bReturningInt();
      ConcurrentIdentitySet var11 = new ConcurrentIdentitySet(new EntityType[0], var4);
      int var10 = var10000;
      MultiModeSetting var335 = this.e;
      short var10001 = 9638;
      long var10002 = 6001361811740805740L ^ var2;
      Object[] var13 = new Object[]{"Players", var8};
      MultiModeSetting var12 = var335;
      boolean var336 = var12.aReturningBoolean(var13);
      int var292 = var10;
      boolean var291 = var336;
      boolean var264 = var291;
      boolean var263 = var291;
      if (var292 == 0) {
         boolean var293 = var263;
         if (var293) {
            Object[] var16 = new Object[]{EntityType.PLAYER, var6};
            ConcurrentIdentitySet var15 = var11;
            var15.aReturningBoolean(var16);
         }

         MultiModeSetting var337 = this.e;
         var10001 = 13388;
         var10002 = 6170324365266803606L ^ var2;
         Object[] var19 = new Object[]{"Crystals", var8};
         MultiModeSetting var18 = var337;
         var264 = var18.aReturningBoolean(var19);
      }

      int var295 = var10;
      boolean var294 = var264;
      boolean var266 = var294;
      boolean var265 = var294;
      if (var295 == 0) {
         boolean var296 = var265;
         if (var296) {
            Object[] var22 = new Object[]{EntityType.END_CRYSTAL, var6};
            ConcurrentIdentitySet var21 = var11;
            var21.aReturningBoolean(var22);
         }

         MultiModeSetting var338 = this.e;
         var10001 = 7850;
         var10002 = 3396354037835821434L ^ var2;
         Object[] var25 = new Object[]{"Items", var8};
         MultiModeSetting var24 = var338;
         var266 = var24.aReturningBoolean(var25);
      }

      int var298 = var10;
      boolean var297 = var266;
      boolean var268 = var297;
      boolean var267 = var297;
      if (var298 == 0) {
         boolean var299 = var267;
         if (var299) {
            Object[] var28 = new Object[]{EntityType.ITEM, var6};
            ConcurrentIdentitySet var27 = var11;
            var27.aReturningBoolean(var28);
         }

         MultiModeSetting var339 = this.e;
         var10001 = 5839;
         var10002 = 6576478924391872769L ^ var2;
         Object[] var31 = new Object[]{"Monsters", var8};
         MultiModeSetting var30 = var339;
         var268 = var30.aReturningBoolean(var31);
      }

      int var301 = var10;
      boolean var300 = var268;
      boolean var270 = var300;
      boolean var269 = var300;
      if (var301 == 0) {
         boolean var302 = var269;
         if (var302) {
            Object[] var34 = new Object[]{EntityType.ZOMBIE, var6};
            ConcurrentIdentitySet var33 = var11;
            var33.aReturningBoolean(var34);
            Object[] var36 = new Object[]{EntityType.SKELETON, var6};
            ConcurrentIdentitySet var35 = var11;
            var35.aReturningBoolean(var36);
            Object[] var38 = new Object[]{EntityType.CREEPER, var6};
            ConcurrentIdentitySet var37 = var11;
            var37.aReturningBoolean(var38);
            Object[] var40 = new Object[]{EntityType.SPIDER, var6};
            ConcurrentIdentitySet var39 = var11;
            var39.aReturningBoolean(var40);
            Object[] var42 = new Object[]{EntityType.CAVE_SPIDER, var6};
            ConcurrentIdentitySet var41 = var11;
            var41.aReturningBoolean(var42);
            Object[] var44 = new Object[]{EntityType.ZOMBIE_VILLAGER, var6};
            ConcurrentIdentitySet var43 = var11;
            var43.aReturningBoolean(var44);
            Object[] var46 = new Object[]{EntityType.HUSK, var6};
            ConcurrentIdentitySet var45 = var11;
            var45.aReturningBoolean(var46);
            Object[] var48 = new Object[]{EntityType.DROWNED, var6};
            ConcurrentIdentitySet var47 = var11;
            var47.aReturningBoolean(var48);
            Object[] var50 = new Object[]{EntityType.STRAY, var6};
            ConcurrentIdentitySet var49 = var11;
            var49.aReturningBoolean(var50);
            Object[] var52 = new Object[]{EntityType.WITCH, var6};
            ConcurrentIdentitySet var51 = var11;
            var51.aReturningBoolean(var52);
            Object[] var54 = new Object[]{EntityType.SLIME, var6};
            ConcurrentIdentitySet var53 = var11;
            var53.aReturningBoolean(var54);
            Object[] var56 = new Object[]{EntityType.SILVERFISH, var6};
            ConcurrentIdentitySet var55 = var11;
            var55.aReturningBoolean(var56);
            Object[] var58 = new Object[]{EntityType.PHANTOM, var6};
            ConcurrentIdentitySet var57 = var11;
            var57.aReturningBoolean(var58);
            Object[] var60 = new Object[]{EntityType.VEX, var6};
            ConcurrentIdentitySet var59 = var11;
            var59.aReturningBoolean(var60);
            Object[] var62 = new Object[]{EntityType.VINDICATOR, var6};
            ConcurrentIdentitySet var61 = var11;
            var61.aReturningBoolean(var62);
            Object[] var64 = new Object[]{EntityType.EVOKER, var6};
            ConcurrentIdentitySet var63 = var11;
            var63.aReturningBoolean(var64);
            Object[] var66 = new Object[]{EntityType.PILLAGER, var6};
            ConcurrentIdentitySet var65 = var11;
            var65.aReturningBoolean(var66);
            Object[] var68 = new Object[]{EntityType.RAVAGER, var6};
            ConcurrentIdentitySet var67 = var11;
            var67.aReturningBoolean(var68);
         }

         MultiModeSetting var340 = this.e;
         var10001 = 25827;
         var10002 = 6987759671222700849L ^ var2;
         Object[] var71 = new Object[]{"Ambient", var8};
         MultiModeSetting var70 = var340;
         var270 = var70.aReturningBoolean(var71);
      }

      int var304 = var10;
      boolean var303 = var270;
      boolean var272 = var303;
      boolean var271 = var303;
      if (var304 == 0) {
         boolean var305 = var271;
         if (var305) {
            Object[] var74 = new Object[]{EntityType.BAT, var6};
            ConcurrentIdentitySet var73 = var11;
            var73.aReturningBoolean(var74);
         }

         MultiModeSetting var341 = this.e;
         var10001 = 21486;
         var10002 = 8411749338218642482L ^ var2;
         Object[] var77 = new Object[]{"Friendly", var8};
         MultiModeSetting var76 = var341;
         var272 = var76.aReturningBoolean(var77);
      }

      int var307 = var10;
      boolean var306 = var272;
      boolean var274 = var306;
      boolean var273 = var306;
      if (var307 == 0) {
         boolean var308 = var273;
         if (var308) {
            Object[] var80 = new Object[]{EntityType.COW, var6};
            ConcurrentIdentitySet var79 = var11;
            var79.aReturningBoolean(var80);
            Object[] var82 = new Object[]{EntityType.SHEEP, var6};
            ConcurrentIdentitySet var81 = var11;
            var81.aReturningBoolean(var82);
            Object[] var84 = new Object[]{EntityType.PIG, var6};
            ConcurrentIdentitySet var83 = var11;
            var83.aReturningBoolean(var84);
            Object[] var86 = new Object[]{EntityType.CHICKEN, var6};
            ConcurrentIdentitySet var85 = var11;
            var85.aReturningBoolean(var86);
            Object[] var88 = new Object[]{EntityType.RABBIT, var6};
            ConcurrentIdentitySet var87 = var11;
            var87.aReturningBoolean(var88);
            Object[] var90 = new Object[]{EntityType.OCELOT, var6};
            ConcurrentIdentitySet var89 = var11;
            var89.aReturningBoolean(var90);
            Object[] var92 = new Object[]{EntityType.VILLAGER, var6};
            ConcurrentIdentitySet var91 = var11;
            var91.aReturningBoolean(var92);
            Object[] var94 = new Object[]{EntityType.IRON_GOLEM, var6};
            ConcurrentIdentitySet var93 = var11;
            var93.aReturningBoolean(var94);
            Object[] var96 = new Object[]{EntityType.SNOW_GOLEM, var6};
            ConcurrentIdentitySet var95 = var11;
            var95.aReturningBoolean(var96);
            Object[] var98 = new Object[]{EntityType.MOOSHROOM, var6};
            ConcurrentIdentitySet var97 = var11;
            var97.aReturningBoolean(var98);
            Object[] var100 = new Object[]{EntityType.GOAT, var6};
            ConcurrentIdentitySet var99 = var11;
            var99.aReturningBoolean(var100);
            Object[] var102 = new Object[]{EntityType.PANDA, var6};
            ConcurrentIdentitySet var101 = var11;
            var101.aReturningBoolean(var102);
            Object[] var104 = new Object[]{EntityType.ALLAY, var6};
            ConcurrentIdentitySet var103 = var11;
            var103.aReturningBoolean(var104);
            Object[] var106 = new Object[]{EntityType.SNIFFER, var6};
            ConcurrentIdentitySet var105 = var11;
            var105.aReturningBoolean(var106);
            Object[] var108 = new Object[]{EntityType.ARMADILLO, var6};
            ConcurrentIdentitySet var107 = var11;
            var107.aReturningBoolean(var108);
         }

         MultiModeSetting var342 = this.e;
         var10001 = 20912;
         var10002 = 8640953681007132280L ^ var2;
         Object[] var111 = new Object[]{"Aquatic", var8};
         MultiModeSetting var110 = var342;
         var274 = var110.aReturningBoolean(var111);
      }

      int var310 = var10;
      boolean var309 = var274;
      boolean var276 = var309;
      boolean var275 = var309;
      if (var310 == 0) {
         boolean var311 = var275;
         if (var311) {
            Object[] var114 = new Object[]{EntityType.GUARDIAN, var6};
            ConcurrentIdentitySet var113 = var11;
            var113.aReturningBoolean(var114);
            Object[] var116 = new Object[]{EntityType.ELDER_GUARDIAN, var6};
            ConcurrentIdentitySet var115 = var11;
            var115.aReturningBoolean(var116);
            Object[] var118 = new Object[]{EntityType.DOLPHIN, var6};
            ConcurrentIdentitySet var117 = var11;
            var117.aReturningBoolean(var118);
            Object[] var120 = new Object[]{EntityType.COD, var6};
            ConcurrentIdentitySet var119 = var11;
            var119.aReturningBoolean(var120);
            Object[] var122 = new Object[]{EntityType.SALMON, var6};
            ConcurrentIdentitySet var121 = var11;
            var121.aReturningBoolean(var122);
            Object[] var124 = new Object[]{EntityType.PUFFERFISH, var6};
            ConcurrentIdentitySet var123 = var11;
            var123.aReturningBoolean(var124);
            Object[] var126 = new Object[]{EntityType.TROPICAL_FISH, var6};
            ConcurrentIdentitySet var125 = var11;
            var125.aReturningBoolean(var126);
            Object[] var128 = new Object[]{EntityType.SQUID, var6};
            ConcurrentIdentitySet var127 = var11;
            var127.aReturningBoolean(var128);
            Object[] var130 = new Object[]{EntityType.GLOW_SQUID, var6};
            ConcurrentIdentitySet var129 = var11;
            var129.aReturningBoolean(var130);
            Object[] var132 = new Object[]{EntityType.AXOLOTL, var6};
            ConcurrentIdentitySet var131 = var11;
            var131.aReturningBoolean(var132);
            Object[] var134 = new Object[]{EntityType.TURTLE, var6};
            ConcurrentIdentitySet var133 = var11;
            var133.aReturningBoolean(var134);
            Object[] var136 = new Object[]{EntityType.TADPOLE, var6};
            ConcurrentIdentitySet var135 = var11;
            var135.aReturningBoolean(var136);
         }

         MultiModeSetting var343 = this.e;
         var10001 = 22003;
         var10002 = 164418190089959999L ^ var2;
         Object[] var139 = new Object[]{"Nether", var8};
         MultiModeSetting var138 = var343;
         var276 = var138.aReturningBoolean(var139);
      }

      int var313 = var10;
      boolean var312 = var276;
      boolean var278 = var312;
      boolean var277 = var312;
      if (var313 == 0) {
         boolean var314 = var277;
         if (var314) {
            Object[] var142 = new Object[]{EntityType.BLAZE, var6};
            ConcurrentIdentitySet var141 = var11;
            var141.aReturningBoolean(var142);
            Object[] var144 = new Object[]{EntityType.GHAST, var6};
            ConcurrentIdentitySet var143 = var11;
            var143.aReturningBoolean(var144);
            Object[] var146 = new Object[]{EntityType.MAGMA_CUBE, var6};
            ConcurrentIdentitySet var145 = var11;
            var145.aReturningBoolean(var146);
            Object[] var148 = new Object[]{EntityType.PIGLIN, var6};
            ConcurrentIdentitySet var147 = var11;
            var147.aReturningBoolean(var148);
            Object[] var150 = new Object[]{EntityType.PIGLIN_BRUTE, var6};
            ConcurrentIdentitySet var149 = var11;
            var149.aReturningBoolean(var150);
            Object[] var152 = new Object[]{EntityType.HOGLIN, var6};
            ConcurrentIdentitySet var151 = var11;
            var151.aReturningBoolean(var152);
            Object[] var154 = new Object[]{EntityType.ZOGLIN, var6};
            ConcurrentIdentitySet var153 = var11;
            var153.aReturningBoolean(var154);
            Object[] var156 = new Object[]{EntityType.STRIDER, var6};
            ConcurrentIdentitySet var155 = var11;
            var155.aReturningBoolean(var156);
            Object[] var158 = new Object[]{EntityType.WITHER_SKELETON, var6};
            ConcurrentIdentitySet var157 = var11;
            var157.aReturningBoolean(var158);
         }

         MultiModeSetting var344 = this.e;
         var10001 = 6398;
         var10002 = 4224630703505110824L ^ var2;
         Object[] var161 = new Object[]{"End", var8};
         MultiModeSetting var160 = var344;
         var278 = var160.aReturningBoolean(var161);
      }

      int var316 = var10;
      boolean var315 = var278;
      boolean var280 = var315;
      boolean var279 = var315;
      if (var316 == 0) {
         boolean var317 = var279;
         if (var317) {
            Object[] var164 = new Object[]{EntityType.ENDERMAN, var6};
            ConcurrentIdentitySet var163 = var11;
            var163.aReturningBoolean(var164);
            Object[] var166 = new Object[]{EntityType.ENDERMITE, var6};
            ConcurrentIdentitySet var165 = var11;
            var165.aReturningBoolean(var166);
            Object[] var168 = new Object[]{EntityType.SHULKER, var6};
            ConcurrentIdentitySet var167 = var11;
            var167.aReturningBoolean(var168);
         }

         MultiModeSetting var345 = this.e;
         var10001 = 10178;
         var10002 = 1044949389946996768L ^ var2;
         Object[] var171 = new Object[]{"Bosses", var8};
         MultiModeSetting var170 = var345;
         var280 = var170.aReturningBoolean(var171);
      }

      int var319 = var10;
      boolean var318 = var280;
      boolean var282 = var318;
      boolean var281 = var318;
      if (var319 == 0) {
         boolean var320 = var281;
         if (var320) {
            Object[] var174 = new Object[]{EntityType.WITHER, var6};
            ConcurrentIdentitySet var173 = var11;
            var173.aReturningBoolean(var174);
            Object[] var176 = new Object[]{EntityType.ENDER_DRAGON, var6};
            ConcurrentIdentitySet var175 = var11;
            var175.aReturningBoolean(var176);
            Object[] var178 = new Object[]{EntityType.WARDEN, var6};
            ConcurrentIdentitySet var177 = var11;
            var177.aReturningBoolean(var178);
         }

         MultiModeSetting var346 = this.e;
         var10001 = 11954;
         var10002 = 4245042498475934077L ^ var2;
         Object[] var181 = new Object[]{"Tameable", var8};
         MultiModeSetting var180 = var346;
         var282 = var180.aReturningBoolean(var181);
      }

      int var322 = var10;
      boolean var321 = var282;
      boolean var284 = var321;
      boolean var283 = var321;
      if (var322 == 0) {
         boolean var323 = var283;
         if (var323) {
            Object[] var184 = new Object[]{EntityType.WOLF, var6};
            ConcurrentIdentitySet var183 = var11;
            var183.aReturningBoolean(var184);
            Object[] var186 = new Object[]{EntityType.CAT, var6};
            ConcurrentIdentitySet var185 = var11;
            var185.aReturningBoolean(var186);
            Object[] var188 = new Object[]{EntityType.PARROT, var6};
            ConcurrentIdentitySet var187 = var11;
            var187.aReturningBoolean(var188);
            Object[] var190 = new Object[]{EntityType.HORSE, var6};
            ConcurrentIdentitySet var189 = var11;
            var189.aReturningBoolean(var190);
            Object[] var192 = new Object[]{EntityType.DONKEY, var6};
            ConcurrentIdentitySet var191 = var11;
            var191.aReturningBoolean(var192);
            Object[] var194 = new Object[]{EntityType.MULE, var6};
            ConcurrentIdentitySet var193 = var11;
            var193.aReturningBoolean(var194);
            Object[] var196 = new Object[]{EntityType.LLAMA, var6};
            ConcurrentIdentitySet var195 = var11;
            var195.aReturningBoolean(var196);
            Object[] var198 = new Object[]{EntityType.FOX, var6};
            ConcurrentIdentitySet var197 = var11;
            var197.aReturningBoolean(var198);
            Object[] var200 = new Object[]{EntityType.BEE, var6};
            ConcurrentIdentitySet var199 = var11;
            var199.aReturningBoolean(var200);
            Object[] var202 = new Object[]{EntityType.POLAR_BEAR, var6};
            ConcurrentIdentitySet var201 = var11;
            var201.aReturningBoolean(var202);
            Object[] var204 = new Object[]{EntityType.FROG, var6};
            ConcurrentIdentitySet var203 = var11;
            var203.aReturningBoolean(var204);
            Object[] var206 = new Object[]{EntityType.CAMEL, var6};
            ConcurrentIdentitySet var205 = var11;
            var205.aReturningBoolean(var206);
         }

         MultiModeSetting var347 = this.e;
         var10001 = 2274;
         var10002 = 4930230803538110241L ^ var2;
         Object[] var209 = new Object[]{"Projectiles", var8};
         MultiModeSetting var208 = var347;
         var284 = var208.aReturningBoolean(var209);
      }

      int var325 = var10;
      boolean var324 = var284;
      boolean var286 = var324;
      boolean var285 = var324;
      if (var325 == 0) {
         boolean var326 = var285;
         if (var326) {
            Object[] var212 = new Object[]{EntityType.ARROW, var6};
            ConcurrentIdentitySet var211 = var11;
            var211.aReturningBoolean(var212);
            Object[] var214 = new Object[]{EntityType.SPECTRAL_ARROW, var6};
            ConcurrentIdentitySet var213 = var11;
            var213.aReturningBoolean(var214);
            Object[] var216 = new Object[]{EntityType.TRIDENT, var6};
            ConcurrentIdentitySet var215 = var11;
            var215.aReturningBoolean(var216);
            Object[] var218 = new Object[]{EntityType.FIREBALL, var6};
            ConcurrentIdentitySet var217 = var11;
            var217.aReturningBoolean(var218);
            Object[] var220 = new Object[]{EntityType.SMALL_FIREBALL, var6};
            ConcurrentIdentitySet var219 = var11;
            var219.aReturningBoolean(var220);
            Object[] var222 = new Object[]{EntityType.DRAGON_FIREBALL, var6};
            ConcurrentIdentitySet var221 = var11;
            var221.aReturningBoolean(var222);
            Object[] var224 = new Object[]{EntityType.WITHER_SKULL, var6};
            ConcurrentIdentitySet var223 = var11;
            var223.aReturningBoolean(var224);
            Object[] var226 = new Object[]{EntityType.SNOWBALL, var6};
            ConcurrentIdentitySet var225 = var11;
            var225.aReturningBoolean(var226);
            Object[] var228 = new Object[]{EntityType.EGG, var6};
            ConcurrentIdentitySet var227 = var11;
            var227.aReturningBoolean(var228);
            Object[] var230 = new Object[]{EntityType.ENDER_PEARL, var6};
            ConcurrentIdentitySet var229 = var11;
            var229.aReturningBoolean(var230);
            Object[] var232 = new Object[]{EntityType.EXPERIENCE_BOTTLE, var6};
            ConcurrentIdentitySet var231 = var11;
            var231.aReturningBoolean(var232);
         }

         MultiModeSetting var348 = this.e;
         var10001 = 16967;
         var10002 = 905461822185221528L ^ var2;
         Object[] var235 = new Object[]{"Vehicles", var8};
         MultiModeSetting var234 = var348;
         var286 = var234.aReturningBoolean(var235);
      }

      int var328 = var10;
      boolean var327 = var286;
      boolean var288 = var327;
      boolean var287 = var327;
      if (var328 == 0) {
         boolean var329 = var287;
         if (var329) {
            Object[] var238 = new Object[]{EntityType.MINECART, var6};
            ConcurrentIdentitySet var237 = var11;
            var237.aReturningBoolean(var238);
            Object[] var240 = new Object[]{EntityType.CHEST_MINECART, var6};
            ConcurrentIdentitySet var239 = var11;
            var239.aReturningBoolean(var240);
            Object[] var242 = new Object[]{EntityType.FURNACE_MINECART, var6};
            ConcurrentIdentitySet var241 = var11;
            var241.aReturningBoolean(var242);
            Object[] var244 = new Object[]{EntityType.TNT_MINECART, var6};
            ConcurrentIdentitySet var243 = var11;
            var243.aReturningBoolean(var244);
            Object[] var246 = new Object[]{EntityType.HOPPER_MINECART, var6};
            ConcurrentIdentitySet var245 = var11;
            var245.aReturningBoolean(var246);
            Object[] var248 = new Object[]{EntityType.SPAWNER_MINECART, var6};
            ConcurrentIdentitySet var247 = var11;
            var247.aReturningBoolean(var248);
         }

         MultiModeSetting var349 = this.e;
         var10001 = 27330;
         var10002 = 3901383823593211162L ^ var2;
         Object[] var251 = new Object[]{"Decorations", var8};
         MultiModeSetting var250 = var349;
         var288 = var250.aReturningBoolean(var251);
      }

      int var331 = var10;
      boolean var330 = var288;
      boolean var289 = var330;
      if (var331 == 0) {
         boolean var332 = var289;
         if (var332) {
            Object[] var254 = new Object[]{EntityType.ITEM_FRAME, var6};
            ConcurrentIdentitySet var253 = var11;
            var253.aReturningBoolean(var254);
            Object[] var256 = new Object[]{EntityType.GLOW_ITEM_FRAME, var6};
            ConcurrentIdentitySet var255 = var11;
            var255.aReturningBoolean(var256);
            Object[] var258 = new Object[]{EntityType.ARMOR_STAND, var6};
            ConcurrentIdentitySet var257 = var11;
            var257.aReturningBoolean(var258);
            Object[] var260 = new Object[]{EntityType.PAINTING, var6};
            ConcurrentIdentitySet var259 = var11;
            boolean var333 = var259.aReturningBoolean(var260);
         }
      }

      Map var262 = EntityModelManager.c;
      var262.clear();
      EntityModelManager.d = var11;
   }

   private void lambda$onEnable$9(MeshBufferManager var1, RenderContext var2) {
      int var5 = Event.cReturningInt();
      ESP var7 = this;
      boolean var15 = var7.aReturningBoolean();
      if (var15) {
         Object[] var9 = new Object[0];
         FramebufferEffect var6 = EntityModelManager.aReturningc_(var9);
         int var17 = var5;
         FramebufferEffect var16 = var6;
         FramebufferEffect var14 = var16;
         FramebufferEffect var13 = var16;
         if (var17 != 0) {
            FramebufferEffect var18 = var13;
            if (var18 == null) {
               return;
            }

            var14 = var6;
         }

         Object[] var12 = new Object[]{this.t};
         FramebufferEffect var11 = var14;
         var11.dReturningVoid(var12);
      }
   }

   private boolean lambda$new$8(Float var1) {
      ModeSetting var4 = this.d;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Aura";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$7(Float var1) {
      ModeSetting var4 = this.d;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Aura";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$6(Float var1) {
      ModeSetting var4 = this.d;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Aura";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$5(Float var1) {
      ModeSetting var4 = this.d;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Chams";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$4(Float var1) {
      ModeSetting var4 = this.d;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Chams";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$3(Boolean var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.d;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Chams";
      String var6 = var10000;
      byte var15 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var12 = var4;
      byte var11 = var15;
      byte var9 = var11;
      byte var8 = var11;
      if (var12 == 0) {
         byte var13 = var8;
         if (var13 != 0) {
            return false;
         }

         var9 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$2(Integer var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.d;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Chams";
      String var6 = var10000;
      byte var15 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var12 = var4;
      byte var11 = var15;
      byte var9 = var11;
      byte var8 = var11;
      if (var12 == 0) {
         byte var13 = var8;
         if (var13 != 0) {
            return false;
         }

         var9 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$1(Integer var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.d;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Chams";
      String var6 = var10000;
      byte var15 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var12 = var4;
      byte var11 = var15;
      byte var9 = var11;
      byte var8 = var11;
      if (var12 == 0) {
         byte var13 = var8;
         if (var13 != 0) {
            return false;
         }

         var9 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$0(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.f;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 != 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(81641942594648L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[34];
      String var11 = "ìAðÖ\u0099\u0082\u0084oßÀ]*\u0007[¡×u\r\u0093ÅSeÙ\u0017ÿ¥©\u0097r[I- ]®¥/dÂ\u000f\u009b\u0016¯.n\u009b\u0094\féÃ\"ê¿\u008düðê\b6qSe\u00826\u0004\u0010¢$á\u000ewØ\bM'\u0088wæ\u000eÛ\u0096h\u0010½À\u0000\u0000Î£@!\u001aÑX~\u001dä/û\u0010ÈXÿ@o\u0096Bß?ÆæW0ïØ<\u0010\u0011l¸ö¥l»\u0094Ëvÿj¡\u0018öÜ\u0018Íæýdß²Vt¿BO¸\n\u008ekÝoiÍWá\u001bµÇ\u0010:\u0010ê\u009bð#|êbDª\u0093&aÈ\b\u0010¢Ý¥Ð=\u008fú\u001bÌv\u000eIÑYY\\ ù|\u009d\"\ffcØå÷¹\u0001\u0089èÞõ\fÆoz\u0087´\"u¢ê\u001a\u008eÉv8\u0012\u0010\u0084²ð\u0019Í¯fa3]\u009fçÞ¿\u0005N\u0010\u0095WY«o&oõ«â«n\u0084ËÃk\u00181p.\u0084\u0097Á#ÚfÁL(ä\u001aøó5°|F\u0086\rqN Ôe¹ô\u0085m\u0004¥¤nËÅ¶S\u000f-®¸\u00adàß\u0002±\t\u0080Wì\u000f\u009eé\u0005l\u0010M\n§Í\u000b\rï££ØNyåÂßZ\u0010\u000bd+ÆÓá¤/Ö=ë{mù\u0096ï\u0010y\u009aí£0Óû¶y²\u0093u\u0090ûìÌ\u00108\u009arZ)f\u0016(Mû\r©¥ôcL\u0010\u0080B\u0013'\u0097BRÓ>B\u0091ÙÒU\u0094@\u0010â\u009fÄ3'\u0005\u00adÓ Á¿4(.\u009e$\u0010îöü7)\u001e\u00ad\u001e\u0084ÃÇQ7¬41\u0010Þ\té§U6ÞZ\u0095t«OÅ9eÌ\u0010\u001e_\u001b \u007fwÉ\fî\u0084G`®ç^-\u0010É\u0093\u0005æx\u0093åñ\u0017lìHNT÷Ù µ(p G·S\u008cÑ0ï¬©2ê%Ï_I\t·Ý®2\u001c\u009fh63ìÏH\u0010¹\u0018\u008anò\u007fÏÚ/\u0095r\u008ay\u0015 é )×\u001då;\u0085\u0002ð\u0004SAêÎ\u0094Ô'3|©ºù{\u009c#ý\u0086¡Ùµûï\u001e\u0010-Oð\u0080PÊ\n-sB9\u0099z\u0086Öü\u0010\u001b*)¦1ùÊ\u0012GÜ\u007f\u009b)Ríä Ö=Sx\u0007Í¢|!ÏÒg{\u009büÙ©¥ìù0\u0019§¨ò³\u0089\u008b\u008e \u001b\u001a \u008béÓE\u0005ÞM7ß\fc¼ì÷.0\u009b\u0010Mr®<æ Ü(\u0005ýû¦´\u0016\u0010ä\u0012M\u0006\u0007\u0090\b°\u0004ß\u000bå·¼}p";
      int var13 = "ìAðÖ\u0099\u0082\u0084oßÀ]*\u0007[¡×u\r\u0093ÅSeÙ\u0017ÿ¥©\u0097r[I- ]®¥/dÂ\u000f\u009b\u0016¯.n\u009b\u0094\féÃ\"ê¿\u008düðê\b6qSe\u00826\u0004\u0010¢$á\u000ewØ\bM'\u0088wæ\u000eÛ\u0096h\u0010½À\u0000\u0000Î£@!\u001aÑX~\u001dä/û\u0010ÈXÿ@o\u0096Bß?ÆæW0ïØ<\u0010\u0011l¸ö¥l»\u0094Ëvÿj¡\u0018öÜ\u0018Íæýdß²Vt¿BO¸\n\u008ekÝoiÍWá\u001bµÇ\u0010:\u0010ê\u009bð#|êbDª\u0093&aÈ\b\u0010¢Ý¥Ð=\u008fú\u001bÌv\u000eIÑYY\\ ù|\u009d\"\ffcØå÷¹\u0001\u0089èÞõ\fÆoz\u0087´\"u¢ê\u001a\u008eÉv8\u0012\u0010\u0084²ð\u0019Í¯fa3]\u009fçÞ¿\u0005N\u0010\u0095WY«o&oõ«â«n\u0084ËÃk\u00181p.\u0084\u0097Á#ÚfÁL(ä\u001aøó5°|F\u0086\rqN Ôe¹ô\u0085m\u0004¥¤nËÅ¶S\u000f-®¸\u00adàß\u0002±\t\u0080Wì\u000f\u009eé\u0005l\u0010M\n§Í\u000b\rï££ØNyåÂßZ\u0010\u000bd+ÆÓá¤/Ö=ë{mù\u0096ï\u0010y\u009aí£0Óû¶y²\u0093u\u0090ûìÌ\u00108\u009arZ)f\u0016(Mû\r©¥ôcL\u0010\u0080B\u0013'\u0097BRÓ>B\u0091ÙÒU\u0094@\u0010â\u009fÄ3'\u0005\u00adÓ Á¿4(.\u009e$\u0010îöü7)\u001e\u00ad\u001e\u0084ÃÇQ7¬41\u0010Þ\té§U6ÞZ\u0095t«OÅ9eÌ\u0010\u001e_\u001b \u007fwÉ\fî\u0084G`®ç^-\u0010É\u0093\u0005æx\u0093åñ\u0017lìHNT÷Ù µ(p G·S\u008cÑ0ï¬©2ê%Ï_I\t·Ý®2\u001c\u009fh63ìÏH\u0010¹\u0018\u008anò\u007fÏÚ/\u0095r\u008ay\u0015 é )×\u001då;\u0085\u0002ð\u0004SAêÎ\u0094Ô'3|©ºù{\u009c#ý\u0086¡Ùµûï\u001e\u0010-Oð\u0080PÊ\n-sB9\u0099z\u0086Öü\u0010\u001b*)¦1ùÊ\u0012GÜ\u007f\u009b)Ríä Ö=Sx\u0007Í¢|!ÏÒg{\u009büÙ©¥ìù0\u0019§¨ò³\u0089\u008b\u008e \u001b\u001a \u008béÓE\u0005ÞM7ß\fc¼ì÷.0\u009b\u0010Mr®<æ Ü(\u0005ýû¦´\u0016\u0010ä\u0012M\u0006\u0007\u0090\b°\u0004ß\u000bå·¼}p"
         .length();
      char var10 = ' ';
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         // while (true) {
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     w = var14;
                     x = new String[34];
                     c = "Aura";
                     b = "Chams";
                     a = "Normal";
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(81641942594648L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = -7636774395443567297L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)150L,
                           (byte)38404L,
                           (byte)9831610L,
                           (byte)2516892198L,
                           (byte)644324402705L,
                           (byte)164947047092681L,
                           (byte)42226444055726501L,
                           (byte)-7636774395443567297L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     z = var31;
                     u = new ThreadLocal();
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "I\u009cø×\u00150!Ò\u0096¨å4Y\u0092\u000e5 Õê#½¦\u0097\u000eGó²oÃ2\u0086×\u007fEå'\u0088\u0092f\u0091·O\u0088S3Åp°(";
                  var13 = "I\u009cø×\u00150!Ò\u0096¨å4Y\u0092\u000e5 Õê#½¦\u0097\u000eGó²oÃ2\u0086×\u007fEå'\u0088\u0092f\u0091·O\u0088S3Åp°(".length();
                  var10 = 16;
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29979;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ez", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ez_C0268",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ez" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = B[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = A[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 3;
            yield var15;
         }
         case 1 -> {
            byte var16 = 49;
            yield var16;
         }
         case 2 -> {
            byte var17 = 40;
            yield var17;
         }
         case 3 -> {
            byte var18 = 36;
            yield var18;
         }
         case 4 -> {
            byte var19 = 46;
            yield var19;
         }
         case 5 -> {
            byte var20 = 29;
            yield var20;
         }
         case 6 -> {
            byte var21 = 41;
            yield var21;
         }
         case 7 -> {
            byte var22 = 59;
            yield var22;
         }
         case 8 -> {
            byte var23 = 30;
            yield var23;
         }
         case 9 -> {
            byte var24 = 24;
            yield var24;
         }
         case 10 -> {
            byte var25 = 58;
            yield var25;
         }
         case 11 -> {
            byte var26 = 51;
            yield var26;
         }
         case 12 -> {
            byte var27 = 5;
            yield var27;
         }
         case 13 -> {
            byte var28 = 61;
            yield var28;
         }
         case 14 -> {
            byte var29 = 44;
            yield var29;
         }
         case 15 -> {
            byte var30 = 14;
            yield var30;
         }
         case 16 -> {
            byte var31 = 57;
            yield var31;
         }
         case 17 -> {
            byte var32 = 21;
            yield var32;
         }
         case 18 -> {
            byte var33 = 12;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 0;
            yield var36;
         }
         case 22 -> {
            byte var37 = 19;
            yield var37;
         }
         case 23 -> {
            byte var38 = 26;
            yield var38;
         }
         case 24 -> {
            byte var39 = 25;
            yield var39;
         }
         case 25 -> {
            byte var40 = 55;
            yield var40;
         }
         case 26 -> {
            byte var41 = 27;
            yield var41;
         }
         case 27 -> {
            byte var42 = 16;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 9;
            yield var44;
         }
         case 30 -> {
            byte var45 = 6;
            yield var45;
         }
         case 31 -> {
            byte var46 = 11;
            yield var46;
         }
         case 32 -> {
            byte var47 = 1;
            yield var47;
         }
         case 33 -> {
            byte var48 = 52;
            yield var48;
         }
         case 34 -> {
            byte var49 = 4;
            yield var49;
         }
         case 35 -> {
            byte var50 = 56;
            yield var50;
         }
         case 36 -> {
            byte var51 = 34;
            yield var51;
         }
         case 37 -> {
            byte var52 = 20;
            yield var52;
         }
         case 38 -> {
            byte var53 = 31;
            yield var53;
         }
         case 39 -> {
            byte var54 = 54;
            yield var54;
         }
         case 40 -> {
            byte var55 = 23;
            yield var55;
         }
         case 41 -> {
            byte var56 = 60;
            yield var56;
         }
         case 42 -> {
            byte var57 = 53;
            yield var57;
         }
         case 43 -> {
            byte var58 = 7;
            yield var58;
         }
         case 44 -> {
            byte var59 = 43;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 33;
            yield var61;
         }
         case 47 -> {
            byte var62 = 22;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 17;
            yield var64;
         }
         case 50 -> {
            byte var65 = 37;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 28;
            yield var67;
         }
         case 53 -> {
            byte var68 = 35;
            yield var68;
         }
         case 54 -> {
            byte var69 = 8;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 50;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 39;
            yield var73;
         }
         case 59 -> {
            byte var74 = 62;
            yield var74;
         }
         case 60 -> {
            byte var75 = 63;
            yield var75;
         }
         case 61 -> {
            byte var76 = 13;
            yield var76;
         }
         case 62 -> {
            byte var77 = 42;
            yield var77;
         }
         default -> 48;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            B[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      A[0] = "ibP`M\u0005bmA/0\u001dqjHf";
      A[1] = "[\u0011b\u001c0xP\u001esSQv[\u0015w\t";
      A[2] = boolean.class;
      B[2] = "java/lang/Boolean";
      A[3] = "cUUb9,uUP8*;b\u001eS>&/sYD)m8A";
      A[4] = "D\u0003g\"\u0014PR\u0003bx\u0007GEHa~\u000bST\u000fvi@EZ";
      A[5] = "1CEleV:LT#\u0006[/A[H3Y>RGd$T";
      A[6] = "CZv\u0015\\\u0015CZaIP\u001aY\u0011aWP\u000f^`3\t\bE";
      A[7] = ",Y\n?\u001ag2Q\u0010pys6";
      A[8] = void.class;
      B[8] = "java/lang/Void";
      A[9] = "\u001bC5r6\u0015\rC0(%\u0002\u001a\b3.)\u0016\u000bO$9b\u0006(";
      A[10] = "?=\u0001od\u0014J\u001d\n`u[+\u0013\u0001kq\u0001_";
      A[11] = "t~$|etb~!&vcu5\" zwdr571eU";
      A[12] = int.class;
      B[12] = "java/lang/Integer";
      A[13] = "\u0014\u0001`>e\u001d\u0002\u0001edv\n\u0015Jfbz\u001e\u0004\rqu1\t>";
      A[14] = "Hd'\u0012\u001e\b=D,\u001d\u000fG\\J'\u0016\u000b\u001d(";
      A[15] = "=0q\nsW+0tP`@<{wVlT-<`A'F\u001d";
      A[16] = "Nem1G\u0005;Ef>VJZKm5R\u0010.";
      A[17] = "\f\ty\u00160\u007f\u001a\t|L#h\rB\u007fJ/|\u001c\u0005h]dl7";
      A[18] = "j:\f*rx\u001f\u001a\u0007%c7~\u0014\f.gm\n";
      A[19] = "&\t\u001d;\u0015z0\t\u0018a\u0006m'B\u001bg\ny6\u0005\fpAn\u0013";
      A[20] = "\"<oPy\u0004)3~\u001f\u0015\u0007'1|P9";
      A[21] = "P[/\u0001\"\u0000%{$\u000e3ODu/\u00057\u00150";
      A[22] = ")J=\u001d\u0004S?J8G\u0017D(\u0001;A\u001bP9F,VPN";
      A[23] = "\u001e\u000bl8B\u001a\u0012\u001cquI\u0018^\bytV\u0012\u0013@yfMU\u0015\u0018}xPU5\u0018}xP";
      A[24] = "p}F\u0016?L\u0005]M\u0019.\u0003dSF\u0012*Y\u0010";
      A[25] = "h\u0007\f\u0000\u0013\u000b\u001d'\u0007\u000f\u0002D|)\f\u0004\u0006\u001e\b";
      A[26] = "`Q%\b%M~Y?GJJxQ*\u001a";
      A[27] = "\u0011_";
      A[28] = "\u0006]";
      A[29] = "\u000f_";
      A[30] = "1\u001b";
      A[31] = "h1";
      A[32] = "g;gUWrl4v\u001a4\u007fy2";
      A[33] = "cR\u0018+\u0001[uR\u001dq\u0012Lb\u0019\u001ew\u001eXs^\t`UN4";
      A[34] = "\f0&)OBy\u0010-&^\r\u0018\u001e&-ZWl";
      A[35] = "X\u001d\u001cl\u00064N\u001d\u00196\u0015#YV\u001a0\u00197H\u0011\r'R u";
      A[36] = "Y\u0016GEtgO\u0016B\u001fgpX]A\u0019kdI\u001aV\u000e pD";
      A[37] = float.class;
      B[37] = "java/lang/Float";
      A[38] = "\u00023CbH\u0005\t<R-/\u0007\u001c7Rf\u0014";
      A[39] = "I;\u001eD\u001f,_;\u001b\u001e\f;Hp\u0018\u0018\u0000/Y7\u000f\u000fK?j";
      A[40] = "adYe\"J\u0014DRj3\u0005uJYa7_\u0001";
      A[41] = "xT^>HYeA\u0006\u001c\tT}G";
      A[42] = "|\rU$\b\tw\u0002Dk`\ty\rW";
      A[43] = "]<~K'GK<{\u00114P\\wx\u00178DM0o\u0000sTU0m\u000b)\u0019i+m\u0016)^^<";
      A[44] = "UK\u0014%e\rZ\n\u000evYTYGd);QH]\r'2AS7T{9IZ^Zr)R0\u0007\u0006y![Y\t\u000fi:1";
      A[45] = "|*NUf2wt\u000bA\u001c=G\u007fUZ-$9\"V\\vT|&Q\rl*!%WV\u001c";
      A[46] = "\\]T\u000fi%\u0002\\D\u0019Xz\u0001SB\u000e\u000f*Y\u0002\u001bbdw\u0012S\u0017S:v\u0002E";
      A[47] = "sMu\u0018\u0014ex\u00130\fnjHYqK\u0004|2\u0012<\u0010\u0004\u0003&Jg@\r:sQr\u001bn";
      A[48] = "\"H\u0010Nzl|I\u0000XK3\u007fF\u0006O\u001cc&\u001aY#w>lFS\u0012)?|P";
      A[49] = "*j\u0005\f\u0003'tk\u0015\u001a2xwd\u0013\re(.6La\u000euddFPPttr";
      A[50] = ">\u001b!\u0014m~`\u001a1\u0002\\!c\u00157\u0015\u000bq;Dky`,p\u0015bH>-`\u0003";
      A[51] = "'\u0011%)\u0004/y\u00105?5pz\u001f3(b \"HmD\t}i\u001ffuW|y\t";
      A[52] = "U*8SV%\u000b+(Egz\b$.R0.Yrs\u0003g(\n;'\u000fVv\u000b+1";
      A[53] = "+b\u0015r\u001ekuc\u0005d/4vl\u0003sxa'9V\"/fts\n.\u001e8uc\u001c";
      A[54] = "VN4ot+\bO$yEt\u000b@\"n\u0012 R\u0016z<E&\t_+3tx\bO=";
      A[55] = "Er\t\u00163Q\u001bs\u0019\u0000\u0002\u000e\u0018|\u001f\u0017U^A!B{>\u0003\u000b|JJ`\u0002\u001bj";
      A[56] = "\r$I'5>S%Y1\u0004aP*_&S1\tx\u000bJ8lC*\n{fmS<";
      A[57] = "\rv\u000fYTD\re_J+\\wg\u001d\u000eAJ\r,PUA5\u0011p\u0000RUI\u000b\"\u0001K+";
      A[58] = "\fHKHtNRI[^E\u0011QF]I\u0012A\t\u0017\u0002%y\u001cBF\b\u0014'\u001dRP";
      A[59] = "Tv(9/y\nw8/\u001e&\tx>8IvQ)dT\"+\u001axke|*\nn";
      A[60] = "\u0005fYH\u0003Y[gI^2\u0006XhOIeV\u0000<\u0013%\u000e\u000bKh\u001a\u0014P\n[~";
      A[61] = "K\u0000L%\u001d_\u0015\u0001\\3,\u0000\u0016\u000eZ${PO]\u0004H\u0010\r\u0005\u000e\u000fyN\f\u0015\u0018";
      A[62] = "'K4>ANyJ$(p\u0011zE\"?'A\"\u0011wSL\u001ciEwb\u0012\u001dyS";
      A[63] = "\u00037(6+j]68 \u001a5^9>7Mg\u0005j`a\u001ag\\&7j+9]6!";
      A[64] = "\r5\u001eLW_S4\u000eZf\u0000P;\bM1P\boS!Z\rC;]\u0010\u0004\fS-";
      A[65] = "5+5BC,k*%Trsh%#C%#0tx/N~{%v\u001e\u0010\u007fk3";
      A[66] = "yq~']w+6\u007fF\u000fvofy=b6,qa<\u001et|jfF[iy3`=Rht`\u001d";
      A[67] = "\u000f\fgaz3Q\rwwKlR\u0002q`\u001c<\nS)\fwaA\u0002$=)`Q\u0014";
      A[68] = "&E\u0014\u001aA_xD\u0004\fp\u0000{K\u0002\u001b'P#\u001dYwL\rhKWF\u0012\fx]";
      A[69] = "\u001aJ\u001c;7\u0013DK\f-\u0006LGD\n:Q\u001c\u001e\u0016PV:ATD_gd@DR";
      A[70] = "\u0005\u001bc[/\u0000\u0010Hc\u001fU\u0019}\u0012d\u00074O\u0005@#\u0006U@\u001f\u0019b\u000e<N\u0016\tyd-\u0012\u0004F`\u00148A\u0004\u0002\u001a";
      A[71] = "\u001eM0<\u0013>@L *\"aCC&=u6\u001d\u001f~j\"3A\\/`\u0013m@L9";
      A[72] = "c\u0003\u0002.\u001a8=\u0002\u00128+g>\r\u0014/|7g\\OC\u0017j-\rArIk=\u001b";
      A[73] = "\u001c\\!h\u001e\u0011B]1~/NAR7ix\u001e\u0018\u0003i\u0005\u0013CRRb4MBBD";
      A[74] = "W#i.\u001a\u0004\u000erh6*\u0017Od}5QzRbf;I\u0016\u0007bp`*\u001eMk~2FKM}%Q\u0013\u001c]%i*\u001a\u001dPv\u0014";
      A[75] = "\u000e\u0017|[;{WF}C\u000bn\bUpce\u0005\u000bVsNhi^Ve\u0015\u000b5\rMyNb;\u0004]b$o~\u001dGbH:~\u000b\u001c\u0001";
      A[76] = "\u000ew\b:\u007fTPv\u0018,N\u000bSy\u001e;\u0019[\n(DWr\u0006@yKf,\u0007Po";
      A[77] = "!-6-z\u0015hl(1C\u0011\u0010w#!)\u001b|\"#7rx";
      A[78] = "ju\u000f%Og4t\u001f3~87{\u0019$)ho/MHB5${Ly\u001c44m";
      A[79] = "^j98\u0001\u001d\u0000k).0B\u0003d/9g\u0012[3zU\fO\u0010dzdRN\u0000r";
      A[80] = "x\u0016ocz>&\u0017\u007fuKa%\u0018yb\u001c3{J 2K3'\u0007p?zm&\u0017f";
      A[81] = "\u001f/`8fNA.p.W\u0011B!v9\u0000E\u0018v+iWC@>\u007fdf\u001dA.i";
      A[82] = "5zR()|k{B>\u0018#htD)Os1%\u0011E$.{t\u0011tz/kb";
      A[83] = "%o\u0013\u0015e\u0012{n\u0003\u0003TMxa\u0005\u0014\u0003\u001d!=Yxh@kaPI6A{w";
      A[84] = "\u000fW\u0000\u0001Y}\nM\u000b_:*fS\u0019\u0001P<\u001c\u0018TZPC\r\u0010X\u0000Q*WR\u0016I:";
      A[85] = "\u000ft|\u001c\u0003|M$,\u0018\u007fu?z$G\u0007tVt-W\u001c\u001e";
      A[86] = ";r\u0015g\u0004\u0004:7Hb:^1(\u0015sSR\b&\u0015cW4o)\u001a\"GOf(\u0017q:";
      A[87] = "\u0014z\u001c\u001c\u0012\u0001J{\f\n#^It\n\u001dt\f\u0010 WO#\fKk\u0003@\u0012RJ{\u0015";
      A[88] = "\u0018YBag\\FXRwV\u0003EWT`\u0001W\u0019\u0005\r5VQGH]=g\u000fFXK";
      A[89] = "d5Q.u/:4A8Dp9;G/\u0013 `g\u0013Cx}*;\u0012r&|:-";
      A[90] = "i\"j+M\u000b7#z=|T4,|*+\u0004ly%F@Y',)w\u001eX7:";
      A[91] = "\r\u007f\u0006~\u0011wS~\u0016h (Pq\u0010\u007fwx\t-E\u0013\u001c%CqE\"B$Sg";
      A[92] = "',\u0015Usly-\u0005CB3z\"\u0003T\u0015c\"u\\8~>i\"V\t ?y4";
      A[93] = "\b\u000ev9pe\u0007OljL<\f\u0014\u00065.9\u0015\u0018o;')\u000er6g,!\u0007\u001b8n<:mBde43\u0004Lmu/Y";
      A[94] = "8<\u0001^\u0001%f=\u0011H0ze2\u0017_g.>eC\n0(g-\u001e\u0002\u0001vf=\b";
      A[95] = "O\u0013R Z\u001d\u0011\u0012B6kB\u0012\u001dD!<\u0012KM\u0011MWO\u0001\u001d\u0011|\tN\u0011\u000b";
      A[96] = "d!4k2\u0002: $}\u0003]9/\"jT\r`}z\u0006?P*/w7aQ:9";
      A[97] = "O3\u0016\u0015\tr\u00112\u0006\u00038-\u0012=\u0000\u0014o}Jk]x\u0004 \u0001=UIZ!\u0011+";
      A[98] = ";\r\u001cc\u0000Le\f\fu1\u0013f\u0003\nbfC>WR\u000e\r\u001eu\u0003_?S\u001fe\u0015";
      A[99] = "R\u001dU1\u0014\f\f\u001cE'%S\u000f\u0013C0r\u0003WG\u001e\\\u0019^\u001c\u0013\u0016mG_\f\u0005";
      A[100] = "/B\u000b\u0011\u00070qC\u001b\u00076orL\u001d\u0010a?*\u0018B|\nbaLHMTcqZ";
      A[101] = "bZSAxu<[CWI*?TE@\u001ezg\u0003\u0019,u',T\u0010\u001d+&<B";
      A[102] = "\u000f\u001b<JZ\u001bUYr\u00031\u001edX}K[\r\u001e\u00130\u0010[rYG}NA\u001e\u001cS|\u000b1";
      A[103] = "KX\u001a\u0002\u0013nO_RCz~SX\n\u0007$ySB\u000e{\u0002l\u0007\u0003S\u0006\u0004m\tOc";
      A[104] = ".c[\u0016\u001fBiqPCrCv~\u0002\u0006r\u0015wnT\f\u001ePco\u0011|";
      A[105] = "\u00014g;U\u001b_5w-dD\\:q:3\u0014\u0005g)VXIO:$g\u0006H_,";
      A[106] = "Yr[@4f\u0007sKV\u00059\u0004|MARi\\*\u0014-94\u0017|\u0018\u001cg5\u0007j";
      A[107] = "z09Uh\u0019$1)CYF'>/T\u000e\u0016\u007fiu8eK4>z\t;J$(";
      A[108] = "\r;ZW\u0000eS:JA1:P5LVfj\bb\u0018:\r7C5\u0019\u000bS6S#";
      A[109] = "OP\u0003T27\u0011Q\u0013B\u0003h\u0012^\u0015UT8K\u0003O9?e\u0001^@\bad\u0011H";
      A[110] = "\r1j*\u001fCS0z<.\u001cP?|+yL\bi\"G\u0012\u0011C?)vL\u0010S)";
      A[111] = "5<_\"muk=O4\\*h2I#\u000b~9c\u0015v\\xj-@~m&k=V";
      A[112] = "\u007f\\C&\u001bA-\u001bBGDPoBk HT\u0014\u0012B'\\S}\u001cK7G9";
      A[113] = "M\tM\u0010,k\u0013\b]\u0006\u001d4\u0010\u0007[\u0011JdIW\u0006}!9\u0003\u0007\u000eL\u007f8\u0013\u0011";
      A[114] = "\rA\"\u0001J\u001dDC/Y{L\u0012\\LV\u001fP\u0019 \"]\u001bU\u001eI,T\u000bNt";
      A[115] = "4g\b\t6`!4\bMLyLn\u000fU-/4<HTLk34\u001b\bwb/?I64r5:\u000bF!!5~q";
      A[116] = "\u0003\u0010*dC-]\u0011:rrr^\u001e<e%\"\u0007Mh\tN\u007fM\u001ei8\u0010~]\b";
      A[117] = "(pn\"\u0012-vq~4#ru~x#t\",#&O\u001f\u007ff~-~A~vh";
      A[118] = "z\f <#\u000f$\r0*\u0012P'\u00026=E\u0000~^mQ.]4\u0002c`p\\$\u0014";
      A[119] = ")U(\u0003\u001fRwT8\u0015.\rt[>\u0002yY.\bkP._vD7_\u001f\u0001wT!";
      A[120] = "\u0001=d\u001ev\u001f_<t\bG@\\3r\u001f\u0010\u0010\u0004f,s{MO3'B%L_%";
      A[121] = "`CV(S\">BF>b}=M@)5-d\u001d\u0014E^p.M\u0015t\u0000q>[";
      A[122] = "-;OttGs:_bE\u0018p5Yu\u0012M.d\u0004(EJr*P(t\u0014s:F";
      A[123] = "z)d\u0019pp$(t\u000fA/''r\u0018\u0016{\u007f{)OA}%8{Ep#$(m";
      A[124] = "\bTL\u000byEVU\\\u001dH\u001aUZZ\n\u001fJ\f\n\u0005ft\u0017FZ\u000fW*\u0016VL";
      A[125] = "\"[N8m?|Z^.\\`\u007fUX9\u000b0&\b\u0001U`mlU\rd>l|C";
      A[126] = "}hc\u0000m\"#is\u0016\\} fu\u0001\u000b-y4.m`p3f \\>q#p";
      A[127] = "@%n/^j\u001e$~9o5\u001d+x.8eDz'BS8\u000e+-s\r9\u001e=";
      A[128] = "\u0005Vx\u0014\n\u0019\u000e\b=\u0000p\u001c>B|G\u001a\u0000D\t1\u001c\u001a\u007f\u0003]|B\u0000\u0013FI}\u0007p";
      A[129] = "T\u0006\r\u0015FK\n\u0007\u001d\u0003w\u0014\t\b\u001b\u0014 DPUGxK\u0019\u001a\bNI\u0015\u0018\n\u001e";
      A[130] = "Z\\\r!4R\u0004]\u001d7\u0005\r\u0007R\u001b R]_\u0005BL9\u0000\u0014RN}g\u0001\u0004D";
      A[131] = "\u0000@\n}1,^A\u001ak\u0000s]N\u001c|W#\u0005\u001aE\u0010<~NNI!b\u007f^X";
      A[132] = "u@#ZAI+A3Lp\u0016(N5['Fq\u001en7L\u001b;N`\u0006\u0012\u001a+X";
      A[133] = "Z\\\u001d1Ko\u0004]\r'z0\u0007R\u000b0-`_\u0006Q\\F=\u0014R^m\u0018<\u0004D";
      A[134] = "C\u001fC)5>\u001d\u001eS?\u0004a\u001e\u0011U(S1GM\bD8l\r\u0011\u0000ufm\u001d\u0007";
      A[135] = "\u0010a\u0019\u0016zAN`\t\u0000K\u001eMo\u000f\u0017\u001cN\u0014<W{w\u0013^oZJ)\u0012Ny";
      A[136] = "~=7J*7 <'\\\u001bh#3!KL8z`z''e03t\u0016yd %";
      A[137] = "PXkIYW]\u001d#Kf\u0014R\nsY\u001a\u0003Ee+\u001c\u0018\u0012E\u0019iL\u0003\u0015?Xw_Y\u001eS\u001dc^\u001cn";
      A[138] = "T;{Z\u0006k\n:kL74\t5m[`dPh67\u000b9\u001a58\u0006U8\n#";
      A[139] = "?09[\n\u0018:*2\u0005iOV4 [\u0003Y,\u007fm\u0000\u0003&k+ ^\u0019J.?!\u001bi";
      A[140] = "2\u00025JNdo\u0019)\bp4\f\u00185N\u001a\"vSx\u0015\u001a]5\u0004#H\r&<\u0005.\u001bp";
      A[141] = "\u001fg0\u000f#%]7`\u000b_-/ihT'-FgaD<G";
      A[142] = "~)>4c^7h (ZZOm-p0L5&`+03vq;v'H\u007fp6%Z";
      A[143] = ";.siYCe/c\u007fh\u001cf eh?L?p;\u0004T\u0011u 05\n\u0010e6";
      A[144] = "^\t^EhI\u0000\bNSY\u0016\u0003\u0007HD\u000eFZW\u0010(e\u001b\u0010\u0007\u001d\u0019;\u001a\u0000\u0011";
      A[145] = "Lpm\u0018^C\u0012q}\u000eo\u001c\u0011~{\u00198LI+ uS\u0011\u0002~.D\r\u0010\u0012h";
      A[146] = "zi0^\u000e\f$h H?S'g&_h\u0006y6x\u000b?\u0001%x/\u0002\u000e_$h9";
      A[147] = "u1\u000bJ@B+0\u001b\\q\u001d(?\u001dK&HyiI\u001bqO* \u0014\u0016@\u0011+0\u0002";
      A[148] = "RL;M2n\fM+[\u00031\u000fB-LTaV\u0011w ?<\u001cBx\u0011a=\fT";
      A[149] = "':m|s;|hp9\u001cj\u001d`/}`ya\"\u007ffg\u0003";
      A[150] = "/Z7Nk\u000fq['XZPrT!O\r\u0000*\u0002t#f]aTt\u00128\\qB";
      A[151] = "e\u0007o8j\u000e;\u0006\u007f.[Q8\ty9\f\u0001`^\"Ug\\+\t,d9];\u001f";
      A[152] = "+U\u0011o\u0018DbW\u001c7)\u001a6SH-w\u001d6ILQQ\bb\b\u0011,W\tlD!";
      A[153] = "0aKl.\u0000n`[z\u001f_mo]mH\u000f4=\u0001\u0001#R~o\b0}Sny";
      A[154] = "!WpLS\u00188Y'\u000b)\n\\\u001cp\u0019D\u0019-\u001ccIW";
      A[155] = "\u0002\\\u0013j@z\\]\u0003|q%_R\u0005k&u\u0006\u0002\\\u0007M(LRP6\u0013)\\D";
      A[156] = "%\u001bojF\u000b{\u001a\u007f|wTx\u0015yk \u0004!F,\u0007KYk\u0015,6\u0015X{\u0003";
      A[157] = "wa\u0018<TFm3\u0019%*P\u0011v\u0005`@Ek=H;@:va\u001e>\u001bHin\u0002#*";
      A[158] = "{\u0016\u0000}~n%\u0017\u0010kO1&\u0018\u0016|\u0018a\u007fJK\u0010s<5\u0018C!-=%\u000e";
      A[159] = "?{9\u000eM\u0011*(9J7\bGr>RV^? yS7\u0019;)|\u0001J\u001f:'01O\u0003>&:AZP>b@";
      A[160] = "d\u001c\u0003xE):\u001d\u0013ntv9\u0012\u0015y#!fEA,t$;\r\u001c$Ez:\u001d\n";
      A[161] = "K\u001a0zd\u0006\u0015\u001b lUY\u0016\u0014&{\u0002\tNB~\u0017iT\u0005\u0014s&7U\u0015\u0002";
      A[162] = "T\\V4FT\n]F\"w\u000b\tR@5 [P\u0000\u0015YK\u0006\u001aR\u0015h\u0015\u0007\nD";
      A[163] = "\u0003=mL~B]<}ZO\u001d^3{M\u0018M\u0006e'!s\u0010M3.\u0010-\u0011]%";
      A[164] = "\u000f\u0019Z\"SE\u000f\u001c\u0002z3LcGZ(\u000fX\u0018N[%\\%";
      A[165] = "\u0017\u0002x&}CI\u0003h0L\u001cJ\fn'\u001bL\u0012Y6Kp\u0011Y\f;z.\u0010I\u001a";
      A[166] = "\u0002$:dF]\\%*rw\u0002_*,e R\u0006vv\tK\u000fL*y8\u0015\u000e\\<";
      A[167] = "\u001f<\u0007^WTA=\u0017Hf\u000bB2\u0011_1[\u001agE3Z\u0006Q2D\u0002\u0004\u0007A$";
      A[168] = "`x\r*y\u0010>y\u001d<HO=v\u001b+\u001f\u001fe#NGtB.vNv*C>`";
      A[169] = "?bc\u0006\u0006Qacs\u00107\u000eblu\u0007`Z3=)Q7\\`s|Z\u0006\u0002acj";
      A[170] = ":EMU\t<dD]C8cgK[To6>\u001e\u0002\u000281eTR\t\todDD";
      A[171] = "5O/@R&kN?VcyhA9A4)0\u0010g-_t{Al\u001c\u0001ukW";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = A[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(B[var4]);
            A[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = A[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = B[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            A[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  A[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(120980714510116L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = A[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = B[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  A[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(120980714510116L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        A[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(120980714510116L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 78;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 99;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 120;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 204;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 75;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 116;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 78;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 99;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 120;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ez_C0268",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ez" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static RenderCallback invokeBinding1(ESP var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/ez_C0268;)Ldev/zprestige/prestige/dm_C0190;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/ez_C0268",
                     "lambda$onEnable$9",
                     "(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (RenderCallback)var2.invokeExact((ESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static int invokeBinding2(long var0, long var2) {
         MethodHandle var8 = bindingCache2;
         MethodHandle var7 = bindingCache2;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache2 = c(MethodHandles.lookup(), "t", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Object invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding6(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(MethodHandles.lookup(), "t", SourceSupport.methodType("(IIJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding7(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = c(MethodHandles.lookup(), "t", SourceSupport.methodType("(IIJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ModuleManager invokeBinding11(long var0, long var2) {
         MethodHandle var8 = bindingCache11;
         MethodHandle var7 = bindingCache11;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache11 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cG_C0123;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (ModuleManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MenuSettings invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/e3;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MenuSettings)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ColorSetting invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/dI_C0181;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ColorSetting)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding17(int var0, long var1) {
         MethodHandle var7 = bindingCache17;
         MethodHandle var6 = bindingCache17;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache17 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static RLUniforms invokeBinding18(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache18;
         MethodHandle var10 = bindingCache18;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache18 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType(
                     "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static int invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding22(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = c(
                  MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding25(int var0, long var1) {
         MethodHandle var7 = bindingCache25;
         MethodHandle var6 = bindingCache25;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache25 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding26(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache26;
         MethodHandle var9 = bindingCache26;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache26 = c(
                  MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding29(int var0, long var1) {
         MethodHandle var7 = bindingCache29;
         MethodHandle var6 = bindingCache29;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache29 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static boolean invokeBinding30(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache30;
         MethodHandle var9 = bindingCache30;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache30 = c(
                  MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding33(int var0, long var1) {
         MethodHandle var7 = bindingCache33;
         MethodHandle var6 = bindingCache33;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache33 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static RLUniforms invokeBinding34(Object var0, Object var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache34;
         MethodHandle var10 = bindingCache34;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache34 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;IJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding35(int var0, long var1) {
         MethodHandle var7 = bindingCache35;
         MethodHandle var6 = bindingCache35;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache35 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding39(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache39;
         MethodHandle var10 = bindingCache39;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache39 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding40(int var0, long var1) {
         MethodHandle var7 = bindingCache40;
         MethodHandle var6 = bindingCache40;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache40 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding45(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache45;
         MethodHandle var10 = bindingCache45;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache45 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding46(int var0, long var1) {
         MethodHandle var7 = bindingCache46;
         MethodHandle var6 = bindingCache46;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache46 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding48(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding49(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache49;
         MethodHandle var10 = bindingCache49;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache49 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding50(int var0, long var1) {
         MethodHandle var7 = bindingCache50;
         MethodHandle var6 = bindingCache50;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache50 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding51(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache51;
         MethodHandle var8 = bindingCache51;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache51 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding52(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache52;
         MethodHandle var8 = bindingCache52;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache52 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding53(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache53;
         MethodHandle var10 = bindingCache53;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache53 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static MatchException invokeBinding54(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache54;
         MethodHandle var8 = bindingCache54;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache54 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding55(int var0, long var1) {
         MethodHandle var7 = bindingCache55;
         MethodHandle var6 = bindingCache55;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache55 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static RLUniforms invokeBinding56(Object var0, Object var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache56;
         MethodHandle var10 = bindingCache56;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache56 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;IJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding57(int var0, long var1) {
         MethodHandle var7 = bindingCache57;
         MethodHandle var6 = bindingCache57;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache57 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding58(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache58;
         MethodHandle var8 = bindingCache58;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache58 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding59(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache59;
         MethodHandle var8 = bindingCache59;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache59 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding60(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache60;
         MethodHandle var8 = bindingCache60;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache60 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding61(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache61;
         MethodHandle var10 = bindingCache61;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache61 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding62(int var0, long var1) {
         MethodHandle var7 = bindingCache62;
         MethodHandle var6 = bindingCache62;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache62 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding63(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache63;
         MethodHandle var8 = bindingCache63;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache63 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding64(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache64;
         MethodHandle var8 = bindingCache64;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache64 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding65(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache65;
         MethodHandle var8 = bindingCache65;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache65 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding66(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache66;
         MethodHandle var8 = bindingCache66;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache66 = c(
                  MethodHandles.lookup(), "t", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding67(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache67;
         MethodHandle var10 = bindingCache67;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache67 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding68(int var0, long var1) {
         MethodHandle var7 = bindingCache68;
         MethodHandle var6 = bindingCache68;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache68 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding69(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache69;
         MethodHandle var8 = bindingCache69;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache69 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding70(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache70;
         MethodHandle var8 = bindingCache70;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache70 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding71(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache71;
         MethodHandle var10 = bindingCache71;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache71 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding72(int var0, long var1) {
         MethodHandle var7 = bindingCache72;
         MethodHandle var6 = bindingCache72;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache72 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding73(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache73;
         MethodHandle var8 = bindingCache73;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache73 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding74(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache74;
         MethodHandle var8 = bindingCache74;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache74 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding75(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache75;
         MethodHandle var10 = bindingCache75;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache75 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static String invokeBinding76(int var0, long var1) {
         MethodHandle var7 = bindingCache76;
         MethodHandle var6 = bindingCache76;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache76 = b(MethodHandles.lookup(), "v", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Object invokeBinding77(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache77;
         MethodHandle var8 = bindingCache77;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache77 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding78(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache78;
         MethodHandle var8 = bindingCache78;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache78 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RLUniforms invokeBinding79(Object var0, Object var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache79;
         MethodHandle var10 = bindingCache79;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache79 = c(
                  MethodHandles.lookup(),
                  "K",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;FJJ)Ldev/zprestige/prestige/gy_C0374;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RLUniforms)var8.invokeExact((Object)var0, (Object)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }
}
