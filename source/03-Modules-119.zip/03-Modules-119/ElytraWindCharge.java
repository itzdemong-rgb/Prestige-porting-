package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class ElytraWindCharge extends Module implements RotationSource {
   private boolean i;
   private int a;
   private ElapsedTimer c;
   private ElapsedTimer d;
   private boolean e;
   private static final long k = 58731513107115L;
   private static final long l;
   private static final Object[] m = new Object[112];
   private static final String[] n = new String[112];
   private static volatile MethodHandle bindingCache1;

   public ElytraWindCharge() {
      super();
      long var10001 = 130661708688619L ^ 26236128025538L;

      this.a = 0;
      this.c = new ElapsedTimer(106698256430889L);
      this.d = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 125488093490804L ^ 1087296853548L;
      var10001 = 125488093490804L ^ 129325237710727L;
      int var8 = Event.bReturningInt();
      int var21 = var8;
      boolean var20 = this.i;
      boolean var17 = var20;
      boolean var16 = var20;
      if (var21 == 0) {
         boolean var22 = var16;
         if (var22) {
            return;
         }

         Object[] var10 = new Object[]{Items.NETHERITE_CHESTPLATE, 8519502184947L};
         var17 = InventoryUtil.lReturningBoolean(var10);
      }

      label25: {
         int var24 = var8;
         boolean var23 = var17;
         boolean var19 = var23;
         boolean var18 = var23;
         if (var24 == 0) {
            boolean var25 = var18;
            if (var25) {
               break label25;
            }

            Object[] var12 = new Object[]{Items.DIAMOND_CHESTPLATE, 8519502184947L};
            boolean var26 = InventoryUtil.lReturningBoolean(var12);
            var19 = var26;
         }

         boolean var27 = var19;
         if (!var27) {
            return;
         }
      }

      Object[] var15 = new Object[]{126290808879192L};
      ElytraWindCharge var14 = this;
      var14.aReturningVoid(var15);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 49132168048187L;
      long var6 = var2 ^ 65762800970131L;
      long var8 = var2 ^ 73608466808436L;
      long var10 = var2 ^ 29159961624672L;
      long var12 = var2 ^ 96471650842703L;
      long var14 = var2 ^ 117380820149222L;
      long var16 = var2 ^ 125416469990252L;
      long var18 = var2 ^ 19182256418671L;
      long var20 = var2 ^ 138007752420630L;
      long var22 = var2 ^ 125483130411561L;
      long var24 = var2 ^ 16882931127021L;
      long var26 = var2 ^ 48279607100484L;
      int var28 = Event.bReturningInt();
      int var162 = var28;
      MinecraftClient var161 = b;
      MinecraftClient var137 = var161;
      MinecraftClient var136 = var161;
      if (var162 == 0) {
         MinecraftClient var41 = var136;
         Screen var163 = var41.currentScreen;
         if (var163 != null) {
            return null;
         }

         MinecraftClient var164 = b;
         var137 = var164;
      }

      MinecraftClient var44 = var137;
      int var10000 = (((var44.isWindowFocused()) ? 1 : 0));
      int var166 = var28;
      byte var165 = (byte)var10000;
      int var139 = var165;
      byte var138 = var165;
      if (var166 == 0) {
         byte var167 = var138;
         if (var167 == 0) {
            return null;
         }

         this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
         var139 = this.a;
      }

      int var169 = var28;
      int var168 = var139;
      int var141 = var168;
      int var140 = var168;
      if (var169 == 0) {
         // int var170 = var140;
         if (var170 == var171) {
            MinecraftClient var50 = b;
            int var174 = var28;
            ClientPlayerEntity var173 = var50.player;
            ClientPlayerEntity var148 = var173;
            ClientPlayerEntity var142 = var173;
            if (var174 == 0) {
               EquipmentSlot var52 = EquipmentSlot.CHEST;
               ClientPlayerEntity var51 = var142;
               ItemStack var53 = var51.getEquippedStack(var52);
               Item var209 = var53.getItem();
               Item var176 = Items.ELYTRA;
               Item var175 = var209;
               if (var175 != var176) {
                  int var178 = var28;
                  Item var177 = Items.ELYTRA;
                  Item var145 = var177;
                  Item var143 = var177;
                  if (var178 == 0) {
                     Item var179 = var143;
                     Item var144 = var179;
                     Object[] var56 = new Object[]{var144, var6};
                     boolean var180 = InventoryUtil.lReturningBoolean(var56);
                     if (var180) {
                        this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
                        Object[] var58 = new Object[]{Hand.MAIN_HAND, var24};
                        ItemUseUtil.cReturningBoolean(var58);
                        int var181 = var28;
                        if (var181 == 0) {
                           return null;
                        }
                     }

                     Item var182 = Items.ELYTRA;
                     var145 = var182;
                  }

                  Object[] var61 = new Object[]{var145, var14};
                  Integer var208 = InventoryUtil.aReturningBoxedInteger(var61);
                  int var184 = var28;
                  Integer var183 = var208;
                  Integer var147 = var183;
                  Integer var146 = var183;
                  if (var184 == 0) {
                     Integer var185 = var146;
                     if (var185 == null) {
                        return null;
                     }

                     var147 = var208;
                  }

                  Integer var63 = var147;
                  var10000 = var63;
                  Object[] var217 = new Object[]{null, var20};
                  var217[0] = var10000;
                  Object[] var64 = var217;
                  InventoryUtil.aReturningVoid(var64);
                  return null;
               }

               MinecraftClient var65 = b;
               var148 = var65.player;
            }

            ClientPlayerEntity var66 = var148;
            boolean var210 = var66.isOnGround();
            int var187 = var28;
            boolean var186 = var210;
            boolean var150 = var186;
            boolean var149 = var186;
            if (var187 == 0) {
               boolean var188 = var149;
               if (var188) {
                  MinecraftClient var68 = b;
                  GameOptions var69 = var68.options;
                  KeyBinding var70 = var69.jumpKey;
                  var70.setPressed(true);
                  return null;
               }

               MinecraftClient var73 = b;
               GameOptions var74 = var73.options;
               KeyBinding var75 = var74.jumpKey;
               var75.setPressed(false);
               Object[] var77 = new Object[]{var4};
               var150 = RaycastUtil.aReturningBoolean(var77);
            }

            int var190 = var28;
            boolean var189 = var150;
            boolean var158 = var189;
            boolean var151 = var189;
            if (var190 == 0) {
               boolean var191 = var151;
               if (!var191) {
                  ElapsedTimer var157;
                  label126: {
                     MinecraftClient var79 = b;
                     ClientPlayerEntity var80 = var79.player;
                     var210 = var80.isOnGround();
                     int var193 = var28;
                     boolean var192 = var210;
                     boolean var156 = var192;
                     boolean var152 = var192;
                     if (var193 == 0) {
                        boolean var194 = var152;
                        boolean var153 = var194;
                        boolean var195 = var153;
                        if (var195) {
                           return null;
                        }

                        int var197 = var28;
                        ElapsedTimer var196 = this.c;
                        var157 = var196;
                        ElapsedTimer var154 = var196;
                        if (var197 != 0) {
                           break label126;
                        }

                        ElapsedTimer var198 = var154;
                        ElapsedTimer var155 = var198;
                        Object[] var218 = new Object[]{null, var8};
                        var218[0] = 400.0F;
                        Object[] var85 = var218;
                        ElapsedTimer var84 = var155;
                        boolean var199 = var84.aReturningBoolean(var85);
                        var156 = var199;
                     }

                     boolean var200 = var156;
                     if (!var200) {
                        return null;
                     }

                     MinecraftClient var87 = b;
                     GameOptions var88 = var87.options;
                     KeyBinding var89 = var88.jumpKey;
                     var89.setPressed(true);
                     Object[] var91 = new Object[]{var26};
                     ItemUseUtil.bReturningVoid(var91);
                     MinecraftClient var92 = b;
                     ClientPlayerEntity var93 = var92.player;
                     ClientPlayNetworkHandler var215 = var93.networkHandler;
                     MinecraftClient var94 = b;
                     ClientCommandC2SPacket var96 = new ClientCommandC2SPacket(var94.player, Mode.START_FALL_FLYING);
                     ClientPlayNetworkHandler var95 = var215;
                     var95.sendPacket((Packet)var96);
                     ElapsedTimer var201 = this.c;
                     var157 = var201;
                  }

                  Object[] var99 = new Object[]{var10};
                  ElapsedTimer var98 = var157;
                  var98.aReturningVoid(var99);
                  return null;
               }

               ElapsedTimer var211 = this.d;
               Object[] var10004 = new Object[]{null, var8};
               var10004[0] = 400.0F;
               Object[] var101 = var10004;
               ElapsedTimer var100 = var211;
               var158 = var100.aReturningBoolean(var101);
            }

            boolean var202 = var158;
            if (!var202) {
               return null;
            }

            MinecraftClient var103 = b;
            ClientPlayerEntity var104 = var103.player;
            Vec3d var29 = var104.getVelocity();
            MinecraftClient var105 = b;
            ClientPlayerEntity var106 = var105.player;
            float var30 = var106.getYaw();
            double var107 = var30;
            double var31 = Math.toRadians(var107);
            double var109 = var31;
            double var10002 = -Math.sin(var109);
            double var111 = var31;
            Vec3d var113 = new Vec3d(var10002, 0.0, Math.cos(var111));
            Vec3d var33 = var113.normalize();
            Vec3d var114 = var29;
            Vec3d var115 = var33;
            double var212 = var114.x * var115.x;
            Vec3d var116 = var29;
            Vec3d var117 = var33;
            float var34 = (float)(var212 + var116.z * var117.z);
            float var35 = 0.4F;
            float var36 = 1.2F;
            float var119 = var34;
            float var118 = 1.0F;
            float var121 = Math.min(var118, var119);
            float var120 = 0.0F;
            float var37 = Math.max(var120, var121);
            float var38 = var36 - (var36 - var35) * var37;
            MinecraftClient var122 = b;
            Object[] var123 = new Object[]{var122.player, var22};
            double var219;
            int var203 = (var219 = RaycastUtil.aReturningDouble(var123) - var38) == 0.0 ? 0 : (var219 < 0.0 ? -1 : 1);
            if (var203 > 0) {
               return null;
            }

            Random var125 = RandomUtil.a;
            float var39 = 87.0F + var125.nextFloat() * 3.0F;
            Object[] var127 = new Object[]{var12};
            ElytraWindCharge var126 = this;
            int var40 = var126.dReturningInt(var127);
            int var205 = var28;
            int var204 = var40;
            int var160 = var204;
            int var159 = var204;
            if (var205 == 0) {
               // int var206 = var159;
               if (var206 == var207) {
                  return null;
               }

               Object[] var130 = new Object[]{var18};
               this.a = InventoryUtil.aReturningInt(var130);
               var160 = var40;
            }

            Runnable var10001 = invokeBinding1(var39);
            Object[] var10005 = new Object[]{null, null, null, var16};
            var10005[2] = false;
            var10005[1] = var10001;
            var10005[0] = var160;
            Object[] var131 = var10005;
            InventoryUtil.bReturningVoid(var131);
            ElapsedTimer var213 = this.d;
            Object[] var133 = new Object[]{var10};
            ElapsedTimer var132 = var213;
            var132.aReturningVoid(var133);
            MinecraftClient var134 = b;
            ClientPlayerEntity var135 = var134.player;
            return new Rotation(var135.getYaw(), var39);
         }

         int var172 = this.a;
         var141 = var172;
      }

      Object[] var10003 = new Object[]{null, var20};
      var10003[0] = var141;
      Object[] var49 = var10003;
      InventoryUtil.aReturningVoid(var49);
      this.a = -1;
      return null;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      int var10000 = Event.cReturningInt();
      RotationManager var10001 = Prestige.o;
      Object[] var8 = new Object[]{this, var4};
      RotationManager var7 = var10001;
      var7.eReturningVoid(var8);
      int var6 = var10000;
      int var24 = var6;
      MinecraftClient var23 = b;
      MinecraftClient var22 = var23;
      MinecraftClient var21 = var23;
      if (var24 != 0) {
         MinecraftClient var9 = var21;
         Window var27 = var9.getWindow();
         MinecraftClient var10 = b;
         GameOptions var11 = var10.options;
         KeyBinding var12 = var11.jumpKey;
         Key var13 = var12.getDefaultKey();
         int var15 = var13.getCode();
         Window var14 = var27;
         boolean var25 = InputUtil.isKeyPressed(var14, var15);
         if (var25) {
            return;
         }

         MinecraftClient var26 = b;
         var22 = var26;
      }

      MinecraftClient var18 = var22;
      GameOptions var19 = var18.options;
      KeyBinding var20 = var19.jumpKey;
      var20.setPressed(false);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 58731513107115L ^ var2;
      int var25 = Event.bReturningInt();
      int var4 = var25;

      byte var16;
      while (true) {
         int var18 = (int)l;
         int var17 = var5;
         if (var17 <= var18) {
            MinecraftClient var7 = b;
            ClientPlayerEntity var8 = var7.player;
            PlayerInventory var26 = var8.getInventory();
            int var10 = var5;
            PlayerInventory var9 = var26;
            ItemStack var6 = var9.getStack(var10);
            int var19 = var4;
            if (var19 == 0) {
               ItemStack var11 = var6;
               Item var27 = var11.getItem();
               Item var13 = Items.WIND_CHARGE;
               Item var12 = var27;
               byte var28 = ((byte)((var12.equals(var13)) ? 1 : 0));
               int var21 = var4;
               byte var20 = var28;
               var16 = var20;
               byte var14 = var20;
               if (var21 != 0) {
                  break;
               }

               byte var22 = var14;
               byte var15 = var22;
               byte var23 = var15;
               if (var23 != 0) {
                  return var5;
               }

               var5++;
            }

            int var24 = var4;
            if (var24 == 0) {
               continue;
            }
         }

         var16 = -1;
         break;
      }

      return var16;
   }

   private static void lambda$calculate$0(float var0) {
      long var10001 = 93175234010231L ^ 113888845080314L;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      float var5 = var7.getPitch();
      MinecraftClient var8 = b;
      float var10 = var0;
      ClientPlayerEntity var9 = var8.player;
      var9.setPitch(var10);
      Object[] var11 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var11);
      MinecraftClient var12 = b;
      float var14 = var5;
      ClientPlayerEntity var13 = var12.player;
      var13.setPitch(var14);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(115549323137959L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 7759302047028465085L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)107L,
            (byte)27566L,
            (byte)7057044L,
            (byte)1806603289L,
            (byte)462490442218L,
            (byte)118397553207831L,
            (byte)30309773621204941L,
            (byte)7759302047028465085L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 17;
            yield var16;
         }
         case 2 -> {
            byte var17 = 45;
            yield var17;
         }
         case 3 -> {
            byte var18 = 1;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 10;
            yield var20;
         }
         case 6 -> {
            byte var21 = 35;
            yield var21;
         }
         case 7 -> {
            byte var22 = 37;
            yield var22;
         }
         case 8 -> {
            byte var23 = 16;
            yield var23;
         }
         case 9 -> {
            byte var24 = 13;
            yield var24;
         }
         case 10 -> {
            byte var25 = 28;
            yield var25;
         }
         case 11 -> {
            byte var26 = 51;
            yield var26;
         }
         case 12 -> {
            byte var27 = 23;
            yield var27;
         }
         case 13 -> {
            byte var28 = 62;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 14;
            yield var30;
         }
         case 16 -> {
            byte var31 = 56;
            yield var31;
         }
         case 17 -> {
            byte var32 = 6;
            yield var32;
         }
         case 18 -> {
            byte var33 = 61;
            yield var33;
         }
         case 19 -> {
            byte var34 = 50;
            yield var34;
         }
         case 20 -> {
            byte var35 = 20;
            yield var35;
         }
         case 21 -> {
            byte var36 = 4;
            yield var36;
         }
         case 22 -> {
            byte var37 = 2;
            yield var37;
         }
         case 23 -> {
            byte var38 = 59;
            yield var38;
         }
         case 24 -> {
            byte var39 = 18;
            yield var39;
         }
         case 25 -> {
            byte var40 = 63;
            yield var40;
         }
         case 26 -> {
            byte var41 = 22;
            yield var41;
         }
         case 27 -> {
            byte var42 = 15;
            yield var42;
         }
         case 28 -> {
            byte var43 = 8;
            yield var43;
         }
         case 29 -> {
            byte var44 = 46;
            yield var44;
         }
         case 30 -> {
            byte var45 = 38;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 33;
            yield var47;
         }
         case 33 -> {
            byte var48 = 54;
            yield var48;
         }
         case 34 -> {
            byte var49 = 27;
            yield var49;
         }
         case 35 -> {
            byte var50 = 26;
            yield var50;
         }
         case 36 -> {
            byte var51 = 44;
            yield var51;
         }
         case 37 -> {
            byte var52 = 30;
            yield var52;
         }
         case 38 -> {
            byte var53 = 3;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 60;
            yield var55;
         }
         case 41 -> {
            byte var56 = 9;
            yield var56;
         }
         case 42 -> {
            byte var57 = 29;
            yield var57;
         }
         case 43 -> {
            byte var58 = 47;
            yield var58;
         }
         case 44 -> {
            byte var59 = 11;
            yield var59;
         }
         case 45 -> {
            byte var60 = 34;
            yield var60;
         }
         case 46 -> {
            byte var61 = 39;
            yield var61;
         }
         case 47 -> {
            byte var62 = 41;
            yield var62;
         }
         case 48 -> {
            byte var63 = 31;
            yield var63;
         }
         case 49 -> {
            byte var64 = 42;
            yield var64;
         }
         case 50 -> {
            byte var65 = 43;
            yield var65;
         }
         case 51 -> {
            byte var66 = 25;
            yield var66;
         }
         case 52 -> {
            byte var67 = 32;
            yield var67;
         }
         case 53 -> {
            byte var68 = 48;
            yield var68;
         }
         case 54 -> {
            byte var69 = 36;
            yield var69;
         }
         case 55 -> {
            byte var70 = 5;
            yield var70;
         }
         case 56 -> {
            byte var71 = 53;
            yield var71;
         }
         case 57 -> {
            byte var72 = 57;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 55;
            yield var74;
         }
         case 60 -> {
            byte var75 = 19;
            yield var75;
         }
         case 61 -> {
            byte var76 = 24;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 52;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "]cG~\u000fkKcB$\u001c|\\(A\"\u0010hMoV5[~x";
      m[1] = "\u0001jC\u0014\t\u001f\neR[j\u0012\u001fh]0_\u0010\u000e{A\u001cH\u001d";
      m[2] = "\\\u0000,0~\u007f\\\u0000;lrpFK;rreA:k/#";
      m[3] = "\u0012m!\u0001yF\u0012m6]uI\b&6Cu\\\u000fWf\u001e!";
      m[4] = ")\u0002)\r\u0019D)\u0002>Q\u0015K3I>O\u0015^48n\u0013@";
      m[5] = "\u0006S(u%@\u0006S?))O\u001c\u0018?7)Z\u001biom\u007f\u001cLU0:;Z7\u0005lm";
      m[6] = int.class;
      n[6] = "java/lang/Integer";
      m[7] = "Wr~>\u0017\u0000Ar{d\u0004\u0017V9xb\b\u0003G~ouC\u0011v";
      m[8] = boolean.class;
      n[8] = "java/lang/Boolean";
      m[9] = void.class;
      n[9] = "java/lang/Void";
      m[10] = "l\u0000\u001a8\u0005|z\u0000\u001fb\u0016kmK\u001cd\u001a\u007f|\f\u000bsQhq";
      m[11] = "\u0006EA\u001db\\seJ\u0012s\u0013\u0012kA\u0019wIf";
      m[12] = "4H+? H4H<c,G.\u0003<},R)rl'z\u0014";
      m[13] = "\u0005@\u0010D'{\u0005@\u0007\u0018+t\u001f\u000b\u0007\u0006+a\u0018zUZ~#";
      m[14] = "&\u001c\u0006\u000e\u000e\u00160\u001c\u0003T\u001d\u0001'W\u0000R\u0011\u00156\u0010\u0017EZ\u0005.\u0010\u0015N\u0000H\u0012\u000b\u0015S\u0000\u000f%\u001c";
      m[15] = "4bT#FH*jNl;X*";
      m[16] = "+\u000f\u00153\u0003W \u0000\u0004|bY+\u000b\u0000&";
      m[17] = "S\u0005\u000bGc2S\u0005\u001c\u001bo=IN\u001c\u0005o(N?IZ:";
      m[18] = "yb(\u000ebwyb?Rnxc)?LnmdXn\u00156(";
      m[19] = "BGA=6yIHPrUt\\N";
      m[20] = double.class;
      n[20] = "java/lang/Double";
      m[21] = "_\u0006bN\u0019u_\u0006u\u0012\u0015zEMu\f\u0015oB<'WM%";
      m[22] = "vV/u2JvV8)>El\u001d87>Pkljlf\u0011";
      m[23] = "tSa!hktSv}ddn\u0018vcdqii\";3";
      m[24] = "XX'-!!XX0q-.B\u00130o-;Ebb0||";
      m[25] = "3\u001b;\u0004<x3\u001b,X0w)P,F0b.!{\u0019f";
      m[26] = "U{7JBUC{2\u0010QBT01\u0016]VEw&\u0001\u0016F^";
      m[27] = "A?\u0016L\u0007\u000e4\u001f\u001dC\u0016AU\u0011\u0016H\u0012\u001b!";
      m[28] = float.class;
      n[28] = "java/lang/Float";
      m[29] = "xjsqskxjd-\u007fdb!d3\u007fqeP5k-";
      m[30] = "\u001bE\u0013WK(\rE\u0016\rX?\u001a\u000e\u0015\u000bT+\u000bI\u0002\u001c\u001f;\u0013";
      m[31] = "\u000eS\u0013J\u001f?{s\u0018E\u000ep\u001a}\u0013N\n*n";
      m[32] = "&\f<:\u000bR-\u0003-ulP8\b->W";
      m[33] = "\u0001I\u0012/(H\u0017I\u0017u;_\u0000\u0002\u0014s7K\u0011E\u0003d|^<";
      m[34] = "yc7 \u0016n\fC</\u0007!mM7$\u0003{\u0019";
      m[35] = "\"\u00137/4TW3< %\u001b6=7+!AB";
      m[36] = "\u0017iq\t\u0012O\u0001itS\u0001X\u0016\"wU\rL\u0007e`BF\\@";
      m[37] = "\u001aR:\u000f^mor1\u0000O\"\u000e|:\u000bKxz";
      m[38] = "\u001c\u0011\u000fr[#i1\u0004}Jl\b?\u000fvN6|";
      m[39] = "\u007f\u001bB*Q\b\u007f\u001bUv]\u0007ePUh]\u0012b!\u0007<\fS";
      m[40] = "<\\\f\u000e\niI|\u0007\u0001\u001b&(r\f\n\u001f|\\";
      m[41] = ";S\u000bg\u001d\u0000Ns\u0000h\fO/}\u000bc\b\u0015[";
      m[42] = "H\u001dK_\u0007%==@P\u0016j\\3K[\u00120(";
      m[43] = "ju3$x\u0003\u001fU8+iL~[3 m\u0016\n";
      m[44] = "\u001aqt~\u0012\u0006oQ\u007fq\u0003I\u000e_tz\u0007\u0013z";
      m[45] = "\u0018\u0006\u000eQU<m&\u0005^Ds\f(\u000eU@)x";
      m[46] = "]'(b}B]'?>qMGl? qX@\u001dnt$\u0013\u0017!0-cXlpdx)";
      m[47] = "Q\u0010+\u001e`4Q\u0010<Bl;K[<\\l.L*n\u0002;e";
      m[48] = "S]\u0001\u000bpiMU\u001bD\f}WX\u0018\u0007";
      m[49] = "5'7\u0002\u0003I@\u0007<\r\u0012\u0006!\t7\u0006\u0016\\U";
      m[50] = "e\u001e\u000bE\u0012Fs\u001e\u000e\u001f\u0001QdU\r\u0019\rEu\u0012\u001a\u000eFRP";
      m[51] = "l\u0018]$jN\u00198V+{\u0001x6] \u007f[\f";
      m[52] = "Z||jb-Z|k6n\"@7k(n7GF9r9u";
      m[53] = "n!AN62='\b\u001e\f8lf\u0019B`\n:#D\u0019<]8\"GH2'?\u007f\b\u0019h]";
      m[54] = "OtXU\u0019:\u001f2\bRzj\u0014#P@-=Js\t,\u001az\u00073L\u0011\u0002t\u0012 ";
      m[55] = "\u000f-\u000e\r5E\\+G]\u000fO\rjV\u0001c}[(\n[3*\u0002y\n\u001fc\u0015ZiI\u0006\u000f";
      m[56] = "W\u001e\t\u0001&@J\u001fSPHYZ\u0003h_'\u0000B\tW\u00077C[e\nRtEWZRB7\\;\u0007\u0007\u00011P\u0004_\u0017B(<";
      m[57] = "\n\u0015\u0017\u000bt\u001dH\u0004\u000b\t\u001b\u0006\\\u0019\n\bw4\bYVS\u001b_[\u0017\u0006SeZ\r]\u0004o";
      m[58] = "H,a&\u0014Q\r8`:{Lv.o'\u0000Y\u0006:+/\u0002 H>.3\u0016E\u0012..'{";
      m[59] = "==\u0006^w\u001dm{VY\u0014Fj{\n@xt>:T\u0016\u0014\u001ed;\u001a\u0018h_<b\u0011'";
      m[60] = "ClQCFz\u0010j\u0018\u0013|pA+\tO\u0010B\u0016kY\u0012L\u0015\u00114UXCiPl\fS|";
      m[61] = "0\\\u0013cZ\u0018j@\u001476A3Y)5R]8%K6DLi[N`\u000eNU";
      m[62] = "@\u0005*\bA\u001e]\u0004pY/\u001eK$\"XN\u000bJ\u0005KYA\u0000\u0016C*IQ\u001fQ~&ZMX\u0011\u001f6JR\u001f,";
      m[63] = "C\u00186Mn4\u0010\u001e\u007f\u001dT>A_nA8\f\u0017\u001d2\u001bi[NL2_8d\u0016\\qFT";
      m[64] = "\b>MNc@\u0015?\u0017\u001f\rW\u0003>,\u001fc^^xM\u000fsA\u0019EA\u001co\u0006Y$Q\fpAd";
      m[65] = "\b<S\u0007\u0014G\u0019`^\u000b)J\u001bq^SR'\b<S\u0007\u0014G\u0019`^\u000b)\u001a\u00010G\bU[YiL7";
      m[66] = "SL\u000e,\u001aj\u0003\n^+y1\u0004\n\u00022\u0015\u0003SL\\eBTX\u001bS1\u0007d\u0005\u0010\u001c2y";
      m[67] = "\u001b>\u0014pHEZs\u0007s#Qcs\u0003fXA\u0013gGnZ8^bAo\u001cD\u001f:\u0018d#";
      m[68] = "3\u000es+1\\?\u001enfT\u00021\tww\u0003UkY)\u001b9\u00022^.z)\u0012-\u0019";
      m[69] = "O\u001d\ry\u001b\\\u001f[]~x\f\u0014J\u0005l/[K\u0016Y\u0000B\u0006\f\u001d\b;\u0017\u000e\u0016V";
      m[70] = "'\u001fw\u000f(B{Co\u0002L\u0014F\tu\u00197\u00046\u001d1\u00115}#\u0002o_ Ey\u001eh\u000bL";
      m[71] = "\u0019&@\u0011\u000fDXkS\u0012dPakW\u0007\u001f@\u0011\u007f\u0013\u000f\u001d9\fwKDYX\u001cgT\u0003d";
      m[72] = "K}\u0017]Xf\u001eu\r\u001613\u0010t\n\u000bfd@!Ug\u000b!Az\u001fXK9L`";
      m[73] = " \"\u0019.]L|~\u0001#9\u0019A4\u001b8B\n1 _0@s\u007f$Z,T\u0016%4Z89";
      m[74] = "Q3V\u0003%~\u001c4\u000f\u0000X~ :\u0016\u0006#nP.R\u000e!\u0017\u001e*W\u00125rD:W\u0006X";
      m[75] = "BRTI-`CD\u0014->\u001a\u000fB\u0013V+j\u001b\u0006\u001bTR&\u0017N\u0006\u0011,#A\u0004\u0004-";
      m[76] = "66;z\u0015\t1kt+OsjcywL\u001fX39,\u001bs3dw{\u0017\r62=y+\u001d0\u007fi*NBd>5\u0017";
      m[77] = "B\bj0`\u0010Z\u000bu$\f\u0002&Fn2w\u0011VR*:uh\u0018V/&a\rBF/2\f";
      m[78] = "\u0014bUV\u0019\u000f\u0005a\u0012\u0012c\u001f\n5M\u00044HQi\u0019Rc\u000eQ$\u0017\u0012\u001d\u001fRcS";
      m[79] = "_\u001a\u001f \u00008\u0012BS=g'NM\u000b20t\u001f\u0018_^\u0017s_^\b/Z+\u0013C";
      m[80] = "G3$ T\u0005Z:dt6\u001a\\8{&aD\u0005h/JX\u0011\f6$3Y\u000bQ?";
      m[81] = "\u001fS@\u0010_t\rN\u0016\u001b#r\u0018RN\u001cO@H\u0014\u0011K\u001c\u0017\u001eMV\u0001GxE_KB#)\u0017\u0011C\u0016Fs\u0007\u0011W{";
      m[82] = "c\u0006$|0y5FefSw^\u0002qh?! \u0007'\"=\u001d";
      m[83] = "\u0017\u000bJnOc\n\n\u0010?!d\u001a\u0016+?O}AMJ/_b\u0006pF<C%F\u0011V,\\b{";
      m[84] = "JJv\u0016\u0011R\u0015\u001e7J,RI\tg\u001d@`\u001bD?K,YADdAUX[\u0019mz";
      m[85] = "/u1;/O|sxk\u0015N!#m<B\u001bqr5P\u007f].%u3m@x.";
      m[86] = "wzN\u0013\u0017\r$|\u0007C-\u0007u=\u0016\u001fA5&xOH-\u0002(*H\u0002U\u0001g~\u001fxC]i-K\u001d\u001c\t(qv";
      m[87] = "O]c,\u001c\u0005\u001eH34f\u0005H&fm\u0002R\u001bFw1\u000f^&Ow2\u0017\u0018A\u001ebb\u000fb";
      m[88] = "+>$8&\u0018wb<5BNJ(&.9^:<b&;'t8g:/B.(g.B";
      m[89] = "<\u0012\u0015)bn0\u0002\bd\u0007;2\u0004\u0015~k\tf@O(\u0007=5\u0018E|71%\u0005\b\u0019";
      m[90] = "/>\f\u0010bCy~M\n\u0001L\u0012:Y\u0004m\u001bl?\u000fNo'";
      m[91] = "W==\u0018\u0011j\u0004;tH+`Uze\u0014GR\u000389N\u0014\u0005Zi9\nG:\u0002yz\u0013+;Z9h\u001eNaJ9|s";
      m[92] = "\u001ek4\f{\u001a\u0006h+\u0018\u0017\tz%0\u000el\u001b\n1t\u0006nbG4r\u0007(\u001e\u0006l+\f\u0017";
      m[93] = "#\u001b;r}a/\u000b&?\u0018?!\u001c?.Oh{LcBu?\"Kf#e/=\f";
      m[94] = "@C\u001d\u000b3\u0014\u0005W\u001c\u0017\\\b~A\u0013\n'\u001c\u000eUW\u0002%e@QR\u001e1\u0000\u001aAR\n\\";
      m[95] = "\u000fLSx!$\\J\u001a(\u001b.\r\u000b\u000btw\u001cYGT\"+K\u0003\u001d\u000b#~{\u000f\r\u0016n\u001b";
      m[96] = "vP`\u0004\u0011>&\u00160\u0003rn-\u0007h\u0011%9sP0}\u001d;t\u00016\u0012N==Q";
      m[97] = "^-xz\u00072Y\u007fh#\u007f48=yf\u0004$H)=n\u0006]\u0006-8r\u00128\\=8f\u007f";
      m[98] = "u*j\rn%h#*Y\f:n!5\u000b[n5tkW\f:j}2\\u;p ;";
      m[99] = "\u000eZB\u001b\u0016M\u001b_VMj\u0016g\u000fX\u0004\u0012\u001e\u0016JL\u0005\u000e";
      m[100] = "\u0014\u0000N1E8H\\V<!nu\u0016L'Z~\u0005\u0002\b/X\u0007I\u000e@2\u001dyLX\n0!";
      m[101] = "a\\AyD^!DLc5\u00046\\\u0011}Y6b\u001cK+5Z+]\u0015uK\u0018:A\u0017\u001a";
      m[102] = "P' uXVSht\"\"@Qz/'u\u0010\t(wKB\u001e[)13AQ\u000f~";
      m[103] = "RwTZb}Sa\u0014>t\u0007\u0011k[[ce\u0015#\u0006>au\\|\u0014\\e=\u0001\u0019";
      m[104] = "0(3\n\u001a!7z#Sb'V82\u0016\u00197&,v\u001e\u001bNk)p\u001f]2*q)\u0014b";
      m[105] = "\rPilo]\u0010Y)8\rB\u0016[6jZ\u001cG\ri\u0006cIFUi\u007fbS\u001b\\";
      m[106] = "\u001b/\u0005N/<\u0006._\u001fA%\u001e$d\u0010.|\u000e8[H>?\u0017T\u0006\u001d}9\u001bk^\r> w6\u000bN8,Hn\u001b\r!@";
      m[107] = "'D\u0011y8\u0013{\u0018\tt\\HFR\u0013o'U6FWg%,{CQfcP:\u001b\bm\\";
      m[108] = "VQ\u0010 *,KXPtH3MZO&\u001fa\u001d\u000f\u001azH3I\u0006Hq12S[A";
      m[109] = "\u007fe,\u0003HD?}!\u00199\u001e(e|\u0007U,\u007f\" P\u0000{xz \u0010\u0006\u00079\"y\u001b9E'&q\r\\\u001f7&e`";
      m[110] = "0\u0000@#)\u000e0\u001a\u0014$[Zm\u001fK-7h9^\u001azd?1\u000e\u001a.%\u000fl\u0005U-[\u0003j\u0011Gv%\u0006<[EJf\\<\u0013\u00146'\u0004e\u0018+";
      m[111] = "MW|9\fL\u0006Zr'kCP@>\u0011\u000fBTLB=\u0004\u0019D\\}e\u0014Z]0";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1141391796524860L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1141391796524860L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1141391796524860L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 246;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 66;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 116;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 224;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 98;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 236;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 246;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 66;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 116;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eA_C0217",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eA" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(float var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(F)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/eA_C0217", "lambda$calculate$0", "(F)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((float)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
