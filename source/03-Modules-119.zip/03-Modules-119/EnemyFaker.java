package dev.zprestige.prestige.client.modules;

import com.mojang.authlib.GameProfile;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.EntityNameEvent;
import dev.zprestige.prestige.api.util.SkinProfileUtil;
import dev.zprestige.prestige.api.events.PlayerNameEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PlayerSkinEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.StringSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.texture.PlayerSkinProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Pair;

public class EnemyFaker extends Module {
   private StringSetting a;
   private StringSetting c;
   private ModeSetting d;
   private BooleanSetting e;
   private SkinTextures f = null;
   private PlayerEntity g;
   private static final long k = 4159416439736L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[146];
   private static final String[] s = new String[146];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;

   @EventListener
   public void a(PlayerSkinEvent var1) {
      long var10001 = 8342489206399L ^ 16546421674147L;
      int var6 = Event.cReturningInt();
      int var62 = var6;
      EnemyFaker var61 = this;
      EnemyFaker var50 = var61;
      EnemyFaker var49 = var61;
      if (var62 != 0) {
         PlayerEntity var63 = var49.g;
         if (var63 == null) {
            return;
         }

         EnemyFaker var64 = this;
         var50 = var64;
      }

      SkinTextures var65 = var50.f;
      if (var65 != null) {
         int var67 = var6;
         PlayerSkinEvent var66 = var1;
         PlayerSkinEvent var53 = var66;
         PlayerSkinEvent var51 = var66;
         if (var67 != 0) {
            PlayerSkinEvent var68 = var51;
            PlayerSkinEvent var52 = var68;
            Object[] var11 = new Object[0];
            PlayerSkinEvent var10 = var52;
            String var69 = var10.aReturningString(var11);
            if (var69 == null) {
               return;
            }

            PlayerSkinEvent var70 = var1;
            var53 = var70;
         }

         Object[] var15 = new Object[0];
         PlayerSkinEvent var14 = var53;
         SkinTextures var10000 = var14.aReturningSkinTextures(var15);
         int var72 = var6;
         SkinTextures var71 = var10000;
         Object var55 = var71;
         SkinTextures var54 = var71;
         if (var72 != 0) {
            SkinTextures var73 = var54;
            if (var73 == null) {
               return;
            }

            StringSetting var17 = this.a;
            Object var74 = var17.aReturningObject();
            var55 = var74;
         }

         String var19 = (String)var55;
         boolean var75 = var19.isEmpty();
         if (!var75) {
            MinecraftClient var20 = b;
            ClientPlayNetworkHandler var86 = var20.getNetworkHandler();
            PlayerEntity var21 = this.g;
            UUID var23 = var21.getUuid();
            ClientPlayNetworkHandler var22 = var86;
            PlayerListEntry var87 = var22.getPlayerListEntry(var23);
            int var77 = var6;
            PlayerListEntry var76 = var87;
            PlayerListEntry var58 = var76;
            PlayerListEntry var56 = var76;
            if (var77 != 0) {
               PlayerListEntry var78 = var56;
               PlayerListEntry var57 = var78;
               PlayerListEntry var79 = var57;
               if (var79 == null) {
                  return;
               }

               MinecraftClient var26 = b;
               ClientPlayNetworkHandler var88 = var26.getNetworkHandler();
               PlayerEntity var27 = this.g;
               UUID var29 = var27.getUuid();
               ClientPlayNetworkHandler var28 = var88;
               PlayerListEntry var80 = var28.getPlayerListEntry(var29);
               var58 = var80;
            }

            PlayerListEntry var31 = var58;
            GameProfile var81 = var31.getProfile();
            if (var81 != null) {
               int var83 = var6;
               PlayerSkinEvent var82 = var1;
               PlayerSkinEvent var60 = var82;
               PlayerSkinEvent var59 = var82;
               if (var83 != 0) {
                  Object[] var34 = new Object[0];
                  PlayerSkinEvent var33 = var59;
                  String var89 = var33.aReturningString(var34);
                  MinecraftClient var35 = b;
                  ClientPlayNetworkHandler var90 = var35.getNetworkHandler();
                  PlayerEntity var36 = this.g;
                  UUID var38 = var36.getUuid();
                  ClientPlayNetworkHandler var37 = var90;
                  PlayerListEntry var39 = var37.getPlayerListEntry(var38);
                  Object[] var40 = new Object[]{var39.getProfile(), 9461285330652L};
                  String var42 = RaycastUtil.aReturningString(var40);
                  String var41 = var89;
                  boolean var84 = var41.equals(var42);
                  if (!var84) {
                     return;
                  }

                  Object[] var45 = new Object[]{this.f};
                  PlayerSkinEvent var44 = var1;
                  var44.bReturningVoid(var45);
                  PlayerSkinEvent var85 = var1;
                  var60 = var85;
               }

               Object[] var48 = new Object[0];
               PlayerSkinEvent var47 = var60;
               var47.aReturningVoid(var48);
               return;
            }
         }
      }
   }

   @EventListener
   public void a(EntityNameEvent var1) {
      long var10001 = 25494703861939L ^ 42053247157917L;
      int var6 = Event.cReturningInt();
      int var69 = var6;
      PlayerEntity var68 = this.g;
      Object var62 = var68;
      PlayerEntity var61 = var68;
      if (var69 != 0) {
         PlayerEntity var70 = var61;
         if (var70 == null) {
            return;
         }

         Object[] var14 = new Object[0];
         EntityNameEvent var13 = var1;
         var62 = var13.aReturningEntity(var14);
      }

      int var72 = var6;
      Object var71 = var62;
      Object var64 = var71;
      Object var63 = var71;
      if (var72 != 0) {
         PlayerEntity var16 = this.g;
         Object var15 = var63;
         boolean var73 = ((Entity)var15).equals(var16);
         if (!var73) {
            return;
         }

         Object[] var19 = new Object[]{53947911878190L};
         EnemyFaker var18 = this;
         Pair var20 = var18.aReturningPair(var19);
         Object var74 = var20.getLeft();
         var64 = var74;
      }

      Object var22 = var64;
      String var23 = String.valueOf(var22);
      MutableText var7 = Text.literal(var23);
      short var10000 = 275;
      ModeSetting var24 = this.d;
      String var25 = (String)var24.aReturningObject();
      String var26 = var25.toString();
      MutableText var86 = Text.literal(var26);
      UnaryOperator var28 = invokeBinding1(this);
      MutableText var27 = var86;
      MutableText var8 = var27.styled(var28);
      var10001 = 6183727353507336110L;
      String var29 = " | ";
      MutableText var80 = Text.literal(var29);
      UnaryOperator var31 = invokeBinding2();
      MutableText var30 = var80;
      MutableText var9 = var30.styled(var31);
      StringSetting var32 = this.a;
      String var33 = (String)var32.aReturningObject();
      String var34 = var33.toString();
      MutableText var81 = Text.literal(var34);
      UnaryOperator var36 = invokeBinding3();
      MutableText var35 = var81;
      MutableText var10 = var35.styled(var36);
      StringSetting var37 = this.a;
      String var38 = (String)var37.aReturningObject();
      boolean var82 = var38.isEmpty();
      int var76 = var6;
      boolean var75 = var82;
      boolean var66 = var75;
      boolean var65 = var75;
      if (var76 != 0) {
         boolean var77 = var65;
         if (var77) {
            Object[] var41 = new Object[0];
            EntityNameEvent var40 = var1;
            Entity var42 = var40.aReturningEntity(var41);
            Text var43 = var42.getName();
            String var44 = var43.getString();
            MutableText var83 = Text.literal(var44);
            UnaryOperator var46 = invokeBinding4();
            MutableText var45 = var83;
            var10 = var45.styled(var46);
         }

         ModeSetting var47 = this.d;
         String var84 = (String)var47.aReturningObject();
         String var49 = "None";
         String var48 = var84;
         var66 = var48.equals(var49);
      }

      boolean var78 = var66;
      MutableText var67;
      if (var78) {
         MutableText var79 = Text.empty();
         var67 = var79;
      } else {
         MutableText var52 = var8;
         MutableText var51 = var7;
         MutableText var85 = var51.append((Text)var52);
         MutableText var54 = var9;
         MutableText var53 = var85;
         var67 = var53.append((Text)var54);
      }

      MutableText var56 = var10;
      MutableText var55 = var67;
      MutableText var11 = var55.append((Text)var56);
      Object[] var58 = new Object[]{var11};
      EntityNameEvent var57 = var1;
      var57.bReturningVoid(var58);
      Object[] var60 = new Object[0];
      EntityNameEvent var59 = var1;
      var59.aReturningVoid(var60);
   }

   @EventListener
   public void a(PlayerNameEvent var1) {
      int var4 = Event.bReturningInt();
      int var35 = var4;
      PlayerEntity var34 = this.g;
      Object var29 = var34;
      PlayerEntity var28 = var34;
      if (var35 == 0) {
         PlayerEntity var36 = var28;
         if (var36 == null) {
            return;
         }

         StringSetting var6 = this.a;
         Object var37 = var6.aReturningObject();
         var29 = var37;
      }

      PlayerNameEvent var33;
      label37: {
         String var8 = (String)var29;
         boolean var10000 = var8.isEmpty();
         int var39 = var4;
         boolean var38 = var10000;
         boolean var32 = var38;
         boolean var30 = var38;
         if (var39 == 0) {
            boolean var40 = var30;
            if (var40) {
               return;
            }

            int var42 = var4;
            PlayerNameEvent var41 = var1;
            var33 = var41;
            PlayerNameEvent var31 = var41;
            if (var42 != 0) {
               break label37;
            }

            Object[] var11 = new Object[0];
            PlayerNameEvent var10 = var31;
            String var46 = var10.bReturningString(var11);
            PlayerEntity var12 = this.g;
            Text var13 = var12.getName();
            String var15 = var13.getString();
            String var14 = var46;
            boolean var43 = var14.contains(var15);
            var32 = var43;
         }

         boolean var44 = var32;
         if (!var44) {
            return;
         }

         PlayerEntity var17 = this.g;
         Text var18 = var17.getName();
         Object[] var20 = new Object[]{var18.getString()};
         PlayerNameEvent var19 = var1;
         var19.bReturningVoid(var20);
         StringSetting var21 = this.a;
         String var22 = (String)var21.aReturningObject();
         Object[] var24 = new Object[]{var22.toString()};
         PlayerNameEvent var23 = var1;
         var23.cReturningVoid(var24);
         PlayerNameEvent var45 = var1;
         var33 = var45;
      }

      Object[] var27 = new Object[0];
      PlayerNameEvent var26 = var33;
      var26.aReturningVoid(var27);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 5987788452163L ^ 102435012933549L;
      var10001 = 5987788452163L ^ 7412687366249L;
      var10001 = 5987788452163L ^ 49301360255322L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var14 = b;
      ClientWorld var15 = var14.world;
      List var16 = var15.getPlayers();
      Iterator var11 = var16.iterator();
      int var10 = var10000;

      boolean var61;
      while (true) {
         Iterator var17 = var11;
         boolean var68 = var17.hasNext();
         if (var68) {
            Iterator var18 = var11;
            PlayerEntity var12 = (PlayerEntity)var18.next();
            MinecraftClient var19 = b;
            ClientPlayerEntity var21 = var19.player;
            PlayerEntity var20 = var12;
            boolean var94 = var20.equals(var21);
            int var70 = var10;
            boolean var69 = var94;
            var61 = var69;
            boolean var55 = var69;
            if (var70 != 0) {
               break;
            }

            label73: {
               int var72 = var10;
               boolean var71 = var55;
               boolean var58 = var71;
               boolean var56 = var71;
               if (var72 == 0) {
                  boolean var73 = var56;
                  boolean var57 = var73;
                  boolean var74 = var57;
                  if (var74) {
                     break label73;
                  }

                  PlayerEntity var24 = var12;
                  boolean var75 = var24.isDead();
                  var58 = var75;
               }

               label61: {
                  int var77 = var10;
                  boolean var76 = var58;
                  boolean var60 = var76;
                  boolean var59 = var76;
                  if (var77 == 0) {
                     boolean var78 = var59;
                     if (var78) {
                        break label61;
                     }

                     PlayerEntity var27 = var12;
                     boolean var79 = var27.isAlive();
                     var60 = var79;
                  }

                  boolean var80 = var60;
                  if (var80) {
                     break label73;
                  }
               }

               MinecraftClient var29 = b;
               ClientWorld var95 = var29.world;
               PlayerEntity var30 = var12;
               int var101 = var30.getId();
               RemovalReason var33 = RemovalReason.DISCARDED;
               int var32 = var101;
               ClientWorld var31 = var95;
               var31.removeEntity(var32, var33);
            }

            int var81 = var10;
            if (var81 == 0) {
               continue;
            }
         }

         Object[] var35 = new Object[]{97135627208430L};
         this.g = aReturningPlayerEntity(var35);
         BooleanSetting var36 = this.e;
         Boolean var37 = (Boolean)var36.aReturningObject();
         var61 = var37;
         break;
      }

      String var65;
      label74: {
         int var83 = var10;
         boolean var82 = var61;
         boolean var64 = var82;
         boolean var62 = var82;
         if (var83 == 0) {
            boolean var84 = var62;
            if (!var84) {
               return;
            }

            BooleanSetting var96 = this.e;
            Boolean var41 = false;
            BooleanSetting var40 = var96;
            var40.aReturningVoid(var41);
            StringSetting var42 = this.a;
            String var97 = (String)var42.aReturningObject();
            int var86 = var10;
            String var85 = var97;
            var65 = var85;
            String var63 = var85;
            if (var86 != 0) {
               break label74;
            }

            String var43 = var63;
            boolean var87 = var43.isEmpty();
            var64 = var87;
         }

         boolean var88 = var64;
         if (var88) {
            return;
         }

         StringSetting var45 = this.a;
         String var46 = (String)var45.aReturningObject();
         var65 = var46.toString();
      }

      Object[] var47 = new Object[]{var65, 45788546748441L};
      UUID var92 = SkinProfileUtil.aReturningUUID(var47);
      int var90 = var10;
      UUID var89 = var92;
      UUID var67 = var89;
      UUID var66 = var89;
      if (var90 == 0) {
         UUID var91 = var66;
         if (var91 == null) {
            return;
         }

         var67 = var92;
      }

      Object[] var49 = new Object[]{var67, 4190857861418L};
      GameProfile var93 = SkinProfileUtil.aReturningGameProfile(var49);
      MinecraftClient var50 = b;
      PlayerSkinProvider var98 = var50.getSkinProvider();
      GameProfile var52 = var93;
      PlayerSkinProvider var51 = var98;
      CompletableFuture var13 = var51.fetchSkinTextures(var52);
      Consumer var54 = invokeBinding5(this);
      CompletableFuture var53 = var13;
      var53.thenAccept(var54);
   }

   public static PlayerEntity aReturningPlayerEntity(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 4159416439736L ^ var1;
      long var3 = var1 ^ 1503608641426L;
      long var5 = var1 ^ 139884661418119L;
      int var10000 = Event.bReturningInt();
      Object var8 = null;
      MinecraftClient var11 = b;
      ClientWorld var12 = var11.world;
      ArrayList var13 = new ArrayList(var12.getPlayers());
      Iterator var9 = var13.iterator();
      int var7 = var10000;

      Object var53;
      while (true) {
         Iterator var14 = var9;
         boolean var54 = var14.hasNext();
         if (var54) {
            Iterator var15 = var9;
            PlayerEntity var10 = (PlayerEntity)var15.next();
            int var56 = var7;
            PlayerEntity var55 = var10;
            var53 = var55;
            PlayerEntity var41 = var55;
            if (var56 != 0) {
               break;
            }

            MinecraftClient var16 = b;
            ClientPlayerEntity var18 = var16.player;
            PlayerEntity var17 = var41;
            byte var80 = ((byte)((var17.equals(var18)) ? 1 : 0));
            int var58 = var7;
            byte var57 = var80;
            byte var44 = var57;
            byte var42 = var57;
            if (var58 == 0) {
               byte var59 = var42;
               byte var43 = var59;
               byte var60 = var43;
               if (var60 != 0) {
                  continue;
               }

               SocialsManager var81 = Prestige.g;
               PlayerEntity var21 = var10;
               Text var22 = var21.getName();
               Object[] var24 = new Object[]{var22.getString(), var5};
               SocialsManager var23 = var81;
               var44 = ((byte)((var23.aReturningBoolean(var24)) ? 1 : 0));
            }

            int var62 = var7;
            byte var61 = var44;
            int var46 = var61;
            byte var45 = var61;
            if (var62 == 0) {
               byte var63 = var45;
               if (var63 != 0) {
                  continue;
               }

               PlayerEntity var26 = var10;
               Text var27 = var26.getName();
               String var28 = var27.getString();
               var46 = var28.length();
            }

            int var65 = var7;
            int var64 = var46;
            int var48 = var64;
            int var47 = var64;
            if (var65 == 0) {
               byte var67 = 3;
               int var66 = var47;
               if (var66 < var67) {
                  continue;
               }

               PlayerValidationTracker var82 = Prestige.i;
               Object[] var31 = new Object[]{var10, var3};
               PlayerValidationTracker var30 = var82;
               var48 = (((var30.aReturningBoolean(var31)) ? 1 : 0));
            }

            int var68 = var48;
            if (var68 == 0) {
               int var69 = var7;
               if (var69 == 0) {
                  continue;
               }
            }

            label55: {
               Object var52;
               int var71 = var7;
               Object var70 = var8;
               var52 = var70;
               Object var49 = var70;
               label54:
               if (var71 == 0) {
                  Object var72 = var49;
                  if (var72 != null) {
                     MinecraftClient var34 = b;
                     int var74 = var7;
                     ClientPlayerEntity var73 = var34.player;
                     var52 = var73;
                     ClientPlayerEntity var50 = var73;
                     if (var74 != 0) {
                        break label54;
                     }

                     ClientPlayerEntity var75 = var50;
                     ClientPlayerEntity var51 = var75;
                     PlayerEntity var37 = var10;
                     ClientPlayerEntity var36 = var51;
                     double var83 = var36.squaredDistanceTo((Entity)var37);
                     MinecraftClient var38 = b;
                     Object var40 = var8;
                     ClientPlayerEntity var39 = var38.player;
                     double var84;
                     int var76 = (var84 = var83 - var39.squaredDistanceTo((Entity)var40)) == 0.0 ? 0 : (var84 < 0.0 ? -1 : 1);
                     if (var76 >= 0) {
                        break label55;
                     }
                  }

                  PlayerEntity var77 = var10;
                  var52 = var77;
               }

               var8 = var52;
            }

            int var78 = var7;
            if (var78 == 0) {
               continue;
            }
         }

         var53 = var8;
         break;
      }

      return (PlayerEntity)var53;
   }

   private static int aReturningInt(Object[] var0) {
      int var4;
      int var68;
      long var137;
      String var1 = (String)var0[0];
      var137 = (Long)var0[1];
      var137 = 4159416439736L ^ var137;
      String var5 = var1;
      int var10000 = Event.bReturningInt();
      // var4 = var10000;
      String var7 = var5;
      var10000 = var7.hashCode();
      int var73 = var4;
      int var72 = var10000;
      var68 = var72;
      int var47 = var72;
      label130:
      if (var73 == 0) {
         int var74 = var47;
         switch (var74) {
            case 71845:
               short var10001 = 19221;
               long var10002 = 9005501276553042835L ^ var137;
               String var10 = "HT1";
               String var9 = var5;
               byte var139 = ((byte)((var9.equals(var10)) ? 1 : 0));
               int var76 = var4;
               byte var75 = var139;
               var68 = var75;
               byte var48 = var75;
               if (var76 != 0) {
                  break label130;
               }

               byte var77 = var48;
               byte var49 = var77;
               byte var78 = var49;
               if (var78 == 0) {
                  break;
               }

               var6 = 0;
               int var79 = var4;
               if (var79 == 0) {
                  break;
               }
            case 75689:
               short var164 = 20554;
               long var188 = 891977971545686230L ^ var137;
               String var14 = "LT1";
               String var13 = var5;
               byte var140 = ((byte)((var13.equals(var14)) ? 1 : 0));
               int var81 = var4;
               byte var80 = var140;
               var68 = var80;
               byte var50 = var80;
               if (var81 != 0) {
                  break label130;
               }

               byte var82 = var50;
               byte var51 = var82;
               byte var83 = var51;
               if (var83 == 0) {
                  break;
               }

               var6 = 1;
               int var84 = var4;
               if (var84 == 0) {
                  break;
               }
            case 71846:
               short var165 = 10007;
               long var189 = 5141074800402839471L ^ var137;
               String var18 = "HT2";
               String var17 = var5;
               byte var141 = ((byte)((var17.equals(var18)) ? 1 : 0));
               int var86 = var4;
               byte var85 = var141;
               var68 = var85;
               byte var52 = var85;
               if (var86 != 0) {
                  break label130;
               }

               byte var87 = var52;
               byte var53 = var87;
               byte var88 = var53;
               if (var88 == 0) {
                  break;
               }

               var6 = 2;
               int var89 = var4;
               if (var89 == 0) {
                  break;
               }
            case 75690:
               short var166 = 28926;
               long var190 = 425940546428985449L ^ var137;
               String var22 = "LT2";
               String var21 = var5;
               byte var142 = ((byte)((var21.equals(var22)) ? 1 : 0));
               int var91 = var4;
               byte var90 = var142;
               var68 = var90;
               byte var54 = var90;
               if (var91 != 0) {
                  break label130;
               }

               byte var92 = var54;
               byte var55 = var92;
               byte var93 = var55;
               if (var93 == 0) {
                  break;
               }

               var6 = 3;
               int var94 = var4;
               if (var94 == 0) {
                  break;
               }
            case 71847:
               short var167 = 15015;
               long var191 = 8703647885636381239L ^ var137;
               String var26 = "HT3";
               String var25 = var5;
               byte var143 = ((byte)((var25.equals(var26)) ? 1 : 0));
               int var96 = var4;
               byte var95 = var143;
               var68 = var95;
               byte var56 = var95;
               if (var96 != 0) {
                  break label130;
               }

               byte var97 = var56;
               byte var57 = var97;
               byte var98 = var57;
               if (var98 == 0) {
                  break;
               }

               var6 = 4;
               int var99 = var4;
               if (var99 == 0) {
                  break;
               }
            case 75691:
               short var168 = 2012;
               long var192 = 3667941185886295887L ^ var137;
               String var30 = "LT3";
               String var29 = var5;
               byte var144 = ((byte)((var29.equals(var30)) ? 1 : 0));
               int var101 = var4;
               byte var100 = var144;
               var68 = var100;
               byte var58 = var100;
               if (var101 != 0) {
                  break label130;
               }

               byte var102 = var58;
               byte var59 = var102;
               byte var103 = var59;
               if (var103 == 0) {
                  break;
               }

               var6 = 5;
               int var104 = var4;
               if (var104 == 0) {
                  break;
               }
            case 71848:
               short var169 = 3840;
               long var193 = 1256092641395253150L ^ var137;
               String var34 = "HT4";
               String var33 = var5;
               short var145 = ((short)((var33.equals(var34)) ? 1 : 0));
               int var106 = var4;
               byte var105 = (byte)var145;
               var68 = var105;
               byte var60 = var105;
               if (var106 != 0) {
                  break label130;
               }

               byte var107 = var60;
               byte var61 = var107;
               byte var108 = var61;
               if (var108 == 0) {
                  break;
               }

               var145 = 3506;
               long var170 = 2805773498940641783L ^ var137;
               var6 = 6;
               int var109 = var4;
               if (var109 == 0) {
                  break;
               }
            case 75692:
               short var171 = 31741;
               long var194 = 4060689123622677352L ^ var137;
               String var38 = "LT4";
               String var37 = var5;
               short var147 = ((short)((var37.equals(var38)) ? 1 : 0));
               int var111 = var4;
               byte var110 = (byte)var147;
               var68 = var110;
               byte var62 = var110;
               if (var111 != 0) {
                  break label130;
               }

               byte var112 = var62;
               byte var63 = var112;
               byte var113 = var63;
               if (var113 == 0) {
                  break;
               }

               var147 = 25336;
               long var172 = 679327777776451241L ^ var137;
               var6 = 7;
               int var114 = var4;
               if (var114 == 0) {
                  break;
               }
            case 71849:
               short var173 = 14026;
               long var195 = 135542371162105438L ^ var137;
               String var42 = "HT5";
               String var41 = var5;
               short var149 = ((short)((var41.equals(var42)) ? 1 : 0));
               int var116 = var4;
               byte var115 = (byte)var149;
               var68 = var115;
               byte var64 = var115;
               if (var116 != 0) {
                  break label130;
               }

               byte var117 = var64;
               byte var65 = var117;
               byte var118 = var65;
               if (var118 == 0) {
                  break;
               }

               var149 = 11452;
               long var174 = 586870320809341133L ^ var137;
               var6 = 8;
               int var119 = var4;
               if (var119 == 0) {
                  break;
               }
            case 75693:
               short var175 = 19647;
               long var196 = 2256438885754428465L ^ var137;
               String var46 = "LT5";
               String var45 = var5;
               short var151 = ((short)((var45.equals(var46)) ? 1 : 0));
               int var121 = var4;
               byte var120 = (byte)var151;
               var68 = var120;
               byte var66 = var120;
               if (var121 != 0) {
                  break label130;
               }

               byte var122 = var66;
               byte var67 = var122;
               byte var123 = var67;
               if (var123 != 0) {
                  var151 = 25388;
                  long var176 = 5628709895121813363L ^ var137;
                  var6 = 9;
               }
         }

         var68 = var6;
      }

      int var125 = var4;
      int var124 = var68;
      int var70 = var124;
      int var69 = var124;
      if (var125 == 0) {
         int var126 = var69;
         switch (var126) {
            case 0:
               short var163 = 18285;
               long var187 = 3081553144881453848L ^ var137;
               var70 = 15252026;
               break;
            case 1:
               short var162 = 30859;
               long var186 = 1260814064364659932L ^ var137;
               return 14005077;
            case 2:
               short var161 = 8093;
               long var185 = 4546774739570574287L ^ var137;
               return 12899303;
            case 3:
               short var160 = 29534;
               long var184 = 621804216628522782L ^ var137;
               return 10528690;
            case 4:
               short var159 = 26173;
               long var183 = 7863606559609305702L ^ var137;
               return 16293722;
            case 5:
               short var158 = 16486;
               long var182 = 6503342215043456062L ^ var137;
               return 13007682;
            case 6:
               short var157 = 16612;
               long var181 = 1732953709720312966L ^ var137;
               return 8483994;
            case 7:
               short var156 = 22933;
               long var180 = 1366520294291375577L ^ var137;
               return 6642553;
            case 8:
               short var155 = 14420;
               long var179 = 5484802605792322607L ^ var137;
               return 9405096;
            case 9:
               short var154 = 23721;
               long var178 = 3979917271763091662L ^ var137;
               return 6642553;
            default:
               short var153 = 16263;
               long var177 = 7653132832199730116L ^ var137;
               return 13882323;
         }
      }

      return var70;
   }

   private Pair aReturningPair(Object[] var1) {
      int var181;
      long var311;
      var311 = (Long)var1[0];
      var311 = 4159416439736L ^ var311;
      int var10000 = Event.bReturningInt();
      StringSetting var7 = this.c;
      String var8 = (String)var7.aReturningObject();
      String var5 = var8.toLowerCase();
      // int var4 = var10000;
      String var9 = var5;
      var10000 = var9.hashCode();
      int var184 = var4;
      int var183 = var10000;
      var181 = var183;
      int var138 = var183;
      label245:
      if (var184 == 0) {
         int var185 = var138;
         switch (var185) {
            case 97038:
               short var10001 = 20905;
               long var10002 = 2759212661854845595L ^ var311;
               String var12 = "axe";
               String var11 = var5;
               byte var313 = ((byte)((var11.equals(var12)) ? 1 : 0));
               int var187 = var4;
               byte var186 = var313;
               var181 = var186;
               byte var139 = var186;
               if (var187 != 0) {
                  break label245;
               }

               byte var188 = var139;
               byte var140 = var188;
               byte var189 = var140;
               if (var189 == 0) {
                  break;
               }

               var6 = 0;
               int var190 = var4;
               if (var190 == 0) {
                  break;
               }
            case 3343606:
               short var349 = 22645;
               long var384 = 8038245308177101641L ^ var311;
               String var16 = "mace";
               String var15 = var5;
               byte var314 = ((byte)((var15.equals(var16)) ? 1 : 0));
               int var192 = var4;
               byte var191 = var314;
               var181 = var191;
               byte var141 = var191;
               if (var192 != 0) {
                  break label245;
               }

               byte var193 = var141;
               byte var142 = var193;
               byte var194 = var142;
               if (var194 == 0) {
                  break;
               }

               var6 = 1;
               int var195 = var4;
               if (var195 == 0) {
                  break;
               }
            case -1048925812:
               short var350 = 19519;
               long var385 = 5087980347885102866L ^ var311;
               String var20 = "nethop";
               String var19 = var5;
               byte var315 = ((byte)((var19.equals(var20)) ? 1 : 0));
               int var197 = var4;
               byte var196 = var315;
               var181 = var196;
               byte var143 = var196;
               if (var197 != 0) {
                  break label245;
               }

               byte var198 = var143;
               byte var144 = var198;
               byte var199 = var144;
               if (var199 == 0) {
                  break;
               }

               var6 = 2;
               int var200 = var4;
               if (var200 == 0) {
                  break;
               }
            case 1299136129:
               short var351 = 13077;
               long var386 = 6039591626756937788L ^ var311;
               String var24 = "neth_pot";
               String var23 = var5;
               byte var316 = ((byte)((var23.equals(var24)) ? 1 : 0));
               int var202 = var4;
               byte var201 = var316;
               var181 = var201;
               byte var145 = var201;
               if (var202 != 0) {
                  break label245;
               }

               byte var203 = var145;
               byte var146 = var203;
               byte var204 = var146;
               if (var204 == 0) {
                  break;
               }

               var6 = 3;
               int var205 = var4;
               if (var205 == 0) {
                  break;
               }
            case 111189:
               short var352 = 8085;
               long var387 = 3331984881235260597L ^ var311;
               String var28 = "pot";
               String var27 = var5;
               byte var317 = ((byte)((var27.equals(var28)) ? 1 : 0));
               int var207 = var4;
               byte var206 = var317;
               var181 = var206;
               byte var147 = var206;
               if (var207 != 0) {
                  break label245;
               }

               byte var208 = var147;
               byte var148 = var208;
               byte var209 = var148;
               if (var209 == 0) {
                  break;
               }

               var6 = 4;
               int var210 = var4;
               if (var210 == 0) {
                  break;
               }
            case 114006:
               short var353 = 4864;
               long var388 = 7955851184651892799L ^ var311;
               String var32 = "smp";
               String var31 = var5;
               byte var318 = ((byte)((var31.equals(var32)) ? 1 : 0));
               int var212 = var4;
               byte var211 = var318;
               var181 = var211;
               byte var149 = var211;
               if (var212 != 0) {
                  break label245;
               }

               byte var213 = var149;
               byte var150 = var213;
               byte var214 = var150;
               if (var214 == 0) {
                  break;
               }

               var6 = 5;
               int var215 = var4;
               if (var215 == 0) {
                  break;
               }
            case 109860349:
               short var354 = 5938;
               long var389 = 69709892338646079L ^ var311;
               String var36 = "sword";
               String var35 = var5;
               short var319 = ((short)((var35.equals(var36)) ? 1 : 0));
               int var217 = var4;
               byte var216 = (byte)var319;
               var181 = var216;
               byte var151 = var216;
               if (var217 != 0) {
                  break label245;
               }

               byte var218 = var151;
               byte var152 = var218;
               byte var219 = var152;
               if (var219 == 0) {
                  break;
               }

               var319 = 19174;
               long var355 = 7306441925806288173L ^ var311;
               var6 = 6;
               int var220 = var4;
               if (var220 == 0) {
                  break;
               }
            case 115760:
               short var356 = 13832;
               long var390 = 1345938329463971079L ^ var311;
               String var40 = "uhc";
               String var39 = var5;
               short var321 = ((short)((var39.equals(var40)) ? 1 : 0));
               int var222 = var4;
               byte var221 = (byte)var321;
               var181 = var221;
               byte var153 = var221;
               if (var222 != 0) {
                  break label245;
               }

               byte var223 = var153;
               byte var154 = var223;
               byte var224 = var154;
               if (var224 == 0) {
                  break;
               }

               var321 = 10759;
               long var357 = 522580239992819153L ^ var311;
               var6 = 7;
               int var225 = var4;
               if (var225 == 0) {
                  break;
               }
            case 233102203:
               short var358 = 20155;
               long var391 = 242464967874848141L ^ var311;
               String var44 = "vanilla";
               String var43 = var5;
               short var323 = ((short)((var43.equals(var44)) ? 1 : 0));
               int var227 = var4;
               byte var226 = (byte)var323;
               var181 = var226;
               byte var155 = var226;
               if (var227 != 0) {
                  break label245;
               }

               byte var228 = var155;
               byte var156 = var228;
               byte var229 = var156;
               if (var229 == 0) {
                  break;
               }

               var323 = 27277;
               long var359 = 5740811900221345100L ^ var311;
               var6 = 8;
               int var230 = var4;
               if (var230 == 0) {
                  break;
               }
            case 97409:
               short var360 = 15915;
               long var392 = 1400759173413524758L ^ var311;
               String var48 = "bed";
               String var47 = var5;
               short var325 = ((short)((var47.equals(var48)) ? 1 : 0));
               int var232 = var4;
               byte var231 = (byte)var325;
               var181 = var231;
               byte var157 = var231;
               if (var232 != 0) {
                  break label245;
               }

               byte var233 = var157;
               byte var158 = var233;
               byte var234 = var158;
               if (var234 == 0) {
                  break;
               }

               var325 = 12701;
               long var361 = 8499583062617265760L ^ var311;
               var6 = 9;
               int var235 = var4;
               if (var235 == 0) {
                  break;
               }
            case 97738:
               short var362 = 11840;
               long var393 = 2887936160805471611L ^ var311;
               String var52 = "bow";
               String var51 = var5;
               short var327 = ((short)((var51.equals(var52)) ? 1 : 0));
               int var237 = var4;
               byte var236 = (byte)var327;
               var181 = var236;
               byte var159 = var236;
               if (var237 != 0) {
                  break label245;
               }

               byte var238 = var159;
               byte var160 = var238;
               byte var239 = var160;
               if (var239 == 0) {
                  break;
               }

               var327 = 8660;
               long var363 = 9157530527151326728L ^ var311;
               var6 = 10;
               int var240 = var4;
               if (var240 == 0) {
                  break;
               }
            case 1028669806:
               short var364 = 27005;
               long var394 = 6465557467602387534L ^ var311;
               String var56 = "creeper";
               String var55 = var5;
               short var329 = ((short)((var55.equals(var56)) ? 1 : 0));
               int var242 = var4;
               byte var241 = (byte)var329;
               var181 = var241;
               byte var161 = var241;
               if (var242 != 0) {
                  break label245;
               }

               byte var243 = var161;
               byte var162 = var243;
               byte var244 = var162;
               if (var244 == 0) {
                  break;
               }

               var329 = 15486;
               long var365 = 2687186831485672376L ^ var311;
               var6 = 11;
               int var245 = var4;
               if (var245 == 0) {
                  break;
               }
            case -1335741356:
               short var366 = 26084;
               long var395 = 7083457565067808467L ^ var311;
               String var60 = "debuff";
               String var59 = var5;
               short var331 = ((short)((var59.equals(var60)) ? 1 : 0));
               int var247 = var4;
               byte var246 = (byte)var331;
               var181 = var246;
               byte var163 = var246;
               if (var247 != 0) {
                  break label245;
               }

               byte var248 = var163;
               byte var164 = var248;
               byte var249 = var164;
               if (var249 == 0) {
                  break;
               }

               var331 = 31757;
               long var367 = 9146863361169284056L ^ var311;
               var6 = 12;
               int var250 = var4;
               if (var250 == 0) {
                  break;
               }
            case 1415803507:
               short var368 = 2760;
               long var396 = 8880079424383869415L ^ var311;
               String var64 = "dia_crystal";
               String var63 = var5;
               short var333 = ((short)((var63.equals(var64)) ? 1 : 0));
               int var252 = var4;
               byte var251 = (byte)var333;
               var181 = var251;
               byte var165 = var251;
               if (var252 != 0) {
                  break label245;
               }

               byte var253 = var165;
               byte var166 = var253;
               byte var254 = var166;
               if (var254 == 0) {
                  break;
               }

               var333 = 10413;
               long var369 = 8657156091049709412L ^ var311;
               var6 = 13;
               int var255 = var4;
               if (var255 == 0) {
                  break;
               }
            case 1654641427:
               short var370 = 27442;
               long var397 = 568812588659965964L ^ var311;
               String var68 = "dia_smp";
               String var67 = var5;
               short var335 = ((short)((var67.equals(var68)) ? 1 : 0));
               int var257 = var4;
               byte var256 = (byte)var335;
               var181 = var256;
               byte var167 = var256;
               if (var257 != 0) {
                  break label245;
               }

               byte var258 = var167;
               byte var168 = var258;
               byte var259 = var168;
               if (var259 == 0) {
                  break;
               }

               var335 = 6510;
               long var371 = 1373468104987819653L ^ var311;
               var6 = 14;
               int var260 = var4;
               if (var260 == 0) {
                  break;
               }
            case -1299962959:
               short var372 = 2442;
               long var398 = 1993759130389078694L ^ var311;
               String var72 = "elytra";
               String var71 = var5;
               short var337 = ((short)((var71.equals(var72)) ? 1 : 0));
               int var262 = var4;
               byte var261 = (byte)var337;
               var181 = var261;
               byte var169 = var261;
               if (var262 != 0) {
                  break label245;
               }

               byte var263 = var169;
               byte var170 = var263;
               byte var264 = var170;
               if (var264 == 0) {
                  break;
               }

               var337 = 32129;
               long var373 = 7782451738897570414L ^ var311;
               var6 = 15;
               int var265 = var4;
               if (var265 == 0) {
                  break;
               }
            case 835482605:
               short var374 = 22227;
               long var399 = 4536311858873089511L ^ var311;
               String var76 = "manhunt";
               String var75 = var5;
               short var339 = ((short)((var75.equals(var76)) ? 1 : 0));
               int var267 = var4;
               byte var266 = (byte)var339;
               var181 = var266;
               byte var171 = var266;
               if (var267 != 0) {
                  break label245;
               }

               byte var268 = var171;
               byte var172 = var268;
               byte var269 = var172;
               if (var269 == 0) {
                  break;
               }

               var339 = 9681;
               long var375 = 1782811844713677342L ^ var311;
               var6 = 16;
               int var270 = var4;
               if (var270 == 0) {
                  break;
               }
            case -1363067405:
               short var376 = 4432;
               long var400 = 6543496173366770277L ^ var311;
               String var80 = "minecart";
               String var79 = var5;
               short var341 = ((short)((var79.equals(var80)) ? 1 : 0));
               int var272 = var4;
               byte var271 = (byte)var341;
               var181 = var271;
               byte var173 = var271;
               if (var272 != 0) {
                  break label245;
               }

               byte var273 = var173;
               byte var174 = var273;
               byte var274 = var174;
               if (var274 == 0) {
                  break;
               }

               var341 = 32629;
               long var377 = 8218947335997544597L ^ var311;
               var6 = 17;
               int var275 = var4;
               if (var275 == 0) {
                  break;
               }
            case 768948244:
               short var378 = 8308;
               long var401 = 8735912296714324814L ^ var311;
               String var84 = "og_vanilla";
               String var83 = var5;
               short var343 = ((short)((var83.equals(var84)) ? 1 : 0));
               int var277 = var4;
               byte var276 = (byte)var343;
               var181 = var276;
               byte var175 = var276;
               if (var277 != 0) {
                  break label245;
               }

               byte var278 = var175;
               byte var176 = var278;
               byte var279 = var176;
               if (var279 == 0) {
                  break;
               }

               var343 = 14421;
               long var379 = 3842500935146217395L ^ var311;
               var6 = 18;
               int var280 = var4;
               if (var280 == 0) {
                  break;
               }
            case 109641799:
               short var380 = 2123;
               long var402 = 3809069458192917359L ^ var311;
               String var88 = "speed";
               String var87 = var5;
               short var345 = ((short)((var87.equals(var88)) ? 1 : 0));
               int var282 = var4;
               byte var281 = (byte)var345;
               var181 = var281;
               byte var177 = var281;
               if (var282 != 0) {
                  break label245;
               }

               byte var283 = var177;
               byte var178 = var283;
               byte var284 = var178;
               if (var284 == 0) {
                  break;
               }

               var345 = 27981;
               long var381 = 5862121837305875123L ^ var311;
               var6 = 19;
               int var285 = var4;
               if (var285 == 0) {
                  break;
               }
            case -1059982798:
               short var382 = 28534;
               long var403 = 7401220478655038543L ^ var311;
               String var92 = "trident";
               String var91 = var5;
               short var347 = ((short)((var91.equals(var92)) ? 1 : 0));
               int var287 = var4;
               byte var286 = (byte)var347;
               var181 = var286;
               byte var179 = var286;
               if (var287 != 0) {
                  break label245;
               }

               byte var288 = var179;
               byte var180 = var288;
               byte var289 = var180;
               if (var289 != 0) {
                  var347 = 390;
                  long var383 = 1514380356867892802L ^ var311;
                  var6 = 20;
               }
         }

         var181 = var6;
      }

      int var290 = var181;
      Pair var182;
      switch (var290) {
         case 0:
            short var444 = 3672;
            long var475 = 7442919102384613818L ^ var311;
            Character var445 = '\ue701';
            Formatting var96 = Formatting.GREEN;
            Pair var291 = new Pair(var445, TextColor.fromFormatting(var96));
            var182 = var291;
            break;
         case 1:
            short var442 = 12605;
            long var474 = 8944763855965984487L ^ var311;
            Character var443 = '\ue702';
            Formatting var99 = Formatting.GRAY;
            Pair var292 = new Pair(var443, TextColor.fromFormatting(var99));
            var182 = var292;
            break;
         case 2:
         case 3:
            short var440 = 409;
            long var472 = 7946189725254461013L ^ var311;
            Character var441 = '\ue703';
            short var473 = 9934;
            long var484 = 7339482372993057038L ^ var311;
            Pair var293 = new Pair(var441, TextColor.fromRgb(8211008));
            var182 = var293;
            break;
         case 4:
            short var438 = 132;
            long var470 = 8237032397262464886L ^ var311;
            Character var439 = '\ue704';
            short var471 = 19524;
            long var483 = 1740246746895739827L ^ var311;
            Pair var294 = new Pair(var439, TextColor.fromRgb(16711680));
            var182 = var294;
            break;
         case 5:
            short var436 = 196;
            long var468 = 793799340079785738L ^ var311;
            Character var437 = '\ue705';
            short var469 = 6660;
            long var482 = 5051534928979246550L ^ var311;
            Pair var295 = new Pair(var437, TextColor.fromRgb(15518533));
            var182 = var295;
            break;
         case 6:
            short var434 = 11831;
            long var466 = 8989552591241349595L ^ var311;
            Character var435 = '\ue706';
            short var467 = 4281;
            long var481 = 6870910853698533226L ^ var311;
            Pair var296 = new Pair(var435, TextColor.fromRgb(10812912));
            var182 = var296;
            break;
         case 7:
            short var432 = 21718;
            long var465 = 4313395339028689673L ^ var311;
            Character var433 = '\ue707';
            Formatting var109 = Formatting.RED;
            Pair var297 = new Pair(var433, TextColor.fromFormatting(var109));
            var182 = var297;
            break;
         case 8:
            short var430 = 22282;
            long var464 = 2125433437165547712L ^ var311;
            Character var431 = '\ue708';
            Formatting var111 = Formatting.LIGHT_PURPLE;
            Pair var298 = new Pair(var431, TextColor.fromFormatting(var111));
            var182 = var298;
            break;
         case 9:
            short var428 = 24635;
            long var462 = 39713049406195659L ^ var311;
            Character var429 = '\ue801';
            short var463 = 16883;
            long var480 = 8506392663326483976L ^ var311;
            Pair var299 = new Pair(var429, TextColor.fromRgb(16711680));
            var182 = var299;
            break;
         case 10:
            short var426 = 30178;
            long var460 = 5812914845722235399L ^ var311;
            Character var427 = '\ue802';
            short var461 = 24679;
            long var479 = 1624101911106668443L ^ var311;
            Pair var300 = new Pair(var427, TextColor.fromRgb(6700304));
            var182 = var300;
            break;
         case 11:
            short var424 = 16666;
            long var459 = 5258968841896617712L ^ var311;
            Character var425 = '\ue803';
            Formatting var117 = Formatting.GREEN;
            Pair var301 = new Pair(var425, TextColor.fromFormatting(var117));
            var182 = var301;
            break;
         case 12:
            short var422 = 29483;
            long var458 = 1931807228783023342L ^ var311;
            Character var423 = '\ue804';
            Formatting var119 = Formatting.DARK_GRAY;
            Pair var302 = new Pair(var423, TextColor.fromFormatting(var119));
            var182 = var302;
            break;
         case 13:
            short var420 = 3525;
            long var457 = 8086749940465609254L ^ var311;
            Character var421 = '\ue805';
            Formatting var121 = Formatting.AQUA;
            Pair var303 = new Pair(var421, TextColor.fromFormatting(var121));
            var182 = var303;
            break;
         case 14:
            short var418 = 5301;
            long var455 = 1486459482815148919L ^ var311;
            Character var419 = '\ue806';
            short var456 = 23339;
            long var478 = 1346026472528772306L ^ var311;
            Pair var304 = new Pair(var419, TextColor.fromRgb(9201291));
            var182 = var304;
            break;
         case 15:
            short var416 = 30224;
            long var453 = 1756538131747951047L ^ var311;
            Character var417 = '\ue807';
            short var454 = 30980;
            long var477 = 556938956394815193L ^ var311;
            Pair var305 = new Pair(var417, TextColor.fromRgb(9276849));
            var182 = var305;
            break;
         case 16:
            short var414 = 3023;
            long var452 = 3271447659019709499L ^ var311;
            Character var415 = '\ue808';
            Formatting var127 = Formatting.RED;
            Pair var306 = new Pair(var415, TextColor.fromFormatting(var127));
            var182 = var306;
            break;
         case 17:
            short var412 = 18845;
            long var451 = 5524246981140409941L ^ var311;
            Character var413 = '\ue809';
            Formatting var129 = Formatting.GRAY;
            Pair var307 = new Pair(var413, TextColor.fromFormatting(var129));
            var182 = var307;
            break;
         case 18:
            short var410 = 16062;
            long var450 = 3573054173067811168L ^ var311;
            Character var411 = '\ue810';
            Formatting var131 = Formatting.GOLD;
            Pair var308 = new Pair(var411, TextColor.fromFormatting(var131));
            var182 = var308;
            break;
         case 19:
            short var408 = 31357;
            long var448 = 3452989522019540357L ^ var311;
            Character var409 = '\ue811';
            short var449 = 24873;
            long var476 = 4920717273445222081L ^ var311;
            Pair var309 = new Pair(var409, TextColor.fromRgb(4434385));
            var182 = var309;
            break;
         case 20:
            short var406 = 17713;
            long var446 = 6600039241118016192L ^ var311;
            Character var407 = '\ue812';
            short var447 = 24538;
            long var10004 = 2414156315529443338L ^ var311;
            Pair var310 = new Pair(var407, TextColor.fromRgb(5741452));
            var182 = var310;
            break;
         default:
            short var404 = 6202;
            long var10003 = 2178264401104650181L ^ var311;
            Character var405 = '•';
            Formatting var137 = Formatting.WHITE;
            var182 = new Pair(var405, TextColor.fromFormatting(var137));
      }

      return var182;
   }

   private void lambda$onTick$4(Optional var1) {
      label17: {
         int var4 = Event.cReturningInt();
         int var20 = var4;
         if (var20 != 0) {
            Optional var5 = var1;
            boolean var21 = var5.isPresent();
            if (!var21) {
               break label17;
            }

            Optional var7 = var1;
            this.f = (SkinTextures)var7.get();
            MinecraftClient var8 = b;
            ClientPlayerEntity var10000 = var8.player;
            StringSetting var9 = this.a;
            String var10 = "Fake skin updated to: " + (String)var9.aReturningObject();
            Text var12 = Text.of(var10);
            ClientPlayerEntity var11 = var10000;
            var11.sendMessage(var12, false);
         }

         int var22 = var4;
         if (var22 != 0) {
            return;
         }
      }

      MinecraftClient var15 = b;
      ClientPlayerEntity var23 = var15.player;
      StringSetting var16 = this.a;
      String var17 = "Failed to fetch skin for: " + (String)var16.aReturningObject();
      Text var19 = Text.of(var17);
      ClientPlayerEntity var18 = var23;
      var18.sendMessage(var19, false);
   }

   private static Style lambda$onLabel$3(Style var0) {
      Formatting var4 = Formatting.WHITE;
      Style var3 = var0;
      return var3.withFormatting(var4);
   }

   private static Style lambda$onLabel$2(Style var0) {
      Formatting var4 = Formatting.WHITE;
      Style var3 = var0;
      return var3.withFormatting(var4);
   }

   private static Style lambda$onLabel$1(Style var0) {
      Formatting var4 = Formatting.GRAY;
      Style var3 = var0;
      return var3.withColor(var4);
   }

   private Style lambda$onLabel$0(Style var1) {
      long var10001 = 27726384895211L ^ 88686855051635L;
      ModeSetting var6 = this.d;
      String var7 = (String)var6.aReturningObject();
      Object[] var8 = new Object[]{var7.toString(), 80945255239064L};
      int var10 = aReturningInt(var8);
      Style var9 = var1;
      return var9.withColor(var10);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(12790036125057L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[35];
      String var17 = "\u0016úahaà©3\u0002\"§Î/á9ð\u0092û\u000f@\u0089_\u0007\u001böÕO\u0012\u0001é/§(gÔ©\u001a¯k\u0090oÏ.\bM(\u0080<\u009e¸\u009a$\u0098s°¤©\u0012\u0012e\u009b¿Ö}\u0081XMÕ´V}v\u009c\u00105\u009dÏ\u001aÕ\rÈ#½\u0011ÙqmVá\u001f\u0010,Wü\u0087lÔÝ:\u009d|X\u0018Ùq¥ð\u0010Ö\u009d×øû1\u0003à\u0007.\u0081í\u009eLa\u009f\u0010\u0011s@3´ÉÌx¶\u0093½#gËÿ¥\u0018W:÷\u0092¡\u008cï\u001a\u0019Ò(\u0087¤ò\u0017ã!=Ï\u0016fV\r\u0005\u0010|\u0097)¥²\u009cµ%TnÜÚy\u001dWd\u0010y\nÊZ\u0010B\u0001ò3r]\u0017Îi\u009a$\u0010aå\u001c\u0080\u0081¨ÙJRJ\u0097\u0006\u0090+\u0089g\u0010ä¡¢m»\u0089·ü\u00ad\n:\u00adw\u0010ÿ\u009f\u0010F\u001f\\\u0014\u000f\u000eD 4\u0099N\u0000\u00adùÛr\u0010\u001cïP¾Oú&Ù¨hk\u008773_7\u0010ï:Xúq/\u001c\u001a®Ú_Æ\u008bçG\"\u0010G½P\u001c$ðI\u0017ü\u0015èÎ\u0089Ø4n\u0010Øà\u0017\u0014¹²\u0095@\u0089\u0082q½\u0010Þ\u0002²\u0010\u0012\u0094c§×ðø2{Ok,xã\"\u009f\u0010³h,j\t Ñ\u0087à\u009búÆÁ`\u0019b\u0010Y`X;úëQö\u0096Õ\u009f\u0013*4µ¾\u0010kÐ\u0093þ1¾Ê-D\u0012\u008e>x£!´\u0010U ¢~û\u008f\u0007 e5Êº³ö4ø\u0018\u001f®°w>\u0010\u009c\u008f'3-h\u0005\\4E[d\u0090ü1Væ\u0093\u00101\u0007\u00040]\u0085\u0003\u0011yM¿es\t\u001aÆ\u0010\u0005ñÃ½\u0016¾ð|Z\u0089\u008e9á\u0015¿¿\u0010\u0003P\tõ[\u000e×AOÖ\u0007*òOx%\u0010\u0001ý\u00ad¼'\u009càa¨øYñ\u009dÑ@\u0016 \u0013\u0098ÏbdF?\u0088C<Ò±0¼&ðñ1&7HÁ\u0004\u0000.\u0083²$\"\u001e/M\u0010\u0086É¯GÂi\u001f\u0080µ¸\u0083\u0019\u0083V\u0002»\u0010ÿÿ\\èl.É\tþõ¶2\u000f8g¹\u0010$WÕõ\tk\u0016.²¥¶\u008cHÌàæ0\u009apd=~Î¨°ù_\u0090É\u0016\u0082°¤ÀmVØT\u0098\u008e/Lå\u0000!4\u008f)â\u000bîSê\u0086Ö|\u0086.Úð\u001a0\u001dÈ³\u0010\u0012\\ëZ\u001de\u0014kU\u0098/{«Í\u0001\u0089\u0010D§á÷Tzz\"à\u0086\u001a>°B¥4";
      int var19 = "\u0016úahaà©3\u0002\"§Î/á9ð\u0092û\u000f@\u0089_\u0007\u001böÕO\u0012\u0001é/§(gÔ©\u001a¯k\u0090oÏ.\bM(\u0080<\u009e¸\u009a$\u0098s°¤©\u0012\u0012e\u009b¿Ö}\u0081XMÕ´V}v\u009c\u00105\u009dÏ\u001aÕ\rÈ#½\u0011ÙqmVá\u001f\u0010,Wü\u0087lÔÝ:\u009d|X\u0018Ùq¥ð\u0010Ö\u009d×øû1\u0003à\u0007.\u0081í\u009eLa\u009f\u0010\u0011s@3´ÉÌx¶\u0093½#gËÿ¥\u0018W:÷\u0092¡\u008cï\u001a\u0019Ò(\u0087¤ò\u0017ã!=Ï\u0016fV\r\u0005\u0010|\u0097)¥²\u009cµ%TnÜÚy\u001dWd\u0010y\nÊZ\u0010B\u0001ò3r]\u0017Îi\u009a$\u0010aå\u001c\u0080\u0081¨ÙJRJ\u0097\u0006\u0090+\u0089g\u0010ä¡¢m»\u0089·ü\u00ad\n:\u00adw\u0010ÿ\u009f\u0010F\u001f\\\u0014\u000f\u000eD 4\u0099N\u0000\u00adùÛr\u0010\u001cïP¾Oú&Ù¨hk\u008773_7\u0010ï:Xúq/\u001c\u001a®Ú_Æ\u008bçG\"\u0010G½P\u001c$ðI\u0017ü\u0015èÎ\u0089Ø4n\u0010Øà\u0017\u0014¹²\u0095@\u0089\u0082q½\u0010Þ\u0002²\u0010\u0012\u0094c§×ðø2{Ok,xã\"\u009f\u0010³h,j\t Ñ\u0087à\u009búÆÁ`\u0019b\u0010Y`X;úëQö\u0096Õ\u009f\u0013*4µ¾\u0010kÐ\u0093þ1¾Ê-D\u0012\u008e>x£!´\u0010U ¢~û\u008f\u0007 e5Êº³ö4ø\u0018\u001f®°w>\u0010\u009c\u008f'3-h\u0005\\4E[d\u0090ü1Væ\u0093\u00101\u0007\u00040]\u0085\u0003\u0011yM¿es\t\u001aÆ\u0010\u0005ñÃ½\u0016¾ð|Z\u0089\u008e9á\u0015¿¿\u0010\u0003P\tõ[\u000e×AOÖ\u0007*òOx%\u0010\u0001ý\u00ad¼'\u009càa¨øYñ\u009dÑ@\u0016 \u0013\u0098ÏbdF?\u0088C<Ò±0¼&ðñ1&7HÁ\u0004\u0000.\u0083²$\"\u001e/M\u0010\u0086É¯GÂi\u001f\u0080µ¸\u0083\u0019\u0083V\u0002»\u0010ÿÿ\\èl.É\tþõ¶2\u000f8g¹\u0010$WÕõ\tk\u0016.²¥¶\u008cHÌàæ0\u009apd=~Î¨°ù_\u0090É\u0016\u0082°¤ÀmVØT\u0098\u008e/Lå\u0000!4\u008f)â\u000bîSê\u0086Ö|\u0086.Úð\u001a0\u001dÈ³\u0010\u0012\\ëZ\u001de\u0014kU\u0098/{«Í\u0001\u0089\u0010D§á÷Tzz\"à\u0086\u001a>°B¥4"
         .length();
      char var16 = ' ';
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     l = var20;
                     m = new String[35];
                     q = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(12790036125057L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[61];
                     String var4 = "ëü±\u009eeYInh/\u0087Ãð%ôû\u0017\u008cµäÔ\t1\u0089){.s´\u0093Ì\u0017BbÕ\u0013Ì\u0018¢\u0006o:'\u0087/âçM\u00179#8Æ\u0081D\bjFiß\u0084û\u0013¼\u007fG7<}ûu&2\u0001\u008aæ\u001aÊo¹Õáì.\fyÓõX#Z0ÐL\u0016z±(hàÛö4y¿ì6(ÂöìÖ¤\u0016V¤\u0099é\u0080\u008aRû,Bx\u0080OR\u0088«fg©\u009e^\u0095|z\fêô7l\u009b:¶¡ËÜ\u0095Æ`ð(|_Rç\t\bÝfEN\u008a\u0087\u009a\u009b}\u0094:«ã/°n\u009a`J\u001eú¶ªcÐ\u0094O¦®6(\u001a\u0082\u009d÷qÇªÊ¬_{Ed\u00ad=ãÆÓÍãÞ§UÑ\u0010Î\u0016&\u0088EÂ\u0011\u0092û#\nÕ\u0096\u0097ë*uù\u0096\u008dÈ8\u00adõëÂoF\u009eè{t\u007f^?«½\u001f^.\u001aÙ\b}©Ë¤\u0080ÿ¹µµ\u008e`\u0087aº}=\u0000Iv\u0087\u0012\r\u0013£¶\f\u0006\u0000«mÅâ\u0002ò\\T\u008eç'A`³å\u0007\u0017âµbR$\u0081\u0004\u001d½\u0015\u0007ºÓ½e\u009eË8\u007fÄ\u0005ùýø n*\u0091º\u008eÄ»©àñ\u0093Í\u008dÒê\u0096w\u0011ï½ºõ\u0003pziÉÁÐ\u0085\u00ad)\u008a¯7e\u0097cºüí\u0097<Òþ+I'\u0015w\u00adS\u0081Ýäf=8S×Ð\u000f\u0091\u0098ia\u009eé\u0084Ý©|\u0019\u0097A\u0085A¯´Ç\u0083¤}üÇ:×¡\u0011|È(\u009c\u0017Ú\t»áÂ\u0080Ûµ¹fÁÚú\u00800\u0002\u0010V\u000fyHp\u0098\u0080\u008b\u0015\u0096jRÊ\u0086©ºâ½ä\tÌ¥ÉB\u0005¸¼\u000fþuÈ\u0099";
                     int var5 = "ëü±\u009eeYInh/\u0087Ãð%ôû\u0017\u008cµäÔ\t1\u0089){.s´\u0093Ì\u0017BbÕ\u0013Ì\u0018¢\u0006o:'\u0087/âçM\u00179#8Æ\u0081D\bjFiß\u0084û\u0013¼\u007fG7<}ûu&2\u0001\u008aæ\u001aÊo¹Õáì.\fyÓõX#Z0ÐL\u0016z±(hàÛö4y¿ì6(ÂöìÖ¤\u0016V¤\u0099é\u0080\u008aRû,Bx\u0080OR\u0088«fg©\u009e^\u0095|z\fêô7l\u009b:¶¡ËÜ\u0095Æ`ð(|_Rç\t\bÝfEN\u008a\u0087\u009a\u009b}\u0094:«ã/°n\u009a`J\u001eú¶ªcÐ\u0094O¦®6(\u001a\u0082\u009d÷qÇªÊ¬_{Ed\u00ad=ãÆÓÍãÞ§UÑ\u0010Î\u0016&\u0088EÂ\u0011\u0092û#\nÕ\u0096\u0097ë*uù\u0096\u008dÈ8\u00adõëÂoF\u009eè{t\u007f^?«½\u001f^.\u001aÙ\b}©Ë¤\u0080ÿ¹µµ\u008e`\u0087aº}=\u0000Iv\u0087\u0012\r\u0013£¶\f\u0006\u0000«mÅâ\u0002ò\\T\u008eç'A`³å\u0007\u0017âµbR$\u0081\u0004\u001d½\u0015\u0007ºÓ½e\u009eË8\u007fÄ\u0005ùýø n*\u0091º\u008eÄ»©àñ\u0093Í\u008dÒê\u0096w\u0011ï½ºõ\u0003pziÉÁÐ\u0085\u00ad)\u008a¯7e\u0097cºüí\u0097<Òþ+I'\u0015w\u00adS\u0081Ýäf=8S×Ð\u000f\u0091\u0098ia\u009eé\u0084Ý©|\u0019\u0097A\u0085A¯´Ç\u0083¤}üÇ:×¡\u0011|È(\u009c\u0017Ú\t»áÂ\u0080Ûµ¹fÁÚú\u00800\u0002\u0010V\u000fyHp\u0098\u0080\u008b\u0015\u0096jRÊ\u0086©ºâ½ä\tÌ¥ÉB\u0005¸¼\u000fþuÈ\u0099"
                        .length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    o = var6;
                                    p = new Integer[61];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0097\u0001\u00ad\u0006ó\u001c\u0005\u0096UîTæÚA6z";
                                 var5 = "\u0097\u0001\u00ad\u0006ó\u001c\u0005\u0096UîTæÚA6z".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "\u0087Åõÿõ¥6F\u009e\u0004ÓM\u000b^Ýw\u0010\u0092\u0088\u0095gS\u009eW²^\u0097;~\u000e²\u00ad\u008d";
                  var19 = "\u0087Åõÿõ¥6F\u009e\u0004ÓM\u000b^Ýw\u0010\u0092\u0088\u0095gS\u009eW²^\u0097;~\u000e²\u00ad\u008d".length();
                  var16 = 16;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20153;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eB", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eB_C0219",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 624;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eB", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eB_C0219",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 35;
            yield var15;
         }
         case 1 -> {
            byte var16 = 43;
            yield var16;
         }
         case 2 -> {
            byte var17 = 8;
            yield var17;
         }
         case 3 -> {
            byte var18 = 40;
            yield var18;
         }
         case 4 -> {
            byte var19 = 31;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 6;
            yield var21;
         }
         case 7 -> {
            byte var22 = 37;
            yield var22;
         }
         case 8 -> {
            byte var23 = 56;
            yield var23;
         }
         case 9 -> {
            byte var24 = 53;
            yield var24;
         }
         case 10 -> {
            byte var25 = 20;
            yield var25;
         }
         case 11 -> {
            byte var26 = 54;
            yield var26;
         }
         case 12 -> {
            byte var27 = 36;
            yield var27;
         }
         case 13 -> {
            byte var28 = 18;
            yield var28;
         }
         case 14 -> {
            byte var29 = 46;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 3;
            yield var32;
         }
         case 18 -> {
            byte var33 = 29;
            yield var33;
         }
         case 19 -> {
            byte var34 = 49;
            yield var34;
         }
         case 20 -> {
            byte var35 = 9;
            yield var35;
         }
         case 21 -> {
            byte var36 = 17;
            yield var36;
         }
         case 22 -> {
            byte var37 = 0;
            yield var37;
         }
         case 23 -> {
            byte var38 = 39;
            yield var38;
         }
         case 24 -> {
            byte var39 = 59;
            yield var39;
         }
         case 25 -> {
            byte var40 = 14;
            yield var40;
         }
         case 26 -> {
            byte var41 = 41;
            yield var41;
         }
         case 27 -> {
            byte var42 = 5;
            yield var42;
         }
         case 28 -> {
            byte var43 = 16;
            yield var43;
         }
         case 29 -> {
            byte var44 = 52;
            yield var44;
         }
         case 30 -> {
            byte var45 = 63;
            yield var45;
         }
         case 31 -> {
            byte var46 = 62;
            yield var46;
         }
         case 32 -> {
            byte var47 = 22;
            yield var47;
         }
         case 33 -> {
            byte var48 = 44;
            yield var48;
         }
         case 34 -> {
            byte var49 = 28;
            yield var49;
         }
         case 35 -> {
            byte var50 = 38;
            yield var50;
         }
         case 36 -> {
            byte var51 = 32;
            yield var51;
         }
         case 37 -> {
            byte var52 = 30;
            yield var52;
         }
         case 38 -> {
            byte var53 = 13;
            yield var53;
         }
         case 39 -> {
            byte var54 = 10;
            yield var54;
         }
         case 40 -> {
            byte var55 = 25;
            yield var55;
         }
         case 41 -> {
            byte var56 = 47;
            yield var56;
         }
         case 42 -> {
            byte var57 = 42;
            yield var57;
         }
         case 43 -> {
            byte var58 = 55;
            yield var58;
         }
         case 44 -> {
            byte var59 = 4;
            yield var59;
         }
         case 45 -> {
            byte var60 = 61;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 2;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 15;
            yield var64;
         }
         case 50 -> {
            byte var65 = 23;
            yield var65;
         }
         case 51 -> {
            byte var66 = 58;
            yield var66;
         }
         case 52 -> {
            byte var67 = 27;
            yield var67;
         }
         case 53 -> {
            byte var68 = 21;
            yield var68;
         }
         case 54 -> {
            byte var69 = 51;
            yield var69;
         }
         case 55 -> {
            byte var70 = 33;
            yield var70;
         }
         case 56 -> {
            byte var71 = 50;
            yield var71;
         }
         case 57 -> {
            byte var72 = 11;
            yield var72;
         }
         case 58 -> {
            byte var73 = 26;
            yield var73;
         }
         case 59 -> {
            byte var74 = 12;
            yield var74;
         }
         case 60 -> {
            byte var75 = 24;
            yield var75;
         }
         case 61 -> {
            byte var76 = 19;
            yield var76;
         }
         case 62 -> {
            byte var77 = 45;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = ";\u000bw\u00168\";\u000b`J4-!@`T48&11\rmx";
      r[1] = "im\u0005'nWim\u0012{bXs&\u0012ebMtW@;7";
      r[2] = "yj\bXCYyj\u001f\u0004OVc!\u001f\u001aOCdPJE\u0016";
      r[3] = "vJ\u0017uNUhB\r:,Io_";
      r[4] = "N1U\u0018\u001b\bX1PB\b\u001fOzSD\u0004\u000b^=DSO\u001bF=FX\u0015Vz&FE\u0015\u0011M1";
      r[5] = "\u0001(hyLc\u0017(m#_t\u0000cn%S`\u0011$y2\u0018r\u0003";
      r[6] = "~ 'X\u001d\u0013\u000b\u0000,W\f\\j\u000e'\\\b\u0006\u001e";
      r[7] = boolean.class;
      s[7] = "java/lang/Boolean";
      r[8] = "y\t\u001cW&@o\t\u0019\r5WxB\u001a\u000b9Ci\u0005\r\u001crQX";
      r[9] = int.class;
      s[9] = "java/lang/Integer";
      r[10] = "v=*0$\u0017h50\u007fK\u0010n=%\u001dc\u0011h";
      r[11] = "0K~\\y*.Cd\u0013\u001e+?XiI8-";
      r[12] = "BW*\u00157\bBW=I;\u0007X\u001c=W;\u0012_mo\roV";
      r[13] = "\u0006wH\u0006\u0016\u0000\rxYIw\u000e\u0006s]\u0013";
      r[14] = "!DM26\u00187DHh%\u000f \u000fKn)\u001b1H\\yb\u000e\n";
      r[15] = "Hz\u000f\u0019S\u0007=Z\u0004\u0016BH\\T\u000f\u001dF\u0012(";
      r[16] = "dC\u001c fMdC\u000b|jB~\b\u000bbjWyy_:=";
      r[17] = "#pFC\u0013g#pQ\u001f\u001fh9;Q\u0001\u001f}>J\u0003_G9";
      r[18] = double.class;
      s[18] = "java/lang/Double";
      r[19] = "\u00048!\u0011.\u0010\u000486M\"\u001f\u001es6S\"\n\u0019\u0002f\u000es";
      r[20] = "p%\u0011\u0018 8{*\u0000W] h-\t\u001e";
      r[21] = "V\u000e\u0014bQLV\u000e\u0003>]CLE\u0003 ]VK4Ry\n\u0014";
      r[22] = "\u007fogOv8iob\u0015e/~$a\u0013i;ocv\u0004\"-Y";
      r[23] = "iu\u0015U\u0004(bz\u0004\u001ag%ww\u000bqR'fd\u0017]E*";
      r[24] = "9&\\&hLL\u0006W)y\u0003-\b\\\"}YY";
      r[25] = "_\u0014\u0001\u0011Q\u0007I\u0014\u0004KB\u0010^_\u0007MN\u0004O\u0018\u0010Z\u0005\u0013}";
      r[26] = "\u001aGP\u0011O\t\u0004OJ^4)9b";
      r[27] = "\u0014=L\rhy\u0002=IW{n\u0015vJQwz\u00041]F<k\b";
      r[28] = "'\u001bu\u0003\\sR;~\fM<35u\u0007IfG";
      r[29] = "N?\u001bF4B;\u001f\u0010I%\rZ\u0011\u001bB!W.";
      r[30] = void.class;
      s[30] = "java/lang/Void";
      r[31] = "\u0017UB\rVy\u0017UUQZv\r\u001eUOZc\no\u0000\u0017\u000b";
      r[32] = "\u0011.)Job\u0018 *\u0003,l\u00075,\bko\\\u0006%\tg]\u0000.\"\rnh";
      r[33] = "x_M)y\u0002x_Zuu\rb\u0014Zku\u0018ee\u000f4 ";
      r[34] = "4\u00190X@0A9;WQ\u007f 70\\U%T";
      r[35] = "\u0012oc5O>\u0012otiC1\b$twC$\u000fU/-\u001ab";
      r[36] = "\nNdv{\u000f\u001cNa,h\u0018\u000b\u0005b*d\f\u001aBu=/\u001c]";
      r[37] = ")r\f{\u001d\u001b\\R\u0007t\fT=\\\f\u007f\b\u000eI";
      r[38] = "0\u0018\tRq:E8\u0002]`u$6\tVd/P";
      r[39] = "\"2 _t#\"27\u0003x,8y7\u001dx9?\baC,z";
      r[40] = "X\u001dcu\u001e*N\u001df/\r=YVe)\u0001)H\u0011r>J;\u0005";
      r[41] = "+\"7cPT^\u0002<lA\u001b?\f7gEAK";
      r[42] = "p\u001a9\u0015p\u0004\u0005:2\u001aaKd49\u0011e\u0011\u0010";
      r[43] = "2\u000fz>\u000e62\u000fmb\u00029(Dm|\u0002,/5=%Wj";
      r[44] = "u\u001c$\f\"\r\u0000</\u00033Ba2$\b7\u0018\u0015";
      r[45] = "^\u0019D^I)@\u0011^\u0011\u0001)Z\u001bFV\b2\u001a-\\^\u0015%{\bWM\u0006([\n";
      r[46] = "$ }\tia$ jUen>kjKe{9\u001a<\u001519";
      r[47] = ":gS&\u0010\r1hBi}\t1tD$J\u0004\"";
      r[48] = char.class;
      s[48] = "java/lang/Character";
      r[49] = "f\rES^tx\u0005_\u001c?qx\u0005\\\\\u0011m";
      r[50] = "\u0002rM7-|\t}\\xA\u007f\u0007\u007f^7m";
      r[51] = "v\u0018!R8Jv\u00186\u000e4ElS6\u00104Pk\"dNl\u0014<\u001e9\u001d&PGH`Nl";
      r[52] = "\u0016\u0005CJ@4c%HEQ{\u0002+CNU!v";
      r[53] = "\">'g\u001d\u0002\">0;\u0011\r8u0%\u0011\u0018?\u0004byGZ";
      r[54] = "\u0003O!b9g\u001dG;-t}\u0007M\"qew\u0007Zy@x\u007f\u0019B2wvp\u0005K\u0011vcg\u001bK";
      r[55] = "9`r=~+/`wgm<8+taa()lcv*:\u001e";
      r[56] = "\u0000u]`\u001a>uUVo\u000bq\u0014[]d\u000f+`";
      r[57] = "L\b\u0018x%fR\u0000\u00027mfH\n\u001apd}\b*\u0001wxfK\f\u001c";
      r[58] = "]Yzu6\f(yqz'CIwzq#\u0019=";
      r[59] = "^\u00074k_9H\u000711L._L27@:N\u000b% \u000b(e";
      r[60] = "^\u0012@.n:+2K!\u007fuJ<@*{/>";
      r[61] = "\u0017g^\u0006bx\u001chOI\u000f|\u001ct{\u0002=a\u0018hK\u0002";
      r[62] = "4uW4xGAU\\;i\b [W0mRT";
      r[63] = ")@:d\u0018\u0003\\`1k\tL=n:`\r\u0016I";
      r[64] = "\\op C-\\5p,',Kv 'K\u001e\u001f2p}\u001dIH7-/Nx[g2,'3C: $C3\u0019:,@";
      r[65] = "pw|O\u001a'+6aX*vKr<@[}q~h\fD";
      r[66] = "Uf\u0010^@EY2\\A*\u0016igRSW\u001eQcP^U\u0003ib\u0013LSD\u0018&\u0002R\u0011\u007f";
      r[67] = "')\u0012=:o9xKR1k4!\u001c\u0005f2g|p,3h6 \u00152b1";
      r[68] = "x_E4,v+SF&\u0015r|\u0018@\u0010r~xc\u001e6\u007f*/\tJ0\u007f~\u0015";
      r[69] = "{\u0000ZR\b)eQ\u0003=\u0003-h\bTjTt;T8C\u0001.j\t]]Pw";
      r[70] = "\u001alc\u00044!A-~\u0013\u0004~!<'\u0010y Elj\u0018~";
      r[71] = "v-X\b\u001a04b\u001a\u0001\u001a\u0000%\u0010^O\\}.(ZMQ\u007f3\u0010\u0003OP15t\u001c\u000bN\u007fO";
      r[72] = "I#b7qOT}s$L\u001b@>}! )\u0017s#xL\u001bT#e 0\u0000I0oF";
      r[73] = "\b\u001d\u0000LE9\u0016LY#N=\u001b\u0015\u000et\u0019dHLb]L>\u0019\u0014\u0007C\u001dg";
      r[74] = "o%O(hqj I1\u0011q)sO#mw/\u001e\n2!)9}M.`uU";
      r[75] = "+\u00057\"\u0003e9[&=a\u007f*\u001e6:\rM~_hga\u007f9\u0002$6P$?\\?]";
      r[76] = "lhFL\u000bRtz\u0016Oj]\u007fj@E\u001107}G\u0019\u0018];(JCj\fxtP\u001a\u001bHij\u0012!";
      r[77] = ":\u0018\n6<b<N\thWyALQ**ryHS'(oA\u0011Q&fi%\u000e\u00158(\u0013";
      r[78] = "\u0016V<<p@EZ?.I@\u0016\f6/)$E\u00073ksN\u0011\u00013?I";
      r[79] = "8=R\u001eTqzr\u0010\u0017TAj\u0000TY\u0012<`8P[\u001f>}\u0000\tY\u001ep{d\u0016\u001d\u0000>\u0001";
      r[80] = ";r6@\u001e\u0005|nw\u001cr\u0000izzyC\fj2t\u0014OYgh\u0006";
      r[81] = "\u0003\u0001\fjcZ\u0010Q\u0013i\n\u0004\u0000@:yp\n\u000bSah6\u000e\u0002\u0005\u0005;:\r\u0010<";
      r[82] = ",te\t^\u00128tx2_\u001b6pm^mLu/2\f:\b&reW_\u0016w+\nT^\u0019qtn@^\u0004J";
      r[83] = "CX\u007fQyY\u0017^|_\u0002N}_)B\u007fFE[+O}[}\u0002)N3]\u0019\u001dmP}'";
      r[84] = "\u0010?_v*^\u000en\u0006\u0019!Z\u00037QNv\u0003Ph=g#Y\u00016Xyr\u0000";
      r[85] = "\u0013\u0007M\u0005`h@\u000bN\u0017Ym\u0005vM\u0012%}~\u0007V\t 7\u000fCG\u0017b\f";
      r[86] = "*!yI\u001c a)i\u0000zu~?s\u001e\u0016G*s/DD\u0010)xi\u001b\u0003q,}o\u0002z";
      r[87] = "\u001c\u001eN~{?\u0002O\u0017\u0011p;\u000f\u0016@F'b\\B,or8\r\u0017Iq#a";
      r[88] = "#F.Z\u00114pJ-H(=7\u0007\"QSP\u007f\u0010%\rZ=sE(W(l0\u00192\u000eY(!\u0007p5";
      r[89] = "U}\u0001&U%Pt\u0002l2!7(RaO)\u000f,PlM47|Qx]qS/]{OH";
      r[90] = "\u001cVa+\u0002\u0007\u001f\u00144:x\u0014_\u0007v2\u0004\u0012Yj3#HLO\tt?\t\u0010#";
      r[91] = "3EJd5\u0005c\bBc\u0004\bZ@\u0013ey\u0000bD\u0011h{\u001dZERz}Z+\u0001Cd?a";
      r[92] = "AC8i:'HSf(U FR<?9\u0012\u0014\u0015acU+\u0016C31d8F\\0Xi;HWg)-*V\u0015\\<j5\u001aT8#.+T.";
      r[93] = "cR*\u001a\u0002j UkY\u0006\u0003?\u0006g\u0007\u0003o\rV!WZ8Z\u000eb\u0006\u001ce&\u0015\u007f\u0015\u0016\u0003cR~\u001a\b{9U+\u0017\u000f\u0003";
      r[94] = "I;(pn\u0003L2+:\t\u0004+n{7t\u000f\u0013jy:v\u0012+3{;8\u0014O,?%vn";
      r[95] = "c\u0015\u0006mX\u000b0\u0019\u0005\u007fa\u0013im\u0004}\f\u0015E@\u0018oa\u00022L\f;\u0005Q>O\u001e\u0002";
      r[96] = "u7e/Djsafq/r\u000ec>3Rz6g<>Pg\u000e0~ Bzl(lpA\u001b";
      r[97] = "-W5.6\u001a?\t$1T\u0000,L4682x\rdkT\\x\u0001)7=\u001f\u007f@j3T";
      r[98] = "H\tu\u0014m\u001aM\u0000v^\n\u001e*\\&Sw\u0016\u0012X$^u\u000b*\u0002wMm\u000b@\u0015{Fsw";
      r[99] = "\b.p\n:A\u001apa\u0015XP\u0005$u\u0019\u000f\u0007Zy.ua\\\u000eywE*T\u001e0";
      r[100] = "G_VnL0S\u0007\t-/)?\u0007YhR!\u0007\u0003[eP<?SZq@y[\u0000VrR@";
      r[101] = "S)\flk#R%\u0007k\u0007#A;\u0016`k\u0011\u0016xI>7FR+\u0014hb#LzM\u0007x(V,\u001aby$]+v";
      r[102] = "\u007fg^BA\u001eo`^\u001b,\u0016uRD\u0013W\u001ahv>BR\u0014w1O\u0006C\n5\n";
      r[103] = "<v#]j*fqvPmRy/+FO9n\">\\\u0006k>5#\u001by2cw7J\u0006k<*;L~1;\u007f6K\u0006";
      r[104] = "K+d=%>]`5\"Nx]=y(\th4){)<h\r64\u007f0\u0006K+d=%>]`5\"N";
      r[105] = "T[F\u0012[4J\n\u001f}P0GSH*\u0007i\u0015\t$\u0003R3ERA\u001d\u0003j";
      r[106] = "i_:q4IyX:(YOuNZ|3N @7pfCz2";
      r[107] = "n=O\u0000_~n8GO5x3#HYYJca\u0012\u000e5#35\u0010\u0004_w55D>";
      r[108] = "9\\:4sw9Y2{\u0019qdB=muC4\u0000c5\u0019u7O/vwunF:\n";
      r[109] = "\u0013P5(]`Q\u001fw!]P@m3o\u001b-KU7m\u0016/Vmgl\u0002?\u0013\t4`\u0001-*";
      r[110] = "V$\f##\u000e\u0002\"\u000f-X\u001ah$\b&`J\u0002p\u000e&4p";
      r[111] = "YK%O h\u0015\u0016 RYpAH R\u001e`(\u0010#\\ 5YT2Bb\u000eYK%O h\u0015\u0016 RY";
      r[112] = "\u0007\f%RaFT\u0000&@XI\rV<T9D\u00110y\u00038@PY\"BhG\u00060|C;[QA8R%\u0019j";
      r[113] = "\u001b\u007f\fvzE\u0005.U\u0019qA\bw\u0002N&\u0018Z.ngsB\nv\u000by\"\u001b";
      r[114] = "ot0=1\u0003t(+lP\u000b|x&>\u0007_#$scP\u0017|g-36\f ||";
      r[115] = "g&y\u0000\u001fps&d;\u001ey}\"qW,/?{-\n{*l(.\u0001\u0011~j(z;\u001dpnyr_\tpsB";
      r[116] = "\u0011UpU<|\u0018E.\u0014S{\u0016Dt\u0003?IF\b)TSt\u0004Wy\u00051l\u0016\u0007zd8~EUp\u0004/ DY\u0014";
      r[117] = "P:[GFX\u0004<XI=Mn:_B\u0005\u001c\u0004nYBQ&";
      r[118] = ":GUDJ3;K^C&3(UOHJ\u0001\u007f\u0016\u0010\u0016\u0019V{DE\u0017\u001c</BEC&)+SDCC('XC/";
      r[119] = "B+\u0005\t}q\u000ev\u0000\u0014\u0004}T+\u0019\u0014mqm%\u0019\u0004i\u0017\u000f2\u001e\u0000?fK#\u0000B\u0004";
      r[120] = "4gtv*:=;18\u00107Z836m?b<1;o\"Z}w3+'>;7t/^";
      r[121] = "Z\r\u0000z7/SQE4\r\"4RG:p*\fVE7r74[\u001a!3!W[\u001f)|K";
      r[122] = "r\u0005]Q\u0015\u0014`\u0006\u0002Zw\u0013\u0012HU\u0004O\b\u007fD\u0000\t\u0015z";
      r[123] = "Or[\u0000\rQ\\\"D\u0003d\u0005L3V\b\b7\u001dt\nP_`[*\u0006\u000f\u0000\u0004[p\u0006\u0003d";
      r[124] = "sb|g\u0006;a<mxd*~hyt3} ?!\u0018\u000e){4rz\u00079%u";
      r[125] = "\u0013\b\u0005o-\u0000\u0013R\u0005cI\u0001\u0004\u0011Uh%3SR\u000b>ud\u0017\u0001[\u007f0\u0015Y\u001c\f\u007fI\u001e\f]Uk-\u001eV]Y\u000f";
      r[126] = "\u0010Nw/\u0001\u001c[FgfgIDP}x\u000b{\u0013\u001d!\"g\u0012DF%%\rFBFq\u001f\u0015M[C|y\u000e\u0011@\u0012\u001d{X\\\u0018Vyd\u001cBV,";
      r[127] = "\u0019e{\u0006w<Jix\u0014N$\u0013\u0002b\u0013/>\u001bYsU+7M= Y(%t";
      r[128] = "_rBH\u001b[G`\u0012Kz\\XqMB\u0016n\b1\u0012\u001azW\b`BLKDX\u007fA%";
      r[129] = "#eK\u000e~\u0016dy\nR\u0012\u0015uf=Zb\t\u001c!\u0005TkNme\u0014J)u";
      r[130] = "~A7v\u0010Z`\u0010n\u0019\u001b^mI9NL\u00070\u0015Ug\u0019]oH0yH\u0004";
      r[131] = "<%,R41< $\u001d^7a;+\u000b2\u00051{tS^<1*$\u0005o/a5'l";
      r[132] = "0}J$Dj0xBk.lmcM}B^=/\u0015'.5~|T!_qob\u0016\u001a";
      r[133] = "\bW\u0002x^\u0000\u001cW\u001fC_\t\u0012S\n/m]V\u0002R|:\u001a\u0002Q\u0002&_\u0004S\bm%^\u000bUW\t1^\u0016n";
      r[134] = "N~!\n\u000b*N{)Ea$\u0007a/P\u001aIOv(\f\u0013$C#%Vau\u0000\u007f?\u000f\u00101\u0011a}4";
      r[135] = "Mbf:\u001f\u0012^2y9vFN#k2\u001at\u001fd7jN#Ncn:OG\u001dom(vYFok1\u0012Y\u001cogU";
      r[136] = "\u0019C:nf\u0000BEdu\rT\u0011A:{afF\re%\rPBL(`cP\u001bE=\u001ciP\u0003Lg-t\u000e\u0012_Z";
      r[137] = "'=zzy\"t1yh@8#ebx\u0007(J0u{x4'< v\"F'=zzy\"t1yh@";
      r[138] = "?E{{RU6\u0019>5hXQ\u001a<;\u0015Pi\u001e>6\u0017MQ\u001dn-P\u000b;Ih-\u00041";
      r[139] = "\u0007;*C P\u0014k5@I\u0004\u0004z'K%6R>~\u0012ra\u0004:\"Cp\u0005W6!QI\u000fTk(Ex\u001c\u0004t+,";
      r[140] = "h\u0013M#*\u000e/MNv\u007fk8)\u0018s=\u00160\u0011\u001cq0\u0014-)@r0\u0019-G@+9\fQ";
      r[141] = "\u007f_!oK\u001cv\u0003d!q\u0011\u0011V0/\n\u001f}\\?+Kx~P%(\u0016\u0014t_!iq";
      r[142] = "]\u0001WZ96]\u0004_\u0015S0\u0000\u001fP\u0003?\u0002WR\r\\oUQ\u001dS\u001dh$\u0015\fM_S";
      r[143] = "\ru\u0001mHw\u001fv^f*pm8\t8\u0012k\u00004\\5H\u0019\t6\u0013gP}\u0016r\r)*";
      r[144] = "\u0017f\b|`#P8\u000b)5FG\\],w;OdY.z9R\\\u0001jj>H \u001awy4.";
      r[145] = "K-Y\u001dH/\rm\u001e\u00191.Z*@A]\u001c\u000ek\u001c\u001a\u000bK\u0006<N\u001eC&\niCD1";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(946249421533075L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(946249421533075L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(946249421533075L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 193;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 231;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 118;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 81;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 66;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 254;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 193;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 231;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 118;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eB_C0219",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static UnaryOperator invokeBinding1(EnemyFaker var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eB_C0219;)Ljava/util/function/UnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/eB_C0219", "lambda$onLabel$0", "(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (UnaryOperator)var2.invokeExact((EnemyFaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static UnaryOperator invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/UnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eB_C0219", "lambda$onLabel$1", "(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (UnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static UnaryOperator invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/UnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eB_C0219", "lambda$onLabel$2", "(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (UnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static UnaryOperator invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/UnaryOperator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eB_C0219", "lambda$onLabel$3", "(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/text/Style;)Lnet/minecraft/text/Style;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (UnaryOperator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding5(EnemyFaker var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eB_C0219;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eB_C0219", "lambda$onTick$4", "(Ljava/util/Optional;)V"),
                  SourceSupport.methodType("(Ljava/util/Optional;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((EnemyFaker)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
