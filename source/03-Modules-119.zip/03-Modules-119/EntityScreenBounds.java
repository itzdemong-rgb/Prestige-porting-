package dev.zprestige.prestige.client.modules.state;

import net.minecraft.entity.player.PlayerEntity;

public final class EntityScreenBounds {
   public PlayerEntity a;
   public String b;
   public float c;
   public float d;
   public float e;
   public float f;
   public float g;
   public boolean h;

   public EntityScreenBounds() {
   }
}
